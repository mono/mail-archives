// Created by Michael Schurter <michael@susens-schurter.com> on 2007-02-12
// Public Domain - No license, no copyright, steal this code ;)
using System;
using System.Threading;

namespace ServiceTemplate
{
	class ServiceTemplate : System.ServiceProcess.ServiceBase
	{		
		Thread ServiceWorkerThread;
		
		public static void Main ()
		{
			System.ServiceProcess.ServiceBase.Run (new ServiceTemplate ());
		}
		
		public ServiceTemplate ()
		{
			this.ServiceName = "ServiceTemplate";
			this.CanStop = true;
			this.CanPauseAndContinue = false;
			this.AutoLog = true;
			EventLog.WriteEntry (
				String.Format ("{0} Constructed", this.ServiceName)
			);
		}
		
		protected override void OnStart (string[] args)
		{
			EventLog.WriteEntry("Starting...");

			ServiceWorkerThread = new Thread(new ThreadStart (WorkerMethod));
			ServiceWorkerThread.Start();
			
			// Give the worker thread some time to start.
			Thread.Sleep(5000);
			
			/*
			There are lots of interesting ways to test and deal with worker
			thread startup problems.  In this example we're just going to
			pretend everything worked.
			 */
			EventLog.WriteEntry("Started successfully!");
		}
		
		protected override void OnStop ()
		{
			EventLog.WriteEntry("Stopping...");
			
			/*
			This is an awfully mean way to stop a worker thread.  It should
			work, but you may want to consider a "nicer" method like using a
			static volatile class variable as a "Please Stop" flag.
			*/
			ServiceWorkerThread.Abort();
			
			EventLog.WriteEntry ("Stopped successfully!");
		}
		
		private void WorkerMethod ()
		{
			EventLog.WriteEntry ("Worker method started!");
			
			try {
				// MAIN LOOP
				while (true) {
					// Pretend to do some work
					Thread.Sleep(5000);
					EventLog.WriteEntry("WorkerMethod: Jobs done!");
				}
			}
			catch (ThreadAbortException) {
				// Someone's trying to kill us!  Run away!
				EventLog.WriteEntry ("Caught ThreadAbortException.");
			}
			
			EventLog.WriteEntry ("Ending Worker Method");
		}
	}
}