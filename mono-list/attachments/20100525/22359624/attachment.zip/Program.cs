using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Net;
using System.Net.Sockets;

namespace BeginConnect
{
    public class BeginConnectParams
    {
        public IPEndPoint Ip;
        public AsyncCallback Callback;
        public int ConnectTimeout;
        public Socket Socket;
        public AsyncResult<Socket> AsyncResult;

        public BeginConnectParams(Socket sock, IPEndPoint ip, AsyncCallback callback, int connectTimeout, AsyncResult<Socket> asyncResult)
        {
            Ip = ip;
            Callback = callback;
            ConnectTimeout = connectTimeout;
            Socket = sock;
            AsyncResult = asyncResult;
        }
    }   

    class Program
    {
        static int cbs = 500;
        static void ConnAsyncCallback(IAsyncResult ar)
        {            
            Console.WriteLine(Interlocked.Decrement(ref cbs));
            try
            {
                AsyncResult<Socket> sar = (AsyncResult<Socket>)ar;
                Socket sock = sar.EndInvoke();
                Console.WriteLine("Connection Established !");
            }
            catch (Exception e)
            {
                Console.WriteLine("Received exception : " + e);                
            }            
        }

        static void Main(string[] args)
        {
            for (int i = 0; i < 500; i++)
            {
                Socket sock = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                IPEndPoint ep = new IPEndPoint(IPAddress.Parse("74.125.39.99"), 8000); //existing ip, closed port
                AsyncResult<Socket> ar = BeginConnect(sock, ep, ConnAsyncCallback, 10000);

                Console.WriteLine("Connecting...");
            }
            while (Console.ReadKey(true).Key != ConsoleKey.Enter) ;
        }

        /// <summary>
        /// Performs an async Connect operation, and invokes the callback (if given) 
        /// with an AsyncResult&lt;Socket&gt; parameter as the IAsyncResult, upon which EndInvoke should be called.
        /// </summary>
        public static AsyncResult<Socket> BeginConnect(Socket sock, IPEndPoint ip, AsyncCallback callback, int ConnectTimeout)
        {
            AsyncResult<Socket> ar = new AsyncResult<Socket>(callback, null);
            BeginConnectParams bcp = new BeginConnectParams(sock, ip, callback, ConnectTimeout, ar);

            ThreadPool.QueueUserWorkItem(delegate(object tstate)
            {
                Exception connectEx = null;
                BeginConnectParams tbcp = (BeginConnectParams)tstate;
                try
                {
                    Thread t = new Thread(delegate(object ttstate)
                    {
                        BeginConnectParams ttbcp = (BeginConnectParams)ttstate;
                        try
                        {
                            ttbcp.Socket.Connect(ttbcp.Ip);
                        }
                        catch (ThreadAbortException)
                        {
                            return;
                        }
                        catch (Exception e)
                        {
                            connectEx = e;
                        }
                    });
                    t.IsBackground = true;
                    t.Start(tbcp);

                    if (!t.Join(tbcp.ConnectTimeout))
                    {
                        t.Abort();
                        connectEx = new Exception("connect timed out");
                    }

                    if (tbcp.Socket.Connected)
                    {
                        tbcp.AsyncResult.SetAsCompleted(tbcp.Socket, false);
                    }
                    else
                    {
                        tbcp.Socket.Close();
                        tbcp.AsyncResult.SetAsCompleted(connectEx, false);
                    }
                }
                catch (Exception e)
                {
                    tbcp.AsyncResult.SetAsCompleted(e, false);
                }
            }, bcp);

            return ar;
        }
    }
}
