
using System;
using System.Collections;
using System.ComponentModel;
using System.Web;
using System.Web.SessionState;

namespace mysqltest
{
	
	
	public class Global : System.Web.HttpApplication
	{
		
		protected virtual void Application_Start(object sender, EventArgs e)
		{
		}
		
		protected virtual void Session_Start(object sender, EventArgs e)
		{
		}
		
		protected virtual void Application_BeginRequest(object sender, EventArgs e)
		{
		}
		
		protected virtual void Application_EndRequest(object sender, EventArgs e)
		{
		}
		
		protected virtual void Application_AuthenticateRequest(object sender, EventArgs e)
		{
		}
		
		protected virtual void Application_Error(object sender, EventArgs e)
		{
		}
		
		protected virtual void Session_End(object sender, EventArgs e)
		{
		}
		
		protected virtual void Application_End(object sender, EventArgs e)
		{
		}
	}
}
