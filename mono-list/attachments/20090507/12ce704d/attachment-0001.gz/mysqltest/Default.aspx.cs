using System;
using System.Web;
using System.Web.UI;
using System.Data;
using MySql.Data.MySqlClient;

namespace mysqltest
{
	
	
	public partial class Default : System.Web.UI.Page
	{
		
		public virtual void button1Clicked(object sender, EventArgs args)
		{
			
			DataTable dt = new DataTable();
			string connectionstring = "user id=root;database=test;host=localhost;password=passw";
			
			using ( MySqlConnection cn = new MySqlConnection(connectionstring)  )
			{
				string sqlcmd = "SELECT * FROM `product`";

				MySqlCommand cmd = new MySqlCommand( sqlcmd, cn );
                         
				using( MySqlDataAdapter da = new MySqlDataAdapter( cmd ) )
				{
					da.Fill( dt );
				}
			}
			
			button1.Text = "We found " + dt.Rows.Count.ToString() + " records";

		}
	}
}
