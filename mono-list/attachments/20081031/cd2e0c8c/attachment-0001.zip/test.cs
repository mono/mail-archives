using System;
using System.Collections.Generic;
 
namespace  Indy.IL2CPU.IL
{
	public class ConsoleDrv
	{
		public static void Main()
		{
			var xTheType = typeof(ConsoleDrv);
			var xModule = xTheType.Module;
			var xTheMethod = xTheType.GetMethod("Test");
			if(xTheMethod==null){Console.WriteLine("Method not found!");}
			var xReader  =new ILReader(xTheMethod);
			while(xReader.Read())
			{
				Console.WriteLine("Op: " + xReader.OpCode);
				if (xReader.OpCode == OpCodeEnum.Call | xReader.OpCode == OpCodeEnum.Callvirt)
				{
					Console.WriteLine("\tMethod: " + xModule.ResolveMethod(xReader.OperandValueInt32).ToString());
				}
			}
		}
		public static void Test()
		{
			mMyList.Add(5);
		}
		private static List<int> mMyList = new List<int>();
	}
}