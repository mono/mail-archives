using System;
using System.Collections;

namespace Alek.Math {

public class TreeNode {
  public object data;
  public TreeNode leftNode;
  public TreeNode rightNode;
}

public class Evaluator {

  public static char[] allOps = new char[]{'+','-','*','/','^'};
  public static char[][] signList = new char[][]{new char[]{'+','-'},new char[]{'*','/'},new char[]{'^'}}; // an array of char arrays. These determine the order of operations.

  public static string removeSpaces( string sValue ) {
    string[] valueParts = sValue.Split( new char[]{' '}, 50 ); // get an array of words
    string noSpaces = "";
    foreach ( string s in valueParts ) // recombine
      noSpaces += s;
    return noSpaces;
  }

  public static bool containsOp( char testChar, char[] operators ) { // test if char is an operator
    foreach ( char op in operators ) {
      if ( testChar == op )
	return true;
    }
    return false;
  }

  public static ArrayList getSigns( string sValue, char[] activeOps, char[] allOps ) { // return an array of ints, each an index of an operator
    // activeOps = operators we're currently looking for
    int numParens = 0;
    ArrayList signs = new ArrayList();
    bool ignoreSign = false;
    for ( int i = 0; i < sValue.Length-1; i++ ) {
      if ( i > 0 ) // allow for negative numbers, since '-' is also a subtraction sign
	ignoreSign = containsOp( sValue[i-1], allOps );
      if ( containsOp( sValue[i], activeOps ) && numParens == 0 && !ignoreSign && i > 0 )
	signs.Add( i );
      else if ( sValue[i] == '(' ) // don't add any ops inside parentheses
	numParens++;
      else if ( sValue[i] == ')' )
	numParens--;
    }
    return signs;
  }

  public static string removeParens( string sValue ) { // remove any parentheses around entire statement

    /* This is kind of complicated. We know each open parenthesis has a closing
    one. If either the opening or the closing parenthesis is not one of the
    parentheses on the edge, then it's a false parenthesis, and we get rid of
    it. For example, in the statement - ((2+3)(5*(4+5))) -the first parenthesis
    has a closing one at the very end, so it's a false one and we can get rid
    of it.The second openeing one, however, has a closing one inside the body
    of the statement, so we'll keep it.  If we didn't do this check, we'd
    output: 2+3)*(4+5. Instead, we output: (2+3)*(4+5), and go on our merry
    way. */

    int c = sValue.Length-1;
    while ( sValue[c] == ')' ) // find edge of ending parentheses
      c--;
    c++;

    int a = 0;
    int falseParens = 0; // number of extraneous parentheses
    while ( sValue[a] == '(' ) { // match starting opening parenthesis to its closing one
      bool stopIterating = false;
      int x = a+1;
      int numParens = 1;
      while ( !stopIterating ) {
	if ( sValue[x] == '(' )
	  numParens++;
	else if ( sValue[x] == ')' ) {
	  numParens--;
	  if ( numParens == 0 ) { // we've found our match!
	    stopIterating = true;
	    if ( x >= c ) // if it's an ending parenthesis, get rid of it
	      falseParens++;
	  }
	}
	else if ( x == sValue.Length-1 )
	  throw new Exception( "Invalid parenthesis at: " + a );
	x++;
      }
      a++;
    }
    string rValue = sValue.Substring( falseParens, sValue.Length-falseParens*2 ); // cut out extra parentheses

    return rValue;
  }

  public static void processValue( string sValue, TreeNode rootNode, ArrayList signs ) {
    rootNode.data = sValue[ (int)signs[ signs.Count-1 ] ]; // use the last operator

    // get strings to the left and right of the operator
    string leftNodeValue = sValue.Substring( 0, (int)signs[ signs.Count-1 ]);
    string rightNodeValue = sValue.Substring( (int)signs[ signs.Count-1 ]+1, sValue.Length - (int)signs[ signs.Count-1 ]-1 );

    // and construct new nodes with those
    rootNode.leftNode = makeNode( leftNodeValue );
    rootNode.rightNode = makeNode( rightNodeValue );
  }

  public static TreeNode makeNode( string sValue ) {

    /* This function is called recursively to make a binary tree of the entire
       operation.  It returns the root node of the tree.  Each node holds data,
       a left node, and a right node.  Data will be either an operation or a
       value.  Operations to be done last are put at the top, and values will
       be at the bottom. */

    sValue = removeParens( sValue );
    TreeNode rootNode = new TreeNode(); // the node we're making
    bool hasOp = false;
    int i = 0;
    while ( !hasOp && i < signList.Length ) { // check for any operations
      ArrayList signs = getSigns( sValue, signList[i], allOps );
      if ( signs.Count > 0 ) { // there's an operation; make new nodes
	hasOp = true;
	processValue( sValue, rootNode, signs );
      }
      i++;
    }
    if ( !hasOp ) // no operations
      rootNode.data = sValue; // store value

    return rootNode;
  }

  public static double execNode( TreeNode node ) { // execute the binary tree
    if ( node.data is char ) { // operation was stored
      if ( (char)node.data == '+' )
	return execNode( node.leftNode ) + execNode( node.rightNode );
      else if ( (char)node.data == '-' )
	return execNode( node.leftNode ) - execNode( node.rightNode );
      else if ( (char)node.data == '*' )
	return execNode( node.leftNode ) * execNode( node.rightNode );
      else if ( (char)node.data == '/' )
	return execNode( node.leftNode ) / execNode( node.rightNode );
      else if ( (char)node.data == '^' )
	return System.Math.Pow( execNode( node.leftNode ), execNode( node.rightNode ) );
    }
    return Convert.ToDouble( (string)node.data ); // a value was stored; convert
  }

  public static double eval( string sValue ) {
    return execNode( makeNode( removeSpaces( sValue ) ) );
  }
}
}
