using System;
using System.Threading;
using Alek.Math;

public class Test {

  public static void benchMark() {
    string testValue = "";
    Console.WriteLine( "Now performing one thousand random calculations..." );
    for ( int i = 0; i < 1000; i++ ) {
      Random random = new Random();
      testValue += random.Next(10).ToString();
      int opID = random.Next(2);
      if ( opID == 0 )
	testValue += "+";
      else if ( opID == 1 )
	testValue += "-";
    }
    testValue += "5";
    DateTime before = DateTime.Now;
    Evaluator.eval( testValue );
    DateTime after = DateTime.Now;
    Console.WriteLine( "Calculation took: " + ((after.Ticks-before.Ticks)/1000) + " milliseconds" ); // this time seems to decrease every time I benchmark
  }

  public static void Main() {
    bool quit = false;
    Console.WriteLine( "Welcome to the eval() tester! Type 'bench' to benchmark, or 'quit' to quit." );
    while ( !quit ) {
      Console.Write( "Please enter a mathematical expression: " );
      string sValue = Console.ReadLine().Trim();
      if ( sValue.ToLower() == "bench" )
	benchMark();
      else if ( sValue.ToLower() == "quit" )
	quit = true;
      else
	Console.WriteLine( "Result: " + Evaluator.eval( sValue ) );
    }
  }
}
