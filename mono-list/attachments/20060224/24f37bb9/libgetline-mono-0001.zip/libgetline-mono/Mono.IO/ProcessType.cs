using System;

namespace Mono.IO
{
    public enum ProcessType
    {
        Managed,
        GetLine,
        ReadLine,
        EditLine
    }
}