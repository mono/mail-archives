using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Collections;

namespace Mono.IO
{
	public sealed class Readline
	{
		#region ctor
		private static Readline()
		{
		}
		#endregion

		#region Fields
		private static Encoding encoding = Encoding.ASCII;
		private static bool throwException = false;
		private static ProcessType processType = ProcessType.GetLine;
		private static TextReader reader = null;
		#endregion

		#region Properties
		public static Encoding Encoding
		{
			get { return encoding; }
			set { encoding = value; }
		}

		public static bool ThrowException
		{
			get { return throwException; }
			set { throwException = value; }
		}

		public static ProcessType ProcessType
		{
			get { return processType; }
			set { processType = value; }
		}
		#endregion

		#region Private Extern Static Methods
		[DllImport("libgetline-mono")]
		private static extern void mono_getline_init(string appName);

		[DllImport("libgetline-mono")]
		private static extern void mono_cleanup_readline();

		[DllImport("libgetline-mono")]
		private static extern bool mono_hasterminal();

		[DllImport("libgetline-mono")]
		private static extern void mono_addtohistory(string line);

		[DllImport("libgetline-mono")]
		private static extern string mono_readline(string prompt);

		[DllImport("libgetline-mono")]
		private static extern void mono_gethistory(ICollection lines);

		[DllImport("libgetline-mono")]
		private static extern void mono_clear_history();

		[DllImport("libgetline-mono")]
		private static extern string mono_get_history_line(int index);

		[DllImport("libgetline-mono")]
		private static extern int mono_get_history_size();

		[DllImport("libgetline-mono")]
		private static extern void mono_read_init_file(string fileName);

		[DllImport("libgetline-mono")]
		private static extern bool mono_parse_and_bind(string line);

		[DllImport("libgetline-mono")]
		private static extern void mono_read_history_file(string fileName);

		[DllImport("libgetline-mono")]
		private static extern void mono_write_history_file(string fileName);

		[DllImport("libgetline-mono")]
		private static extern void mono_set_completer(/*TODO: What argument!?!?*/);

		[DllImport("libgetline-mono")]
		private static extern string mono_get_line_buffer();
		#endregion

		#region Public Static Methods
		public static void Init(string appName)
		{
			if (processType == ProcessType.ReadLine ||
				processType == ProcessType.EditLine ||
				processType == ProcessType.GetLine)
				mono_getline_init(appName);
		}

		public static string ReadLine(string prompt, bool addToHistory)
		{
			if (processType != ProcessType.Managed)
			{
				string line = mono_readline(prompt);
				if (line != null && addToHist)
					AddToHistory(line);
				return line;
			}
			else
			{
				Console.Out.Write(prompt);
				if (reader == null)
				{
					if (encoding == null)
						reader = new StreamReader(new BufferedStream(Console.OpenStandardInput()));
					else
						reader = new StreamReader(new BufferedStream(Console.OpenStandardInput(), encoding));
				}
				string line = reader.ReadLine();
				if (line == null)
					throw new EndOfStreamException();
				if (line.Length == 0)
					line = null;
				return line;
			}
		}

		public static string ReadLine(string prompt)
		{
			return ReadLine(prompt, true);
		}

		public static void AddToHistory(string line)
		{
			if (processType == ProcessType.ReadLine ||
				processType == ProcessType.EditLine ||
				processType == ProcessType.GetLine)
				mono_addtohistory(line);
			else if (throwException)
				throw new NotSupportedException();
		}

		public static void GetHistory(ICollection collection)
		{
			if (processType == ProcessType.ReadLine ||
				processType == ProcessType.EditLine)
				mono_clear_history(collection);
			else if (iThrowException)
				throw new NotSupportedException();
		}

		public static int GetHistorySize()
		{
			int result = 0;
			if (processType == ProcessType.ReadLine ||
				processType == ProcessType.EditLine)
				result = mono_get_history_size();
			else if (throwException)
				throw new NotSupportedException();
			return result;
		}

		public static void ClearHistory()
		{
			if (processType == ProcessType.ReadLine ||
				processType == ProcessType.EditLine)
				mono_clear_history();
			else if (throwException)
				throw new NotSupportedException();
		}

		public static string GetHistoryLine(int i)
		{
			string s = null;
			if (processType == ProcessType.Readline ||
				processType == ProcessType.EditLine) {
				if (i < 0 || i >= GetHistorySize())
					throw new IndexOutOfRangeException();
				s = mono_get_history_line(i);
			} else if (throwException)
				throw new NotSupportedException();
			return s;
		}

		public static void ReadInitFile(string fileName)
		{
			if (processType == ProcessType.ReadLine)
				mono_read_init_file(fileName);
			else if (throwException)
				throw new NotSupportedException();
		}

		public static bool ParseAndBind(string line)
		{
			if (processType == ProcessType.ReadLine)
				return mono_parse_and_bind(line);
			else if (throwException)
				throw new NotSupportedException();
			return true;
		}

		public static void ReadHistoryFile(string fileName)
		{
			if (processType == ProcessType.ReadLine || 
				processType == ProcessType.EditLine)
				mono_read_history_file(fileName);
			else if (throwException)
				throw new NotSupportedException();
		}

		public static void WriteHistoryFile(string filename)
		{
			if (processType == ProcessType.ReadLine || 
				processType == ProcessType.EditLine)
				mono_write_history_file(fileName);
			else if (throwException)
				throw new NotSupportedException();
		}

		public static void SetCompleter(/*TODO: What argument?!?!*/)
		{
			if (processType == ProcessType.ReadLine ||
				processType == ProcessType.EditLine)
			{
				mono_set_completer(/*TODO:*/);
			} else if (throwException)
				throw new NotSupportedException();
		}

		public static void Cleanup()
		{
			if (processType == ProcessType.ReadLine ||
				processType == ProcessType.EditLine)
			{
				mono_cleanup_readline();
			}
		}

		public static bool HasTerminal()
		{
			if (processType == ProcessType.ReadLine ||
				processType == ProcessType.EditLine)
			{
				return mono_hasterminal();
			}
			return true;
		}

		public static string GetLineBuffer()
		{
			if (processType == ProcessType.ReadLine || 
				processType == ProcessType.EditLine)
				return mono_get_line_buffer();
			else if (iThrowException)
				throw new UnsupportedOperationException();
			else
				return null;
		}
		#endregion
	}
}