#ifdef WIN32
#include <windows.h>
#endif
#include "mono_readline.h"

#if MONO_GETLINE
#include "getline.h"
#endif

#ifdef MONO_READLINE
#include <readline/readline.h>
#include <readline/history.h>
#endif

#ifdef MONO_EDITLINE
#include <editline/readline.h>
#endif

#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include <errno.h>
#ifndef WIN32
#include <unistd.h>
#endif

/* -------------------------------------------------------------------------- */
/* Global buffer. The buffer is allocated when needed and grows in steps of   */
/* 1024. It is never freed, but this is not a problem since in realistic      */
/* environments it should never be larger than a few KB. This strategy will   */
/* prevent constant malloc/free-cycles and keeps the code clean.              */
/*                                                                            */
/* TODO: buffer is changed by utf82ucs and ucs2utf8, but this is not really   */
/*       transparent. Add some additional comments.                           */
/*       Change the variable name buffer to globalBuffer.                     */
/* -------------------------------------------------------------------------- */

static char*  buffer = NULL;
static size_t bufLength = 0;

static char*  word_break_buffer = NULL;

static char* utf2ucs(const char *utf8);
static char* ucs2utf(const char *ucs);
static int   allocBuffer(size_t n);

extern void mono_getline_init(const char* appName) {
    if (appName && strlen(appName))
        rl_readline_name = strdup(appName);
    else
        rl_readline_name = strdup("MONO");
#ifdef MONO_READLINE
    rl_catch_signals = 0;
#endif
#ifndef MONO_GETLINE
    rl_initialize();
#endif
    using_history();
}

extern void mono_cleanup_getline() {
#ifdef MONO_READLINE
    rl_free_line_state();
    rl_cleanup_after_signal();
#endif
}

#if MONO_GETLINE
extern bool mono_hasterminal() {
    return (bool)isatty(STDIN_FILENO);
}
#endif

extern void mono_addtohistory(const char* line) {
    if (!utf2ucs(line))
        return;
    add_history(buffer);
}

extern const char* mono_readline(const char* prompt) {
    char* input;
    
    if (!utf2ucs(prompt))
        return NULL;
    
    /* use gnu-readline, convert string to utf8 ------------------------------- */
    
    input = readline(buffer);
    if (input == NULL) {
        return NULL;
    } else if (*input) {
        ucs2utf(input);
        return buffer;
    } else {
        return NULL;
    }
}

#ifndef MONO_GETLINE
extern void mono_gethistory(/*TODO: What argument!?!?*/) {
#ifdef MONO_READLINE
    HIST_ENTRY **hist;
#endif
#ifdef MONO_EDITLINE
    HIST_ENTRY *histSingle;
    int pos;
#endif

#ifdef MONO_READLINE
    hist = history_list();
    if (hist != NULL) {
        while (*hist != NULL) {
            // (*hist)->line ...
            hist++;
        }
    }
#endif

#ifdef MONO_EDITLINE
    for (pos = 0; pos < history_length; pos++) {
        histSingle = history_get(pos + 1);
        if (histSingle) {
            ucs2utf(histSingle->line);
            //TODO: a new UTF string should be constructed on the buffer
        }
    }
#endif
}
#endif

/* -------------------------------------------------------------------------- */
/* Clear the current history buffer                                           */
/* -------------------------------------------------------------------------- */
extern void mono_clear_history() {
     clear_history();
}

/* -------------------------------------------------------------------------- */
/* Get nth entry from history file                                            */
/* -------------------------------------------------------------------------- */
#if MONO_GETLINE
extern const char* mono_get_history_line(int index) {
    HIST_ENTRY *hist = NULL;

    if ((hist = history_get((int) (index + 1))) != NULL) {
        ucs2utf(hist->line);
        // This should return an UTF string constructed on the buffer...
        return NULL;
    }
    return NULL;
}
#endif

/* -------------------------------------------------------------------------- */
/* Get the size of the history buffer.                                        */
/* -------------------------------------------------------------------------- */

#ifndef MONO_GETLINE
extern int mono_get_history_size() {
    return history_length;
}
#endif

/* -------------------------------------------------------------------------- */
/* Read keybindings from file.                                                */
/* -------------------------------------------------------------------------- */

#ifdef MONO_READLINE
extern void mono_read_init_file(const char *filename) {
    /* retrieve filename argument and convert to ucs -------------------------- */

    if (!utf2ucs(filename))
        return;

    /* pass to readline function ---------------------------------------------- */

    if (rl_read_init_file(buffer))
        return;
}
#endif

/* -------------------------------------------------------------------------- */
/* Read keybinding from string.                                               */
/* -------------------------------------------------------------------------- */

#ifdef MONO_READLINE
extern bool mono_parse_and_bind(const char* line) {
    /* retrieve line argument and convert to ucs -------------------------- */

    if (!utf2ucs(line))
        return FALSE;
        
    /* pass to readline function ---------------------------------------------- */

    if (rl_parse_and_bind(buffer))
        return FALSE;
    else
        return TRUE;
}
#endif

/* -------------------------------------------------------------------------- */
/* Read history file                                                          */
/* -------------------------------------------------------------------------- */

#ifndef MONO_GETLINE
extern void mono_read_history_file(const char* filename) {
    /* retrieve filename argument and convert to ucs -------------------------- */

    if (!utf2ucs(filename))
        return;
    
    /* pass to history function ----------------------------------------------- */
    read_history(buffer);
}
#endif

/* -------------------------------------------------------------------------- */
/* Write history file                                                         */
/* -------------------------------------------------------------------------- */

#ifndef MONO_GETLINE
extern void mono_write_history_file(const char* filename) {  
    /* retrieve filename argument and convert to ucs -------------------------- */

    if (!utf2ucs(filename))
        return;
    
    /* pass to history function ----------------------------------------------- */
    
    write_history(buffer);
}
#endif

#ifndef MONO_GETLINE
extern void set_completer(rl_compentry_func_t function) {
#if MONO_GETLINE
    rl_completion_entry_function = function;
#else
    rl_completion_entry_function = NULL;
#endif
}
#endif
