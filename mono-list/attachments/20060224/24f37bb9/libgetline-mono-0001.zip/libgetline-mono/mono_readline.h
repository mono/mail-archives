#ifndef MONO_READLINE_H
#define MONO_READLINE_H

extern void mono_getline_init(const char* appName);
extern void mono_cleanup_readline();
extern bool mono_hasterminal();
extern const char* mono_readline(const char* prompt);

extern void mono_addtohistory(const char* line);
extern void mono_gethistory(/*TODO: What argument!?!?*/);
extern void mono_clear_history();
extern const char* mono_get_history_line(int index);
extern int mono_get_history_size();
extern void mono_read_history_file(const char* filename);
extern void mono_write_history_file(const char* filename);

extern void mono_read_init_file(const char *filename);
extern bool mono_parse_and_bind(const char* line);

extern void mono_set_completer(rl_compentry_func_t function);
