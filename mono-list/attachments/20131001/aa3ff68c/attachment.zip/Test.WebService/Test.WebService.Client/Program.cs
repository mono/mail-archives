﻿using System;
using System.Configuration;

namespace Test.WebService.Client {
    class Program {
        static void Main() {
            try {
                var proxy = new SampleWebService { Url = ConfigurationManager.ConnectionStrings["SampleWebService"].ConnectionString };
                var result = proxy.SampleMethod("Test", 0, false);
                Console.WriteLine(result);
            }
            catch (Exception ex) {
                Console.WriteLine(ex.ToString());
            }
            Console.WriteLine("Press <enter> to exit...");
            Console.ReadLine();
        }
    }
}
