﻿using System;
using System.Web.Services;

namespace Test.WebService {
    [WebService(Namespace = "http://sample.webservice.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    public class SampleWebService : System.Web.Services.WebService {

        [WebMethod]
        public string SampleMethod(string name, int age, [System.Xml.Serialization.XmlIgnoreAttribute()] bool ageSpecified) {
            return String.Format("Hello, {0}, your age is: {1}", name, ageSpecified ? age.ToString() : "<undefined>");
        }

    }
}
