using System;
using Gtk;
using Gdk;
using Gnome;

using NHibernate;
using NHibernate.Cfg;


public class MyWindow : Gtk.Window
{	


	IconList ic;
	Disco[] discos;
	
	public MyWindow () : base ("MyWindow")
	{
		this.SetDefaultSize (400, 300);
		this.DeleteEvent += new DeleteEventHandler (OnMyWindowDelete);
		
		
		discos = new Disco[2];
		
		PopulateDiscos();


		ic = new IconList(64,null,0);
		
		foreach (Disco i in discos){
			Console.WriteLine (i.Id+" "+i.NDisco+" "+i.Imagen);
			ic.Append (i.Imagen , i.NDisco);
		}
		
		ic.IconSelected += new IconSelectedHandler (IconSelect);
		
		Add(ic);
		
		
		Configuration cfg = new Configuration();
		ISessionFactory factory = cfg.BuildSessionFactory();
		ISession session = factory.OpenSession();
		ITransaction transaction = session.BeginTransaction();
		
		Disco d = new Disco(696969,"Hooola","Chaaao");
		
		session.Save(d);
		
		//transaction.Commit();
		//session.Close();
		
	}
	
	void PopulateDiscos(){
		discos[0] = new Disco(0,"artista1","disco1");
		discos[1] = new Disco(1,"artista2","disco2");
	}
	
	void IconSelect(object o, Gnome.IconSelectedArgs a){
	
		if (a.Event == null)
			return;
	
	
		int idx = a.Num;
		EventButton ev = new EventButton (a.Event.Handle);
		if ( ev.Type == EventType.TwoButtonPress )
			Console.WriteLine ("hey "+discos[idx].Id+" "+discos[idx].NDisco);
	
	}
	
	
	void OnMyWindowDelete (object sender, DeleteEventArgs a)
	{
		Application.Quit ();
		a.RetVal = true;
	}
}