// project created on 04/07/2005 at 12:38
using System;
using Gtk;




class MainClass
{
	public static void Main (string[] args)
	{
		Application.Init ();
		MyWindow w = new MyWindow ();

		w.ShowAll ();
		Application.Run ();
	}
	

}