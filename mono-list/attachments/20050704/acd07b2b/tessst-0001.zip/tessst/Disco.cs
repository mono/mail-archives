using System;


public class Disco {

	private int id;
	private string disco;
	private string nartista;
	private DateTime hora_llegada;
	private string imagen;
	private int ano;
	private string pais;


	public Disco(){
	}
	public Disco(int a, string b, string c){
		Id=a;
		NDisco=b;
		NArtista=c;
		Imagen="defecto.jpg";
	}
	
	
	public int Id{
		get { return id;}
		set { id = value; }
	}
	public string NDisco{
		get { return disco;}
		set { disco = value;}
	} 
	public string NArtista{
		get { return nartista;}
		set { nartista = value;}
	}
	
	public DateTime HoraLlegada{
		get {return hora_llegada;}
		set {hora_llegada=value;}
	}
	public string Imagen{
		get {return imagen;}
		set {imagen = value;}
	}
	public int Ano{
		get {return ano;}
		set {ano = value;} 
	}
	public string Pais{
		get {return pais;}
		set {pais = value;}
	}
	

}
