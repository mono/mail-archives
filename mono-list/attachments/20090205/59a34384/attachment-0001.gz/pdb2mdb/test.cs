using System;

class Program
{
	static void Main ()
	{
		throw new NotImplementedException ();
	}
}
