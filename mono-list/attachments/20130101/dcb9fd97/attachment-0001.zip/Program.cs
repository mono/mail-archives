﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;

namespace AesProof
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Encrypting \"Hello, world!\" (in UTF-8) with AES/CFB8 without padding.");
            Console.WriteLine("Using 00 01 02 03 04 05 06 07 08 09 0A 0B 0C 0D 0E 0F as the key.");

            var data = Encoding.UTF8.GetBytes("Hello, world!");
            var stream = new MemoryStream();
            var cryptoStream = new AesStream(stream, new byte[] {
                0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
                0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F });
            cryptoStream.Write(data, 0, data.Length);
            var encrypted = stream.GetBuffer();

            Console.Write("Result: ");
            for (int i = 0; i < data.Length; i++) Console.Write(encrypted[i].ToString("X2"));
            Console.WriteLine();

            Console.WriteLine("Decrypting result");
            cryptoStream = new AesStream(stream, new byte[] {
                0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
                0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F });
            cryptoStream.Read(data, 0, data.Length);
            Console.WriteLine("Result: " + Encoding.UTF8.GetString(data));
        }

        public class AesStream : Stream
        {
            private CryptoStream decryptStream { get; set; }
            private CryptoStream encryptStream { get; set; }
            internal byte[] Key { get; set; }

            public AesStream(Stream stream, byte[] key)
            {
                BaseStream = stream;
                Key = key;
                var rijndael = GenerateAES(key);
                var encryptTransform = rijndael.CreateEncryptor();
                var decryptTransform = rijndael.CreateDecryptor();

                encryptStream = new CryptoStream(BaseStream, encryptTransform, CryptoStreamMode.Write);
                decryptStream = new CryptoStream(BaseStream, decryptTransform, CryptoStreamMode.Read);
            }

            public Stream BaseStream { get; set; }

            private static Rijndael GenerateAES(byte[] key)
            {
                var cipher = new RijndaelManaged();
                cipher.Mode = CipherMode.CFB;
                cipher.Padding = PaddingMode.None;
                cipher.KeySize = 128;
                cipher.FeedbackSize = 8;
                cipher.Key = cipher.IV = key;
                return cipher;
            }

            public override bool CanRead
            {
                get { return true; }
            }

            public override bool CanSeek
            {
                get { return false; }
            }

            public override bool CanWrite
            {
                get { return true; }
            }

            public override long Length
            {
                get { throw new NotSupportedException(); }
            }

            public override long Position
            {
                get { return 0; } // hack for libnbt
                set { throw new NotSupportedException(); }
            }

            public override void Flush()
            {
                BaseStream.Flush();
            }

            public override int ReadByte()
            {
                return decryptStream.ReadByte();
            }

            public override int Read(byte[] buffer, int offset, int count)
            {
                return decryptStream.Read(buffer, offset, count);
            }

            public override long Seek(long offset, SeekOrigin origin)
            {
                throw new NotSupportedException();
            }

            public override void SetLength(long value)
            {
                throw new NotSupportedException();
            }

            public override void Write(byte[] buffer, int offset, int count)
            {
                encryptStream.Write(buffer, offset, count);
            }

            public override void Close()
            {
                decryptStream.Close();
                encryptStream.Close();
            }

            public override IAsyncResult BeginRead(byte[] buffer, int offset, int count, AsyncCallback callback, object state)
            {
                return decryptStream.BeginRead(buffer, offset, count, callback, state);
            }

            public override IAsyncResult BeginWrite(byte[] buffer, int offset, int count, AsyncCallback callback, object state)
            {
                return encryptStream.BeginWrite(buffer, offset, count, callback, state);
            }

            public override int EndRead(IAsyncResult asyncResult)
            {
                return decryptStream.EndRead(asyncResult);
            }

            public override void EndWrite(IAsyncResult asyncResult)
            {
                encryptStream.EndWrite(asyncResult);
            }
        }
    }
}
