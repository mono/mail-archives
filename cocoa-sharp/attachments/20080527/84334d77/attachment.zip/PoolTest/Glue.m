// compile with: gcc glue.m -framework Foundation -ggdb -o glue.dylib -dynamiclib
#include <Foundation/Foundation.h>
#include <objc/message.h>
#include <objc/runtime.h>

typedef id (*Methodv)(void*, void*);
typedef id (*Methodp)(void*, void*, void*);
typedef id (*Methodr)(void*, void*, void**);

void Test()
{
	@try
	{			
		printf("********* testing\n");
		// obj = Construct ("NSAutoreleasePool")
		// new Object (Messaging.objc_msgSend (new Class (klass).Handle, aselector.Handle))
		id klass = objc_getClass("NSAutoreleasePool");
		id obj = ((Methodv) objc_msgSend)(klass, @selector(alloc));
		
		// Init()
		// Call (this, "init");
		// MethodSignature signature = new MethodSignature (obj, sel);
		// Messaging.objc_msgSend (obj.Handle, msfsSelector.Handle, selector.Handle);
		NSMethodSignature* sig = ((Methodp) objc_msgSend)(obj, @selector(methodSignatureForSelector:), @selector(init));

		// Invocation invocation = new Invocation (signature) {Target = obj, Selector = sel};
		// handle = Messaging.objc_msgSend (cls.Handle, iwmsSelector.Handle, signature.Handle);
		id clsHandle = objc_getClass("NSInvocation");
		NSInvocation* handle = ((Methodp) objc_msgSend)(clsHandle, @selector(invocationWithMethodSignature:), sig);
		
		// Messaging.objc_msgSend (handle, new Selector ("setTarget:").Handle, target.Handle);
		((Methodp) objc_msgSend)(handle, @selector(setTarget:), obj);
		
		// Messaging.objc_msgSend (handle, new Selector ("setSelector:").Handle, selector.Handle);
		((Methodp) objc_msgSend)(handle, @selector(setSelector:), @selector(init));
		
		// Messaging.objc_msgSend (handle, new Selector ("invoke").Handle);
		((Methodv) objc_msgSend)(handle, @selector(invoke));		// this is where we crash when using managed code

		// IntPtr v = IntPtr.Zero;
		// Messaging.objc_msgSend (handle, new Selector ("getReturnValue:").Handle, ref v);
		id pool2;																		// original code doesn't use init return value
		((Methodr) objc_msgSend)(handle, @selector(getReturnValue:), (void**) &pool2);	// but it does get it
		
		[obj drain];
		printf("********* all done\n");
	}
	@catch (NSException* e)
	{
		printf("********* exception: %s %s\n", [[e name] UTF8String], [[e reason] UTF8String]);
	}
} 

