// compile with: gcc UTest.m -framework Foundation -ggdb -o test.exe
#include <Foundation/Foundation.h>
#include <objc/message.h>
#include <objc/runtime.h>
#include <dlfcn.h>

int main()
{
	@try 
	{
		void* lib_handle = dlopen("glue.dylib", RTLD_LOCAL|RTLD_LAZY);
        if (!lib_handle) 
        {
            printf("[%s] Unable to load library: %s\n", __FILE__, dlerror());
            exit(1);
        }
 
        void (*test)() = dlsym(lib_handle, "Test");
        if (!test) {       
            printf("[%s] Unable to get symbol: %s\n", __FILE__, dlerror());
            exit(1);
        }
        test();
  
        if (dlclose(lib_handle) != 0) {
            printf("[%s] Problem closing library: %s", __FILE__, dlerror());
        } 
	}
	@catch (NSException* e)
	{
		printf("exception: %s %s\n", [[e name] UTF8String], [[e reason] UTF8String]);
	}
	@catch (id ie)
	{
		printf("weird exception: %s\n", [[ie description] UTF8String]);
	}
			
	return 0;
} 

