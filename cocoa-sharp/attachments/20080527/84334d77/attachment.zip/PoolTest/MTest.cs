// compile with: gmcs -out:app.exe MTest.cs
using System;
using System.Runtime.InteropServices;


public class Program
{
	[DllImport("glue.dylib")]
	public extern static void Test();

	public static void Main()
	{ 		
		Test(); 
	}
} 
