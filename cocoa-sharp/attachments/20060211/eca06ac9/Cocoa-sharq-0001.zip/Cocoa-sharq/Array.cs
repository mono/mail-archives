using System;
using Cocoa.Interop;

namespace Cocoa {
	[ObjectiveCClass ("NSArray")]
	public class Array : Object {
		public Array (IntPtr id) : base (id)
		{
		}
		
		public int Count {
			get {
				return (int)(uint)ObjectiveC.SendMessage (Id, "count", typeof (uint));
			}
		}
		
		public ObjectiveCObject this [int index] {
			get {
				return ObjectiveCObject.FromId ((IntPtr)ObjectiveC.SendMessage (Id, "objectAtIndex:", typeof (IntPtr), (uint)index));
			}
		}
	}
}
