using System;
using Cocoa.Interop;

namespace Cocoa {
	[ObjectiveCClass ("NSNotificationCenter")]
	public class NotificationCenter : Object {
		public static NotificationCenter Default {
			get {
				return (NotificationCenter)ObjectiveCObject.FromId ((IntPtr)ObjectiveC.SendMessage (ObjectiveC.GetClass ("NSNotificationCenter"), "defaultCenter", typeof (IntPtr)));
			}
		}
		
		public NotificationCenter (IntPtr id) : base (id)
		{
		}
		
		internal void AddObserver (ObjectiveCObject observer, string selector, string notification, ObjectiveCObject obj)
		{
			String strNotification = null;
			try {
				if (strNotification != null)
					strNotification = new Cocoa.String (notification);
				ObjectiveC.SendMessage (Id, "addObserver:selector:name:object:", typeof (void), observer, ObjectiveC.GetSelector (selector), strNotification, obj);
			} finally {
				if (strNotification != null)
					strNotification.Dispose ();
			}
		}
		
		internal void RemoveObserver (ObjectiveCObject observer)
		{
			ObjectiveC.SendMessage (Id, "removeObserver:", typeof (void), observer);
		}
		
		public void PostNotification (string name, ObjectiveCObject obj, Dictionary userInfo)
		{
			using (Cocoa.String str = new Cocoa.String(name))
				ObjectiveC.SendMessage (Id, "postNotificationName:object:userInfo:", typeof (void), str, obj, userInfo);
		}
	}
}
