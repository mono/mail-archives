namespace Cocoa {
	public enum TitlePosition {
		NoTitle = 0,
		AboveTop = 1,
		AtTop = 2,
		BelowTop = 3,
		AboveBottom = 4,
		AtBottom = 5,
		BelowBottom = 6
	}
}
