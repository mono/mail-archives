using System;
using Cocoa.Interop;

namespace Cocoa {
	[ObjectiveCClass ("NSControl")]
	public abstract class Control : View {
		public Control (Rect frame) : base (frame)
		{
		}
		
		public Control (IntPtr id) : base (id)
		{
		}
		
		protected override void Dispose (bool disposing)
		{
			if (proxy != null)
				proxy.Dispose ();
			base.Dispose (disposing);
		}
		
		public bool Enabled {
			set {
				ObjectiveC.SendMessage (Id, "setEnabled:", typeof (void), value);
			}
		}
		
		public string StringValue {
			set {
				using (Cocoa.String str = new Cocoa.String (value)) {
					ObjectiveC.SendMessage (Id, "setStringValue:", typeof (void), str);
				}
			}
		}
		
		public Cell Cell {
			get {
				return (Cell)ObjectiveC.SendMessage (Id, "cell", typeof (Cell));
			}
		}
		
		#region
		
		private IntPtr Target {
			set {
				ObjectiveC.SendMessage (Id, "setTarget:", typeof (void), value);
			}
		}
		
		private string ActionSelector {
			set {
				ObjectiveC.SendMessage (Id, "setAction:", typeof (void), ObjectiveC.GetSelector (value));
			}
		}
		
		/*private string DoubleActionSelector {
			set {
				ObjectiveC.SendMessage (Id, "setDoubleAction:", typeof (void), ObjectiveC.GetSelector (value));
			}
		}*/
		
		EventHandler actionDelegate = null;
		//EventHandler doubleActionDelegate = null;
		
		protected virtual void OnAction (EventArgs e)
		{
			if (actionDelegate != null)
				actionDelegate (this, e);
		}
		
		/*protected virtual void OnDoubleAction (EventArgs e)
		{
			if (doubleActionDelegate != null)
				doubleActionDelegate (this, e);
		}*/
		
		public event EventHandler Action {
			add {
				if (proxy == null) {
					proxy = new Proxy (this);
					Target = proxy.Id;
					ActionSelector = "dispatchAction";
					//DoubleActionSelector = "dispatchDoubleAction";
				}
				actionDelegate = (EventHandler)Delegate.Combine (actionDelegate, value);
			}
			remove {
				actionDelegate = (EventHandler)Delegate.Remove  (actionDelegate, value);
			}
		}
		
		/*public event EventHandler DoubleAction {
			add {
				if (proxy == null) {
					proxy = new Proxy (this);
					Target = proxy.Id;
					ActionSelector = "dispatchAction";
					DoubleActionSelector = "dispatchDoubleAction";
				}
				doubleActionDelegate = (EventHandler)Delegate.Combine (doubleActionDelegate, value);
			}
			remove {
				doubleActionDelegate = (EventHandler)Delegate.Remove  (doubleActionDelegate, value);
			}
		}*/
		
		Proxy proxy = null;
		
		[ObjectiveCClass ("CSControlProxy")]
		internal sealed class Proxy : Cocoa.Object {
			
			static Proxy ()
			{
				ObjectiveCClass.Create (typeof (Proxy));
			}
			
			readonly Control parent;
			
			public Proxy (Control parent) : base ()
			{
				Init ();
				this.parent = parent;
			}
			
			[ObjectiveCMethod ("dispatchAction")]
			public void DispatchAction ()
			{
				parent.OnAction (EventArgs.Empty);
			}
			
			/*[ObjectiveCMethod ("dispatchDoubleAction")]
			protected void DispatchDoubleAction ()
			{
				parent.OnDoubleAction (EventArgs.Empty);
			}*/
		}
		
		#endregion
	}
}
