using System;
using Cocoa.Interop;

namespace Cocoa {
	[ObjectiveCClass ("NSAlert")]
	public class Alert : Cocoa.Object
	{
		public Alert () : base ()
		{
			if (Environment.OSVersion.Version.Major < 7)
				throw new PlatformNotSupportedException ("Requires OS 10.3 or later.");
			Init ();
		}
		
		public Alert (IntPtr id) : base (id)
		{
		}
		
		public string MessageText {
			set {
				using (Cocoa.String str = new Cocoa.String (value)) {
					ObjectiveC.SendMessage (Id, "setMessageText:", typeof (void), str);
				}
			}
		}
		
		public string InformativeText {
			set {
				using (Cocoa.String str = new Cocoa.String (value)) {
					ObjectiveC.SendMessage (Id, "setInformativeText:", typeof (void), str);
				}
			}
		}
		
		public Window Window {
			get {
				return (Window)ObjectiveC.SendMessage (Id, "window", typeof (Window));
			}
		}
		
		public Button AddButton (string title)
		{
			using (Cocoa.String str = new Cocoa.String (title))
				return (Button)ObjectiveC.SendMessage (Id, "addButtonWithTitle:", typeof (Button), str);
		}
		
		public void BeginSheet (Window window, AlertSheetCallback callback)
		{
			if (callback != null) {
				if (proxy == null)
					proxy = new Proxy ();
				proxy.Callback = callback;
			}
			ObjectiveC.SendMessage (Id, "beginSheetModalForWindow:modalDelegate:didEndSelector:contextInfo:", typeof (void), window, (callback != null) ? proxy.Id : IntPtr.Zero, (callback != null) ? ObjectiveC.GetSelector ("dispatchEnd") : IntPtr.Zero, IntPtr.Zero);
		}
		
		/*public void RunSheetModal (Window window, AlertSheetCallback callback)
		{
			BeginSheetModal (window, callback);
		}*/
		
		Proxy proxy = null;
		
		[ObjectiveCClass ("CSAlertProxy")]
		private sealed class Proxy : Cocoa.Object
		{
			static Proxy() {
				ObjectiveCClass.Create (typeof (Proxy));
			}
		
			AlertSheetCallback endDelegate = null;
			
			public Proxy () : base ()
			{
				Init ();
			}
			
			public AlertSheetCallback Callback {
				set {
					endDelegate = value;
				}
			}
			
			[ObjectiveCMethod ("dispatchEnd")]
			internal void OnEnd (Alert alert, int returnCode, IntPtr contextInfo)
			{
				if (endDelegate != null)
					endDelegate (alert, returnCode, contextInfo);
			}
		}
	}
	
	public delegate void AlertSheetCallback(Alert alert, int returnCode, IntPtr contextInfo);
}
