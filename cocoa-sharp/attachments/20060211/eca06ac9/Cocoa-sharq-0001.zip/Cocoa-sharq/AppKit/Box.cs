using System;
using Cocoa.Interop;

namespace Cocoa {
	[ObjectiveCClass ("NSBox")]
	public class Box : View {
		public Box (Rect frame) : base (frame)
		{
		}
		
		public Box (IntPtr id) : base (id)
		{
		}
		
		public string Title {
			get { 
				return ((Cocoa.String)ObjectiveCObject.FromId((IntPtr)ObjectiveC.SendMessage (Id, "title", typeof (IntPtr)))).ToString ();
			}
			set {
				using (Cocoa.String str = new Cocoa.String (value)) {
					ObjectiveC.SendMessage (Id, "setTitle:", typeof (void), str);
				}
			}
		}
		
		public TitlePosition TitlePosition {
			get {
				return (TitlePosition)ObjectiveC.SendMessage (Id, "titlePosition", typeof (int));
			}
			set {
				ObjectiveC.SendMessage (Id, "setTitlePosition:", typeof (void), value);
			}
		}
		
		public Font TitleFont {
			get {
				return (Font) ObjectiveCObject.FromId ((IntPtr)ObjectiveC.SendMessage (Id, "titleFont", typeof(IntPtr)));
			}
			set {
				if (value == null)
					throw new ArgumentNullException("value");
				ObjectiveC.SendMessage (Id, "setTitleFont:", typeof (void), value);
			}
		}
		
		public View ContentView {
			get {
				return (View) ObjectiveCObject.FromId ((IntPtr)ObjectiveC.SendMessage (Id, "contentView", typeof (IntPtr)));
			}
			set {
				ObjectiveC.SendMessage (Id, "setContentView:", typeof (void), value);
			}
		}
	}
}
