using System;
using Cocoa.Interop;

namespace Cocoa {
	[ObjectiveCClass ("NSCell")]
	public class Cell : Cocoa.Object {
		/*public Cell (Rect frame) : base (frame)
		{
		}*/
		
		public Cell (IntPtr id) : base (id)
		{
		}
		
		public string StringValue {
			set {
				using (Cocoa.String str = new Cocoa.String (value))
				ObjectiveC.SendMessage (Id, "setStringValue:", typeof (void), str);
			}
		}
	}
}
