using System;
using Cocoa.Interop;

namespace Cocoa {
	[ObjectiveCClass ("NSScrollView")]
	public class ScrollView : View {
		public ScrollView (Rect frame) : base (frame)
		{
		}
		
		public ScrollView (IntPtr id) : base (id)
		{
		}

		public bool HasHorizontalScroller {
			set {
				ObjectiveC.SendMessage (Id, "setHasHorizontalScroller:", typeof(void), value);
			}
		}

		public bool HasVerticalScroller {
			set {
				ObjectiveC.SendMessage (Id, "setHasVerticalScroller:", typeof(void), value);
			}
		}
		
		public View DocumentView {
			get {
				return (View) ObjectiveCObject.FromId ((IntPtr)ObjectiveC.SendMessage (Id, "documentView", typeof (IntPtr)));
			}
			set {
				ObjectiveC.SendMessage (Id, "setDocumentView:", typeof (void), value);
			}
		}
	}
}
