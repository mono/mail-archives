using System;
using System.ComponentModel;
using Cocoa.Interop;

namespace Cocoa {
	[ObjectiveCClass ("NSApplication")]
	public class Application : Cocoa.Object {
		//private static readonly AutoreleasePool pool;
		
		static Application ()
		{
			AppKit.Init ();
			//Mach.Test ();
			//pool = new AutoreleasePool();
		}
		
		public static new void Init ()
		{
			//if (pool != null)
			//	throw new InvalidOperationException ("Application already initialized.");
		}

		public static Application Shared {
			get {
				IntPtr id = (IntPtr)ObjectiveC.SendMessage (ObjectiveC.GetClass ("NSApplication"), "sharedApplication", typeof (IntPtr));
				try {
					return (Application)FromId (id);
				} catch {
					return new Application (id);
				}
			}
		}
		
		/*public static void Run ()
		{
			Current.Run ();
		}*/

		public Application (IntPtr id) : base (id)
		{
			proxy = new Proxy (this);
			ObjectiveC.SendMessage (Id, "setDelegate:", typeof (void), proxy.Id);
		}
		
		protected override void Dispose (bool disposing)
		{
			//if (this.RetainCount <= 1)
				proxy.Dispose ();
			base.Dispose (disposing);
		}
		
		public IntPtr Zone {
			get {
				return (IntPtr)ObjectiveC.SendMessage (Id, "zone", typeof (IntPtr));
			}
		}
		
		public Array Windows {
			get {
				return (Array)ObjectiveC.SendMessage (Id, "windows", typeof (Cocoa.Array));
			}
		}
		
		public void Run ()
		{
			ObjectiveC.SendMessage (Id, "run", typeof (void));
			
			using (AutoreleasePool pool = new AutoreleasePool ()) {
				using (Array windows = Windows) {
					for (int i = 0; i < windows.Count; i++) {
						Console.WriteLine("Closing window {0}", i);
						Window window = (Window)windows [i];
						window.Close ();
					}
				}
			}
		}
		
		internal static void OnExit() {
			Console.WriteLine("OnExit");
			//AutoreleasePool arp = new AutoreleasePool ();
			//Environment.Exit(0);
			//GC.KeepAlive (arp);
			//GC.KeepAlive (pool);
			//throw new Exception();
		}
		
		public void Hide ()
		{
			ObjectiveC.SendMessage (Id, "hide:", typeof (void), Id);
		}
		
		protected void Stop ()
		{
			ObjectiveC.SendMessage (Id, "stop:", typeof (void), Id);
		}
		
		protected void Deactivate ()
		{
			ObjectiveC.SendMessage (Id, "deactivate", typeof (void));
		}
		
		protected void Terminate ()
		{
			ObjectiveC.SendMessage (Id, "terminate", typeof (void));
		}
		
		#region
		
		protected ApplicationTerminateReply OnShouldTerminate ()
		{
			Console.WriteLine ("should terminate...?");
			//parent.Deactivate();
			Hide ();
			Stop ();
			return ApplicationTerminateReply.Cancel;
		}
		
		protected void OnWillTerminate ()
		{
			Console.WriteLine ("will terminate...");
			//System.Threading.Thread.Sleep(5000);
			//pool.Dispose();
			//Stop ();
			//Environment.Exit (0);
		}
		
		readonly Proxy proxy;
		
		[ObjectiveCClass ("CSApplicationProxy")]
		private sealed class Proxy : Cocoa.Object {
			static Proxy ()
			{
				ObjectiveCClass.Create (typeof (Proxy));
			}
			
			readonly Application parent;
			
			public Proxy (Application parent)
			{
				Init ();
				this.parent = parent;
			}
			
			[ObjectiveCMethod ("applicationShouldTerminate:")]
			public ApplicationTerminateReply OnShouldTerminate (Application app)
			{
				return parent.OnShouldTerminate();
			}
			
			[ObjectiveCMethod ("applicationWillTerminate:")]
			public void OnWillTerminate (Notification notification)
			{
				parent.OnWillTerminate ();
			}
		}
		
		#endregion
	}
}
