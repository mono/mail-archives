using Cocoa;

namespace Cocoa {
	public enum CompositingOperation {
		Clear = 0,
		Copy = 1,
		SourceOver = 2,
		SourceIn = 3,
		SourceOut = 4,
		SourceAtop = 5,
		DestinationOver = 6,
		DestinationIn = 7,
		DestinationOut = 8,
		DestinationAtop = 9,
		Xor = 10,
		PlusDarker = 11,
		Highlight = 12,
		PlusLigher = 13
	}
}
