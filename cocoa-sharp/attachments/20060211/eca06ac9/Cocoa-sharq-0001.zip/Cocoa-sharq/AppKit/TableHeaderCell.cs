using System;
using Cocoa.Interop;

namespace Cocoa {
	[ObjectiveCClass ("NSTableHeaderCell")]
	public class TableHeaderCell : Cell
	{
		public TableHeaderCell (IntPtr id) : base (id)
		{
		}
	}
}
