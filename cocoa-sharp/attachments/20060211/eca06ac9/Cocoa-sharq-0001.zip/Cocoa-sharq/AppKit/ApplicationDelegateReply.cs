namespace Cocoa {
	public enum ApplicationDelegateReply {
		Success = 0,
		Cancel  = 1,
		Failure = 2
	}
}
