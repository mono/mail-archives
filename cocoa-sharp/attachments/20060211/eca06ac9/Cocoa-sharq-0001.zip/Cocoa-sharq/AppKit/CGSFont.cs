using System;
using Cocoa.Interop;

namespace Cocoa {
	[ObjectiveCClass ("NSCGSFont")]
	public class CGSFont : Font
	{
		public CGSFont (IntPtr id) : base (id)
		{
		}
	}
}
