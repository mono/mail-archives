using System;
using Cocoa.Interop;

namespace Cocoa {
	[ObjectiveCClass ("NSFont")]
	public class Font : Cocoa.Object {
		/*public Cell (Rect frame) : base (frame)
		{
		}*/
		
		public Font (IntPtr id) : base (id)
		{
		}

		public static Font GetBoldSystemFont (float size)
		{
			return (Font) ObjectiveCObject.FromId ((IntPtr)ObjectiveC.SendMessage (ObjectiveC.GetClass ("NSFont"), "boldSystemFontOfSize:", typeof (IntPtr), size));
		}

		public static Font GetMessageFont (float size)
		{
			return (Font) ObjectiveCObject.FromId ((IntPtr)ObjectiveC.SendMessage (ObjectiveC.GetClass ("NSFont"), "messageFontOfSize:", typeof (IntPtr), size));
		}
	}
}
