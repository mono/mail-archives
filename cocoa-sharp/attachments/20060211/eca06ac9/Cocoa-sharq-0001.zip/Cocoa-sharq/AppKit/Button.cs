using System;
using Cocoa.Interop;

namespace Cocoa {
	[ObjectiveCClass ("NSButton")]
	public class Button : Control {
		public Button (Rect frame) : base (frame)
		{
		}
		
		public Button (IntPtr id) : base (id)
		{
		}

		public BezelStyle BezelStyle {
			get {
				return (BezelStyle)ObjectiveC.SendMessage (Id, "bezelStyle", typeof (int));
			}
			set {
				ObjectiveC.SendMessage (Id, "setBezelStyle:", typeof (void), value);
			}
		}

		public string Title {
			get { 
				return ((Cocoa.String)ObjectiveCObject.FromId((IntPtr)ObjectiveC.SendMessage (Id, "title", typeof (IntPtr)))).ToString ();
			}
			set {
				using (Cocoa.String str = new Cocoa.String (value)) {
					ObjectiveC.SendMessage (Id, "setTitle:", typeof (void), str);
				}
			}
		}
	}
}
