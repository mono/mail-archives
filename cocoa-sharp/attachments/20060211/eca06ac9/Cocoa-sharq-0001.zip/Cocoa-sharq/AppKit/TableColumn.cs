using System;
using Cocoa.Interop;

namespace Cocoa {
	[ObjectiveCClass ("NSTableColumn")]
	public class TableColumn : Cocoa.Object {
		public TableColumn (Cocoa.Object identifier) : base ()
		{
			Id = (IntPtr) ObjectiveC.SendMessage (Id, "initWithIdentifier:", typeof (IntPtr), identifier);
		}
		
		public TableColumn (IntPtr id) : base (id)
		{
		}

		public float Width {
			set {
				ObjectiveC.SendMessage (Id, "setWidth:", typeof (void), value);
			}
		}

		public Cell HeaderCell {
			get {
				return (Cell) ObjectiveCObject.FromId ((IntPtr) ObjectiveC.SendMessage (Id, "headerCell", typeof (IntPtr)));
			}
		}
		
		public bool Editable {
			get {
				return (bool)ObjectiveC.SendMessage (Id, "isEditable", typeof (bool));
			}
			set {
				ObjectiveC.SendMessage (Id, "setEditable:", typeof (void), value);
			}
		}
	}
}
