using System;
using Cocoa.Interop;

namespace Cocoa {
	[ObjectiveCClass ("NSView")]
	public class View : Cocoa.Object {
		public View (Rect frame)
		{
			Id = (IntPtr)ObjectiveC.SendMessage (Id, "initWithFrame:", typeof (IntPtr), frame);
		}
		
		public View (IntPtr id) : base (id)
		{
		}
		
		protected override void Dispose (bool disposing)
		{
			if (proxy != null)
				NotificationCenter.Default.RemoveObserver(proxy);
			base.Dispose (disposing);
		}
		
		public Rect Frame {
			get {
				return (Rect)ObjectiveC.SendMessage (Id, "frame", typeof (Rect));
			}
			set {
				ObjectiveC.SendMessage (Id, "setFrame:", typeof (void), value);
			}
		}
		
		public Rect Bounds {
			get {
				return (Rect)ObjectiveC.SendMessage (Id, "bounds", typeof (Rect));
			}
		}
		
		public Window Window {
			get {
				return (Window)ObjectiveCObject.FromId ((IntPtr)ObjectiveC.SendMessage (Id, "window", typeof (IntPtr)));
			}
		}
		
		public View Superview {
			get {
				return (View)ObjectiveCObject.FromId ((IntPtr)ObjectiveC.SendMessage (Id, "superview", typeof (IntPtr)));
			}
		}
		
		public void AddSubview (View view)
		{
			if (view == null)
				throw new ArgumentNullException("view");
			ObjectiveC.SendMessage (Id, "addSubview:", typeof (void), view);
		}
	
		public void ReplaceSubview (View oldView, View newView) {
			if (oldView == null)
				throw new ArgumentNullException ("oldView");
			if (newView == null)
				throw new ArgumentNullException ("newView");
			ObjectiveC.SendMessage (Id, "replaceSubview:with:", typeof (void), oldView, newView);
		}

		public void RemoveFromSuperview (bool update) {
			ObjectiveC.SendMessage (Id, (update) ? "removeFromSuperview" : "removeFromSuperviewWithoutNeedingDisplay", typeof (void));
		}
		
		EventHandler frameChangeDelegate = null;
		
		public event EventHandler Resized {
			add {
				if (proxy == null) {
					proxy = new Proxy (this);
					NotificationCenter.Default.AddObserver (proxy, "dispatchFrameChanged", "NSViewFrameDidChangeNotification", this);
				}
				frameChangeDelegate = (EventHandler)Delegate.Combine (frameChangeDelegate, value);
			}
			remove {
				frameChangeDelegate = (EventHandler)Delegate.Remove (frameChangeDelegate, value);
				
			}
		}
		
		protected void OnFrameChanged (EventArgs e)
		{
			if (frameChangeDelegate != null)
				frameChangeDelegate (this, e);
		}
		
		Proxy proxy = null;
		
		[ObjectiveCClass ("CSViewProxy")]
		private sealed class Proxy : Cocoa.Object
		{
			static Proxy ()
			{
				ObjectiveCClass.Create (typeof (Proxy));
			}
			
			View parent;
			
			public Proxy (View parent) : base ()
			{
				Init ();
				this.parent = parent;
			}
			
			[ObjectiveCMethod ("dispatchFrameChanged")]
			protected void OnFrameChanged ()
			{
				parent.OnFrameChanged (EventArgs.Empty);
			}
		}
	}
}
