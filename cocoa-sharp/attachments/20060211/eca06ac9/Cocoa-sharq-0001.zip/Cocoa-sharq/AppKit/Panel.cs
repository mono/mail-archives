using System;
using Cocoa.Interop;

namespace Cocoa {
	[ObjectiveCClass ("NSPanel")]
	public class Panel : Window {
		public Panel (IntPtr id) : base (id)
		{
		}
	}
}
