using System;
using Cocoa.Interop;

namespace Cocoa {
	[ObjectiveCClass ("NSSegmentedCell")]
	public class SegmentedCell : Cell {
		/*public SegmentedControl (Rect frame) : base (frame)
		{
			if (Environment.OSVersion.Version.Major < 7)
				throw new PlatformNotSupportedException ("Requires Mac OS X v10.3 or later.");
		}*/
		
		public SegmentedCell (IntPtr id) : base (id)
		{
		}
		
		public int SegmentCount {
			get {
				return (int)ObjectiveC.SendMessage (Id, "segmentCount", typeof (int));
			}
			set {
				if ((value < 0) || (value > 2049))
					throw new ArgumentOutOfRangeException ("segmentCount must be between 0 and 2049.");
				ObjectiveC.SendMessage (Id, "setSegmentCount:", typeof (void), value);
			}
		}
		
		public SegmentSwitchTrackingMode TrackingMode {
			get {
				return (SegmentSwitchTrackingMode)ObjectiveC.SendMessage (Id, "trackingMode", typeof (int));
			}
			set {
				ObjectiveC.SendMessage (Id, "setTrackingMode:", typeof (void), value);
			}
		}
	}
}
