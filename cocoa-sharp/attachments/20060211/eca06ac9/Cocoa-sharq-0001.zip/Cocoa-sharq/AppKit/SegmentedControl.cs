using System;
using Cocoa.Interop;

namespace Cocoa {
	[ObjectiveCClass ("NSSegmentedControl")]
	public class SegmentedControl : Control {
		public SegmentedControl (Rect frame) : base (frame)
		{
			if (Environment.OSVersion.Version.Major < 7)
				throw new PlatformNotSupportedException ("Requires Mac OS X v10.3 or later.");
		}
		
		public SegmentedControl (IntPtr id) : base (id)
		{
		}
		
		public int SegmentCount {
			get {
				return (int)ObjectiveC.SendMessage (Id, "segmentCount", typeof (int));
			}
			set {
				if ((value < 0) || (value > 2049))
					throw new ArgumentOutOfRangeException ("segmentCount must be between 0 and 2049.");
				ObjectiveC.SendMessage (Id, "setSegmentCount:", typeof (void), value);
			}
		}
		
		public int SelectedSegment {
			get {
				return (int)ObjectiveC.SendMessage (Id, "selectedSegment", typeof (int));
			}
			set {
				ObjectiveC.SendMessage (Id, "setSelectedSegment:", typeof (void), value);
			}
		}
		
		public bool GetEnabled (int index)
		{
			return (bool)ObjectiveC.SendMessage (Id, "enabled:forSegment:", typeof (bool), index);
		}
		
		public void SetEnabled (bool value, int index)
		{
			ObjectiveC.SendMessage (Id, "setEnabled:forSegment:", typeof (void), value, index);
		}
		
		public Image GetImage (int index)
		{
			return (Image)ObjectiveC.SendMessage (Id, "image:forSegment:", typeof (Image), index);
		}
		
		public void SetImage (Image value, int index)
		{
			ObjectiveC.SendMessage (Id, "setImage:forSegment:", typeof (void), value, index);
		}
	}
}
