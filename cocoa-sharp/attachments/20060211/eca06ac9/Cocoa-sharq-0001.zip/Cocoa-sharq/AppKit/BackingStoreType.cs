namespace Cocoa {
	public enum BackingStoreType : int {
		Retained,
		Nonretained,
		Buffered
	}
}
