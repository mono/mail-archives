using System;
using Cocoa.Interop;

namespace Cocoa {
	[ObjectiveCClass ("NSTableView")]
	public class TableView : Control {
		public TableView (Rect frame) : base (frame)
		{
		}
		
		public TableView (IntPtr id) : base (id)
		{
		}

		public Cocoa.Object DataSource {
			get {
				return(Cocoa.Object) ObjectiveCObject.FromId ((IntPtr)ObjectiveC.SendMessage (Id, "dataSource", typeof(System.IntPtr)));
			}
			set {
				ObjectiveC.SendMessage (Id, "setDataSource:", typeof (void), value);
			}
		}

		public void AddTableColumn (TableColumn column)
		{
			ObjectiveC.SendMessage (Id, "addTableColumn:", typeof (void), column);
		}

		public void ReloadData ()
		{
			ObjectiveC.SendMessage (Id, "reloadData", typeof (void));
		}
	}
}
