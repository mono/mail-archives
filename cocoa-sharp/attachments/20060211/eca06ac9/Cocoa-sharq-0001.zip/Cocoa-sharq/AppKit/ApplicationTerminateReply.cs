namespace Cocoa {
	public enum ApplicationTerminateReply {
		Cancel = 0,
		Now    = 1,
		Later  = 2
	}
}
