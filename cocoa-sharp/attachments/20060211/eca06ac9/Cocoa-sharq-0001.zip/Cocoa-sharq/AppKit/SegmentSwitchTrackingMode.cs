namespace Cocoa {
	public enum SegmentSwitchTrackingMode {
		SelectOne = 0,
		SelectAny = 1,
		Momentary = 2
	}
}
