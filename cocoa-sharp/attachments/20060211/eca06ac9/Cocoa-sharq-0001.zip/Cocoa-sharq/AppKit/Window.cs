using System;
using Cocoa.Interop;

namespace Cocoa {
	[ObjectiveCClass ("NSWindow")]
	public class Window : Object {
		public Window (Rect contentRect, WindowStyle styleMask, BackingStoreType backingType, bool defer) : base ()
		{
			Id = (IntPtr)ObjectiveC.SendMessage (Id, "initWithContentRect:styleMask:backing:defer:", typeof(IntPtr), contentRect, styleMask, backingType, defer);
		}
		
		public Window (IntPtr id) : base (id)
		{
		}

		public string Title {
			get { 
				using (Cocoa.String str = (Cocoa.String)ObjectiveC.SendMessage (Id, "title", typeof (Cocoa.String)))
					return str.ToString ();
			}
			set {
				using (Cocoa.String str = new Cocoa.String (value)) {
					ObjectiveC.SendMessage (Id, "setTitle:", typeof (void), str);
				}
			}
		}
		
		public View ContentView {
			get {
				return (View)ObjectiveC.SendMessage (Id, "contentView", typeof (View));
			}
			set {
				ObjectiveC.SendMessage (Id, "setContentView:", typeof (void), value);
			}
		}
		
		internal bool ReleasedWhenClosed {
			get {
				return (bool)ObjectiveC.SendMessage (Id, "isReleasedWhenClosed", typeof (bool));
			}
		}
		
		public void Center ()
		{
			ObjectiveC.SendMessage (Id, "center", typeof (void));
		}
		
		public void Show ()
		{
			ObjectiveC.SendMessage (Id, "makeKeyAndOrderFront:", typeof (void), Id);
		}
		
		public void OrderOut ()
		{
			ObjectiveC.SendMessage (Id, "orderOut:", typeof (void), Id);
		}
		
		public void Close ()
		{
			ObjectiveC.SendMessage (Id, "close", typeof (void));
			//if (ReleasedWhenClosed)
			//	Dispose();
		}
	}
}
