using System;
using Cocoa.Interop;

namespace Cocoa {
	[ObjectiveCClass ("NSImage")]
	public class Image : Cocoa.Object {
		public Image (string file) : base ()
		{
			using (Cocoa.String str = new Cocoa.String (file))
				Id = (IntPtr)ObjectiveC.SendMessage (Id, "initByReferencingFile:", typeof (IntPtr), str);
		}
		
		public Image (IntPtr id) : base (id)
		{
		}

		public void Composite (Point point, CompositingOperation op)
		{
			ObjectiveC.SendMessage (Id, "compositeToPoint:operation:", typeof (void), point, op);
		}
	}
}
