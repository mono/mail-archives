using System;
using System.Runtime.InteropServices;
using Cocoa;

class Test {
	public static void Main() {
		Application.Init();
		new Cocoa.String("Test");
		Marshal.ReadIntPtr(IntPtr.Zero);
	}
}
