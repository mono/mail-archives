using System;
using System.Runtime.InteropServices;
using System.Threading;

namespace Cocoa.Interop {
	public class Mach {
		private Mach ()
		{
		}

		private static IntPtr port;
		public static void Test ()
		{
			IntPtr machTask = Mach.Task;
			port = Mach.AllocatePort (machTask, MachPortRight.Receive);
			Mach.InsertPortRight (machTask, port, port, MachMessageType.MakeSend);
			IntPtr task = GetTask (machTask);
			Mach.SetTaskExceptionPorts (task, MachExceptionMask.All & ~(MachExceptionMask.Syscall|MachExceptionMask.MachSyscall|MachExceptionMask.RpcAlert), port, MachExceptionBehavior.Default, MachThreadStateFlavor.None);
			Thread t = new Thread (new ThreadStart (MachExceptionHandler));
			t.Start ();
		}
		private static void MachExceptionHandler () {
			IntPtr pMsg = IntPtr.Zero;
			IntPtr pReply = IntPtr.Zero;
			try {
				pMsg = Marshal.AllocHGlobal (Marshal.SizeOf (typeof (MachExceptionRaiseRequest)));
				pReply = Marshal.AllocHGlobal (Marshal.SizeOf (typeof (MachExceptionRaiseReply)));
				while (true) {
					Mach.ReceiveMessage (pMsg, Marshal.SizeOf (typeof (MachExceptionRaiseRequest)), port);
					MachExceptionRaiseRequest msg = (MachExceptionRaiseRequest)Marshal.PtrToStructure (pMsg, typeof (MachExceptionRaiseRequest));
					Console.WriteLine ("Caught a Mach exception.");
					Console.WriteLine ("Id: " + msg.Head.id);
					MachExceptionRaiseReply reply = new MachExceptionRaiseReply ();
					reply.Head.bits = (uint)MachMessageType.MoveSendOnce;
					reply.Head.size = (uint)Marshal.SizeOf (typeof (MachExceptionRaiseReply));
					reply.Head.remote_port = msg.Head.remote_port;
					reply.Head.local_port = IntPtr.Zero;
					reply.Head.seqno_reserved = 0;
					reply.Head.id = (msg.Head.id + 100);
					reply.RetCode = (int)MachResultCode.Failure;
					Marshal.StructureToPtr (reply, pReply, false);
					Mach.SendMessage (pReply, reply.Head.size, msg.Head.local_port);
				}
			} finally {
				if (pMsg   != IntPtr.Zero) Marshal.FreeHGlobal (pMsg);
				if (pReply != IntPtr.Zero) Marshal.FreeHGlobal (pReply);
			}
		}

		internal static IntPtr Task {
			get {
				return MachMethods.mach_task_self ();
			}
		}

		internal static IntPtr AllocatePort (IntPtr task, MachPortRight rights)
		{
			IntPtr name = IntPtr.Zero;
			MachResultCode rc = (MachResultCode)MachMethods.mach_port_allocate(task, (uint)rights, ref name);
			if (rc != MachResultCode.Success)
				throw new Exception("mach_port_allocate: " + rc);
			return name;
		}

		internal static void InsertPortRight (IntPtr task, IntPtr name, IntPtr right, MachMessageType rightType)
		{
			MachResultCode rc = (MachResultCode)MachMethods.mach_port_insert_right(task, name, right, (uint)rightType);
			if (rc != MachResultCode.Success)
				throw new Exception("mach_port_insert_right: " + rc);
		}

		internal static IntPtr GetTask (IntPtr port)
		{
			IntPtr task = IntPtr.Zero;
			MachResultCode rc = (MachResultCode)MachMethods.task_for_pid(port, MachMethods.getpid(), ref task);
			if (rc != MachResultCode.Success)
				throw new Exception("task_for_pid: " + rc);
			return task;
		}

		internal static void SetTaskExceptionPorts (IntPtr task, MachExceptionMask exceptionMask, IntPtr newPort, MachExceptionBehavior behavior, MachThreadStateFlavor newFlavor)
		{
			MachResultCode rc = (MachResultCode)MachMethods.task_set_exception_ports(task, (uint)exceptionMask, newPort, (uint)behavior, (uint)newFlavor);
			if (rc != MachResultCode.Success)
				throw new Exception("task_set_exception_ports: " + rc);
		}

		internal static void ReceiveMessage(IntPtr msg, int size, IntPtr port)
		{
			MachMessageResultCode rc = (MachMessageResultCode)MachMethods.mach_msg (msg, (uint)MachMessageOption.Receive, 0, (uint)size, port, 0, IntPtr.Zero);
			if (rc != MachMessageResultCode.Success)
				throw new Exception("mach_msg receive: " + rc);
		}

		internal static void SendMessage(IntPtr msg, uint size, IntPtr port)
		{
			MachMessageResultCode rc = (MachMessageResultCode)MachMethods.mach_msg (msg, (uint)MachMessageOption.Send, (uint)size, 0, port, 0, IntPtr.Zero);
			if (rc != MachMessageResultCode.Success)
				throw new Exception("mach_msg send: " + rc);
		}
	}
}
