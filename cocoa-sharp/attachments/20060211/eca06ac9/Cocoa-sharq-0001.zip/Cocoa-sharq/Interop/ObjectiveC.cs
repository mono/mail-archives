using System;
using System.Reflection;
using System.Runtime.InteropServices;

namespace Cocoa.Interop {
	public sealed class ObjectiveC {

		static ObjectiveC ()
		{
		}

		private ObjectiveC ()
		{
		}

		public static IntPtr GetSelector (string selector)
		{
			if (selector == null)
				throw new ArgumentNullException ("selector");
			return ObjectiveCMethods.sel_registerName (selector);
		}
		
		public static string GetSelectorName (IntPtr selector)
		{
			if (selector == IntPtr.Zero)
				throw new ArgumentException ("Selector cannot be IntPtr.Zero");
			IntPtr ptr = ObjectiveCMethods.sel_getName (selector);
			return Marshal.PtrToStringAnsi (ptr);
		}
		
		public static IntPtr GetClass (string className)
		{
			if (className == null)
				throw new ArgumentNullException ("className");
			IntPtr cls = ObjectiveCMethods.objc_getClass (className);
			if (cls == IntPtr.Zero)
				throw new ArgumentException ("Class " + className + " not found.");
			return cls;
		}

		public static IntPtr GetMetaClass (string className)
		{
			if (className == null)
				throw new ArgumentNullException ("className");
			IntPtr cls = ObjectiveCMethods.objc_getMetaClass (className);
			if (cls == IntPtr.Zero)
				throw new ArgumentException ("Metaclass " + className + " not found.");
			return cls;
		}

		public static void AddClass (IntPtr cls) {
			ObjectiveCMethods.objc_addClass (cls);
		}

		public static object SendMessage (IntPtr receiver, string selector, Type returnType, params object [] args)
		{
			if (receiver == IntPtr.Zero)
				throw new ArgumentException ("Receiver can not be IntPtr.Zero");
			if (selector == null)
				throw new ArgumentNullException ("selector");
			if (args == null)
				throw new ArgumentNullException ("args");
			Type retType = GetMarshalledReturnType (returnType);
			IntPtr sel = GetSelector (selector);
			object ret;
			if (IsStretNeeded (retType)) {
				IntPtr ptr = Marshal.AllocHGlobal (Marshal.SizeOf (retType));
				try {
					object [] myArgs = new object [3 + args.Length];
					myArgs [0] = ptr;
					myArgs [1] = receiver;
					myArgs [2] = sel;
					CopyAndConvertArguments (args, myArgs, 3);
					DynamicPInvoke.InvokeMethod ("libobjc.dylib", "objc_msgSend_stret", typeof (void), myArgs);
					ret = Marshal.PtrToStructure (ptr, retType);
				} finally {
					Marshal.FreeHGlobal (ptr);
				}
			} else {
				object [] myArgs = new object [2 + args.Length];
				myArgs [0] = receiver;
				myArgs [1] = sel;
				CopyAndConvertArguments (args, myArgs, 2);
				ret = ChangeReturnType ((IntPtr)DynamicPInvoke.InvokeMethod ("libobjc.dylib", "objc_msgSend", typeof (IntPtr), myArgs), returnType);
			}
			return ret;
		}

		public static object SendMessageToSuper (IntPtr receiver, IntPtr superclass, string selector, Type returnType, params object [] args)
		{
			if (receiver == IntPtr.Zero)
				throw new ArgumentException ("Receiver can not be IntPtr.Zero");
			if (selector == null)
				throw new ArgumentNullException ("selector");
			if (args == null)
				throw new ArgumentNullException ("args");
			Type retType = GetMarshalledReturnType (returnType);
			IntPtr sel = GetSelector (selector);
			object ret = null;
			IntPtr superContext = Marshal.AllocHGlobal (Marshal.SizeOf (typeof (objc_super)));
			try {
				Marshal.StructureToPtr (new objc_super (receiver, superclass), superContext, false);
				if (IsStretNeeded (retType)) {
					IntPtr ptr = Marshal.AllocHGlobal (Marshal.SizeOf (retType));
					try {
						object [] myArgs = new object [3 + args.Length];
						myArgs [0] = ptr;
						myArgs [1] = superContext;
						myArgs [2] = sel;
						CopyAndConvertArguments (args, myArgs, 3);
						DynamicPInvoke.InvokeMethod ("libobjc.dylib", "objc_msgSendSuper_stret", typeof (void), myArgs);
						ret = Marshal.PtrToStructure (ptr, retType);
					} finally {
						Marshal.FreeHGlobal (ptr);
					}
				} else {
					object [] myArgs = new object [2 + args.Length];
					myArgs [0] = superContext;
					myArgs [1] = sel;
					CopyAndConvertArguments (args, myArgs, 2);
					ret = ChangeReturnType ((IntPtr)DynamicPInvoke.InvokeMethod ("libobjc.dylib", "objc_msgSendSuper", typeof (IntPtr), myArgs), returnType);
				}
			} finally {
				Marshal.FreeHGlobal (superContext);
			}
			return ret;
		}

		private static bool IsStretNeeded (Type returnType)
		{
			return returnType.IsValueType && (returnType.Namespace != "System");
		}

		private static void CopyAndConvertArguments (object [] srcArgs, object [] destArgs, int offset)
		{
			for (int i = 0; i < srcArgs.Length; i++) {
				if (srcArgs [i] != null) {
					Type type = srcArgs [i].GetType ();
					if (type.IsEnum) {
						destArgs [offset + i] = Convert.ChangeType (srcArgs [i], Enum.GetUnderlyingType (type));
					} else if ((type == typeof (ObjectiveCObject)) || type.IsSubclassOf (typeof (ObjectiveCObject))) {
						destArgs [offset + i] = ((ObjectiveCObject)srcArgs [i]).Id;
					} else
						destArgs [offset + i] = srcArgs [i];
				} else
					destArgs [offset + i] = IntPtr.Zero;
			}
		}

		private static Type GetMarshalledReturnType (Type type)
		{
			if (type == null)
				return typeof (void);
			if (type == typeof (string))
				return typeof (IntPtr);
			if (type.IsSubclassOf (typeof (ObjectiveCObject)) || (type == typeof (ObjectiveCObject)))
				return typeof (IntPtr);
			return type;
		}

		private static object ChangeReturnType (IntPtr ret, Type type)
		{
			if (type == typeof (void))
				return null;
			if (type == typeof (IntPtr))
				return ret;
			if (type == typeof (string))
				return Marshal.PtrToStringAuto (ret);
			if (type == typeof (int))
				return (int)ret;
			if (type == typeof (bool))
				return (int)ret != 0;
			if (type == typeof (uint))
				return (uint)ret;
			if (type.IsSubclassOf (typeof (ObjectiveCObject)) || (type == typeof (ObjectiveCObject)))
				return ObjectiveCObject.FromId (ret);
			throw new ArgumentException ("Return type not yet supported: " + type.FullName);
		}

		public static void SetClassHandler (ObjectiveCClassHandlerDelegate classHandler) {
			ObjectiveCMethods.objc_setClassHandler (classHandler);
		}
	}
}
