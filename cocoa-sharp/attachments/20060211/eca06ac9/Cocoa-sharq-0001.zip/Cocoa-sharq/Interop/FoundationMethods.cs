using System;
using System.Runtime.InteropServices;

namespace Cocoa.Interop {
	internal class FoundationMethods {
		private FoundationMethods ()
		{
		}
		
		[DllImport ("/System/Library/Frameworks/Foundation.framework/Foundation")]
		internal static extern IntPtr NSStringFromClass (IntPtr cls);
	}
}