using System;

namespace Cocoa.Interop {
	[AttributeUsage (AttributeTargets.Method, Inherited=false, AllowMultiple=true)]
	public sealed class ObjectiveCMethodAttribute : Attribute {
		string selector;
		
		public ObjectiveCMethodAttribute (string selector)
		{
			this.selector = selector;
		}
		
		public string Selector {
			get {
				return selector;
			}
		}
	}
}
