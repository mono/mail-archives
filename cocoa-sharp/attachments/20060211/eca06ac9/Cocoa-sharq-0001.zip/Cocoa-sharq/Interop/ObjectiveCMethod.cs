using System;
using System.Reflection;
using System.Text;

namespace Cocoa.Interop {
	public struct ObjectiveCMethod {
		public string Selector;
		public string Signature;
		public Delegate FunctionPtr;
		
		public ObjectiveCMethod (string selector, string signature, Delegate functionPtr)
		{
			this.Selector = selector;
			this.Signature = signature;
			this.FunctionPtr = functionPtr;
		}
		
		public static string EncodeType (Type type)
		{
			if (type == typeof (void))
				return "v";
			if (type == typeof (int))
				return "i";
			if (type.IsValueType && !type.IsPrimitive)
				return "@";
			if ((type == typeof (ObjectiveCObject)) || type.IsSubclassOf (typeof (ObjectiveCObject)))
				return "@";
			if (type == typeof (IntPtr))
				return "^?";
			throw new ArgumentException ("Type not yet supported: " + type.FullName);
		}
		
		public static string Encode (MethodInfo method)
		{
			StringBuilder sb = new StringBuilder ();
			sb.Append (EncodeType (method.ReturnType));
			sb.Append ('@'); //
			sb.Append (':');
			foreach (ParameterInfo param in method.GetParameters ())
				sb.Append (EncodeType (param.ParameterType));
			return sb.ToString ();
		}
	}
}
