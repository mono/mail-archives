using System;
using System.Collections;
using System.Reflection;
using System.Reflection.Emit;
using System.Runtime.InteropServices;
using System.Security.Permissions;
using System.Text;

namespace Cocoa.Interop {
	internal sealed class DynamicPInvoke {
		private static Hashtable libraries = new Hashtable ();
		private static AssemblyBuilder builder;
		private static ModuleBuilder module;

		static DynamicPInvoke ()
		{
			AssemblyName an = new AssemblyName ();
			an.Name = "DynamicPInvoke";
			builder = AppDomain.CurrentDomain.DefineDynamicAssembly (an, AssemblyBuilderAccess.Run, null, null, null, null, null, true);
			module = builder.DefineDynamicModule ("DynPInvoke");
		}
		
		private DynamicPInvoke ()
		{
		}
		
		[SecurityPermission (SecurityAction.Demand, UnmanagedCode=true)]
		[ReflectionPermission (SecurityAction.Demand, ReflectionEmit=true)]
		public static object InvokeMethod (string library, string method, Type returnType, object [] args)
		{
			MethodInfo meth = GetMethod (library, method, returnType, args);
			return meth.Invoke (null, args);
		}

		private static MethodInfo GetMethod (string library, string method, Type returnType, object [] args)
		{
			if (!libraries.ContainsKey (library)) {
				libraries [library] = new Hashtable ();
			}
			Hashtable methods = (Hashtable) libraries [library];
			StringBuilder sb = new StringBuilder ();
			sb.Append (method);
			sb.Append ('(');
			for (int i = 0; i < args.Length; i++) {
				if (i > 0) sb.Append (',');
				sb.Append(args [i].GetType ().FullName);
			}
			sb.Append (')');
			string signature = sb.ToString();
			if (!methods.ContainsKey (signature)) {
				Type [] paramTypes = new Type [args.Length];
				for (int i = 0; i < args.Length; i++) {
					paramTypes [i] = args [i].GetType ();
				}
				MethodInfo meth = DefineMethod (library, method, returnType, paramTypes);
				methods [signature] = meth;
				return meth;
			}
			return (MethodInfo)methods [signature];
		}

		private static MethodInfo DefineMethod (string library, string method, Type returnType, Type [] paramTypes)
		{
			TypeBuilder tb = module.DefineType (Guid.NewGuid().ToString());
			tb.DefinePInvokeMethod (method, library, MethodAttributes.PinvokeImpl | MethodAttributes.Static | MethodAttributes.Public, CallingConventions.Standard, returnType, paramTypes, CallingConvention.Cdecl, CharSet.Auto);
			Type type = tb.CreateType ();
			return type.GetMethod (method, BindingFlags.Static|BindingFlags.Public, null, paramTypes, null);
		}
	}
}
