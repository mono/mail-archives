using System;
using System.Runtime.InteropServices;

namespace Cocoa.Interop {
	internal sealed class ObjectiveCMethods {
		private ObjectiveCMethods()
		{
		}
		
		[DllImport ("libobjc.dylib", CharSet=CharSet.Ansi, CallingConvention=CallingConvention.Cdecl)]
		internal static extern IntPtr sel_registerName (string selectorName);
		
		[DllImport ("libobjc.dylib", CharSet=CharSet.Ansi, CallingConvention=CallingConvention.Cdecl)]
		internal static extern IntPtr sel_getName (IntPtr selector);
		
		[DllImport ("libobjc.dylib", CharSet=CharSet.Ansi, CallingConvention=CallingConvention.Cdecl)]
		internal static extern IntPtr objc_getClass (string className);
		
		[DllImport ("libobjc.dylib", CharSet=CharSet.Ansi, CallingConvention=CallingConvention.Cdecl)]
		internal static extern IntPtr objc_getMetaClass (string className);
		
		[DllImport ("libobjc.dylib", CharSet=CharSet.Ansi, CallingConvention=CallingConvention.Cdecl)]
		internal static extern IntPtr objc_lookUpClass (string className);
		
		[DllImport ("libobjc.dylib", CharSet=CharSet.Ansi, CallingConvention=CallingConvention.Cdecl)]
		internal static extern void objc_setClassHandler ([MarshalAs (UnmanagedType.FunctionPtr)] ObjectiveCClassHandlerDelegate callback);
		
		[DllImport ("libobjc.dylib", CharSet=CharSet.Auto, CallingConvention=CallingConvention.Cdecl)]
		internal static extern void objc_addClass (IntPtr cls);
		
		[DllImport ("libobjc.dylib", CharSet=CharSet.Auto, CallingConvention=CallingConvention.Cdecl)]
		internal static extern void class_addMethods (IntPtr cls, IntPtr methodList);
		
		[DllImport ("libobjc.dylib", CharSet=CharSet.Auto, CallingConvention=CallingConvention.Cdecl)]
		internal static extern IntPtr class_poseAs (IntPtr imposter, IntPtr original);
		
		[DllImport ("libobjc.dylib", CharSet=CharSet.Auto, CallingConvention=CallingConvention.Cdecl)]
		internal static extern void atexit ([MarshalAs (UnmanagedType.FunctionPtr)] ExitHandlerDelegate d);
	}
	
	public delegate int ObjectiveCClassHandlerDelegate(string className);
	
	public delegate void ExitHandlerDelegate();
	
	[StructLayout (LayoutKind.Sequential)]
	internal struct objc_super {
		internal IntPtr receiver;
		internal IntPtr superclass;

		internal objc_super(IntPtr receiver, IntPtr superclass) {
			this.receiver = receiver;
			this.superclass = superclass;
		}
	}

	[StructLayout (LayoutKind.Sequential)]
	internal struct objc_class {
		internal IntPtr isa;
		internal IntPtr super_class;
		internal IntPtr name;
		internal int version;
		internal int info;
		internal int instance_size;
		internal IntPtr ivars;
		internal IntPtr methodLists;
		internal IntPtr cache;
		internal IntPtr protocols;
	}

	[Flags ()]
	internal enum ObjectiveCClassInfo : int {
		Class = 1,
		Meta = 2
	}

	[StructLayout (LayoutKind.Sequential)]
	internal struct objc_ivar_list {
		internal int count;
	}
	
	[StructLayout (LayoutKind.Sequential)]
	internal struct objc_ivar {
	}
	
	[StructLayout (LayoutKind.Sequential)]
	internal struct objc_method_list {
		internal IntPtr obsolete;
		internal int count;
	}
	
	public delegate IntPtr ObjectiveCImpDelegate (IntPtr id, IntPtr selector);
	
	[StructLayout (LayoutKind.Sequential)]
	internal struct objc_method {
		internal IntPtr name;
		internal IntPtr types;
		[MarshalAs (UnmanagedType.FunctionPtr)]
		internal Delegate imp;
	}
}
