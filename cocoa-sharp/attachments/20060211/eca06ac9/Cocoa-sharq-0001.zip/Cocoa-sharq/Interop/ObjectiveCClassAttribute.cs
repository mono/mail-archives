using System;

namespace Cocoa.Interop {
	[AttributeUsage (AttributeTargets.Class, Inherited=false, AllowMultiple=false)]
	public sealed class ObjectiveCClassAttribute : Attribute {
		private string className;
		
		public ObjectiveCClassAttribute(string className)
		{
			this.className = className;
		}
		
		public string Name {
			get { return className; }
		}
	}
}
