using System;
using System.Collections;
using System.Reflection;
using System.Reflection.Emit;
using System.Runtime.InteropServices;

namespace Cocoa.Interop {
	public sealed class ObjectiveCClass {
		static Hashtable instances = new Hashtable();
		
		IntPtr ptr = IntPtr.Zero;

		protected ObjectiveCClass (IntPtr cls)
		{
			this.ptr = cls;
		}

		~ObjectiveCClass ()
		{
		}

		public static ObjectiveCClass FromPtr (IntPtr cls)
		{
			if (cls == IntPtr.Zero)
				throw new ArgumentException ("Class cannot be IntPtr.Zero");
			lock (instances) {
				if (instances.ContainsKey (cls))
					return (ObjectiveCClass)instances [cls];
				ObjectiveCClass occ = new ObjectiveCClass (cls);
				instances [cls] = occ;
				return occ;
			}
		}

		public static bool Exists (string className)
		{
			if (className == null)
				throw new ArgumentNullException ("className");
			return ObjectiveCMethods.objc_lookUpClass (className) != IntPtr.Zero;
		}

		public static ObjectiveCClass Create (string name, IntPtr superClass)
		{
			if (name == null)
				throw new ArgumentNullException ("name");
			if (Exists (name))
				throw new ArgumentException ("Class " + name + " exists.");
			IntPtr root = (superClass == IntPtr.Zero) ? IntPtr.Zero : GetRoot (superClass);
			IntPtr ptr = IntPtr.Zero;
			objc_class cls  = new objc_class();
			objc_class meta = new objc_class();
			try {
				meta.isa = (root != IntPtr.Zero) ? ((objc_class)Marshal.PtrToStructure (root, typeof (objc_class))).isa : IntPtr.Zero;
				if (superClass != IntPtr.Zero) {
					objc_class superCls = (objc_class)Marshal.PtrToStructure (superClass, typeof (objc_class));
					meta.super_class = superCls.isa;
					superCls = (objc_class)Marshal.PtrToStructure (meta.super_class, typeof (objc_class));
					meta.instance_size = superCls.instance_size;
				} else {
					meta.super_class = IntPtr.Zero;
					meta.instance_size = 0;
				}
				meta.name = Marshal.StringToHGlobalAnsi (name);
				meta.info = (int)ObjectiveCClassInfo.Meta;
				meta.methodLists = Marshal.AllocHGlobal (Marshal.SizeOf (typeof (IntPtr)));
				Marshal.WriteIntPtr(meta.methodLists, (IntPtr)(-1));
				cls.isa = Marshal.AllocHGlobal (Marshal.SizeOf (typeof (objc_class)));
				Marshal.StructureToPtr (meta, cls.isa, false);
				cls.name = meta.name;
				cls.info = (int)ObjectiveCClassInfo.Class;
				cls.super_class = superClass;
				if (cls.super_class != IntPtr.Zero) {
					cls.instance_size = ((objc_class)Marshal.PtrToStructure (cls.super_class, typeof (objc_class))).instance_size;
				} else
					cls.instance_size = 0;
				cls.methodLists = Marshal.AllocHGlobal (Marshal.SizeOf (typeof (IntPtr)));
				Marshal.WriteIntPtr(cls.methodLists, (IntPtr)(-1));
				ptr = Marshal.AllocHGlobal (Marshal.SizeOf (typeof (objc_class)));
				Marshal.StructureToPtr (cls, ptr, false);
				ObjectiveC.AddClass (ptr);
			} catch (Exception ex) {
				if (cls.name != IntPtr.Zero)
					Marshal.FreeHGlobal (cls.name);
				if (cls.isa != IntPtr.Zero)
					Marshal.FreeHGlobal (cls.isa);
				if (meta.methodLists != IntPtr.Zero)
					Marshal.FreeHGlobal (meta.methodLists);
				if (cls.methodLists != IntPtr.Zero)
					Marshal.FreeHGlobal (cls.methodLists);
				if (ptr != IntPtr.Zero)
					Marshal.FreeHGlobal (ptr);
				throw new Exception("Error.", ex);
			}
			return new ObjectiveCClass (ptr);
		}
		
		public static ObjectiveCClass Create (Type classType)
		{
			if (classType == null)
				throw new ArgumentNullException ("classType");
			ObjectiveCClassAttribute classAttr = (ObjectiveCClassAttribute)Attribute.GetCustomAttribute (classType, typeof (ObjectiveCClassAttribute));
			if (classAttr == null)
				throw new ArgumentException ("Not marked as an Objective-C class.");
			if (Exists (classAttr.Name))
				throw new ArgumentException ("An Objective-C class " + classAttr.Name + " already exists.");
			if (!classType.IsSubclassOf (typeof (ObjectiveCObject)))
				throw new ArgumentException ("Class does not derive from " + typeof(ObjectiveCObject).FullName);
			if (classType == (typeof (ObjectiveCObject)))
				throw new ArgumentException ("Cannot register " + typeof(ObjectiveCObject).FullName + " class itself.");
			Type baseType = classType.BaseType;
			while ((baseType != typeof (ObjectiveCObject)) && (Attribute.GetCustomAttribute (baseType, typeof (ObjectiveCClassAttribute)) == null))
				baseType = baseType.BaseType;
			ObjectiveCClass cls = Create (classAttr.Name, (baseType != typeof (ObjectiveCObject)) ? ObjectiveC.GetClass (((ObjectiveCClassAttribute)Attribute.GetCustomAttribute (baseType, typeof (ObjectiveCClassAttribute))).Name) : IntPtr.Zero);
			
			ArrayList instanceMethods = new ArrayList ();
			MethodInfo [] methods = classType.GetMethods (BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.DeclaredOnly);
			foreach (MethodInfo method in methods) {
				Attribute [] attrs = Attribute.GetCustomAttributes (method, typeof (ObjectiveCMethodAttribute)); 
				ObjectiveCMethod meth = new ObjectiveCMethod ();
				foreach (ObjectiveCMethodAttribute attr in attrs) {
					meth.Selector = attr.Selector;
					meth.Signature = ObjectiveCMethod.Encode (method);
					meth.FunctionPtr = Dispatcher.RegisterMethod (method, meth.Selector, cls);
					instanceMethods.Add (meth);
				}
			}
			ArrayList classMethods = new ArrayList ();
			methods = classType.GetMethods (BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.DeclaredOnly);
			foreach (MethodInfo method in methods) {
				Attribute [] attrs = Attribute.GetCustomAttributes (method, typeof (ObjectiveCMethodAttribute)); 
				ObjectiveCMethod meth = new ObjectiveCMethod ();
				foreach (ObjectiveCMethodAttribute attr in attrs) {
					meth.Selector = attr.Selector;
					meth.Signature = ObjectiveCMethod.Encode (method);
					meth.FunctionPtr = Dispatcher.RegisterMethod (method, meth.Selector, cls.IsA);
					classMethods.Add (meth);
				}
			}
			if (instanceMethods.Count > 0)
				cls.AddMethods ((ObjectiveCMethod [])instanceMethods.ToArray (typeof (ObjectiveCMethod)));
			if (classMethods.Count > 0)
				cls.IsA.AddMethods ((ObjectiveCMethod [])classMethods.ToArray (typeof (ObjectiveCMethod)));
			return cls;
		}

		private static IntPtr GetRoot (IntPtr cls)
		{
			if (cls == IntPtr.Zero)
				throw new ArgumentException ("cls");
			objc_class classDef = (objc_class)Marshal.PtrToStructure (cls, typeof (objc_class));
			while (classDef.super_class != IntPtr.Zero) {
				cls = classDef.super_class;
				classDef = (objc_class)Marshal.PtrToStructure (cls, typeof (objc_class));
			}
			return cls;
		}
		
		public IntPtr Ptr {
			get {
				return ptr;
			}
		}

		public string Name {
			get {
				objc_class c = (objc_class)Marshal.PtrToStructure (ptr, typeof(objc_class));
				if (c.name == IntPtr.Zero)
					return null;
				return Marshal.PtrToStringAnsi (c.name);
			}
		}
		
		public ObjectiveCClass IsA {
			get {
				objc_class c = (objc_class)Marshal.PtrToStructure (ptr, typeof(objc_class));
				if (c.isa == IntPtr.Zero)
					return null;
				return FromPtr (c.isa);
			}
		}
		
		public bool IsMetaclass {
			get {
				objc_class c = (objc_class)Marshal.PtrToStructure (ptr, typeof(objc_class));
				return (c.info & (int)ObjectiveCClassInfo.Meta) != 0;
			}
		}
		
		public void AddMethods(Delegate [] methodDelegates)
		{
			if (methodDelegates == null)
				throw new ArgumentNullException ("methodDelegates");
			ArrayList methods = new ArrayList ();
			foreach (Delegate methodDelegate in methodDelegates) {
				if (methodDelegate == null)
					throw new ArgumentException ("A method delegate is null.");
				Attribute [] attrs = Attribute.GetCustomAttributes (methodDelegate.Method, typeof (ObjectiveCMethodAttribute));
				if (attrs.Length == 0)
					throw new ArgumentException ("A target method is not marked as an Objective-C method.");
				foreach (ObjectiveCMethodAttribute attr in attrs) {
					ObjectiveCMethod method = new ObjectiveCMethod (attr.Selector, "v@:", methodDelegate); //
					methods.Add (method);
				}
			}
			AddMethods((ObjectiveCMethod [])methods.ToArray(typeof(ObjectiveCMethod)));
		}
		
		public void AddMethods(ObjectiveCMethod [] methods) {
			if (methods == null)
				throw new ArgumentNullException ("methods");
			if (methods.Length == 0)
				throw new ArgumentException ("No methods passed.");
			IntPtr methodListPtr = Marshal.AllocHGlobal (Marshal.SizeOf (typeof (objc_method_list)) + methods.Length * Marshal.SizeOf (typeof (objc_method)));
			try {
				objc_method_list methodList = new objc_method_list ();
				methodList.count = methods.Length;
				Marshal.StructureToPtr (methodList, methodListPtr, false);
				ArrayList methodSignatures = new ArrayList ();
				try {
					for (int i = 0; i < methods.Length; i++) {
						objc_method method = new objc_method ();
						method.name = ObjectiveC.GetSelector (methods [i].Selector);
						method.types = Marshal.StringToHGlobalAnsi (methods [i].Signature);
						method.imp = methods [i].FunctionPtr;
						methodSignatures.Add (method.types);
						Marshal.StructureToPtr(method, (IntPtr)((long) methodListPtr + Marshal.SizeOf (typeof (objc_method_list)) + i * Marshal.SizeOf (typeof (objc_method))), false);
					}
					ObjectiveCMethods.class_addMethods (ptr, methodListPtr);
				} catch (Exception ex) {
					foreach (IntPtr ptr in methodSignatures) {
						Marshal.FreeHGlobal (ptr);
					}
					methodSignatures.Clear ();
					throw new Exception ("Methods not added.", ex);
				}
			} catch (Exception ex) {
				Marshal.FreeHGlobal (methodListPtr);
				throw new Exception ("Methods could not be added.", ex);
 			}
		}
		
		public void PoseAs (ObjectiveCClass original)
		{
			ObjectiveCMethods.class_poseAs (ptr, original.Ptr);
		}
	
		internal class Dispatcher {
			static readonly Hashtable classes = new Hashtable ();
			
			internal static Delegate RegisterMethod (MethodInfo method, string selector, ObjectiveCClass cls)
			{
				//Console.WriteLine("RegisterMethod: " + method);
				Hashtable methods;
				lock (classes) {
					if (!classes.ContainsKey (cls.Ptr))
						classes [cls.Ptr] = new Hashtable ();
					methods = (Hashtable)classes [cls.Ptr];
				}
				IntPtr sel = ObjectiveC.GetSelector (selector);
				lock (methods) {
					if (methods.ContainsKey (sel))
						throw new InvalidOperationException ("The selector for the class is already registered. This should never happen.");
					MethodInfo dispatchMethod = DynamicDispatching.GetMethod (method);
					Delegate dispatchDelegate = Delegate.CreateDelegate(DelegateFactory.Get (dispatchMethod), dispatchMethod);
					methods [sel] = method;
					return dispatchDelegate;
				}
			}
			
			internal static IntPtr Dispatch (IntPtr receiver, IntPtr selector, object [] args)
			{
				//Console.WriteLine ("Dispatch w/ args of length " + args.Length);
				ObjectiveCClass cls = ObjectiveCClass.FromPtr (Marshal.ReadIntPtr (receiver)); //
				Hashtable methods;
				lock(classes) {
					methods = (Hashtable)classes [cls.Ptr];
				}
				if (methods == null)
					throw new Exception ("Unknown receiver class.");
				MethodInfo method;
				lock (methods) {
					method = (MethodInfo)methods [selector];
				}
				if (method == null)
					throw new Exception ("Unknown selector.");
				//Console.WriteLine ("Dispatching " + ObjectiveC.GetSelectorName (selector) + " to: " + method);
				object [] arguments;
				if (args.Length > 0)
					arguments = ConvertArguments (args, method);
				else
					arguments = args;
				object ret = method.Invoke(cls.IsMetaclass ? null : ObjectiveCObject.FromId (receiver), arguments);
				//Console.WriteLine("Dispatch finished. Now transforming arguments.");
				return ConvertReturnValue (ret);
			}
			
			internal static object [] ConvertArguments (object [] args, MethodInfo method)
			{
				ParameterInfo [] parameters = method.GetParameters ();
				object [] arguments = new object [args.Length];
				for (int i = 0; i < args.Length; i++) {
					//Console.WriteLine(i + ": " + args [i].GetType().FullName);
					Type type = args [i].GetType ();
					if ((type == typeof (IntPtr)) && (parameters [i].ParameterType.IsSubclassOf (typeof (ObjectiveCObject)) || (parameters [i].ParameterType == typeof (ObjectiveCObject)))) {
						arguments [i] = ObjectiveCObject.FromId ((IntPtr)args [i]);
					} else
						arguments [i] = args [i];
				}
				return arguments;
			}
			
			internal static IntPtr ConvertReturnValue (object value) {
				if (value == null)
					return IntPtr.Zero;
				Type type = value.GetType ();
				if (type == typeof (void)) {
					return IntPtr.Zero;
				} else if (type == typeof (int)) {
					return (IntPtr)(int)value;
				} else if (type.IsSubclassOf (typeof (ObjectiveCObject)) || (type == typeof (ObjectiveCObject))) {
					return ((ObjectiveCObject)value).Id;
				} else if (type.IsEnum) {
					return (IntPtr)Convert.ToInt64 (Convert.ChangeType (value, Enum.GetUnderlyingType (type)));
				}
				throw new Exception ("Return type not yet supported: " + type.FullName);
			}
		}
	}
	
	
	internal sealed class DelegateFactory {
		private static AssemblyBuilder builder;
		private static ModuleBuilder module;
		static Hashtable delegates = new Hashtable ();

		static DelegateFactory()
		{
			AssemblyName an = new AssemblyName ();
			an.Name = "DynamicImpDelegates";
			builder = AppDomain.CurrentDomain.DefineDynamicAssembly (an, AssemblyBuilderAccess.Run, null, null, null, null, null, true);
			module = builder.DefineDynamicModule ("DynIMP", true);
		}
		
		private DelegateFactory ()
		{
		}
		
		public static Type Get (MethodInfo method)
		{
			Type delegateType;
			delegateType = DefineDelegate (method);
			delegates [DateTime.Now] = delegateType; // change this
			return delegateType;
		}
		
		public static Type DefineDelegate (MethodInfo targetMethod)
		{
			TypeBuilder type = module.DefineType (Guid.NewGuid ().ToString (), TypeAttributes.Class | TypeAttributes.Public | TypeAttributes.Sealed | TypeAttributes.AnsiClass | TypeAttributes.AutoClass, typeof (MulticastDelegate));
			type.SetCustomAttribute (new CustomAttributeBuilder (typeof (MarshalAsAttribute).GetConstructor (new Type [] { typeof (UnmanagedType) }), new object [] { UnmanagedType.FunctionPtr }));
			
			ConstructorBuilder constructor = type.DefineConstructor (MethodAttributes.RTSpecialName | MethodAttributes.HideBySig | MethodAttributes.Public, CallingConventions.Standard, new Type [] { typeof (object), typeof (int) });
			constructor.SetImplementationFlags (MethodImplAttributes.Runtime | MethodImplAttributes.Managed);
			
			ParameterInfo [] parameters = targetMethod.GetParameters ();
			Type [] paramTypes = new Type [parameters.Length];
			for (int i = 0; i < parameters.Length; i++) {
				paramTypes [i] = parameters [i].ParameterType;
			}
			MethodBuilder method = type.DefineMethod ("Invoke", MethodAttributes.Public | MethodAttributes.HideBySig | MethodAttributes.NewSlot | MethodAttributes.Virtual, targetMethod.ReturnType, paramTypes);
			method.SetImplementationFlags (MethodImplAttributes.Runtime | MethodImplAttributes.Managed);
			
			return type.CreateType ();
		}
	}
	
	internal sealed class DynamicDispatching {
		private static AssemblyBuilder builder;
		private static ModuleBuilder module;
		static Hashtable methods = new Hashtable ();

		static DynamicDispatching()
		{
			AssemblyName an = new AssemblyName ();
			an.Name = "DynamicImpTargets";
			builder = AppDomain.CurrentDomain.DefineDynamicAssembly (an, AssemblyBuilderAccess.Run, null, null, null, null, null, true);
			module = builder.DefineDynamicModule ("DynIMPd");
		}
		
		private DynamicDispatching ()
		{
		}
		
		public static MethodInfo GetMethod (MethodInfo targetMethod) {
			MethodInfo method;
			method = DefineMethod (targetMethod);
			methods [DateTime.Now] = method;
			return method;
		}
		
		public static MethodInfo DefineMethod (MethodInfo targetMethod) {
			TypeBuilder type = module.DefineType (Guid.NewGuid ().ToString ());
			
			ParameterInfo [] parameters = targetMethod.GetParameters ();
			Type [] paramTypes = new Type [parameters.Length + 2];
			paramTypes [0] = typeof (IntPtr);
			paramTypes [1] = typeof (IntPtr);
			for (int i = 0; i < parameters.Length; i++) {
				Type paramType = parameters [i].ParameterType;
				if (paramType.IsSubclassOf (typeof (ObjectiveCObject)) || (paramType == typeof (ObjectiveCObject))) {
					paramTypes [2 + i] = typeof (IntPtr);
				} else
					paramTypes [2 + i] = paramType;
			}
			MethodBuilder method = type.DefineMethod ("Dispatch", MethodAttributes.Public | MethodAttributes.Static, typeof (IntPtr), paramTypes);
			ILGenerator il = method.GetILGenerator ();
			LocalBuilder args = il.DeclareLocal (typeof (object []));
			args.SetLocalSymInfo ("args");
			il.Emit (OpCodes.Ldc_I4, parameters.Length);
			il.Emit (OpCodes.Newarr, typeof (object));
			il.Emit (OpCodes.Stloc_0);
			for (int i = 2; i < paramTypes.Length; i++) {
				il.Emit (OpCodes.Ldloc_0);
				il.Emit (OpCodes.Ldc_I4, i - 2);
				il.Emit (OpCodes.Ldarg, i);
				if (paramTypes [i].IsValueType)
					il.Emit (OpCodes.Box, paramTypes [i]);
				il.Emit (OpCodes.Stelem_I4);
			}
			il.Emit (OpCodes.Ldarg_0);
			il.Emit (OpCodes.Ldarg_1);
			il.Emit (OpCodes.Ldloc_0);
			il.Emit (OpCodes.Call, typeof (ObjectiveCClass.Dispatcher).GetMethod ("Dispatch", BindingFlags.NonPublic | BindingFlags.Static, null, new Type [] { typeof (IntPtr), typeof (IntPtr), typeof (object []) }, null));
			il.Emit (OpCodes.Ret);
			//Console.WriteLine(method);
			
			MethodInfo m = type.CreateType ().GetMethod ("Dispatch", BindingFlags.Public | BindingFlags.Static);
			//Console.WriteLine("DefineMethod: " + m);
			return m;
		}
	}
}
