using System;
using System.Runtime.InteropServices;

namespace Cocoa.Interop {
	internal class AppKitMethods {
		private AppKitMethods ()
		{
		}
	
		[DllImport ("/System/Library/Frameworks/AppKit.framework/AppKit")]
		internal static extern bool NSApplicationLoad ();
	}
}
