using System;

namespace Cocoa.Interop {
	public class Foundation {
		private Foundation ()
		{
		}
		
		public static void Init ()
		{
			FoundationMethods.NSStringFromClass (IntPtr.Zero);
		}
	}
}
