using System;
using System.Collections;
using System.ComponentModel;
using System.Reflection;
using System.Runtime.InteropServices;

namespace Cocoa.Interop {
	public abstract class ObjectiveCObject : Component, IDisposable {
		private static readonly Hashtable instances = new Hashtable();

		private IntPtr id = IntPtr.Zero;
		
		protected ObjectiveCObject ()
		{
		}
		
		protected ObjectiveCObject (IntPtr id)
		{
			Id = id;
		}
		
		protected override void Dispose (bool disposing)
		{
			//Console.WriteLine("Disposing object of type " + this.GetType().FullName);
			Unregister (id);
			base.Dispose(disposing);
		}
		
		internal static void Unregister (IntPtr id)
		{
			lock (instances) {
				instances.Remove (id);
			}
		}
		
		public IntPtr Id {
			get {
				return id;
			}
			set {
				if (value == IntPtr.Zero)
					throw new InvalidOperationException ("Setting Id to IntPtr.Zero should not happen.");
				lock (instances) {
					// remove previous mapping
					if (id != IntPtr.Zero)
						instances.Remove (id);
					// save new id
					id = value;
					// insert new mapping
					if (instances.ContainsKey (value) && (instances [value] != this))
						throw new InvalidOperationException ("Another object is already mapped to that id.");
					instances [value] = this;
				}
			}
		}
		
		public ObjectiveCClass IsA {
			get {
				return ObjectiveCClass.FromPtr (Marshal.ReadIntPtr (id));
			}
		}
		
		protected IntPtr FindClosestObjCClass ()
		{
			Type cls = this.GetType ();
			while (cls != null) {
				if (cls.IsDefined (typeof (ObjectiveCClassAttribute), false)) {
					ObjectiveCClassAttribute attr = (ObjectiveCClassAttribute)Attribute.GetCustomAttribute (cls, typeof (ObjectiveCClassAttribute));
					return ObjectiveC.GetClass (attr.Name);
				}
				cls = cls.BaseType;
			}
			throw new InvalidOperationException (this.GetType ().FullName + " is not an Objective-C wrapper class.");
		}

		public static ObjectiveCObject FromId (IntPtr id)
		{
			lock (instances) {
				if (instances.ContainsKey (id))
					return (ObjectiveCObject)instances [id];
			}
			ObjectiveCClass cls = ObjectiveCClass.FromPtr (Marshal.ReadIntPtr (id));
			Type type = FindType (cls);
			return (ObjectiveCObject)Activator.CreateInstance (type, new object [] { id });
		}
		
		public static bool Exists (IntPtr id)
		{
			lock (instances) {
				return instances.ContainsKey (id);
			}
		}
		
		private static Type FindType (ObjectiveCClass cls)
		{
			string className = cls.Name;
			Assembly [] assemblies = AppDomain.CurrentDomain.GetAssemblies ();
			foreach (Assembly assembly in assemblies) {
				if (assembly is System.Reflection.Emit.AssemblyBuilder)
					continue;
				Type [] types = assembly.GetExportedTypes ();
				foreach (Type type in types) {
					if (!type.IsSubclassOf (typeof (ObjectiveCObject)))
						continue;
					ObjectiveCClassAttribute attr = (ObjectiveCClassAttribute)Attribute.GetCustomAttribute (type, typeof (ObjectiveCClassAttribute));
					if (attr == null)
						continue;
					if (attr.Name != className)
						continue;
					return type;
				}
			}
			throw new Exception ("Class " + className + " not found.");
		}
	}
}
