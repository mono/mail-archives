using System;

namespace Cocoa.Interop {
	public class AppKit {
		private AppKit ()
		{
		}
		
		public static void Init ()
		{
			AppKitMethods.NSApplicationLoad ();
		}
	}
}
