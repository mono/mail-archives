using System;
using Cocoa.Interop;

namespace Cocoa {
	[ObjectiveCClass ("NSObject")]
	public abstract class Object : ObjectiveCObject {
		static IntPtr objCls;
		static Object ()
		{
			Foundation.Init ();
			ObjectiveCClass cls = ObjectiveCClass.Create ("CSObject", ObjectiveC.GetClass ("NSObject"));
			cls.AddMethods (new Delegate [] { new ObjectiveCImpDelegate (OnDealloc) });
			//cls.PoseAs (ObjectiveCClass.FromPtr (ObjectiveC.GetClass ("NSObject")));
			//ObjectiveC.SendMessage (cls.Ptr, "poseAsClass:", typeof (void), objCls = ObjectiveC.GetClass ("NSObject"));
		}
		
		protected Object () : base ()
		{
			Alloc ();
		}
		
		public Object (IntPtr id) : base (id)
		{
			Retain ();
		}

		protected void Init ()
		{
			Id = (IntPtr)ObjectiveC.SendMessage (Id, "init", typeof (IntPtr));
		}
		
		private void Alloc ()
		{
			Id = (IntPtr)ObjectiveC.SendMessage (FindClosestObjCClass (), "alloc", typeof (IntPtr));
		}

		protected void Retain ()
		{
			ObjectiveC.SendMessage (Id, "retain", typeof (IntPtr));
		}

		public int RetainCount {
			get {
				return (int)(uint)ObjectiveC.SendMessage (Id, "retainCount", typeof (uint));
			}
		}

		private void Release ()
		{
			ObjectiveC.SendMessage (Id, "release", typeof (void));
		}

		/*private void Autorelease ()
		{
			Id = (IntPtr)ObjectiveC.SendMessage (Id, "autorelease", typeof (IntPtr));
		}*/

		protected override void Dispose (bool disposing)
		{
			/*try {
				Console.WriteLine("Object of type {0} {2}... ({1}) {3}", this.GetType().FullName, RetainCount, disposing ? "disposing" : "finalizing", this);
			} catch (Exception ex) { Console.WriteLine(ex.Message); }*/
			//if (disposing)
				Release ();
			//else
			//	Autorelease ();
			base.Dispose (disposing);
		}
		
		[ObjectiveCMethod ("dealloc")]
		protected static IntPtr OnDealloc (IntPtr receiver, IntPtr selector)
		{
			//Console.WriteLine("OnDealloc");
			//Unregister (receiver);
			ObjectiveC.SendMessageToSuper (receiver, objCls, "dealloc", typeof (void));
			return IntPtr.Zero;
		}
	}
}
