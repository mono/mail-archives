using System;
using Cocoa.Interop;

namespace Cocoa {
	[ObjectiveCClass ("NSString")]
	public class String : Cocoa.Object {
		public String (string value) : base ()
		{
			Id = (IntPtr)ObjectiveC.SendMessage (Id, "initWithUTF8String:", typeof (IntPtr), value);
			Retain ();
		}
		
		public String (IntPtr id) : base (id)
		{
		}
		
		public static String Create (string value)
		{
			return (String)ObjectiveCObject.FromId ((IntPtr)ObjectiveC.SendMessage (ObjectiveC.GetClass ("NSString"), "stringWithUTF8String:", typeof (IntPtr), value));
		}
		
		public override string ToString ()
		{
			return (string)ObjectiveC.SendMessage (Id, "cString", typeof(string));
		}
	}
}
