using System;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Threading;
using Cocoa;
using Cocoa.Interop;

class Test {
	public static void Main() {
		/*Mach.Test();
		Thread.Sleep(2000);
		try {
			Marshal.ReadIntPtr(IntPtr.Zero);
		} catch (Exception ex) {
			Console.WriteLine(ex.Message);
		}*/
		Console.WriteLine(new ObjectiveCImpDelegate(ImpTest).Method.Name);
		//Application.Current.Run();
	}
	public static IntPtr ImpTest(IntPtr c, IntPtr s) {
		Console.WriteLine("ImpTest");
		return IntPtr.Zero;
	}
}
