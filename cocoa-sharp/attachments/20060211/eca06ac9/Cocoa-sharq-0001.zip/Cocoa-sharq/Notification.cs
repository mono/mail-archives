using System;
using Cocoa.Interop;

namespace Cocoa {
	[ObjectiveCClass ("NSNotification")]
	public class Notification : Object {
		public Notification (IntPtr id) : base (id)
		{
		}
	}
}
