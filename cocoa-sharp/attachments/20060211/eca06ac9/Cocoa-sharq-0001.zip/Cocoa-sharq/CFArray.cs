using System;
using Cocoa.Interop;

namespace Cocoa {
	[ObjectiveCClass ("NSCFArray")]
	public class CFArray : Array {
		public CFArray (IntPtr id) : base (id)
		{
		}
	}
}
