using System;
using Cocoa.Interop;

namespace Cocoa {
	[ObjectiveCClass ("NSCFDictionary")]
	public class CFDictionary : Dictionary {
		public CFDictionary (IntPtr id) : base (id)
		{
		}
	}
}
