using System;
using Cocoa.Interop;

namespace Cocoa {
	[ObjectiveCClass ("NSBundle")]
	public class Bundle : Cocoa.Object {
		/*public Cell (Rect frame) : base (frame)
		{
		}*/
		
		public Bundle (IntPtr id) : base (id)
		{
		}
		
		public static Bundle Main {
			get {
				return (Bundle)ObjectiveCObject.FromId ((IntPtr)ObjectiveC.SendMessage (ObjectiveC.GetClass ("NSBundle"), "mainBundle", typeof (IntPtr)));
			}
		}
		
		public string GetPathForImage (string name)
		{
			using (Cocoa.String str = new Cocoa.String (name))
				return ((Cocoa.String)ObjectiveC.SendMessage (Id, "pathForImageResource:", typeof (Cocoa.String), str)).ToString ();
		}
		
		public string GetLocalizedString (string key, string defaultValue, string tableName)
		{
			Cocoa.String strKey = null, strDefault = null, strTable = null;
			try {
				if (key != null)
					strKey = new Cocoa.String (key);
				if (defaultValue != null)
					strDefault = new Cocoa.String (defaultValue);
				if (tableName != null)
					strTable = new Cocoa.String (tableName);
				return ((Cocoa.String)ObjectiveC.SendMessage (Id, "localizedStringForKey:value:table:", typeof (Cocoa.String), strKey, strDefault, strTable)).ToString ();
			} finally {
				if (strKey != null)
					strKey.Dispose ();
				if (strDefault != null)
					strDefault.Dispose ();
				if (strTable != null)
					strTable.Dispose ();
			}
		}

		public bool LoadNibFile (string nibname)
		{
			using (Dictionary dict = Dictionary.Create ("NSOwner", Application.Shared)) {
				using (Cocoa.String str = new Cocoa.String (nibname))
					return (bool)ObjectiveC.SendMessage (Id, "loadNibFile:externalNameTable:withZone:", typeof (bool), str, dict, Application.Shared.Zone);
			}
		}
	}
}
