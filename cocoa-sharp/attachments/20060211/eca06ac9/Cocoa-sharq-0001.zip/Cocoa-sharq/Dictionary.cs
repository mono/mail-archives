using System;
using Cocoa.Interop;

namespace Cocoa {
	[ObjectiveCClass ("NSDictionary")]
	public class Dictionary : Cocoa.Object {
		public Dictionary () : base ()
		{
			Init();
		}
		
		public Dictionary (IntPtr id) : base (id)
		{
		}
		
		public static Dictionary Create (string key, Cocoa.Object value)
		{
			using (Cocoa.String str = new Cocoa.String (key)) {
				return (Dictionary)ObjectiveCObject.FromId ((IntPtr)ObjectiveC.SendMessage (ObjectiveC.GetClass ("NSDictionary"), "dictionaryWithObject:forKey:", typeof (IntPtr), value, str));
			}
		}
	}
}
