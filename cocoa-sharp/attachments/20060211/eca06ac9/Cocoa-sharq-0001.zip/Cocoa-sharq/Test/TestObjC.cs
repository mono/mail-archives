using System;
using System.Runtime.InteropServices;
using Cocoa;
using Cocoa.Interop;
using NUnit.Framework;

[TestFixture()]
public class Test {
	[Test()]
	public void TestMessaging() {
		Foundation.Init();
		IntPtr obj;

		obj = (IntPtr)ObjectiveC.SendMessage(ObjectiveC.GetClass("NSObject"), "alloc", typeof(IntPtr));
		Assert.AreEqual(1, (uint)ObjectiveC.SendMessage(obj, "retainCount", typeof(uint)));
		obj = (IntPtr)ObjectiveC.SendMessage(obj, "init", typeof(IntPtr));
		Assert.AreEqual(1, (uint)ObjectiveC.SendMessage(obj, "retainCount", typeof(uint)));
		ObjectiveC.SendMessage(obj, "release", typeof(void));
	}

	[Test()]
	public void TestMessagingWithPool() {
		AppKit.Init();
		IntPtr arp = (IntPtr)ObjectiveC.SendMessage(ObjectiveC.GetClass("NSAutoreleasePool"), "alloc", typeof(IntPtr));
		try {
			arp = (IntPtr)ObjectiveC.SendMessage(arp, "init", typeof(IntPtr));
			IntPtr obj;

			obj = (IntPtr)ObjectiveC.SendMessage(ObjectiveC.GetClass("NSBox"), "alloc", typeof(IntPtr));
			obj = (IntPtr)ObjectiveC.SendMessage(obj, "initWithFrame:", typeof(IntPtr), new Rect(0,0,100,25));
			ObjectiveC.SendMessage(obj, "release", typeof(void));

			string str = "hello";
			obj = (IntPtr)ObjectiveC.SendMessage(ObjectiveC.GetClass("NSString"), "stringWithUTF8String:", typeof(IntPtr), str);
			obj = (IntPtr)ObjectiveC.SendMessage(obj, "retain", typeof(IntPtr));
			Assert.AreEqual(str, (string)ObjectiveC.SendMessage(obj, "cString", typeof(string)));
			ObjectiveC.SendMessage(obj, "release", typeof(void));
		} finally {
			ObjectiveC.SendMessage(arp, "release", typeof(void));
		}
	}

	[Test()]
	public void TestWindow() {
		AppKit.Init();
		IntPtr arp = (IntPtr)ObjectiveC.SendMessage(ObjectiveC.GetClass("NSAutoreleasePool"), "alloc", typeof(IntPtr));
		try {
			arp = (IntPtr)ObjectiveC.SendMessage(arp, "init", typeof(IntPtr));
			Cocoa.Window w = new Cocoa.Window(new Rect(0,0,200,100), WindowStyle.Titled | WindowStyle.Closable, BackingStoreType.Buffered, false);
			Assert.AreEqual(1, w.RetainCount, "retainCount expected to be 1, is "+w.RetainCount);
			w.Show();
			System.Threading.Thread.Sleep(1000);
			w.Dispose();
		} finally {
			ObjectiveC.SendMessage(arp, "release", typeof(void));
		}
	}

	[Test()]
	[Ignore("Causes a SIGSEGV signal")]
	[ExpectedException(typeof(NullReferenceException))]
	public void TestMachExceptions() {
		Mach.Test();
		System.Threading.Thread.Sleep(500);
		//Marshal.ReadIntPtr(IntPtr.Zero);
	}

	[Test()]
	public void TestClassAdding() {
		Assert.AreEqual(3*Marshal.SizeOf(typeof(IntPtr)), Marshal.SizeOf(typeof(ObjectiveC).Assembly.GetType("Cocoa.Interop.objc_method", true)));
		Foundation.Init();
		string className = "AFTest";
		ObjectiveCClass cls = ObjectiveCClass.Create(className, ObjectiveC.GetClass("NSObject"));
		Assert.AreEqual(className, cls.Name, "Class name is " + cls.Name + ", expected " + className);
		cls.AddMethods(new Delegate [] { new ObjectiveCImpDelegate(ImpMethod) });
		TestObject obj = new TestObject();
		obj.Test();
		obj.Dispose();
	}
	
	[ObjectiveCMethod ("test")]
	private static IntPtr ImpMethod(IntPtr id, IntPtr selector)
	{
		Console.WriteLine("ImpMethod");
		return IntPtr.Zero;
	}
	
	[ObjectiveCClass("AFTest")]
	private class TestObject : Cocoa.Object {
		public TestObject() : base() {
			Id = (IntPtr)ObjectiveC.SendMessage(Id, "init", typeof(IntPtr));
		}
		public void Test() {
			ObjectiveC.SendMessage(Id, "test", typeof(void));
		}
	}

	[Test()]
	[ExpectedException(typeof(ArgumentException))]
	public void TestClassHandler() {
		ObjectiveC.SetClassHandler(new ObjectiveCClassHandlerDelegate(ClassHandler));
		ObjectiveC.GetClass("AFNonExistingClass");
	}
	private static int ClassHandler(string className) {
		Console.WriteLine("ClassHandler");
		return 0;
	}
	
	public void TestClassRegistering() {
		ObjectiveCClass.Create(typeof(TestClass));
		TestClass x = new TestClass();
		x.Test();
		x.Dispose();
	}
	[ObjectiveCClass("AFTestClass")]
	private class TestClass : Cocoa.Object {
		public TestClass() {
			Init();
		}
		[ObjectiveCMethod("testX")]
		public void TestX() {
			Console.WriteLine("testX");
		}
		[ObjectiveCMethod("testY:")]
		public void TestY(int a) {
			Console.WriteLine("testY");
			Assert.AreEqual (42, a);
		}
		public void Test() {
			ObjectiveC.SendMessage(Id, "testX", typeof(void));
			ObjectiveC.SendMessage(Id, "testY:", typeof(void), (int)42);
		}
	}
}
