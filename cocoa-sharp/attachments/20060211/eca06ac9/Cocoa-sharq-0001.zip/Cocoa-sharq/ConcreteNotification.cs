using System;
using Cocoa.Interop;

namespace Cocoa {
	[ObjectiveCClass ("NSConcreteNotification")]
	public class ConcreteNotification : Notification {
		public ConcreteNotification (IntPtr id) : base (id)
		{
		}
	}
}
