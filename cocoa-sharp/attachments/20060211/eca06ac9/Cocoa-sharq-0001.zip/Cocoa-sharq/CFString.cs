using System;
using Cocoa.Interop;

namespace Cocoa {
	[ObjectiveCClass ("NSCFString")]
	public class CFString : Cocoa.String {
		public CFString (IntPtr id) : base (id)
		{
		}
	}
}
