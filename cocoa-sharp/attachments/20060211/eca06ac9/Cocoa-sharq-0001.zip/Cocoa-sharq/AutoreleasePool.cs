using System;
using Cocoa.Interop;

namespace Cocoa {
	[ObjectiveCClass ("NSAutoreleasePool")]
	public class AutoreleasePool : Cocoa.Object {
		public AutoreleasePool () : base ()
		{
			Init ();
		}
		
		public AutoreleasePool (IntPtr id) : base (id)
		{
		}
		
		protected override void Dispose (bool disposing)
		{
			base.Dispose (true); // do not autorelease!
		}
	}
}
