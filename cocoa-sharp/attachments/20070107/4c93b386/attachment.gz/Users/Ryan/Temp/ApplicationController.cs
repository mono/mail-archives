using System;
using Cocoa;

namespace CocoaSharpTextFieldTestApp
{
        [Register("ApplicationController")]
        public class ApplicationController : Cocoa.Object 
        {
                [Connect]
                public Cocoa.Window mainWindow;
                
                [Connect]
                public Cocoa.Button allowsEditingTextAttributesButton;

                [Connect]
                public Cocoa.Button bezeledButton;

                [Connect]
                public Cocoa.Button borderedButton;

                [Connect]
                public Cocoa.Button drawsBackgroundButton;

                [Connect]
                public Cocoa.Button editableButton;

                [Connect]
                public Cocoa.Button selectableButton;

                [Connect]
                public Cocoa.Button importGraphicsButton;

                [Connect]
                public Cocoa.TextField textField;

                [Connect]
                public Cocoa.TextField titleTextField;

                [Connect]
                public Cocoa.Button acceptsFirstResponderButton;
        
                public ApplicationController(System.IntPtr a)
                        : base(a)
                {
                }
        
                [Export("applicationWillFinishLaunching:")]
                public void FinishLoading(Cocoa.Notification notification)
                {
                        Console.WriteLine("Form Loaded");
                        
                        acceptsFirstResponderButton.Value = (textField.AcceptsFirstResponder ? "1" : "0");
                        
                        Console.WriteLine("textField.AcceptsFirstResponder=" + textField.AcceptsFirstResponder.ToString());
                        Console.WriteLine("textField.AllowsEditingTextAttributes=" + textField.AllowsEditingTextAttributes.ToString());
                        Console.WriteLine("textField.BackgroundColor=" + textField.BackgroundColor.ToString());
                        Console.WriteLine("textField.TextColor=" + textField.TextColor.ToString());
                        Console.WriteLine("textField.Bezeled=" + textField.Bezeled.ToString());
                        Console.WriteLine("textField.Bordered=" + textField.Bordered.ToString());
                        Console.WriteLine("textField.DrawsBackground=" + textField.DrawsBackground.ToString());
                        Console.WriteLine("textField.Editable=" + textField.Editable.ToString());
                        Console.WriteLine("textField.ImportsGraphics=" + textField.ImportsGraphics.ToString());
                        Console.WriteLine("textField.Selectable=" + textField.Selectable.ToString());
                }
                
                [Export("allowsEditingTextAttributesClick:")]
                public void AllowsEditingTextAttributesClick(object sender)
                {
                        Console.WriteLine("AllowsEditingTextAttributesClick");
                        textField.AllowsEditingTextAttributes = (allowsEditingTextAttributesButton.Value == "1");
                }

                [Export("backgroundWhiteClick:")]
                public void BackgroundWhiteClick(object sender)
                {
                        Console.WriteLine("BackgroundWhiteClick");
                        textField.BackgroundColor = Cocoa.Color.White;
                }

                [Export("backgroundYellowClick:")]
                public void BackgroundYellowClick(object sender)
                {
                        Console.WriteLine("BackgroundYellowClick");
                        textField.BackgroundColor = Cocoa.Color.Yellow;
                }

                [Export("backgroundRedClick:")]
                public void BackgroundRedClick(object sender)
                {
                        Console.WriteLine("BackgroundRedClick");
                        textField.BackgroundColor = Cocoa.Color.Red;
                }
                
                [Export("applyTitleClick:")]
                public void ApplyTitleClick(object sender)
                {
                        Console.WriteLine("ApplyTitleClick");
                        textField.SetTitleWithMnemonic(titleTextField.Value);
                }
                
                [Export("textBlackClick:")]
                public void TextBlackClick(object sender)
                {
                        Console.WriteLine("TextBlackClick");
                        textField.TextColor = Cocoa.Color.Black;
                }

                [Export("textRedClick:")]
                public void TextRedClick(object sender)
                {
                        Console.WriteLine("TextRedClick");
                        textField.TextColor = Cocoa.Color.Red;
                }

                [Export("textBlueClick:")]
                public void TextBlueClick(object sender)
                {
                        Console.WriteLine("TextBlueClick");
                        textField.TextColor = Cocoa.Color.Blue;
                }
                
                [Export("bezeledClick:")]
                public void BezeledClick(object sender)
                {
                        Console.WriteLine("BezeledClick");
                        textField.Bezeled = (bezeledButton.Value == "1");
                }
                
                [Export("borderedClick:")]
                public void BorderedClick(object sender)
                {
                        Console.WriteLine("BorderedClick");
                        textField.Bordered = (borderedButton.Value == "1");
                }
                
                [Export("drawsBackgroundClick:")]
                public void DrawsBackgroundClick(object sender)
                {
                        Console.WriteLine("DrawsBackgroundClick");
                        textField.DrawsBackground = (drawsBackgroundButton.Value == "1");
                }
                
                [Export("editableClick:")]
                public void EditableClick(object sender)
                {
                        Console.WriteLine("EditableClick");
                        textField.Editable = (editableButton.Value == "1");
                }
                
                [Export("importGraphicsClick:")]
                public void ImportGraphicsClick(object sender)
                {
                        Console.WriteLine("ImportGraphicsClick");
                        textField.ImportsGraphics = (importGraphicsButton.Value == "1");
                }
                
                [Export("selectableClick:")]
                public void SelectableClick(object sender)
                {
                        Console.WriteLine("SelectableClick");
                        textField.Selectable = (selectableButton.Value == "1");
                }
                
                [Export("selectTextClick:")]
                public void SelectTextClick(object sender)
                {
                        Console.WriteLine("SelectTextClick");
                        textField.SelectText();
                }
                
                [Export("bezelStyleClick:")]
                public void BezelStyleClick(object sender)
                {
                        Console.WriteLine("BezelStyleClick");
                        Console.WriteLine("BezelStyle=" + textField.BezelStyle.ToString());
                        textField.BezelStyle = Cocoa.BezelStyle.Rounded;
                        
                        //Rounded          = 1
                        //RegularSquare    = 2
		        //ThickSquare      = 3,
		        //ThickerSquare    = 4,
		        //Disclosure       = 5,
		        //ShadowlessSquare = 6,
		        //Circular         = 7,
		        //TexturedSquare   = 8,
		        //HelpButton       = 9
                }
        }
}