using System;
using Cocoa;

namespace CocoaSharpTextFieldTestApp
{
        class MainClass
        {
                static void Main(string[] args) 
                {
                        MainClass main = new MainClass();
                        main.Run();
                }

                public void Run() 
                {
                        Application.Init();
                        Application.LoadNib("Main.nib");
                        Application.Run();
                }
        }
}