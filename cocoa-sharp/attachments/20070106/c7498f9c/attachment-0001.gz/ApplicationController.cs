using System;
using Cocoa;

namespace CocoaSharpHelloWorld
{
    [Register("ApplicationController")]
    public class ApplicationController : Cocoa.Object 
    {
        [Connect]
        public Cocoa.Window mainWindow;
        
        [Connect]
        public Cocoa.ProgressIndicator progressBar;

        [Connect]
        public Cocoa.Button bezeledButton;
        
        [Connect]
        public Cocoa.TextField doubleValue;

        [Connect]
        public Cocoa.TextField minValue;

        [Connect]
        public Cocoa.TextField maxValue;
        
        [Connect]
        public Cocoa.Button displayedWhenStoppedButton;

        [Connect]
        public Cocoa.Button usesThreadedAnimationButton;
        
        public ApplicationController(System.IntPtr a)
            : base(a)
        {
        }
        
        [Export("applicationWillFinishLaunching:")]
        public void FinishLoading(Cocoa.Notification notification)
        {
            Console.WriteLine("Form Loaded");
        }

        [Export("startAnimationClick:")]
        public void StartAnimationClick(object sender)
        {
                Console.WriteLine("StartAnimationClick");
                progressBar.StartAnimation();
        }

        [Export("stopAnimationClick:")]
        public void StopAnimationClick(object sender)
        {
                Console.WriteLine("StopAnimationClick");
                progressBar.StopAnimation();
        }

        [Export("animateClick:")]
        public void AnimateClick(object sender)
        {
                Console.WriteLine("AnimateClick");
                progressBar.Animate();
        }

        [Export("determinateClick:")]
        public void DeterminateClick(object sender)
        {
                Console.WriteLine("DeterminateClick");
                progressBar.Indeterminate = false;
        }

        [Export("indeterminateClick:")]
        public void IndeterminateClick(object sender)
        {
                Console.WriteLine("IndeterminateClick");
                progressBar.Indeterminate = true;
        }

        [Export("barClick:")]
        public void BarClick(object sender)
        {
                Console.WriteLine("BarClick");
                progressBar.Style = ProgressIndicatorStyle.Bar;
        }

        [Export("spinningClick:")]
        public void SpinningClick(object sender)
        {
                Console.WriteLine("SpinningClick");
                progressBar.Style = ProgressIndicatorStyle.Spinning;
        }
        
        [Export("bezeledClick:")]
        public void BezeledClick(object sender)
        {
                Console.WriteLine("BezeledClick");
                //Console.WriteLine(bezeledButton.Value);
                progressBar.Bezeled = (bezeledButton.Value == "1");
        }

        [Export("smallClick:")]
        public void SmallClick(object sender)
        {
                Console.WriteLine("SmallClick");
                progressBar.ControlSize = ProgressIndicatorControlSize.Small;
        }

        [Export("regularClick:")]
        public void RegularClick(object sender)
        {
                Console.WriteLine("RegularClick");
                progressBar.ControlSize = ProgressIndicatorControlSize.Regular;
        }

        [Export("defaultClick:")]
        public void DefaultClick(object sender)
        {
                Console.WriteLine("DefaultClick");
                progressBar.ControlTint = ProgressIndicatorControlTint.Default;
        }

        [Export("clearClick:")]
        public void ClearClick(object sender)
        {
                Console.WriteLine("ClearClick");
                progressBar.ControlTint = ProgressIndicatorControlTint.Clear;
        }
        
        [Export("displayedWhenStoppedClick:")]
        public void DisplayedWhenStoppedClick(object sender)
        {
                Console.WriteLine("DisplayedWhenStoppedClick");
                progressBar.DisplayedWhenStopped = (displayedWhenStoppedButton.Value == "1");
        }

        [Export("incrementByClick:")]
        public void IncrementByClick(object sender)
        {
                Console.WriteLine("IncrementByClick");
                progressBar.IncrementBy(1);
        }

        [Export("applyDoubleValueClick:")]
        public void ApplyDoubleValueClick(object sender)
        {
                Console.WriteLine("ApplyDoubleValueClick");

                double value;
                bool result = double.TryParse(doubleValue.Value, out value);
                if (!result)
                {
                        doubleValue.Value = "0";
                        value = 0;
                }
                progressBar.DoubleValue = value;
        }

        [Export("applyMinValueClick:")]
        public void MinValueClick(object sender)
        {
                Console.WriteLine("ApplyMinValueClick");
                
                double value;
                bool result = double.TryParse(minValue.Value, out value);
                if (!result)
                {
                        minValue.Value = "0";
                        value = 0;
                }
                progressBar.MinValue = value;
        }

        [Export("applyMaxValueClick:")]
        public void ApplyMaxValueClick(object sender)
        {
                Console.WriteLine("ApplyMaxValueClick");

                double value;
                bool result = double.TryParse(maxValue.Value, out value);
                if (!result)
                {
                        maxValue.Value = "100";
                        value = 100;
                }
                progressBar.MaxValue = value;
        }

        [Export("sizeToFitClick:")]
        public void SizeToFitClick(object sender)
        {
                Console.WriteLine("SizeToFitClick");
                progressBar.SizeToFit();
        }

        [Export("usesThreadedAnimationClick:")]
        public void UsesThreadedAnimationClick(object sender)
        {
                Console.WriteLine("UsesThreadedAnimationClick");
                //Console.WriteLine(usesThreadedAnimationButton.Value);
                progressBar.UsesThreadedAnimation = (usesThreadedAnimationButton.Value == "1");
        }
    }   
}