//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading;
//using Android.App;
//using Android.Content;
//using Android.OS;
//using Android.Preferences;
//using Android.Runtime;
//using Android.Views;
//using Android.Widget;
//using NorthStar.Driver.Application;
//using TheNorthStar.Api.Requests;
//using TheNorthStar.Api.Results;

//namespace NorthStar.Driver
//{
//    [Service]
//    public class NorthStarBackgroundService : Service
//    {
//        private string driverId;
//        private System.Timers.Timer timer;

//        public override IBinder OnBind(Intent intent)
//        {
//            return null;
//        }

//        public override void OnCreate()
//        {
//            base.OnCreate();
//            timer = new System.Timers.Timer(20000);
//            timer.Elapsed += TimerElapsed;
//        }

//        void TimerElapsed(object sender, System.Timers.ElapsedEventArgs e)
//        {
//            ThreadPool.QueueUserWorkItem(UpdatePosition);
//        }

//        public override void OnStart(Intent intent, int startId)
//        {
//            base.OnStart(intent, startId);

//            driverId = intent.GetStringExtra("driverId");

//            timer.Start();
//        }

//        public override void OnDestroy()
//        {
//            base.OnDestroy();
//            timer.Stop();
//        }

//        private void UpdatePosition(object data)
//        {

//            ConnectToSever api = new ConnectToSever(Helper.GetServer(ApplicationContext));

//            GPSTracker gps = new GPSTracker(ApplicationContext);

//            var pos = new DriverPosition() { Latitude = gps.latitude, Longitude = gps.longitude, DriverId = driverId };
//            try
//            {
//                api.UpdatePosition(pos);
//            }
//            catch
//            {
//                Android.Util.Log.Info("EXC_update1", "update driver failed");
//            }
//        }
//    }
//}