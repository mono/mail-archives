using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.Locations;
using Java.IO;

namespace NorthStar.Driver
{
    public class GPSTracker : Service, ILocationListener
    {

        public readonly Context mContext;

        // flag for network status
        Boolean isNetworkEnabled = false;

        Location location; // location
        public double latitude; // latitude
        public double longitude; // longitude

        public LocationManager locationManager;



        public GPSTracker(Context context)
        {
            this.mContext = context;
            getLocation();

        }


        public Location getLocation()
        {
            locationManager = (LocationManager)mContext.GetSystemService(Context.LocationService);

            // getting network status
            isNetworkEnabled = locationManager.IsProviderEnabled(LocationManager.NetworkProvider);

            if (isNetworkEnabled)
            {
                locationManager.RequestLocationUpdates(LocationManager.NetworkProvider, 1000, 10, this);

                if (locationManager != null)
                {
                    location = locationManager.GetLastKnownLocation(LocationManager.NetworkProvider);
                    if (location != null)
                    {
                        latitude = location.Latitude;
                        longitude = location.Longitude;
                    }
                }
            }

            return location;
        }


        /**
        * Function to get latitude
        * */
        public double getLatitude()
        {

            latitude = location.Latitude;
            // return latitude

            return latitude;
        }


        /**
         * Function to get longitude
         * */
        public double getLongitude()
        {
            latitude = location.Longitude;
            // return latitude

            return longitude;
        }

        public void OnLocationChanged(Location location)
        {
        }


        public void OnProviderDisabled(String provider)
        {
        }


        public void OnProviderEnabled(String provider)
        {
        }


        public void OnStatusChanged(string provider, Availability status, Bundle extras)
        {
        }


        public override IBinder OnBind(Intent arg0)
        {
            return null;
        }


    }
}