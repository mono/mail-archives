﻿using System;

using Android.App;
using Android.Content;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.OS;
using Android.Util;

namespace GcTest
{
    [Activity(Label = "GcTest", MainLauncher = true)]
    public class Activity1 : Activity
    {
        private Button aBtn;
        protected override void OnCreate(Bundle bundle)
        {
            Log.Info("TEST", "create Activity1");
            base.OnCreate(bundle);
            SetContentView(Resource.Layout.Main);

            aBtn = FindViewById<Button>(Resource.Id.buttonA);
            aBtn.Click += new EventHandler(aBtn_Click);
        }

        protected override void OnResume()
        {
            base.OnResume();
            Log.Info("TEST", "resumed Activity1");
        }

        void aBtn_Click(object sender, EventArgs e)
        {
            StartActivity(typeof(A));
        }
    }
}

