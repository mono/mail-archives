using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.Util;
using System.Threading;
using Android.Graphics.Drawables;

namespace GcTest
{
    [Activity(Label = "A")]
    public class A : Activity
    {
        private LimitedSizeDictionary<string, Drawable> imgCache = new LimitedSizeDictionary<string, Drawable>(10);
        private LimitedSizeDictionary<string, Drawable> imgCache2 = new LimitedSizeDictionary<string, Drawable>(10);
        protected override void OnCreate(Bundle bundle)
        {
            Log.Info("TEST", "create A");
            base.OnCreate(bundle);
            SetContentView(Resource.Layout.Main);

            imgCache.OnCleared += new LimitedSizeDictionary<string, Drawable>.ItemsClearedHandler(imgCache_OnCleared);
            imgCache2.OnCleared += new LimitedSizeDictionary<string, Drawable>.ItemsClearedHandler(imgCache_OnCleared);

            imgCache.Clear();
            imgCache2.Clear();
        }

        void imgCache_OnCleared()
        {
            try
            {
                Log.Info("TEST", "collect");
                GC.Collect(); //causes app to crash
                Log.Info("TEST", "collect finished");
            }
            catch (Exception e)
            {
                //exception is never caught
                Log.Warn("TEST", e.Message);
            }
        }


        protected override void OnDestroy()
        {
            Log.Info("TEST", "destroy A");
            base.OnDestroy();

            collect();
        }

        private void collect()
        {
            //when no new thread is started, application works fine
            new Thread(() =>
            {
                imgCache.Clear();
                imgCache2.Clear();
            }).Start();
        }
    }
}