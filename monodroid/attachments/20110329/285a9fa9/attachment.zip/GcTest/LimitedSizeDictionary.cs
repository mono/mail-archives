﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GcTest
{
    /// <summary>
    /// Limited size dictionary.
    /// When size limit is reached, adding entry will
    /// cause the oldest entry to be automatically removed.
    /// </summary>
    /// <typeparam name="K">dictionary keys type</typeparam>
    /// <typeparam name="V">dictionary values type</typeparam>
    public class LimitedSizeDictionary<K, V> : IDictionary<K, V>
    {
        private Dictionary<K, V> inner;
        private Queue<K> addOrder;

        private int maxSize;
        public int MaxSize
        {
            get { return maxSize; }
        }

        public LimitedSizeDictionary(int maxSize)
        {
            inner = new Dictionary<K, V>(maxSize);
            addOrder = new Queue<K>(maxSize);
            this.maxSize = maxSize;
        }

        public delegate void ItemsClearedHandler();
        public delegate void ItemRemovedHandler<V>(V item);
        /// <summary>
        /// Triggered when item is no longer kept in this dictionary.
        /// Provides an opportunity to call dispose on that object, if necessary.
        /// Can be trigger when item is added (another item may be removed if size limit is reached) or removed.
        /// </summary>
        public event ItemRemovedHandler<V> OnItemRemoved;
        /// <summary>
        /// Triggered when clear was called, for each item in dictionary,
        /// before item is removed from dictionary.
        /// </summary>
        public event ItemRemovedHandler<V> OnAboutToClear;

        public event ItemsClearedHandler OnCleared;

        #region IDictionary<K,V> Members

        public void Add(K key, V value)
        {
            if (inner.Count == maxSize)
            {
                K k;
                do
                {
                    k = addOrder.Dequeue();
                } while (!inner.ContainsKey(k) && addOrder.Count > 0);
                Remove(k);
            }

            if (inner.Count == maxSize)
                throw new InvalidOperationException("dictionary size limit reached");
            inner.Add(key, value);
            addOrder.Enqueue(key);
        }

        public bool ContainsKey(K key)
        {
            return inner.ContainsKey(key);
        }

        public ICollection<K> Keys
        {
            get { return inner.Keys; }
        }

        public bool Remove(K key)
        {
            V val = default(V);
            bool fireEvent = false;
            if (OnItemRemoved != null && inner.ContainsKey(key))
            {
                val = inner[key];
                fireEvent = true;
            }
            bool result = inner.Remove(key);
            if (OnItemRemoved != null && fireEvent)
                OnItemRemoved(val);
            return result;
        }

        public bool TryGetValue(K key, out V value)
        {
            return inner.TryGetValue(key, out value);
        }

        public ICollection<V> Values
        {
            get { return inner.Values; }
        }

        public V this[K key]
        {
            get
            {
                return inner[key];
            }
            set
            {
                if (inner.ContainsKey(key))
                    inner[key] = value;
                else
                    Add(key, value);
            }
        }

        #endregion

        #region ICollection<KeyValuePair<K,V>> Members

        public void Add(KeyValuePair<K, V> item)
        {
            inner.Add(item.Key, item.Value);
        }

        public void Clear()
        {
            if (OnAboutToClear != null)
            {
                foreach (var kvp in inner)
                {
                    if (OnAboutToClear != null)
                        OnAboutToClear(kvp.Value);
                    else
                        break;
                }
            }
            inner.Clear();

            if (OnCleared != null)
                OnCleared();
        }

        public bool Contains(KeyValuePair<K, V> item)
        {
            return inner.ContainsKey(item.Key) && inner[item.Key].Equals(item.Value);
        }

        public void CopyTo(KeyValuePair<K, V>[] array, int arrayIndex)
        {
            int idx = arrayIndex;
            foreach (KeyValuePair<K, V> kvp in inner)
                array[idx++] = kvp;
        }

        public int Count
        {
            get { return inner.Count; }
        }

        public bool IsReadOnly
        {
            get { return false; }
        }

        public bool Remove(KeyValuePair<K, V> item)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region IEnumerable<KeyValuePair<K,V>> Members

        public IEnumerator<KeyValuePair<K, V>> GetEnumerator()
        {
            return inner.GetEnumerator();
        }

        #endregion

        #region IEnumerable Members

        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            return inner.GetEnumerator();
        }

        #endregion
    }
}
