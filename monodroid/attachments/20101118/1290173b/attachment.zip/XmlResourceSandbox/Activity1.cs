﻿using System;
using System.IO;
using System.Text;
using System.Xml;
using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Javax.Xml;
using Javax.Xml.Parsers;
using System.Reflection;

namespace XmlResourceSandbox
{
    [Activity(Label = "My Activity", MainLauncher = true)]
    public class Activity1 : Activity
    {
        int count = 1;

        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);

            // Set our view from the "main" layout resource
            SetContentView(Resource.layout.main);

            // Get our button from the layout resource,
            // and attach an event to it
            Button button = FindViewById<Button>(Resource.id.myButton);

            button.Click += delegate { button.Text = string.Format("{0} clicks!", count++); };

            this.ParseXmlResource();
        }

        private void ParseXmlResource()
        {
            var file = new Java.IO.File(this.GetExternalFilesDir(null), "resource_compiled.xml");
            using (Java.IO.InputStream bytes = this.Resources.OpenRawResource(Resource.xml.resource))
            using (Java.IO.FileOutputStream fos = new Java.IO.FileOutputStream(file))
            {
                byte[] buffer = new byte[1024];
                int i;
                while ((i = bytes.Read(buffer)) > -1)
                {
                    fos.Write(buffer, 0, i);

                    Array.Clear(buffer, 0, buffer.Length - 1);
                }
            }
        }
    }
}
