﻿using System;

using Android.App;
using Android.Content;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.OS;
using Android.Views.Animations;

namespace SweepSample
{
    [Activity(Label = "SweepSample", MainLauncher = true, Icon = "@drawable/icon")]
    public class Activity1 : Activity
    {
        enum item
        {
            First,
            Second
        }

        item currentItem;

        int count = 1;
        GestureListener gestureListener;
        private GestureDetector gestureScanner;

        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);

            SetContentView(Resource.Layout.Main);

            gestureListener = new GestureListener();
            gestureListener.LeftEvent += new Action(gestureListener_LeftEvent);
            gestureListener.RightEvent += new Action(gestureListener_RightEvent);
            gestureScanner = new GestureDetector(this, gestureListener);

            currentItem = item.First;
        }

        void gestureListener_RightEvent()
        {
            int it, it2;

            if (currentItem == item.First)
            {
                it = Resource.Id.FirstItem;
                it2 = Resource.Id.SecondItem;
            }
            else
            {
                it = Resource.Id.SecondItem;
                it2 = Resource.Id.FirstItem;
            }

            Animation a = AnimationUtils.LoadAnimation(this, Resource.Animation.translateFirstItemLeftToRight);
            a.Reset();
            RelativeLayout r = FindViewById(it) as RelativeLayout;
            r.ClearAnimation();
            r.StartAnimation(a);
            r.Visibility = ViewStates.Gone;

            Animation a2 = AnimationUtils.LoadAnimation(this, Resource.Animation.translateSecondItemLeftToRight);
            a2.Reset();
            RelativeLayout r2 = FindViewById(it2) as RelativeLayout;
            r2.ClearAnimation();
            r2.StartAnimation(a2);
            r2.Visibility = ViewStates.Visible;

            currentItem = it2 == Resource.Id.FirstItem ? item.First : item.Second;
        }

        void gestureListener_LeftEvent()
        {
            int it, it2;

            if (currentItem == item.First)
            {
                it = Resource.Id.FirstItem;
                it2 = Resource.Id.SecondItem;
            }
            else
            {
                it = Resource.Id.SecondItem;
                it2 = Resource.Id.FirstItem;
            }

            Animation a = AnimationUtils.LoadAnimation(this, Resource.Animation.translateFirstItemRightToLeft);
            a.Reset();
            RelativeLayout r = FindViewById(it) as RelativeLayout;
            r.ClearAnimation();
            r.StartAnimation(a);
            r.Visibility = ViewStates.Gone;

            Animation a2 = AnimationUtils.LoadAnimation(this, Resource.Animation.translateSecondItemRightToLeft);
            a2.Reset();
            RelativeLayout r2 = FindViewById(it2) as RelativeLayout;
            r2.ClearAnimation();
            r2.StartAnimation(a2);
            r2.Visibility = ViewStates.Visible;

            currentItem = it2 == Resource.Id.FirstItem ? item.First : item.Second;
        }

        public override bool OnTouchEvent(MotionEvent e)
        {
            return gestureScanner.OnTouchEvent(e);
        }
    }
}

