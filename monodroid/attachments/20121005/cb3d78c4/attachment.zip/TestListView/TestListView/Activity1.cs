using System;

using Android.App;
using Android.Content;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.OS;

namespace TestListView
{
	[Activity (Label = "TestListView", MainLauncher = true)]
	public class Activity1 : Activity
	{
		int count = 1;

		protected override void OnCreate (Bundle bundle)
		{
			base.OnCreate (bundle);

			// Set our view from the "main" layout resource
			SetContentView (Resource.Layout.Main);

			var items = new string []{"Row 1", "Row 2", "Row 3", "Row 1", "Row 2", "Row 3", "Row 1", "Row 2", "Row 3", "Row 1", "Row 2", "Row 3", "Row 1", "Row 2", "Row 3", "Row 1", "Row 2", "Row 3", "Row 1", "Row 2", "Row 3", "Row 1", "Row 2", "Row 3"};
			
			var ListAdapter = new ArrayAdapter<String> (this, Android.Resource.Layout.SimpleListItem1, items);

			ListView list = FindViewById(Resource.Id.listView1) as ListView;

			list.Adapter = ListAdapter;
			list.SetSelection(5);
			list.Selected = true;
			list.RequestFocus();
		}
	}
}


