﻿using System;

using Android.App;
using Android.Content;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.OS;
using System.Threading;
using Android.Util;

namespace NullRefTest
{
    [Activity(Label = "NullRefTest", MainLauncher = true, Icon = "@drawable/icon", 
        ScreenOrientation = Android.Content.PM.ScreenOrientation.Portrait)]
    public class Activity1 : Activity
    {
        private Button aBtn;
        private CustomWebView view;
        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);

            // Set our view from the "main" layout resource
            SetContentView(Resource.Layout.Main);

            aBtn = FindViewById<Button>(Resource.Id.buttonA);
            view = FindViewById<CustomWebView>(Resource.Id.webview);

            view.setParent(this);
        }

        private int count;
        private readonly object nextTaskLock = new object();
        internal void doStuff()
        {
            new Thread(() =>
            {
                Log.Warn("TEST", "wait");
                lock (nextTaskLock)
                {
                    Log.Warn("TEST", "acquired");

                    ManualResetEvent ev = new ManualResetEvent(false);
                    RunOnUiThread(() => { updateUI(); ev.Set(); });
                    ev.WaitOne();

                    startCalc();

                    waitForCalcEnd();
                    simulateCalculations(2000);

                    RunOnUiThread(() =>
                    {
                        simulateCalculations(500);
                    });
                    ev.Dispose();
                    RunOnUiThread(() =>
                    {
                        aBtn.Text = (count++).ToString();
                    });
                    Log.Warn("TEST", "finished");
                }
            }).Start();
        }

        private void updateUI()
        {
            simulateCalculations(10);
        }

        private void simulateCalculations(int max)
        {
            double d = new Random().NextDouble();
            double d2 = Math.Pow(d, 2) + 1;
            for (int i = 0; i < max; i++)
            {
                d /= d2 * new Random().NextDouble();
            }
        }

        private ManualResetEvent foreEv = new ManualResetEvent(false);
        private void startCalc()
        {
            new Thread(() =>
                {
                    simulateCalculations(10000);
                    foreEv.Set();
                }).Start();
        }

        private void waitForCalcEnd()
        {
            foreEv.WaitOne();
        }
    }
}

