using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.Webkit;
using Android.Util;

namespace NullRefTest
{
    public class CustomWebView : WebView, Android.Views.GestureDetector.IOnGestureListener
    {
         public CustomWebView(Context ctx, global::Android.Util.IAttributeSet attrSet)
            : base(ctx, attrSet)
        {
        }

        public CustomWebView(IntPtr ptr)
            : base(ptr)
        {
        }

        private Activity1 parent;
        internal void setParent(Activity1 parent)
        {
            lock (parentLock)
            {
                gestureDetector = new GestureDetector(this);
                this.parent = parent;

                int width = parent.WindowManager.DefaultDisplay.Width;
                leftTapThreshold = width >> 2;
                rightTapThreshold = 3 * leftTapThreshold;
            }
        }

        #region IOnGestureListener Members
        private GestureDetector gestureDetector;
        private readonly object parentLock = new object();

        private const int SWIPE_MIN_DISTANCE = 120;
        private const int SWIPE_MAX_OFF_PATH = 250;
        private const int SWIPE_THRESHOLD_VELOCITY = 200;
        public bool OnFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY)
        {
            if (Math.Abs(e1.RawY - e2.RawY) > SWIPE_MAX_OFF_PATH)
                return false;

            //horizontal swipes
            lock (parentLock)
            {
                if (parent == null)
                    return false;
                if (Math.Abs(velocityX) > SWIPE_THRESHOLD_VELOCITY)
                {
                    if (e1.RawX - e2.RawX > SWIPE_MIN_DISTANCE)
                    {
                        parent.doStuff();
                        return true;
                    }
                    else if (e2.RawX - e1.RawX > SWIPE_MIN_DISTANCE)
                    {
                        parent.doStuff();
                        return true;
                    }
                }
            }
            return false;
        }

        public void OnLongPress(MotionEvent e)
        {
            lock (parentLock)
            {
                if (parent == null)
                    return;
                parent.RunOnUiThread(() => parent.OpenContextMenu(this));
            }
        }

        public bool OnScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY)
        {
            return true;
        }

        public void OnShowPress(MotionEvent e)
        {
        }

        private int leftTapThreshold;
        private int rightTapThreshold;
        public bool OnSingleTapUp(MotionEvent e)
        {
            lock (parentLock)
            {
                if (e.RawX < leftTapThreshold)
                    parent.doStuff();
                else if (e.RawX > rightTapThreshold)
                    parent.doStuff();
                else
                    parent.doStuff();
                return true;
            }
        }

        public bool OnDown(MotionEvent e)
        {
            return true;
        }

        public override bool OnTouchEvent(MotionEvent e)
        {
            lock (parentLock)
            {
                if (gestureDetector != null)
                    return gestureDetector.OnTouchEvent(e);
                else
                {
                    Log.Warn("TEST", "detector is null");
                    return false;
                }
            }
        }
        #endregion
    }
}