using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace AdapterTest
{
    public class CompanyAdapter : ArrayAdapter<string>, ISpinnerAdapter
    {
        public Context Context
        {
            get;
            set;
        }
        public CompanyAdapter(IntPtr ptr)
            : base(ptr)
        {
        }

        public override View GetView(int position, View convertView, ViewGroup parent)
        {
            TextView text;
            if (convertView == null || !(convertView is TextView))
            {
                text = new TextView(Context);
                text.SetBackgroundColor(Android.Graphics.Color.Azure);
            }
            else
            {
                text = convertView as TextView;
            }

            text.Text = this.GetItem(position).ToString();

            return text;
        }
    }
}