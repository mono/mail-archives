using System;

using Android.App;
using Android.Content;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.OS;

using Mono.Data.Sqlite;

namespace Scratch.Sqlite
{
	[Activity (Label = "Scratch.Sqlite", MainLauncher = true)]
	public class Activity1 : Activity
	{
		int count = 1;

		protected override void OnCreate (Bundle bundle)
		{
			base.OnCreate (bundle);

			// Set our view from the "main" layout resource
			SetContentView (Resource.Layout.Main);

			string dbPath = System.IO.Path.Combine(
					System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal),
					"testdb.db");
			bool exists = System.IO.File.Exists (dbPath);
			var cn = new SqliteConnection ("Data Source=" + dbPath);
			cn.Open ();
			if (exists) {
				WithCommand (cn, c => {
					c.CommandText = "DROP TABLE TESTTABLE";
					c.ExecuteNonQuery ();
				});
			}
			WithCommand(cn, c => {
				c.CommandText = "CREATE TABLE TESTTABLE (DATA blob not null)";
				c.ExecuteNonQuery ();
			});
			WithCommand (cn, c => {
				c.CommandText = "SELECT * FROM TESTTABLE";
				using (var r = c.ExecuteReader ()) {
					string typeName = r.GetDataTypeName(0);
					Console.WriteLine ("TESTTABLE.DATA type name: {0}", typeName);
				}
			});

			// Get our button from the layout resource,
			// and attach an event to it
			Button button = FindViewById<Button> (Resource.Id.myButton);
			
			button.Click += delegate {
				button.Text = string.Format ("{0} clicks!", count++);
			};
		}

		static void WithCommand (SqliteConnection connection, Action<SqliteCommand> action)
		{
			using (var command = connection.CreateCommand ()) {
				action (command);
			}
		}
	}
}


