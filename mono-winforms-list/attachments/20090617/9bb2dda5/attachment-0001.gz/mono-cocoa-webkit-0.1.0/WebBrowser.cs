using System;
using System.Runtime.InteropServices;

using Mono.WebBrowser;
using Mono.WebBrowser.DOM;

using Monobjc;
using Monobjc.Cocoa;
using Monobjc.WebKit;

namespace Mono.CocoaWebKit
{
	internal class WebBrowser : IWebBrowser
	{
		System.ComponentModel.EventHandlerList events;

		WebView webView;
		Navigation navigation;

		static bool initialized;

		#region Public ctors
		public WebBrowser ()
		{
			Initialize ();

			webView = new WebView ();
			navigation = new Navigation (webView);
		}
		#endregion // Public ctors

		#region Public Instance Methods
		public bool Load (IntPtr handle, int width, int height)
		{
			int error = HICocoaViewSetView (handle, webView.NativePointer);
			if (error != 0)
				return false;
			return true;
		}

		public void Shutdown ()
		{
		}

		public void FocusIn (FocusOption focus)
		{
		}

		public void FocusOut ()
		{
		}

		public void Activate ()
		{
		}

		public void Deactivate ()
		{
		}

		public void Resize (int width, int height)
		{
		}

		public void Render (byte[] data)
		{
		}

		public void Render (string html)
		{
		}

		public void Render (string html, string uri, string contentType)
		{
		}

		public void ExecuteScript (string script)
		{
		}
		#endregion // Public Instance Methods

		#region Public Instance Properties
		public bool Initialized {
			get {
				return initialized;
			}
		}

		public IWindow Window {
			get {
				return null;
			}
		}

		public IDocument Document {
			get {
				return null;
			}
		}

		public bool Offline {
			get {
				return false;
			}
			set {
				throw new NotImplementedException ();
			}
		}
		
		public INavigation Navigation {
			get {
				return navigation;
			}
		}
		#endregion // Public Instance Properties

		#region Events
		System.ComponentModel.EventHandlerList Events {
			get {
				if (events == null)
					events = new System.ComponentModel.EventHandlerList ();

				return events;
			}
		}

		internal static object KeyDownEvent = new object ();
		internal static object KeyPressEvent = new object ();
		internal static object KeyUpEvent = new object ();
		internal static object MouseClickEvent = new object ();
		internal static object MouseDoubleClickEvent = new object ();
		internal static object MouseDownEvent = new object ();
		internal static object MouseEnterEvent = new object ();
		internal static object MouseLeaveEvent = new object ();
		internal static object MouseMoveEvent = new object ();
		internal static object MouseUpEvent = new object ();
		internal static object FocusEvent = new object ();
		internal static object BlurEvent = new object ();
		internal static object CreateNewWindowEvent = new object ();
		internal static object AlertEvent = new object ();
			
		internal static object LoadStartedEvent = new object ();
		internal static object LoadCommitedEvent = new object ();
		internal static object ProgressChangedEvent = new object ();
		internal static object LoadFinishedEvent = new object ();	
		
		internal static object LoadEvent = new object ();
		internal static object UnloadEvent = new object ();
		internal static object StatusChangedEvent = new object ();
		internal static object SecurityChangedEvent = new object ();
		internal static object ProgressEvent = new object ();
		internal static object ContextMenuEvent = new object ();
		
		internal static object NavigationRequestedEvent = new object ();
		
		public event NodeEventHandler KeyDown
		{
			add { Events.AddHandler (KeyDownEvent, value); }
			remove { Events.RemoveHandler (KeyDownEvent, value); }
		}

		public event NodeEventHandler KeyPress
		{
			add { Events.AddHandler (KeyPressEvent, value); }
			remove { Events.RemoveHandler (KeyPressEvent, value); }
		}

		public event NodeEventHandler KeyUp
		{
			add { Events.AddHandler (KeyUpEvent, value); }
			remove { Events.RemoveHandler (KeyUpEvent, value); }
		}

		public event NodeEventHandler MouseClick
		{
			add { Events.AddHandler (MouseClickEvent, value); }
			remove { Events.RemoveHandler (MouseClickEvent, value); }
		}

		public event NodeEventHandler MouseDoubleClick
		{
			add { Events.AddHandler (MouseDoubleClickEvent, value); }
			remove { Events.RemoveHandler (MouseDoubleClickEvent, value); }
		}

		public event NodeEventHandler MouseDown
		{
			add { Events.AddHandler (MouseDownEvent, value); }
			remove { Events.RemoveHandler (MouseDownEvent, value); }
		}

		public event NodeEventHandler MouseEnter
		{
			add { Events.AddHandler (MouseEnterEvent, value); }
			remove { Events.RemoveHandler (MouseEnterEvent, value); }
		}

		public event NodeEventHandler MouseLeave
		{
			add { Events.AddHandler (MouseLeaveEvent, value); }
			remove { Events.RemoveHandler (MouseLeaveEvent, value); }
		}

		public event NodeEventHandler MouseMove
		{
			add { Events.AddHandler (MouseMoveEvent, value); }
			remove { Events.RemoveHandler (MouseMoveEvent, value); }
		}

		public event NodeEventHandler MouseUp
		{
			add { Events.AddHandler (MouseUpEvent, value); }
			remove { Events.RemoveHandler (MouseUpEvent, value); }
		}

		public event EventHandler Focus
		{
			add { Events.AddHandler (FocusEvent, value); }
			remove { Events.RemoveHandler (FocusEvent, value); }
		}

		public event EventHandler Blur
		{
			add { Events.AddHandler (BlurEvent, value); }
			remove { Events.RemoveHandler (BlurEvent, value); }
		}

		public event CreateNewWindowEventHandler CreateNewWindow
		{
			add { Events.AddHandler (CreateNewWindowEvent, value); }
			remove { Events.RemoveHandler (CreateNewWindowEvent, value); }
		}

		public event AlertEventHandler Alert
		{
			add { Events.AddHandler (AlertEvent, value); }
			remove { Events.RemoveHandler (AlertEvent, value); }
		}

		public event EventHandler Loaded
		{
			add { Events.AddHandler (LoadEvent, value); }
			remove { Events.RemoveHandler (LoadEvent, value); }
		}

		public event EventHandler Unloaded
		{
			add { Events.AddHandler (UnloadEvent, value); }
			remove { Events.RemoveHandler (UnloadEvent, value); }
		}

 		public event StatusChangedEventHandler StatusChanged
		{
			add { Events.AddHandler (StatusChangedEvent, value); }
			remove { Events.RemoveHandler (StatusChangedEvent, value); }
		}
		
 		public event SecurityChangedEventHandler SecurityChanged
		{
			add { Events.AddHandler (SecurityChangedEvent, value); }
			remove { Events.RemoveHandler (SecurityChangedEvent, value); }
		}

		public event LoadStartedEventHandler LoadStarted
		{
			add { Events.AddHandler (LoadStartedEvent, value); }
			remove { Events.RemoveHandler (LoadStartedEvent, value); }
		}
		
		public event LoadCommitedEventHandler LoadCommited
		{
			add { Events.AddHandler (LoadCommitedEvent, value); }
			remove { Events.RemoveHandler (LoadCommitedEvent, value); }
		}		
		
		public event ProgressChangedEventHandler ProgressChanged
		{
			add { Events.AddHandler (ProgressChangedEvent, value); }
			remove { Events.RemoveHandler (ProgressChangedEvent, value); }
		}
		
		public event LoadFinishedEventHandler LoadFinished
		{
			add { Events.AddHandler (LoadFinishedEvent, value); }
			remove { Events.RemoveHandler (LoadFinishedEvent, value); }
		}

		public event ContextMenuEventHandler ContextMenuShown
		{
			add { Events.AddHandler (ContextMenuEvent, value); }
			remove { Events.RemoveHandler (ContextMenuEvent, value); }
		}

		public event NavigationRequestedEventHandler NavigationRequested
		{
			add { Events.AddHandler (NavigationRequestedEvent, value); }
			remove { Events.RemoveHandler (NavigationRequestedEvent, value); }
		}
		#endregion // Events

		#region Private
		void Initialize ()
		{
			if (!initialized) {
				ObjectiveCRuntime.LoadFramework ("Cocoa");
				ObjectiveCRuntime.LoadFramework ("WebKit");
				ObjectiveCRuntime.Initialize ();

				NSThread.MakeMultiThreaded ();

				WebInitForCarbon ();

				initialized = true;
			}
		}

        [DllImport ("/System/Library/Frameworks/WebKit.framework/Versions/Current/WebKit")]
        extern static void WebInitForCarbon ();

        [DllImport ("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        extern static int HICocoaViewSetView (IntPtr hiView, IntPtr nsView);
		#endregion // Private
	}
}
