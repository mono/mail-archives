using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("mono-cocoa-webkit")]
[assembly: AssemblyDescription("Managed Wrapper for the Mac OS X Cocoa webkit engine")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyCopyright("")]
[assembly: AssemblyProduct("mono-cocoa-webkit")]
[assembly: AssemblyVersion("0.5.0.0")]
[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyKeyFile("./mono-cocoa-webkit.snk")]
