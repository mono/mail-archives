using System;

using Mono.WebBrowser;
using Mono.WebBrowser.DOM;

using Monobjc;
using Monobjc.Cocoa;
using Monobjc.WebKit;

namespace Mono.CocoaWebKit
{
	internal class Navigation : INavigation
	{
		WebView webView;

		internal Navigation (WebView view)
		{
			this.webView = view;
		}

		public bool CanGoBack { get { return false; } }

		public bool CanGoForward { get { return false; } }

		public bool Back ()
		{
			throw new NotImplementedException ();
		}

		public bool Forward ()
		{
			throw new NotImplementedException ();
		}

		public void Home ()
		{
			throw new NotImplementedException ();
		}

		public void Reload ()
		{
			throw new NotImplementedException ();
		}

		public void Reload (ReloadOption option)
		{
			throw new NotImplementedException ();
		}

		public void Stop ()
		{
			throw new NotImplementedException ();
		}

		public void Go (int index)
		{
			throw new NotImplementedException ();
		}

		public void Go (int index, bool relative)
		{
			throw new NotImplementedException ();
		}

		public void Go (string url)
		{
			webView.MainFrame.LoadRequest (NSURLRequest.RequestWithURL (NSURL.URLWithString (new NSString (url))));
		}

		public void Go (string url, LoadFlags flags)
		{
			throw new NotImplementedException ();
		}

		public int HistoryCount { get { return 0; } }
	}
}
