using System;
using System.Windows.Forms;
using System.Drawing;

namespace SimpleBrowser
{
    internal class MainForm : Form
    {
        private Panel _panel;
        private Button _button;
        private TextBox _textbox;
        private CheckBox _checkbox;
        private WebBrowser _browser;

        public MainForm()
        {
            _panel = new Panel();
            _button = new Button();
            _textbox = new TextBox();
            _checkbox = new CheckBox();
            _browser = new WebBrowser();

            this.SuspendLayout();

            _panel.Dock = DockStyle.Top;

            _button.Text = "Test";
            _button.Dock = DockStyle.Top;

            _textbox.Text = "Test";
            _textbox.Dock = DockStyle.Fill;

            _checkbox.Text = "Test";
            _checkbox.Dock = DockStyle.Bottom;

            _browser.Dock = DockStyle.Fill;
            
            _panel.Controls.Add(_textbox);
            _panel.Controls.Add(_button);
            _panel.Controls.Add(_checkbox);
            
            this.Text = "SimpleBrowser";
            this.Controls.Add(_browser);
            this.Controls.Add(_panel);
            
            this.ResumeLayout();
        }
        
        protected override void OnLoad (System.EventArgs e)
        {
            base.OnLoad (e);
            
            _browser.Navigate("http://www.google.com/");
        }
    };
    
    public class Program
    {
        public static void Main()
        {
            Application.Run(new MainForm());
        }
    }
}
