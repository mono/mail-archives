//Compile with : gmcs -r:System.Data -r:System.Drawing -r:System.Windows.Forms ./linenumbering.cs -o:./linenumbering.exe
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace Gutter
{
	public partial class frmMain : Form
	{

		public frmMain()
		{
			InitializeComponent();
		}
#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
			this.panel1 = new System.Windows.Forms.PictureBox();
			this.richTextBox1 = new System.Windows.Forms.RichTextBox();
			this.splitContainer1 = new System.Windows.Forms.SplitContainer();
			this.splitContainer1.Panel1.SuspendLayout();
			this.splitContainer1.Panel2.SuspendLayout();
			this.splitContainer1.SuspendLayout();
			this.SuspendLayout();
			// 
			// richTextBox1
			// 
			this.richTextBox1.AcceptsTab = true;
			this.richTextBox1.AutoWordSelection = true;
			//resources.ApplyResources(this.richTextBox1, "richTextBox1");
			this.richTextBox1.EnableAutoDragDrop = true;
			this.richTextBox1.HideSelection = false;
			this.richTextBox1.Name = "richTextBox1";
			this.richTextBox1.ShowSelectionMargin = true;
			this.richTextBox1.VScroll += new System.EventHandler(this.richTextBox1_VScroll);
			this.richTextBox1.Resize += new System.EventHandler(this.richTextBox1_Resize);
			this.richTextBox1.TextChanged += new System.EventHandler(this.richTextBox1_TextChanged);
			this.richTextBox1.Dock = System.Windows.Forms.DockStyle.Fill;
			// 
			// panel1
			// 
			//resources.ApplyResources(this.panel1, "panel1");
			this.panel1.Name = "panel1";
			this.panel1.TabStop = false;
			this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
			// 
			// splitContainer1
			// 
			//resources.ApplyResources(this.splitContainer1, "splitContainer1");
			this.splitContainer1.Name = "splitContainer1";
			this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;

			// 
			// splitContainer1.Panel1
			// 
			this.splitContainer1.Panel1.Controls.Add(this.panel1);
			// 
			// splitContainer1.Panel2
			// 
			this.splitContainer1.Panel2.Controls.Add(this.richTextBox1);
			// 
			// frmMain
			// 
			//resources.ApplyResources(this, "$this");
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.Controls.Add(this.splitContainer1);
			this.Name = "frmMain";
			((System.ComponentModel.ISupportInitialize)(this.panel1)).EndInit();
			this.splitContainer1.Panel1.ResumeLayout(false);
			this.splitContainer1.Panel2.ResumeLayout(false);
			this.splitContainer1.ResumeLayout(false);
			this.ResumeLayout(false);
			this.PerformLayout();


			this.richTextBox1.LoadFile(Application.StartupPath + Path.DirectorySeparatorChar + "Licence.rtf");
		}

		private System.Windows.Forms.RichTextBox richTextBox1;
		private System.Windows.Forms.SplitContainer splitContainer1;
		private System.Windows.Forms.PictureBox panel1;
#endregion

		int total_lines = 0;

		private void DrawRichTextBoxLineNumbers(Graphics g)
		{
			Single font_height;
			if (richTextBox1.Lines.Length < 3)
			{
				font_height = richTextBox1.Font.Height;
			} else
			{
				font_height = richTextBox1.GetPositionFromCharIndex(richTextBox1.GetFirstCharIndexFromLine(2)).Y - richTextBox1.GetPositionFromCharIndex(richTextBox1.GetFirstCharIndexFromLine(1)).Y;
			}
			Point pos = new Point (0,(int)(g.VisibleClipBounds.Y + font_height / 3));
			int first_index, first_line, first_line_y;
			first_index = richTextBox1.GetCharIndexFromPosition(pos);
			first_line = richTextBox1.GetLineFromCharIndex(first_index);
			first_line_y = richTextBox1.GetPositionFromCharIndex(first_index).Y;

			g.Clear(Control.DefaultBackColor);
			int i = first_line;
			int x = 0;
			Single y = 0;
			total_lines = richTextBox1.GetLineFromCharIndex(Int32.MaxValue) + 1;

			while (y < g.VisibleClipBounds.Y + g.VisibleClipBounds.Height)
			{
				y = first_line_y - 1 + font_height * (i - first_line - 1);
				x = panel1.Width - (int)g.MeasureString(i.ToString(), richTextBox1.Font).Width - 5;
				if (i <= total_lines)
				{
					g.DrawString((i).ToString(), richTextBox1.Font, Brushes.DarkBlue, x, (int)y);
				}
				i++;
			}
			//Console.WriteLine("Bad boy who make infinite loop with mono is here at line 130, just comment it and all is okay");
			this.splitContainer1.SplitterDistance = (i).ToString().Length;
		}

		private void panel1_Paint(object sender, PaintEventArgs e)
		{
			DrawRichTextBoxLineNumbers(e.Graphics);
		}

		private void richTextBox1_Resize(object sender, EventArgs e)
		{
			panel1.Invalidate();
		}

		private void richTextBox1_VScroll(object sender, EventArgs e)
		{
			panel1.Invalidate();
		}

		private void richTextBox1_TextChanged(object sender, EventArgs e)
		{
			if ((richTextBox1.GetLineFromCharIndex(Int32.MaxValue) + 1) != total_lines)
			{
				panel1.Invalidate();
			}
		}
	}

	static class Program
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main()
		{
			Application.EnableVisualStyles();
			Application.SetCompatibleTextRenderingDefault(false);
			Application.Run(new frmMain());
		}
	}

} 
