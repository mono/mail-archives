﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Runtime.Serialization;

namespace MonoCliptest
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public static bool Formats2Combobox(ref ComboBox _combo)
        {            
            _combo.Items.Clear();
            _combo.SelectedItem = 0;
            IDataObject clipdata = Clipboard.GetDataObject();
            if (clipdata == null)
            {
                Console.WriteLine("no clipdata");
                return false;
            }
            string[] myformats = clipdata.GetFormats();

            Console.WriteLine("Found {0} formats.", myformats.Length);

            for (int i = 0; i < myformats.Length; i++)
            {
                DataFormats.Format clipformat = DataFormats.GetFormat(myformats[i]);
                object thisclip = clipdata.GetData(myformats[i]);                
                if (thisclip == null)
                {
                    _combo.Items.Add("[{0}] null");
                    continue;
                }
                _combo.Items.Add(clipformat.Name);                
            }
            return true;
        }

        public static void ShowSelection(ref ComboBox _combo, ref PictureBox _picbox)
        {

            int item = _combo.SelectedIndex;
            IDataObject clipdata = Clipboard.GetDataObject();

            object data = clipdata.GetData(_combo.Text);

            try
            {
                
                _picbox.Image = (System.Drawing.Image)data;                
                return;               
                
            }
            catch (Exception ex) { Console.WriteLine(ex.Message); }

        }

        private void loadButton_Click(object sender, EventArgs e)
        {
            Image im = (Image)Bitmap.FromFile("test.jpg");            
            if (!(im is ISerializable)) Console.WriteLine("not serializable");
            Clipboard.SetDataObject(im);
            Formats2Combobox(ref comboBox);
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Image im = (Image)Bitmap.FromFile("test.jpg");
            if (!(im is ISerializable)) Console.WriteLine("not serializable");
            DataObject dataObj = new DataObject(DataFormats.Bitmap, im);                        
            dataObj.SetData( DataFormats.Bitmap , im);
            Clipboard.SetDataObject(dataObj, true);
            Formats2Combobox(ref comboBox);       
        }

        private void listClipformats_Click(object sender, EventArgs e)
        {
            Formats2Combobox(ref comboBox);
        }

        private void comboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            pictureBox.Image = null;
            ShowSelection(ref comboBox, ref pictureBox);
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            pictureBox.Image = null;
            Clipboard.Clear();            
            comboBox.Items.Clear();
            comboBox.Text = "";
        }

        
    }
}
