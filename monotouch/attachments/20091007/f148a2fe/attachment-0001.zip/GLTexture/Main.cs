using System;
using System.Drawing;
using MonoTouch.CoreAnimation;
using MonoTouch.CoreGraphics;
using MonoTouch.Foundation;
using MonoTouch.OpenGLES;
using MonoTouch.UIKit;
using MonoTouch.ObjCRuntime;
using OpenTK;
using OpenTK.Graphics;
using OpenTK.Graphics.ES11;
using OpenTK.Platform;
using OpenTK.Platform.iPhoneOS;

public class EAGLView : iPhoneOSGameView {

	uint texture;
	float rota;
	int depthBuffer;

	[Export ("layerClass")]
	static Class LayerClass()
	{
		return iPhoneOSGameView.GetLayerClass ();
	}

	[Export ("initWithCoder:")]
	public EAGLView (NSCoder coder)
		: base (coder)
	{
		LayerRetainsBacking = false;
		LayerColorFormat    = EAGLColorFormat.RGBA8;
		ContextRenderingApi = EAGLRenderingAPI.OpenGLES1;
	}

	protected override void ConfigureLayer(CAEAGLLayer eaglLayer)
	{
		eaglLayer.Opaque = true;
	}

	protected override void CreateFrameBuffer ()
	{
		base.CreateFrameBuffer ();

		// due to bug in iPhoneOSGameView.
		GL.Oes.BindFramebuffer(All.FramebufferOes, base.Framebuffer);
		GL.Disable(All.ScissorTest);

		GL.Oes.GenRenderbuffers (1, ref depthBuffer);
		GL.Oes.BindRenderbuffer (All.RenderbufferOes, depthBuffer);
		GL.Oes.RenderbufferStorage (All.RenderbufferOes, All.DepthComponent16Oes, Size.Width, Size.Height);
		GL.Oes.FramebufferRenderbuffer (All.FramebufferOes, All.DepthAttachmentOes, All.RenderbufferOes, depthBuffer);

		SetupView ();
		LoadTexture ();
	}

	protected override void DestroyFrameBuffer ()
	{
		GL.Oes.DeleteRenderbuffers (1, ref depthBuffer);
		depthBuffer = 0;
		base.DestroyFrameBuffer ();
	}

	static double DegreesToRadians (double angle)
	{
		return (angle * Math.PI) / 180.0;
	}

	void SetupView ()
	{
		float zNear = 0.1f, zFar = 1000.0f, fieldOfView = 60.0f;

		GL.Enable (All.DepthTest);
		GL.MatrixMode (All.Projection);
		float size = zNear * (float) Math.Tan (DegreesToRadians (fieldOfView) / 2.0);

		var rect = Bounds;
		GL.Frustum (-size, size, -size / (rect.Width / rect.Height),
				size / (rect.Width / rect.Height), zNear, zFar);
		GL.Viewport (0, 0, (int) rect.Width, (int) rect.Height);

		GL.ClearColor (0.0f, 0.0f, 0.0f, 1.0f);
	}

	unsafe void LoadTexture()
	{
		var textureImage = UIImage.FromFile ("checkerplate.png").CGImage;
		if (textureImage == null)
			throw new InvalidOperationException("Could not load checkerplate.png");
		var texWidth  = textureImage.Width;
		var texHeight = textureImage.Height;
		var textureData = new byte[texWidth * texHeight * 4];
		CGBitmapContext textureContext;
		fixed (byte* pTextureData = textureData) {
			textureContext = new CGBitmapContext((IntPtr) pTextureData,
					texWidth, texHeight,	8, texWidth * 4,
					textureImage.ColorSpace,	CGImageAlphaInfo.PremultipliedLast);
			textureContext.DrawImage (new RectangleF (0, 0, texWidth, texHeight),
					textureImage);
			textureContext.Dispose ();
		}
		GL.GenTextures(1, ref texture);
		GL.BindTexture(All.Texture2D, texture);
		GL.TexImage2D(All.Texture2D, 0, (int) All.Rgba,
				texWidth, texHeight, 0, All.Rgba,
				All.UnsignedByte, textureData);
		textureData = null;
		GL.TexParameter (All.Texture2D, All.TextureMinFilter, (float) All.Linear);
		GL.TexParameter (All.Texture2D, All.TextureMagFilter, (float) All.Linear);
		GL.Enable (All.Texture2D);
	}

	protected override void OnRenderFrame(FrameEventArgs e)
	{
		base.OnRenderFrame (e);

		float[] triangleVertices = {
			 0.0f,  1.0f, 0.0f,  // Triangle top center
			 1.0f, -1.0f, 0.0f,  // bottom right
			-1.0f, -1.0f, 0.0f,  // bottom left
		};
		float[] squareVertices = {
			-1.0f,  1.0f, 0.0f,  // Top left
			 1.0f,  1.0f, 0.0f,  // Top right
			 1.0f, -1.0f, 0.0f,  // Bottom right
			-1.0f, -1.0f, 0.0f,  // Bottom left
		};
		short[] squareTextureCoords = {
			0, 1,  // top left
			1, 1,  // top right
			1, 0,  // bottom right
			0, 0,  // bottom left
		};

		MakeCurrent();
		GL.Viewport (0, 0, Size.Width, Size.Height);
		GL.Clear ((uint) All.ColorBufferBit | (uint) All.DepthBufferBit);

		GL.MatrixMode (All.Modelview);

		rota += 0.5f;

		GL.LoadIdentity ();
		GL.Color4 (0.0f, 0.0f, 0.8f, 1.0f);
		GL.Translate (-1.5f, 0.0f, -6.0f);
		GL.Rotate (rota, 0.0f, 0.0f, 1.0f);
		GL.VertexPointer (3, All.Float, 0, triangleVertices);
		GL.EnableClientState (All.VertexArray);
		GL.DrawArrays (All.Triangles, 0, 3);

		GL.LoadIdentity ();
		GL.Color4 (1.0f, 1.0f, 1.0f, 1.0f);
		GL.Translate (1.5f, 0.0f, -6.0f);
		GL.Rotate (rota, 0.0f, 0.0f, 1.0f);
		GL.VertexPointer (3, All.Float, 0, squareVertices);
		GL.EnableClientState (All.VertexArray);

		GL.TexCoordPointer (2, All.Short, 0, squareTextureCoords);
		GL.EnableClientState (All.TextureCoordArray);

		GL.DrawArrays (All.TriangleFan, 0, 4);
		GL.DisableClientState (All.TextureCoordArray);

		SwapBuffers ();
	}
}

[Register]
public class OpenGLESSampleAppDelegate : UIApplicationDelegate {

	[Connect]
	public EAGLView glView {
		get {return (EAGLView) GetNativeField ("glView");}
		set {SetNativeField("glView", value);}
	}

	[Connect]
	public UIWindow window {
		get {return (UIWindow) GetNativeField ("window");}
		set {SetNativeField("window", value);}
	}

	public override bool FinishedLaunching (UIApplication app, NSDictionary options)
	{
		return true;
	}

	public override void OnResignActivation (UIApplication app)
	{
		glView.Stop();
		glView.Run(5.0);
	}

	public override void OnActivated (UIApplication app)
	{
		glView.Run(60.0);
	}

}

class Demo {
	static void Main (string [] args)
	{
		UIApplication.Main (args);
	}
}
