using System;
using System.Collections.Generic;
using System.Linq;
using MonoTouch.Foundation;
using MonoTouch.UIKit;

namespace Siemens3G
{
	public partial class Einstellungen : UIViewController
	{
		//loads the Einstellungen.xib file and connects it to this object
		public Einstellungen () : base ("Einstellungen", null)
		{
		}
		
		
	}
}
