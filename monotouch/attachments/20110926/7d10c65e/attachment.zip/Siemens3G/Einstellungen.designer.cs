// WARNING
//
// This file has been generated automatically by MonoDevelop to store outlets and
// actions made in the Xcode designer. If it is removed, they will be lost.
// Manual changes to this file may not be handled correctly.
//
using MonoTouch.Foundation;

namespace Siemens3G
{
	[Register ("Einstellungen")]
	partial class Einstellungen
	{
		[Action ("btn_about_event:")]
		partial void btn_about_event (MonoTouch.Foundation.NSObject sender);

		[Action ("btn_server_event:")]
		partial void btn_server_event (MonoTouch.Foundation.NSObject sender);

		[Action ("btn_login_event:")]
		partial void btn_login_event (MonoTouch.Foundation.NSObject sender);

		[Action ("btn_actual_mail_event:")]
		partial void btn_actual_mail_event (MonoTouch.Foundation.NSObject sender);

		[Action ("btn_history_mail_event:")]
		partial void btn_history_mail_event (MonoTouch.Foundation.NSObject sender);

		[Action ("btn_history_delete_event:")]
		partial void btn_history_delete_event (MonoTouch.Foundation.NSObject sender);
	}
}
