using System;
using System.Collections.Generic;
using System.Linq;
using MonoTouch.Foundation;
using MonoTouch.UIKit;

namespace pharaoapp
{
	public partial class Bedienteil : UIViewController
	{
		//loads the Bedienteil.xib file and connects it to this object
		public Bedienteil () : base ("Bedienteil", null)
		{
		}
		 string ipadresse;
        int port;
		Haupttabelle controller;
		  Controls.CAlertView loadingcontrol;
		 public Bedienteil(string _ipadresse, int _port,Haupttabelle _controller)
        {
            port = _port;
            ipadresse = _ipadresse;
			loadingcontrol = new Controls.CAlertView();
			loadingcontrol.AlertViewType=Controls.CAlertViewType.ActivityIndicator;
			loadingcontrol.Message="Laden...";
			controller=_controller;
			
		}
		public override void ViewWillAppear (bool animated)
		{
			System.Diagnostics.Debug.WriteLine("Laden");
			base.ViewWillAppear (animated);
		}
		
		public override void ViewDidLoad ()
		{
				btnnavbarhide.Hidden=true;
			System.Diagnostics.Debug.WriteLine("viewdidload()");
			this.Title="asdf";
			//controller.NavigationController.SetNavigationBarHidden(true,true);
			BedienteilConnector.getInstance( ipadresse + port).Displaychanged += delegate(object sender, DisplayEventArgs e)
            {
				backgroundimage.Image=UIImage.FromFile("mres/Images/ABI-BC22_03.jpg");
				ausgabe.BackgroundColor=UIColor.Clear;
				ausgabe.Opaque=false;
                ausgabe.LoadHtmlString("<html><body style='background-color:transparent'><center>" +
                e.Displayinhalt.ToString()+"</center></body></html>", new NSUrl());
				InvokeOnMainThread(delegate{
					hideloadingview();
				});
			};
			btn0.TouchDown+=delegate{
				generateloadingview();
				BedienteilConnector.getInstance( ipadresse + port).sendMessage("0");
			};
			btn1.TouchDown+=delegate{
				generateloadingview();
				BedienteilConnector.getInstance( ipadresse + port).sendMessage("1");
			};
			
			btnnavbar.TouchDown+=delegate{
				System.Diagnostics.Debug.WriteLine("show navbar");
				btnnavbarhide.Hidden=false;
				controller.NavigationController.SetNavigationBarHidden(false,true);
			};
			
			btnnavbarhide.TouchDown+=delegate{
				System.Diagnostics.Debug.WriteLine("hide navbar");
				btnnavbarhide.Hidden=true;
				controller.NavigationController.SetNavigationBarHidden(true,true);
			};
			btn2.TouchDown+=delegate{
				generateloadingview();
				BedienteilConnector.getInstance( ipadresse + port).sendMessage("2");
			};
			btn3.TouchDown+=delegate{
				generateloadingview();
				BedienteilConnector.getInstance( ipadresse + port).sendMessage("3");
			};
				btn4.TouchDown+=delegate{
				generateloadingview();
				BedienteilConnector.getInstance( ipadresse + port).sendMessage("4");
			};
			
				btn5.TouchDown+=delegate{
				generateloadingview();
				BedienteilConnector.getInstance( ipadresse + port).sendMessage("5");
			};
			
			btn6.TouchDown+=delegate{
				generateloadingview();
				BedienteilConnector.getInstance( ipadresse + port).sendMessage("6");
			};
			btn7.TouchDown+=delegate{
				generateloadingview();
				BedienteilConnector.getInstance( ipadresse + port).sendMessage("7");
			};
			btn8.TouchDown+=delegate{
				generateloadingview();
				BedienteilConnector.getInstance( ipadresse + port).sendMessage("8");
			};
			btn9.TouchDown+=delegate{
				generateloadingview();
				BedienteilConnector.getInstance( ipadresse + port).sendMessage("9");
			};
			btnF1.TouchDown+=delegate{
				generateloadingview();
				BedienteilConnector.getInstance( ipadresse + port).sendMessage("OFF");
			};
			btnF2.TouchDown+=delegate{
				generateloadingview();
				BedienteilConnector.getInstance( ipadresse + port).sendMessage("ON");
			};
			BedienteilConnector.getInstance( ipadresse + port).Connect( ipadresse, port);
			base.ViewDidLoad ();
		}
		void generateloadingview()
        {
            loadingcontrol.Show();
        }
		
        void hideloadingview()
        {
            loadingcontrol.Hide(false);
        }
		
	}
}
