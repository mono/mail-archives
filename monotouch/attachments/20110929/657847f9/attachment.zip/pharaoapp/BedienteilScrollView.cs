using System;
using System.Collections.Generic;
using System.Linq;
using MonoTouch.Foundation;
using MonoTouch.UIKit;

namespace pharaoapp
{
	public partial class BedienteilScrollView : UIViewController
	{
	Haupttabelle _controller;
	UITabBarController maintabbar;
			
		//loads the BedienteilScrollView.xib file and connects it to this object
		public BedienteilScrollView (Haupttabelle controller,UITabBarController _maintabbar) : base ("BedienteilScrollView", null)
		{
		_controller=controller;
		maintabbar=_maintabbar;
		}
		Bedienteil x;
		public override void ViewDidDisappear (bool animated)
		{
	//_controller.TabBarController.TabBar.Hidden=false;
	base.ViewDidDisappear (animated);
		}
		public override void ViewDidAppear (bool animated)
		{
			this.HidesBottomBarWhenPushed=true;
			_controller.NavigationController.SetNavigationBarHidden(true,true);
			//
			
			this.WantsFullScreenLayout=true;
			x.View.Frame= new System.Drawing.RectangleF(0,0,320,480);
			 scrview.ScrollEnabled = true;
            scrview.PagingEnabled = true;
			scrview.AddSubview(x.View);
			//_controller.WantsFullScreenLayout=true;
			//_controller.NavigationController.WantsFullScreenLayout=true;
			base.ViewDidAppear (animated);
		}
		public override void ViewDidLoad ()
		{
			
			this.TabBarController.TabBar.Hidden=true;
			System.Diagnostics.Debug.WriteLine("Bedienteilscrollview did load");
			this.WantsFullScreenLayout=true;
			_controller.NavigationController.NavigationBar.TintColor=UIColor.LightGray;
			_controller.NavigationController.NavigationBar.Translucent=true;
			_controller.NavigationController.NavigationBar.BarStyle=UIBarStyle.Black;
		    _controller.NavigationController.SetNavigationBarHidden(true,true);
			
			//maintabbar.TabBarController.TabBar.Hidden=true;
				scrview.ContentSize=new System.Drawing.SizeF(640,480);
			if(x==null){
			x = new  Bedienteil("192.168.22.213",2101,_controller);
			}
			
		
			base.ViewDidLoad ();
		}
	}
}
