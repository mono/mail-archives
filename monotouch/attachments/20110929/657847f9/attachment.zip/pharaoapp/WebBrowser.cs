using System;
using System.Collections.Generic;
using System.Linq;
using MonoTouch.Foundation;
using MonoTouch.UIKit;

namespace pharaoapp
{
	public partial class WebBrowser : UIViewController
	{
		//loads the WebBrowser.xib file and connects it to this object
		public WebBrowser () : base ("WebBrowser", null)
		{
			
		}
		public override void ViewDidAppear (bool animated)
		{
			browser1.LoadRequest(new NSUrlRequest(new NSUrl("http://www.pharao.mobi/smartphone/?NativeWebClient=true"),NSUrlRequestCachePolicy.UseProtocolCachePolicy,10000));
	browser1.LoadFinished+=delegate{
				this.Title=browser1.EvaluateJavascript("document.title");
			};
			base.ViewDidAppear (animated);
		}
		
		
	}
}
