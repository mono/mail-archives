// WARNING
//
// This file has been generated automatically by MonoDevelop to store outlets and
// actions made in the Xcode designer. If it is removed, they will be lost.
// Manual changes to this file may not be handled correctly.
//
using MonoTouch.Foundation;

namespace pharaoapp
{
	[Register ("Bedienteil")]
	partial class Bedienteil
	{
		[Outlet]
		MonoTouch.UIKit.UIButton btnnavbarhide { get; set; }

		[Outlet]
		MonoTouch.UIKit.UIButton btnnavbar { get; set; }

		[Outlet]
		MonoTouch.UIKit.UIButton btnF2 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UIButton btnF1 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UIButton btn0 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UIImageView backgroundimage { get; set; }

		[Outlet]
		MonoTouch.UIKit.UIWebView ausgabe { get; set; }

		[Outlet]
		MonoTouch.UIKit.UIButton btn2 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UIButton btn3 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UIButton btn4 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UIButton btn5 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UIButton btn6 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UIButton btn7 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UIButton btn8 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UIButton btn9 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UIButton btn1 { get; set; }
	}
}
