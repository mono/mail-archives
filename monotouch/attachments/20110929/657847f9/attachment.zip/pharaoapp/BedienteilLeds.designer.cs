// WARNING
//
// This file has been generated automatically by MonoDevelop to store outlets and
// actions made in the Xcode designer. If it is removed, they will be lost.
// Manual changes to this file may not be handled correctly.
//
using MonoTouch.Foundation;

namespace pharaoapp
{
	[Register ("BedienteilLeds")]
	partial class BedienteilLeds
	{
		[Outlet]
		MonoTouch.UIKit.UIImageView background { get; set; }

		[Outlet]
		MonoTouch.UIKit.UIImageView led1 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UIImageView led2 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UIImageView led3 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UIImageView led4 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UIImageView led5 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UIImageView led6 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UIImageView led7 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UIImageView led8 { get; set; }
	}
}
