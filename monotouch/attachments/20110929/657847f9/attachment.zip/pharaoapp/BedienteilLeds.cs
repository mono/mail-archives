using System;
using System.Collections.Generic;
using System.Linq;
using MonoTouch.Foundation;
using MonoTouch.UIKit;

namespace pharaoapp
{
	public partial class BedienteilLeds : UIViewController
	{
		//loads the BedienteilLeds.xib file and connects it to this object
		public BedienteilLeds () : base ("BedienteilLeds", null)
		{
			
		}
		
		
	}
}
