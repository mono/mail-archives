using System;
using System.Collections.Generic;
using System.Linq;
using MonoTouch.Foundation;
using MonoTouch.UIKit;

namespace pharaoapp
{
public class HaupttabelleDataSource : UITableViewDataSource
{
    IList<SectionData> _data;

    private class SectionData
    {
    	public string Title { get;set; }
    	public string CellId { get;set; }
    	public IList<string> Data { get;set; }

    	public SectionData(string cellId)
    	{
    		Title = "";
    		CellId = cellId;
    		Data = new List<string>();
    	}
    }

    public HaupttabelleDataSource()
    {
    	_data = new List<SectionData>();
    	SectionData section1 = new SectionData("Online Server");
    	section1.Data.Add("Server 1");
    	section1.Data.Add("Server 4");
    	section1.Data.Add("Server 6");
    	section1.Title = "Online Server";
    	_data.Add(section1);

    	SectionData section2 = new SectionData("Offline Server");
    	section2.Data.Add("Server 2");
    	section2.Data.Add("Server 5");
    	section2.Title = "Offline Server";
    	_data.Add(section2);
    }

    public override string TitleForHeader(UITableView tableView, int section)
    {
    	return _data[section].Title;
    }

    public override int RowsInSection(UITableView tableview, int section)
    {
    	return _data[section].Data.Count;
    }
	

    public override int NumberOfSections(UITableView tableView)
    {
    	return _data.Count;
    }
	


    public override UITableViewCell GetCell(UITableView tableView, NSIndexPath indexPath)
    {	SectionData sectionData = _data[indexPath.Section];
    	string cellId = sectionData.CellId;
    	string row = sectionData.Data[indexPath.Row];
		
		UITableViewCell x = new UITableViewCell(UITableViewCellStyle.Subtitle,"asdf");
		x.TextLabel.Text=row;
	//	x.EditingStyle=UITableViewCellEditingStyle.Insert;
    	return 	x;
    }
}

}

