using System;
using System.Collections.Generic;
using System.Linq;
using MonoTouch.Foundation;
using MonoTouch.UIKit;

namespace pharaoapp
{
	public class Haupttabelle : UITableViewController
{
			UIBarButtonItem rechterbutton;
		UITabBarController maintabbar;
    // Allow us to set the style of the TableView
    public Haupttabelle(UITableViewStyle style,UITabBarController _maintabbar) : base(style)
    {
			this.Title="Serverliste";
			maintabbar=_maintabbar;
    }
		public override void ViewDidAppear (bool animated)
		{
			/*
			this.NavigationController.NavigationBar.TintColor=UIColor.FromRGB(204,0,0);
			this.NavigationController.NavigationBar.Translucent=false;
			this.NavigationController.NavigationBar.BarStyle=UIBarStyle.Default;
			*/	
			
		//this.HidesBottomBarWhenPushed=false;
			base.ViewDidAppear (animated);
			
		}
    public override void ViewDidLoad ()
    {
		
			
			System.Diagnostics.Debug.WriteLine("Haupttabelle viewdidload");
    	TableView.DataSource = new HaupttabelleDataSource();
    	TableView.Delegate = new HaupttabelleDelegate(this,maintabbar);
		TableView.RowHeight=30;
//		TableView.BackgroundColor=UIColor.FromRGB(255,182,193);
    	base.ViewDidLoad ();
    }
}

}

