using System;
using System.Collections.Generic;
using System.Linq;
using MonoTouch.Foundation;
using System.Drawing;
using MonoTouch.UIKit;

namespace pharaoapp
{
    public class xxxBedienteil : UIViewController
    {
        public UIView view;
        public UIWebView ausgabe;
        string url;
        string ipadresse;
        int port;

        Controls.CAlertView loadingcontrol;
		
        public xxxBedienteil(string _ipadresse, int _port)
        {
            port = _port;
            ipadresse = _ipadresse;
			loadingcontrol = new Controls.CAlertView();			
            BedienteilConnector.getInstance( ipadresse + port).Connect( ipadresse, port);
            BedienteilConnector.getInstance( ipadresse + port).Displaychanged += delegate(object sender, DisplayEventArgs e)
            {
                ausgabe.LoadHtmlString("<html><body style='background-color:transparent'>" +
                e.Displayinhalt.ToString().Split(';')[0] + "</body></html>", new NSUrl());
				InvokeOnMainThread(delegate{
					hideloadingview();
				//Leds[0].Image=UIImage.FromFile("mres/Images/"+e.Displayinhalt.ToString().Split(';')[1]+"_led.png");
				//Leds[1].Image=UIImage.FromFile("mres/Images/"+e.Displayinhalt.ToString().Split(';')[2]+"_led.png");
				});
			};
			
            view = new UIView(new System.Drawing.RectangleF(320, 100, 320, 480));
			View.AddSubview(view);
			//oberflaeche.Add(loadingcontrol);
            loadingcontrol.Message = "Laden...";
            loadingcontrol.AlertViewType = Controls.CAlertViewType.ActivityIndicator;
          //  var imageRect = new RectangleF(-1, -1, 322, 481);
             var imageRect = new RectangleF(50,50, 322, 481);
          
			using (var myImage = new UIImageView(imageRect))
            {
                myImage.Image = UIImage.FromFile("mres/Images/BlackBedienteil.png");
                myImage.Opaque = true;
				myImage.BackgroundColor=UIColor.Red;
                view.AddSubview(myImage);
            }
            erstelleausgabe();
            #region LEDS
            generateled(0.9f, 2.1f, "green_led.png");
			generateled(4.3f, 2.1f, "green_led.png");
			generateled(7.4f, 2.1f, "green_led.png");
			generateled(10.5f, 2.1f, "green_led.png");
		
            #endregion

            #region Tasten hinzufügen
            //Klassische Ziffern Anfang

            view.Add(generatezifferntaste(-0.1f, 0, "10", "bstar_btn_transparent.png"));
            view.Add(generatezifferntaste(1, 0, "0", "b0_btn_transparent.png"));
            view.Add(generatezifferntaste(2, 0, "11", "benter_btn_transparent.png"));
            view.Add(generatezifferntaste(-0.1f, 1, "7", "b7_btn_transparent.png"));
            view.Add(generatezifferntaste(1, 1, "8", "b8_btn_transparent.png"));
            view.Add(generatezifferntaste(2, 1, "9", "b9_btn_transparent.png"));
            view.Add(generatezifferntaste(-0.1f, 2, "4", "b4_btn_transparent.png"));
            view.Add(generatezifferntaste(1, 2, "5", "b5_btn_transparent.png"));
            view.Add(generatezifferntaste(2, 2, "6", "b6_btn_transparent.png"));
            view.Add(generatezifferntaste(-0.1f, 3, "1", "b1_btn_transparent.png"));
            view.Add(generatezifferntaste(1, 3, "2", "b2_btn_transparent.png"));
            view.Add(generatezifferntaste(2, 3, "3", "b3_btn_transparent.png"));
            //Klassische Ziffern Ende	

            view.Add(generatezifferntaste(0.95f, 4.3f, "2", "bdown_btn_transparent.png"));
            view.Add(generatezifferntaste(0.95f, 5.3f, "2", "bup_btn_transparent.png"));
            view.Add(generatezifferntaste(0, 4.5f, "2", "bF1_btn_transparent.png"));
            view.Add(generatezifferntaste(2, 4.5f, "2", "bF2_btn_transparent.png"));
            view.Add(generatezifferntaste(2, 4.5f, "2", "bF2_btn_transparent.png"));

            //Tasten rechts
            view.Add(generatezifferntaste(2.6f, 0, "2", "bonoff_btn_transparent.png"));
            view.Add(generatezifferntaste(2.6f, 1, "2", "bsound_btn_transparent.png"));
            view.Add(generatezifferntaste(2.6f, 2, "2", "binfo_btn_transparent.png"));
            view.Add(generatezifferntaste(2.6f, 3, "2", "bkey_btn_transparent.png"));
            #endregion

        }
        public override bool ShouldAutorotateToInterfaceOrientation(UIInterfaceOrientation toInterfaceOrientation)
        {
            return true;
        }
		void generateloadingview()
        {
            loadingcontrol.Show();
        }
        void hideloadingview()
        {
            loadingcontrol.Hide(false);
        }

		
        public override void DidRotate(UIInterfaceOrientation fromInterfaceOrientation)
        {
            System.Diagnostics.Debug.WriteLine(fromInterfaceOrientation.ToString());
            base.DidRotate(fromInterfaceOrientation);
        }

        List<UIImageView> Leds = new List<UIImageView>();
        public bool generateled(float x, float y, string bildpfad)
        {
			
            int xoffset = 10;
            float faktor = 0.4f;
            int yoffset = 18;
            float height = UIImage.FromFile("mres/Images/" + bildpfad).Size.Height;
            float width = UIImage.FromFile("mres/Images/" + bildpfad).Size.Width;
			float xneu=x * (width * faktor + xoffset) + xoffset;
			float yneu= (y + 1) * (height * faktor + yoffset) + yoffset;
            UIImage bild = UIImage.FromFile("mres/Images/" + bildpfad).Scale(new SizeF((int)(width * faktor), (int)(height * faktor)));
			UIImageView temp = new UIImageView(new System.Drawing.RectangleF(x * (width * faktor + xoffset) + xoffset, (y + 1) * (height * faktor + yoffset) + yoffset, (int)(bild.Size.Width), (int)(bild.Size.Height)));
            temp.Image = bild;
            Leds.Add(temp);
            view.Add(Leds[Leds.Count - 1]);
			return true;
        }


        /// <summary>
        /// Generiert die klassischen Ziffern
        /// </summary>
        /// <param name="x">
        /// A <see cref="System.Int32"/>
        /// </param>
        /// <param name="y">
        /// A <see cref="System.Int32"/>
        /// </param>
        /// <param name="tastenziffer">
        /// A <see cref="System.String"/>
        /// </param>
        /// <param name="bildpfad">
        /// A <see cref="System.String"/>
        /// </param>
        /// <returns>
        /// A <see cref="UIButton"/>
        /// </returns>
        public UIButton generatezifferntaste(float x, float y, string tastenziffer, string bildpfad)
        {
            int xoffset = 10;
            float faktor = 1.0f;
            int yoffset = 13;
            float height = UIImage.FromFile("mres/Images/" + bildpfad).Size.Height;
            float width = UIImage.FromFile("mres/Images/" + bildpfad).Size.Width;
			UIImage bild = UIImage.FromFile("mres/Images/" + bildpfad);//.Scale(new SizeF((int)(width * faktor), (int)(height * faktor)));
			UIButton taste = UIButton.FromType(UIButtonType.Custom);
            taste.Frame = new System.Drawing.RectangleF(x * (width * faktor + xoffset) + xoffset+20, 480 - (y + 1) * (height * faktor + yoffset) - yoffset, (int)(bild.Size.Width), (int)(bild.Size.Height));
            taste.BackgroundColor = UIColor.Clear;
           // taste.SetImage(bild, UIControlState.Normal);
            taste.SetTitle("", UIControlState.Normal);
           // taste.TouchDown += delegate { generateloadingview(); ServerConnector.getInstance(  ipadresse + port).loadBC85Display(url, tastenziffer); };
            return taste;
        }
        public override void MotionEnded(UIEventSubtype motion, UIEvent evt)
        {
            System.Diagnostics.Debug.WriteLine("Motion detected");
            base.MotionEnded(motion, evt);
        }
        public void erstelleausgabe()
        {
            /*var imageRect = new RectangleF(10, 30, 320 - 2 * 10, 70);
            using (var myImage = new UIImageView(imageRect))
            {
                myImage.Image = UIImage.FromFile("mres/Images/display.png");
                myImage.Opaque = true;
                oberflaeche.AddSubview(myImage);
            }*/
            ausgabe = new UIWebView(new RectangleF(10, 30, 320 - 2 * 10, 70)
			                        );
            ausgabe.BackgroundColor = UIColor.Clear;
            view.Add(ausgabe);
            ausgabe.Opaque = false;
        }
    }
}

