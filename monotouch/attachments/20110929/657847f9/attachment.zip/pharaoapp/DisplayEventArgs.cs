using System;
namespace pharaoapp
{
	public class DisplayEventArgs:EventArgs
	{
		private String m_Message = "";
	    public String Displayinhalt
	    {
	        get { return m_Message; }
	 
	    }
		public DisplayEventArgs (string Message)
		{
						System.Diagnostics.Debug.WriteLine("Display Event");
		
		m_Message=Message;	
		}
	}
}

