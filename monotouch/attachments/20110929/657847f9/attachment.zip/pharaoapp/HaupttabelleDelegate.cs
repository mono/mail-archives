using System;
using System.Collections.Generic;
using System.Linq;
using MonoTouch.Foundation;
using MonoTouch.UIKit;

namespace pharaoapp
{
	public class HaupttabelleDelegate : UITableViewDelegate
{   	
    private Haupttabelle _controller;
	private UITabBarController maintabbar;
    public HaupttabelleDelegate(Haupttabelle controller,UITabBarController _maintabbar)
    {
    	_controller = controller;	
		maintabbar=_maintabbar;
    }
BedienteilScrollView bedienteilscrollview1;
    public override void RowSelected (UITableView tableView, NSIndexPath indexPath)
    {
		//Detailtabelle x = new Detailtabelle(UITableViewStyle.Plain);
	 //  _controller.NavigationController.PushViewController(x,true);
		//WebBrowser x = new WebBrowser();
		//	Bedienteil x = new Bedienteil("192.168.22.213",2101);
		if(bedienteilscrollview1==null)
			bedienteilscrollview1 = new BedienteilScrollView(_controller,maintabbar);
		_controller.NavigationController.PushViewController(bedienteilscrollview1,true);
		//2101, "192.168.22.213"
		System.Diagnostics.Debug.WriteLine("Zeile:"+indexPath.Row.ToString());
    }
}

}

