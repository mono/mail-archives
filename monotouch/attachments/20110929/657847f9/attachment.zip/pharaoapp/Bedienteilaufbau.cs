using System;

namespace pharaoapp
{
	public class Bedienteilaufbau
	{
		public string bezeichnung;
		public  BedienteilConnector Singleton;
		public Bedienteilaufbau()
		{
	
		}
	}
}

