﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Net.Sockets;
using System.Net;
using System.Runtime.InteropServices;
using System.Threading;


namespace pharaoapp
{
    public delegate void BCxxEventHandler(object sender, BCxxEventArgs e);

    class DigiSocket
    {
        public event BCxxEventHandler TextRawReceived;

        //public event EventHandler LayoutUpdatedata;

        private System.Timers.Timer timer1 = new System.Timers.Timer();

        private Socket socketClient;
        private int socketSize = 1024;
        private bool wait4connect;
        private bool wait4version;
        private bool wait4info;
        private bool wait4mctype;
        private bool wait4bctype;
        private bool wait4summer;
        private bool wait4displaytext;
        private bool wait4leds;
        private Byte recError;

        private int responsetimeout;
        private int timeoutCnt;

        private int seqNr = 0;

        public byte[] socketData = new byte[1024];
        public int socketDataLen = 0;

        public Byte[] Version = new Byte[4];
        public Byte[] Info = new Byte[1000];
        public Byte[] MCType = new Byte[1];
        public Byte[] BCType = new Byte[1];
        public Byte[] Summer = new Byte[1];
        public Byte[] DisplayText = new Byte[100];
        public Byte[] LEDs = new Byte[30];


        public DigiSocket()
        {
            this.wait4connect = false;
            this.wait4version = false;
            this.wait4info = false;
            this.wait4mctype = false;
            this.wait4bctype = false;
            this.wait4summer = false;
            this.wait4displaytext = false;
            this.wait4leds = false;

            this.recError = 0;

            this.responsetimeout = 3000;

            this.timer1.Elapsed += new System.Timers.ElapsedEventHandler(timer1_Tick);

            this.timer1.Stop();
            this.timer1.Enabled = true;
            this.timer1.AutoReset = true;
            this.timer1.Interval = 200;
            this.timer1.Start();
        }

        public int getversion(bool _wait)
        {
            this.wait4version = true;
            this.timeoutCnt = 0;
            this.sendMessage(requestId.StartSession);

            while (_wait)
            {
                if (this.wait4version == false) return 0;
                if (this.timeoutCnt >= this.responsetimeout) return -1;
            }
            return 0;
        }


        public int getinfo(bool _wait)
        {
            this.wait4info = true;
            this.timeoutCnt = 0;
            this.sendMessage(requestId.GetInfo);

            while (_wait)
            {
                if (this.wait4info == false) return 0;
                if (this.timeoutCnt >= this.responsetimeout) return -1;
            }
            return 0;
        }


        public int getmctype(bool _wait)
        {
            this.wait4mctype = true;
            this.timeoutCnt = 0;
            this.sendMessage(requestId.StartSession);

            while (_wait)
            {
                if (this.wait4mctype == false) return 0;
                if (this.timeoutCnt >= this.responsetimeout) return -1;
            }
            return 0;
        }


        public int getbctype(bool _wait)
        {
            this.wait4bctype = true;
            this.timeoutCnt = 0;
            this.sendMessage(requestId.StartSession);

            while (_wait)
            {
                if (this.wait4bctype == false) return 0;
                if (this.timeoutCnt >= this.responsetimeout) return -1;
            }
            return 0;
        }


        public int getsummer(bool _wait)
        {
            this.wait4summer = true;
            this.timeoutCnt = 0;
            this.sendMessage(requestId.GetData);

            while (_wait)
            {
                if (this.wait4summer == false) return 0;
                if (this.timeoutCnt >= this.responsetimeout) return -1;
            }
            return 0;
        }


        public int getdisplaytext(bool _wait)
        {
            this.wait4displaytext = true;
            this.timeoutCnt = 0;
            this.sendMessage(requestId.GetData);

            while (_wait)
            {
                if (this.wait4displaytext == false) return 0;
                if (this.timeoutCnt >= this.responsetimeout) return -1;
            }
            return 0;
        }


        public int getvLEDs(bool _wait)
        {
            this.wait4leds = true;
            this.timeoutCnt = 0;
            this.sendMessage(requestId.GetData);

            while (_wait)
            {
                if (this.wait4leds == false) return 0;
                if (this.timeoutCnt >= this.responsetimeout) return -1;
            }
            return 0;
        }

        public void socketConnect(int port, string ip)
        {
            this.wait4connect = true;

            this.socketClient = new Socket(AddressFamily.InterNetwork,
                                    SocketType.Stream, ProtocolType.Tcp);
            IPEndPoint iep = new IPEndPoint(IPAddress.Parse(ip), port);
            this.socketClient.BeginConnect(iep, new AsyncCallback(Connected), this.socketClient);
        }

        void socketSend(string data)
        {
            byte[] message = Encoding.ASCII.GetBytes(data);
            socketClient.BeginSend(message, 0, message.Length, SocketFlags.None,
                            new AsyncCallback(SendData), socketClient);
        }

        public void socketDisconnect(object obj, EventArgs ea)
        {
            socketClient.Close();
        }

        private void Connected(IAsyncResult iar)
        {
            this.socketClient = (Socket)iar.AsyncState;
            try
            {
                this.socketClient.EndConnect(iar);
                this.socketClient.BeginReceive(this.socketData, 0, this.socketSize, SocketFlags.None,
                                new AsyncCallback(ReceiveData), this.socketClient);

                this.wait4connect = false;
            }
            catch (SocketException)
            {
                // "Error connecting";
            }
        }

        private void ReceiveData(IAsyncResult iar)
        {
            Socket remote = (Socket)iar.AsyncState;
            int recv = remote.EndReceive(iar);
            this.socketDataLen = recv;

            this.readPakete(this.socketData, recv);

            remote.BeginReceive(this.socketData, 0, this.socketSize, SocketFlags.None,
                            new AsyncCallback(ReceiveData), remote);
        }

        private void SendData(IAsyncResult iar)
        {
            Socket remote = (Socket)iar.AsyncState;
            int sent = remote.EndSend(iar);
            remote.BeginReceive(this.socketData, 0, this.socketSize, SocketFlags.None,
                            new AsyncCallback(ReceiveData), remote);
        }

        public bool Wait4Connect
        {
            get { return this.wait4connect; }
        }

        public bool Wait4Version
        {
            get { return this.wait4version; }
            set { this.wait4version = value; }
        }

        public bool Wait4Info
        {
            get { return this.wait4info; }
            set { this.wait4info = value; }
        }

        public bool Wait4MCType
        {
            get { return this.wait4mctype; }
            set { this.wait4mctype = value; }
        }

        public bool Wait4BCType
        {
            get { return this.wait4bctype; }
            set { this.wait4bctype = value; }
        }

        public bool Wait4Summer
        {
            get { return this.wait4summer; }
            set { this.wait4summer = value; }
        }

        public bool Wait4DisplayText
        {
            get { return this.wait4displaytext; }
            set { this.wait4displaytext = value; }
        }

        public bool Wait4LEDs
        {
            get { return this.wait4leds; }
            set { this.wait4leds = value; }
        }

        public int ResponseTimeout
        {
            get { return this.responsetimeout; }
            set { this.responsetimeout = value; }
        }

        public byte ReceiveError
        {
            get { return this.recError; }
        }


        public enum tag
        {
            Version = 1,
            Info = 2,
            MCType = 3,
            BCType = 4,
            Summer = 5,
            Displaytext = 6,
            Key = 7,
            LED = 8,
            LCDLED = 9
        }


        private void readPakete(byte[] data, int len)
        {

            this.recError = data[9];

            if (this.get_rx_buf_paket((byte)tag.Version, ref this.Version, this.Version.Length, this.socketData) != -1)
            {
                this.wait4version = false;
            }

            if (this.get_rx_buf_paket((byte)tag.Info, ref this.Info, this.Info.Length, this.socketData) != -1)
            {
                this.wait4info = false;
            }

            if (this.get_rx_buf_paket((byte)tag.MCType, ref this.MCType, this.MCType.Length, this.socketData) != -1)
            {
                this.wait4mctype = false;
            }

            if (this.get_rx_buf_paket((byte)tag.BCType, ref this.BCType, this.BCType.Length, this.socketData) != -1)
            {
                this.wait4bctype = false;
            }

            if (this.get_rx_buf_paket((byte)tag.Summer, ref this.Summer, this.Summer.Length, this.socketData) != -1)
            {
                this.wait4summer = false;
            }

            if (this.get_rx_buf_paket((byte)tag.Displaytext, ref this.DisplayText, this.DisplayText.Length, this.socketData) != -1)
            {
                this.wait4displaytext = false;
            }

            if (this.get_rx_buf_paket((byte)tag.LED, ref this.LEDs, this.LEDs.Length, this.socketData) != -1)
            {
                this.wait4leds = false;
            }

            BCxxEventHandler textRawReceived = this.TextRawReceived;
            if (textRawReceived != null)
            {
                textRawReceived(this, new BCxxEventArgs(this.DisplayText, this.LEDs, this.Summer[0], this.ReceiveError));
            }
        }
        public enum requestId
        {
            StartSession = 1,
            EndSession = 2,
            Ping = 3,
            GetInfo = 0x10,
            KeyDown = 0x21,
            KeyUp = 0x22,
            KeyPressed = 0x23,
            DataChanged = 0x24,
            GetData = 0x25
        }

        public void sendMessage(requestId requestType)
        {
            this.sendMessage(requestType, 0);
        }

        public void sendMessage(requestId requestType, byte taste)
        {
            byte[] chrData = new byte[20];
            int len = 16;

            // ProtocolID
            chrData[0] = (byte)'\x42';
            chrData[1] = (byte)'\x43';
            chrData[2] = (byte)'\x6d';
            chrData[3] = (byte)'\x50';

            // ProtocolVersion
            chrData[4] = (byte)'\x01';

            // MessageType
            chrData[5] = (byte)'\x01';

            // RequestID
            chrData[6] = (byte)requestType;

            // SequenceNumber
            chrData[7] = (byte)(seqNr / 0x100);
            chrData[8] = (byte)(seqNr % 0x100);

            // ResponseCode
            chrData[9] = (byte)'\x00';

            // Sizeofbody
            chrData[10] = (byte)'\x00';
            chrData[11] = (byte)'\x00';

            // Reserved
            chrData[12] = (byte)'\x00';
            chrData[13] = (byte)'\x00';
            chrData[14] = (byte)'\x00';
            chrData[15] = (byte)'\x00';

            if (requestType == requestId.KeyDown ||
                 requestType == requestId.KeyPressed ||
                 requestType == requestId.KeyUp)
            {
                chrData[16] = (byte)'\x07';  //Key Tag
                chrData[17] = (byte)'\x00';
                chrData[18] = (byte)'\x01';
                chrData[19] = (byte)taste;   // Taste 
                // Sizeofbody
                chrData[10] = (byte)'\x00';
                chrData[11] = (byte)'\x04';
                len = 20;
            }

            this.socketClient.BeginSend(chrData, 0, len, SocketFlags.None,
                new AsyncCallback(this.SendData), this.socketClient);

        }
    
        // kopiert Daten des angeforderten Tag von rxBuf nach dest
        // -1 wenn Tag nicht im rx_buf enthalten ist
        int get_rx_buf_paket(byte tag, ref byte[] dest, int max_len, byte[] rxBuf)
        {
            uint size_of_body = chr2uint(rxBuf[10], rxBuf[11]);
            uint bodyIx;
            uint body_ix = 0;
            uint body_len = 0;

            bodyIx = 16;

            while (body_ix < size_of_body)
            {
                if (rxBuf[bodyIx] == tag)
                {
                    body_len = chr2uint(rxBuf[bodyIx + 1], rxBuf[bodyIx + 2]);
                    bodyIx = bodyIx + 3; // 1Byte Tag, 2Byte Length - body zeigt auf Value
                    int ix1 = 0;
                    for (; body_len > 0 && max_len > 0; body_len--, max_len--, ix1++)
                    {
                        dest[ix1] = rxBuf[bodyIx + ix1];
                    }
                    return ix1;
                }
                else
                {
                    body_len = chr2uint(rxBuf[bodyIx + 1], rxBuf[bodyIx + 2]);
                    body_ix = body_ix + body_len + 3;
                    bodyIx = bodyIx + body_len + 3;
                }
            }
            return -1;
        }

        uint chr2uint(byte var1, byte var2)
        {
            uint nr;
            nr = (uint)(var1 * 0x100);
            nr = nr + (uint)var2;
            return nr;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            this.timeoutCnt += (int)this.timer1.Interval;
        }
    }

    public class BCxxEventArgs : System.EventArgs
    {
        private readonly byte[] display;
        private readonly byte[] LED;
        private readonly byte buzzer;
        private readonly byte recerror;
        public BCxxEventArgs(byte[] display, byte[] LEDs, byte summer, byte error)
            : base()
        {
            this.display = display;
            this.LED = LEDs;
            this.buzzer = summer;
            this.recerror = error;
        }
        public byte[] Display
        { get { return this.display; } }
        public byte[] LEDs
        { get { return this.LED; } }
        public byte summer
        { get { return this.buzzer; } }
        public byte error
        { get { return this.recerror; } }
    }

}
