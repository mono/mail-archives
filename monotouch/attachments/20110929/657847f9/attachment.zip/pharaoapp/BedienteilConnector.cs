using System;
using System.Collections.Generic;
using System.Linq;
using MonoTouch.Foundation;
using MonoTouch.UIKit;
using System.Net.Sockets;

namespace pharaoapp
{
	public class BedienteilConnector
	{
		static List<Bedienteilaufbau> _connectors;
		DigiSocket digiSocket;
		
		public static BedienteilConnector getInstance(string bezeichnung)
	   {
			if(_connectors==null)
				_connectors=new List<Bedienteilaufbau>();
			for(int i=0;i<_connectors.Count;i++){
			if(_connectors[i].bezeichnung==bezeichnung){
					System.Diagnostics.Debug.WriteLine("Bezeichnung");
					return _connectors[i].Singleton;
				}
			}
			
	       	BedienteilConnector BC85Singleton = new BedienteilConnector();
			Bedienteilaufbau temp= new Bedienteilaufbau();
			temp.bezeichnung=bezeichnung;
			temp.Singleton=BC85Singleton;
	        _connectors.Add(temp);
	         return _connectors[_connectors.Count-1].Singleton;
	     
	   }
		bool connected=false;
		public void Connect(string ipadresse,int port){
			if(connected==false){
		    digiSocket = new DigiSocket();
            digiSocket.TextRawReceived += new BCxxEventHandler(dSocket_LayoutUpdatedata);
						System.Diagnostics.Debug.WriteLine("Verbinde zu Socket");
            digiSocket.socketConnect(port, ipadresse);
						System.Diagnostics.Debug.WriteLine("Socket verbunden gestartet");
            while (this.digiSocket.Wait4Connect == true) ;
			connected=true;
									System.Diagnostics.Debug.WriteLine("Connected");
            int cnt = 0;
            for (; cnt < 5; cnt++)
                if (this.digiSocket.getbctype(true) != -1) break;

            if (this.digiSocket.BCType[0] == 1)
            {
                this.InitBC22();
            }
            if (this.digiSocket.BCType[0] == 2)
            {
                this.InitBC85();
            }
            digiSocket.getinfo(true);
			}
		}
		
		public BedienteilConnector ()
		{
			
		}
			
		
		public event EventHandler<DisplayEventArgs> Displaychanged;
		public void dSocket_LayoutUpdatedata(object sender, BCxxEventArgs tArgs)
        {
                string returnStr = string.Empty;
                try
                {
                    string rData = string.Empty;
                    string receiveData = string.Empty;

                    for (int ix = 0; ix < this.digiSocket.socketDataLen; ix++)
                    {
                        if ((int)this.digiSocket.socketData[ix] >= 0x20 && (int)this.digiSocket.socketData[ix] < 0x80)
                        {
                            receiveData = receiveData + (char)this.digiSocket.socketData[ix];
                        }
                        rData = rData + this.digiSocket.socketData[ix].ToString("x") + "   ";
                        if (ix == 3) rData = rData + "\n";
                        if (ix == 4) rData = rData + "\n";
                        if (ix == 5) rData = rData + "\n";
                        if (ix == 6) rData = rData + "\n";
                        if (ix == 8) rData = rData + "\n";
                        if (ix == 9) rData = rData + "\n";
                        if (ix == 11) rData = rData + "\n";
                        if (ix == 15) rData = rData + "\n";
                    }

                    seqNr = (int)this.digiSocket.socketData[7] * 0x100 + this.digiSocket.socketData[8];
                    seqNr++;

                    returnStr = "Received:\n\n" + rData;
                    returnStr = returnStr + "\n\nReceived: " + receiveData;

                    this.updateLayout();

                }
                catch (ArgumentNullException e)
                {
                    returnStr = returnStr + "\r\nArgumentNullException: {" + e + "}";

                }
                catch (SocketException e)
                {
                    returnStr = returnStr + "\r\nSocketException: {" + e + "}";
                }
		
       //       System.Diagnostics.Debug.WriteLine("strings:"+returnStr);
        }
        void updateLayout()
        {
            System.Diagnostics.Debug.WriteLine("updatelayout()");
            if (this.BCType == "BC22")
            {
                if (this.digiSocket.ReceiveError == 0)
                {
					string datengesamt="";
                    int ixDis = 0;
                    string dis = string.Empty;
                    for (; ixDis < 16; ixDis++)
                    {
                        dis = dis + getSonderzeichen(this.digiSocket.DisplayText[ixDis]);
                    }
                    System.Diagnostics.Debug.WriteLine("BC22 Zeile1:" + dis);
					datengesamt+=dis;
                    dis = string.Empty;
                    for (; ixDis < 32; ixDis++)
                    {
                        dis = dis + getSonderzeichen(this.digiSocket.DisplayText[ixDis]);
                    }
                    System.Diagnostics.Debug.WriteLine("BC22 Zeile2:" + dis);
					datengesamt+="<br>"+dis;
					System.Diagnostics.Debug.WriteLine("BC22 daten"+datengesamt);
					if (Displaychanged != null) {	
					System.Diagnostics.Debug.WriteLine("BC22 Eventreceiver attached");
					Displaychanged(this, new DisplayEventArgs(datengesamt));
					}
                }
                else
                {
                    System.Diagnostics.Debug.WriteLine("BC22 Zeile1: leer");
                    System.Diagnostics.Debug.WriteLine("BC22 Zeile2: leer");
                }
            }
            else
            {
                System.Diagnostics.Debug.WriteLine("nicht typ 22");
            }

            if (this.BCType == "BC85")
            {
                if (this.digiSocket.ReceiveError == 0)
                {
                    int ixDis = 0;
					string datengesamt="";
                    string dis = string.Empty;
                    for (; ixDis < 20; ixDis++)
                    {
                        dis = dis + getSonderzeichen(this.digiSocket.DisplayText[ixDis]);
                    }
                    System.Diagnostics.Debug.WriteLine("Zeile1"+dis);
					datengesamt+=dis;
                    dis = string.Empty;
                    for (; ixDis < 40; ixDis++)
                    {
                        dis = dis + getSonderzeichen(this.digiSocket.DisplayText[ixDis]);
                    }
                    System.Diagnostics.Debug.WriteLine("Zeile2" + dis);
					datengesamt+="<br>"+dis;
                    dis = string.Empty;
                    for (; ixDis < 60; ixDis++)
                    {
                        dis = dis + getSonderzeichen(this.digiSocket.DisplayText[ixDis]);
                    }
                    System.Diagnostics.Debug.WriteLine("Zeile3" + dis);
                 datengesamt+="<br>"+dis;
                    dis = string.Empty;
                    for (; ixDis < 80; ixDis++)
                    {
                        dis = dis + getSonderzeichen(this.digiSocket.DisplayText[ixDis]);
                    }
                    System.Diagnostics.Debug.WriteLine("Zeile4" + dis);
                 datengesamt+="<br>"+dis;
					System.Diagnostics.Debug.WriteLine("BC85 Event");
				if (Displaychanged != null) {
											System.Diagnostics.Debug.WriteLine("BC85 Eventreceiver attached");
					Displaychanged(this, new DisplayEventArgs(datengesamt));
					}
                }
                else
                {
                    System.Diagnostics.Debug.WriteLine("Zeile1 leer" );
                    System.Diagnostics.Debug.WriteLine("Zeile2 leer");
                    System.Diagnostics.Debug.WriteLine("Zeile3 leer");
                    System.Diagnostics.Debug.WriteLine("Zeile4 leer");
                }
            }
            else
            {
                System.Diagnostics.Debug.WriteLine("nicht typ bc85");
            }


        }
		
        static Dictionary<string, byte> BCTaste = new Dictionary<string, byte>( 12 );
		public void sendMessage(string Taste){
		System.Diagnostics.Debug.WriteLine("Taste:"+Taste+" entspricht Key:"+BCTaste[Taste]);
		 this.digiSocket.sendMessage(DigiSocket.requestId.KeyDown,BCTaste[Taste]);
		}
		
        private void InitBC22()
        {
			BCTaste.Add( "1", 0x01 );
            BCTaste.Add( "2", 0x02 );
            BCTaste.Add( "3", 0x03 );
            BCTaste.Add( "4", 0x04 );
            BCTaste.Add( "5", 0x05 );
            BCTaste.Add( "6", 0x06 );
            BCTaste.Add( "7", 0x07 );
            BCTaste.Add( "8", 0x08 );
            BCTaste.Add( "9", 0x09 );
            BCTaste.Add( "A", 0x0A );
            BCTaste.Add( "B", 0x0B );
            BCTaste.Add( "C", 0x0C );
            BCTaste.Add( "D", 0x0D );
            BCTaste.Add( "#\r\nEnter", 0x0E );
            BCTaste.Add( "v", 0x0F );
            BCTaste.Add( "OFF", 0x10 );
            BCTaste.Add( "0", 0x12 );
            BCTaste.Add( "ON", 0x20 );
            BCTaste.Add( "^", 0x24 );
            BCTaste.Add( "*", 0x25 );
            this.BCType = "BC22";
     //       Point p = new Point(250, 100);
            this.digiSocket.sendMessage(pharaoapp.DigiSocket.requestId.GetData); // Anzeige aktualisieren

        }
        private void InitBC85()
        {
			BCTaste.Add( "1", 0x11 );
            BCTaste.Add( "2", 0x12 );
            BCTaste.Add( "3", 0x13 );
            BCTaste.Add( "4", 0x14 );
            BCTaste.Add( "5", 0x15 );
            BCTaste.Add( "6", 0x16 );
            BCTaste.Add( "7", 0x17 );
            BCTaste.Add( "8", 0x18 );
            BCTaste.Add( "9", 0x19 );
            BCTaste.Add( "I/O", 0x24 );   // I/O
            BCTaste.Add( "B", 0x27 );     // Schlüsselöcher
            BCTaste.Add( "C", 0x25 );     // i
            BCTaste.Add( "D", 0x26 );     // Abstellen
            BCTaste.Add( "#\r\nEnter", 0x21 );
            BCTaste.Add( "v", 0x23 );
            BCTaste.Add( "F2", 0x1c );    // F2
            BCTaste.Add( "0", 0x1a );
            BCTaste.Add( "F1", 0x1b );    // F1
            BCTaste.Add( "^", 0x22 );
            BCTaste.Add( "*", 0x20 );
            this.BCType = "BC85";
            this.digiSocket.sendMessage(pharaoapp.DigiSocket.requestId.GetData); // Anzeige aktualisieren
	     }
	    static Dictionary<char, char> Sonderzeichen = new Dictionary<char, char>(10);
        private string BCType = string.Empty;
        char getSonderzeichen(Byte b)
        {
            char c = ' ';
            if (Sonderzeichen.ContainsKey((char)(b & 0x7f)) == true)
            {
                c = Sonderzeichen[(char)(b & 0x7f)];
            }
            else
            {
                c = (char)(b & 0x7f);
            }
            return c;
        }
        private int seqNr = 0;
	}
}

