#import "MainViewController.h"

@implementation MainViewController
@synthesize label4WebView;
@synthesize label4ImageView;


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil 
{
  if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) 
  {
    // Custom initialization
  }
  return self;
}


 // Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
 - (void)viewDidLoad 
{
  self.label4WebView.text = NSLocalizedString(@"label4WebView.Text", @"");
  self.label4ImageView.text = NSLocalizedString(@"label4ImageView.Text", @"");
 [super viewDidLoad];
}


/*
 // Override to allow orientations other than the default portrait orientation.
 - (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
 // Return YES for supported orientations
 return (interfaceOrientation == UIInterfaceOrientationPortrait);
 }
 */


/*
 // Override to allow orientations other than the default portrait orientation.
 - (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
 // Return YES for supported orientations
 return (interfaceOrientation == UIInterfaceOrientationPortrait);
 }
 */

- (void)didReceiveMemoryWarning 
{
	// Releases the view if it doesn't have a superview.
  [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload 
{
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
  self.label4WebView = nil;
  self.label4ImageView = nil;
}


- (void)dealloc 
{
  [label4WebView release];
  [label4ImageView release];
  [super dealloc];
}

- (IBAction)myAction1:(id)sender 
{
  NSString* tmp = self.label4ImageView.text;
  self.label4ImageView.text = self.label4WebView.text;
  self.label4WebView.text = tmp;
}
@end
