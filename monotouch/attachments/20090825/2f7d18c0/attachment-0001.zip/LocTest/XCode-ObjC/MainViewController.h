#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

@interface MainViewController : UIViewController
{
    UILabel* label4ImageView;
    UILabel* label4WebView;
}

@property (nonatomic, retain) IBOutlet UILabel* label4WebView;
@property (nonatomic, retain) IBOutlet UILabel* label4ImageView;

- (IBAction)myAction1:(id)sender;
@end
