//
//  LocTestAppDelegate.m
//  LocTest
//
//  Created by Peter Sakhno on 25.08.09.
//  Copyright Peter Sakhno 2009. All rights reserved.
//

#import "LocTestAppDelegate.h"
#import "MainViewController.h"

@implementation LocTestAppDelegate

@synthesize window;
@synthesize viewController;


- (void)applicationDidFinishLaunching:(UIApplication *)application 
{    
  // Override point for customization after application launch
  MainViewController* aController = 
  [[MainViewController alloc] initWithNibName:nil bundle:nil];
  self.viewController = aController;
  [aController release];
  
  self.viewController.view.frame = [UIScreen mainScreen].applicationFrame;
  [window addSubview:self.viewController.view];
  [window makeKeyAndVisible];
}


- (void)dealloc 
{
  [viewController release];
  [window release];
  [super dealloc];
}


@end
