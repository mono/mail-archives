//
//  LocTestAppDelegate.h
//  LocTest
//
//  Created by Peter Sakhno on 25.08.09.
//  Copyright Peter Sakhno 2009. All rights reserved.
//

#import <UIKit/UIKit.h>

@class MainViewController;

@interface LocTestAppDelegate : NSObject <UIApplicationDelegate> 
{
  UIWindow *window;
  MainViewController* viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) MainViewController* viewController;

@end

