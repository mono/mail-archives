//
//  main.m
//  LocTest
//
//  Created by Peter Sakhno on 25.08.09.
//  Copyright Peter Sakhno 2009. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
    
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    int retVal = UIApplicationMain(argc, argv, nil, nil);
    [pool release];
    return retVal;
}
