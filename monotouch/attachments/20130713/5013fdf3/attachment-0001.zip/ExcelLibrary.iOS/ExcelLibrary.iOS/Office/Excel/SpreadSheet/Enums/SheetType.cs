using System;
using System.Collections.Generic;
using System.Text;

namespace ExcelLibrary.SpreadSheet
{
    public enum SheetType
    {
        Worksheet = 0,
        Chart = 2,
        VisualBasicModule = 6
    }
}
