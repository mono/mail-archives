// WARNING
//
// This file has been generated automatically by Xamarin Studio to store outlets and
// actions made in the UI designer. If it is removed, they will be lost.
// Manual changes to this file may not be handled correctly.
//
using MonoTouch.Foundation;
using System.CodeDom.Compiler;

namespace ExcelLibrary.iOS.Test
{
	[Register ("ExcelLibrary_iOS_TestViewController")]
	partial class ExcelLibrary_iOS_TestViewController
	{
		[Outlet]
		MonoTouch.UIKit.UILabel A1 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel A10 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel A11 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel A12 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel A2 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel A3 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel A4 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel A5 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel A6 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel A7 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel A8 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel A9 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel B1 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel B10 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel B11 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel B12 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel B2 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel B3 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel B4 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel B5 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel B6 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel B7 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel B8 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel B9 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel C1 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel C10 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel C11 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel C12 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel C2 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel C3 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel C4 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel C5 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel C6 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel C7 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel C8 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel C9 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel D1 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel D10 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel D11 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel D12 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel D2 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel D3 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel D4 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel D5 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel D6 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel D7 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel D8 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel D9 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel E1 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel E10 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel E11 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel E12 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel E2 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel E3 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel E4 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel E5 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel E6 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel E7 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel E8 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel E9 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel F1 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel F10 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel F11 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel F12 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel F2 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel F3 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel F4 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel F5 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel F6 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel F7 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel F8 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UILabel F9 { get; set; }

		[Outlet]
		MonoTouch.UIKit.UICollectionView Grid { get; set; }

		[Action ("TestRead:")]
		partial void TestRead (MonoTouch.Foundation.NSObject sender);

		[Action ("TestSave:")]
		partial void TestSave (MonoTouch.Foundation.NSObject sender);
		
		void ReleaseDesignerOutlets ()
		{

			if (Grid != null) {
				Grid.Dispose ();
				Grid = null;
			}

			if (A1 != null) {
				A1.Dispose ();
				A1 = null;
			}

			if (A2 != null) {
				A2.Dispose ();
				A2 = null;
			}

			if (A3 != null) {
				A3.Dispose ();
				A3 = null;
			}

			if (A4 != null) {
				A4.Dispose ();
				A4 = null;
			}

			if (A5 != null) {
				A5.Dispose ();
				A5 = null;
			}

			if (A6 != null) {
				A6.Dispose ();
				A6 = null;
			}

			if (A7 != null) {
				A7.Dispose ();
				A7 = null;
			}

			if (A8 != null) {
				A8.Dispose ();
				A8 = null;
			}

			if (A9 != null) {
				A9.Dispose ();
				A9 = null;
			}

			if (A10 != null) {
				A10.Dispose ();
				A10 = null;
			}

			if (A11 != null) {
				A11.Dispose ();
				A11 = null;
			}

			if (A12 != null) {
				A12.Dispose ();
				A12 = null;
			}

			if (B1 != null) {
				B1.Dispose ();
				B1 = null;
			}

			if (B2 != null) {
				B2.Dispose ();
				B2 = null;
			}

			if (B3 != null) {
				B3.Dispose ();
				B3 = null;
			}

			if (B4 != null) {
				B4.Dispose ();
				B4 = null;
			}

			if (B5 != null) {
				B5.Dispose ();
				B5 = null;
			}

			if (B6 != null) {
				B6.Dispose ();
				B6 = null;
			}

			if (B7 != null) {
				B7.Dispose ();
				B7 = null;
			}

			if (B8 != null) {
				B8.Dispose ();
				B8 = null;
			}

			if (B9 != null) {
				B9.Dispose ();
				B9 = null;
			}

			if (B10 != null) {
				B10.Dispose ();
				B10 = null;
			}

			if (B11 != null) {
				B11.Dispose ();
				B11 = null;
			}

			if (B12 != null) {
				B12.Dispose ();
				B12 = null;
			}

			if (C1 != null) {
				C1.Dispose ();
				C1 = null;
			}

			if (C2 != null) {
				C2.Dispose ();
				C2 = null;
			}

			if (C3 != null) {
				C3.Dispose ();
				C3 = null;
			}

			if (C4 != null) {
				C4.Dispose ();
				C4 = null;
			}

			if (C5 != null) {
				C5.Dispose ();
				C5 = null;
			}

			if (C6 != null) {
				C6.Dispose ();
				C6 = null;
			}

			if (C7 != null) {
				C7.Dispose ();
				C7 = null;
			}

			if (C8 != null) {
				C8.Dispose ();
				C8 = null;
			}

			if (C9 != null) {
				C9.Dispose ();
				C9 = null;
			}

			if (C10 != null) {
				C10.Dispose ();
				C10 = null;
			}

			if (C11 != null) {
				C11.Dispose ();
				C11 = null;
			}

			if (C12 != null) {
				C12.Dispose ();
				C12 = null;
			}

			if (D1 != null) {
				D1.Dispose ();
				D1 = null;
			}

			if (D2 != null) {
				D2.Dispose ();
				D2 = null;
			}

			if (D3 != null) {
				D3.Dispose ();
				D3 = null;
			}

			if (D4 != null) {
				D4.Dispose ();
				D4 = null;
			}

			if (D5 != null) {
				D5.Dispose ();
				D5 = null;
			}

			if (D6 != null) {
				D6.Dispose ();
				D6 = null;
			}

			if (D7 != null) {
				D7.Dispose ();
				D7 = null;
			}

			if (D8 != null) {
				D8.Dispose ();
				D8 = null;
			}

			if (D9 != null) {
				D9.Dispose ();
				D9 = null;
			}

			if (D10 != null) {
				D10.Dispose ();
				D10 = null;
			}

			if (D11 != null) {
				D11.Dispose ();
				D11 = null;
			}

			if (D12 != null) {
				D12.Dispose ();
				D12 = null;
			}

			if (E1 != null) {
				E1.Dispose ();
				E1 = null;
			}

			if (E2 != null) {
				E2.Dispose ();
				E2 = null;
			}

			if (E3 != null) {
				E3.Dispose ();
				E3 = null;
			}

			if (E4 != null) {
				E4.Dispose ();
				E4 = null;
			}

			if (E5 != null) {
				E5.Dispose ();
				E5 = null;
			}

			if (E6 != null) {
				E6.Dispose ();
				E6 = null;
			}

			if (E7 != null) {
				E7.Dispose ();
				E7 = null;
			}

			if (E8 != null) {
				E8.Dispose ();
				E8 = null;
			}

			if (E9 != null) {
				E9.Dispose ();
				E9 = null;
			}

			if (E10 != null) {
				E10.Dispose ();
				E10 = null;
			}

			if (E11 != null) {
				E11.Dispose ();
				E11 = null;
			}

			if (E12 != null) {
				E12.Dispose ();
				E12 = null;
			}

			if (F1 != null) {
				F1.Dispose ();
				F1 = null;
			}

			if (F2 != null) {
				F2.Dispose ();
				F2 = null;
			}

			if (F3 != null) {
				F3.Dispose ();
				F3 = null;
			}

			if (F4 != null) {
				F4.Dispose ();
				F4 = null;
			}

			if (F5 != null) {
				F5.Dispose ();
				F5 = null;
			}

			if (F6 != null) {
				F6.Dispose ();
				F6 = null;
			}

			if (F7 != null) {
				F7.Dispose ();
				F7 = null;
			}

			if (F8 != null) {
				F8.Dispose ();
				F8 = null;
			}

			if (F9 != null) {
				F9.Dispose ();
				F9 = null;
			}

			if (F10 != null) {
				F10.Dispose ();
				F10 = null;
			}

			if (F11 != null) {
				F11.Dispose ();
				F11 = null;
			}

			if (F12 != null) {
				F12.Dispose ();
				F12 = null;
			}
		}
	}
}
