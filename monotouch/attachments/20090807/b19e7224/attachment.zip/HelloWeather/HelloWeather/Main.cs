
using System;
using System.IO;
using System.Net;

using MonoTouch.Foundation;
using MonoTouch.UIKit;

namespace HelloWeather
{
	public class Application
	{
		static void Main (string[] args)
		{
			UIApplication.Main (args);
		}
	}

	// The name AppDelegate is referenced in the MainWindow.xib file.
	public partial class AppDelegate : UIApplicationDelegate
	{
		// This method is invoked when the application has loaded its UI and its ready to run
		public override bool FinishedLaunching (UIApplication app, NSDictionary options)
		{
			
			button.TouchUpInside += delegate {
				UIApplication.SharedApplication.NetworkActivityIndicatorVisible = true;
				
				var url = "http://ws.cdyne.com/WeatherWS/Weather.asmx/GetCityWeatherByZIP?ZIP=" + zipcode.Text;
				var results = string.Empty;
				
				using(var web = new WebClient())
				using(var stream = web.OpenRead(new Uri(url)))
				using(var reader = new StreamReader(stream)) {
					results = reader.ReadToEnd();
				}
				
				temperature.Text = results;
				
				UIApplication.SharedApplication.NetworkActivityIndicatorVisible = false;
				zipcode.ResignFirstResponder();
			};
			
			// If you have defined a view, add it here:
			// window.AddSubview (navigationController.View);

			window.MakeKeyAndVisible ();

			return true;
		}

		// This method is required in iPhoneOS 3.0
		public override void OnActivated (UIApplication application)
		{
		}
	}
}
