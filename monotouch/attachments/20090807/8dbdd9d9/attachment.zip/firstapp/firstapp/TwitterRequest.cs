/*
 * This file is part of the Twitterizer library <http://code.google.com/p/twitterizer/>
 *
 * Copyright (c) 2008, Patrick "Ricky" Smith <ricky@digitally-born.com>
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification, are 
 * permitted provided that the following conditions are met:
 *
 * - Redistributions of source code must retain the above copyright notice, this list 
 *   of conditions and the following disclaimer.
 * - Redistributions in binary form must reproduce the above copyright notice, this list 
 *   of conditions and the following disclaimer in the documentation and/or other 
 *   materials provided with the distribution.
 * - Neither the name of the Twitterizer nor the names of its contributors may be 
 *   used to endorse or promote products derived from this software without specific 
 *   prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
 * IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
 * POSSIBILITY OF SUCH DAMAGE.
 */
using System;
using System.Text;
using System.Text.RegularExpressions;
using System.Net;
using System.Xml;
using System.Xml.Linq;
using System.IO;

namespace Twitterizer.Framework
{    
	internal class TwitterRequest
	{
        private string proxyUri = string.Empty;

        /// <summary>
        /// Initializes a new instance of the <see cref="TwitterRequest"/> class.
        /// </summary>
        /// <param name="ProxyUri">The proxy URI.</param>
        public TwitterRequest(string ProxyUri)
        {
            proxyUri = ProxyUri;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="TwitterRequest"/> class.
        /// </summary>
        public TwitterRequest()
        {
            
        }

        /// <summary>
        /// Performs the web request.
        /// </summary>
        /// <param name="Data">The data.</param>
        /// <returns></returns>
		public TwitterRequestData PerformWebRequest(TwitterRequestData Data)
		{
			PerformWebRequest(Data, "POST");

			return Data;

		}

        /// <summary>
        /// Performs the web request.
        /// </summary>
        /// <param name="Data">The data.</param>
        /// <param name="HTTPMethod">The HTTP method.</param>
        /// <returns></returns>
		public TwitterRequestData PerformWebRequest(TwitterRequestData Data, string HTTPMethod)
		{
			HttpWebRequest Request = (HttpWebRequest)WebRequest.Create(Data.ActionUri);

            // Check if a proxy address was given, if so, we need to parse it and give it to the HttpWebRequest object.
            if (!string.IsNullOrEmpty(proxyUri))
            {
                UriBuilder proxyUriBuilder = new UriBuilder(proxyUri);
                Request.Proxy = new WebProxy(proxyUriBuilder.Host, proxyUriBuilder.Port);

                // Add the proxy credentials if they are supplied.
                if (!string.IsNullOrEmpty(proxyUriBuilder.UserName))
                    Request.Proxy.Credentials = new NetworkCredential(proxyUriBuilder.UserName, proxyUriBuilder.Password);
            }
            
			Request.Method = HTTPMethod;

			StreamReader readStream;

			// Some limitations
			Request.MaximumAutomaticRedirections = 4;
			Request.MaximumResponseHeadersLength = 4;
			Request.ContentLength = 0;

			// Set our credentials
			Request.Credentials = new NetworkCredential(Data.UserName, Data.Password);

			HttpWebResponse Response;

			// Get the response
			try
			{
				Response = (HttpWebResponse)Request.GetResponse();

				// Get the stream associated with the response.
				Stream receiveStream = Response.GetResponseStream();

				// Pipes the stream to a higher level stream reader with the required encoding format. 
				readStream = new StreamReader(receiveStream, Encoding.UTF8);

				Data.Response = readStream.ReadToEnd();
				Data = ParseResponseData(Data);

				Response.Close();
				readStream.Close();
			}
			catch (Exception ex)
			{
				throw new TwitterizerException(ex.Message, Data, ex);
			}

			return Data;
		}

        /// <summary>
        /// Parses the response data.
        /// </summary>
        /// <param name="Data">The data.</param>
        /// <returns></returns>
        private TwitterRequestData ParseResponseData(TwitterRequestData Data)
        {
            if (Data == null || Data.Response == string.Empty)
                return null;

            XDocument ResultXmlDocument = new XDocument();
			
            ResultXmlDocument.Add(Data.Response);

            if (ResultXmlDocument.Root != null)
                switch (ResultXmlDocument.Root.Name.LocalName.ToLower())
                {
                    case "status":
                        Data.Statuses = new TwitterStatusCollection();
                        Data.Statuses.Add(ParseStatusNode(ResultXmlDocument.Root));
                        break;
                    case "statuses":
                        Data.Statuses = ParseStatuses(ResultXmlDocument.Root);
                        break;
                    case "users":
                        Data.Users = ParseUsers(ResultXmlDocument.Root);
                        break;
                    case "user":
                        Data.Users = new TwitterUserCollection();
                        Data.Users.Add(ParseUserNode(ResultXmlDocument.Root));
                        break;
                    case "direct_message":
                        Data.Statuses = new TwitterStatusCollection();
                        Data.Statuses.Add(ParseDirectMessageNode(ResultXmlDocument.Root));
                        break;
                    case "direct-messages":
                        Data.Statuses = ParseDirectMessages(ResultXmlDocument.Root);
                        break;
                    case "nilclasses":
                    case "nil-classes":
                        // do nothing, this seems to be a null response i.e. no messages since
                        break;
                    case "error":
                        throw new Exception("Error response from Twitter: " + ResultXmlDocument.Root.ToString());
                    default:
                        throw new Exception("Invalid response from Twitter");
                }
            return Data;
        }

		#region Parse Statuses
        /// <summary>
        /// Parses multiple status nodes and returns a collection of status objects.
        /// </summary>
        /// <param name="Element">The element.</param>
        /// <returns></returns>
		private static TwitterStatusCollection ParseStatuses(XElement Element)
		{
			
			TwitterStatusCollection Collection = new TwitterStatusCollection();
			foreach (var Child in Element.Elements("status"))
			{
				Collection.Add(ParseStatusNode(Child));
			}

			return Collection;
		}

        /// <summary>
        /// Parses a single status node and returns a status object.
        /// </summary>
        /// <param name="Element">The element.</param>
        /// <returns></returns>
		private static TwitterStatus ParseStatusNode(XElement Element)
		{
			TwitterStatus Status = new TwitterStatus();
            Status.IsDirectMessage = false;

			if (Element == null) return null;

			//Mon May 12 15:56:07 +0000 2008
			Status.ID = Int64.Parse(Element.Element("id").ToString());
			Status.Created = ParseDateString(Element.Element("created_at").ToString());
			Status.Text = Element.Element("text").ToString();
			Status.Source = Element.Element("source").ToString();
			Status.IsTruncated = bool.Parse(Element.Element("truncated").ToString());
			if (Element.Element("in_reply_to_status_id") != null)
				Status.InReplyToStatusID = Int64.Parse(Element.Element("in_reply_to_status_id").ToString());
			if (Element.Element("in_reply_to_user_id") != null)
				Status.InReplyToUserID = int.Parse(Element.Element("in_reply_to_user_id").ToString());

			// Fix for Issued #4
			bool isFavorited;
			bool.TryParse(Element.Element("favorited").ToString(), out isFavorited);
			Status.IsFavorited = isFavorited;

			Status.TwitterUser = ParseUserNode(Element.Element("user"));
            if (Element.Element("sender") != null)
                Status.TwitterUser = ParseUserNode(Element.Element("sender"));
            if (Element.Element("recipient") != null)
                Status.Recipient = ParseUserNode(Element.Element("recipient"));

			return Status;
		}
		#endregion

		#region Parse DirectMessages
        /// <summary>
        /// Parses multiple direct messages and returns a collection of statuses.
        /// </summary>
        /// <param name="Element">The element.</param>
        /// <returns></returns>
		private static TwitterStatusCollection ParseDirectMessages(XElement Element)
		{
			TwitterStatusCollection Collection = new TwitterStatusCollection();
			foreach (var Child in Element.Elements("direct_message"))
			{
				Collection.Add(ParseDirectMessageNode(Child));
			}

			return Collection;
		}

        /// <summary>
        /// Parses a single direct message node and returns a status object.
        /// </summary>
        /// <param name="Element">The element.</param>
        /// <returns></returns>
		private static TwitterStatus ParseDirectMessageNode(XElement Element)
		{
			if (Element == null) return null;

			TwitterStatus Status = new TwitterStatus();

            Status.IsDirectMessage = true;
			Status.ID = Int64.Parse(Element.Element("id").ToString());
			Status.Created = ParseDateString(Element.Element("created_at").ToString());
			Status.Text = Element.Element("text").ToString();

			if (Element.Element("favorited") != null && (Element.Element("in_reply_to_status_id").ToString() != string.Empty))
				Status.IsFavorited = bool.Parse(Element.Element("favorited").ToString());

            Status.TwitterUser = ParseUserNode(Element.Element("sender"));
			Status.RecipientID = int.Parse(Element.Element("recipient_id").ToString());
            Status.Recipient = ParseUserNode(Element.Element("recipient"));
            
			return Status;
		}
		#endregion
		/// <summary>
        /// Parses a single user node and returns a user object.
        /// </summary>
        /// <param name="Element">The element.</param>
        /// <returns></returns>
        private static TwitterUser ParseUserNode(XElement Element)
		{
			if (Element == null)
				return null;

			TwitterUser User = new TwitterUser();
			User.ID = int.Parse(Element.Element("id").ToString());
			User.UserName = Element.Element("name").ToString();
			User.ScreenName = Element.Element("screen_name").ToString();
			User.Location = Element.Element("location").ToString();
			User.Description = Element.Element("description").ToString();
			User.IsProtected = bool.Parse(Element.Element("protected").ToString());
			User.NumberOfFollowers = int.Parse(Element.Element("followers_count").ToString());
            User.ProfileImageUri = Element.Element("profile_image_url").ToString();
            User.ProfileUri = Element.Element("url").ToString();
			if (Element.Element("friends_count") != null)
				User.Friends_count = int.Parse(Element.Element("friends_count").ToString());
			else
				User.Friends_count = -1;        // flag that we don't know, which is different than having zero friends

			if (Element.Element("status") != null)
				User.Status = ParseStatusNode(Element.Element("status"));

			return User;
		}
		
		/// <summary>
        /// Parses a date string into a strongly typed DateTime object.
        /// </summary>
        /// <param name="DateString">The date string.</param>
        /// <returns></returns>
        /// <remarks>Format example: Wed Apr 08 20:30:04 +0000 2009</remarks>
		private static DateTime ParseDateString(string DateString)
		{
			Regex re = new Regex(@"(?<DayName>[^ ]+) (?<MonthName>[^ ]+) (?<Day>[^ ]{1,2}) (?<Hour>[0-9]{1,2}):(?<Minute>[0-9]{1,2}):(?<Second>[0-9]{1,2}) (?<TimeZone>[+-][0-9]{4}) (?<Year>[0-9]{4})");
			Match CreatedAt = re.Match(DateString);
			DateTime parsedDate = DateTime.Parse(
				string.Format(
					"{0} {1} {2} {3}:{4}:{5}",
					CreatedAt.Groups["MonthName"].Value,
					CreatedAt.Groups["Day"].Value,
					CreatedAt.Groups["Year"].Value,
					CreatedAt.Groups["Hour"].Value,
					CreatedAt.Groups["Minute"].Value,
					CreatedAt.Groups["Second"].Value));

			return parsedDate;
		}
		#region Parse Users
        /// <summary>
        /// Parses multiple users nodes and returns a collection of user objects.
        /// </summary>
        /// <param name="Element">The element.</param>
        /// <returns></returns>
		private static TwitterUserCollection ParseUsers(XElement Element)
		{
			if (Element == null) return null;

			TwitterUserCollection Collection = new TwitterUserCollection();
			foreach (XElement Child in Element.Elements("user")) 
			{
				Collection.Add(ParseUserNode(Child));
			}

			return Collection;
		}

        	 
		#endregion

        
	}
}
