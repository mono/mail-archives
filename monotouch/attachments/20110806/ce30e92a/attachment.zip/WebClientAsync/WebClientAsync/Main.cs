
using System;
using System.Net;
using System.Collections.Generic;
using System.Linq;
using MonoTouch.Foundation;
using MonoTouch.UIKit;

namespace WebClientAsync
{
	public class Application
	{
		static void Main (string[] args)
		{
			UIApplication.Main (args);
		}
	}

	// The name AppDelegate is referenced in the MainWindow.xib file.
	public partial class AppDelegate : UIApplicationDelegate
	{
		private WebClientCookieAware _webclient;
		private UIAlertView _progressView;
		private const string DownloadURL = "http://download.thinkbroadband.com/20MB.zip";
		private long _byteCount = 0;
		private long _totalBytes = 0;
		// This method is invoked when the application has loaded its UI and its ready to run
		public override bool FinishedLaunching (UIApplication app, NSDictionary options)
		{
			// If you have defined a view, add it here:
			// window.AddSubview (navigationController.View);
			btnStartDownload.TouchUpInside += HandleBtnStartDownloadTouchUpInside;
			
			
			window.MakeKeyAndVisible ();
			
			return true;
		}

		void HandleBtnStartDownloadTouchUpInside (object sender, EventArgs e)
		{
			//Here we initiate the webclient itself and start the async download
			//As per multiple fora, I embedd the object and it's siblings via NSAUtoReleasePool
			Uri uri = new Uri(DownloadURL);
			
			using (var pool = new NSAutoreleasePool()) {  
				_webclient = new WebClientCookieAware();
				_webclient.DownloadProgressChanged += Handle_webclientDownloadProgressChanged;
				_webclient.DownloadDataCompleted += Handle_webclientDownloadDataCompleted;
				_webclient.Disposed += Handle_webclientDisposed;
				
				InvokeOnMainThread(delegate {
					_progressView = new UIAlertView("Downloading","Initiating download",null,"Cancel Download");
					_progressView.Canceled += Handle_progressViewCanceled;
					_progressView.Clicked += Handle_progressViewClicked;
					_progressView.Show();
				});
				
				_byteCount = 0;
				_totalBytes = 0;
				_webclient.DownloadDataAsync(uri);
			}
		}

		void Handle_progressViewClicked (object sender, UIButtonEventArgs e)
		{
			System.Diagnostics.Debug.WriteLine("UIView Clicked");
			_webclient.CancelAsync();
		}

		void Handle_progressViewCanceled (object sender, EventArgs e)
		{
			System.Diagnostics.Debug.WriteLine("UIView Cancelled");
		}

		void Handle_webclientDisposed (object sender, EventArgs e)
		{
			System.Diagnostics.Debug.WriteLine("WebClient Disposed");
		}

		void Handle_webclientDownloadDataCompleted (object sender, DownloadDataCompletedEventArgs e)
		{
			System.Diagnostics.Debug.WriteLine("WebClient DownloadData Completed");
			if(!e.Cancelled)
			{
				if(e.Error == null)
				{
					//The was downloaded succesfully
					System.Diagnostics.Debug.WriteLine("WebClient Download Success");
				}
				else
				{
					//We have reached this code due to an Error during download
					System.Diagnostics.Debug.WriteLine("WebClient Download Error");
				}
			}
			else
			{
				//We have reached this code due to the CancelAsync request
				System.Diagnostics.Debug.WriteLine("WebClient Download Cancelled");
			}
		}

		void Handle_webclientDownloadProgressChanged (object sender, DownloadProgressChangedEventArgs e)
		{
			if(e.BytesReceived>0)
				_byteCount += e.BytesReceived;
			
			//We will update the UIAlertView only from the moment we have receveid enough info 
			//to actually show a progress message
			if(e.TotalBytesToReceive>0)
			{
				_totalBytes = e.TotalBytesToReceive;	
				InvokeOnMainThread(delegate {
					_progressView.Message = String.Format("{0}Kb of {1}Kb downloaded", (_byteCount/1024).ToString(), (_totalBytes/1024).ToString());
				});
			}
		}

		// This method is required in iPhoneOS 3.0
		public override void OnActivated (UIApplication application)
		{
		}
	}
}

