
using System;
using System.Collections.Generic;
using System.Linq;
using MonoTouch.Foundation;
using MonoTouch.UIKit;
using System.Net;
using System.IO;

namespace Bugs
{
	public class Application
	{
		static void Main(string[] args)
		{
			UIApplication.Main(args);
		}
	}

	// The name AppDelegate is referenced in the MainWindow.xib file.
	public partial class AppDelegate : UIApplicationDelegate
	{
		// This method is invoked when the application has loaded its UI and its ready to run
		public override bool FinishedLaunching(UIApplication app, NSDictionary options)
		{
			var label = new UILabel(new System.Drawing.RectangleF(0, 0, this.window.Frame.Width, this.window.Frame.Height));
			label.Lines = 500;
			window.AddSubview(label);
			
			using (var wc = new WebClient()) {
				UIApplication.SharedApplication.NetworkActivityIndicatorVisible = true;
				//wc.OpenReadCompleted += delegate(object sender, OpenReadCompletedEventArgs e) {
				//	WriteResponse(e.Result, label);
				//};
				try {
					//wc.OpenReadAsync(new Uri("http://google.com"));
					WriteResponse(wc.OpenRead(new Uri("http://google.com")), label);
				}
				catch (Exception ex) {
					label.Text = ex.ToString();
				}
			}

			
			window.MakeKeyAndVisible();

			return true;
		}
		
		void WriteResponse(Stream response, UILabel label)
		{
			string html;
			using (var reader = new StreamReader(response)) {
				html = reader.ReadToEnd();
			}
			label.Text = html;
			UIApplication.SharedApplication.NetworkActivityIndicatorVisible = false;
		}
		
		// This method is required in iPhoneOS 3.0
		public override void OnActivated(UIApplication application)
		{
		}
	}
}
