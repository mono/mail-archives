using System;
using System.Drawing;
using TestSchober.www.salesreport.ch;
using MonoTouch.Foundation;
using MonoTouch.UIKit;

namespace TestSchober
{
	public partial class TestSchoberViewController : UIViewController
	{
		static bool UserInterfaceIdiomIsPhone {
			get { return UIDevice.CurrentDevice.UserInterfaceIdiom == UIUserInterfaceIdiom.Phone; }
		}

		public TestSchoberViewController ()
			: base (UserInterfaceIdiomIsPhone ? "TestSchoberViewController_iPhone" : "TestSchoberViewController_iPad", null)
		{
		}
		
		public override void DidReceiveMemoryWarning ()
		{
			// Releases the view if it doesn't have a superview.
			base.DidReceiveMemoryWarning ();
			
			// Release any cached data, images, etc that aren't in use.
		}
		
		public override void ViewDidLoad ()
		{
			base.ViewDidLoad ();
			new MobileDataServiceSoapClient().ApplicationLogin("asdf","asdaf");
			System.Diagnostics.Debug.WriteLine("juhu");
			// Perform any additional setup after loading the view, typically from a nib.
		}
		
		public override bool ShouldAutorotateToInterfaceOrientation (UIInterfaceOrientation toInterfaceOrientation)
		{
			// Return true for supported orientations
			if (UserInterfaceIdiomIsPhone) {
				return (toInterfaceOrientation != UIInterfaceOrientation.PortraitUpsideDown);
			} else {
				return true;
			}
		}
	}
}

