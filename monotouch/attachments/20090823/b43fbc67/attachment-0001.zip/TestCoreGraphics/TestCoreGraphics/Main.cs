
using System;
using System.Collections.Generic;
using System.Linq;
using MonoTouch.Foundation;
using MonoTouch.UIKit;

namespace TestCoreGraphics
{
	public class Application
	{
		static void Main (string[] args)
		{
			UIApplication.Main (args);
		}
	}

	// The name AppDelegate is referenced in the MainWindow.xib file.
	public partial class AppDelegate : UIApplicationDelegate
	{
		// This method is invoked when the application has loaded its UI and its ready to run
		public override bool FinishedLaunching (UIApplication app, NSDictionary options)
		{
			// If you have defined a view, add it here:
			// window.AddSubview (navigationController.View);
			window.AddSubview(gameView);
			window.MakeKeyAndVisible ();

			return true;
		}

		// This method is required in iPhoneOS 3.0
		public override void OnActivated (UIApplication application)
		{
		}
	}
	public partial class GameView : UIView
	{
		float x = 0;
		public GameView(IntPtr handle)
		{
			NSTimer.CreateRepeatingScheduledTimer(TimeSpan.FromSeconds(.033), () => Update());
		}
		public void Update()
		{
			x += 4;
			SetNeedsDisplay();
		}
		public override void Draw (System.Drawing.RectangleF rect)
		{
			MonoTouch.CoreGraphics.CGContext context = UIGraphics.GetCurrentContext();
			UIImage.FromFile("icon.png").Draw(new System.Drawing.PointF(x, 20));
		}

	}
}
