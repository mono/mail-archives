
using System;
using System.Collections.Generic;
using System.Linq;
using MonoTouch.Foundation;
using MonoTouch.UIKit;

namespace MonoUtilityProject
{
	public partial class MainView : UIViewController
	{
		// This is required for controllers that need to be able to be
		// created from a xib rather than from managed code
		public MainView (IntPtr handle) : base(handle)
		{
			Initialize ();
		}

		public MainView ()
		{
			Initialize ();
		}

		void Initialize ()
		{
		}
  		
		partial void showInfo (UIButton sender)	
		{	
			var app = (AppDelegate)UIApplication.SharedApplication.Delegate;

			// use horizontal flip for transition to flip view
			app.FlipViewController.ModalTransitionStyle = UIModalTransitionStyle.FlipHorizontal;			
			
			// this is our callback from the Done button on the flip view
			app.FlipViewController.DoneTapped += delegate
			{
				// dismiss modal view
				this.DismissModalViewControllerAnimated(true);	
			};
			
			// show flip view as modal view
			this.PresentModalViewController(app.FlipViewController, true);
		}
	}
}