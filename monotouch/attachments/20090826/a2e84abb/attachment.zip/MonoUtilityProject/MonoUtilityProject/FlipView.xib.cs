
using System;
using System.Collections.Generic;
using System.Linq;
using MonoTouch.Foundation;
using MonoTouch.UIKit;

namespace MonoUtilityProject
{
	public partial class FlipView : UIViewController
	{
		internal event EventHandler<EventArgs> DoneTapped = delegate {};
		
		// This is required for controllers that need to be able to be
		// created from a xib rather than from managed code
		public FlipView (IntPtr handle) : base(handle)
		{
			Initialize ();
		}

		public FlipView ()
		{
			Initialize ();
		}

		void Initialize ()
		{	
		}
		
		partial void done (UIBarButtonItem sender)
		{			
			// tell our mainview to dismiss modal dialog
			// (which is currently this view, if we're active)
			DoneTapped(this, EventArgs.Empty);
		}
		
		public override void ViewDidLoad ()
		{
			base.ViewDidLoad ();
			this.View.BackgroundColor = UIColor.ViewFlipsideBackgroundColor;			
		}
	}
}
