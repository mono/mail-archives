
using System;
using System.Collections.Generic;
using System.Linq;
using MonoTouch.Foundation;
using MonoTouch.UIKit;

namespace HelloWorld2
{
	public partial class ViewController : UIViewController
	{
		#region Constructors

		// The IntPtr and initWithCoder constructors are required for items that need 
		// to be able to be created from a xib rather than from managed code

		public ViewController (IntPtr handle) : base(handle)
		{
			Initialize ();
		}

		[Export("initWithCoder:")]
		public ViewController (NSCoder coder) : base(coder)
		{
			Initialize ();
		}

		public ViewController () : base("ViewController", null)
		{
			Initialize ();
		}

		void Initialize ()
		{
		}
		
		#endregion
		
		public override void ViewDidLoad ()
		{
			myDelegateButton.TouchUpInside += delegate
			{
				using (UIAlertView alertView = new UIAlertView ("Info", "Delegate button has done its duty", null, "OK", null)) {
					alertView.Show ();
				};
			};
		}

		partial void myActionButtonPressed (MonoTouch.UIKit.UIButton sender)
		{
			using (UIAlertView alertView = new UIAlertView ("Info", "Action button has done its duty", null, "OK", null)) {
				alertView.Show ();
			}
		}
	}
}

