
using System;
using System.Collections.Generic;
using System.Linq;
using MonoTouch.Foundation;
using MonoTouch.UIKit;

namespace LocTest
{
	public partial class MainViewController : UIViewController
	{

		// This is required for controllers that need to be able to be
		// created from a xib rather than from managed code
		public MainViewController (IntPtr handle) : base(handle)
		{
			Console.WriteLine ("===> MainViewController::MainViewController (IntPtr handle);");
			Initialize ();
		}
		
		public MainViewController (string nibName, NSBundle bundle) : base(nibName, bundle)
		{
			Console.WriteLine ("===> MainViewController::MainViewController (string nibName, NSBundle bundle);");
			Initialize ();
		}

		public MainViewController ()
		{
			Console.WriteLine ("===> MainViewController::MainViewController ();");
			Initialize ();
		}
		
		void Initialize ()
		{
		}

		public override void AwakeFromNib ()
		{
			base.AwakeFromNib ();
			Console.WriteLine ("===> MainViewController::AwakeFromNib ();");
		}

		public override void ViewDidLoad ()
		{
			base.ViewDidLoad ();
			Console.WriteLine ("===> MainViewController::ViewDidLoad ();");
			this.label4ImageView.Text = 
				NSBundle.MainBundle.LocalizedString ("label4ImageView.Text", "", "");
			this.label4WebView.Text = 
				NSBundle.MainBundle.LocalizedString ("label4WebView.Text", "", "");
		}

		partial void myAction1 (MonoTouch.UIKit.UIButton sender)
		{
			// Set up labels
			this.label4ImageView.Text = 
				NSBundle.MainBundle.LocalizedString ("label4ImageView.Text", "", "");
			Console.WriteLine ("===> label4ImageView.Text = '{0}'", this.label4ImageView.Text);
			this.label4WebView.Text = 
				NSBundle.MainBundle.LocalizedString ("label4WebView.Text", "", "");
			Console.WriteLine ("===> label4WebView.Text = '{0}'", this.label4WebView.Text);
		}
	}
}
