#region Using

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;

using Gizmox.WebGUI.Common;
using Gizmox.WebGUI.Forms;

#endregion

namespace WebGUIApplicationMono
{
    public partial class Form1 : Form
    {
        Form runtimeForm;
        public Form1()
        {
            InitializeComponent();
        }

        

        private void buttonCalc_Click(object sender, EventArgs e)
        {
            try
            {
                labelResult.Text = (int.Parse(textBox1.Text) + int.Parse(textBox2.Text)).ToString();

            }
            catch (Exception)
            {

                this.errorProvider1.SetError(this.labelResult, "please, Only numbers!!");
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            runtimeForm = new Form();
            runtimeForm.Text = "El mono se calma bebiendo te de Java!!";
            runtimeForm.Width = 400;
            runtimeForm.Height  = 400;
            Button b1 = new Button();
            Label l1 = new Label();
            l1.Width = 200;
             
            b1.Text = "cerrar";
            b1.Top = 200;
            b1.Left = 200;
            l1.Top = b1.Top - (b1.Height + 5);
            l1.Left = b1.Left;
            l1.BackColor = labelResult.BackColor;
            l1.Text = labelResult.Text;
            l1.Font = labelResult.Font;


            b1.Click += new EventHandler(b1_Click);
           

            runtimeForm.Controls.Add(b1);
            runtimeForm.Controls.Add(l1);


            runtimeForm.ShowDialog();

        }

        void b1_Click(object sender, EventArgs e)
        {
            runtimeForm.Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            this.errorProvider1.SetError(labelResult, "");
        }

        private void button2_Click(object sender, EventArgs e)
        {
          
            MessageBox.Show("Quieres salir ..?", "SI o No", MessageBoxButtons.YesNo,MessageBoxIcon.Question, new EventHandler(medieron));

        }

        private void medieron (object sender, EventArgs e)
        {
            if (((Form)sender).DialogResult == DialogResult.Yes)
            {
                MessageBox.Show("SI", "I Said",MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
            else
            {
                MessageBox.Show("NO", "I Said",MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
             

        }
    }
}