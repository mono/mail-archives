// Main.cs created with MonoDevelop
// User: kraptor at 15:17 27/06/2008
//
// To change standard headers go to Edit->Preferences->Coding->Standard Headers
//

using System;

namespace test2
{
	public class Start
	{
		
		static public void Main( string[] param )
		{
			System.Console.WriteLine( "Hello world" );
			
			Gtk.Application.Init();
			
			
			MainWindow win = new MainWindow();
			
			win.Show();
			
			Gtk.Application.Run();
		}
	}
}
