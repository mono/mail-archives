// MainWindow.cs created with MonoDevelop
// User: kraptor at 15:36 27/06/2008
//
// To change standard headers go to Edit->Preferences->Coding->Standard Headers
//

using System;
using System.IO;
using MonoDevelop.Components.Docking;

using Gtk;

namespace test2
{
	public class MainWindow: Window
	{
		DockFrame df;
	
		public MainWindow(): base( "This is a window test" )
		{
			DeleteEvent += onDeleteEvent;
			SetSizeRequest( 800, 600 );
						
			df = new DockFrame();
			df.DefaultItemHeight = 100;
			df.DefaultItemWidth = 100;
			df.Homogeneous = false;
			
			Add( df );
									
			DockItem doc_item = df.AddItem( "Document" );
			doc_item.Behavior = DockItemBehavior.Locked;
			doc_item.Expand = true;
			doc_item.DrawFrame = false;
			doc_item.Label = "Documentos";
			Gtk.Notebook nb = new Notebook();
			//nb.AppendPage( sw, new Label( "The label" ) );
			nb.AppendPage( new Label( "Other page" ), new Label( "The label" ) );
			nb.AppendPage( new TextView(), new Image( "gtk-new", IconSize.Menu ) );
			nb.ShowAll();
			doc_item.Content = nb;
			doc_item.DefaultVisible = true;
			doc_item.Visible = true;
			
			DockItem left = df.AddItem( "left" );
			left.Behavior = DockItemBehavior.CantClose;
			left.DefaultLocation = "Document/Left";
			left.DefaultVisible = true;
			left.Visible = true;
			left.Label = "Izquierda";
			left.DrawFrame = true;
			left.Content = new Label( "This is a test" );
			
			
			
			DockItem right = df.AddItem( "right" );
			right.Behavior = DockItemBehavior.CantClose;
			right.DefaultLocation = "Document/Right";
			right.DefaultVisible = true;
			right.Visible = true;
			right.Label = "Derecha";
			right.DrawFrame = true;
			right.Content = new Label( "CONTENIDO" );
			right.Icon = "gtk-close";
			
			DockItem rb = df.AddItem( "right_bottom" );
			rb.Behavior = DockItemBehavior.CantClose;
			rb.DefaultLocation = "right/Bottom";
			rb.DefaultVisible = true;
			rb.Visible = true;
			rb.Label = "Derecha abajo";
			rb.DrawFrame = true;
			rb.Content = new Button( "A BUTTON!" );
			rb.Behavior = DockItemBehavior.CantClose;
			rb.Icon = "gtk-new";
			
			
			if ( File.Exists( "config.layout" ) )
			{
				df.LoadLayouts( "config.layout" );
			}
			else
			{
				df.CreateLayout( "test", true );
			}
			df.CurrentLayout = "test";
			df.HandlePadding = 0;
			df.HandleSize = 10;
		
								
			ShowAll();
		}
		
		public void onDeleteEvent( object sender, DeleteEventArgs args )
		{
			df.SaveLayouts( "config.layout" );
			Gtk.Application.Quit();
		}
	}
}
