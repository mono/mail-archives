using Gtk;

using MonoDevelop.Core;
using MonoDevelop.Core.Gui.Dialogs;

namespace MonoDevelop.ChangeLogAddIn
{
	public class ChangeLogAddInOptionPanel : AbstractOptionPanel
	{
		Entry nameEntry = new Entry();
		Entry emailEntry = new Entry();
		
		public override void LoadPanelContents()
		{
			VBox vbox = new VBox();
			this.Add(vbox);
			
			Label nameLabel = new Label(GettextCatalog.GetString ("Full Name:"));
			nameEntry.Text = Runtime.Properties.GetProperty("ChangeLogAddIn.Name", "Full Name");

			Label emailLabel = new Label(GettextCatalog.GetString ("Email Address:"));
			emailEntry.Text = Runtime.Properties.GetProperty("ChangeLogAddIn.Email", "Email Address");

			HBox nameBox = new HBox();
			nameBox.PackStart(nameLabel, false, false, 10);
			nameBox.PackStart(nameEntry, true, true, 10);
			vbox.PackStart(nameBox, false, false, 10);

			HBox emailBox = new HBox();
			emailBox.PackStart(emailLabel, false, false, 10);
			emailBox.PackStart(emailEntry, true, true, 10);
			vbox.PackStart(emailBox, false, false, 10);
		}
		
		public override bool StorePanelContents()
		{
			Runtime.Properties.SetProperty("ChangeLogAddIn.Name", nameEntry.Text);
			Runtime.Properties.SetProperty("ChangeLogAddIn.Email", emailEntry.Text);
			return true;
		}
	}

}
