using System;

using MonoDevelop.Core;
using MonoDevelop.Components.Commands;
using MonoDevelop.Ide.Gui;
using MonoDevelop.SourceEditor.Gui;

using Gtk;

namespace MonoDevelop.ChangeLogAddIn
{
        public enum ChangeLogCommands
        {
                AddChangeLogEntry
        }

	public class AddChangeLogEntryHandler : CommandHandler
	{
		protected override void Run()
                {
			MonoDevelop.SourceEditor.Gui.SourceEditor editor = GetEditorForActiveChangeLogDocument();

			if (editor == null)
				return;
						
			string name = Runtime.Properties.GetProperty("ChangeLogAddIn.Name", "Full Name");
			string email = Runtime.Properties.GetProperty("ChangeLogAddIn.Email", "Email Address");
			string date = DateTime.Now.ToString("yyyy-MM-dd");
			string text = date + "  " + name + " <" + email + "> " + Environment.NewLine + Environment.NewLine + "\t*";
			
			TextIter iter = editor.Buffer.GetIterAtMark(editor.Buffer.InsertMark);
			editor.Buffer.Insert(ref iter, text);
		}

		protected override void Update(CommandInfo info)
		{
			info.Enabled = GetEditorForActiveChangeLogDocument() != null;
		}

		private MonoDevelop.SourceEditor.Gui.SourceEditor GetEditorForActiveChangeLogDocument()
		{
			Document document = IdeApp.Workbench.ActiveDocument;

			if (document != null && document.Content is SourceEditorDisplayBindingWrapper) {

				if (!document.FileName.EndsWith("ChangeLog"))
					return null;

				SourceEditorDisplayBindingWrapper wrapper = document.Content as SourceEditorDisplayBindingWrapper;
				return wrapper.Editor as MonoDevelop.SourceEditor.Gui.SourceEditor;
			}

			return null;		
		}
	}
}
	
