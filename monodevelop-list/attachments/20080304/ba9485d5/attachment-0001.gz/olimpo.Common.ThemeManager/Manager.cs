using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections.Generic;
using System.Threading;

namespace olimpo.Common.Theme
{
	public static class Manager
	{		
#region Public Methods
		public static void PreInit (System.Web.UI.Page page)
		{
			DataService.CORE_tblPage pageControl = new DataService.CORE_tblPage();
			Data.CORE_tblPage olimpoPage = DataService.CORE_tblPage.GetPage(page.Request.CurrentExecutionFilePath);
			
			if (!string.IsNullOrEmpty(olimpoPage.MasterPageFile))
				page.MasterPageFile = olimpoPage.MasterPageFile;
		}
		public static void LoadTheme (System.Web.UI.MasterPage masterPage)
		{
			if (olimpo.Common.Globals.DebugMode) System.Console.WriteLine(string.Format("olimpo.Common.Theme :: LoadTheme")); 			
			System.Security.Principal.IIdentity userIdentify = Thread.CurrentPrincipal.Identity;			
			
			DataService.CORE_tblPage pageControl = new DataService.CORE_tblPage();
			Data.CORE_tblPage olimpoPage = DataService.CORE_tblPage.GetPage(masterPage.Page.MasterPageFile);

			if (olimpoPage == null)
				throw new ApplicationException(string.Format("There is no page defined in Olimpo System named {0}", masterPage.Page.MasterPageFile));
			if (olimpo.Common.Globals.DebugMode) System.Console.WriteLine(string.Format("Page {0} was found", masterPage.Page.MasterPageFile));
			
			// Giving to the Page a tittle
			masterPage.Page.Title = olimpoPage.Title;

			List<Data.CORE_tblWebControl> webUserControlList = (List<Data.CORE_tblWebControl>) DataService.CORE_tblWebControl.GetWebUserControls(olimpoPage.PageID);
			foreach (Data.CORE_tblWebControl webUserControl in webUserControlList)
			{
				PlaceHolder myPlaceHolder = (PlaceHolder)masterPage.FindControl(webUserControl.PlaceHolder);
				if (myPlaceHolder == null)
					throw new ApplicationException(string.Format("PlaceHolder {0} not found in the {1}", webUserControl.PlaceHolder, olimpoPage.Name));

				// Check if the user as access to the Module
				bool moduleAccess = olimpo.Common.Membership.SecurityAccess.CheckUserRight(userIdentify.Name, webUserControl.AclID, "ModuleAccess");
				
				if (moduleAccess)
					AddWebControl2PlaceHolder(masterPage, webUserControl, myPlaceHolder);
			}
		}
		public static void LoadTheme (System.Web.UI.Page page, PlaceHolder placeHolder)
		{
			if (olimpo.Common.Globals.DebugMode) System.Console.WriteLine(string.Format("olimpo.Common.Theme :: LoadTheme"));
			System.Security.Principal.IIdentity userIdentify = Thread.CurrentPrincipal.Identity;
			
			DataService.CORE_tblPage pageControl = new DataService.CORE_tblPage();
			Data.CORE_tblPage olimpoPage = DataService.CORE_tblPage.GetPage(page.Request.CurrentExecutionFilePath);

			if (olimpoPage == null)
				throw new ApplicationException(string.Format("There is no page defined in Olimpo System named {0}", page.MasterPageFile));
			if (olimpo.Common.Globals.DebugMode) System.Console.WriteLine(string.Format("Page {0} was found", page.MasterPageFile));
			
			// Giving to the Page a tittle
			page.Title = olimpoPage.Title;

			List<Data.CORE_tblWebControl> webUserControlList = (List<Data.CORE_tblWebControl>) DataService.CORE_tblWebControl.GetWebUserControls(olimpoPage.PageID);
			foreach (Data.CORE_tblWebControl webUserControl in webUserControlList)
			{
				// Check if the user as access to the Module
				bool moduleAccess = olimpo.Common.Membership.SecurityAccess.CheckUserRight(userIdentify.Name, webUserControl.AclID, "ModuleAccess");
				
				if (moduleAccess)
					AddWebControl2PlaceHolder(page, webUserControl, placeHolder);
			}
		}
#endregion
		
#region Private Static Methods
		private static void AddWebControl2PlaceHolder(System.Web.UI.MasterPage page, Data.CORE_tblWebControl myWebControl, PlaceHolder myPlaceHolder) 
		{
			AddWebControl2PlaceHolder(page, myWebControl, myPlaceHolder, "index.ascx", "");
		}
		private static void AddWebControl2PlaceHolder(System.Web.UI.Page page, Data.CORE_tblWebControl myWebControl, PlaceHolder myPlaceHolder) 
		{
			AddWebControl2PlaceHolder(page, myWebControl, myPlaceHolder, "index.ascx", "");
		}
		private static void AddWebControl2PlaceHolder(System.Web.UI.MasterPage page, Data.CORE_tblWebControl myWebControl, PlaceHolder myPlaceHolder, string webControlName, string webControlCaption) 
		{
			if (myWebControl == null)
				throw new ApplicationException("WebUserControl was not found to be load. Please you have to register it in Olimpo CMS.");

			myPlaceHolder.Controls.Add(new LiteralControl(string.Format("<div id='WebControlDetail'>")));
			myPlaceHolder.Controls.Add(new LiteralControl(string.Format("<div id='{0}'>", myWebControl.CssClass)));

			if (!string.IsNullOrEmpty(myWebControl.Caption))
			{
				myPlaceHolder.Controls.Add(new LiteralControl(string.Format("<div id='WebControlHeader'>")));
				if (string.IsNullOrEmpty(webControlCaption))
					myPlaceHolder.Controls.Add(new LiteralControl(string.Format("{0}", myWebControl.Caption)));
				else
					myPlaceHolder.Controls.Add(new LiteralControl(string.Format("{0}", webControlCaption)));
				myPlaceHolder.Controls.Add(new LiteralControl(string.Format("</div>")));
			}

			string strWebControlPath = string.Format("{0}/{1}", myWebControl.WebControlPath, webControlName);
			Control myControl = page.Page.LoadControl(strWebControlPath);

			// if the WebControl to be loaded implements the IWebUserControl, then, we must pass the parameters defined in the structure
			if (IsIWebUserControl(myControl))
				SendParametersToWebUserControl(myWebControl.Parameters, myControl);

			//myControl.ID = string.Format("WebControl_{0}_{1}", myWebControl.Name, webControlName);
			myPlaceHolder.Controls.Add(myControl);
			myPlaceHolder.Controls.Add(new LiteralControl(string.Format("</div>")));
			myPlaceHolder.Controls.Add(new LiteralControl("</div>"));
		}
		private static void AddWebControl2PlaceHolder(System.Web.UI.Page page, Data.CORE_tblWebControl myWebControl, PlaceHolder myPlaceHolder, string webControlName, string webControlCaption) 
		{
			if (myWebControl == null)
				throw new ApplicationException("WebUserControl was not found to be load. Please you have to register it in Olimpo CMS.");

			myPlaceHolder.Controls.Add(new LiteralControl(string.Format("<div id='WebControlDetail'>")));
			myPlaceHolder.Controls.Add(new LiteralControl(string.Format("<div id='{0}'>", myWebControl.CssClass)));

			if (!string.IsNullOrEmpty(myWebControl.Caption))
			{
				myPlaceHolder.Controls.Add(new LiteralControl(string.Format("<div id='WebControlHeader'>")));
				if (string.IsNullOrEmpty(webControlCaption))
					myPlaceHolder.Controls.Add(new LiteralControl(string.Format("{0}", myWebControl.Caption)));
				else
					myPlaceHolder.Controls.Add(new LiteralControl(string.Format("{0}", webControlCaption)));
				myPlaceHolder.Controls.Add(new LiteralControl(string.Format("</div>")));
			}

			string strWebControlPath = string.Format("{0}/{1}", myWebControl.WebControlPath, webControlName);
			Control myControl = page.Page.LoadControl(strWebControlPath);

			// if the WebControl to be loaded implements the IWebUserControl, then, we must pass the parameters defined in the structure
			if (IsIWebUserControl(myControl))
				SendParametersToWebUserControl(myWebControl.Parameters, myControl);

			//myControl.ID = string.Format("WebControl_{0}_{1}", myWebControl.Name, webControlName);
			myPlaceHolder.Controls.Add(myControl);
			myPlaceHolder.Controls.Add(new LiteralControl(string.Format("</div>")));
			myPlaceHolder.Controls.Add(new LiteralControl("</div>"));
		}
		private static bool IsIWebUserControl(Control myControl) 
		{
			return myControl is olimpo.Common.Interfaces.Web.IWebUserControl;
		}
		private static void SendParametersToWebUserControl(string parameters, Control myControl) 
		{
			if (!string.IsNullOrEmpty(parameters))
			{
				olimpo.Common.Interfaces.Web.IWebUserControl interfaceObject = (olimpo.Common.Interfaces.Web.IWebUserControl)myControl;
				interfaceObject.ReceiveParameters(parameters);
			}
		}
#endregion
	}
}
