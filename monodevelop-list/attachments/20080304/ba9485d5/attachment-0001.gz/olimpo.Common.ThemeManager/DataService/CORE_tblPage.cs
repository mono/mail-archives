// CORE_tblPage.cs created with MonoDevelop
// User: esqueleto at 6:07 PM 2/4/2008
//
// To change standard headers go to Edit->Preferences->Coding->Standard Headers
//

using System;
using olimpoTools.DataAccess;

namespace olimpo.Common.Theme.DataService
{
	public class CORE_tblPage
	{
#region Public Static Methods
		public static olimpo.Common.Theme.Data.CORE_tblPage GetPage (string pageName)
		{
			string sqlStatement = string.Format("SELECT * FROM CORE_tblPage WHERE Name = '{0}' and Available = '1'", pageName);
			
			if (olimpo.Common.Globals.DebugMode) System.Console.WriteLine(string.Format("GetPage with SQLStatement {0}", sqlStatement));
			
			DataPersistency<Theme.Data.CORE_tblPage> dalPage = new DataPersistency<olimpo.Common.Theme.Data.CORE_tblPage>();
			olimpo.Common.Theme.Data.CORE_tblPage pageAUX = dalPage.GetObject(sqlStatement);
			
			if (pageAUX == null)
				throw new ApplicationException(string.Format("Olimpo Error: Cannot find the page {0} on the Olimpo database.", pageName));
			else
				return pageAUX;
			
			return pageAUX;
		}
#endregion
	}
}
