using System;
using System.Collections.Generic;
using olimpoTools.DataAccess;

namespace olimpo.Common.Theme.DataService
{
	public class CORE_tblWebControl
	{
#region Public Static Methods
		public static System.Collections.Generic.ICollection<Data.CORE_tblWebControl> GetWebUserControls(int pageID)
		{
			string sqlStatement = string.Format("SELECT * FROM CORE_tblWebControl WHERE PageID = {0} ORDER BY WebControlOrder", pageID.ToString());
			DataPersistency<Data.CORE_tblWebControl> dalWebControl = new DataPersistency<Data.CORE_tblWebControl>();
			return dalWebControl.GetObjects(sqlStatement);
		}
#endregion
	}
}
