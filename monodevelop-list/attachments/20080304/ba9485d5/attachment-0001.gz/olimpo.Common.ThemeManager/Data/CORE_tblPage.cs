using System;
using olimpoTools.DataAccess;

namespace olimpo.Common.Theme.Data
{
	[Table("CORE_tblPage")]
	public class CORE_tblPage
	{
		#region Private Fields
		private int _pageID;
		private string _name;
        private string _title;
		private string _masterPageFile;
		private string _theme;
		private string _targetPlaceHolder;
		private bool _available;
		#endregion
		
		#region Public Properties
		[IsIdentity, IsPrimaryKey]
		public int PageID
		{
			get { return _pageID; }
			set { _pageID = value; }
		}
		public string Name
		{
			get { return _name; }
			set { _name = value; }
		}
        public string Title
        {
            get { return _title; }
            set { _title = value; }
        }
	
		public string Theme
		{
			get { return _theme; }
			set { _theme = value; }
		}
		public string MasterPageFile
		{
			get { return _masterPageFile; }
			set { _masterPageFile = value; }
		}
		public string TargetPlaceHolder
		{
			get { return _targetPlaceHolder; }
			set { _targetPlaceHolder = value; }
		}
		public bool Available
		{
			get { return _available; }
			set { _available = value; }
		}
		#endregion		
	}
}
