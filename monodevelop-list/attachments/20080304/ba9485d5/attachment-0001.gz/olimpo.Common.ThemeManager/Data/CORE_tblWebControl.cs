using System;
using olimpoTools.DataAccess;

namespace olimpo.Common.Theme.Data
{
	[Table("CORE_tblWebControl")]
	public class CORE_tblWebControl
	{
		#region Private Fields
		private int _webControlID;
		private string _name;
		private string _caption;
		private int _pageID;
		private string _placeHolder;
		private string _webControlPath;
		private int _webControlOrder;
		private string _cssClass;
		private string _parameters;
		private int _aclID;
		#endregion
		
		#region Public Properties
		public int WebControlID
		{
			get { return _webControlID; }
			set { _webControlID = value; }
		}
		public string Name
		{
			get { return _name; }
			set { _name = value; }
		}
		public string Caption
		{
			get { return _caption; }
			set { _caption = value; }
		}
		public int PageID
		{
			get { return _pageID; }
			set { _pageID = value; }
		}
		public string PlaceHolder
		{
			get { return _placeHolder; }
			set { _placeHolder = value; }
		}
		public string WebControlPath
		{
			get { return _webControlPath; }
			set { _webControlPath = value; }
		}
		public int WebControlOrder
		{
			get { return _webControlOrder; }
			set { _webControlOrder = value; }
		}
		[IsNullable]
		public string CssClass
		{
			get { return _cssClass; }
			set { _cssClass = value; }
		}
		[IsNullable]
		public string Parameters
		{
			get { return _parameters; }
			set { _parameters = value; }
		}
		[IsNullable]
		public int AclID
		{
			get { return _aclID; }
			set { _aclID = value; }
		}
		#endregion
	}
}
