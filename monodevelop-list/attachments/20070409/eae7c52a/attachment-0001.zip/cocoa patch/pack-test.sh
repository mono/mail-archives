#!/bin/sh

echo Creating OS X bundle...

if [ -e "MonoDevelop.app" ]; then
    rm -rf MonoDevelop.app
fi

macpack -m:2 -n:MonoDevelop -o:. -a:bin/MonoDevelop.exe -r:bin -r:AddIns -r:/Library/Frameworks/Mono.framework/Versions/Current/lib/libintl.dylib -r:monodevelop.nib -r:../Core/src/MonoDevelop.Ide/icons/SplashScreen.png

rm -rf MonoDevelop.app/Contents/Resources/MonoDevelop.exe

SCRIPT="MonoDevelop.app/Contents/MacOS/MonoDevelop"

mv $SCRIPT .
sed 's/\(.*\)\$ASSEMBLY/\1\.\/bin\/\$ASSEMBLY/' MonoDevelop > $SCRIPT
chmod +x $SCRIPT

rm MonoDevelop

echo -----
echo Creation complete!