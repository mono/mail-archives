//
// GuidGenerate.cs: Defines add-in commands and handlers.
//
// Author:
//   Sorin Peste (neaorin@gmail.com)
//
// Copyright (C) 2006 
// 
using System;
using MonoDevelop.Components.Commands;

namespace GuidGenerateAddIn
{

	public enum GenerateGuidCommands { GenerateGuid	}

		
	public class GuidGenerateHandler : CommandHandler 
	{
		
		protected override void Run()
		{
			GuidDialog dialog = new GuidDialog ();
			dialog.Show ();
		}
	}
}
