//
// GuidDialog.cs: Generate Guid dialog window.
//
// Author:
//   Sorin Peste (neaorin@gmail.com)
//
// Copyright (C) 2006 
// 

using System;
using Gtk;

namespace GuidGenerateAddIn
{
	
	
	public class GuidDialog : Gtk.Dialog
	{
		protected Gtk.Button buttonClose;
		protected Gtk.Button buttonNew;
		protected Gtk.Button buttonCopy;
		
		private Guid current_guid;
		protected Gtk.Label label2;
		protected Gtk.ComboBox comboboxType;
		
		public GuidDialog()
		{
			Stetic.Gui.Build(this, typeof(GuidGenerateAddIn.GuidDialog));
			buttonClose.Clicked +=	new EventHandler (CloseDialog);
			buttonNew.Clicked +=	new EventHandler (NewGuid);
			buttonCopy.Clicked +=	new EventHandler (CopyGuid);
			comboboxType.Changed +=	new EventHandler (TypeChange);
			
			CreateNewGuid ();
		}
		
		private string GuidText {
			get {
				string format = String.Empty;
				switch (comboboxType.Active) {
				case 0: format = "D"; break; 
				case 1: format = "B"; break; 
				case 2: format = "P"; break; 
				case 3: format = "N"; break; 						
				}
				return current_guid.ToString(format);
			}
		}
		
		private void CreateNewGuid () 
		{
			current_guid = Guid.NewGuid();
			label2.Text = "<b>" + GuidText + "</b>";
			label2.UseMarkup = true;
		}
		
		private void CloseDialog(object obj, EventArgs args)
		{
			this.Destroy ();
		}
		
		private void NewGuid(object obj, EventArgs args)
		{
			CreateNewGuid ();
		}
		
		private void TypeChange(object obj, EventArgs args)
		{
			label2.Text = "<b>" + GuidText + "</b>";
			label2.UseMarkup = true;			
		}		
		
		private void CopyGuid(object obj, EventArgs args)
		{
			Gtk.Clipboard clipboard = Gtk.Clipboard.Get (
				Gdk.Atom.Intern ("CLIPBOARD", true));
			clipboard.Text = GuidText;
			
		}
		
	}
}
