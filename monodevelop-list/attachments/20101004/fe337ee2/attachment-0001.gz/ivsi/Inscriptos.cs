using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public class Inscripto
{
    //esta clase encapsula los datos de un Inscripto
    private int _Id;
    private String _Nombre;
    private String _TipoIns;
    private int _Ruip;
    private int _Tipdoc;
    private int _Nrodoc;
    private DateTime _Nacimiento;
    private int _Localidad;
    private int _Profesion;
    private int _SLaboral;
    private int _Estudios;
   
	public Inscripto()
	{
	}
    public Inscripto(int _Id, String _TipoIns, int _Ruip, String _Nombre, int _Nrodoc, int _Tipdoc, DateTime _Nacimiento, int _Localidad, int _Profesion, int _SLaboral, int _Estudios)
    {
        
        this._Id = _Id;
        this._Nombre = _Nombre;
        this._TipoIns = _TipoIns;
        this._Ruip = _Ruip;
        this._Tipdoc = _Tipdoc;
        this._Nrodoc = _Nrodoc;
        this._Nacimiento = _Nacimiento;
        this._Localidad = _Localidad;
        this._Profesion = _Profesion;
        this._SLaboral = _SLaboral;
        this._Estudios = _Estudios;
      


    }
    public int Id
    {
        get { return _Id; }
        set { _Id = value; }
    }
    public String Nombre
    {
        get { return _Nombre; }
        set { _Nombre = value; }
    }
    public String TipoIns
    {
        get { return _TipoIns; }
        set { _TipoIns = value; }
    }
    public int Ruip
    {
        get { return _Ruip; }
        set { _Ruip = value; }
    }
   
    public int Tipdoc
    {
        get { return _Tipdoc; }
        set { _Tipdoc = value; }
    }
    public int Nrodoc
    {
        get { return _Nrodoc; }
        set { _Nrodoc = value; }
    }
    public int Profesion
    {
        get { return _Profesion; }
        set { _Profesion = value; }
    }
    public int SLaboral
    {
        get { return _SLaboral; }
        set { _SLaboral = value; }
    }
    public int Estudios
    {
        get { return _Estudios; }
        set { _Estudios = value; }
    }
    
   public DateTime Nacimiento
    {
        get { return _Nacimiento; }
        set { _Nacimiento = value; }
    }
    public int Localidad
    {
        get { return _Localidad; }
        set { _Localidad = value; }
    }

 }
