using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class dnleg : System.Web.UI.Page
{
    GestionNLegal gl = new GestionNLegal();
    GestionCNLeg cn = new GestionCNLeg();
    GestionTNleg tn = new GestionTNleg();
    Nlegal nleg;
	tnleg tleg;
    int nivel;
	bool alta;
	
    protected void Page_Load(object sender, EventArgs e)
    {   
		     if (this.Session["nivel"] == null) 
		        { this.Response.Redirect("Default.aspx");}
	         else 
		        {nivel = (Int16)this.Session["nivel"];}
    
		   
		       int id = int.Parse(Request["id"]);
		       if (id == 0)
		          { nleg = new Nlegal();}
		       else
		         { nleg = gl.GetNLegalById(id);}
		      
		
			       
        if (!this.IsPostBack)
        {
	
		     
            txtid.Text = Convert.ToString(id);
            txtid.Enabled = false;
                     
            DDLTipo.DataSource = tn.GetTNleg();
            DDLTipo.DataTextField = "nlegal";
            DDLTipo.DataValueField = "id";
            DDLTipo.SelectedIndex = Convert.ToInt32(nleg.Tipo);
            DDLTipo.DataBind();
            DDLTipo.Enabled = false;

            txtnro.Text = Convert.ToString(nleg.Nro);
            txtnro.Enabled = false;
            txtano.Text = Convert.ToString(nleg.Ano);
            txtano.Enabled = false;
            txtfecha.Text = nleg.Fecha.ToString("dd/MM/yyyy");
            txtfecha.Enabled = false;
			
			
            DDLConcept.DataSource = cn.GetCNleg();
            DDLConcept.DataTextField = "concepto";
            DDLConcept.DataValueField = "id";
            DDLConcept.SelectedIndex = Convert.ToInt32(nleg.Concepto);
            DDLConcept.DataBind();
            DDLConcept.Enabled = false;

            txtexpte.Text = Convert.ToString(nleg.Expte);
            txtexpte.Enabled = false;
			txtalcance.Text = Convert.ToString(nleg.Alc);
            txtalcance.Enabled = false;
			txtasunto.Text = Convert.ToString(nleg.Asunto);
			txtasunto.Enabled = false;
            txtparent.Text = Convert.ToString(nleg.ParentId);
            txtparent.Enabled = false;
                   
        }

    }
             
    protected bool valida()
    { 
        return true;
    }

    protected void cmdAlta_Click1(object sender, EventArgs e)
    {
        DDLTipo.Enabled = true;
		DDLTipo.Focus();
        DDLConcept.Enabled = true;
        txtnro.Enabled = true;
        txtexpte.Enabled = true;
		txtalcance.Enabled = true;
        txtasunto.Enabled = true;
        txtano.Enabled = true;
        txtfecha.Enabled = true;
		txtparent.Enabled = true;
		 alta = true;
		 ViewState["alta"] = alta;	
         msg.Text = "Alta";
    }
    protected void cmdBaja_Click1(object sender, EventArgs e)
    {
        if (gl.DeleteNLegal(nleg.Id))
            this.Response.Redirect("NLegal.aspx");
        else
            msg.Text = "No se ha podido eliminar.  Posiblemente posee registros asociados. Verifique!!!";
    }
    protected void cmdModif_Click1(object sender, EventArgs e)
    {
        DDLTipo.Enabled = true;
		DDLTipo.Focus();
        DDLConcept.Enabled = true;
        txtnro.Enabled = true;
        txtexpte.Enabled = true;
	    txtalcance.Enabled = true;
        txtasunto.Enabled = true;
        txtano.Enabled = true;
        txtfecha.Enabled = true;
		txtparent.Enabled = true;
		alta = false;
		ViewState["alta"] = alta;
        msg.Text = "Modificación";
    }
    protected void cmdGrabar_Click1(object sender, EventArgs e)
    {
        if (valida())
        {
            alta = (bool)ViewState["alta"];
			
			nleg.Tipo = Convert.ToInt16(DDLTipo.SelectedValue);
			nleg.Nro = Convert.ToInt32(txtnro.Text);
			nleg.Ano = Convert.ToInt16(txtano.Text);
			nleg.Fecha = Convert.ToDateTime(txtfecha.Text);
			nleg.Expte = txtexpte.Text;
			nleg.Alc = txtalcance.Text;
			nleg.Concepto = Convert.ToInt16(DDLConcept.SelectedValue);
			nleg.ParentId = Convert.ToInt32(txtparent.Text);
			nleg.Asunto = txtasunto.Text;
			
            if (!alta)
            {
                if (gl.UpdateNLegal(nleg))
                    this.Response.Redirect("NLegal.aspx");
                else
                    msg.Text = "No se ha podido actualizar. Verifique!!";
            }
            else
            {
                if (gl.GrabaNLegal(nleg))
                    this.Response.Redirect("NLegal.aspx");
                else
                    msg.Text = "No se ha podido dar el alta. Verifique!!";
            }
        }
    }
    protected void cmdCancel_Click1(object sender, EventArgs e)
    {
        this.Response.Redirect("NLegal.aspx");
    }
}
