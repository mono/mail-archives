using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class aregistro : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
       
    }
    protected void cmdCancelar_Click(object sender, EventArgs e)
    {
        this.Response.Redirect("Default.aspx");
    }
    protected void cmdGrabar_Click(object sender, EventArgs e)
    {
        String s = txtusr.Text;
        int n = s.Length;
        if (n > 0)
        {
            s = txtpwd.Text;
            n = s.Length;
            if ( n > 0) 
            {
            GestionUsuarios gusuarios = new GestionUsuarios();
            Usuario usr = gusuarios.IsRegistrado(txtusr.Text);
            Clave clv = new Clave();

            if (usr != null)
            {
                lblMsg.Text = "<b> Ya Existe ese Nick. Modifique!!! <b>";
            }
            else
            {
                int clave = String.Compare(txtpwd.Text, txtRptpwd.Text);
                if (clave == 0)
                {
                    s = clv.Encrypt(txtpwd.Text);
                    usr = new Usuario();
                    usr.Nick = txtusr.Text;
                    usr.Password = s;
                    usr.Nombre = txtNombre.Text;
                    usr.Apellido = txtApellido.Text;
                    usr.Email = txtEmail.Text;
                    usr.Telefono = txtTelefono.Text;
                    s = "";
                    //informa sobre el resultado de la operación
                    if (!gusuarios.GrabarUsuario(usr))
                        lblMsg.Text = "Grabación fallida. Consulte el administrador!";
                    else
                        lblMsg.Text = "El usuario se ha grabado correctamente";
                }
                else
                    lblMsg.Text = "La Clave y su repetición no son iguales. Verifique!!";
            }
            }
            else
                lblMsg.Text = "Debe Ingresar una Clave!!!.";
        }
        else
            lblMsg.Text = "Debe Ingresar un Nick!!!";
    }
}
