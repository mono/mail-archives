using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.IO;

public partial class locpy : System.Web.UI.Page
{
    GestionLocalidades gl = new GestionLocalidades();
    GestionBarrios gb = new GestionBarrios();
    BoundField gridColumn;
    HyperLinkField linkColumn;
    int loc;
    GestionPDF gpdf = new GestionPDF();
    DataTable tloc;
    String[] aField = new String[] { "id" };
    String sql,nom,comodin;
    int nivel,depto;
	Localidad Loca = new Localidad();
	
    protected void Page_Load(object sender, EventArgs e)
    {
             if (this.Session["nivel"] == null) 
		        { this.Response.Redirect("Default.aspx");}
	         else 
		        {
			      nivel = (Int16)this.Session["nivel"];
		          depto = (Int16)this.Session["depto"];
		        }


        if (!this.IsPostBack)
        {
          
         
           
        
        DDLloc.DataSource = gl.GetLocalidades();
        DDLloc.DataTextField = "localidad";
        DDLloc.DataValueField = "id";
        DDLloc.DataBind();

        gridColumn = new BoundField();
        gridColumn.DataField = "id";
        gridColumn.HeaderText = "ID";
        GVBarriosxLoc.Columns.Add(gridColumn);

        gridColumn = new BoundField();
        gridColumn.DataField = "sistema";
        gridColumn.HeaderText = "Sistema";
        GVBarriosxLoc.Columns.Add(gridColumn);

        gridColumn = new BoundField();
        gridColumn.DataField = "codigo";
        gridColumn.HeaderText = "Código";
        GVBarriosxLoc.Columns.Add(gridColumn);

        gridColumn = new BoundField();
        gridColumn.DataField = "plan";
        gridColumn.HeaderText = "Plan";
        GVBarriosxLoc.Columns.Add(gridColumn);


        gridColumn = new BoundField();
        gridColumn.DataField = "proyecto";
        gridColumn.HeaderText = "Proyecto";
        gridColumn.ItemStyle.Width = 500;
        GVBarriosxLoc.Columns.Add(gridColumn);

        linkColumn = new HyperLinkField();
        linkColumn.Text = "Adjudicatarios";
        linkColumn.NavigateUrl = "~\\adjxb.aspx";
        linkColumn.DataNavigateUrlFields = aField;
        linkColumn.DataNavigateUrlFormatString = "adjxb.aspx?id={0}";
        linkColumn.ItemStyle.Width = 30;
        GVBarriosxLoc.Columns.Add(linkColumn);


        if (nivel < 5 && depto == 99)
        {
            linkColumn = new HyperLinkField();
            linkColumn.Text = "ABM";
            linkColumn.NavigateUrl = "~\\dbarrio.aspx";
            linkColumn.DataNavigateUrlFields = aField;
            linkColumn.DataNavigateUrlFormatString = "dbarrio.aspx?id={0}";
            linkColumn.ItemStyle.Width = 30;
            GVBarriosxLoc.Columns.Add(linkColumn);

        }
        
        GVBarriosxLoc.AllowPaging = true;
      
        }
        nom = txtnombre.Text;
     
        if (nom == null)
        {
            nom = "*";
            comodin = "%";

        }
        else comodin = '%' + nom + '%';



        loc = int.Parse(DDLloc.SelectedValue);
	    Loca = gl.GetLocalidadById(loc);
        
		sql = "Select b.id,b.sistema,b.codigo,b.plan,b.proyecto";
	    sql += " from barrios as b join localidad as l on l.id = b.localidad";
	    sql += " where (b.proyecto ilike '" + comodin + "' and l.id = " + loc + ")";
     
		tloc = gb.GetBarrios(sql);
        GVBarriosxLoc.DataSource = tloc;
        GVBarriosxLoc.DataBind();
        

    }

    protected void GVBarriosxLoc_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GVBarriosxLoc.PageIndex = e.NewPageIndex;
        GVBarriosxLoc.DataSource = gb.GetBarrios(sql);
        GVBarriosxLoc.DataBind();
    }

    protected void GVBarriosxLoc_SelectedIndexChanged(object sender, EventArgs e)
    {
               
    }

   
    protected void Write()
    {
        MemoryStream m = new MemoryStream();
        Document doc = new Document();
        doc.SetMargins(50,50,50,50);
		
        try
        {
            Response.ContentType = "application/pdf";
	        PdfWriter writer = PdfWriter.GetInstance(doc, m);
            writer.CloseStream = false;
            Single[] width = { 30, 10, 30, 10, 100 };
			itsEvents ev = new itsEvents();
			writer.PageEvent = ev;
			ev.Header = Loca.Nombre.ToString();
			ev.tabla = tloc;
			ev.Width = width;
			doc.Open();
            PdfPTable tabla = gpdf.TablePDF(tloc);
            tabla.SetWidths(width);
            doc.Add(tabla);
            doc.Close();
        }
        catch (DocumentException ex)
        {
            Console.Error.WriteLine(ex.StackTrace);
            Console.Error.WriteLine(ex.Message);
        }
        // step 6: Write pdf bytes to outputstream
        Response.OutputStream.Write(m.GetBuffer(), 0, m.GetBuffer().Length);
        Response.OutputStream.Flush();
        Response.OutputStream.Close();
        m.Close();


    }
    
    protected void btBuscar_Click(object sender, EventArgs e)
    {

        if (tloc != null)
        {
            GVBarriosxLoc.DataSource = tloc;
            GVBarriosxLoc.DataBind();

        }

    }
    protected void BPrint_Click(object sender, EventArgs e)
    {
        if (tloc != null)
        {
            Write();
        }
    }
}
