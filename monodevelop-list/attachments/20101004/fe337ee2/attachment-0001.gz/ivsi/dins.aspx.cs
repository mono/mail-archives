using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class dins : System.Web.UI.Page
{
    GestionInscriptos gi = new GestionInscriptos();
    GestionLocalidades loc = new GestionLocalidades();
    GestionTipdoc td = new GestionTipdoc();
    Inscripto ins;
    int nivel;
	bool alta;
	
    protected void Page_Load(object sender, EventArgs e)
    {   
		     if (this.Session["nivel"] == null) 
		        { this.Response.Redirect("Default.aspx");}
	         else 
		        {nivel = (Int16)this.Session["nivel"];}
    
             int id = int.Parse(Request["id"]);
               
             Inscripto ins = gi.GetInscriptosById(id);

    
        if (!this.IsPostBack)
        {
			
                 
            txtid.Text = Convert.ToString(id);
            txtid.Enabled = false;
            txtDescr.Text = ins.Nombre;
            txtDescr.Enabled = false;
            
            DDLLoca.DataSource = loc.GetLocalidades();
            DDLLoca.DataTextField = "nombre";
            DDLLoca.DataValueField = "id";
            DDLLoca.SelectedIndex = Convert.ToInt32(ins.Localidad);
            DDLLoca.DataBind();
            DDLLoca.Enabled = false;

            txttipoins.Text = Convert.ToString(ins.TipoIns);
            txttipoins.Enabled = false;
            txtruip.Text = Convert.ToString(ins.Ruip);
            txtruip.Enabled = false;

            DDLtipdoc.DataSource = td.GetTipdoc();
            DDLtipdoc.DataTextField = "descripcion";
            DDLtipdoc.DataValueField = "id";
            DDLtipdoc.SelectedIndex = Convert.ToInt32(ins.Localidad);
            DDLtipdoc.DataBind();
            DDLtipdoc.Enabled = false;

            txtnrodoc.Text = Convert.ToString(ins.Nrodoc);
            txtnrodoc.Enabled = false;
            txtprofe.Text = Convert.ToString(ins.Profesion);
            txtprofe.Enabled = false;
            txtestudios.Text = Convert.ToString(ins.Estudios);
            txtestudios.Enabled = false;
            txtslaboral.Text = Convert.ToString(ins.SLaboral);
            txtslaboral.Enabled = false;
         


        
        }

    }
             
    protected bool valida()
    { 
        return true;
    }

    protected void cmdAlta_Click1(object sender, EventArgs e)
    {
      
        txtDescr.Enabled = true;
        txtDescr.Text = "";
        txtDescr.Focus();
        DDLLoca.Enabled = true;
        DDLtipdoc.Enabled = true;
        txtnrodoc.Enabled = true;
        txtprofe.Enabled = true;
        txtslaboral.Enabled = true;
        txtestudios.Enabled = true;
        txtIngresos.Enabled = true;
		alta = true;
		ViewState["alta"] = alta;
		
        msg.Text = "Alta";
    }
    protected void cmdBaja_Click1(object sender, EventArgs e)
    {
        int id = (int)this.Session["id"];
        if (gi.DeleteInscriptos(id))
            this.Response.Redirect("clocpy.aspx");
        else
            msg.Text = "No se ha podido eliminar.  Posiblemente posee registros asociados. Verifique!!!";
    }
    protected void cmdModif_Click1(object sender, EventArgs e)
    {
        txtDescr.Enabled = true;
        txtDescr.Focus();
        DDLLoca.Enabled = true;
        DDLtipdoc.Enabled = true;
        txtnrodoc.Enabled = true;
        txtprofe.Enabled = true;
        txtslaboral.Enabled = true;
        txtestudios.Enabled = true;
        txtIngresos.Enabled = true;
		alta = false;
		ViewState["alta"] = alta;
		
        msg.Text = "Modificación";
    }
    protected void cmdGrabar_Click1(object sender, EventArgs e)
    {
        if (valida())
        {
            ins.Nombre = txtDescr.Text;
            string descr = txtDescr.Text.ToString();

            bool alta = (bool)ViewState["alta"];
			
            if (!alta)
            {
                if (gi.UpdateInscriptos(ins))
                    this.Response.Redirect("cins.aspx");
                else
                    msg.Text = "No se ha podido actualizar. Verifique!!";
            }
            else
            {
                if (gi.GrabaInscriptos(ins))
                    this.Response.Redirect("cins.aspx");
                else
                    msg.Text = "No se ha podido dar el alta. Verifique!!";
            }
        }
    }
    protected void cmdCancel_Click1(object sender, EventArgs e)
    {
        this.Response.Redirect("cins.aspx");
    }
}
