using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for Observa
/// </summary>
public class UndIns
{
  
    private long _Unidad;
    private long _IdIns;
   
	public UndIns()
	{
	}
     public UndIns(long _Unidad, long _IdIns)
    {
        this._Unidad = _Unidad;
        this._IdIns = _IdIns;
    }
    public long Unidad
    {
        get { return _Unidad; }
        set { _Unidad = value; }
    }
    public long IdIns
    {
        get { return _IdIns; }
        set { _IdIns = value; }
    }
    
}
