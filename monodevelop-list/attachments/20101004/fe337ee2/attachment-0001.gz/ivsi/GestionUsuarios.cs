using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Npgsql;

public class GestionUsuarios
{
    private String sql;

	public GestionUsuarios()
	{
	}
  
    
    private DataTable GetTabla(String Name, String Sql)
    {
        //crea un objeto DataTable con el nombre
        //especificado a partir de la instrucci�n
        //Select indicada
        DataSet ds = new DataSet();
        Data datos = new Data();
        NpgsqlDataAdapter adp = datos.getAdapter(Sql);
        adp.Fill(ds, Name);
        return ds.Tables[Name];

    }

    public DataTable GetUsuarioByNick(String nick)
    {
        if (nick == null)
            nick = "*";

        sql = "SELECT nick,nombre,apellido,email,telefono ";
        sql += "FROM usuarios ";
        sql += "WHERE nick ILIKE '" + '%' + nick + "%'";

        return GetTabla("linea", sql);
    }

    public bool GrabarUsuario(Usuario usr)
    {
        //Si el usuario se puede registrar
        //devolver� true, sino devolver� false
        Data datos = new Data();
        NpgsqlConnection cn=datos.GetConnection();
        //realiza la operaci�n si se ha conseguido
        //una conexi�n. 
        if (cn != null)
         {
            //utiliza el modo conectado pues es una
            //actualizaci�n puntual
            NpgsqlCommand cmd;
            String sql = "Insert into usuarios values(";
            sql += "'" + usr.Nick + "',";
            sql += "'" + usr.Nombre + "',";
            sql += "'" + usr.Apellido + "',";
            sql += "'" + usr.Email + "',";
            sql += "'" + usr.Telefono + "',";
            sql += "'" + usr.Password + "')";
            cmd = new NpgsqlCommand(sql, cn);
            try
            {
                cmd.ExecuteNonQuery();
                return true;
            }
            catch 
            {
                return false;
            }
            finally
            {
                cn.Close();
            }
        }
        else
            return false;
    }

    public bool UpdateUsuario(Usuario usr)
    { //Si el usuario se puede registrar
        //devolver� true, sino devolver� false
        Data datos = new Data();
        NpgsqlConnection cn = datos.GetConnection();
        //realiza la operaci�n si se ha conseguido
        //una conexi�n. 
        if (cn != null)
        {
            //utiliza el modo conectado pues es una
            //actualizaci�n puntual
            NpgsqlCommand cmd;
            String sql = "Update usuarios SET ";
            sql += "nombre = '" + usr.Nombre + "',";
            sql += "apellido = '" + usr.Apellido + "',";
            sql += "email = '" + usr.Email + "',";
            sql += "telefono = '" + usr.Telefono + "'," ;
            sql += "password = '" + usr.Password + "'";
            sql += " Where nick = '" + usr.Nick + "'";
            cmd = new NpgsqlCommand(sql, cn);
            try
            {
                cmd.ExecuteNonQuery();
                return true;
            }
            catch
            {
                return false;
            }
            finally
            {
                cn.Close();
            }
        }
        else
            return false;
    }    
    public Usuario IsRegistrado(String user)
    {
        //utiliza el modo conectado, pues es una consulta
        //puntual
        Data datos = new Data();
        NpgsqlConnection cn=datos.GetConnection();
        NpgsqlCommand cmd;
        NpgsqlDataReader dr;
        String sql = "Select * From usuarios Where nick = '" + user + "'";
        //realiza la operaci�n si se ha conseguido
        //una conexi�n
        if (cn != null)
        {
           try
                {
                cmd = new NpgsqlCommand(sql, cn);
                dr = cmd.ExecuteReader();
                 
                if (dr.Read())
                    {
                    Usuario usr = new Usuario();

                    usr.Nick = (String)dr["nick"];
                    usr.Password = (String)dr["password"];
                    usr.Nombre = (String)dr["nombre"];
                    usr.Apellido = (String)dr["apellido"];
                    usr.Email = (String)dr["email"];
                    usr.Telefono = (String)dr["telefono"];
                    usr.Nivel = (Int16)dr["nivel"];
					usr.Depto = (Int16)dr["depto"];
                    return usr;
                    }
                 else
                    return null;
                 }
            catch
               {
                   return null;
               }
            finally
               {
                   cn.Close();
               }
        }
        else
            return null;
    }
}
