using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for Linea
/// </summary>
public class Remesas
{
    private long _id;
    private byte _ctacte;
    private long _hoja;
    private DateTime _fecha;
    private long _sucursal;
    private int _cupones;
    private decimal _importe;
    private String _marca;
    private long _nc;
    private byte _sistema;

	public Remesas()
	{
    }
     public Remesas(long _id, byte _ctacte, long _hoja, DateTime _fecha, long _sucursal, int _cupones, decimal _importe, String _marca, long _nc, byte _sistema)
    {
        this._id = _id;
        this._ctacte = _ctacte;
        this._hoja = _hoja;
        this._fecha = _fecha;
        this._sucursal = _sucursal;
        this._cupones = _cupones;
        this._importe = _importe;
        this._marca = _marca;
        this._nc = _nc;
        this._sistema = _sistema;
    }
    public long Id
    {
        get { return _id; }
        set { _id = value; }
    }
    public byte ctacte
    {
        get { return _ctacte; }
        set { _ctacte = value; }
    }
    public long hoja
    {
        get { return _hoja; }
        set { _hoja = value; }
    }
    public DateTime fecha
    {
        get { return _fecha; }
        set { _fecha = value; }
    }
    public long sucursal
    {
        get { return _sucursal; }
        set { _sucursal = value; }
    }
    public int cupones
    {
        get { return _cupones; }
        set { _cupones = value; }
    }
    public decimal importe
    {
        get { return _importe; }
        set { _importe = value; }
    }
    public String marca
    {
        get { return _marca; }
        set { _marca = value; }
    }
    public long nc
    {
        get { return _nc; }
        set { _nc = value; }
    }
    public byte sistema
    {
        get { return _sistema; }
        set { _sistema = value; }
    }
}
