using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public class Nlegal
{
    //esta clase encapsula los datos de la norma legal
    private Int32 _id;
    private Int16 _tipo;
    private Int32 _nro;
    private Int16 _ano;
    private DateTime _fecha;
    private String _asunto;
    private Int32 _parentid;
	private String _expte;
	private String _alc;
	private Int16 _concepto;
		
    public Nlegal()
    {
    }
	
    public Nlegal(Int32 _id, Int16 _tipo, Int32 _nro, Int16 _ano, DateTime _fecha, String  _asunto, Int32 _parentid, String _expte,String _alc,Int16 _concepto)
    {
        this._id = _id;
        this._tipo = _tipo;
        this._nro = _nro;
        this._ano = _ano;
        this._fecha = _fecha;
        this._asunto = _asunto;
        this._parentid = _parentid;
		this._expte = _expte;
		this._alc = _alc;
		this._concepto = _concepto;
    }
    public Int32 Id
    {
        get { return _id; }
        set { _id = value; }
    }
    public Int16 Tipo
    {
        get { return _tipo; }
        set { _tipo = value; }
    }
    public Int32 Nro
    {
        get { return _nro; }
        set { _nro = value; }
    }
    public Int16 Ano
    {
        get { return _ano; }
        set { _ano = value; }
    }
    public DateTime Fecha
    {
        get { return _fecha; }
        set { _fecha = value; }
    }
    public String Asunto
    {
        get { return _asunto; }
        set { _asunto = value; }
    }
    public Int32 ParentId
    {
        get { return _parentid; }
        set { _parentid = value; }
    }
    public String Expte
    {
        get { return _expte; }
        set { _expte = value; }
    }
	 public String Alc
    {
        get { return _alc; }
        set { _alc = value; }
    }
	public Int16 Concepto
    {
        get { return _concepto; }
        set { _concepto = value; }
    }
	
}
