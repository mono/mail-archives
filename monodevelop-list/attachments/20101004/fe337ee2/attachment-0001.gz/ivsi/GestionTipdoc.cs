using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Npgsql;

/// <summary>
/// Summary description for GestionBarrios
/// </summary>
public class GestionTipdoc
{
	public GestionTipdoc()
	{
	}

    private DataTable GetTabla(String Name, String Sql)
    {
        //crea un objeto DataTable con el nombre
        //especificado a partir de la bartrucci�n
        //Select indicada
        DataSet ds = new DataSet();
        Data datos = new Data();
        NpgsqlDataAdapter adp = datos.getAdapter(Sql);
        adp.Fill(ds, Name);
        return ds.Tables[Name];

    }

    public DataTable GetTipdoc()
    {
        return GetTabla("tipdoc", "Select * From tipdoc");
    }

    public bool GrabaTipdoc(Tipdoc td)
    {
        Data datos = new Data();
        NpgsqlConnection cn = datos.GetConnection();
        //realiza la operaci�n si se ha conseguido
        //una conexi�n. 
        if (cn != null)
        {
            //utiliza el modo conectado pues es una
            //actualizaci�n puntual
            NpgsqlCommand cmd;
            String sql = "Insert into tipdoc values(";
            sql += "'" + td.Id + "'";
            sql += "'" + td.TipDoc + "')";
            cmd = new NpgsqlCommand(sql, cn);
            try
            {
                cmd.ExecuteNonQuery();
                return true;
            }
            catch
            {
                return false;
            }
            finally
            {
                cn.Close();
            }
        }
        else
            return false;
    }

    public bool UpdateTipdoc(Tipdoc td)
    {
        Data datos = new Data();
        NpgsqlConnection cn = datos.GetConnection();
        //realiza la operaci�n si se ha conseguido
        //una conexi�n. 
        if (cn != null)
        {
            //utiliza el modo conectado pues es una
            //actualizaci�n puntual
            NpgsqlCommand cmd;
            String sql = "Update tipdoc SET ";
            sql += "'" + td.TipDoc + "'";
            sql += " Where id = " + td.Id;
            cmd = new NpgsqlCommand(sql, cn);
            try
            {
                cmd.ExecuteNonQuery();
                return true;
            }
            catch
            {
                return false;
            }
            finally
            {
                cn.Close();
            }
        }
        else
            return false;
    }

    public bool DeleteTipdoc(int id)
    {
        Data datos = new Data();
        NpgsqlConnection cn = datos.GetConnection();
        //realiza la operaci�n si se ha conseguido
        //una conexi�n. 
        if (cn != null)
        {
            //utiliza el modo conectado pues es una
            //actualizaci�n puntual
            NpgsqlCommand cmd;
            String sql = "DELETE FROM tipdoc ";
            sql += " Where id = " + id;
            cmd = new NpgsqlCommand(sql, cn);
            try
            {
                cmd.ExecuteNonQuery();
                return true;
            }
            catch
            {
                return false;
            }
            finally
            {
                cn.Close();
            }
        }
        else
            return false;
    }

    public Tipdoc GetTipdocById(int id)
    {
        Data datos = new Data();
        NpgsqlConnection con = datos.GetConnection();
        NpgsqlDataReader dr;
        String sql = "Select * From tipdoc Where id = " + id;
        //realiza la operaci�n si se ha conseguido
        //una conexi�n
        if (con != null)
        {
            NpgsqlCommand cmd = new NpgsqlCommand(sql, con);
            try
            {
                dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                   Tipdoc ag = new Tipdoc((int)dr["id"],
                                        (String)dr["descripcion"]);

                    return ag;
                }
                else
                    return null;
            }
            catch
            {
                return null;
            }
            finally
            {
                con.Close();
            }
        }
        else
            return null;

    }
}
