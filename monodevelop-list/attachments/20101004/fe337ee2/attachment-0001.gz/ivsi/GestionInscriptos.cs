using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Npgsql;

/// <summary>
/// Summary description for GestionInscriptos
/// </summary>
public class GestionInscriptos
{
    
	public GestionInscriptos()
	{
	}

    private DataTable GetTabla(String Name, String Sql)
    {
        //crea un objeto DataTable con el nombre
        //especificado a partir de la instrucci�n
        //Select indicada
        DataSet ds = new DataSet();
        Data datos = new Data();
        NpgsqlConnection cn = datos.GetConnection();
        //realiza la operaci�n si se ha conseguido
        //una conexi�n. 
        if (cn != null)
        {
        NpgsqlDataAdapter adp = new NpgsqlDataAdapter();
        adp = datos.getAdapter(Sql);
        adp.Fill(ds, Name);
        return ds.Tables[Name];
        }
        else return null; 
    }

    public DataTable GetInscriptos(String den)
    {
        String comodin;
        if (den.Length == 0)
        {
           comodin = "%";
        }
        else comodin = '%' + den + '%';
      
		NpgsqlDataReader dr;
	    DataTable dt = new DataTable();
		Data datos = new Data();
		NpgsqlConnection conn = datos.GetConnection();
		
		if (conn != null)
		{
	//		try 
			{
      	       NpgsqlCommand cmd = new NpgsqlCommand("getins", conn);
               cmd.CommandType = System.Data.CommandType.StoredProcedure;
			   cmd.Parameters.Add(new NpgsqlParameter("nombre",NpgsqlTypes.NpgsqlDbType.Varchar));
			   cmd.Prepare();
		       cmd.Parameters[0].Value = comodin;
			   dr = cmd.ExecuteReader();
			   dt.Load(dr);
               return dt;
			}
	  //      catch
            {
      //          return null;
            }
     //       finally
            {
      //          conn.Close();
            }
		}
		else return null;
    }
    
    public bool GrabaInscriptos(Inscripto ins)
    {
        Data datos = new Data();
        NpgsqlConnection cn = datos.GetConnection();
        //realiza la operaci�n si se ha conseguido
        //una conexi�n. 
        if (cn != null)
        {
            //utiliza el modo conectado pues es una
            //actualizaci�n puntual
            NpgsqlCommand cmd;
            String sql = "Insert into inscriptos values(";
            sql += "'" + ins.TipoIns + "',";
            sql += "'" + ins.Ruip + "',";
            sql += "'" + ins.Nombre + "',";
            sql += "'" + ins.Nrodoc + "',";
            sql += "'" + ins.Tipdoc + "',";
            sql += "'" + ins.Nacimiento + "',";
            sql += "'" + ins.Localidad + "',";
            sql += "'" + ins.Profesion + "',";
            sql += "'" + ins.SLaboral + "',";
            sql += "'" + ins.Estudios + "')";
            cmd = new NpgsqlCommand(sql, cn);
            try
            {
                cmd.ExecuteNonQuery();
                return true;
            }
            catch
            {
                return false;
            }
            finally
            {
                cn.Close();
            }
        }
        else
            return false;
    }

    public bool UpdateInscriptos(Inscripto ins)
    {
        Data datos = new Data();
        NpgsqlConnection cn = datos.GetConnection();
        //realiza la operaci�n si se ha conseguido
        //una conexi�n. 
        if (cn != null)
        {
            //utiliza el modo conectado pues es una
            //actualizaci�n puntual
            NpgsqlCommand cmd;
            String sql = "Update inscriptos SET ";
            sql += "'" + ins.TipoIns + "',";
            sql += "'" + ins.Ruip + "',";
            sql += "'" + ins.Nombre + "',";
            sql += "'" + ins.Nrodoc + "',";
            sql += "'" + ins.Tipdoc + "',";
            sql += "'" + ins.Nacimiento + "',";
            sql += "'" + ins.Localidad + "',";
            sql += "'" + ins.Profesion + "',";
            sql += "'" + ins.SLaboral + "',";
            sql += "'" + ins.Estudios + "'";
            sql += " Where id = " + ins.Id;
            cmd = new NpgsqlCommand(sql, cn);
            try
            {
                cmd.ExecuteNonQuery();
                return true;
            }
            catch
            {
                return false;
            }
            finally
            {
                cn.Close();
            }
        }
        else
            return false;
    }

    public bool DeleteInscriptos(int id)
    {
        Data datos = new Data();
        NpgsqlConnection cn = datos.GetConnection();
        //realiza la operaci�n si se ha conseguido
        //una conexi�n. 
        if (cn != null)
        {
            //utiliza el modo conectado pues es una
            //actualizaci�n puntual
            NpgsqlCommand cmd;
            String sql = "DELETE FROM inscriptos ";
            sql += " Where id = " + id;
            cmd = new NpgsqlCommand(sql, cn);
            try
            {
                cmd.ExecuteNonQuery();
                return true;
            }
            catch
            {
                return false;
            }
            finally
            {
                cn.Close();
            }
        }
        else
            return false;
    }

    public Inscripto GetInscriptosById(int id)
    {
        Data datos = new Data();
        NpgsqlConnection con = datos.GetConnection();
        NpgsqlDataReader dr;
        String sql = "Select * From inscriptos Where id = " + id;
        //realiza la operaci�n si se ha conseguido
        //una conexi�n
        if (con != null)
        {
            NpgsqlCommand cmd = new NpgsqlCommand(sql, con);
            try
            {
                dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    Inscripto ag = new Inscripto();
                                        
                    ag.Id = (int)dr["id"];
                    ag.Nombre = (String)dr["nombre"];
                    ag.TipoIns = (String)dr["tipoins"];
                    ag.Ruip = (int)dr["ruip"];
                    ag.Tipdoc = (Int16)(dr["tipdoc"]);
                    ag.Nrodoc = (int)dr["nrdoc"];
                    ag.Nacimiento = (DateTime)dr["nacimiento"];
                    ag.Localidad = (int)dr["localidad"];
                    ag.Profesion = (Int16)dr["profesion"];
                    ag.SLaboral = (Int16)dr["slaboral"];
                    ag.Estudios = (Int16)dr["estudios"];

                    return ag;
                }
                else
                    return null;
            }
            catch
            {
                return null;
            }
            finally
            {
                con.Close();
            }
        }
        else
            return null;

    }
}
