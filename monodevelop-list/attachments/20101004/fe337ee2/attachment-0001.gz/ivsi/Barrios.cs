using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for Linea
/// </summary>
public class Barrio
{
    private Int32 _id;
    private Int16 _Sistema;
    private String _Codigo;
    private Int16 _Plan;
    private int _Localidad;
    private String _Proyecto;

	public Barrio()
	{
    }
     public Barrio(int _id, Int16 _Sistema, String _Codigo, Int16 _Plan, int _Localidad, String _Proyecto)
    {
        this._id = _id;
        this._Sistema = _Sistema;
        this._Codigo = _Codigo;
        this._Plan = _Plan;
        this._Localidad = _Localidad;
        this._Proyecto = _Proyecto;
    }
    public Int32 Id
    {
        get { return _id; }
        set { _id = value; }
    }
    public Int16 Sistema
    {
        get { return _Sistema; }
        set { _Sistema = value; }
    }
    public String Codigo
    {
        get { return _Codigo; }
        set { _Codigo = value; }
    }
    public Int16 Plan
    {
        get { return _Plan; }
        set { _Plan = value; }
    }
    public int Localidad
    {
        get { return _Localidad; }
        set { _Localidad = value; }
    }
    public String Proyecto
    {
        get { return _Proyecto; }
        set { _Proyecto = value; }
    }
  
}
