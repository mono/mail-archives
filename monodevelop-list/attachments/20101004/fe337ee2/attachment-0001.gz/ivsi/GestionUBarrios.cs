using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Npgsql;

/// <summary>
/// Summary description for GestionBarrios
/// </summary>
public class GestionUBarrios
{
	public GestionUBarrios()
	{
	}

    private DataTable GetTabla(String Name, String Sql)
    {
        //crea un objeto DataTable con el nombre
        //especificado a partir de la bartrucci�n
        //Select indicada
        DataSet ds = new DataSet();
        Data datos = new Data();
        NpgsqlDataAdapter adp = datos.getAdapter(Sql);
        adp.Fill(ds, Name);
        return ds.Tables[Name];

    }

    public DataTable GetUBarrios(String sql)
    {
        return GetTabla("unidbarrio", sql);
    }

    public bool GrabaUBarrios(UBarrios ubar)
    {
        Data datos = new Data();
        NpgsqlConnection cn = datos.GetConnection();
        //realiza la operaci�n si se ha conseguido
        //una conexi�n. 
        if (cn != null)
        {
            //utiliza el modo conectado pues es una
            //actualizaci�n puntual
            NpgsqlCommand cmd;
			String serial = "nextval('unidbarrio_id_seq')";
            String sql = "Insert into unidbarrio values(";
			sql += serial + ",";
            sql += "'" + ubar.Barrio + "',";
            sql += "'" + ubar.Mza + "',";
            sql += "'" + ubar.Lote + "',";
            sql += "'" + ubar.Mono + "',";
		    sql += "'" + ubar.Puerta + "',";
            sql += "'" + ubar.Piso + "',";
            sql += "'" + ubar.Depto + "',";
            sql += "'" + ubar.Tipvi + "',";
			sql += "'" + ubar.Calle + "',";
			sql += "'" + ubar.Nro + "',";
			sql += "'" + ubar.NC + "')";
            cmd = new NpgsqlCommand(sql, cn);
            try
            {
                cmd.ExecuteNonQuery();
                return true;
            }
            catch
            {
                return false;
            }
            finally
            {
                cn.Close();
            }
        }
        else
            return false;
    }

    public bool UpdateUBarrios(UBarrios ubar)
    {
        Data datos = new Data();
        NpgsqlConnection cn = datos.GetConnection();
        //realiza la operaci�n si se ha conseguido
        //una conexi�n. 
        if (cn != null)
        {
            //utiliza el modo conectado pues es una
            //actualizaci�n puntual
            NpgsqlCommand cmd;
            String sql = "Update unidbarrio SET ";
			sql += "barrio = ";
            sql += "'" + ubar.Barrio + "',";
			sql += "mza = ";
	        sql += "'" + ubar.Mza + "',";
			sql += "lote = ";
	        sql += "'" + ubar.Lote + "',";
			sql += "mono = ";
            sql += "'" + ubar.Mono + "',";
			sql += "puerta = ";
			sql += "'" + ubar.Puerta + "',";
			sql += "piso = ";
            sql += "'" + ubar.Piso + "',";
			sql += "depto = ";
            sql += "'" + ubar.Depto + "',";
			sql += "tipvi = ";
            sql += "'" + ubar.Tipvi + "',";
			sql += "calle = ";
			sql += "'" + ubar.Calle + "',";
			sql += "nro = ";
			sql += "'" + ubar.Nro + "',";
			sql += "nc = ";
		    sql += "'" + ubar.NC + "'";
            sql += " Where id = " + ubar.Id ;
            cmd = new NpgsqlCommand(sql, cn);
            try
            {
                cmd.ExecuteNonQuery();
                return true;
            }
            catch
            {
                return false;
            }
            finally
            {
                cn.Close();
            }
        }
        else
            return false;
    }

    public bool DeleteUBarrios(int id)
    {
        Data datos = new Data();
        NpgsqlConnection cn = datos.GetConnection();
        //realiza la operaci�n si se ha conseguido
        //una conexi�n. 
        if (cn != null)
        {
            //utiliza el modo conectado pues es una
            //actualizaci�n puntual
            NpgsqlCommand cmd;
            String sql = "DELETE FROM unidbarrio ";
            sql += " Where id = " + id;
            cmd = new NpgsqlCommand(sql, cn);
            try
            {
                cmd.ExecuteNonQuery();
                return true;
            }
            catch
            {
                return false;
            }
            finally
            {
                cn.Close();
            }
        }
        else
            return false;
    }

    public UBarrios GetUBarriosById(int id)
    {
        Data datos = new Data();
        NpgsqlConnection con = datos.GetConnection();
        NpgsqlDataReader dr;
        String sql = "Select * From unidbarrio Where id = " + id;
        //realiza la operaci�n si se ha conseguido
        //una conexi�n
        if (con != null)
        {
            NpgsqlCommand cmd = new NpgsqlCommand(sql, con);
            try
            {
                dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    UBarrios ub = new UBarrios();
					ub.Id = (Int32)dr["id"];
					ub.Barrio= (Int32)dr["barrio"];
					ub.Mza = (String)dr["mza"];
					ub.Lote = (String)dr["lote"];
					ub.Mono = (String)dr["mono"];
					ub.Puerta = (String)dr["puerta"];
					ub.Piso = (String)dr["piso"];
					ub.Depto = (String)dr["depto"];
					ub.Tipvi = (Int16)dr["tipvi"];
					ub.Calle = (String)dr["calle"];
					ub.Nro = (Int32)dr["nro"];
					ub.NC = (String)dr["nc"];
                    return ub;
                }
                else
                    return null;
            }
            catch
            {
                return null;
            }
            finally
            {
               con.Close();
            }
        }
        else
            return null;

    }
}
