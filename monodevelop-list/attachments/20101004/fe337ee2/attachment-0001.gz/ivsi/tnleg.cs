using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for Observa
/// </summary>
public class tnleg
{
    private int _id;
    private String _nleg;
   
   
	public tnleg()
	{
	}
    public tnleg(int _id, String _nleg)
    {
        this._id = _id;
        this._nleg = _nleg;
       
    }
    public int Id
    {
        get { return _id; }
        set { _id = value; }
    }
    public String Nleg
    {
        get { return _nleg; }
        set { _nleg = value; }
    }
   
}
