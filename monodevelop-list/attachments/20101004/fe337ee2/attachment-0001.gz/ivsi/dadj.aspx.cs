using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class dadj : System.Web.UI.Page
{
    GestionUBarrios gu = new GestionUBarrios();
    Int16 nivel,depto;
	int idub;
	UBarrios ub;
	String pagina;
	bool alta;
	
    protected void Page_Load(object sender, EventArgs e)
    {   
		     if (this.Session["nivel"] == null) 
		        { this.Response.Redirect("Default.aspx");}
	         else 
		        {
			     nivel = (Int16)this.Session["nivel"];
		         depto = (Int16)this.Session["depto"];
		        }
          
		    idub = int.Parse(Request["id"]);
            ub = gu.GetUBarriosById(idub);
		    pagina = "adjxb.aspx?id=" + ub.Barrio;
           
		 
        if (! this.IsPostBack)
        {
			txtmza.Text = ub.Mza;
            txtmza.Enabled = false;
            txtlote.Text = ub.Lote;
            txtlote.Enabled = false;
            txtmono.Text = ub.Mono;
            txtmono.Enabled = false;
            txtpuerta.Text = ub.Puerta;
            txtpuerta.Enabled = false;
            txtpiso.Text = ub.Piso;
            txtpiso.Enabled = false;
            txtdepto.Text = ub.Depto;
            txtdepto.Enabled = false;
            txttipvi.Text = Convert.ToString(ub.Tipvi);
            txttipvi.Enabled = false;
            txtcalle.Text = ub.Calle;
			txtcalle.Enabled = false;
            txtnro.Text = Convert.ToString(ub.Nro);
			txtnro.Enabled = false;
			txtNC.Text = ub.NC;
			txtNC.Enabled = false;

      
        }

    }
             
    protected bool valida()
    { 
        
  
        if ((txtlote.Text.Length == 0) && (txtmono.Text.Length == 0) && (txtpuerta.Text.Length == 0) && (txtpiso.Text.Length == 0) && (txtdepto.Text.Length == 0)) 
        {
            msg.Text = "Debe Ingresar al menos un identificador de ubicación";
            return false;
        }

    
		if ((txtmono.Text.Length > 0) && (txtpuerta.Text.Length == 0) && (txtpiso.Text.Length == 0) && (txtdepto.Text.Length == 0))
        {
            msg.Text = "Si ingresa monoblock debe ingresar puerta, piso y depto";
            return false;
        }

        return true;
    }

    protected void cmdAlta_Click1(object sender, EventArgs e)
    {
		    txtmza.Enabled = true;
            txtlote.Enabled = true;
            txtmono.Enabled = true;
            txtpuerta.Enabled = true;
            txtpiso.Enabled = true;
            txtdepto.Enabled = true;
            txttipvi.Enabled = true;
			txtcalle.Enabled = true;
			txtnro.Enabled = true;
			txtNC.Enabled = true;
            msg.Text = "Alta";
		    alta = true;
		    ViewState["alta"] = alta;
    }
    protected void cmdBaja_Click1(object sender, EventArgs e)
    {  		
        if (gu.DeleteUBarrios(idub))
            this.Response.Redirect(pagina);
        else
            msg.Text = "No se ha podido eliminar.  Posiblemente posee registros asociados. Verifique!!!";
    }
    protected void cmdModif_Click1(object sender, EventArgs e)
    {
		    txtmza.Enabled = true;
            txtlote.Enabled = true;
            txtmono.Enabled = true;
            txtpuerta.Enabled = true;
            txtpiso.Enabled = true;
            txtdepto.Enabled = true;
            txttipvi.Enabled = true;
			txtcalle.Enabled = true;
			txtnro.Enabled = true;
			txtNC.Enabled = true;
		    alta = false;
		    ViewState["alta"] = alta;
    
        msg.Text = "Modificación";
    }
    protected void cmdGrabar_Click1(object sender, EventArgs e)
    {
	
        if (valida())
        {  
			ub.Mza = txtmza.Text;
			ub.Lote = txtlote.Text;
			ub.Mono = txtmono.Text;
			ub.Puerta = txtpuerta.Text;
			ub.Piso = txtpiso.Text;
			ub.Depto = txtdepto.Text;
			ub.Tipvi = Convert.ToUInt16(txttipvi.Text);
			ub.Calle = txtcalle.Text;
			ub.Nro = Convert.ToUInt16(txtnro.Text);
			ub.NC = txtNC.Text;
			
			bool alta = (bool)ViewState["alta"];
			
            if ( !alta )
            {
                if (gu.UpdateUBarrios(ub))
                    this.Response.Redirect(pagina);
                else
                    msg.Text = "No se ha podido actualizar. Verifique!!";
            }
            else
            {
                if (gu.GrabaUBarrios(ub))
                    this.Response.Redirect(pagina);
                else
                    msg.Text = "No se ha podido dar el alta. Ya existe el código?. Verifique!!";
            }
        }
    }
    protected void cmdCancel_Click1(object sender, EventArgs e)
    {       
		   this.Response.Redirect(pagina);
    }
}
