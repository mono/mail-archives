using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.Security;
using System.Web.UI.WebControls.WebParts;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.IO;


public partial class mvcc : System.Web.UI.Page
{

  

    GestionCC gcc = new GestionCC();
    GestionPDF gpdf = new GestionPDF();
    BoundField gridColumn;
    HyperLinkField linkColumn;
    String sql;
    DataTable CC;
    String[] aField = new String[]{"id"};
    int nivel;

	
    protected void Page_Load(object sender, EventArgs e)
    {
             if (this.Session["nivel"] == null) 
		        { this.Response.Redirect("Default.aspx");}
	         else 
		        {nivel = (Int16)this.Session["nivel"];}

        
      
           
        
        if (!this.IsPostBack)
        {
            txtdesde.Attributes.Add("onkeydown", "return (event.keyCode!=13);");
            txthasta.Attributes.Add("onkeydown", "return (event.keyCode!=13);");
			txtdesde.Text="1970/01/01";
			txthasta.Text="9999/12/12";
			
            GVMVCC.Columns.Clear();

            gridColumn = new BoundField();
            gridColumn.DataField = "id";
            gridColumn.HeaderText = "ID";
            gridColumn.ItemStyle.Width = 20;
            GVMVCC.Columns.Add(gridColumn);

            gridColumn = new BoundField();
            gridColumn.DataField = "prestamo";
            gridColumn.HeaderText = "Prestamo";
            gridColumn.ItemStyle.Width = 20;
            GVMVCC.Columns.Add(gridColumn);

			gridColumn = new BoundField();
            gridColumn.DataField = "sucursal";
            gridColumn.HeaderText = "Sucursal";
            gridColumn.ItemStyle.Width = 20;
            GVMVCC.Columns.Add(gridColumn);

        	gridColumn = new BoundField();
            gridColumn.DataField = "tipco";
            gridColumn.HeaderText = "TIPCO";
            gridColumn.ItemStyle.Width = 20;
            GVMVCC.Columns.Add(gridColumn);

                
            gridColumn = new BoundField();
            gridColumn.DataField = "nro";
            gridColumn.HeaderText = "Nro";
            gridColumn.ItemStyle.Width = 100;
            GVMVCC.Columns.Add(gridColumn);

            gridColumn = new BoundField();
            gridColumn.DataField = "fecha";
            gridColumn.HeaderText = "Fecha";
            gridColumn.ItemStyle.Width = 20;
            GVMVCC.Columns.Add(gridColumn);

            gridColumn = new BoundField();
            gridColumn.DataField = "observaciones";
            gridColumn.HeaderText = "Observaciones";
            gridColumn.ItemStyle.Width = 80;
            GVMVCC.Columns.Add(gridColumn);

            gridColumn = new BoundField();
            gridColumn.DataField = "importe";
            gridColumn.HeaderText = "Importe";
            gridColumn.ItemStyle.Width = 80;
            GVMVCC.Columns.Add(gridColumn);
			
			
			linkColumn = new HyperLinkField();
            linkColumn.Text = "Emision";
            linkColumn.NavigateUrl="~\\cgrufa.aspx";
            linkColumn.DataNavigateUrlFields = aField;
            linkColumn.DataNavigateUrlFormatString = "grufa.aspx?id={0}";

            linkColumn.ItemStyle.Width = 30;
            GVMVCC.Columns.Add(linkColumn);
       

              if (nivel < 3)
              {
                    linkColumn = new HyperLinkField();
                    linkColumn.Text = "ABM";
                    linkColumn.NavigateUrl="~\\dins.aspx";
                    linkColumn.DataNavigateUrlFields = aField;
                    linkColumn.DataNavigateUrlFormatString = "dlins.aspx?id={0}";
                    linkColumn.ItemStyle.Width = 30;
                    GVMVCC.Columns.Add(linkColumn);
                    
               }
              GVMVCC.AllowPaging = true;
           
        }
       
        int id = int.Parse(Request["id"]);       

        sql = "SELECT cc.id, cc.prestamo, s.sucursal, t.tipco, cc.nro, cc.fecha, cc.observaciones, cc.importe ";
		sql += "FROM mvcc AS cc "; 
		sql += "INNER JOIN sucursales AS s on (cc.sucursal = s.id) ";
		sql += "INNER JOIN tipco AS t on (cc.tipco = t.id) ";
        sql += "WHERE cc.prestamo = " + id + " and cc.fecha >= " + txtdesde.Text + " and cc.fecha <= " + txthasta.Text + " ORDER BY cc.prestamo,cc.tipco,cc.nro";

       
        CC = gcc.GetCC(sql);

       

    }

    protected void GVMVCC_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
       
            GVMVCC.PageIndex = e.NewPageIndex;
            GVMVCC.DataSource = CC;
            GVMVCC.DataBind();
                   
    }

    protected void GVMVCC_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

     protected void  BPrint_Click(object sender, EventArgs e)
    {  	
        if (CC != null)
        {
           Write();            
        } 
     }
    protected void Write()
    {
        MemoryStream m = new MemoryStream();
        Document doc = new Document();
        doc.SetMargins(50,50,50,50);
		
        try
        {
            Response.ContentType = "application/pdf";
            PdfWriter writer = PdfWriter.GetInstance(doc, m);
            writer.CloseStream = false;
            PdfWriter.GetInstance(doc, Response.OutputStream);
			Single[] width = { 30,30,50, 30, 60, 30, 100, 30 };
	        itsEvents ev = new itsEvents();
			writer.PageEvent = ev;
			ev.Header = "INSCRIPTOS";
			ev.tabla = CC;
			ev.Width = width;
            doc.Open();
            PdfPTable tabla = gpdf.TablePDF(CC);
            tabla.SetWidths(width);
            doc.Add(tabla);
          
            doc.Close();
        }
        catch (DocumentException ex)
        {
            Console.Error.WriteLine(ex.StackTrace);
            Console.Error.WriteLine(ex.Message);
        }
        // step 6: Write pdf bytes to outputstream
        Response.OutputStream.Write(m.GetBuffer(), 0, m.GetBuffer().Length);
        Response.OutputStream.Flush();
        Response.OutputStream.Close();
        m.Close();


    }





    protected void btBuscar_Click(object sender, EventArgs e)
    {
      if (Page.IsValid)
	  {
        if (CC != null)
        {
            GVMVCC.DataSource = CC;
            GVMVCC.DataBind();
        }
	  }

    }
  
}

