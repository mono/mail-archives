using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public class Usuario
{
    //esta clase encapsula los datos de un usuario
    private String s_Usuario;
    private String s_Password;
    private String s_Nombre;
    private String s_Apellido;
    private String s_Email;
    private String s_Telefono;
    private Int16 i_nivel;
	private Int16 i_depto;

    public Usuario()
    {
    }
	
    public Usuario(String s_Usuario, String s_Password, String s_Nombre, String s_Apellido,  String s_Email, String s_Telefono, Int16 i_nivel, Int16 i_depto)
    {
        this.s_Usuario = s_Usuario;
        this.s_Password = s_Password;
        this.s_Nombre = s_Nombre;
        this.s_Apellido = s_Apellido;
        this.s_Email = s_Email;
        this.s_Telefono = s_Telefono;
        this.i_nivel = i_nivel;
		this.i_depto = i_depto;
    }
    public String Nick
    {
        get { return s_Usuario; }
        set { s_Usuario = value; }
    }
    public String Password
    {
        get { return s_Password; }
        set { s_Password = value; }
    }
    public String Nombre
    {
        get { return s_Nombre; }
        set { s_Nombre = value; }
    }
    public String Apellido
    {
        get { return s_Apellido; }
        set { s_Apellido = value; }
    }
    public String Email
    {
        get { return s_Email; }
        set { s_Email = value; }
    }
    public String Telefono
    {
        get { return s_Telefono; }
        set { s_Telefono = value; }
    }
    public Int16 Nivel
    {
        get { return i_nivel; }
        set { i_nivel = value; }
    }
	public Int16 Depto
    {
        get { return i_depto; }
        set { i_depto = value; }
    }
}
