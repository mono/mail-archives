using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.IO;


public partial class finan : System.Web.UI.Page
{
    GestionFinan gf = new GestionFinan();
	GestionInscriptos gi = new GestionInscriptos();
    GestionPDF gpdf = new GestionPDF();
    BoundField gridColumn;
    HyperLinkField linkColumn;
    DataTable Finan;
    String[] aField = new String[]{"id"};
    String sql;
    String insstr;
    int nivel,depto;

            
    protected void Page_Load(object sender, EventArgs e)
    {
       if (this.Session["nivel"] == null) 
		{ this.Response.Redirect("Default.aspx");}
	   else 
		{
			nivel = (Int16)this.Session["nivel"];
		    depto = (Int16)this.Session["depto"];
		}
      
		   
        
        if (!this.IsPostBack)
        {
                

            GVFin.Columns.Clear();

            gridColumn = new BoundField();
            gridColumn.DataField = "id";
            gridColumn.HeaderText = "ID";
            gridColumn.ItemStyle.Width = 20;
            GVFin.Columns.Add(gridColumn);

            gridColumn = new BoundField();
            gridColumn.DataField = "sistema";
            gridColumn.HeaderText = "Sistema";
            gridColumn.ItemStyle.Width = 20;
            GVFin.Columns.Add(gridColumn);

            gridColumn = new BoundField();
            gridColumn.DataField = "tipfi";
            gridColumn.HeaderText = "TIPFI";
            gridColumn.ItemStyle.Width = 20;
            GVFin.Columns.Add(gridColumn);

                
            gridColumn = new BoundField();
            gridColumn.DataField = "nrofi";
            gridColumn.HeaderText = "NROFI";
            gridColumn.ItemStyle.Width = 20;
            GVFin.Columns.Add(gridColumn);

            gridColumn = new BoundField();
            gridColumn.DataField = "fecfi";
            gridColumn.HeaderText = "FECFI";
            gridColumn.ItemStyle.Width = 20;
            GVFin.Columns.Add(gridColumn);

			gridColumn = new BoundField();
            gridColumn.DataField = "plazo";
            gridColumn.HeaderText = "Plazo";
            gridColumn.ItemStyle.Width = 100;
            GVFin.Columns.Add(gridColumn);

			gridColumn = new BoundField();
            gridColumn.DataField = "emitido";
            gridColumn.HeaderText = "Emitido";
            gridColumn.ItemStyle.Width = 100;
            GVFin.Columns.Add(gridColumn);
			
			gridColumn = new BoundField();
            gridColumn.DataField = "impulcta";
            gridColumn.HeaderText = "IMPULCTA";
            gridColumn.ItemStyle.Width = 20;
            GVFin.Columns.Add(gridColumn);
			
            gridColumn = new BoundField();
            gridColumn.DataField = "vtoultcta";
            gridColumn.HeaderText = "VTOULCTA";
            gridColumn.ItemStyle.Width = 20;
            GVFin.Columns.Add(gridColumn);

        //    linkColumn.Text = "Cta.Cte";
        //    linkColumn.NavigateUrl = "~\\mvcc.aspx";
        //    linkColumn.DataNavigateUrlFields = aField;
        //    linkColumn.DataNavigateUrlFormatString = "mvcc.aspx?id={0}";
        //    linkColumn.ItemStyle.Width = 30;
        //    GVFin.Columns.Add(linkColumn);
          
            if (nivel < 5 && depto == 4)
              {
                    linkColumn = new HyperLinkField();
                    linkColumn.Text = "ABM";
                    linkColumn.NavigateUrl="~\\dfin.aspx";
                    linkColumn.DataNavigateUrlFields = aField;
                    linkColumn.DataNavigateUrlFormatString = "dfin.aspx?id={0}";
                    linkColumn.ItemStyle.Width = 30;
                    GVFin.Columns.Add(linkColumn);
                  
              } 
                    GVFin.AllowPaging = true;
           
        }
        int idins = int.Parse(Request["id"]);

		Inscripto ins = gi.GetInscriptosById(idins);    
    
        lblIns.Text = ins.Id + " " + ins.Nombre + " Documento " + ins.Tipdoc + " " + ins.Nrodoc;
		insstr = lblIns.Text;
		
        sql = "select id,sistema,tipfi,nrofi,plazo,emitido,fecfi,impulcta,vtoultcta";
        sql += " from finan where idinsc = " + idins;
       
		
		
        Finan = gf.GetFin(sql);
     
        GVFin.DataSource = Finan;
        GVFin.DataBind();
        
           

    }

    protected void GVFin_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
       
            GVFin.PageIndex = e.NewPageIndex;
            GVFin.DataSource = Finan;
            GVFin.DataBind();
                   
    }

    protected void GVFin_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

     protected void  BPrint_Click(object sender, EventArgs e)
    {
        if (Finan != null)
        {
           Write();            
        } 
     }
    protected void Write()
    {
        MemoryStream m = new MemoryStream();
        Document doc = new Document();
		doc.SetMargins(50,20,30,30);
		
        try
        {
            Response.ContentType = "application/pdf";
            PdfWriter writer = PdfWriter.GetInstance(doc, m);
            writer.CloseStream = false;
			Single[] width = {30,20,20,20,20,20,30,30,30};
            itsEvents ev = new itsEvents();
			writer.PageEvent = ev;
			ev.Header = insstr;
			ev.tabla = Finan;
			ev.Width = width;
            doc.Open();
            PdfPTable tabla = gpdf.TablePDF(Finan);
            tabla.SetWidths(width);
            doc.Add(tabla);
            doc.Close();
           
        }
        catch (DocumentException ex)
        {
            Console.Error.WriteLine(ex.StackTrace);
            Console.Error.WriteLine(ex.Message);
        }
        // step 6: Write pdf bytes to outputstream
        Response.OutputStream.Write(m.GetBuffer(), 0, m.GetBuffer().Length);
        Response.OutputStream.Flush();
        Response.OutputStream.Close();
        m.Close();
       

    }





   
}

