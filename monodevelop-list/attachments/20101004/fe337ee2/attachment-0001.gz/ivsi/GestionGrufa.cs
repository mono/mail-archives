using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Npgsql;

public class GestionGrufa
{

	public GestionGrufa()
	{
	}
  
    
    private DataTable GetTabla(String Name, String Sql)
    {
        //crea un objeto DataTable con el nombre
        //especificado a partir de la instrucci�n
        //Select indicada
        DataSet ds = new DataSet();
        Data datos = new Data();
        NpgsqlDataAdapter adp = datos.getAdapter(Sql);
        adp.Fill(ds, Name);
        return ds.Tables[Name];

    }
    public DataTable GetGrufa(String sql)
    {
        return GetTabla("grufa", sql);
    }
    
    public bool GrabarGrufa(Grufa gf)
    {
        //Si el usuario se puede registrar
        //devolver� true, sino devolver� false
        Data datos = new Data();
        NpgsqlConnection cn=datos.GetConnection();
        //realiza la operaci�n si se ha conseguido
        //una conexi�n. 
        if (cn != null)
         {
            //utiliza el modo conectado pues es una
            //actualizaci�n puntual
            NpgsqlCommand cmd;
            String sql = "Insert into grufa values(";
            sql += "'" + gf.idIns + "',";
            sql += "'" + gf.Relacion + "',";
            sql += "'" + gf.Apellido + "',";
            sql += "'" + gf.Nombre + "',";
            sql += "'" + gf.Tido + "',";
            sql += "'" + gf.Nudo + "')";
            cmd = new NpgsqlCommand(sql, cn);
            try
            {
                cmd.ExecuteNonQuery();
                return true;
            }
            catch 
            {
                return false;
            }
            finally
            {
                cn.Close();
            }
        }
        else
            return false;
    }

    public bool UpdateGrufa(Grufa gf)
    { //Si el usuario se puede registrar
        //devolver� true, sino devolver� false
        Data datos = new Data();
        NpgsqlConnection cn = datos.GetConnection();
        //realiza la operaci�n si se ha conseguido
        //una conexi�n. 
        if (cn != null)
        {
            //utiliza el modo conectado pues es una
            //actualizaci�n puntual
            NpgsqlCommand cmd;
            String sql = "Update usuarios SET ";
            sql += "idins = '" + gf.idIns + "',";
            sql += "nombre = '" + gf.Nombre + "',";
            sql += "apellido = '" + gf.Apellido + "',";
            sql += "relacion = '" + gf.Relacion + "',";
            sql += "tido = '" + gf.Tido + "'" ;
            sql += " Where id = '" + gf.Id + "'";
            cmd = new NpgsqlCommand(sql, cn);
            try
            {
                cmd.ExecuteNonQuery();
                return true;
            }
            catch
            {
                return false;
            }
            finally
            {
                cn.Close();
            }
        }
        else
            return false;
    }    
    public Grufa GetGrufabyid(long id)
    {
        //utiliza el modo conectado, pues es una consulta
        //puntual
        Data datos = new Data();
        NpgsqlConnection cn=datos.GetConnection();
        NpgsqlCommand cmd;
        NpgsqlDataReader dr;
        String sql = "Select * From usuarios Where id = " + id;
        //realiza la operaci�n si se ha conseguido
        //una conexi�n
        if (cn != null)
        {
           try
                {
                cmd = new NpgsqlCommand(sql, cn);
                dr = cmd.ExecuteReader();
                 
                if (dr.Read())
                    {
                   Grufa usr = new Grufa((long)dr["id"],
                                        (long)dr["idIns"],
                                        (byte)dr["relacion"],
                                        (String)dr["apellido"],
                                        (String)dr["nombre"],
                                        (byte)dr["tido"],
                                        (long)dr["nudo"]);
                    return usr;
                    }
                 else
                    return null;
                 }
            catch
               {
                   return null;
               }
            finally
               {
                   cn.Close();
               }
        }
        else
            return null;
    }
}
