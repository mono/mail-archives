using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Npgsql;

/// <summary>
/// Summary description for GestionFinan
/// </summary>
public class GestionFinan
{
    
	public GestionFinan()
	{
	}

    private DataTable GetTabla(String Name, String Sql)
    {
        //crea un objeto DataTable con el nombre
        //especificado a partir de la fintrucción
        //Select indicada
        DataSet ds = new DataSet();
        Data datos = new Data();
        NpgsqlConnection cn = datos.GetConnection();
        //realiza la operación si se ha conseguido
        //una conexión. 
        if (cn != null)
        {
        NpgsqlDataAdapter adp = new NpgsqlDataAdapter();
        adp = datos.getAdapter(Sql);
        adp.Fill(ds, Name);
        return ds.Tables[Name];
        }
        else return null; 
    }

    public DataTable GetFin(String sql)
    {
        return GetTabla("finan",sql);
    }
    
    public bool GrabaFinan(Finan fin)
    {
        Data datos = new Data();
        NpgsqlConnection cn = datos.GetConnection();
        //realiza la operación si se ha conseguido
        //una conexión. 
        if (cn != null)
        {
            //utiliza el modo conectado pues es una
            //actualización puntual
            NpgsqlCommand cmd;
            String sql = "Insert into finan values(";
            sql += "'" + fin.Sistema + "',";
            sql += "'" + fin.IdIns + "',";
            sql += "'" + fin.Tipfi + "',";
            sql += "'" + fin.Nrofi + "',";
            sql += "'" + fin.Plazo + "',";
            sql += "'" + fin.Emitido + "',";
            sql += "'" + fin.Fecfi + "',";
            sql += "'" + fin.Interes + "',";
            sql += "'" + fin.Saldo + "',";
			sql += "'" + fin.Salte + "',";
			sql += "'" + fin.AnoBase + "',";
		    sql += "'" + fin.MesBase + "',";
		    sql += "'" + fin.PorSub + "',";
		    sql += "'" + fin.FecSus + "',";
		    sql += "'" + fin.MesSus + "',";
			sql += "'" + fin.PagoDiferido + "')";
            cmd = new NpgsqlCommand(sql, cn);
            try
            {
                cmd.ExecuteNonQuery();
                return true;
            }
            catch
            {
                return false;
            }
            finally
            {
                cn.Close();
            }
        }
        else
            return false;
    }

    public bool UpdateFinan(Finan fin)
    {
        Data datos = new Data();
        NpgsqlConnection cn = datos.GetConnection();
        //realiza la operación si se ha conseguido
        //una conexión. 
        if (cn != null)
        {
            //utiliza el modo conectado pues es una
            //actualización puntual
            NpgsqlCommand cmd;
            String sql = "Update finan SET ";
            sql += "'" + fin.Sistema + "',";
            sql += "'" + fin.IdIns + "',";
            sql += "'" + fin.Tipfi + "',";
            sql += "'" + fin.Nrofi + "',";
            sql += "'" + fin.Plazo + "',";
            sql += "'" + fin.Emitido + "',";
            sql += "'" + fin.Fecfi + "',";
            sql += "'" + fin.Interes + "',";
            sql += "'" + fin.Saldo + "',";
			sql += "'" + fin.Salte + "',";
			sql += "'" + fin.AnoBase + "',";
		    sql += "'" + fin.MesBase + "',";
		    sql += "'" + fin.PorSub + "',";
		    sql += "'" + fin.FecSus + "',";
		    sql += "'" + fin.MesSus + "',";
			sql += "'" + fin.PagoDiferido + "'";
            sql += " Where id = " + fin.Id;
            cmd = new NpgsqlCommand(sql, cn);
            try
            {
                cmd.ExecuteNonQuery();
                return true;
            }
            catch
            {
                return false;
            }
            finally
            {
                cn.Close();
            }
        }
        else
            return false;
    }

    public bool DeleteFinan(int id)
    {
        Data datos = new Data();
        NpgsqlConnection cn = datos.GetConnection();
        //realiza la operación si se ha conseguido
        //una conexión. 
        if (cn != null)
        {
            //utiliza el modo conectado pues es una
            //actualización puntual
            NpgsqlCommand cmd;
            String sql = "DELETE FROM finan ";
            sql += " Where id = " + id;
            cmd = new NpgsqlCommand(sql, cn);
            try
            {
                cmd.ExecuteNonQuery();
                return true;
            }
            catch
            {
                return false;
            }
            finally
            {
                cn.Close();
            }
        }
        else
            return false;
    }

    public Finan GetFinanById(int id)
    {
        Data datos = new Data();
        NpgsqlConnection con = datos.GetConnection();
        NpgsqlDataReader dr;
        String sql = "Select * From finan Where id = " + id;
        //realiza la operación si se ha conseguido
        //una conexión
        if (con != null)
        {
            NpgsqlCommand cmd = new NpgsqlCommand(sql, con);
            try
            {
                dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    Finan f = new Finan();
                                        
                    f.Id = (long)dr["id"];
                    f.IdIns = (Int32)dr["idins"];
                    f.Sistema = (Int16)dr["sistema"];
                    f.Tipfi = (Int16)dr["tipfi"];
                    f.Nrofi = (Int16)(dr["nrofi"]);
                    f.Fecfi = (DateTime)dr["fecfi"];
                    f.Saldo = (decimal)dr["saldo"];
                    f.Plazo = (int)dr["plazo"];
                    f.Emitido = (int)dr["emitido"];
                    f.Interes = (decimal)dr["interes"];
                    f.Estado = (String)dr["estado"];
                    f.AnoBase= (Int16)dr["anobase"];
                    f.MesBase = (Int16)dr["mesbase"];
                    f.PorSub = (Int16)dr["porsub"];
                    f.MesSus = (Int16)dr["mesus"];
					f.PagoDiferido = (String)dr["pagodiferido"];

					
                    return f;
                }
                else
                    return null;
            }
            catch
            {
                return null;
            }
            finally
            {
                con.Close();
            }
        }
        else
            return null;

    }
}
