using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.IO;


public partial class adjsfinan : System.Web.UI.Page
{

    GestionInscriptos gi = new GestionInscriptos();
    GestionPDF gpdf = new GestionPDF();
    BoundField gridColumn;
    HyperLinkField linkColumn;
    DataTable Adjudicatarios;
    String[] aField = new String[]{"id"};
    String sql;
    String insstr;
    int nivel;

            
    protected void Page_Load(object sender, EventArgs e)
    {
       if (this.Session["nivel"] == null) 
		{ this.Response.Redirect("Default.aspx");}
	   else 
		{nivel = (Int16)this.Session["nivel"];}
    
     
    
        
        if (!this.IsPostBack)
        {
                

            GVAdj.Columns.Clear();
			
			gridColumn = new BoundField();
            gridColumn.DataField = "sistema";
            gridColumn.HeaderText = "Sistema";
            gridColumn.ItemStyle.Width = 20;
            GVAdj.Columns.Add(gridColumn);
			
			gridColumn = new BoundField();
            gridColumn.DataField = "codigo";
            gridColumn.HeaderText = "Código";
            gridColumn.ItemStyle.Width = 20;
            GVAdj.Columns.Add(gridColumn);

			gridColumn = new BoundField();
            gridColumn.DataField = "proyecto";
            gridColumn.HeaderText = "Proyecto";
            gridColumn.ItemStyle.Width = 20;
            GVAdj.Columns.Add(gridColumn);
			
            gridColumn = new BoundField();
            gridColumn.DataField = "mza";
            gridColumn.HeaderText = "MZA";
            gridColumn.ItemStyle.Width = 20;
            GVAdj.Columns.Add(gridColumn);

            gridColumn = new BoundField();
            gridColumn.DataField = "lote";
            gridColumn.HeaderText = "LOTE";
            gridColumn.ItemStyle.Width = 20;
            GVAdj.Columns.Add(gridColumn);

            gridColumn = new BoundField();
            gridColumn.DataField = "mono";
            gridColumn.HeaderText = "MONO";
            gridColumn.ItemStyle.Width = 20;
            GVAdj.Columns.Add(gridColumn);

                
            gridColumn = new BoundField();
            gridColumn.DataField = "puerta";
            gridColumn.HeaderText = "PUERTA";
            gridColumn.ItemStyle.Width = 20;
            GVAdj.Columns.Add(gridColumn);

            gridColumn = new BoundField();
            gridColumn.DataField = "piso";
            gridColumn.HeaderText = "Piso";
            gridColumn.ItemStyle.Width = 20;
            GVAdj.Columns.Add(gridColumn);

            gridColumn = new BoundField();
            gridColumn.DataField = "depto";
            gridColumn.HeaderText = "Depto";
            gridColumn.ItemStyle.Width = 20;
            GVAdj.Columns.Add(gridColumn);

            gridColumn = new BoundField();
            gridColumn.DataField = "tipvi";
            gridColumn.HeaderText = "TIPVI";
            gridColumn.ItemStyle.Width = 20;
            GVAdj.Columns.Add(gridColumn);

            gridColumn = new BoundField();
            gridColumn.DataField = "nombre";
            gridColumn.HeaderText = "Nombre";
            gridColumn.ItemStyle.Width = 100;
            GVAdj.Columns.Add(gridColumn);

            gridColumn = new BoundField();
            gridColumn.DataField = "tipdoc";
            gridColumn.HeaderText = "TIPDOC";
            gridColumn.ItemStyle.Width = 20;
            GVAdj.Columns.Add(gridColumn);

            gridColumn = new BoundField();
            gridColumn.DataField = "nrdoc";
            gridColumn.HeaderText = "NrDoc";
            gridColumn.ItemStyle.Width = 30;
            GVAdj.Columns.Add(gridColumn); 
          
            if (nivel < 3)
              {
                    linkColumn = new HyperLinkField();
                    linkColumn.Text = "ABM";
                    linkColumn.NavigateUrl="~\\dadj.aspx";
                    linkColumn.DataNavigateUrlFields = aField;
                    linkColumn.DataNavigateUrlFormatString = "detailadj.aspx?id={0}";
                    linkColumn.ItemStyle.Width = 30;
                    GVAdj.Columns.Add(linkColumn);
                  
              } 
                    GVAdj.AllowPaging = true;
           
        }
       

        sql ="SELECT i.nombre,i.tipdoc,i.nrdoc,";
        sql += "b.sistema,b.codigo,b.proyecto,";
        sql += "ub.mza,ub.lote,ub.mono,ub.puerta,ub.piso,ub.depto,ub.tipvi";
        sql += " FROM inscriptos AS i JOIN undins AS ui ON i.id = ui.idins";
        sql += " JOIN unidbarrio AS ub ON ub.id = ui.unidad";
        sql += " JOIN barrios AS b ON b.id = ub.barrio";
        sql += " LEFT OUTER JOIN finan AS f ON f.idinsc = ui.idins";
        sql += " WHERE f.idinsc IS NULL";
		
		
        Adjudicatarios = gi.GetInscriptos(sql);
     
        GVAdj.DataSource = Adjudicatarios;
        GVAdj.DataBind();
        
           

    }

    protected void GVAdj_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
       
            GVAdj.PageIndex = e.NewPageIndex;
            GVAdj.DataSource = Adjudicatarios;
            GVAdj.DataBind();
                   
    }

    protected void GVAdj_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

     protected void  BPrint_Click(object sender, EventArgs e)
    {
        if (Adjudicatarios != null)
        {
           Write();            
        } 
     }
    protected void Write()
    {
        MemoryStream m = new MemoryStream();
        Document doc = new Document();
        doc.SetMargins(50,50,50,50);
		
        try
        {
            Response.ContentType = "application/pdf";
            PdfWriter writer = PdfWriter.GetInstance(doc, m);
            writer.CloseStream = false;
            PdfWriter.GetInstance(doc, Response.OutputStream);
			Single[] widths = {200,20,90,20,90,200,20,30,20,20,20,20,20};
            itsEvents ev = new itsEvents();
			writer.PageEvent = ev;
			ev.Header = "Adjudicatarios sin Financiacion";
			ev.tabla = Adjudicatarios;
			ev.Width = widths;
            doc.Open();
            PdfPTable tabla = gpdf.TablePDF(Adjudicatarios);
		    tabla.SetWidths(widths);
			
            doc.Add(tabla);
            doc.Close();
           
        }
        catch (DocumentException ex)
        {
            Console.Error.WriteLine(ex.StackTrace);
            Console.Error.WriteLine(ex.Message);
        }
        // step 6: Write pdf bytes to outputstream
        Response.OutputStream.Write(m.GetBuffer(), 0, m.GetBuffer().Length);
        Response.OutputStream.Flush();
        Response.OutputStream.Close();
        m.Close();
       

    }





   
}

