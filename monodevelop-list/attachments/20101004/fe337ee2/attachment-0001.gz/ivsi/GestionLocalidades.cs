using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Npgsql;
using NpgsqlTypes;
/// <summary>
/// Summary description for GestionBarrios
/// </summary>
public class GestionLocalidades

{
    private String sql;

	public GestionLocalidades()
	{
	}

    private DataTable GetTabla(String Name, String sql)
    {
        //crea un objeto DataTable con el nombre
        //especificado a partir de la bartrucci�n
        //Select indicada
        DataSet ds = new DataSet();
        Data datos = new Data();
        NpgsqlDataAdapter adp = datos.getAdapter(sql);
        adp.Fill(ds, Name);
        return ds.Tables[Name];

    }

    public DataTable GetLocalidades()
    {
        return GetTabla("localidad", "Select * From localidad");
    }

    public DataTable GetLocaByNom(String den)
    {
        String comodin;
        if (den.Length == 0)
        {
           comodin = "%";
        }
        else comodin = '%' + den + '%';
      
		NpgsqlDataReader dr;
	    DataTable dt = new DataTable();
		Data datos = new Data();
		NpgsqlConnection conn = datos.GetConnection();
		
		if (conn != null)
		{
			try 
			{
      	       NpgsqlCommand cmd = new NpgsqlCommand("getloca", conn);
               cmd.CommandType = System.Data.CommandType.StoredProcedure;
			   cmd.Parameters.Add(new NpgsqlParameter("nombre",NpgsqlTypes.NpgsqlDbType.Varchar));
			   cmd.Parameters[0].Value = comodin;
			   dr = cmd.ExecuteReader();
			   dt.Load(dr);
               return dt;
			}
	        catch
            {
                return null;
            }
            finally
            {
                conn.Close();
            }
		}
		else return null;
	    
	}

    public bool GrabaLocalidad(Localidad loca)
    {
        Data datos = new Data();
        NpgsqlConnection cn = datos.GetConnection();
        //realiza la operaci�n si se ha conseguido
        //una conexi�n. 
        if (cn != null)
        {
            //utiliza el modo conectado pues es una
            //actualizaci�n puntual
            NpgsqlCommand cmd;
            String sql = "Insert into localidad values(";
            sql += "'" + loca.Nombre + "')";
            cmd = new NpgsqlCommand(sql, cn);
            try
            {
                cmd.ExecuteNonQuery();
                return true;
            }
            catch
            {
                return false;
            }
            finally
            {
                cn.Close();
            }
        }
        else
            return false;
    }

    public bool UpdateLocalidad(Localidad loca)
    {
        Data datos = new Data();
        NpgsqlConnection cn = datos.GetConnection();
        //realiza la operaci�n si se ha conseguido
        //una conexi�n. 
        if (cn != null)
        {
            //utiliza el modo conectado pues es una
            //actualizaci�n puntual
            NpgsqlCommand cmd;
            String sql = "Update barrios SET ";
            sql += "'" + loca.Nombre + "'";
            sql += " Where id = " + loca.Id;
            cmd = new NpgsqlCommand(sql, cn);
            try
            {
                cmd.ExecuteNonQuery();
                return true;
            }
            catch
            {
                return false;
            }
            finally
            {
                cn.Close();
            }
        }
        else
            return false;
    }

    public bool DeleteLocalidad(int id)
    {
        Data datos = new Data();
        NpgsqlConnection cn = datos.GetConnection();
        //realiza la operaci�n si se ha conseguido
        //una conexi�n. 
        if (cn != null)
        {
            //utiliza el modo conectado pues es una
            //actualizaci�n puntual
            NpgsqlCommand cmd;
            String sql = "DELETE FROM localidad ";
            sql += " Where id = " + id;
            cmd = new NpgsqlCommand(sql, cn);
            try
            {
                cmd.ExecuteNonQuery();
                return true;
            }
            catch
            {
                return false;
            }
            finally
            {
                cn.Close();
            }
        }
        else
            return false;
    }

    public Localidad GetLocalidadById(int id)
    {
        Data datos = new Data();
        NpgsqlConnection con = datos.GetConnection();
        NpgsqlDataReader dr;
        String sql = "Select * From localidad Where id = " + id;
        //realiza la operaci�n si se ha conseguido
        //una conexi�n
        if (con != null)
        {
            NpgsqlCommand cmd = new NpgsqlCommand(sql, con);
            try
            {
                dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    Localidad ag = new Localidad((int)dr["id"],
                                        (String)dr["localidad"]);

                    return ag;
                }
                else
                    return null;
            }
            catch
            {
                return null;
            }
            finally
            {
                con.Close();
            }
        }
        else
            return null;

    }
}
