using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Npgsql;

/// <summary>
/// Summary description for GestionCC
/// </summary>
public class GestionCC
{
    
	public GestionCC()
	{
	}

    private DataTable GetTabla(String Name, String Sql)
    {
        //crea un objeto DataTable con el nombre
        //especificado a partir de la instrucción
        //Select indicada
        DataSet ds = new DataSet();
        Data datos = new Data();
        NpgsqlConnection cn = datos.GetConnection();
        //realiza la operación si se ha conseguido
        //una conexión. 
        if (cn != null)
        {
        NpgsqlDataAdapter adp = new NpgsqlDataAdapter();
        adp = datos.getAdapter(Sql);
        adp.Fill(ds, Name);
        return ds.Tables[Name];
        }
        else return null; 
    }

    public DataTable GetCC(String sql)
    {
        return GetTabla("mvcc",sql);
    }
    
    public bool GrabaCC(MVCC cc)
    {
        Data datos = new Data();
        NpgsqlConnection cn = datos.GetConnection();
        //realiza la operación si se ha conseguido
        //una conexión. 
        if (cn != null)
        {
            //utiliza el modo conectado pues es una
            //actualización puntual
            NpgsqlCommand cmd;
            String sql = "Insert into mvcc values(";
            sql += "'" + cc.Prestamo + "',";
            sql += "'" + cc.Sucursal + "',";
            sql += "'" + cc.TipCo + "',";
            sql += "'" + cc.Nro + "',";
            sql += "'" + cc.Fecha + "',";
            sql += "'" + cc.Observaciones + "',";
            sql += "'" + cc.Importe + "')";
            cmd = new NpgsqlCommand(sql, cn);
            try
            {
                cmd.ExecuteNonQuery();
                return true;
            }
            catch
            {
                return false;
            }
            finally
            {
                cn.Close();
            }
        }
        else
            return false;
    }

    public bool UpdateCC(MVCC cc)
    {
        Data datos = new Data();
        NpgsqlConnection cn = datos.GetConnection();
        //realiza la operación si se ha conseguido
        //una conexión. 
        if (cn != null)
        {
            //utiliza el modo conectado pues es una
            //actualización puntual
            NpgsqlCommand cmd;
            String sql = "Update mvcc SET ";
            sql += "'" + cc.Prestamo + "',";
            sql += "'" + cc.Sucursal + "',";
            sql += "'" + cc.TipCo + "',";
            sql += "'" + cc.Nro + "',";
            sql += "'" + cc.Fecha + "',";
            sql += "'" + cc.Observaciones + "',";
            sql += "'" + cc.Importe + "'";
            sql += " Where prestamo = " + cc.id;
            cmd = new NpgsqlCommand(sql, cn);
            try
            {
                cmd.ExecuteNonQuery();
                return true;
            }
            catch
            {
                return false;
            }
            finally
            {
                cn.Close();
            }
        }
        else
            return false;
    }

    public bool DeleteCC(int id)
    {
        Data datos = new Data();
        NpgsqlConnection cn = datos.GetConnection();
        //realiza la operación si se ha conseguido
        //una conexión. 
        if (cn != null)
        {
            //utiliza el modo conectado pues es una
            //actualización puntual
            NpgsqlCommand cmd;
            String sql = "DELETE FROM mvcc ";
            sql += " Where id = " + id;
            cmd = new NpgsqlCommand(sql, cn);
            try
            {
                cmd.ExecuteNonQuery();
                return true;
            }
            catch
            {
                return false;
            }
            finally
            {
                cn.Close();
            }
        }
        else
            return false;
    }

}
