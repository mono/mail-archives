using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for Observa
/// </summary>
public class cnleg
{
    private int _id;
    private String _concepto;
   
   
	public cnleg()
	{
	}
    public cnleg(int _id, String _concepto)
    {
        this._id = _id;
        this._concepto = _concepto;
       
    }
    public int Id
    {
        get { return _id; }
        set { _id = value; }
    }
    public String Concepto
    {
        get { return _concepto; }
        set { _concepto = value; }
    }
   
}
