using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Npgsql;

/// <summary>
/// Summary description for GestionBarrios
/// </summary>
public class GestionNLegal
{
	public GestionNLegal()
	{
	}

    private DataTable GetTabla(String Name, String Sql)
    {
        //crea un objeto DataTable con el nombre
        //especificado a partir de la bartrucción
        //Select indicada
        DataSet ds = new DataSet();
        Data datos = new Data();
        NpgsqlDataAdapter adp = datos.getAdapter(Sql);
        adp.Fill(ds, Name);
        return ds.Tables[Name];

    }

    public DataTable GetNLegal(String sql)
    {
        return GetTabla("nlegal", sql);
    }

    public bool GrabaNLegal(Nlegal nl)
    {
		String alcance,fecha;
        Data datos = new Data();
        NpgsqlConnection cn = datos.GetConnection();
        //realiza la operación si se ha conseguido
        //una conexión. 
        if (cn != null)
        {
			if (nl.Alc == null)
			{alcance = "";}
			else
			{alcance = nl.Alc;}
			
			fecha = nl.Fecha.ToString("yyyy/MM/dd");
			
            //utiliza el modo conectado pues es una
            //actualización puntual
            NpgsqlCommand cmd;
			String serial = "nextval('nlegal_id_seq')";
            String sql = "Insert into nlegal values(";
			sql += serial + ",";
            sql += "'" + nl.Tipo + "',";
            sql += "'" + nl.Nro + "',";
            sql += "'" + nl.Ano + "',";
            sql += "'" + fecha + "',";
		    sql += "'" + nl.Asunto + "',";
            sql += "'" + nl.ParentId + "',";
            sql += "'" + nl.Expte + "',";
			sql += "'" + nl.Concepto + "',";
			sql += "'" + alcance + "')";
            cmd = new NpgsqlCommand(sql, cn);
            try
            {
                cmd.ExecuteNonQuery();
                return true;
            }
            catch
            {
                return false;
            }
            finally
            {
                cn.Close();
            }
        }
        else
            return false;
    }

    public bool UpdateNLegal(Nlegal nl)
    {  
		String alcance,fecha;
        Data datos = new Data();
        NpgsqlConnection cn = datos.GetConnection();
        //realiza la operación si se ha conseguido
        //una conexión. 
        if (cn != null)
        {
			if (nl.Alc == null)
			{alcance = "";}
			else
			{alcance = nl.Alc;}
			
			fecha = nl.Fecha.ToString("yyyy/MM/dd");
            //utiliza el modo conectado pues es una
            //actualización puntual
            NpgsqlCommand cmd;
            String sql = "Update nlegal SET ";
			sql += "tipo = ";
            sql += "'" + nl.Tipo + "',";
			sql += "nro = ";
	        sql += "'" + nl.Nro + "',";
			sql += "ano = ";
	        sql += "'" + nl.Ano + "',";
			sql += "fecha = ";
            sql += "'" + fecha + "',";
			sql += "asunto = ";
			sql += "'" + nl.Asunto + "',";
			sql += "parentid = ";
            sql += "'" + nl.ParentId + "',";
			sql += "expte = ";
            sql += "'" + nl.Expte + "',";
			sql += "alcance = ";
            sql += "'" + alcance + "',";
			sql += "concepto = ";
            sql += "'" + nl.Concepto + "'";
			sql += " Where id = " + nl.Id ;
            cmd = new NpgsqlCommand(sql, cn);
            try
            {
                cmd.ExecuteNonQuery();
                return true;
            }
            catch
            {
                return false;
            }
            finally
            {
                cn.Close();
            }
        }
        else
            return false;
    }

    public bool DeleteNLegal(int id)
    {
        Data datos = new Data();
        NpgsqlConnection cn = datos.GetConnection();
        //realiza la operación si se ha conseguido
        //una conexión. 
        if (cn != null)
        {
            //utiliza el modo conectado pues es una
            //actualización puntual
            NpgsqlCommand cmd;
            String sql = "DELETE FROM nlegal ";
            sql += " Where id = " + id;
            cmd = new NpgsqlCommand(sql, cn);
            try
            {
                cmd.ExecuteNonQuery();
                return true;
            }
            catch
            {
                return false;
            }
            finally
            {
                cn.Close();
            }
        }
        else
            return false;
    }

    public Nlegal GetNLegalById(int id)
    {
        Data datos = new Data();
        NpgsqlConnection con = datos.GetConnection();
        NpgsqlDataReader dr;
        String sql = "Select * From nlegal Where id = " + id;
        //realiza la operación si se ha conseguido
        //una conexión
        if (con != null)
        {
            NpgsqlCommand cmd = new NpgsqlCommand(sql, con);
            try
            {
                dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    Nlegal nl = new Nlegal();
					nl.Id = (Int32)dr["id"];
					nl.Tipo = (Int16)dr["tipo"];
					nl.Nro = (Int32)dr["nro"];
					nl.Ano = (Int16)dr["ano"];
					nl.Fecha = (DateTime)dr["fecha"];
					nl.Asunto = (String)dr["asunto"];
					nl.ParentId = (Int32)dr["parentid"];
					nl.Expte = (String)dr["expte"];
					nl.Alc = (String)dr["alcance"];
					nl.Concepto = (Int16)dr["concepto"];
                    return nl;
                }
                else
                    return null;
            }
            catch
            {
                return null;
            }
            finally
            {
               con.Close();
            }
        }
        else
            return null;

    }
}

