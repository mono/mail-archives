using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for Observa
/// </summary>
public class Localidad
{
    private long _id;
    private String _nombre;
   
	public Localidad()
	{
	}
     public Localidad(long _id, String _nombre)
    {
        this._id = _id;
        this._nombre = _nombre;
    }
    public long Id
    {
        get { return _id; }
        set { _id = value; }
    }
    public String Nombre
    {
        get { return _nombre; }
        set { _nombre = value; }
    }
    
}
