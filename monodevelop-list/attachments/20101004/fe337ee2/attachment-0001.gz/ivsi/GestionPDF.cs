﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.IO;


/// <summary>
/// Descripción breve de PDFTable
/// </summary>

public class GestionPDF
{
	public GestionPDF()
	{
		//
		// TODO: Agregar aquí la lógica del constructor
		//
	}
   
   
    // add a table to the PDF document
    public PdfPTable TablePDF(DataTable tabla)
    {
		 PdfPTable table = new PdfPTable(tabla.Columns.Count);
         table.WidthPercentage = 100;
      
      
        foreach (DataRow row in tabla.Rows)
        {
            foreach (DataColumn cl in tabla.Columns)
            {
				PdfPCell cell = new PdfPCell(new Phrase(row[cl].ToString()));
                // cell.BackgroundColor = new BaseColor(204, 204, 204);
                table.AddCell(cell);
            }
        }
	   
        return table;
    }

}
public class itsEvents : PdfPageEventHelper
{
	    private String _Header;
   	    private DataTable _tabla;
	    private Single[] _width;
	
	   public DataTable tabla
        {
           get { return _tabla; }
           set { _tabla = value; }
        }
	
        public String Header
        {
           get { return _Header; }
           set { _Header = value; }
        }

	    public Single[] Width
        {
           get { return _width; }
           set { _width = value; }
        }
	
	
        public override void OnStartPage(PdfWriter writer, Document document)
        {
                Paragraph p = new Paragraph(Header + " " + DateTime.Now.ToString());
		        p.SpacingBefore = 30;
		        p.SpacingAfter = 30;
		       
                document.Add(p);
		   
	     	   PdfPTable table = new PdfPTable(tabla.Columns.Count);
		       table.WidthPercentage = 100;
               table.SetWidths(Width);
		
		       string[] col;
               col = new string[tabla.Columns.Count];

               int k = 0;
               foreach (DataColumn cl in tabla.Columns)
               {
                  col[k] = cl.ColumnName;
                  ++k;
                }
		
		       for (int i = 0; i < col.Length; ++i)
               {
                 PdfPCell cell = new PdfPCell(new Phrase(col[i]));
                 cell.BackgroundColor = new BaseColor(204, 204, 204);
                 table.AddCell(cell);
               }
		       document.Add(table);
		}
       
}
