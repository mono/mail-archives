using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.IO;


public partial class adjxb : System.Web.UI.Page
{

    GestionUBarrios ub = new GestionUBarrios();
    GestionBarrios gb = new GestionBarrios();
    GestionPDF gpdf = new GestionPDF();
    BoundField gridColumn;
    HyperLinkField linkColumn;
    DataTable Adjudicatarios;
    String[] aField = new String[]{"id1"};
	String[] aField2 = new String[]{"id"};
    String sql;
    String insstr;
    Int16 nivel,depto;

            
    protected void Page_Load(object sender, EventArgs e)
    {
       if (this.Session["nivel"] == null) 
		{ this.Response.Redirect("Default.aspx");}
	   else 
		{
		 nivel = (Int16)this.Session["nivel"];
		 depto = (Int16)this.Session["depto"];
		}
    
 
        
        if (!this.IsPostBack)
        {
                

            GVAdj.Columns.Clear();
			
			gridColumn = new BoundField();
            gridColumn.DataField = "id";
            gridColumn.HeaderText = "ID";
            gridColumn.ItemStyle.Width = 20;
            GVAdj.Columns.Add(gridColumn);

            gridColumn = new BoundField();
            gridColumn.DataField = "mza";
            gridColumn.HeaderText = "MZA";
            gridColumn.ItemStyle.Width = 20;
            GVAdj.Columns.Add(gridColumn);

            gridColumn = new BoundField();
            gridColumn.DataField = "lote";
            gridColumn.HeaderText = "LOTE";
            gridColumn.ItemStyle.Width = 20;
            GVAdj.Columns.Add(gridColumn);

            gridColumn = new BoundField();
            gridColumn.DataField = "mono";
            gridColumn.HeaderText = "MONO";
            gridColumn.ItemStyle.Width = 20;
            GVAdj.Columns.Add(gridColumn);

                
            gridColumn = new BoundField();
            gridColumn.DataField = "puerta";
            gridColumn.HeaderText = "PUERTA";
            gridColumn.ItemStyle.Width = 20;
            GVAdj.Columns.Add(gridColumn);

            gridColumn = new BoundField();
            gridColumn.DataField = "piso";
            gridColumn.HeaderText = "Piso";
            gridColumn.ItemStyle.Width = 20;
            GVAdj.Columns.Add(gridColumn);

            gridColumn = new BoundField();
            gridColumn.DataField = "depto";
            gridColumn.HeaderText = "Depto";
            gridColumn.ItemStyle.Width = 20;
            GVAdj.Columns.Add(gridColumn);

            gridColumn = new BoundField();
            gridColumn.DataField = "tipvi";
            gridColumn.HeaderText = "TIPVI";
            gridColumn.ItemStyle.Width = 20;
            GVAdj.Columns.Add(gridColumn);

			gridColumn = new BoundField();
            gridColumn.DataField = "id1";
            gridColumn.HeaderText = "IdIns";
            gridColumn.ItemStyle.Width = 100;
            GVAdj.Columns.Add(gridColumn);
			
            gridColumn = new BoundField();
            gridColumn.DataField = "nombre";
            gridColumn.HeaderText = "Nombre";
            gridColumn.ItemStyle.Width = 100;
            GVAdj.Columns.Add(gridColumn);

            gridColumn = new BoundField();
            gridColumn.DataField = "tipdoc";
            gridColumn.HeaderText = "TIPDOC";
            gridColumn.ItemStyle.Width = 20;
            GVAdj.Columns.Add(gridColumn);

            gridColumn = new BoundField();
            gridColumn.DataField = "nrdoc";
            gridColumn.HeaderText = "NrDoc";
            gridColumn.ItemStyle.Width = 30;
            GVAdj.Columns.Add(gridColumn); 
			
		    linkColumn = new HyperLinkField();
            linkColumn.Text = "Financiaciones";
            linkColumn.NavigateUrl = "~\\finan.aspx";
            linkColumn.DataNavigateUrlFields = aField;
            linkColumn.DataNavigateUrlFormatString = "finan.aspx?id={0}";
            linkColumn.ItemStyle.Width = 30;
            GVAdj.Columns.Add(linkColumn);
          
            if ((nivel < 5) && (depto == 4))
				
              {
				    linkColumn = new HyperLinkField();
                    linkColumn.Text = "ABM";
                    linkColumn.NavigateUrl="~\\dadj.aspx";
                    linkColumn.DataNavigateUrlFields = aField2;
                    linkColumn.DataNavigateUrlFormatString = "dadj.aspx?id={0}";
                    linkColumn.ItemStyle.Width = 30;
                    GVAdj.Columns.Add(linkColumn);
				
              } 
                    GVAdj.AllowPaging = true;
           
        }
        int idpy = int.Parse(Request["id"]);

        Barrio bb = gb.GetBarriosById(idpy);
        lblBarrio.Text = bb.Proyecto;
		insstr = bb.Proyecto;
		
        sql = "select ub.id,ub.mza,ub.lote,ub.mono,ub.puerta,ub.piso, ub.depto,";
		sql += "ub.tipvi,i.id,i.nombre, td.tipdoc, i.nrdoc ";
        sql += "from unidbarrio as ub left outer join undins as ui "; 
        sql += "on ( ub.id = ui.unidad) left outer join inscriptos as i ";
        sql += "on (ui.idins = i.id) left outer join tipdoc as td on (i.tipdoc = td.id) ";
        sql += "where ub.barrio = " + idpy;
       
		
		
        Adjudicatarios = ub.GetUBarrios(sql);
     
		if (Adjudicatarios != null)
		{
           GVAdj.DataSource = Adjudicatarios;
           GVAdj.DataBind();
		}
           

    }

    protected void GVAdj_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
       
            GVAdj.PageIndex = e.NewPageIndex;
            GVAdj.DataSource = Adjudicatarios;
            GVAdj.DataBind();
                   
    }

    protected void GVAdj_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

     protected void  BPrint_Click(object sender, EventArgs e)
    {
        if (Adjudicatarios != null)
        {
           Write();            
        } 
     }
    protected void Write()
    {
        MemoryStream m = new MemoryStream();
        Document doc = new Document();
		doc.SetMargins(50,20,30,30);
	
        try
        {
            Response.ContentType = "application/pdf";
            PdfWriter writer = PdfWriter.GetInstance(doc, m);
            writer.CloseStream = false;
			Single[] width = {30,20,20,20,10,10,30,20,30,100,20,40};
            itsEvents ev = new itsEvents();
			writer.PageEvent = ev;
			ev.Header = insstr;
			ev.tabla = Adjudicatarios;
			ev.Width = width;
            doc.Open();
            PdfPTable tabla = gpdf.TablePDF(Adjudicatarios);
            tabla.SetWidths(width);
            doc.Add(tabla);
            doc.Close();
           
        }
        catch (DocumentException ex)
        {
            Console.Error.WriteLine(ex.StackTrace);
            Console.Error.WriteLine(ex.Message);
        }
        // step 6: Write pdf bytes to outputstream
        Response.OutputStream.Write(m.GetBuffer(), 0, m.GetBuffer().Length);
        Response.OutputStream.Flush();
        Response.OutputStream.Close();
        m.Close();
       

    }
	




   
}

