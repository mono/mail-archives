using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.Security;
using System.Web.UI.WebControls.WebParts;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.IO;


public partial class ins : System.Web.UI.Page
{

  

    GestionInscriptos gi = new GestionInscriptos();
    GestionPDF gpdf = new GestionPDF();
    BoundField gridColumn;
    HyperLinkField linkColumn;
    String nom,sql;
    DataTable InsByNom;
    String[] aField = new String[]{"id"};
    int nivel,depto;

	
    protected void Page_Load(object sender, EventArgs e)
    {
             if (this.Session["nivel"] == null) 
		        { this.Response.Redirect("Default.aspx");}
	         else 
		        {
			      nivel = (Int16)this.Session["nivel"];
		          depto = (Int16)this.Session["depto"];
		        }

        
      
           
        
        if (!this.IsPostBack)
        {
            txtnom.Attributes.Add("onkeydown", "return (event.keyCode!=13);");

            GVInscriptos.Columns.Clear();

            gridColumn = new BoundField();
            gridColumn.DataField = "id";
            gridColumn.HeaderText = "ID";
            gridColumn.ItemStyle.Width = 20;
            GVInscriptos.Columns.Add(gridColumn);

            gridColumn = new BoundField();
            gridColumn.DataField = "tipoins";
            gridColumn.HeaderText = "TipoIns";
            gridColumn.ItemStyle.Width = 20;
            GVInscriptos.Columns.Add(gridColumn);

            gridColumn = new BoundField();
            gridColumn.DataField = "ruip";
            gridColumn.HeaderText = "RUIP";
            gridColumn.ItemStyle.Width = 20;
            GVInscriptos.Columns.Add(gridColumn);

                
            gridColumn = new BoundField();
            gridColumn.DataField = "nombre";
            gridColumn.HeaderText = "Nombre";
            gridColumn.ItemStyle.Width = 100;
            GVInscriptos.Columns.Add(gridColumn);

            gridColumn = new BoundField();
            gridColumn.DataField = "tipdoc";
            gridColumn.HeaderText = "TipoDoc";
            gridColumn.ItemStyle.Width = 20;
            GVInscriptos.Columns.Add(gridColumn);

            gridColumn = new BoundField();
            gridColumn.DataField = "nrdoc";
            gridColumn.HeaderText = "NroDoc";
            gridColumn.ItemStyle.Width = 80;
            GVInscriptos.Columns.Add(gridColumn);

            linkColumn = new HyperLinkField();
            linkColumn.Text = "Grupo Fliar";
            linkColumn.NavigateUrl="~\\cgrufa.aspx";
            linkColumn.DataNavigateUrlFields = aField;
            linkColumn.DataNavigateUrlFormatString = "grufa.aspx?id={0}";

            linkColumn.ItemStyle.Width = 30;
            GVInscriptos.Columns.Add(linkColumn);
       

              if (nivel < 5 && depto == 99)
              {
                    linkColumn = new HyperLinkField();
                    linkColumn.Text = "ABM";
                    linkColumn.NavigateUrl="~\\dins.aspx";
                    linkColumn.DataNavigateUrlFields = aField;
                    linkColumn.DataNavigateUrlFormatString = "dlins.aspx?id={0}";
                    linkColumn.ItemStyle.Width = 30;
                    GVInscriptos.Columns.Add(linkColumn);
                    
               }
              GVInscriptos.AllowPaging = true;
           
        }
        nom = txtnom.Text;
            

    }

    protected void GVInscriptos_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
       
            GVInscriptos.PageIndex = e.NewPageIndex;
            GVInscriptos.DataSource = InsByNom;
            GVInscriptos.DataBind();
                   
    }

    protected void GVInscriptos_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

     protected void  BPrint_Click(object sender, EventArgs e)
    {
        if (InsByNom != null)
        {
           Write();            
        } 
     }
    protected void Write()
    {
        MemoryStream m = new MemoryStream();
        Document doc = new Document();
        doc.SetMargins(50,50,50,50);
		
        try
        {
            Response.ContentType = "application/pdf";
            PdfWriter writer = PdfWriter.GetInstance(doc, m);
            writer.CloseStream = false;
            PdfWriter.GetInstance(doc, Response.OutputStream);
			Single[] width = { 30,100, 20, 20, 20, 30, 30 };
	        itsEvents ev = new itsEvents();
			writer.PageEvent = ev;
			ev.Header = "INSCRIPTOS";
			ev.tabla = InsByNom;
			ev.Width = width;
            doc.Open();
            PdfPTable tabla = gpdf.TablePDF(InsByNom);
            tabla.SetWidths(width);
            doc.Add(tabla);
          
            doc.Close();
        }
        catch (DocumentException ex)
        {
            Console.Error.WriteLine(ex.StackTrace);
            Console.Error.WriteLine(ex.Message);
        }
        // step 6: Write pdf bytes to outputstream
        Response.OutputStream.Write(m.GetBuffer(), 0, m.GetBuffer().Length);
        Response.OutputStream.Flush();
        Response.OutputStream.Close();
        m.Close();


    }





    protected void btBuscar_Click(object sender, EventArgs e)
    {
        InsByNom = gi.GetInscriptos(nom);

        if (InsByNom != null)
        {

            GVInscriptos.DataSource = InsByNom;
            GVInscriptos.DataBind();
        }

    }
  
}

