using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public class Finan
{
    //esta clase encapsula los datos de un Inscripto
    private long _Id;
    private Int16 _sistema;
    private long _idIns;
    private Int16 _tipfi;
    private Int16 _nrofi;
    private int _plazo;
    private int _emitido;
    private DateTime _fecfi;
    private decimal _interes;
    private decimal _saldo;
    private String _estado;
    private decimal _salte;
    private Int16 _anobase;
    private Int16 _mesbase;
    private decimal _porsub;
    private DateTime _fecsus;
    private Int16 _mesus;
    private String _pagodiferido;
    private DateTime _deudafec;
    private int _deudactas;
    private decimal _dbcr;
    private double _i;
    private String _r454;
    private decimal _impulcta;
    private DateTime _vtoulcta;

	public Finan()
	{
	}
    public Finan(long _Id,Int16 _sistema, long _idIns,Int16 _tipfi ,Int16 _nrofi, int _plazo, int _emitido, DateTime _fecfi, decimal _interes, decimal _saldo, String _estado, decimal _salte,Int16 _anobase,Int16 _mesbase, decimal _porsub, DateTime _fecsus,Int16 _mesus, String _pagodiferido, DateTime _deudafec, int _deudactas, decimal _dbcr, double _i, String _r454, decimal _impulcta, DateTime _vtoulcta)
    {
        
        this._Id = _Id;
        this._sistema = _sistema;
        this._idIns = _idIns;
        this._tipfi = _tipfi;
        this._nrofi = _nrofi;
        this._plazo = _plazo;
        this._emitido = _emitido;
        this._fecfi = _fecfi;
        this._interes = _interes;
        this._saldo = _saldo;
        this._estado = _estado;
        this._salte = _salte;
        this._anobase = _anobase;
        this._mesbase = _mesbase;
        this._porsub = _porsub;
        this._fecsus = _fecsus;
        this._mesus = _mesus;
        this._pagodiferido = _pagodiferido;
        this._deudafec = _deudafec;
        this._deudactas = _deudactas;
        this._dbcr = _dbcr;
        this._i = _i;
        this._r454 = _r454;
        this._impulcta = _impulcta;
        this._vtoulcta = _vtoulcta;


    }
    public long Id
    {
        get { return _Id; }
        set { _Id = value; }
    }
    public Int16 Sistema
    {
        get { return _sistema; }
        set { _sistema = value; }
    }
    public long IdIns
    {
        get { return _idIns; }
        set { _idIns = value; }
    }
    public Int16 Tipfi
    {
        get { return _tipfi; }
        set { _tipfi = value; }
    }
    public Int16 Nrofi
    {
        get { return _nrofi; }
        set { _nrofi = value; }
    }
    public int Plazo
    {
        get { return _plazo; }
        set { _plazo = value; }
    }
    public int Emitido
    {
        get { return _emitido; }
        set { _emitido = value; }
    }
    public DateTime Fecfi
    {
        get { return _fecfi; }
        set { _fecfi = value; }
    }
    public decimal Interes
    {
        get { return _interes; }
        set { _interes = value; }
    }
    public decimal Saldo
    {
        get { return _saldo; }
        set { _saldo = value; }
    }
    public String Estado
    {
        get { return _estado; }
        set { _estado = value; }
    }
	public decimal Salte
    {
        get { return _salte; }
        set { _salte = value; }
    }
    public Int16 AnoBase
    {
        get { return _anobase; }
        set { _anobase = value; }
    }
    public Int16 MesBase
    {
        get { return _mesbase; }
        set { _mesbase = value; }
    }
    public decimal PorSub 
    {
        get { return _porsub; }
        set { _porsub = value; }
    }
    public DateTime FecSus
    {
        get { return _fecsus; }
        set { _fecsus = value; }
    }
    public Int16 MesSus
    {
        get { return _mesus; }
        set { _mesus = value; }
    }
    public String PagoDiferido
    {
        get { return _pagodiferido; }
        set { _pagodiferido = value; }
    }
    public DateTime DeudaFec
    {
        get { return _deudafec; }
        set { _deudafec = value; }
    }
    public int DeudaCtas
    {
        get { return _deudactas; }
        set { _deudactas = value; }
    }
    public decimal DBCR
    {
        get { return _dbcr; }
        set { _dbcr = value; }
    }
    public double I
    {
        get { return _i; }
        set { _i = value; }
    }
    public String r454
    {
        get { return _r454; }
        set { _r454 = value; }
    }
    public decimal ImpUlCta
    {
        get { return _impulcta; }
        set { _impulcta = value; }
    }
    public DateTime VtoUlCta
    {
        get { return _vtoulcta; }
        set { _vtoulcta = value; }
    }
 }
