using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Npgsql;

/// <summary>
/// Summary description for GestionBarrios
/// </summary>
public class GestionBarrios
{
	public GestionBarrios()
	{
	}

    private DataTable GetTabla(String Name, String Sql)
    {
        //crea un objeto DataTable con el nombre
        //especificado a partir de la bartrucci�n
        //Select indicada
        DataSet ds = new DataSet();
        Data datos = new Data();
        NpgsqlDataAdapter adp = datos.getAdapter(Sql);
        adp.Fill(ds, Name);
        return ds.Tables[Name];

    }

    public DataTable GetBarrios(String sql)
    {
        return GetTabla("barrios", sql);
    }

    public bool GrabaBarrios(Barrio bar)
    {
        Data datos = new Data();
        NpgsqlConnection cn = datos.GetConnection();
        //realiza la operaci�n si se ha conseguido
        //una conexi�n. 
        if (cn != null)
        {
            //utiliza el modo conectado pues es una
            //actualizaci�n puntual
            NpgsqlCommand cmd;
            String sql = "Insert into barrios values(";
            sql += "'" + bar.Id + "',";
            sql += "'" + bar.Sistema + "',";
            sql += "'" + bar.Codigo + "',";
            sql += "'" + bar.Localidad + "',";
            sql += "'" + bar.Proyecto + "')";
            cmd = new NpgsqlCommand(sql, cn);
		
            try
            {
                cmd.ExecuteNonQuery();
                return true;
            }
            catch
            {
                return false;
            }
            finally
            {
                cn.Close();
            }
        }
        else
            return false;
    }

    public bool UpdateBarrios(Barrio bar)
    {
        Data datos = new Data();
        NpgsqlConnection cn = datos.GetConnection();
        //realiza la operaci�n si se ha conseguido
        //una conexi�n. 
        if (cn != null)
        {
            //utiliza el modo conectado pues es una
            //actualizaci�n puntual
            NpgsqlCommand cmd;
            String sql = "Update barrios SET ";
            sql += "'" + bar.Sistema + "',";
            sql += "'" + bar.Codigo + "',";
            sql += "'" + bar.Localidad + "',";
            sql += "'" + bar.Proyecto + "'";
            sql += " Where id = " + bar.Id;
            cmd = new NpgsqlCommand(sql, cn);
            try
            {
                cmd.ExecuteNonQuery();
                return true;
            }
            catch
            {
                return false;
            }
            finally
            {
                cn.Close();
            }
        }
        else
            return false;
    }

    public bool DeleteBarrios(Int32 id)
    {
        Data datos = new Data();
        NpgsqlConnection cn = datos.GetConnection();
        //realiza la operaci�n si se ha conseguido
        //una conexi�n. 
        if (cn != null)
        {
            //utiliza el modo conectado pues es una
            //actualizaci�n puntual
            NpgsqlCommand cmd;
            String sql = "DELETE FROM barrios ";
            sql += " Where id = " + id;
            cmd = new NpgsqlCommand(sql, cn);
            try
            {
                cmd.ExecuteNonQuery();
                return true;
            }
            catch
            {
                return false;
            }
            finally
            {
                cn.Close();
            }
        }
        else
            return false;
    }

    public Barrio GetBarriosById(Int32 id)
    {
        Data datos = new Data();
        NpgsqlConnection con = datos.GetConnection();
        NpgsqlDataReader dr;
        String sql = "Select * From barrios Where id = " + id;
        //realiza la operaci�n si se ha conseguido
        //una conexi�n
        if (con != null)
        {
            NpgsqlCommand cmd = new NpgsqlCommand(sql, con);
            try
            {
                dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    Barrio ag = new Barrio();
					ag.Id = (Int32)dr["id"];
					ag.Sistema = (Int16)dr["sistema"];
                    ag.Codigo = (String)dr["codigo"];
                    ag.Plan = (Int16)dr["plan"];
                    ag.Proyecto = (String)dr["proyecto"];
                    return ag;
                }
                else
                    return null;
            }
            catch
            {
                return null;
            }
            finally
            {
                con.Close();
            }
        }
        else
            return null;

    }
}
