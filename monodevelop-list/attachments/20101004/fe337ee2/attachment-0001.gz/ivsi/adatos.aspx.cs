
using System;
using System.Web;
using System.Web.UI;

namespace ivsi
{


	public partial class adatos : System.Web.UI.Page
	{
	}
}

