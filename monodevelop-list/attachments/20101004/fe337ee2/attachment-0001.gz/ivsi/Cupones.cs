using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for Linea
/// </summary>
public class Cupones
{
    private long _id;
    private int _codcomp;
    private long _nrocomp;
    private DateTime _pago;
    private decimal _importe;
    private String _error;
    private int _ninsc;
    private DateTime _fecop;
    private String _horaop;


	public Cupones()
	{
    }
    public Cupones(long _id, int _codcomp, long _nrocomp, DateTime _pago, decimal _importe, String _error , int _ninsc, DateTime _fecop, String _horaop)
    {
       
    }
    public long Id
    {
        get { return _id; }
        set { _id = value; }
    }
    public int codcomp
    {
        get { return _codcomp; }
        set { _codcomp = value; }
    }
    public long nrocomp
    {
        get { return _nrocomp; }
        set { _nrocomp = value; }
    }
    public DateTime pago
    {
        get { return _pago; }
        set { _pago = value; }
    }
    public decimal importe
    {
        get { return _importe; }
        set { _importe = value; }
    }
    public String error
    {
        get { return _error; }
        set { _error = value; }
    }
    public int ninsc
    {
        get { return _ninsc; }
        set { _ninsc = value; }
    }
    public DateTime fecop
    {
        get { return _fecop; }
        set { _fecop = value; }
    }
    public String horaop
    {
        get { return _horaop; }
        set { _horaop = value; }
    }
 }
