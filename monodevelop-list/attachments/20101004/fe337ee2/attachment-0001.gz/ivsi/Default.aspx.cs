using System;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;



public partial class Default : System.Web.UI.Page
{
    string s1, s2;
    int n;
    protected void Page_Load(object sender, EventArgs e)
    {
	}
    protected void cmdValidar_Click(object sender, EventArgs e)
    {
        
            GestionUsuarios gusuarios = new GestionUsuarios();
            Usuario usr = gusuarios.IsRegistrado(txtusr.Text);
            Clave clv = new Clave();
            
            if (usr != null)
            {
                s1 = usr.Password;
                s2 = clv.Encrypt(txtpwd.Text);
                
                n = String.Compare(s1, s2,false);

                s1 = "";
                s2 = "";
                usr.Password = "";

                if (n != 0)
                    lblMsg.Text = "Clave Incorrecta!!!";
                else
                {
                    Session["nivel"] = usr.Nivel;
				    Session["depto"] = usr.Depto;
                    this.Response.Redirect("Menu.aspx");
                }
            }
            else
                lblMsg.Text = "<b> Usuario no Registrado ó Usuario o Clave Incorrecta. Verifique!! <b>";
      
    }
    protected void cmdRegistro_Click(object sender, EventArgs e)
    {
        this.Response.Redirect("aregistro.aspx");
    }
   
    
}
