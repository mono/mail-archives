using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for Linea
/// </summary>
public class Grufa
{
    private long _id;
    private long _idIns;
    private byte _relacion;
    private String _apellido;
    private String _nombre;
    private byte _tido;
    private long _nudo;

	public Grufa()
	{
    }
     public Grufa(long _id,long _idIns, byte _relacion, String _apellido, String _nombre, byte _tido, long _nudo)
    {
        this._id = _id;
        this._idIns = _idIns;
        this._relacion = _relacion;
        this._apellido = _apellido;
        this._nombre = _nombre;
        this._tido = _tido;
        this._nudo = _nudo;
    }
    public long Id
    {
        get { return _id; }
        set { _id = value; }
    }
    public long idIns
    {
        get { return _idIns; }
        set { _idIns = value; }
    }
    public byte Relacion
    {
        get { return _relacion; }
        set { _relacion = value; }
    }
    public String Apellido
    {
        get { return _apellido; }
        set { _apellido = value; }
    }
    public String Nombre
    {
        get { return _nombre; }
        set { _nombre = value; }
    }
    public byte Tido
    {
        get { return _tido; }
        set { _tido = value; }
    }
    public long Nudo
    {
        get { return _nudo; }
        set { _nudo = value; }
    }
}
