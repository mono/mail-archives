using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for Linea
/// </summary>
public class Sucursales
{
    private long _id;
    private byte _organismo;
    private byte _sucursal;
    private String _descripcion;
    private String _domicilio;
    private long _localidad;
    private String _contacto;
    private String _te1;
    private String _te2;
    private String _mail;


	public Sucursales()
	{
    }
    public Sucursales(long _id, byte _organismo, byte _sucursal, String _descripcion, String _domicilio, long _localidad, String _contacto, String _te1, String _te2, String _mail)
    {
       
    }
    public long Id
    {
        get { return _id; }
        set { _id = value; }
    }
    public byte organismo
    {
        get { return _organismo; }
        set { _organismo = value; }
    }
    public byte sucursal
    {
        get { return _sucursal; }
        set { _sucursal = value; }
    }
    public String descripcion
    {
        get { return _descripcion; }
        set { _descripcion = value; }
    }
    public String domicilio
    {
        get { return _domicilio; }
        set { _domicilio = value; }
    }
    public long localidad
    {
        get { return _localidad; }
        set { _localidad = value; }
    }
    public String contacto
    {
        get { return _contacto; }
        set { _contacto = value; }
    }
    public String te1
    {
        get { return _te1; }
        set { _te1 = value; }
    }
    public String te2
    {
        get { return _te2; }
        set { _te2 = value; }
    }
    public String mail
    {
        get { return _mail; }
        set { _mail = value; }
    }
}
