using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Npgsql;

/// <summary>
/// Summary description for GestionBarrios
/// </summary>
public class GestionTNleg
{
	public GestionTNleg()
	{
	}

    private DataTable GetTabla(String Name, String Sql)
    {
        //crea un objeto DataTable con el nombre
        //especificado a partir de la bartrucción
        //Select indicada
        DataSet ds = new DataSet();
        Data datos = new Data();
        NpgsqlDataAdapter adp = datos.getAdapter(Sql);
        adp.Fill(ds, Name);
        return ds.Tables[Name];

    }

    public DataTable GetTNleg()
    {
        return GetTabla("tnleg", "Select * From tnleg");
    }

    public bool GrabaTNleg(tnleg td)
    {
        Data datos = new Data();
        NpgsqlConnection cn = datos.GetConnection();
        //realiza la operación si se ha conseguido
        //una conexión. 
        if (cn != null)
        {
            //utiliza el modo conectado pues es una
            //actualización puntual
            NpgsqlCommand cmd;
            String sql = "Insert into tnleg values(";
            sql += "'" + td.Id + "'";
            sql += "'" + td.Nleg + "')";
            cmd = new NpgsqlCommand(sql, cn);
            try
            {
                cmd.ExecuteNonQuery();
                return true;
            }
            catch
            {
                return false;
            }
            finally
            {
                cn.Close();
            }
        }
        else
            return false;
    }

    public bool UpdateTNleg(tnleg td)
    {
        Data datos = new Data();
        NpgsqlConnection cn = datos.GetConnection();
        //realiza la operación si se ha conseguido
        //una conexión. 
        if (cn != null)
        {
            //utiliza el modo conectado pues es una
            //actualización puntual
            NpgsqlCommand cmd;
            String sql = "Update tnleg SET ";
            sql += "'" + td.Nleg + "'";
            sql += " Where id = " + td.Id;
            cmd = new NpgsqlCommand(sql, cn);
            try
            {
                cmd.ExecuteNonQuery();
                return true;
            }
            catch
            {
                return false;
            }
            finally
            {
                cn.Close();
            }
        }
        else
            return false;
    }

    public bool DeleteTNleg(int id)
    {
        Data datos = new Data();
        NpgsqlConnection cn = datos.GetConnection();
        //realiza la operación si se ha conseguido
        //una conexión. 
        if (cn != null)
        {
            //utiliza el modo conectado pues es una
            //actualización puntual
            NpgsqlCommand cmd;
            String sql = "DELETE FROM tnleg ";
            sql += " Where id = " + id;
            cmd = new NpgsqlCommand(sql, cn);
            try
            {
                cmd.ExecuteNonQuery();
                return true;
            }
            catch
            {
                return false;
            }
            finally
            {
                cn.Close();
            }
        }
        else
            return false;
    }

    public tnleg GetTNlegById(int id)
    {
        Data datos = new Data();
        NpgsqlConnection con = datos.GetConnection();
        NpgsqlDataReader dr;
        String sql = "Select * From tnleg Where id = " + id;
        //realiza la operación si se ha conseguido
        //una conexión
        if (con != null)
        {
            NpgsqlCommand cmd = new NpgsqlCommand(sql, con);
            try
            {
                dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                   tnleg ag = new tnleg((int)dr["id"],
                                        (String)dr["nleg"]);

                    return ag;
                }
                else
                    return null;
            }
            catch
            {
                return null;
            }
            finally
            {
                con.Close();
            }
        }
        else
            return null;

    }
}

