using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for Otorgante
/// </summary>
public class UBarrios
{
    private long _id;
    private long _Barrio;
    private String _Mza;
    private String _Lote;
    private String _Mono;
    private String _Puerta;
    private String _Piso;
    private String _Depto;
    private int _Tipvi;
	private String _Calle;
	private int _Nro;
	private String _NC;
	
	public UBarrios()
	{
	}
      public UBarrios(long _id, long _Barrio, String _Mza, String _Lote, String _Mono, String _Puerta, String _Piso, String _Depto, int _Tipvi, String _Calle, int _Nro, String _NC)
    {
        this._id = _id;
        this._Barrio = _Barrio;
        this._Mza = _Mza;
        this._Lote = _Lote;
        this._Mono = _Mono;
        this._Puerta = _Puerta;
        this._Piso = _Piso;
        this._Depto = _Depto;
        this._Tipvi = _Tipvi;
		this._Calle = _Calle;
		this._Nro = _Nro;
		this._NC = _NC;
    }
    public long Id
    {
        get { return _id; }
        set { _id = value; }
    }
    
    public long Barrio
    {
        get { return _Barrio; }
        set { _Barrio = value; }
    }

    public String Mza
    {
        get { return _Mza; }
        set { _Mza = value; }
    }
    public String Lote
    {
        get { return _Lote; }
        set { _Lote = value; }
    }
    public String Mono
    {
        get { return _Mono; }
        set { _Mono = value; }
    }
    public String Puerta
    {
        get { return _Puerta; }
        set { _Puerta = value; }
    }
    public String Piso
    {
        get { return _Piso; }
        set { _Piso = value; }
    }
    public String Depto
    {
        get { return _Depto; }
        set { _Depto = value; }
    }
    public int Tipvi
    {
        get { return _Tipvi; }
        set { _Tipvi = value; }
    }
	public String Calle
    {
        get { return _Calle; }
        set { _Calle = value; }
    }
	public int Nro
    {
        get { return _Nro; }
        set { _Nro = value; }
    }
	public String NC
    {
        get { return _NC; }
        set { _NC = value; }
    }
}
