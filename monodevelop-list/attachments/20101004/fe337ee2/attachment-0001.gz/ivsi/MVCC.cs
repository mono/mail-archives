using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for Linea
/// </summary>
public class MVCC
{
	private Int32 _id;
    private long _prestamo;
    private long _sucursal;
    private byte _tipco;
    private long _nro;
    private DateTime _fecha;
    private String _observaciones;
    private decimal _importe;
 

	public MVCC()
	{
    }
     public MVCC(Int32 id,long _prestamo, long _sucursal, byte _tipco, long _nro, DateTime _fecha, String _observaciones, decimal _importe)
    {
		this.Importe = _id;
        this._prestamo = _prestamo;
        this._sucursal = _sucursal;
        this._tipco = _tipco;
        this._nro = _nro;
        this._fecha = _fecha;
        this._observaciones = _observaciones;
        this._importe = _importe;
    
    }
	public Int32 id
    {
        get { return _id; }
        set { _id = value; }
    }
    public long Prestamo
    {
        get { return _prestamo; }
        set { _prestamo = value; }
    }
    public long Sucursal
    {
        get { return _sucursal; }
        set { _sucursal = value; }
    }
    public byte TipCo
    {
        get { return _tipco; }
        set { _tipco = value; }
    }
    public long Nro
    {
        get { return _nro; }
        set { _nro = value; }
    }
    public DateTime Fecha
    {
        get { return _fecha; }
        set { _fecha = value; }
    }
    public String Observaciones
    {
        get { return _observaciones; }
        set { _observaciones = value; }
    }
    public decimal Importe
    {
        get { return _importe; }
        set { _importe = value; }
    }
    
}
