using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class dloca : System.Web.UI.Page
{
    GestionLocalidades gl = new GestionLocalidades();
    int nivel;
	
    protected void Page_Load(object sender, EventArgs e)
    {
       if (this.Session["nivel"] == null) 
		  { this.Response.Redirect("Default.aspx");}
	   else 
		  {nivel = (Int16)this.Session["nivel"];}
    
        
        if (!this.IsPostBack)
        {
        int id = (int)this.Session["id"];
        Localidad loc = gl.GetLocalidadById(id);
        if (loc != null)
        {
            
            txtid.Text = Convert.ToString(id);
            txtid.Enabled = false;
            txtDescr.Text = loc.Nombre;
            txtDescr.Enabled = false;
        }
        else
            this.Response.Redirect("abmloca.aspx");
        }

    }
             
    protected bool valida()
    { 
        String ln = txtDescr.Text.ToString();
      
        if (ln != "")
            return true;
        else
            { 
            msg.Text = "Debe Ingresar una descripción";
            return false;
            }
    }

    protected void cmdAlta_Click1(object sender, EventArgs e)
    {
        txtid.Enabled = true;
        txtid.Text = "";
        txtid.Enabled = false;
        txtDescr.Enabled = true;
        txtDescr.Text = "";
        txtDescr.Focus();
        msg.Text = "Alta";
    }
    protected void cmdBaja_Click1(object sender, EventArgs e)
    {
        int id = (int)this.Session["id"];
        if (gl.DeleteLocalidad(id))
            this.Response.Redirect("abmlocalidad.aspx");
        else
            msg.Text = "No se ha podido eliminar.  Posiblemente posee barrios asociados. Verifique!!!";
    }
    protected void cmdModif_Click1(object sender, EventArgs e)
    {
        txtDescr.Enabled = true;
        txtDescr.Focus();
        msg.Text = "Modificación";
    }
    protected void cmdGrabar_Click1(object sender, EventArgs e)
    {
        if (valida())
        {
            int id = (int)this.Session["id"];
            Localidad loc = gl.GetLocalidadById(id);
            loc.Nombre = txtDescr.Text;
            string descr = txtDescr.Text.ToString();

            //Si no posee id es un alta
            String ln = txtid.Text.ToString();
         
            if (ln != "")
            {
                if (gl.UpdateLocalidad(loc))
                    this.Response.Redirect("abmlocalidad.aspx");
                else
                    msg.Text = "No se ha podido actualizar. Verifique!!";
            }
            else
            {
                if (gl.GrabaLocalidad(loc))
                    this.Response.Redirect("abmlocalidad.aspx");
                else
                    msg.Text = "No se ha podido dar el alta. Verifique!!";
            }
        }
    }
    protected void cmdCancel_Click1(object sender, EventArgs e)
    {
        this.Response.Redirect("abmloca.aspx");
    }
}
