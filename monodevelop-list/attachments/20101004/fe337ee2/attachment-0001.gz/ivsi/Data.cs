using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Npgsql;

public class Data
{
    //esta clase define los m�todos para conectar
    //con la base de datos, tanto en modo conectado
    //como en desconectado
    String cadenaCon;
    String cadenaUpd;
	public Data()
	{
        cadenaCon = "Server=10.1.33.13;Port=4500;User Id=ivsi;Password=ivsi;Database=ivsi;CommandTimeout=0";
	}
    public NpgsqlConnection GetConnection()
    {
        NpgsqlConnection cn = new NpgsqlConnection(cadenaCon);
        try
        {
            cn.Open();
            return cn;
        }
        catch 
        {
            return null;
        }
    }
    public NpgsqlDataAdapter getAdapter(String sql)
    {
        NpgsqlDataAdapter adp;
        try
        {
            adp = new NpgsqlDataAdapter(sql, cadenaCon);
            return adp;
        }
        catch
        {
            return null;
        }
    }
    public NpgsqlConnection GetConnUpd()
    {
        NpgsqlConnection cn = new NpgsqlConnection(cadenaUpd);
        try
        {
            cn.Open();
            return cn;
        }
        catch
        {
            return null;
        }
    }
    public NpgsqlDataAdapter getAdapterUpd(String s_Sql)
    {
        NpgsqlDataAdapter adp;
        try
        {
            adp = new NpgsqlDataAdapter(s_Sql, cadenaUpd);
            return adp;
        }
        catch
        {
            return null;
        }
    }
}
