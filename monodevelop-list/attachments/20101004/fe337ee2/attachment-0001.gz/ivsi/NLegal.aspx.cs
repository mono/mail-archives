using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.IO;

public partial class NLegal : System.Web.UI.Page
{
    
    GestionNLegal gl = new GestionNLegal();
    BoundField gridColumn;
    HyperLinkField linkColumn;
    String den,sql,comodin;
    GestionPDF gpdf = new GestionPDF();
    DataTable tnleg;
    String[] aField = new String[] { "id" };
    int nivel,depto;

    protected void Page_Load(object sender, EventArgs e)
    {

             if (this.Session["nivel"] == null) 
		        { this.Response.Redirect("Default.aspx");}
	         else 
		        {
			      nivel = (Int16)this.Session["nivel"];
		          depto = (Int16)this.Session["depto"];
		        }

   
             
        
        if (!this.IsPostBack)
        {
            gridColumn = new BoundField();
            gridColumn.DataField = "id";
            gridColumn.HeaderText = "ID";
            gridColumn.ItemStyle.Width = 20;
            GVNLegal.Columns.Add(gridColumn);

            gridColumn = new BoundField();
            gridColumn.DataField = "nlegal";
            gridColumn.HeaderText = "Tipo";
            gridColumn.ItemStyle.Width = 100;
            GVNLegal.Columns.Add(gridColumn);

			gridColumn = new BoundField();
            gridColumn.DataField = "nro";
            gridColumn.HeaderText = "Nro";
            gridColumn.ItemStyle.Width = 100;
            GVNLegal.Columns.Add(gridColumn);
			
			gridColumn = new BoundField();
            gridColumn.DataField = "ano";
            gridColumn.HeaderText = "Año";
            gridColumn.ItemStyle.Width = 100;
            GVNLegal.Columns.Add(gridColumn);
			
			gridColumn = new BoundField();
            gridColumn.DataField = "fecha";
            gridColumn.HeaderText = "Fecha";
            gridColumn.ItemStyle.Width = 100;
            GVNLegal.Columns.Add(gridColumn);
			
			gridColumn = new BoundField();
            gridColumn.DataField = "expte";
            gridColumn.HeaderText = "Expte";
            gridColumn.ItemStyle.Width = 100;
            GVNLegal.Columns.Add(gridColumn);
			
			gridColumn = new BoundField();
            gridColumn.DataField = "asunto";
            gridColumn.HeaderText = "Asunto";
            gridColumn.ItemStyle.Width = 100;
            GVNLegal.Columns.Add(gridColumn);
			
			gridColumn = new BoundField();
            gridColumn.DataField = "concepto";
            gridColumn.HeaderText = "Concepto";
            gridColumn.ItemStyle.Width = 100;
            GVNLegal.Columns.Add(gridColumn);
			
			
            if (nivel < 5 && depto < 5)
            {
            linkColumn = new HyperLinkField();
            linkColumn.Text = "ABM";
            linkColumn.NavigateUrl = "~\\dnleg.aspx";
            linkColumn.DataNavigateUrlFields = aField;
            linkColumn.DataNavigateUrlFormatString = "dnleg.aspx?id={0}";
            linkColumn.ItemStyle.Width = 30;
            GVNLegal.Columns.Add(linkColumn);
          
            } 
            GVNLegal.AllowPaging = true;
        }

        den = txtast.Text;
		
		if (den.Length == 0)
        {
            den = "*";
            comodin = "%";

        }
        else comodin = '%' + den + '%';
		
		sql = "Select n.id, nlegal, nro, ano, fecha, expte, asunto, c.concepto ";
		sql += "from nlegal as n join tnleg as t on ( n.tipo = t.id) ";
	    sql += "join cnleg as c on (n.concepto = c.id) ";
		sql += "where asunto ilike '" + comodin + "'";
		
        tnleg = gl.GetNLegal(sql);
      


    }

    protected void GVNLegal_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GVNLegal.PageIndex = e.NewPageIndex;
        GVNLegal.DataSource = gl.GetNLegal(sql);
        GVNLegal.DataBind();
    }

    protected void GVNLegal_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    
   protected void Write()
    {
        MemoryStream m = new MemoryStream();
        Document doc = new Document();
        doc.SetMargins(50,50,50,50);
		
        try
        {
            Response.ContentType = "application/pdf";
            PdfWriter writer = PdfWriter.GetInstance(doc, m);
            writer.CloseStream = false;
            PdfWriter.GetInstance(doc, Response.OutputStream);
			Single[] width = { 10, 30 };
            itsEvents ev = new itsEvents();
			writer.PageEvent = ev;
			ev.Header = "Normas Legales";
			ev.tabla = tnleg;
			ev.Width = width;
            doc.Open();
            PdfPTable tabla = gpdf.TablePDF(tnleg);
            tabla.SetWidths(width);
            doc.Add(tabla);

            doc.Close();
        }
        catch (DocumentException ex)
        {
            Console.Error.WriteLine(ex.StackTrace);
            Console.Error.WriteLine(ex.Message);
        }
        // step 6: Write pdf bytes to outputstream
        Response.OutputStream.Write(m.GetBuffer(), 0, m.GetBuffer().Length);
        Response.OutputStream.Flush();
        Response.OutputStream.Close();
        m.Close();


    }
    protected void BAlta_Click1(object sender, EventArgs e)
    {
        this.Response.Redirect("dnleg.aspx?id=0");
    }

    protected void btBuscar_Click1(object sender, EventArgs e)
    {
        if (tnleg != null)
        {
            GVNLegal.DataSource = tnleg;
            GVNLegal.DataBind();

        }
    }
    protected void BPrint_Click1(object sender, EventArgs e)
    {
        if (tnleg != null)
        {
            Write();
        }
    }
}
