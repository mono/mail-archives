using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class cdatos : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
       

        if (!this.IsPostBack)
        {
            String nick = (String)this.Session["user"];
            nick = nick.Trim();
            if (nick != "adm")
            {
                ContentPlaceHolder c = new ContentPlaceHolder();
                c = (ContentPlaceHolder)Page.Master.FindControl("ContentPlaceHolder2");
                System.Web.UI.WebControls.Menu mnu = (System.Web.UI.WebControls.Menu)c.FindControl("MenuPrincipal");
                mnu.Items.Remove(mnu.FindItem("Mantenimiento"));
            }

        GestionUsuarios gu = new GestionUsuarios();
        Usuario usr = gu.IsRegistrado(nick);
        if (usr != null)
           {
               txtNombre.Text = usr.Nombre;
               txtApellido.Text = usr.Apellido;
               txtMail.Text = usr.Email;
               txtTelefono.Text = usr.Telefono;
            }
        }
    }
    protected void cmdCancelar_Click(object sender, EventArgs e)
    {   
        this.Response.Redirect("Menu.aspx");
    }
    protected void cmdAceptar_Click(object sender, EventArgs e)
    {
        if (txtpwd.Text != txtRpwd.Text) 
            {
             lblMsg.Text = "La Clave y la repetición deben ser iguales!!";
            }
        else
            {
            String nick = (String)this.Session["user"];
            GestionUsuarios gu = new GestionUsuarios();
            Usuario usr = gu.IsRegistrado(nick);
            Clave clv = new Clave();
            if (usr != null) 
            {
            if (!String.IsNullOrEmpty(txtpwd.Text))
                usr.Password = clv.Encrypt(txtpwd.Text);
                txtpwd.Text = "";
                txtRpwd.Text = "";
                usr.Nombre = txtNombre.Text;
                usr.Apellido = txtApellido.Text;
                usr.Email = txtMail.Text;
                usr.Telefono = txtTelefono.Text;

            if (!gu.UpdateUsuario(usr))
                lblMsg.Text = "Actualización fallida. Consulte el administrador!";
            else
                lblMsg.Text = "El usuario se ha actualizado correctamente";
            }
        }            
    }
}
