using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for Observa
/// </summary>
public class Tipco
{
    private int _id;
    private String _Descripcion;
    private String _letra;
    private long _ultimonro;
    private long _cuenta;
    private Boolean _dbcr;
    private DateTime _lastupdate;
   
	public Tipco()
	{
	}
    public Tipco(int _id, String _Descripcion, String _letra,long _ultimonro, long _cuenta, Boolean _dbcr, DateTime _lastupdate)
    {
        this._id = _id;
        this._Descripcion = _Descripcion;
        this._letra = _letra;
        this._ultimonro = _ultimonro;
        this._cuenta = _cuenta;
        this._dbcr = _dbcr;
        this._lastupdate = _lastupdate;
    }
    public int Id
    {
        get { return _id; }
        set { _id = value; }
    }
    public String Descripcion
    {
        get { return _Descripcion; }
        set { _Descripcion = value; }
    }
    public String Letra
    {
        get { return _letra; }
        set { _letra = value; }
    }
    public long UltimoNro
    {
        get { return _ultimonro; }
        set { _ultimonro = value; }
    }
    public long Cuenta
    {
        get { return _cuenta; }
        set { _cuenta = value; }
    }
    public Boolean DBCR
    {
        get { return _dbcr; }
        set { _dbcr = value; }
    }
    public DateTime LastUpdate
    {
        get { return _lastupdate; }
        set { _lastupdate = value; }
    }

    
}
