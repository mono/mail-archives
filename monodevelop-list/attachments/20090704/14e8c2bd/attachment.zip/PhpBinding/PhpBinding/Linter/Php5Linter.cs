using MonoDevelop.Core;
using MonoDevelop.Projects;
using PhpBinding;
using PhpBinding.Runtime;
using PhpBinding.Linter;
using System;
using System.Diagnostics;
using System.IO;
using System.Text.RegularExpressions;


namespace PhpBinding
{
	public class Php5Linter : IPhpLinter
	{
		IPhpRuntime runtime = null;
		Regex warningRegex;
		Regex errorRegex;
		
		public IPhpRuntime Runtime {
			get { return runtime; }
			set { runtime = value; }
		}
		
		public Php5Linter ()
		{
			warningRegex = new Regex ("");
			errorRegex = new Regex (@"(?<message>.*) in (?<file>.*) on line (?<line>\d+)");
		}
		
		public void Lint (PhpProject project, FilePath fileName, 
		                  PhpConfiguration config, BuildResult result)
		{
			if (String.IsNullOrEmpty (fileName))
				throw new ArgumentNullException ("fileName"); else if (config == null)
				throw new ArgumentNullException ("config"); else if (result == null)
				throw new ArgumentNullException ("result"); else if (Runtime == null)
				throw new InvalidOperationException ("No supported runtime!");

			if (!fileName.IsChildPathOf (project.BaseDirectory)) {
				Console.WriteLine ("File is not within our project");
				return;
			}

			fileName = fileName.ToRelative (project.BaseDirectory);

			Process process = BuildLintProcess (fileName);
			process.Start ();
			process.WaitForExit ();

			string output = process.StandardError.ReadToEnd ();

			// Extract warnigs
//			foreach (Match m in m_WarningRegex.Matches (output)) {
//				string lineNum  = m.Groups[m_WarningRegex.GroupNumberFromName ("line")].Value;
//				string message  = m.Groups[m_WarningRegex.GroupNumberFromName ("message")].Value;
//				
//				result.AddWarning (fileName, Int32.Parse (lineNum), 0, String.Empty, message);
//			}
			
			// Extract potential SyntaxError
			foreach (Match m in errorRegex.Matches (output)) {
				string lineNumber = m.Groups[errorRegex.GroupNumberFromName ("line")].Value;
				result.AddError (fileName, Int32.Parse (lineNumber), 0, String.Empty, "SyntaxError");
			}
		}
		
		private Process BuildLintProcess (string fileName)
		{
			ProcessStartInfo startInfo = new ProcessStartInfo ();
			startInfo.FileName = Runtime.Path;
			startInfo.RedirectStandardError = true;
			startInfo.UseShellExecute = false;
			
			Process process = new Process ();
			process.StartInfo = startInfo;
			
			return process;
		}
		
	}
}
