using MonoDevelop.Core;
using MonoDevelop.Projects;
using PhpBinding;
using System;
	
namespace PhpBinding.Linter
{
	public interface IPhpLinter
	{
		void Lint(PhpProject project,
		          FilePath fileName, 
		          PhpConfiguration config, 
		          BuildResult result);
	}
}
