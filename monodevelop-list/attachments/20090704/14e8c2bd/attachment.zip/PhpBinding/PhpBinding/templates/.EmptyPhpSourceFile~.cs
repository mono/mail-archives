<?xml version="1.0"?>
<Template
    Originator="Christian Hergert"
    Language="Python"
    Created="03/21/2008"
    LastModified="03/21/2008">

    <TemplateConfiguration>
        <_Name>Empty Python Source File</_Name>
        <Icon>res:py-icon-32.png</Icon>
        <_Category>General</_Category>
        <LanguageName>Python</LanguageName>
        <_Description>Creates an empty Python source file.</_Description>
    </TemplateConfiguration>

    <TemplateFiles>
        <File DefaultExtension=".py" DefaultName="EmptyPySourceFile"/>
    </TemplateFiles>

    <FileOptions/>

</Template>