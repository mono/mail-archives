<?xml version="1.0"?>
<Template
    Originator="Christian Hergert"
    Language="Python"
    Created="10/1/2008"
    LastModified="10/1/2008">

    <TemplateConfiguration>
        <_Name>Basic Python Script</_Name>
        <Icon>res:py-icon-32.png</Icon>
        <_Category>General</_Category>
        <_Description>Creates an Python script that can parse command line options.</_Description>
        <LanguageName>Python</LanguageName>
    </TemplateConfiguration>

    <TemplateFiles>
<File DefaultExtension=".py" DefaultName="EmptyPySourceFile" AddStandardHeader="True">
<?php

class 	

?>
</File>
    </TemplateFiles>

    <FileOptions/>

</Template>