using System;
using PhpBinding.Linter;

namespace PhpBinding.Runtime
{
	public abstract class AbstractPhpRuntime : IPhpRuntime
	{
		public abstract string Name {
			get;
		}
		
		public abstract string Path {
			get;
			set;
		}
		
		public abstract IPhpLinter Linter {
			get;
		}
		
		public abstract object Clone();
		public abstract string[] GetArguments(PhpConfiguration config);
		
		/*
		protected virtual string Resolve (string commandName)
		{
			List<string> paths;
			
			paths = new List<string> ();
			paths.Add (".");
			
			foreach (string dirName in Environment.GetEnvironmentVariable (
			    "PATH").Split (m_PathSeparators))
			{
				paths.Add (dirName);
			}
			
			foreach (string dirName in paths) {
				string absPath = System.IO.Path.Combine (dirName, commandName);
				
				if (System.IO.File.Exists (absPath)) {
					return absPath;
				}
			}
			
			throw new FileNotFoundException ("Could not locate executable");
		}
		*/
	}
}
