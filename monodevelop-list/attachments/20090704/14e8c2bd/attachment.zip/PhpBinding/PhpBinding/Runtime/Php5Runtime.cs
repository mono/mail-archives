using PhpBinding.Linter;
using MonoDevelop.Core.Serialization;
using System;
using System.Collections.Generic;

namespace PhpBinding.Runtime
{
	public class Php5Runtime : AbstractPhpRuntime
	{
		static readonly string name = "PHP5";
		static readonly string defaultPath = "php5";
		
		[ItemProperty("Path")]
		string path = string.Empty;
		
		[ItemProperty("Linter", ValueType = typeof(IPhpLinter))]
		IPhpLinter linter = null;
		
		public override IPhpLinter Linter {
			get {
				if (linter == null)
					linter = new Php5Linter ();

				(linter as Php5Linter).Runtime = this;

				return linter;
			}
		}
		
		public override string Name {
			get { return name; }
		}
		
		public override string Path {
			get {
//				if (string.IsNullOrEmpty (path)) {
//					path = Resolve (defaultPath);
//				}

				return path;
			}
			set { path = value; }
		}
		
		public override object Clone ()
		{
			Php5Runtime clone = new Php5Runtime ();
			clone.Path = path;

			return clone;
		}

		public override string[] GetArguments (PhpConfiguration config)
		{
			List<string> args = new List<string> ();

			if (config.DebugMode)
				args.Add ("-l");

			return args.ToArray();
		}
	}
}
