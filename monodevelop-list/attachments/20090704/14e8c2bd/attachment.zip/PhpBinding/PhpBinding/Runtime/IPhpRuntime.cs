using System;
using PhpBinding.Linter;

namespace PhpBinding.Runtime
{
	public interface IPhpRuntime : ICloneable
	{
		/// <value>
		/// The unique name of the PHP runtime (ex: PHP53)
		/// </value>
		string Name {
			get;
		}
		
		/// <value>
		/// The path to the PHP runtime (ex: /usr/bin/php)
		/// </value>
		string Path {
			get;
			set;
		}
		
		/// <value>
		/// The linter for the PHP runtime. This can be used to make sure there
		/// are no obvious errors before running.
		/// </value>
		IPhpLinter Linter {
			get;
		}
		
		/// <summary>
		/// Builds a list of arguments to pass to the runtime for running
		/// a project with the passed configuration.
		/// </summary>
		/// <param name="configuration">
		/// A <see cref="PhpConfiguration"/>
		/// </param>
		/// <returns>
		/// A <see cref="System.String"/>
		/// </returns>
		string[] GetArguments (PhpConfiguration configuration);
	}
}
