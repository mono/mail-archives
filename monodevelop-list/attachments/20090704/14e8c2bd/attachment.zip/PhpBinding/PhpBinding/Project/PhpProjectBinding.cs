using MonoDevelop.Projects;
using System;
using System.IO;
using System.Xml;

namespace PhpBinding
{
	public class PhpProjectBinding : IProjectBinding
	{
		public string Name {
			get	{ return "PHP"; }
		}
		
		public Project CreateProject(ProjectCreateInformation info, 
		                             XmlElement projectOptions)
		{
			string language = projectOptions.GetAttribute("language");
			
			return new PhpProject(language, info, projectOptions);
		}
		
		public Project CreateSingleFileProject (string sourceFile)
		{
			ProjectCreateInformation info = new ProjectCreateInformation ();
			info.ProjectName = Path.GetFileNameWithoutExtension (sourceFile);
			info.CombineName = Path.GetDirectoryName (sourceFile);
			info.ProjectBasePath = Path.GetDirectoryName (sourceFile);

			string language = "PHP";
			
			Project project = new PhpProject(language, info, null);
			project.Files.Add(new ProjectFile(sourceFile));
			
			return project;
		}
		
		public bool CanCreateSingleFileProject (string sourceFile)
		{
			return true;
		}
	}
}

