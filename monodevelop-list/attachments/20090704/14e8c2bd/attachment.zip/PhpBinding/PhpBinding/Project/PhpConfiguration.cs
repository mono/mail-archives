using MonoDevelop.Core.Serialization;
using MonoDevelop.Projects;
using PhpBinding.Runtime;
using System;

namespace PhpBinding
{
	public class PhpConfiguration : ProjectConfiguration
	{
		[ItemProperty("Runtime/Interpreter")]
		IPhpRuntime runtime;
		
		[ItemProperty("Runtime/Module")]
		string module;
		
		public IPhpRuntime Runtime {
			get { return runtime; }
			private set { runtime = value; }
		}
		
		public string Module {
			get { return module; }
			set { module = value; }
		}
		
		public PhpConfiguration ()
		{
			runtime = new Php5Runtime ();
		}
		
		public override void CopyFrom (MonoDevelop.Projects.ItemConfiguration configuration)
		{
			PhpConfiguration config = configuration as PhpConfiguration;

			if (config == null)
				throw new ArgumentException ("Not a PhpConfiguration.");

			Module = config.Module;
			Runtime = (IPhpRuntime)config.Runtime.Clone ();
		}

	}
}
