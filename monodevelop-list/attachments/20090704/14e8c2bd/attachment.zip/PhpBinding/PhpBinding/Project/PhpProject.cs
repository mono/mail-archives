using MonoDevelop.Core;
using MonoDevelop.Core.Execution;
using MonoDevelop.Core.Gui;
using MonoDevelop.Core.ProgressMonitoring;
using MonoDevelop.Projects;
using PhpBinding.Linter;
using PhpBinding.Runtime;
using System;
using System.IO;
using System.Xml;

namespace PhpBinding
{
	public enum Language 
	{
		PHP
	}
	
	public class PhpProject : Project
	{
		static readonly string projectType = "PHP";
		
		public override string ProjectType
		{
			get {
				return projectType;
			}
		}
		
		public PhpProject()
		{
			
		}
		
		public PhpProject (string languageName, ProjectCreateInformation info, XmlElement options)
		{
			PhpConfiguration defaultConfig;

			if (string.Equals (languageName, "PHP")) {
				throw new ArgumentException ("Not a PHP project");
			}

			if (info != null) {
				Name = info.ProjectName;
			}

			// Setup our debug configuration
			defaultConfig = CreateConfiguration ("Debug") as PhpConfiguration;
			Configurations.Add (defaultConfig);

			// Setup our release configuration
			defaultConfig = CreateConfiguration ("Release") as PhpConfiguration;
			Configurations.Add (defaultConfig);
		}

		public override SolutionItemConfiguration CreateConfiguration (string configName)
		{
			PhpConfiguration config = new PhpConfiguration ();
			config.Name = configName;

			return config;
		}
		
		protected override BuildResult DoBuild (IProgressMonitor monitor, string configuration)
		{
			BuildResult result = new BuildResult ();
			PhpConfiguration config = (PhpConfiguration)GetConfiguration (configuration);

			if (config.Runtime != null && config.Runtime.Linter != null) {
				// Why does the completion not finder Compiler?
				IPhpLinter linter = config.Runtime.Linter;

				foreach (ProjectFile projectFile in Files) {
					if (projectFile.BuildAction != BuildAction.Compile) {
						continue;
					}

					linter.Lint (this, projectFile.FilePath, config, result);
				}
			}

			return result;
		}
		
		protected override void DoExecute (IProgressMonitor monitor, ExecutionContext context, string configuration)
		{
			PhpConfiguration config = (PhpConfiguration)GetConfiguration (configuration);
			IConsole console;

			if (config.Runtime != null || String.IsNullOrEmpty (config.Module)) {
				MessageService.ShowMessage ("No target module specified.");
				return;
			}

			monitor.Log.WriteLine ("Running project...");

			if (config.ExternalConsole) {
				console = context.ExternalConsoleFactory.CreateConsole (!config.PauseConsoleOutput);
			} else {
				console = context.ConsoleFactory.CreateConsole (!config.PauseConsoleOutput);
			}

			AggregatedOperationMonitor operationMonitor = new AggregatedOperationMonitor (monitor);

			try {
				PhpExecutionCommand cmd = new PhpExecutionCommand (config);

				if (!context.ExecutionHandler.CanExecute (cmd)) {
					monitor.ReportError ("The selected execution mode is not supported for Python projects.", null);
					return;
				}

				IProcessAsyncOperation op = context.ExecutionHandler.Execute (cmd, console);
				operationMonitor.AddOperation (op);
				op.WaitForCompleted ();

				monitor.Log.WriteLine ("The operation exited with code {0}", op.ExitCode);
			} catch (Exception ex) {
				monitor.ReportError("Cannot execute: \"" + config.Runtime.Path + "\"", ex);
			} finally {
				operationMonitor.Dispose ();
				console.Dispose ();
			}
		}
		
		public override bool IsCompileable (string fileName)
		{
			return Path.GetExtension (fileName) == ".php";
		}

	}
}
