using System;
using MonoDevelop.Core.Execution;

namespace PhpBinding
{
	public class PhpExecutionCommand : ExecutionCommand
	{
		public override string CommandString {
			get { return ""; }
		}
		
		public PhpConfiguration Configuration { get; set; }
		
		public PhpExecutionCommand ()
		{
		}
		
		public PhpExecutionCommand (PhpConfiguration config)
		{
			Configuration = config;
		}
	}
}
