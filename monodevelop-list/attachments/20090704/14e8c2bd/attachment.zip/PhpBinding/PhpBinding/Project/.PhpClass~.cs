using System;
using MonoDevelop.Projects;

namespace PhpProject
{
	public enum Language 
	{
		PHP
	}
	
	public class PhpClass : Project
	{
		public PhpClass()
		{
			
		}
		
		public PhpClass(string languageName, ProjectCreateInformation info, XmlElement options)
		{
			
		}
	}
}
