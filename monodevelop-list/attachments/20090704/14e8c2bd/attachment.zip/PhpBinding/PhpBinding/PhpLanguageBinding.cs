using MonoDevelop.Projects;
using MonoDevelop.Projects.CodeGeneration;
using MonoDevelop.Projects.Dom.Parser;
using System;
using System.IO;

namespace PhpBinding
{
	public class PhpLanguageBinding : ILanguageBinding
	{
		public string Language {
			get { return "PHP"; }
		}
		
		public string SingleLineCommentTag { get { return "//"; } }
		public string BlockCommentStartTag { get { return "/*"; } }
		public string BlockCommentEndTag { get { return "*/"; } }
		
		public bool IsSourceCodeFile (string fileName)
		{
			string ext = Path.GetExtension(fileName);
			return (ext.Equals(".php", StringComparison.OrdinalIgnoreCase));
		}
		
		public IParser Parser {
			get { return null; }
		}
		
		public IRefactorer Refactorer {
			get { return null; }
		}
		
		public string GetFileName (string baseName)
		{
			return baseName + ".php";
		}
	}
}
