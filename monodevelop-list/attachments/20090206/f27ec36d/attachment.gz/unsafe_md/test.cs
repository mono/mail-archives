class Test
{
	static void Main()
	{
		unsafe
		{
			int a = 0;
			int* b = &a;
		}
	}
}
