using System;
using System.Web;
using System.Web.UI;
using Reportman.Drawing;

namespace WebReport
{


public partial class Default : System.Web.UI.Page
{
	protected void Page_Load(object sender, EventArgs e)
    {
		Session["Name"] = "anonymous";
		PreviewWeb1.PreviewControl.ReportFileName = "sales_express.rep" ;
    }
	protected void Button1_Click(object sender, EventArgs e)
	{
	}
	protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
	{
	}
	protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
	{

	}

		
}
}

