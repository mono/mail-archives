#!/bin/bash
#
strWRAP="--wrap"
strCOMMAND="Cs-ObexFtp "
strVERSION="1.5"
strWIZARD="--wizard"
strPROG="Xdialog --title "Setup-of-Cs-ObexFtp" --stdout $strWRAP"
#
#

function msgSTART()
	{
		msgHELLO=`$strPROG --backtitle "Welcome to Cs-ObexFtp setup v $strVERSION" --msgbox "Click Ok to start the installation" 0 0`
		case $? in
			0)
				getFILECONFIG;;
			255)
				msgBYE;;
		esac
	}

function getFILECONFIG()
	{
	  
		MonoVer=`( mono -V|grep vers|cut -d " " -f 5)`
		
		$strPROG --backtitle "Checking the mono RT version" --msgbox "Detected version : "$MonoVer"\nI'm going to download and instal the latest version\nPlease click on OK to continue" 0 0
				case $? in
			0)
		mkdir ~/tmp/mono-latest	
		wget -P ~/tmp/mono-latest http://mono.ximian.com/daily/mono-latest.tar.bz2
		cd ~/tmp/mono-latest
		tar -xvf ./mono-latest.tar.bz2
		#cd mono-latest
		rm -f ./mono-latest.tar.bz2
		LastMono=`ls`
		cd $LastMono
		./configure --prefix=/usr
		make
		su root - c make install
		exit 0;;
			255)
				msgBYE;;
		esac
	}
#
#	
function msgBYE()
	# Displays a "farewell" screen.  If you don't want it, comment out below.
	{
		$strPROG --backtitle "Thank s @++" --msgbox "\nPlease click on OK to leave" 0 0
		exit 0;
	}

strWIZARD="--wizard"
echo "No parameter passed... starting in Wizard mode by default..."
msgSTART