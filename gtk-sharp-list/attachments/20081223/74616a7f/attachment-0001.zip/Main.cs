
using System;
using System.Diagnostics;
using System.Collections.Generic;
using Cairo;

namespace DrawingBenchmark
{
	class MainClass
	{
		public static void Main(string[] args)
		{
			Gtk.Application.Init();
			MainWindow win = new MainWindow();
			win.Resize(800, 800);
			win.ShowAll();
			Gtk.Application.Run();
		}
	}



	/// <summary>
	/// The main window.
	/// </summary>
	public class MainWindow : Gtk.Window
	{

		public MainWindow() : base(Gtk.WindowType.Toplevel)
		{
			Title = "Gtk# Drawing Benchmark";

			DeleteEvent += OnDeleteEvent;

			Gtk.VBox vbox = new Gtk.VBox();
			Add(vbox);

			canvas = new Canvas(64);
			canvas.FrameRateUpdated += OnFrameRateUpdated;
			vbox.PackEnd(canvas, true, true, 0);

			Gtk.HBox controlBox = new Gtk.HBox();
			vbox.PackStart(controlBox, false, true, 4);

			runButton = new Gtk.ToggleButton("Run");
			runButton.Clicked += OnToggleRun;
			controlBox.PackStart(runButton, false, true, 0);

			frameRateLabel = new Gtk.Label("N/A fps");
			controlBox.PackEnd(frameRateLabel, false, true, 0);
			
		}

		void OnDeleteEvent(object o, Gtk.DeleteEventArgs args)
		{
			Gtk.Application.Quit();
		}

		Canvas canvas;

		Gtk.ToggleButton runButton;

		void OnToggleRun(object sender, EventArgs e)
		{
			// adjust the button label
			if (runButton.Active)
				runButton.Label = "Stop";
			else
				runButton.Label = "Run";
			
			canvas.Running = runButton.Active;
			canvas.QueueDraw();
		}

		Gtk.Label frameRateLabel;

		void OnFrameRateUpdated(double frameRate)
		{
			if (runButton.Active)
				frameRateLabel.Text = String.Format("{0:F} fps", frameRate);
		}
		
	}


	/// <summary>
	/// Class responsible for rendering one of the things that moves around the screen.
	/// </summary>
	public class Sprite
	{

		double x, y, radius, speed;

		public Sprite(double x, double y, double radius, double speed)
		{
			this.x = x;
			this.y = y;
			this.radius = radius;
			this.speed = speed;
		}

		LinearGradient cairoPattern;

		/// <summary>
		/// Called when the canvas is resized.
		/// </summary>
		public void Resize(int width, int height)
		{

			// create the cairo pattern			
			cairoPattern = new LinearGradient(0, y * height - radius, 0, y * height + radius);
			cairoPattern.AddColorStop(0, new Color(1, 1, 1));
			cairoPattern.AddColorStop(1, new Color(0, 0, 1));
		}

		/// <summary>
		/// Step the position of the sprite by one speed.
		/// </summary>
		private void Step()
		{
			// alter the position based on the speed
			if (x + speed > 1 || x + speed < 0) // hit the edge, start going the other way
				speed = -speed;
			x += speed;
		}

		/// <summary>
		/// Renders the sprite to a Cairo context with the given size.
		/// </summary>
		public void RenderToCairo(Context cr, double width, double height)
		{
			Step();
			
			cr.Pattern = cairoPattern;

			// draw the sprite
			cr.Arc(x * width, y * height, radius, 0, 2*Math.PI);
			cr.Fill();
		}

		
	}

	
	
	/// <summary>
	/// Canvas that the sprites are drawn on.
	/// </summary>
	public class Canvas : Gtk.DrawingArea
	{
		/// <summary>
		/// Constructs the canvas with the given number of sprites.
		/// </summary>
		/// <param name="numSprites"> </param>
		public Canvas(int numSprites)
		{
			double maxSize = 48;
			double maxSpeed = 0.01;
			Random rand = new Random();
			for (int i=0; i<numSprites; i++)
				sprites.Add(new Sprite(rand.NextDouble(), rand.NextDouble(), rand.NextDouble()*maxSize, (2*rand.NextDouble()-1)*maxSpeed));
			
			stopWatch = new Stopwatch();
		}

		Stopwatch stopWatch;
		
		long lastTick = 0;

		
		List<Sprite> sprites = new List<Sprite>();


		private bool running = false;
		//// <value>
		/// Wether the canvas should be rendering the scene.
		/// </value>
		public bool Running
		{
			set
			{
				running = value;
				if (running)
					stopWatch.Start();
				else
					stopWatch.Stop();
			}
		}

		protected override void OnSizeAllocated (Gdk.Rectangle allocation)
		{
			base.OnSizeAllocated(allocation);

			foreach (Sprite sprite in sprites)
				sprite.Resize(allocation.Width, allocation.Height);
		}


		public delegate void FrameRateUpdatedHandler(double frameRate);

		/// <summary>
		/// Gets raised when the frame rate is recomputed.
		/// </summary>
		public event FrameRateUpdatedHandler FrameRateUpdated;

		private int frameCount = 0;

		private int framesToCount = 8;

		protected override bool OnExposeEvent (Gdk.EventExpose evnt)
		{
			base.OnExposeEvent(evnt);

			using (Context cr = Gdk.CairoHelper.Create(GdkWindow))
			{
				// background
				cr.Color = new Color(1,1,1);
				cr.Rectangle(0, 0, Allocation.Width, Allocation.Height);
				cr.Fill();

				foreach (Sprite sprite in sprites)
					sprite.RenderToCairo(cr, Allocation.Width, Allocation.Height);
			}
				

			// keep track of frame rate
			frameCount++;
			if (frameCount == framesToCount)
			{
				FrameRateUpdated(Stopwatch.Frequency / (double)(stopWatch.ElapsedTicks-lastTick) * framesToCount);
				lastTick = stopWatch.ElapsedTicks;
				frameCount = 0;
			}

			if (running)
				QueueDraw();			
			
			return true;
		}
	}

	
}