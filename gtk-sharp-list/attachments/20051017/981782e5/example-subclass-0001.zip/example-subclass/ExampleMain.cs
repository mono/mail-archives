/* Adding a subclassed widget instance to a glade window testcase.
 */

using System;

using GLib;
using Gtk;
using Glade;


public class
ExampleMain
{
	[Glade.Widget]
	Gtk.Window winMain;	// The main window

	[Glade.Widget]
	Gtk.VBox mainVBox;	// Main window VBox


	public static void Main (string[] args)
	{
		Application.Init ();

		ExampleMain ex = new ExampleMain ();
		ex.Init ();

		Application.Run ();
	}

	private void Init ()
	{
		Glade.XML gxml = new Glade.XML ("example.glade", "winMain", null);
		gxml.Autoconnect (this);

		/* Setup the label subclass
		 */
		ExampleWidget subclassedWidget = new ExampleWidget ("labeltext");
		mainVBox.Add (subclassedWidget);
	}


	/*** Event handlers
	 */
	public void OnMainWinDelete (object obj, DeleteEventArgs args)
	{
		Application.Quit ();

		args.RetVal = true;
	}
}


public class
ExampleWidget : Gtk.Label
{
	public ExampleWidget (string labelText)
		: base ("sub: " + labelText)
	{
	}
}


