using System;
using Gtk;

namespace Project1
{
    /// <summary>
    /// Summary description for Main.
    /// </summary>
    public class Main1
    {
       /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        public static void Main(string[] args)
        {
            Application.Init();
            //new TestDialog().Run();
            new TestWindow().DoStuff();
            Application.Run();
        }
    }
}
