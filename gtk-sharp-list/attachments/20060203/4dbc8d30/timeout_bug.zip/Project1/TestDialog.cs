using System;
using System.Text;
using Gtk;
using GLib;
using Glade;
using System.Threading;

namespace Project1
{
    public class TestDialog
    {
        [Widget]
        Dialog TestDialog1;
        [Widget]
        Button cancelbutton1;
        [Widget]
        Button okbutton1;
           

        public TestDialog()
        {
            
        }

        public Gtk.ResponseType Run()
        {
            Glade.XML gxml = new Glade.XML(null, "Project1.TestGUI.glade", "TestDialog1", null);
            gxml.Autoconnect(this);

            RefreshListAsync();

            return (ResponseType)this.TestDialog1.Run();            
        }

        private void RefreshListAsync()
        {
            okbutton1.Sensitive = false;
            new ThreadStart(a).BeginInvoke(null, null);
        }
        private void a()
        {
            System.Threading.Thread.Sleep(300);
            //Application.Invoke(b);
            GLib.Timeout.Add(0, new GLib.TimeoutHandler(b));
        }

		private bool b()
        {
            okbutton1.Sensitive = true;
			return false;
        }
    }
}