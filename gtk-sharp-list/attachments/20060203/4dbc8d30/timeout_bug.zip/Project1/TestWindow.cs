using System;
using System.Text;
using Gtk;
using GLib;
using Glade;
using System.Threading;

namespace Project1
{
    public class TestWindow
    {
        [Widget]
        Window TestWindow1;
        [Widget]
        Button okbutton1;

        public TestWindow()
        {
            Glade.XML gxml = new Glade.XML(null, "Project1.TestGUI.glade", "TestWindow1", null);
            gxml.Autoconnect(this); 
           
			//GLib.IdleHandler idleHandler = new GLib.IdleHandler(new IdleHandler(idle));
			//GLib.Idle.Add(idleHandler);
        }

        public void DoStuff()
        {           
            RefreshGUIAsync();
        }

        private void RefreshGUIAsync()
        {
            okbutton1.Sensitive = false;
            new System.Threading.Thread(new ThreadStart(calc)).Start();
        }

        private void calc()
        {
            System.Threading.Thread.Sleep(300);
            //Application.Invoke(UpdateGUI);
            GLib.Timeout.Add(0, new TimeoutHandler(UpdateGUI));
        }

        private bool UpdateGUI()
        {
            okbutton1.Sensitive = true;
			return false;
        }

		private bool idle() 
		{
			return true;
		}		
	}	
}