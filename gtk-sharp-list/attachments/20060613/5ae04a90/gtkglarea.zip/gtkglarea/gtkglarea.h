/*
 * Copyright (C) 1997-1998 Janne L�f <jlof@mail.student.oulu.fi>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free
 * Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */


#ifndef __GTK_GL_AREA_H__
#define __GTK_GL_AREA_H__

#include <gdk/gdk.h>
#include "gdkgl.h"
#include <gtk/gtkdrawingarea.h>

#if defined(WIN32) && defined(_USRDLL)
#define GTKGLAREA_EXPORT __declspec(dllexport)
#else
#define GTKGLAREA_EXPORT
#endif

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#define GTK_TYPE_GL_AREA            (gtk_gl_area_get_type())
#define GTK_GL_AREA(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), GTK_TYPE_GL_AREA, GtkGLArea))
#define GTK_GL_AREA_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST (klass, GTK_TYPE_GL_AREA, GtkGLAreaClass))
#define GTK_IS_GL_AREA(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), GTK_TYPE_GL_AREA))
#define GTK_IS_GL_AREA_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), GTK_TYPE_GL_AREA))
#define GTK_GL_AREA_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), GTK_TYPE_GL_AREA, GtkGLArea))


typedef struct _GtkGLArea       GtkGLArea;
typedef struct _GtkGLAreaClass  GtkGLAreaClass;


struct _GtkGLArea
{
  GtkDrawingArea  darea;
  GdkGLContext *glcontext;
};

struct _GtkGLAreaClass
{
  GtkDrawingAreaClass parent_class;
};

GTKGLAREA_EXPORT GtkType    gtk_gl_area_get_type   (void);
GTKGLAREA_EXPORT GtkWidget* gtk_gl_area_new        (int       *attrList);
GTKGLAREA_EXPORT GtkWidget* gtk_gl_area_share_new  (int       *attrList,
                                   GtkGLArea *share);
GTKGLAREA_EXPORT GtkWidget* gtk_gl_area_new_vargs  (GtkGLArea *share,
				   ...);


GTKGLAREA_EXPORT gint       gtk_gl_area_make_current(GtkGLArea *glarea);

GTKGLAREA_EXPORT gint       gtk_gl_area_begingl    (GtkGLArea *glarea); /* deprecated, use gtk_gl_area_make_current */
GTKGLAREA_EXPORT void       gtk_gl_area_endgl      (GtkGLArea *glarea); /* deprecated */

GTKGLAREA_EXPORT void       gtk_gl_area_swapbuffers(GtkGLArea *glarea); /* deprecated */
GTKGLAREA_EXPORT void       gtk_gl_area_swap_buffers(GtkGLArea *glarea);

GTKGLAREA_EXPORT void       gtk_gl_area_size       (GtkGLArea *glarea,  /* deprecated, use gtk_drawing_area_size() */
				   gint width,
				   gint height);

#ifdef __cplusplus
}
#endif /* __cplusplus */


#endif /* __GTK_GL_AREA_H__ */
