gmcs -pkg:gtk-sharp-2.0 -pkg:glade-sharp-2.0 -pkg:gconf-sharp-2.0 -pkg:gnome-vfs-sharp-2.0 -pkg:gio-sharp-2.0 -out:test.exe *.cs
