using GLib;
using System;

namespace Test
{
	public class AppMain : GLib.Object
	{
		public static void Main()
		{
			Gtk.Application.Init();
			
			File afile = FileFactory.NewForUri("file:///home");
			//Console.WriteLine("test "+afile.Path); // Works
			Console.WriteLine("test "+afile.Uri); // Doesn't Work
		}
	}
}
