// project created on 11/07/2005 at 22:27
using System;
using Gtk;

class MainClass
{
	public static void Main (string[] args)
	{
		Application.Init ();
		new MyWindow ();
		Application.Run ();
	}
}