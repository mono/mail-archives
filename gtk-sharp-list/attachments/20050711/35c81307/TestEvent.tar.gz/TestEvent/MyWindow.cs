using System;
using Gtk;

public class MyWindow : Window
{	
	public MyWindow () : base ("MyWindow")
	{
		this.SetDefaultSize (400, 300);
		
		//-1- VBOX
		Gtk.VBox vbox = new Gtk.VBox();
		this.Add(vbox);
		
		//-2- Entry
		Gtk.Entry txt = new Gtk.Entry();
		vbox.PackStart(txt);
		this.record( (Gtk.Widget) txt);
		
		//-3- Combo
		Gtk.Combo cbb = new Gtk.Combo();
		vbox.PackStart(cbb);
		this.record( (Gtk.Widget) cbb);
		
		//-4- ComboBox
		Gtk.ComboBox cbb1 = new Gtk.ComboBox();
		vbox.PackStart(cbb1);
		this.record( (Gtk.Widget) cbb1);
		
		//-5- Bouton
		Gtk.Button btn = new Gtk.Button();
		vbox.PackStart(btn);
		this.record( (Gtk.Widget) btn);
		
		//-6-
		Gtk.Calendar cal = new Gtk.Calendar();
		vbox.PackStart(cal);
		this.record( (Gtk.Widget) cal);
		
		//-7-
		Gtk.CheckButton chk = new Gtk.CheckButton();
		vbox.PackStart(chk);
		this.record( (Gtk.Widget) chk);
		
		
		this.DeleteEvent += new DeleteEventHandler (OnMyWindowDelete);
		this.ShowAll ();
	}
	
	//<summary></summary>
	void OnMyWindowDelete (object sender, DeleteEventArgs a)
	{
		Application.Quit ();
		a.RetVal = true;
	}
	
	
	//<summary> Record the new widget and listen to the two events </summary>
	private void record(Gtk.Widget wid) {
		wid.FocusInEvent += new Gtk.FocusInEventHandler(this.handleFocusInEvent);
		wid.FocusOutEvent += new Gtk.FocusOutEventHandler(this.handleFocusOutEvent);
	}
	
	//<summary> Handle the FocusInEvent </summary>
	private void handleFocusInEvent(object sender, Gtk.FocusInEventArgs e) {
		System.Console.WriteLine("FocusInEvent : " + ((Gtk.Widget) sender).Name);
	}
	
	//<summary> Handle the FocusOutEvent </summary>
	private void handleFocusOutEvent(object sender, Gtk.FocusOutEventArgs e ) {
		System.Console.WriteLine("FocusOutEvent : "  + ((Gtk.Widget) sender).Name);
	}
}