namespace test1
{
	using System;

	public enum Enum1 : int { A, B, C, D }
	public enum Enum2 : short { A, B, C, D }

	public class EnumUserAttribute : Attribute
	{
		public enum Enum3 : long { A, B, C, D }

		public EnumUserAttribute ()
		{
		}

		public EnumUserAttribute (Enum1 x, Enum2 y)
		{
			f1 = x;
			f2 = y;
		}

		public EnumUserAttribute (object x)
		{
			o = x;
		}

		public Enum1 p1
		{
			get { return f1; }
			set { f1 = value; }
		}
		public Enum2 p2
		{
			get { return f2; }
			set { f2 = value; }
		}
		public object po
		{
			get { return o; }
			set { o = value; }
		}
		public Enum1 f1;
		public Enum2 f2;
		public object o;
	}
}
