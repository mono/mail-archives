// Permission is hereby granted, free of charge, to any person obtaining
// a copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to
// permit persons to whom the Software is furnished to do so, subject to
// the following conditions:
// 
// The above copyright notice and this permission notice shall be
// included in all copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
// NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
// LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
// OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
//
// Authors:
//        Alejandro Serrano "Serras" (trupill@yahoo.es)
//

using System;
using System.Collections.Generic;

namespace System.Query
{       
        public static partial class Sequence
        {
                // This methods are not included in the
                // .NET Standard Query Operators Specification,
                // but they provide additional useful commands
                
                #region Compare
                
                [System.Runtime.CompilerServices.Extension]
                private static bool Equals<T> (
                        T first, T second)
                {
                        // Mostly, values in Enumerable<T> 
                        // sequences need to be compared using
                        // Equals and GetHashCode
                        
                        if (first == null || second == null)
                                return (first == null && second == null);
                        else
                                return ((first.Equals (second) ||
                                         first.GetHashCode () == second.GetHashCode ()));
                }
                
                #endregion
                
                #region Contains
                
                [System.Runtime.CompilerServices.Extension]
                public static bool Contains<T> (
                        IEnumerable<T> source,
                        T value)
                {
                        if (source is ICollection<T>) {
                                ICollection<T> collection = (ICollection<T>)source;
                                return collection.Contains(value);
                        }
                        else {
                                foreach (T element in source)
                                        if (Equals(element, value))
                                                return true;
                                return false;
                        }
                }
                
                #endregion

                #region IndexOf
                
                [System.Runtime.CompilerServices.Extension]
                public static int IndexOf<T>(
                        IEnumerable<T> source,
                        T item)
                {
                        int counter = 0;
                        foreach (T element in source) {
                                if (Equals(element, item))
                                        return counter;
                                counter++;
                        }
                        // The item was not found
                        return -1;
                }
                
                #endregion
        }
}
