// Permission is hereby granted, free of charge, to any person obtaining
// a copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to
// permit persons to whom the Software is furnished to do so, subject to
// the following conditions:
// 
// The above copyright notice and this permission notice shall be
// included in all copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
// NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
// LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
// OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
//
// Authors:
//        Alejandro Serrano "Serras" (trupill@yahoo.es)
//

using System;
using System.Collections.Generic;

namespace System.Query
{        
        public static partial class Sequence
        {
                #region First
                
                [System.Runtime.CompilerServices.Extension]
                public static T First<T> (
                        IEnumerable<T> source)
                {
                        if (source == null)
                                throw new ArgumentNullException ();
                        
                        foreach (T element in source)
                                return element;
                        
                        throw new EmptySequenceException();
                }
                
                [System.Runtime.CompilerServices.Extension]
                public static T First<T> (
                        IEnumerable<T> source,
                        Func<T, bool> predicate)
                {
                        if (source == null || predicate == null)
                                throw new ArgumentNullException ();
                        
                        foreach (T element in source) {
                                if (predicate (element))
                                        return element;
                        }
                        
                        throw new EmptySequenceException ();
                }
                
                [System.Runtime.CompilerServices.Extension]
                public static T First<T> (
                        IEnumerable<T> source,
                        Func<T, int, bool> predicate)
                {
                        if (source == null || predicate == null)
                                throw new ArgumentNullException ();
                        
                        int counter = 0;
                        foreach (T element in source) {
                                if (predicate(element, counter))
                                        return element;
                                counter++;
                        }
                        
                        throw new EmptySequenceException ();
                }
                
                #endregion
                
                #region FirstOrDefault
                
                [System.Runtime.CompilerServices.Extension]
                public static T FirstOrDefault<T> (
                        IEnumerable<T> source)
                {
                        if (source == null)
                                throw new ArgumentNullException ();
                        
                        foreach (T element in source)
                                return element;
                        
                        return default (T);
                }
                
                [System.Runtime.CompilerServices.Extension]
                public static T FirstOrDefault<T> (
                        IEnumerable<T> source,
                        Func<T, bool> predicate)
                {
                        if (source == null || predicate == null)
                                throw new ArgumentNullException ();
                        
                        foreach (T element in source) {
                                if (predicate (element))
                                        return element;
                        }
                        
                        return default (T);
                }
                
                [System.Runtime.CompilerServices.Extension]
                public static T FirstOrDefault<T> (
                        IEnumerable<T> source,
                        Func<T, int, bool> predicate)
                {
                        if (source == null || predicate == null)
                                throw new ArgumentNullException ();
                        
                        int counter = 0;
                        foreach (T element in source) {
                                if (predicate(element, counter))
                                        return element;
                                counter++;
                        }
                        
                        return default (T);
                }
                
                #endregion
                
                #region ElementAt
                
                [System.Runtime.CompilerServices.Extension]
                public static T ElementAt<T> (
                        IEnumerable<T> source,
                        int index)
                {
                        if (source == null)
                                throw new ArgumentNullException ();
                        if (index < 0)
                                throw new ArgumentOutOfRangeException ();
                        
                        if (source is IList<T>)
                                return ((IList<T>)source)[index];
                        else {
                                int counter = 0;
                                foreach (T element in source) {
                                        if (counter == index)
                                                return element;
                                        counter++;
                                }
                                throw new ArgumentOutOfRangeException();
                        }
                }
                
                #endregion
        }
}
