// Permission is hereby granted, free of charge, to any person obtaining
// a copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to
// permit persons to whom the Software is furnished to do so, subject to
// the following conditions:
// 
// The above copyright notice and this permission notice shall be
// included in all copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
// NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
// LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
// OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
//
// Authors:
//        Alejandro Serrano "Serras"        (trupill@yahoo.es)
//

using System;
using System.Collections.Generic;

namespace System.Query
{        
        public static partial class Sequence
        {
                #region Count
                
                [System.Runtime.CompilerServices.Extension]
                public static int Count<T> (
                        IEnumerable<T> source)
                {
                        if (source == null)
                                throw new ArgumentNullException ();
                        
                        if (source is ICollection<T>)
                                return ((ICollection<T>)source).Count;
                        else {
                                int counter = 0;
                                foreach (T element in source)
                                        counter++;
                                return counter;
                        }
                }
                
                [System.Runtime.CompilerServices.Extension]
                public static int Count<T> (
                        IEnumerable<T> source,
                        Func<T, bool> selector)
                {
                        if (source == null || selector == null)
                                throw new ArgumentNullException ();
                        
                        int counter = 0;
                        foreach (T element in source)
                                if (selector(element))
                                        counter++;
                        
                        return counter;
                }
                
                [System.Runtime.CompilerServices.Extension]
                public static int Count<T> (
                        IEnumerable<T> source,
                        Func<T, int, bool> selector)
                {
                        if (source == null || selector == null)
                                throw new ArgumentNullException ();
                        
                        int counter = 0;
                        int elementIndex = 0;
                        foreach (T element in source) {
                                if (selector (element, elementIndex))
                                        counter++;
                                elementIndex++;
                        }
                        
                        return counter;
                }
                
                #endregion
                
                #region Sum
                
                [System.Runtime.CompilerServices.Extension]
                public static int Sum (
                        IEnumerable<int> source)
                {
                        if (source == null)
                                throw new ArgumentNullException ();
                        
                        int sum = 0;
                        foreach (int element in source)
                                sum += element;
                        
                        return sum;
                }
                
                [System.Runtime.CompilerServices.Extension]
                public static int Sum<T> (
                        IEnumerable<T> source,
                        Func<T, int> selector)
                {
                        if (source == null || selector == null)
                                throw new ArgumentNullException ();
                        
                        int sum = 0;
                        foreach (T element in source)
                                sum += selector (element);
                        
                        return sum;
                }
                
                [System.Runtime.CompilerServices.Extension]
                public static int? Sum (
                        IEnumerable<int?> source)
                {
                        if (source == null)
                                throw new ArgumentNullException ();
                        
                        int? sum = 0;
                        foreach (int? element in source)
                                if (element.HasValue)
                                        sum += element.Value;
                        
                        return sum;
                }
                
                [System.Runtime.CompilerServices.Extension]
                public static int? Sum<T> (
                        IEnumerable<T> source,
                        Func<T, int?> selector)
                {
                        if (source == null || selector == null)
                                throw new ArgumentNullException ();
                        
                        int? sum = 0;
                        foreach (T element in source) {
                                int? item = selector (element);
                                if (item.HasValue)
                                        sum += item.Value;
                        }
                        
                        return sum;
                }

                [System.Runtime.CompilerServices.Extension]
                public static long Sum (
                        IEnumerable<long> source)
                {
                        if (source == null)
                                throw new ArgumentNullException ();
                        
                        long sum = 0;
                        foreach (long element in source)
                                sum += element;
                        
                        return sum;
                }
                
                [System.Runtime.CompilerServices.Extension]
                public static long Sum<T> (
                        IEnumerable<T> source,
                        Func<T, long> selector)
                {
                        if (source == null || selector == null)
                                throw new ArgumentNullException ();
                        
                        long sum = 0;
                        foreach (T element in source)
                                sum += selector (element);
                        
                        return sum;
                }
                
                [System.Runtime.CompilerServices.Extension]
                public static long? Sum (
                        IEnumerable<long?> source)
                {
                        if (source == null)
                                throw new ArgumentNullException ();
                        
                        long? sum = 0;
                        foreach (long? element in source)
                                if (element.HasValue)
                                        sum += element.Value;
                        
                        return sum;
                }
                
                [System.Runtime.CompilerServices.Extension]
                public static long? Sum<T> (
                        IEnumerable<T> source,
                        Func<T, long?> selector)
                {
                        if (source == null || selector == null)
                                throw new ArgumentNullException ();
                        
                        long? sum = 0;
                        foreach (T element in source) {
                                long? item = selector (element);
                                if (item.HasValue)
                                        sum += item.Value;
                        }
                        
                        return sum;
                }
                
                [System.Runtime.CompilerServices.Extension]
                public static double Sum (
                        IEnumerable<double> source)
                {
                        if (source == null)
                                throw new ArgumentNullException ();
                        
                        double sum = 0;
                        foreach (double element in source)
                                sum += element;
                        
                        return sum;
                }
                
                [System.Runtime.CompilerServices.Extension]
                public static double Sum<T> (
                        IEnumerable<T> source,
                        Func<T, double> selector)
                {
                        if (source == null || selector == null)
                                throw new ArgumentNullException ();
                        
                        double sum = 0;
                        foreach (T element in source)
                                sum += selector (element);
                        
                        return sum;
                }
                
                [System.Runtime.CompilerServices.Extension]
                public static double? Sum (
                        IEnumerable<double?> source)
                {
                        if (source == null)
                                throw new ArgumentNullException ();
                        
                        double? sum = 0;
                        foreach (double? element in source)
                                if (element.HasValue)
                                        sum += element.Value;
                        
                        return sum;
                }
                
                [System.Runtime.CompilerServices.Extension]
                public static double? Sum<T> (
                        IEnumerable<T> source,
                        Func<T, double?> selector)
                {
                        if (source == null || selector == null)
                                throw new ArgumentNullException ();
                        
                        double? sum = 0;
                        foreach (T element in source) {
                                double? item = selector (element);
                                if (item.HasValue)
                                        sum += item.Value;
                        }
                        
                        return sum;
                }
                
                [System.Runtime.CompilerServices.Extension]
                public static decimal Sum (
                        IEnumerable<decimal> source)
                {
                        if (source == null)
                                throw new ArgumentNullException ();
                        
                        decimal sum = 0;
                        foreach (decimal element in source)
                                sum += element;
                        
                        return sum;
                }
                
                [System.Runtime.CompilerServices.Extension]
                public static decimal Sum<T> (
                        IEnumerable<T> source,
                        Func<T, decimal> selector)
                {
                        if (source == null || selector == null)
                                throw new ArgumentNullException ();
                        
                        decimal sum = 0;
                        foreach (T element in source)
                                sum += selector (element);
                        
                        return sum;
                }
                
                [System.Runtime.CompilerServices.Extension]
                public static decimal? Sum (
                        IEnumerable<decimal?> source)
                {
                        if (source == null)
                                throw new ArgumentNullException ();
                        
                        decimal? sum = 0;
                        foreach (decimal? element in source)
                                if (element.HasValue)
                                        sum += element.Value;
                        
                        return sum;
                }
                
                [System.Runtime.CompilerServices.Extension]
                public static decimal? Sum<T> (
                        IEnumerable<T> source,
                        Func<T, decimal?> selector)
                {
                        if (source == null || selector == null)
                                throw new ArgumentNullException ();
                        
                        decimal? sum = 0;
                        foreach (T element in source) {
                                decimal? item = selector (element);
                                if (item.HasValue)
                                        sum += item.Value;
                        }
                        
                        return sum;
                }
                
                #endregion
                
                #region Min
                
                [System.Runtime.CompilerServices.Extension]
                public static int Min (
                        IEnumerable<int> source)
                {
                        if (source == null)
                                throw new ArgumentNullException ();
                        
                        int minimum = int.MaxValue;
                        int counter = 0;
                        foreach (int element in source) {
                                if (element < minimum)
                                        minimum = element;
                                counter++;
                        }
                        
                        if (counter == 0)
                                throw new EmptySequenceException ();
                        else
                                return minimum;
                }
                
                [System.Runtime.CompilerServices.Extension]
                public static int? Min (
                        IEnumerable<int?> source)
                {
                        if (source == null)
                                throw new ArgumentNullException ();
                        
                        bool onlyNull = true;
                        int? minimum = int.MaxValue;
                        foreach (int? element in source) {
                                if (element.HasValue) {
                                        onlyNull = false;
                                        if (element < minimum)
                                                minimum = element;
                                }
                        }
                        return (onlyNull ? null : minimum);
                }
                
                [System.Runtime.CompilerServices.Extension]
                public static long Min (
                        IEnumerable<long> source)
                {
                        if (source == null)
                                throw new ArgumentNullException ();
                        
                        long minimum = long.MaxValue;
                        int counter = 0;
                        foreach (long element in source) {
                                if (element < minimum)
                                        minimum = element;
                                counter++;
                        }
                        
                        if (counter == 0)
                                throw new EmptySequenceException ();
                        else
                                return minimum;
                }
                
                [System.Runtime.CompilerServices.Extension]
                public static long? Min (
                        IEnumerable<long?> source)
                {
                        if (source == null)
                                throw new ArgumentNullException ();
                        
                        bool onlyNull = true;
                        long? minimum = long.MaxValue;
                        foreach (long? element in source) {
                                if (element.HasValue) {
                                        onlyNull = false;
                                        if (element < minimum)
                                                minimum = element;
                                }
                        }
                        return (onlyNull ? null : minimum);
                }
                
                [System.Runtime.CompilerServices.Extension]
                public static double Min (
                        IEnumerable<double> source)
                {
                        if (source == null)
                                throw new ArgumentNullException ();
                        
                        double minimum = double.MaxValue;
                        int counter = 0;
                        foreach (double element in source) {
                                if (element < minimum)
                                        minimum = element;
                                counter++;
                        }
                        
                        if (counter == 0)
                                throw new EmptySequenceException ();
                        else
                                return minimum;
                }
                
                [System.Runtime.CompilerServices.Extension]
                public static double? Min (
                        IEnumerable<double?> source)
                {
                        if (source == null)
                                throw new ArgumentNullException ();
                        
                        bool onlyNull = true;
                        double? minimum = double.MaxValue;
                        foreach (double? element in source) {
                                if (element.HasValue) {
                                        onlyNull = false;
                                        if (element < minimum)
                                                minimum = element;
                                }
                        }
                        return (onlyNull ? null : minimum);
                }
                
                [System.Runtime.CompilerServices.Extension]
                public static decimal Min (
                        IEnumerable<decimal> source)
                {
                        if (source == null)
                                throw new ArgumentNullException ();
                        
                        decimal minimum = decimal.MaxValue;
                        int counter = 0;
                        foreach (decimal element in source) {
                                if (element < minimum)
                                        minimum = element;
                                counter++;
                        }
                        
                        if (counter == 0)
                                throw new EmptySequenceException ();
                        else
                                return minimum;
                }
                
                [System.Runtime.CompilerServices.Extension]
                public static decimal? Min (
                        IEnumerable<decimal?> source)
                {
                        if (source == null)
                                throw new ArgumentNullException ();
                        
                        bool onlyNull = true;
                        decimal? minimum = decimal.MaxValue;
                        foreach (decimal? element in source) {
                                if (element.HasValue) {
                                        onlyNull = false;
                                        if (element < minimum)
                                                minimum = element;
                                }
                        }
                        return (onlyNull ? null : minimum);
                }
                
                [System.Runtime.CompilerServices.Extension]
                public static T Min<T> (
                        IEnumerable<T> source)
                {
                        if (source == null)
                                throw new ArgumentNullException ();
                        
                        bool notAssigned = true;
                        T minimum = default (T);
                        int counter = 0;
                        foreach (T element in source) {
                                if (notAssigned) {
                                        minimum = element;
                                        notAssigned = false;
                                }
                                else {
                                        int comparison;
                                        if (element is IComparable<T>)
                                                comparison = ((IComparable<T>)element).CompareTo (minimum);
                                        else if (element is System.IComparable)
                                                comparison = ((System.IComparable)element).CompareTo (minimum);
                                        else
                                                throw new ArgumentNullException();
                                        
                                        if (comparison < 0)
                                                minimum = element;
                                }
                                counter++;
                        }
                        
                        if (counter == 0)
                                throw new EmptySequenceException ();
                        else
                                return minimum;
                }
                
                [System.Runtime.CompilerServices.Extension]
                public static int Min<T> (
                        IEnumerable<T> source,
                        Func<T, int> selector)
                {
                        if (source == null || selector == null)
                                throw new ArgumentNullException ();
                        
                        int minimum = int.MaxValue;
                        int counter = 0;
                        foreach (T item in source) {
                                int element = selector (item);
                                if (element < minimum)
                                        minimum = element;
                                counter++;
                        }
                        
                        if (counter == 0)
                                throw new EmptySequenceException ();
                        else
                                return minimum;
                }
                
                [System.Runtime.CompilerServices.Extension]
                public static int? Min<T> (
                        IEnumerable<T> source,
                        Func<T, int?> selector)
                {
                        if (source == null || selector == null)
                                throw new ArgumentNullException ();
                        
                        bool onlyNull = true;
                        int? minimum = int.MaxValue;
                        foreach (T item in source) {
                                int? element = selector (item);
                                if (element.HasValue) {
                                        onlyNull = false;
                                        if (element < minimum)
                                                minimum = element;
                                }
                        }
                        return (onlyNull ? null : minimum);
                }
                
                [System.Runtime.CompilerServices.Extension]
                public static long Min<T> (
                        IEnumerable<T> source,
                        Func<T, long> selector)
                {
                        if (source == null || selector == null)
                                throw new ArgumentNullException ();
                        
                        long minimum = long.MaxValue;
                        int counter = 0;
                        foreach (T item in source) {
                                long element = selector (item);
                                if (element < minimum)
                                        minimum = element;
                                counter++;
                        }
                        
                        if (counter == 0)
                                throw new EmptySequenceException ();
                        else
                                return minimum;
                }
                
                [System.Runtime.CompilerServices.Extension]
                public static long? Min<T> (
                        IEnumerable<T> source,
                        Func<T, long?> selector)
                {
                        if (source == null || selector == null)
                                throw new ArgumentNullException ();
                        
                        bool onlyNull = true;
                        long? minimum = long.MaxValue;
                        foreach (T item in source) {
                                long? element = selector (item);
                                if (element.HasValue) {
                                        onlyNull = false;
                                        if (element < minimum)
                                                minimum = element;
                                }
                        }
                        return (onlyNull ? null : minimum);
                }
                
                [System.Runtime.CompilerServices.Extension]
                public static double Min<T> (
                        IEnumerable<T> source,
                        Func<T, double> selector)
                {
                        if (source == null || selector == null)
                                throw new ArgumentNullException ();
                        
                        double minimum = double.MaxValue;
                        int counter = 0;
                        foreach (T item in source)
                        {
                                double element = selector (item);
                                if (element < minimum)
                                        minimum = element;
                                counter++;
                        }
                        
                        if (counter == 0)
                                throw new EmptySequenceException ();
                        else
                                return minimum;
                }
                
                [System.Runtime.CompilerServices.Extension]
                public static double? Min<T> (
                        IEnumerable<T> source,
                        Func<T, double?> selector)
                {
                        if (source == null || selector == null)
                                throw new ArgumentNullException ();
                        
                        bool onlyNull = true;
                        double? minimum = double.MaxValue;
                        foreach (T item in source) {
                                double? element = selector (item);
                                if (element.HasValue) {
                                        onlyNull = false;
                                        if (element < minimum)
                                                minimum = element;
                                }
                        }
                        return (onlyNull ? null : minimum);
                }
                
                [System.Runtime.CompilerServices.Extension]
                public static decimal Min<T> (
                        IEnumerable<T> source,
                        Func<T, decimal> selector)
                {
                        if (source == null || selector == null)
                                throw new ArgumentNullException ();
                        
                        decimal minimum = decimal.MaxValue;
                        int counter = 0;
                        foreach (T item in source) {
                                decimal element = selector (item);
                                if (element < minimum)
                                        minimum = element;
                                counter++;
                        }
                        
                        if (counter == 0)
                                throw new EmptySequenceException ();
                        else
                                return minimum;
                }
                
                [System.Runtime.CompilerServices.Extension]
                public static decimal? Min<T> (
                        IEnumerable<T> source,
                        Func<T, decimal?> selector)
                {
                        if (source == null || selector == null)
                                throw new ArgumentNullException ();
                        
                        bool onlyNull = true;
                        decimal? minimum = decimal.MaxValue;
                        foreach (T item in source) {
                                decimal? element = selector (item);
                                if (element.HasValue) {
                                        onlyNull = false;
                                        if (element < minimum)
                                                minimum = element;
                                }
                        }
                        return (onlyNull ? null : minimum);
                }
                
                [System.Runtime.CompilerServices.Extension]
                public static S Min<T, S> (
                        IEnumerable<T> source,
                        Func<T, S> selector)
                {
                        if (source == null || selector == null)
                                throw new ArgumentNullException ();
                        
                        bool notAssigned = true;
                        S minimum = default (S);
                        int counter = 0;
                        foreach (T item in source) {
                                S element = selector (item);
                                if (notAssigned) {
                                        minimum = element;
                                        notAssigned = false;
                                }
                                else {
                                        int comparison;
                                        if (element is IComparable<S>)
                                                comparison = ((IComparable<S>)element).CompareTo (minimum);
                                        else if (element is System.IComparable)
                                                comparison = ((System.IComparable)element).CompareTo (minimum);
                                        else
                                                throw new ArgumentNullException ();
                                        
                                        if (comparison < 0)
                                                minimum = element;
                                }
                                counter++;
                        }
                        
                        if (counter == 0)
                                throw new EmptySequenceException ();
                        else
                                return minimum;
                }
                
                #endregion
                
                #region Max
                
                [System.Runtime.CompilerServices.Extension]
                public static int Max (
                        IEnumerable<int> source)
                {
                        if (source == null)
                                throw new ArgumentNullException ();
                        
                        int maximum = int.MinValue;
                        int counter = 0;
                        foreach (int element in source) {
                                if (element > maximum)
                                        maximum = element;
                                counter++;
                        }
                        
                        if (counter == 0)
                                throw new EmptySequenceException ();
                        else
                                return maximum;
                }
                
                [System.Runtime.CompilerServices.Extension]
                public static int? Max (
                        IEnumerable<int?> source)
                {
                        if (source == null)
                                throw new ArgumentNullException ();
                        
                        bool onlyNull = true;
                        int? maximum = int.MinValue;
                        foreach (int? element in source) {
                                if (element.HasValue) {
                                        onlyNull = false;
                                        if (element > maximum)
                                                maximum = element;
                                }
                        }
                        return (onlyNull ? null : maximum);
                }
                
                [System.Runtime.CompilerServices.Extension]
                public static long Max (
                        IEnumerable<long> source)
                {
                        if (source == null)
                                throw new ArgumentNullException ();
                        
                        long maximum = long.MinValue;
                        int counter = 0;
                        foreach (long element in source) {
                                if (element > maximum)
                                        maximum = element;
                                counter++;
                        }
                        
                        if (counter == 0)
                                throw new EmptySequenceException ();
                        else
                                return maximum;
                }
                
                [System.Runtime.CompilerServices.Extension]
                public static long? Max (
                        IEnumerable<long?> source)
                {
                        if (source == null)
                                throw new ArgumentNullException ();
                        
                        bool onlyNull = true;
                        long? maximum = long.MinValue;
                        foreach (long? element in source) {
                                if (element.HasValue) {
                                        onlyNull = false;
                                        if (element > maximum)
                                                maximum = element;
                                }
                        }
                        return (onlyNull ? null : maximum);
                }
                
                [System.Runtime.CompilerServices.Extension]
                public static double Max (
                        IEnumerable<double> source)
                {
                        if (source == null)
                                throw new ArgumentNullException ();
                        
                        double maximum = double.MinValue;
                        int counter = 0;
                        foreach (double element in source) {
                                if (element > maximum)
                                        maximum = element;
                                counter++;
                        }
                        
                        if (counter == 0)
                                throw new EmptySequenceException ();
                        else
                                return maximum;
                }
                
                [System.Runtime.CompilerServices.Extension]
                public static double? Max (
                        IEnumerable<double?> source)
                {
                        if (source == null)
                                throw new ArgumentNullException ();
                        
                        bool onlyNull = true;
                        double? maximum = double.MinValue;
                        foreach (double? element in source) {
                                if (element.HasValue) {
                                        onlyNull = false;
                                        if (element > maximum)
                                                maximum = element;
                                }
                        }
                        return (onlyNull ? null : maximum);
                }
                
                [System.Runtime.CompilerServices.Extension]
                public static decimal Max (
                        IEnumerable<decimal> source)
                {
                        if (source == null)
                                throw new ArgumentNullException ();
                        
                        decimal maximum = decimal.MinValue;
                        int counter = 0;
                        foreach (decimal element in source) {
                                if (element > maximum)
                                        maximum = element;
                                counter++;
                        }
                        
                        if (counter == 0)
                                throw new EmptySequenceException ();
                        else
                                return maximum;
                }
                
                [System.Runtime.CompilerServices.Extension]
                public static decimal? Max (
                        IEnumerable<decimal?> source)
                {
                        if (source == null)
                                throw new ArgumentNullException ();
                        
                        bool onlyNull = true;
                        decimal? maximum = decimal.MinValue;
                        foreach (decimal? element in source) {
                                if (element.HasValue) {
                                        onlyNull = false;
                                        if (element > maximum)
                                                maximum = element;
                                }
                        }
                        return (onlyNull ? null : maximum);
                }
                
                [System.Runtime.CompilerServices.Extension]
                public static T Max<T> (
                        IEnumerable<T> source)
                {
                        if (source == null)
                                throw new ArgumentNullException ();
                        
                        bool notAssigned = true;
                        T maximum = default (T);
                        int counter = 0;
                        foreach (T element in source) {
                                if (notAssigned) {
                                        maximum = element;
                                        notAssigned = false;
                                }
                                else {
                                        int comparison;
                                        if (element is IComparable<T>)
                                                comparison = ((IComparable<T>)element).CompareTo (maximum);
                                        else if (element is System.IComparable)
                                                comparison = ((System.IComparable)element).CompareTo (maximum);
                                        else
                                                throw new ArgumentNullException();
                                        
                                        if (comparison > 0)
                                                maximum = element;
                                }
                                counter++;
                        }
                        
                        if (counter == 0)
                                throw new EmptySequenceException ();
                        else
                                return maximum;
                }
                
                [System.Runtime.CompilerServices.Extension]
                public static int Max<T> (
                        IEnumerable<T> source,
                        Func<T, int> selector)
                {
                        if (source == null || selector == null)
                                throw new ArgumentNullException ();
                        
                        int maximum = int.MinValue;
                        int counter = 0;
                        foreach (T item in source)
                        {
                                int element = selector (item);
                                if (element > maximum)
                                        maximum = element;
                                counter++;
                        }
                        
                        if (counter == 0)
                                throw new EmptySequenceException ();
                        else
                                return maximum;
                }
                
                [System.Runtime.CompilerServices.Extension]
                public static int? Max<T> (
                        IEnumerable<T> source,
                        Func<T, int?> selector)
                {
                        if (source == null || selector == null)
                                throw new ArgumentNullException ();
                        
                        bool onlyNull = true;
                        int? maximum = int.MinValue;
                        foreach (T item in source) {
                                int? element = selector (item);
                                if (element.HasValue) {
                                        onlyNull = false;
                                        if (element > maximum)
                                                maximum = element;
                                }
                        }
                        return (onlyNull ? null : maximum);
                }
                
                [System.Runtime.CompilerServices.Extension]
                public static long Max<T> (
                        IEnumerable<T> source,
                        Func<T, long> selector)
                {
                        if (source == null || selector == null)
                                throw new ArgumentNullException ();
                        
                        long maximum = long.MinValue;
                        int counter = 0;
                        foreach (T item in source) {
                                long element = selector (item);
                                if (element > maximum)
                                        maximum = element;
                                counter++;
                        }
                        
                        if (counter == 0)
                                throw new EmptySequenceException ();
                        else
                                return maximum;
                }
                
                [System.Runtime.CompilerServices.Extension]
                public static long? Max<T> (
                        IEnumerable<T> source,
                        Func<T, long?> selector)
                {
                        if (source == null || selector == null)
                                throw new ArgumentNullException ();
                        
                        bool onlyNull = true;
                        long? maximum = long.MinValue;
                        foreach (T item in source) {
                                long? element = selector (item);
                                if (element.HasValue) {
                                        onlyNull = false;
                                        if (element > maximum)
                                                maximum = element;
                                }
                        }
                        return (onlyNull ? null : maximum);
                }
                
                [System.Runtime.CompilerServices.Extension]
                public static double Max<T> (
                        IEnumerable<T> source,
                        Func<T, double> selector)
                {
                        if (source == null || selector == null)
                                throw new ArgumentNullException ();
                        
                        double maximum = double.MinValue;
                        int counter = 0;
                        foreach (T item in source) {
                                double element = selector (item);
                                if (element > maximum)
                                        maximum = element;
                                counter++;
                        }
                        
                        if (counter == 0)
                                throw new EmptySequenceException ();
                        else
                                return maximum;
                }
                
                [System.Runtime.CompilerServices.Extension]
                public static double? Max<T> (
                        IEnumerable<T> source,
                        Func<T, double?> selector)
                {
                        if (source == null || selector == null)
                                throw new ArgumentNullException ();
                        
                        bool onlyNull = true;
                        double? maximum = double.MinValue;
                        foreach (T item in source) {
                                double? element = selector(item);
                                if (element.HasValue) {
                                        onlyNull = false;
                                        if (element > maximum)
                                                maximum = element;
                                }
                        }
                        return (onlyNull ? null : maximum);
                }
                
                [System.Runtime.CompilerServices.Extension]
                public static decimal Max<T> (
                        IEnumerable<T> source,
                        Func<T, decimal> selector)
                {
                        if (source == null || selector == null)
                                throw new ArgumentNullException ();
                        
                        decimal maximum = decimal.MinValue;
                        int counter = 0;
                        foreach (T item in source) {
                                decimal element = selector(item);
                                if (element > maximum)
                                        maximum = element;
                                counter++;
                        }
                        
                        if (counter == 0)
                                throw new EmptySequenceException ();
                        else
                                return maximum;
                }
                
                [System.Runtime.CompilerServices.Extension]
                public static decimal? Max<T> (
                        IEnumerable<T> source,
                        Func<T, decimal?> selector)
                {
                        if (source == null || selector == null)
                                throw new ArgumentNullException ();
                        
                        bool onlyNull = true;
                        decimal? maximum = decimal.MinValue;
                        foreach (T item in source) {
                                decimal? element = selector(item);
                                if (element.HasValue) {
                                        onlyNull = false;
                                        if (element > maximum)
                                                maximum = element;
                                }
                        }
                        return (onlyNull ? null : maximum);
                }
                
                [System.Runtime.CompilerServices.Extension]
                public static S Max<T, S> (
                        IEnumerable<T> source,
                        Func<T, S> selector)
                {
                        if (source == null || selector == null)
                                throw new ArgumentNullException ();
                        
                        bool notAssigned = true;
                        S maximum = default (S);
                        int counter = 0;
                        foreach (T item in source)
                        {
                                S element = selector (item);
                                if (notAssigned)  {
                                        maximum = element;
                                        notAssigned = false;
                                }
                                else  {
                                        int comparison;
                                        if (element is IComparable<S>)
                                                comparison = ((IComparable<S>)element).CompareTo (maximum);
                                        else if (element is System.IComparable)
                                                comparison = ((System.IComparable)element).CompareTo (maximum);
                                        else
                                                throw new ArgumentNullException();
                                        
                                        if (comparison > 0)
                                                maximum = element;
                                }
                                       counter++;
                        }
                        
                        if (counter == 0)
                                throw new EmptySequenceException ();
                        else
                                return maximum;
                }
                                
                #endregion
        
                #region Average
                
                [System.Runtime.CompilerServices.Extension]
                public static double Average (
                        IEnumerable<int> source)
                {
                        if (source == null)
                                throw new ArgumentNullException ();
                        
                        long sum = 0;
                        long counter = 0;
                        foreach (int element in source) {
                                sum += element;                        
                                counter++;
                        }
                        
                        if (counter == 0)
                                throw new EmptySequenceException ();
                        else
                                return (double)sum / (double)counter;
                }
                
                [System.Runtime.CompilerServices.Extension]
                public static double? Average (
                        IEnumerable<int?> source)
                {
                        if (source == null)
                                throw new ArgumentNullException ();
                        
                        bool onlyNull = true;
                        long sum = 0;
                        long counter = 0;
                        foreach (int? element in source) {
                                if (element.HasValue) {
                                        onlyNull = false;
                                        sum += element.Value;
                                        counter++;
                                }
                        }
                        return (onlyNull ? null : (double?)sum / (double?)counter);
                }
                
                [System.Runtime.CompilerServices.Extension]
                public static double Average (
                        IEnumerable<long> source)
                {
                        if (source == null)
                                throw new ArgumentNullException ();
                        
                        long sum = 0;
                        long counter = 0;
                        foreach (long element in source) {
                                sum += element;                        
                                counter++;
                        }
                        
                        if (counter == 0)
                                throw new EmptySequenceException ();
                        else
                                return (double)sum / (double)counter;
                }
                
                [System.Runtime.CompilerServices.Extension]
                public static double? Average (
                        IEnumerable<long?> source)
                {
                        if (source == null)
                                throw new ArgumentNullException ();
                        
                        bool onlyNull = true;
                        long sum = 0;
                        long counter = 0;
                        foreach (long? element in source) {
                                if (element.HasValue) {
                                        onlyNull = false;
                                        sum += element.Value;
                                        counter++;
                                }
                        }
                        return (onlyNull ? null : (double?)sum / (double?)counter);
                }
                
                [System.Runtime.CompilerServices.Extension]
                public static double Average (
                        IEnumerable<double> source)
                {
                        if (source == null)
                                throw new ArgumentNullException ();
                        
                        double sum = 0;
                        double counter = 0;
                        foreach (double element in source) {
                                sum += element;                        
                                counter++;
                        }
                        
                        if (counter == 0)
                                throw new EmptySequenceException ();
                        else
                                return sum / counter;
                }
                
                [System.Runtime.CompilerServices.Extension]
                public static double? Average (
                        IEnumerable<double?> source)
                {
                        if (source == null)
                                throw new ArgumentNullException ();
                        
                        bool onlyNull = true;
                        double sum = 0;
                        double counter = 0;
                        foreach (double? element in source) {
                                if (element.HasValue) {
                                        onlyNull = false;
                                        sum += element.Value;
                                        counter++;
                                }
                        }
                        return (onlyNull ? null : (double?)(sum / counter));
                }
                
                [System.Runtime.CompilerServices.Extension]
                public static decimal Average (
                        IEnumerable<decimal> source)
                {
                        if (source == null)
                                throw new ArgumentNullException ();
                        
                        decimal sum = 0;
                        decimal counter = 0;
                        foreach (decimal element in source) {
                                sum += element;                        
                                counter++;
                        }
                        
                        if (counter == 0)
                                throw new EmptySequenceException ();
                        else
                                return sum / counter;
                }
                
                [System.Runtime.CompilerServices.Extension]
                public static decimal? Average (
                        IEnumerable<decimal?> source)
                {
                        if (source == null)
                                throw new ArgumentNullException ();
                        
                        bool onlyNull = true;
                        decimal sum = 0;
                        decimal counter = 0;
                        foreach (decimal? element in source) {
                                if (element.HasValue) {
                                        onlyNull = false;
                                        sum += element.Value;
                                        counter++;
                                }
                        }
                        return (onlyNull ? null : (decimal?)(sum / counter));
                }
                
                [System.Runtime.CompilerServices.Extension]
                public static double Average<T> (
                        IEnumerable<T> source,
                        Func<T, int> selector)
                {
                        if (source == null || selector == null)
                                throw new ArgumentNullException ();
                        
                        long sum = 0;
                        long counter = 0;
                        foreach (T item in source) {
                                sum += selector (item);
                                counter++;
                        }
                        
                        if (counter == 0)
                                throw new EmptySequenceException ();
                        else
                                return (double)sum / (double)counter;
                }
                
                [System.Runtime.CompilerServices.Extension]
                public static double? Average<T> (
                        IEnumerable<T> source,
                        Func<T, int?> selector)
                {
                        if (source == null || selector == null)
                                throw new ArgumentNullException ();
                        
                        bool onlyNull = true;
                        long sum = 0;
                        long counter = 0;
                        foreach (T item in source) {
                                int? element = selector (item);
                                if (element.HasValue) {
                                        onlyNull = false;
                                        sum += element.Value;
                                        counter++;
                                }
                        }
                        return (onlyNull ? null : (double?)sum / (double?)counter);
                }
                
                [System.Runtime.CompilerServices.Extension]
                public static double Average<T> (
                        IEnumerable<T> source,
                        Func<T, long> selector)
                {
                        if (source == null || selector == null)
                                throw new ArgumentNullException ();
                        
                        long sum = 0;
                        long counter = 0;
                        foreach (T item in source) {
                                sum += selector (item);
                                counter++;
                        }
                        
                        if (counter == 0)
                                throw new EmptySequenceException();
                        else
                                return (double)sum / (double)counter;
                }
                
                [System.Runtime.CompilerServices.Extension]
                public static double? Average<T> (
                        IEnumerable<T> source,
                        Func<T, long?> selector)
                {
                        if (source == null || selector == null)
                                throw new ArgumentNullException ();
                        
                        bool onlyNull = true;
                        long sum = 0;
                        long counter = 0;
                        foreach (T item in source) {
                                long? element = selector (item);
                                if (element.HasValue) {
                                        onlyNull = false;
                                        sum += element.Value;
                                        counter++;
                                }
                        }
                        return (onlyNull ? null : (double?)sum/(double?)counter);
                }
                
                [System.Runtime.CompilerServices.Extension]
                public static double Average<T> (
                        IEnumerable<T> source,
                        Func<T, double> selector)
                {
                        if (source == null || selector == null)
                                throw new ArgumentNullException ();
                        
                        double sum = 0;
                        double counter = 0;
                        foreach (T item in source) {
                                sum += selector (item);
                                counter++;
                        }
                        
                        if (counter == 0)
                                throw new EmptySequenceException ();
                        else
                                return sum / counter;
                }
                
                [System.Runtime.CompilerServices.Extension]
                public static double? Average<T> (
                        IEnumerable<T> source,
                        Func<T, double?> selector)
                {
                        if (source == null || selector == null)
                                throw new ArgumentNullException ();
                        
                        bool onlyNull = true;
                        double sum = 0;
                        double counter = 0;
                        foreach (T item in source) {
                                double? element = selector (item);
                                if (element.HasValue) {
                                        onlyNull = false;
                                        sum += element.Value;
                                        counter++;
                                }
                        }
                        return (onlyNull ? null : (double?)(sum/counter));
                }
                
                [System.Runtime.CompilerServices.Extension]
                public static decimal Average<T> (
                        IEnumerable<T> source,
                        Func<T, decimal> selector)
                {
                        if (source == null || selector == null)
                                throw new ArgumentNullException ();
                        
                        decimal sum = 0;
                        decimal counter = 0;
                        foreach (T item in source) {
                                sum += selector(item);
                                counter++;
                        }
                        
                        if (counter == 0)
                                throw new EmptySequenceException ();
                        else
                                return sum / counter;
                }
                
                [System.Runtime.CompilerServices.Extension]
                public static decimal? Average<T> (
                        IEnumerable<T> source,
                        Func<T, decimal?> selector)
                {
                        if (source == null || selector == null)
                                throw new ArgumentNullException ();
                        
                        bool onlyNull = true;
                        decimal sum = 0;
                        decimal counter = 0;
                        foreach (T item in source) {
                                decimal? element = selector (item);
                                if (element.HasValue) {
                                        onlyNull = false;
                                        sum += element.Value;
                                        counter++;
                                }
                        }
                        return (onlyNull ? null : (decimal?)(sum/counter));
                }
                
                #endregion
                
                #region Fold
                
                [System.Runtime.CompilerServices.Extension]
                public static T Fold<T> (
                        IEnumerable<T> source,
                        Func<T, T, T> func)
                {
                        if (source == null || func == null)
                                throw new ArgumentNullException ();
                        
                        int counter = 0;
                        T folded = default (T);
                        
                        foreach (T element in source) {
                                if (counter == 0)
                                        folded = element;
                                else
                                        folded = func (folded, element);
                        }
                        
                        if (counter == 0)
                                throw new EmptySequenceException ();
                        else
                                return folded;
                }
                
                [System.Runtime.CompilerServices.Extension]
                public static U Fold<T, U> (
                        IEnumerable<T> source,
                        U seed,
                        Func<U, T, U> func)
                {
                        if (source == null || func == null)
                                throw new ArgumentNullException ();
                        
                        U folded = seed;
                        foreach (T element in source)
                                folded = func (folded, element);
                        return folded;
                }
                
                #endregion
        }
}
