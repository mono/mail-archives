using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("System.Query")]
[assembly: AssemblyDescription("System.Query.dll")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Mono Development Team")]
[assembly: AssemblyProduct("System.Query")]
[assembly: AssemblyCopyright("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: AssemblyVersion("1.0.*")]

