namespace tester
{
	using Mono.Cecil;
	using System;
	using System.Collections;

	public class ReadTest2
	{
		public static void Main(string[] args)
		{
			string test = (args.Length > 0 ? args [0] : "test2.dll");
			AssemblyDefinition asm = AssemblyFactory.GetAssembly(test);
			foreach (TypeDefinition t in asm.MainModule.Types)
				ReportCustomAttributes(t);
		}

		static void ReportCustomAttributes(TypeDefinition t)
		{
			Console.WriteLine("Type {0} has {1} custom attributes.", t.FullName, t.CustomAttributes.Count);
			foreach(CustomAttribute ca in t.CustomAttributes) {
				ReportCustomAttribute(ca);
				if (!ca.IsReadable) {
					Console.WriteLine("Forcing reread of attribute");
					ca.ForceRead();
					ReportCustomAttribute(ca);
				}
			}
		}

		static void ReportCustomAttribute(CustomAttribute ca)
		{
			if (!ca.IsReadable) {
				Console.WriteLine("\tAttribute of type {0} is unreadable.", ca.Constructor.DeclaringType.FullName);
				return;
			}
				
			Console.WriteLine("\tAttribute type is {0}", ca.Constructor.DeclaringType.FullName);
			for (int i = 0; i < ca.Constructor.Parameters.Count; i++) {
				Console.Write("\t\tParameter {0} is ", i);
				WriteValue(ca.Constructor.Parameters[i].ParameterType, ca.ConstructorParameters[i]);
				Console.WriteLine();
			}
			foreach (DictionaryEntry field in ca.Fields) {
				Console.Write("\t\tField {0} is ", field.Key);
				WriteValue(ca.GetFieldType((string)field.Key), field.Value);
				Console.WriteLine();
			}
			foreach (DictionaryEntry prop in ca.Properties) {
				Console.Write("\t\tProperty {0} is ", prop.Key);
				WriteValue(ca.GetPropertyType((string)prop.Key), prop.Value);
				Console.WriteLine();
			}
		}

		static void WriteValue(TypeReference t, object val)
		{
			Console.Write("type {0} value is {1}.", t.FullName, val);
		}
	}
}
