namespace test2
{
	using test1;
	using System;

	[EnumUser(Enum1.B, Enum2.C)]
	public class MyClass1 {}

	[EnumUser(f1 = Enum1.C, f2 = Enum2.D)]
	public class MyClass2 {}

	[EnumUser(p1 = Enum1.C, p2 = Enum2.D)]
	public class MyClass3 {}

	[EnumUser("test")]
	public class MyClass4 {}

	[EnumUser(EnumUserAttribute.Enum3.B)]
	public class MyClass5 {}

	[EnumUser(o = EnumUserAttribute.Enum3.B)]
	public class MyClass6 {}

	[EnumUser(po = EnumUserAttribute.Enum3.B)]
	public class MyClass7 {}

	[AttributeUsage(AttributeTargets.Class)]
	public class MyClass8 : Attribute {}
}
