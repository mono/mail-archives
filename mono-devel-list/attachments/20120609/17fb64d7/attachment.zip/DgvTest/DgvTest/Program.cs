﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;

namespace DgvTest
{
	internal sealed class Assert
	{
		public static void AreEqual<T> (T a_correct, T a_found,
			string a_strMessage)
		{
			if (!a_correct.Equals (a_found))
				MessageBox.Show (a_strMessage
					+ ": expected " + a_correct.ToString()
					+ ", found " + a_found.ToString());
		}
	}
	internal sealed class Program
	{
		private class MyForm : Form
		{
			public static DataGridView CreateAndFillBig ()
			{
				DataGridView dgv = new DataGridView ();
				for (int c = 0; c < 10; c++) {
					string A = (((char) ((int) 'A') + c)).ToString ();
					dgv.Columns.Add (A, A);
				}
				for (int r = 0; r < 10; r++) {
					List<object> cells = new List<object> ();
					for (int c = 0; c < 10; c++) {
						cells.Add (string.Format ("Cell {0}{1}", dgv.Columns [c].Name, r));
					}
					dgv.Rows.Add (cells);
				}
				return dgv;
			}

			// For testing row/column selection.
			protected List<List<int>> selections;
			protected void DataGridView_RowSelectionChanged (object sender, EventArgs e)
			{
				// Make a list of selected rows.
				DataGridView dgv = sender as DataGridView;
				List<int> selection = new List<int> ();
				foreach (DataGridViewRow row in dgv.SelectedRows)
					selection.Add (row.Index);
				selections.Add (selection);
			}
			protected void DataGridView_ColumnSelectionChanged (object sender, EventArgs e)
			{
				// Make a list of selected columns.
				DataGridView dgv = sender as DataGridView;
				List<int> selection = new List<int> ();
				foreach (DataGridViewColumn column in dgv.SelectedColumns)
					selection.Add (column.Index);
				selections.Add (selection);
			}

			// Used to generate printable representation of selections.
			protected string ListListIntToString (List<List<int>> selections)
			{
				List<string> selectionsList = new List<string> ();
				foreach (List<int> selection in selections)
				{
					List<string> selectionList = new List<string> ();
					foreach (int selectionNo in selection)
						selectionList.Add (selectionNo.ToString ("D"));
					selectionsList.Add ("<" + string.Join (",", selectionList.ToArray()) + ">");
				}
				return string.Join (",", selectionsList.ToArray());

				// (Here is the disallowed Linq version.)
				/* return string.Join (",", (selections.Select ((List<int> x)
					=> "<" + string.Join (",", (x.Select ((int y)
						=> (y.ToString("D")))).ToArray()) + ">").ToArray())); */
			}

			internal MyForm()
			: base()
			{
				this.Closed += new EventHandler (this_Closed);
			}
			internal void this_Closed (object sender, EventArgs e)
			{
				Application.Exit();
			}
		};

		private class MyRowTestForm : MyForm
		{
			internal MyRowTestForm()
			: base()
			{
				this.Load += new EventHandler (this_Load);
			}
			internal void this_Load (object sender, EventArgs e)
			{
				this.Size = new Size(810, 210);
				DataGridView dgv = /* DataGridViewCommon. */ CreateAndFillBig ();
				dgv.Parent = this;
				dgv.Size = new Size(800, 200);
				dgv.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

				// Prepare to test the SelectionChanged event.
				selections = new List<List<int>> ();
				List<List<int>> expectedSelections = new List<List<int>> ();
				dgv.SelectionChanged += new EventHandler (DataGridView_RowSelectionChanged);

				// Make sure there's no selection to begin with.
				Assert.AreEqual (0, dgv.SelectedRows.Count, "1-10");

				// Select a row.
				dgv.Rows [1].Selected = true;
				Assert.AreEqual (1, dgv.SelectedRows.Count, "1-1");
				Assert.AreEqual (1, dgv.SelectedRows [0].Index, "1-2");
				expectedSelections.Add (new List<int> { 1 });

				// Select another row.
				dgv.Rows [3].Selected = true;
				Assert.AreEqual (2, dgv.SelectedRows.Count, "1-3");
				Assert.AreEqual (3, dgv.SelectedRows [0].Index, "1-4");
				Assert.AreEqual (1, dgv.SelectedRows [1].Index, "1-5");
				expectedSelections.Add (new List<int> { 3, 1 });

				// Select another row.
				dgv.Rows [2].Selected = true;
				Assert.AreEqual (3, dgv.SelectedRows.Count, "1-6");
				Assert.AreEqual (2, dgv.SelectedRows [0].Index, "1-7");
				Assert.AreEqual (3, dgv.SelectedRows [1].Index, "1-8");
				Assert.AreEqual (1, dgv.SelectedRows [2].Index, "1-9");
				expectedSelections.Add (new List<int> { 2, 3, 1 });

				// Unselect a row.
				dgv.Rows [2].Selected = false;
				Assert.AreEqual (2, dgv.SelectedRows.Count, "1-11");
				Assert.AreEqual (3, dgv.SelectedRows [0].Index, "1-12");
				Assert.AreEqual (1, dgv.SelectedRows [1].Index, "1-13");
				expectedSelections.Add (new List<int> { 3, 1 });

				// Delete a row.
				// Since the row wasn't selected, it doesn't fire a
				// SelectionChanged event.
				dgv.Rows.RemoveAt (2);
				Assert.AreEqual (2, dgv.SelectedRows.Count, "1-14");
				Assert.AreEqual (2, dgv.SelectedRows [0].Index, "1-16");
				Assert.AreEqual (1, dgv.SelectedRows [1].Index, "1-17");

				// Delete a selected row.
				dgv.Rows.RemoveAt (2);
				Assert.AreEqual (1, dgv.SelectedRows.Count, "1-18");
				Assert.AreEqual (1, dgv.SelectedRows [0].Index, "1-19");
				expectedSelections.Add (new List<int> { 1 });

				// Make sure the SelectionChanged event was called when expected.
				string selectionsText = ListListIntToString (selections);
				string expectedSelectionsText = ListListIntToString (expectedSelections);
				Assert.AreEqual (expectedSelectionsText, selectionsText, "1-15");
			}
		};

		private class MyColumnTestForm : MyForm
		{
			internal MyColumnTestForm()
			: base()
			{
				this.Load += new EventHandler (this_Load);
			}
			internal void this_Load (object sender, EventArgs e)
			{
				this.Size = new Size(810, 210);
				DataGridView dgv = /* DataGridViewCommon. */ CreateAndFillBig ();
				dgv.Parent = this;
				dgv.Size = new Size(800, 200);

				foreach (DataGridViewColumn col in dgv.Columns)
					col.SortMode = DataGridViewColumnSortMode.NotSortable;
				dgv.SelectionMode = DataGridViewSelectionMode.FullColumnSelect;

				// Prepare to test the SelectionChanged event.
				selections = new List<List<int>> ();
				List<List<int>> expectedSelections = new List<List<int>> ();
				dgv.SelectionChanged += new EventHandler (DataGridView_ColumnSelectionChanged);

				// Make sure there's no selection to begin with.
				Assert.AreEqual (0, dgv.SelectedColumns.Count, "1-13");

				// Select a column.
				dgv.Columns [1].Selected = true;
				Assert.AreEqual (1, dgv.SelectedColumns.Count, "1-1");
				Assert.AreEqual (1, dgv.SelectedColumns [0].Index, "1-2");
				expectedSelections.Add (new List<int> { 1 });

				// Select another column.
				dgv.Columns [3].Selected = true;
				Assert.AreEqual (2, dgv.SelectedColumns.Count, "1-3");
				Assert.AreEqual (3, dgv.SelectedColumns [0].Index, "1-4");
				Assert.AreEqual (1, dgv.SelectedColumns [1].Index, "1-5");
				expectedSelections.Add (new List<int> { 3, 1 });

				// Select another column.
				dgv.Columns [2].Selected = true;
				Assert.AreEqual (3, dgv.SelectedColumns.Count, "1-6");
				Assert.AreEqual (2, dgv.SelectedColumns [0].Index, "1-7");
				Assert.AreEqual (3, dgv.SelectedColumns [1].Index, "1-8");
				Assert.AreEqual (1, dgv.SelectedColumns [2].Index, "1-9");
				expectedSelections.Add (new List<int> { 2, 3, 1 });

				// Unselect a column.
				dgv.Columns [2].Selected = false;
				Assert.AreEqual (2, dgv.SelectedColumns.Count, "1-10");
				Assert.AreEqual (3, dgv.SelectedColumns [0].Index, "1-11");
				Assert.AreEqual (1, dgv.SelectedColumns [1].Index, "1-12");
				expectedSelections.Add (new List<int> { 3, 1 });

				// Delete a column.
				// Since the column wasn't selected, it doesn't fire a
				// SelectionChanged event.
				dgv.Columns.RemoveAt (2);
				Assert.AreEqual (2, dgv.SelectedColumns.Count, "1-14");
				Assert.AreEqual (2, dgv.SelectedColumns [0].Index, "1-16");
				Assert.AreEqual (1, dgv.SelectedColumns [1].Index, "1-17");

				// Delete a selected column.
				dgv.Columns.RemoveAt (2);
				Assert.AreEqual (1, dgv.SelectedColumns.Count, "1-18");
				Assert.AreEqual (1, dgv.SelectedColumns [0].Index, "1-19");
				expectedSelections.Add (new List<int> { 1 });

				// Make sure the SelectionChanged event was called when expected.
				string selectionsText = ListListIntToString (selections);
				string expectedSelectionsText = ListListIntToString (expectedSelections);
				Assert.AreEqual (expectedSelectionsText, selectionsText, "1-15");
			}
		};

		[STAThread]
		private static void Main(string[] args)
		{
			// Create a form with a data-grid-view.
			Form form1 = new MyRowTestForm ();
			form1.Show ();

			// Create another form with a data-grid-view.
			Form form2 = new MyColumnTestForm ();
			form2.Show ();

			// Display the results.
			Application.Run();
		}
	}
}
