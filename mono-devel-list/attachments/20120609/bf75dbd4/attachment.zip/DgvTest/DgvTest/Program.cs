﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;

namespace DgvTest
{
	internal sealed class Assert
	{
		public static void AreEqual<T> (T a_correct, T a_found,
			string a_strMessage)
		{
			if (!a_correct.Equals (a_found))
				MessageBox.Show (a_strMessage
					+ ": expected " + a_correct.ToString()
					+ ", found " + a_found.ToString());
		}
	}
	internal sealed class Program
	{
		private class MyForm : Form
		{
			// For testing the editing-control-showing event.
			int editingControlShowingTest_FoundColumns;
			void DataGridView_EditingControlShowingTest (object sender,
				DataGridViewEditingControlShowingEventArgs e)
			{
				DataGridView dgv = sender as DataGridView;
				if (dgv.CurrentCellAddress.X == 0)
				{
					// This is the name combo-box column.
					// Remember that the event-handler was called for
					// this column.
					editingControlShowingTest_FoundColumns |= 1;

					// Get the combo-box and the column.
					ComboBox cb = e.Control as ComboBox;
					DataGridViewComboBoxColumn col
						= dgv.Columns[0] as DataGridViewComboBoxColumn;

					// Since ObjectCollection doesn't support ToArray(), make
					// a list of the items in the combo-box and in the column.
					List<string> itemList = new List<string> ();
					foreach (string item in cb.Items)
						itemList.Add (item);
					List<string> expectedItemList = new List<string> ();
					foreach (string item in col.Items)
						expectedItemList.Add (item);

					// Make sure the combo-box has the list of allowed
					// items from the column.
					string items = string.Join (",", itemList.ToArray());
					string expectedItems = string.Join (",", expectedItemList.ToArray());
					Assert.AreEqual (expectedItems, items, "1-1");

					// Make sure the combo-box has the right selected item.
					Assert.AreEqual ("Boswell", cb.Text, "1-2");
				}
				else if (dgv.CurrentCellAddress.X == 1)
				{
					// This is the first-name text-box column.
					// Remember that the event-handler was called for
					// this column.
					editingControlShowingTest_FoundColumns |= 2;

					// Get the text-box.
					TextBox tb = e.Control as TextBox;

					// Make sure the text-box has the right contents.
					Assert.AreEqual ("Miguel", tb.Text, "1-3");
				}
				else if (dgv.CurrentCellAddress.X == 2)
				{
					// This is the chosen check-box column.
					// Remember that the event-handler was called for
					// this column.
					editingControlShowingTest_FoundColumns |= 4;

					// Get the check-box.
					CheckBox tb = e.Control as CheckBox;

					// Make sure the check-box has the right contents.
					Assert.AreEqual (CheckState.Checked, tb.CheckState, "1-4");
				}
				else
					Assert.AreEqual (0, 1, "1-5");
			}

			internal MyForm()
			: base()
			{
				this.Closed += new EventHandler (this_Closed);
				this.Load += new EventHandler (this_Load);
			}
			internal void this_Load (object sender, EventArgs e)
			{
				this.Size = new Size(410, 160);

				DataGridView _dataGridView = new DataGridView ();
				_dataGridView.Size = new Size(400, 150);
				_dataGridView.Parent = this;
				DataGridViewComboBoxColumn _nameComboBoxColumn;
				DataGridViewTextBoxColumn _firstNameTextBoxColumn;
				DataGridViewCheckBoxColumn _chosenCheckBoxColumn;

				// Add the event-handler.
				_dataGridView.EditingControlShowing
					+= new DataGridViewEditingControlShowingEventHandler
						(DataGridView_EditingControlShowingTest);

				// No columns have been found in the event-handler yet.
				editingControlShowingTest_FoundColumns = 0;

				// _nameComboBoxColumn
				_nameComboBoxColumn = new DataGridViewComboBoxColumn ();
				_nameComboBoxColumn.HeaderText = "Name";
				_dataGridView.Columns.Add (_nameComboBoxColumn);

				// _firstNameTextBoxColumn
				_firstNameTextBoxColumn = new DataGridViewTextBoxColumn ();
				_firstNameTextBoxColumn.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
				_firstNameTextBoxColumn.HeaderText = "First Name";
				_dataGridView.Columns.Add (_firstNameTextBoxColumn);

				// _chosenCheckBoxColumn
				_chosenCheckBoxColumn = new DataGridViewCheckBoxColumn ();
				_chosenCheckBoxColumn.HeaderText = "Chosen";
				_dataGridView.Columns.Add (_chosenCheckBoxColumn);

				// .NET requires that all possible values for combo-boxes in a column
				// are added to the column.
				_nameComboBoxColumn.Items.Add ("de Icaza");
				_nameComboBoxColumn.Items.Add ("Toshok");
				_nameComboBoxColumn.Items.Add ("Harper");
				_nameComboBoxColumn.Items.Add ("Boswell");

				// Set up the contents of the data-grid.
				_dataGridView.Rows.Add ("de Icaza", "Miguel", true);
				_dataGridView.Rows.Add ("Toshok", "Chris", false);
				_dataGridView.Rows.Add ("Harper", "Jackson", false);
				_dataGridView.Rows.Add ("Boswell", "Steven", true);

				// Edit a combo-box cell.
				_dataGridView.CurrentCell = _dataGridView.Rows[3].Cells[0];
				Assert.AreEqual (true, _dataGridView.Rows[3].Cells[0].Selected, "1-6");
				Assert.AreEqual (true, _dataGridView.BeginEdit (false), "1-7");
				_dataGridView.CancelEdit();

				// Edit a text-box cell.
				_dataGridView.CurrentCell = _dataGridView.Rows[0].Cells[1];
				Assert.AreEqual (false, _dataGridView.Rows[3].Cells[0].Selected, "1-8");
				Assert.AreEqual (true, _dataGridView.Rows[0].Cells[1].Selected, "1-9");
				Assert.AreEqual (true, _dataGridView.BeginEdit (false), "1-10");
				_dataGridView.CancelEdit();

				// Edit a check-box cell.
				_dataGridView.CurrentCell = _dataGridView.Rows[3].Cells[2];
				Assert.AreEqual (false, _dataGridView.Rows[0].Cells[1].Selected, "1-11");
				Assert.AreEqual (true, _dataGridView.Rows[3].Cells[2].Selected, "1-12");
				Assert.AreEqual (true, _dataGridView.BeginEdit (false), "1-13");
				_dataGridView.CancelEdit();

				// Make sure the event-handler was called each time.
				// (DataGridViewCheckBoxCell isn't derived from Control, so the
				// EditingControlShowing event doesn't get called for it.)
				Assert.AreEqual (3, editingControlShowingTest_FoundColumns, "1-14");
			}
			internal void this_Closed (object sender, EventArgs e)
			{
				Application.Exit();
			}
		}

		[STAThread]
		private static void Main(string[] args)
		{
			// Create a form with a combo box.
			Form form = new MyForm ();
			form.ShowInTaskbar = false;
			form.Show ();

			// Display the results.
			Application.Run();
		}
	}
}
