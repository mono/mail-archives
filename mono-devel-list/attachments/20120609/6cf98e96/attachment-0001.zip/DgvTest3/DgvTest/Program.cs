﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;

namespace DgvTest
{
	internal sealed class Assert
	{
		public static void AreEqual<T> (T a_correct, T a_found,
			string a_strMessage)
		{
			if (!a_correct.Equals (a_found))
				MessageBox.Show (a_strMessage
					+ ": expected " + a_correct.ToString()
					+ ", found " + a_found.ToString());
		}
		public static void AreNotEqual<T> (T a_correct, T a_found,
			string a_strMessage)
		{
			string strCorrect, strFound;
			bool bEquals = false;

			if (a_correct == null)
			{
				strCorrect = "null";
				if (a_found == null)
					bEquals = true;
			}
			else
			{
				strCorrect = a_correct.ToString();
				bEquals = a_correct.Equals (a_found);
			}
			strFound = (a_found == null) ? "null" : a_found.ToString();
			if (bEquals)
				MessageBox.Show (a_strMessage
					+ ": expected not " + strCorrect
					+ ", found " + strFound);
		}
	}
	internal sealed class Program
	{
		private class MyForm : Form
		{
			// A custom data-grid-view combo-box cell type, created
			// solely so that mouse clicks can be faked on it.
			public class ClickableComboBoxCell : DataGridViewComboBoxCell
			{
				public ClickableComboBoxCell()
				: base()
				{
				}

				internal void OnMouseDownInternal (DataGridViewCellMouseEventArgs e)
				{
					OnMouseDown (e);
				}

				internal void OnMouseUpInternal (DataGridViewCellMouseEventArgs e)
				{
					OnMouseUp (e);
				}
			};

			internal MyForm()
			: base()
			{
				this.Closed += new EventHandler (this_Closed);
				this.Load += new EventHandler (this_Load);
			}
			internal void this_Load (object sender, EventArgs e)
			{
				DataGridView dgv = new DataGridView ();
				dgv.Parent = this;
				DataGridViewComboBoxColumn cbCol;

				// Create a combo-box column with a custom cell type.
				cbCol = new DataGridViewComboBoxColumn ();
				cbCol.CellTemplate = new ClickableComboBoxCell();
				cbCol.HeaderText = "Name";
				dgv.Columns.Add (cbCol);

				// .NET requires that all possible values for combo-boxes
				// in a column are added to the column.
				cbCol.Items.Add ("Item1");
				cbCol.Items.Add ("Item2");
				cbCol.Items.Add ("Item3");
				cbCol.Items.Add ("Item4");

				// Set up the contents of the data-grid.
				dgv.Rows.Add ("Item1");

				// Show the form, let it draw.
				this.Show();
				Application.DoEvents();

				// Locate the drop-down button.  (This code is taken from mono-winforms,
				// from the private method DataGridViewComboBoxCell.CalculateButtonArea(),
				// and was then hacked mercilessly.)
				Rectangle button_area = Rectangle.Empty;
				{
					int border = 3 /* ThemeEngine.Current.Border3DSize.Width */;
					const int button_width = 16;
					Rectangle text_area = dgv.GetCellDisplayRectangle (0, 0, false);
//					button_area.X = text_area.Right - button_width - border;
//					button_area.Y = text_area.Y + border;
					button_area.X = text_area.Width - button_width - border;
					button_area.Y = border;
					button_area.Width = button_width;
					button_area.Height = text_area.Height - 2 * border;
				}

				// Click on the drop-down button.
				int x = button_area.X + (button_area.Width / 2);
				int y = button_area.Y + (button_area.Height / 2);
				MouseEventArgs me = new MouseEventArgs (MouseButtons.Left, 1, x, y, 0);
				DataGridViewCellMouseEventArgs cme = new DataGridViewCellMouseEventArgs (0, 0, x, y, me);
				ClickableComboBoxCell cell = dgv.Rows[0].Cells[0] as ClickableComboBoxCell;
				Assert.AreNotEqual (null, cell, "1-1");
				cell.OnMouseDownInternal (cme);
				cell.OnMouseUpInternal (cme);

				// Make sure that created an editing control.
				ComboBox cb = dgv.EditingControl as ComboBox;
				Assert.AreNotEqual (null, cb, "1-2");

				// Make sure that dropped down the menu.
				Assert.AreEqual (true, cb.DroppedDown, "1-3");
			}
			internal void this_Closed (object sender, EventArgs e)
			{
				Application.Exit();
			}
		}

		[STAThread]
		private static void Main(string[] args)
		{
			// Create a form with a combo box.
			Form form = new MyForm ();
			form.ShowInTaskbar = false;
			form.Show ();

			// Display the results.
			Application.Run();
		}
	}
}
