﻿using System;
using System.Diagnostics;
using System.Windows.Forms;

namespace ComboBoxTest
{
	internal sealed class Assert
	{
		public static void AreEqual<T> (T a_correct, T a_found,
			string a_strMessage)
		{
			if (!a_correct.Equals (a_found))
				MessageBox.Show (a_strMessage
					+ ": expected " + a_correct.ToString()
					+ ", found " + a_found.ToString());
		}
	}
    internal sealed class Program
    {
		private class MyForm : Form
		{
			internal MyForm()
			: base()
			{
				this.Closed += new EventHandler (this_Closed);
				this.Load += new EventHandler (this_Load);
			}
			internal void this_Load (object sender, EventArgs e)
			{
				ComboBox cb = new ComboBox ();
				cb.DropDownStyle = ComboBoxStyle.DropDownList;
				cb.Parent = this;

				// Add some items to the combo box.
				cb.Items.Add ("Item 0");
				cb.Items.Add ("Item 1");
				cb.Items.Add ("Item 2");

				// Select the last item.
				cb.SelectedIndex = 2;
				Assert.AreEqual(2, cb.SelectedIndex, "SWD1");

				// Show the combo box's dropdown.
				cb.DroppedDown = true;

				// Display the results.
				Application.DoEvents();

				// Hide the combo box's dropdown.
				cb.DroppedDown = false;

				// Display the results.
				Application.DoEvents();

				// Delete an item before the selection.
				// That should move the selection down.
				cb.Items.RemoveAt (1);
				Assert.AreEqual(1, cb.SelectedIndex, "SWD2");

				// Show the combo box's dropdown.
				cb.DroppedDown = true;
				Assert.AreEqual(1, cb.SelectedIndex, "SWD3");
			}
			internal void this_Closed (object sender, EventArgs e)
			{
				Application.Exit();
			}
		}

        [STAThread]
        private static void Main(string[] args)
        {
			// Create a form with a combo box.
			Form form = new MyForm ();
			form.ShowInTaskbar = false;
			form.Show ();

			// Display the results.
			Application.Run();
        }
    }
}
