using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.IO;
using System.Xml.Serialization;
using System.Diagnostics;
using System.Reflection;

namespace TrayMenus
{
    public partial class TrayMenuMainFrm : Form
    {
        ContextMenuStrip cmenu = null;

		public TrayMenuMainFrm()
        {
            InitializeComponent();
        }

        public TrayMenuMainFrm(string file_name, bool setting)
        {
            InitializeComponent();

            cmenu = new ContextMenuStrip(components);

			notifyIcon1.ContextMenuStrip = cmenu;
			cmenu.Opening += HandleOpening;
			cmenu.ItemClicked += HandleItemClicked;
			cmenu.Closed += delegate(object sender, ToolStripDropDownClosedEventArgs e) {
	            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TrayMenuMainFrm));
				notifyIcon1.Icon = ((System.Drawing.Icon)(resources.GetObject("notifyIcon1.Icon")));
				notifyIcon1.Visible = false;	
				notifyIcon1.Visible = true;	
			};
			this.ContextMenuStrip = cmenu;
        }

        private void HandleItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
        }

        private void HandleOpening(object sender, CancelEventArgs e)
        {
        	UpdateContextMenuStrip();
        }

		private void UpdateContextMenuStrip()
		{
            cmenu.Items.Clear();

			ToolStripDropDownMenu dropMenu = new ToolStripDropDownMenu();
			dropMenu.Items.Add("This is a test sub menu item");
			
			ToolStripDropDownItem dropItem = new ToolStripMenuItem("Sub Menu");
			dropItem.DropDown = dropMenu;
			cmenu.Items.Add(dropItem);
			
			if (cmenu.Items.Count > 0)
            {
                cmenu.Items.Add(new ToolStripSeparator());
            }

            ToolStripItem item = cmenu.Items.Add("Settings", null, new EventHandler(OnSettings));
            item.Tag = "SETTINGS_ITEM";
            item = cmenu.Items.Add("Load Menu...", null, null);
			item.Tag = "LOADMENU_ITEM";
            cmenu.Items.Add(new ToolStripSeparator());
            item =  cmenu.Items.Add("Exit", null, new EventHandler(OnExit));
			item.Tag = "EXIT_ITEM";
		}
		
        private void OnExit(object sender, EventArgs e)
        {
            Close();
        }

        private void OnSettings(object sender, EventArgs e)
        {
        }

    }
}