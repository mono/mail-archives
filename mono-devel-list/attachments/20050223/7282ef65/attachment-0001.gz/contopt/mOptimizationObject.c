/*                           ** Mono **
 * File: mOptimization.c/h
 * Version: 0.1
 * Date: 03.12.2004
 *
 * Defines some empty optimization module
 * */

#define INLINE_MONO_OPTIMIZATION
#include "mOptimizationObject.h"

#include <string.h>
#include <glib.h>

/*example of how to use the arrays in ExOptimizationDescriptor*/
OptimizationDescriptor NullOptimizationDescriptor1 = {
	otSpeed,
	ocCheap,
	opStatic,
	oiStandard
};

POptimizationDescriptor NullOptimizationDescriptors[] = {
	&NullOptimizationDescriptor1,
	NULL /*important!! Last element has to be NULL in all arrays!!*/
};

/*Define Extended Optimization Descriptor*/
ExOptimizationDescriptor NullOptimizationDescription = {
	"Mono.Null",	/*Author.Name*/
	1,		/*Initial Version number must be 1!*/
	1,		/*Initial patchlevel must be 1!*/
	NULL,		/*same scheme as below, if needed*/
	NULL,		/*same scheme as below, if needed*/
	(POptimizationDescriptor (*)[]) NullOptimizationDescriptors,	/*C-Compiler needs cast here*/
	MONO_NULLOPTIMIZATION_ID	/*statically linked, so fixed ID*/
};

/*private Prototypes*/
gint32 NullOptimization_EstimateSpeedupFast (gint32 OId, gint32 DId, PCofMethodDataEntry Data);
gpointer NullOptimization_OptimizeAndCompile (gint32 OId, gint32 DId, PCofMethodDataEntry Data, gint32* speedup);


/*Define Optimization Interface*/
OptimizationInterface NullOptimization = {
	&NullOptimizationDescription,
	&NullOptimization_EstimateSpeedupFast,
	&NullOptimization_OptimizeAndCompile
};


/*--------------implementation-----------------*/

gint32
NullOptimization_EstimateSpeedupFast (gint32 OId, gint32 DId, PCofMethodDataEntry Data)
{
	return 0x80000001;
}

gpointer
NullOptimization_OptimizeAndCompile (gint32 OId, gint32 DId, PCofMethodDataEntry Data, gint32* speedup)
{
	*speedup = 0x80000001;
	g_assert (FALSE);
	return NULL;
}

