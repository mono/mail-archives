/*
 *   Dynamic Predictor
 *
 * Selects pre-selects methods for picker.
 * Might feature e.g. Kalman filter..
 *
 * BAD BAD BAD Implementation - needs serious tuning.
 */

#define MDYANMICPREDICTOR_INLINE_
#include "mDynamicPredictor.h"
#include "mono/metadata/debug-helpers.h"


static void DynamicPredictor_WriteProfileData (PDataboardInterface pDataboard);


/* The Phase Change Detection Algorithm used here is based on the one outlined in the paper
 *	"Phase Shift Detection: A Problem Classification" (IBM Research Report)
 * by Hind, Rajan and Sweeney, 2003.
 *
 * This paper also mentiones the algorithm used by Kistler in his work.
 */

#define true 1
#define false 0
#define _DYNAMIC_PREDICTOR_DEBUG_

#define WEIGHT(x) (x)->Calls
#define JITINFO(a) (uintptr_t)(a)->pJitInfo
#define ARRAY(y) (& pProfile[y])
#define VALID(z) ((z)->pJitInfo != NULL)
/* calculates similarity (0..1000) for a weighted abstract representation */
static guint
WeightedModel (DynamicPredictorPhase S1, DynamicPredictorPhase S2, guint ProfileLen,
	       guint IndexOffset, PWeightedSample pProfile)
{
	int i, a;
	guint totalweight = 0;
	guint similarity = 0;
	guint lenS1 = S1.end - S1.start;
	guint lenS2 = S2.end - S2.start;
#ifdef DYNAMIC_PREDICTOR_DEBUG_
	g_print ("LenS1: %i (%i) LenS2 %i (%i) IndexOffset %i\n", lenS1, S1.start, lenS2,
		 S2.start, IndexOffset);
#endif
	/* calculate similarity: run through sorted S2 array */
	a = 0;
	for (i = 0; i < lenS2; i++) {
		int S1index = a + ((S1.start + IndexOffset) % ProfileLen);
		int S2index = i + ((S2.start + IndexOffset) % ProfileLen);
#ifdef DYNAMIC_PREDICTOR_DEBUG_
		g_print ("  S2index %i (%lx) S1index %i (%lx)\n",S2index,
			JITINFO (ARRAY (S2index)),S1index,JITINFO (ARRAY (S1index)));
#endif
		if (VALID (ARRAY (S2index))) {
			totalweight += WEIGHT (ARRAY (S2index));

			/* while S1 array value < current S2 array value, advance S1 index */
			while ((  (!VALID (ARRAY (S1index)))
			          || (JITINFO (ARRAY (S1index)) < JITINFO (ARRAY (S2index))))
			       && (a < lenS1))
			{
				a++;
				S1index = a + (S1.start + IndexOffset)
					% ProfileLen;
#ifdef DYNAMIC_PREDICTOR_DEBUG_
				g_print ("             S1index %i (%lx)\n",S1index,
					JITINFO (ARRAY (S1index)));
#endif
			}

			/* if we have a match, calculate minimal weight and add to similarity */
			if (JITINFO (ARRAY (S2index)) == JITINFO (ARRAY (S1index))) {
				similarity += WEIGHT (ARRAY (S2index)) <= WEIGHT (ARRAY (S1index)) ?
					 WEIGHT (ARRAY (S2index)) : WEIGHT (ARRAY (S1index));
			}

		}

		if (a >= lenS1)
			break;
	}
#ifdef DYNAMIC_PREDICTOR_DEBUG_
	g_print ("SIM: %i / %i\n", similarity, totalweight);
#endif
	return (guint)(((similarity + 0.0)/ (totalweight + 0.0)) * 1000.0);
}
#undef WEIGHT
#undef JITINFO
#undef ARRAY
#undef VALID


/*returns true, if phases are similar, else returns false*/
static gboolean
Similarity (guint Threshold, DynamicPredictorPhase S1, DynamicPredictorPhase S2, guint ProfileLen,
            guint IndexOffset, PWeightedSample pProfile)
{
	/*S1 has to be reversed: We have a consecutive breakup here, so
	  the similarity value is computed from the last chunk of the
	  first string and the first chunk of the  second string. (See
	  page 3 - definition of Breakup)

	  This assumtion if implicitely coded into the algorithm, so
	  we do not actually reverse the order of S1 here.

	  Note: For WeightedModel, we do not need to respect order.
	*/
	guint similarity = WeightedModel (S1, S2, ProfileLen, IndexOffset, pProfile);
#ifdef DYNAMIC_PREDICTOR_DEBUG_
	g_print ("SIM: %i\n", similarity);
#endif
	return  similarity >= Threshold;
}


/* Searches pProfile for similar phases. Returns number of phases found and an array
 * with indices of start and end of each phase.
 * Notes:
 *	pPhaseBoundary.Count == numOfPhases << 1
 *	pPhaseBoundary[2n]	=> start index of phase
 *	pPhaseBoundary[2n+1]	=> end index of phase
 *	You have to g_array_free(pPhaseBoundary,TRUE) in the calling function!
 */
guint
DynamicPredictor_PhaseShiftDetection (guint ChunkSize, guint Threshold, guint ProfileLen,
				      guint IndexOffset, PWeightedSample pProfile,
				      /*out*/ GArray **pPhaseBoundary)
{
	gboolean	inTransition = true;
	guint		numOfPhases = 0;
	guint		startOfPhase = 0;
	guint		endOfPhase = ChunkSize - 1;

	Threshold %= 1001;	/* value has to be in range 0..1000 */

	/* In case pPhaseBoundary <> NULL */
	if (*pPhaseBoundary)
		g_array_free(*pPhaseBoundary, TRUE);

	*pPhaseBoundary = g_array_new (TRUE /*just to be safe*/, TRUE /*ditto*/, sizeof(guint));

	while (endOfPhase + ChunkSize < ProfileLen) {
		DynamicPredictorPhase S1 = {startOfPhase, endOfPhase};
		DynamicPredictorPhase S2 = {endOfPhase + 1, endOfPhase + ChunkSize};

		if (Similarity (Threshold, S1, S2, ProfileLen, IndexOffset, pProfile)) {
			if (inTransition)
				inTransition = false;
		} else {
			if (!inTransition) {
				*pPhaseBoundary = g_array_append_val (*pPhaseBoundary, startOfPhase);
				*pPhaseBoundary = g_array_append_val (*pPhaseBoundary, endOfPhase);
				numOfPhases++;
				startOfPhase = endOfPhase + 1;
				inTransition = true;
			} else {
				startOfPhase += ChunkSize;
			}
		}
		endOfPhase += ChunkSize;
	}

	if (! inTransition) {
		*pPhaseBoundary = g_array_append_val (*pPhaseBoundary, startOfPhase);
		*pPhaseBoundary = g_array_append_val (*pPhaseBoundary, endOfPhase);
		numOfPhases++;
	}

	return numOfPhases;
}

#undef true
#undef false

/* Quicksort of Robert Sedgewick and Jon Bentley */
#define exch(a,b) \
	do { \
		WeightedSample temp = a;\
		a = b;\
		b = temp;\
	} while (0)

static void
SamplesQuicksort(PWeightedSample pSamples, int l, int r)
{
	int i = l-1, j = r, p = l-1, q = r;
	uintptr_t v = (uintptr_t) pSamples [r].pJitInfo;
	if (r <= l) return;
	for (;;) {
		while (((uintptr_t)pSamples [++i].pJitInfo) < v) ;
		while (v < (uintptr_t) pSamples [--j].pJitInfo)
			if (j == l) break;
		if (i >= j) break;
		exch(pSamples [i], pSamples [j]);
		if ((uintptr_t)pSamples [i] .pJitInfo == v) {
			p++;
			exch(pSamples [p], pSamples [i]);
		}
		if (v == (uintptr_t) pSamples [j].pJitInfo) {
			q--;
			exch(pSamples [j], pSamples [q]);
		}
	}
	exch(pSamples [i], pSamples [r]);
	j = i-1;
	i = i+1;
	int k;
	for (k = l; k < p; k++, j--)
		exch(pSamples [k], pSamples [j]);
	for (k = r-1; k > q; k--, i++)
		exch(pSamples [i], pSamples [k]);
	SamplesQuicksort (pSamples, l, j);
	SamplesQuicksort (pSamples, i, r);
}
#undef exch



static void
DynamicPredictor_DoCompressData (PDataboardInterface pDataboard)
{
	/*clean up next chunk of data samples we just fetched from SAM:
	  Delete any dupes that might be in there from the TopClimb
	  part; Do a quicksort first on the two field parts */
	PDynamicPredictorDataboardInterface pPredictor = pDataboard->pDynamicPredictorData;
	int index = pPredictor->ProfileDataFirstElement;
	int length = DYNAMIC_PREDICTOR_CHUNK_SIZE - 1;
	SamplesQuicksort (&pPredictor->ProfileDataHits [index],0 ,length);
}


/* Accesses data provided by SAM and copies it into the RR ProfileData buffer:
 * Each chunk is devided in two parts (dupes possible and likely!!):
 * -> 1st half contains TopWeight entries; (Favours high weight)
 * -> 2nd half contains TopClimb entries; (Favours low weight)
 */
static void
DynamicPredictor_DoCopyData (PDataboardInterface pDataboard)
{
	PDynamicPredictorDataboardInterface pPredictor = pDataboard->pDynamicPredictorData;
	int index = pPredictor->ProfileDataFirstElement;

	while (pDataboard->pProfilerData->Lock) pthread_yield ();
/**/	pDataboard->pProfilerData->Lock = 2;
/**/	/*copy ProfileTopWeight and ProfileTopClimb*/
/**/	int i;
/**/	for (i = 0; i < DYNAMIC_PREDICTOR_CHUNK_SIZE; i++) {
/**/		pPredictor->ProfileDataHits [index] = pDataboard->pProfilerData->ProfileTopWeight [i];
/**/		index = (index + 1);
/**/	}
/**/	index = pPredictor->ProfileDataFirstElement;
/**/	for (i = 0; i < DYNAMIC_PREDICTOR_CHUNK_SIZE; i++) {
/**/		int arr = pDataboard->pProfilerData->Aged ? 1 : 0;
/**/		pPredictor->ProfileDataClimb [index] =
/**/			pDataboard->pProfilerData->ProfileTopClimb [arr] [i];
/**/		index = (index + 1);
/**/	}
/**/
/**/	pDataboard->pProfilerData->Lock = 0;

	DynamicPredictor_DoCompressData (pDataboard);
}

/*check if not queued in picker or optimizer*/
#define NOWHEREQUEUED(x) (!( (x)->cof_optimizer_queued || (x)->cof_picker_queued ) )

/* inspect the hitlist and decide if running pattern has significantly changed. */
void
DynamicPredictor_DoRun (PDataboardInterface pDataboard)
{
	GArray *pPhaseBoundary = NULL;
	int numPhases;
	int i;
	PDynamicPredictorDataboardInterface pDynPredictor = pDataboard->pDynamicPredictorData;
	/*calculate array index of 'oldest' entries.*/
	int oldChunk = (pDynPredictor->ProfileDataFirstElement +
		DYNAMIC_PREDICTOR_CHUNK_SIZE) % DYNAMIC_PREDICTOR_PROFILE_DATA_SIZE;

#ifdef DYNAMIC_PREDICTOR_DEBUG_
	DynamicPredictor_WriteProfileData (pDataboard);
#endif
	/* Do Phase shift detection */
	numPhases = DynamicPredictor_PhaseShiftDetection (DYNAMIC_PREDICTOR_CHUNK_SIZE,
		 	DYNAMIC_PREDICTOR_THRESHOLD, DYNAMIC_PREDICTOR_PROFILE_DATA_SIZE,
		 	oldChunk, &pDynPredictor->ProfileDataHits[0], &pPhaseBoundary);

#ifdef DYNAMIC_PREDICTOR_DEBUG_
	g_print ("\n COF: PRE Phases found %i: ", numPhases);
	for (i = 2 * numPhases; i > 0; i = i - 2) {
		DynamicPredictorPhase phase;
		phase.end = g_array_index (pPhaseBoundary, guint, i - 1);
		phase.start = g_array_index (pPhaseBoundary, guint, i - 2);
		g_print (" (%i -> %i) ", (phase.start + oldChunk) % DYNAMIC_PREDICTOR_PROFILE_DATA_SIZE,
			(phase.end + oldChunk) % DYNAMIC_PREDICTOR_PROFILE_DATA_SIZE);
	}
	g_print ("\n");
#endif

	/* Decide if somethin' has changed.. TODO: Use the info from Phase Shift det. better..*/
	int written = 0;
	int writepos = 0;
	if ((numPhases == 0) || (numPhases != pDataboard->pDynamicPredictorData->Phases)) {
		/*no phases found; or some phase change - look at the Climb list*/
		for (i = 0; i < DYNAMIC_PREDICTOR_CHUNK_SIZE; i++) {
			int pos = pDynPredictor->ProfileDataFirstElement + i;
			writepos = (pDynPredictor->WriteQueuePos + written)
				 % DYNAMIC_PREDICTOR_QUEUE_SIZE;

			MonoJitInfo *pCandidate = pDynPredictor->ProfileDataClimb [pos].pJitInfo;
			if (!pCandidate || pCandidate->cof_sam_ignore)
				continue;
			if (NOWHEREQUEUED(pCandidate) && (writepos != pDynPredictor->ReadQueuePos)) {
				pCandidate->cof_picker_queued = 1;
				pDynPredictor->PredictorQueue[writepos] = pDynPredictor->ProfileDataClimb [pos];
				written++;
#ifdef DYNAMIC_PREDICTOR_DEBUG_
				char *mn = mono_method_full_name (pCandidate->method, TRUE);
				g_printf ("COF: PRE  c     (%i) %p %s\n", i, pCandidate, mn);
				g_free (mn);
#endif
			} else {
#ifdef DYNAMIC_PREDICTOR_DEBUG_
				char *mn = mono_method_full_name (pCandidate->method, TRUE);
				g_printf ("COF: PRE  ?     (%i) %s\n", i, mn);
				g_free (mn);
#endif
			}
		}
		pDynPredictor->WriteQueuePos = writepos;
		pDynPredictor->Phases = numPhases;
		Picker_Wakeup (pDataboard->pPickerData);
	} else {
		/*look at top hits*/
		for (i = 0; i < DYNAMIC_PREDICTOR_CHUNK_SIZE; i++) {
			int pos = pDynPredictor->ProfileDataFirstElement + i;
			writepos = (pDynPredictor->WriteQueuePos + written)
				 % DYNAMIC_PREDICTOR_QUEUE_SIZE;

			MonoJitInfo *pCandidate = pDynPredictor->ProfileDataHits [pos].pJitInfo;
			if (!pCandidate || pCandidate->cof_sam_ignore)
				continue;
			if (NOWHEREQUEUED(pCandidate) && (writepos != pDynPredictor->ReadQueuePos)) {
				pCandidate->cof_picker_queued = 1;
				pDynPredictor->PredictorQueue[writepos] = pDynPredictor->ProfileDataHits [pos];
				written++;
#ifdef DYNAMIC_PREDICTOR_DEBUG_
				char *mn = mono_method_full_name (pCandidate->method, TRUE);
				g_printf ("COF: PRE  h     (%i) %s\n", i, mn);
				g_free (mn);
#endif
			} else {
#ifdef DYNAMIC_PREDICTOR_DEBUG_
				char *mn = mono_method_full_name (pCandidate->method, TRUE);
				g_printf ("COF: PRE  ?     (%i) %s\n", i, mn);
				g_free (mn);
#endif
			}
		}
		pDynPredictor->WriteQueuePos = writepos;
		Picker_Wakeup (pDataboard->pPickerData);
	}

	/* Fill WeightedSamples into PredictorQueue */

	pDataboard->pDynamicPredictorData->ProfileDataFirstElement = oldChunk;
	if (pPhaseBoundary)
		g_array_free(pPhaseBoundary, TRUE);
}



static void
DynamicPredictor_WriteProfileData (PDataboardInterface pDataboard)
{
	PDynamicPredictorDataboardInterface pPredictor = pDataboard->pDynamicPredictorData;
	int i;
	g_print ("\nCOF: PRE Profile Data (%i)\n",pPredictor->ProfileDataFirstElement);
	for (i = 0; i < DYNAMIC_PREDICTOR_PROFILE_DATA_SIZE; i++) {
		int index = (/*pPredictor->ProfileDataFirstElement*/ + i) %
			DYNAMIC_PREDICTOR_PROFILE_DATA_SIZE;

		if (!(i % (DYNAMIC_PREDICTOR_CHUNK_SIZE))) {
			g_print ("\nCOF: PRE == Chunk %i\n", i / DYNAMIC_PREDICTOR_CHUNK_SIZE);
		}


		char *mn;
		char *isTopHit;
		char *isTopInc;
		PWeightedSample pSample = &pPredictor->ProfileDataHits [index];
		isTopHit = pSample->IsProfileTopHit == 1 ? "y" : "n";
		isTopInc = pSample->IsProfileTopClimb == 1 ? "y" : "n";
		if (pPredictor->ProfileDataHits [index].pJitInfo)
			mn = mono_method_full_name (pSample->pJitInfo->method, TRUE);
		else
			mn = "NULL";
		g_printf (" (%3i (%s), %2i (%s), %p)  %s\n", pSample->Weight, isTopHit,
			pSample->Calls, isTopInc, pSample->pJitInfo, mn);
		if (pPredictor->ProfileDataHits [index].pJitInfo)
			g_free (mn);

	}
	g_print("\n");
}


guint32
DynamicPredictor_ThreadMain (gpointer Arg)
{
	PDataboardInterface pDataboard = (PDataboardInterface) Arg;

	/*Run this while not shut down*/
	unsigned char generationState = pDataboard->pProfilerData->AgeCount;
	while (!pDataboard->pDynamicPredictorData->Shutdown &&
	       !pDataboard->pProfilerData->Shutdown) {
/**/		mono_mutex_lock (&pDataboard->pProfilerData->sam_mutex);
/*-*/		mono_cond_wait (&pDataboard->pProfilerData->sam_newgeneration_cv,
/**/			&pDataboard->pProfilerData->sam_mutex);
/**/		generationState = pDataboard->pProfilerData->AgeCount;
/**/		DynamicPredictor_DoCopyData (pDataboard);
/**/		mono_mutex_unlock (&pDataboard->pProfilerData->sam_mutex);
		DynamicPredictor_DoRun (pDataboard);
	}
#ifdef DYNAMIC_PREDICTOR_DEBUG_
	DynamicPredictor_WriteProfileData (pDataboard);
#endif
	/*g_printf ("COF: PRE shutdown\n");*/
	ExitThread (0);
}
