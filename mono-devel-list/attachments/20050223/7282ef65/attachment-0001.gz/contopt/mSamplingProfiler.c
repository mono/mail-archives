/*
 *   Sampling Profiler
 *
 * Default Profiler that is used by COF.
 *
 * This is a low frequency sampling profiler that does not use any special
 * hardware support. This profiler is not meant to supply Basic-Block level
 * profiling data!
 *
 * Note that this profiler module is somewhat special, as it represents the
 * default profiling mechanism. Therefore it's more closely connected to
 * mProfiler.h
 */
#include "mono/io-layer/mono-mutex.h"
#include "mProfiler.h"
#include "mProfilerObject.h"
#include "glib.h"
#include "config.h"
#include "mini.h"
#include "signal.h"
#include "errno.h"
#include "mono/metadata/debug-helpers.h"
#include "execinfo.h"
#include "sched.h"
#include "time.h"


#define SAMPLING_PROFILER_DEBUG_

/* !!DISABLED by default!!
   Filters out all ip addresses that we are interested in..
   Could be faster if inlined in the signal handler and probably a tree? was used for search..
   THIS IS SIGNALHANDLER CODE! */
int
FilterManaged (void *data, int csize, int size, void *user_data)
{
/*!*/	uintptr_t ip = *(uintptr_t*) user_data;
/*!*/	int result = ((uintptr_t)data <= ip) && (ip <= ((uintptr_t)data) + csize);
/*!*/	if (result)
/*!*/		*(uintptr_t*) user_data = 0;
/*!*/	return result;
}


/*
  Writes out the sampled IP addrs along with the names of the functions the
  addrs belong to. Heavily based on work done by Paolo Moralo.
 */
void
SamplingProfiler_WriteThreadSamples (PThreadListEntry thread)
{
	g_printf ("COF: SAM Thread Id: %li (%i)\n",(long unsigned int)thread->ThreadId,
	     thread->NewSignals);

	int i;
	for (i = 0; i < MAX_SAMPLES_PER_THREAD; i++) {
		MonoJitInfo *ji;
		char *mn;
		intptr_t ip = (intptr_t) thread->Samples [i];
		intptr_t mask = (intptr_t)1 << (sizeof(void*)-1);
#ifdef SAM_TRY_FETCH_JIT_INFO_FAST
		if (!(ip & mask))
			ji = (MonoJitInfo*) ip;
		else
#endif
			ji = mono_jit_info_table_find (thread->Domain, (gpointer)(ip & ~mask));

		if (ji) {
			mn = mono_method_full_name (ji->method, TRUE);
		}
		else {
			char **names;
			gpointer ipptr = (gpointer) ip;
			names = backtrace_symbols (&ipptr, 1);
			mn = g_strdup (names [0]);
			free (names);
		}
		g_printf ("COF: SAM        IP:%lx (%s)\n", thread->Samples [i], mn);
		g_free (mn);
	}
}


/* Writes out all sample data for all threads of a given databoard. */
void
SamplingProfiler_WriteAllThreadSamples (PDataboardInterface pDataboard)
{
	PThreadListEntry thread = pDataboard->pLastThreadEntry;
	while (thread) {
		SamplingProfiler_WriteThreadSamples (thread);
		thread = thread->PrevEntry;
	}
}


/* writes out the global hitlist */
void
SamplingProfiler_WriteHitList (PDataboardInterface pDataboard)
{
	int bucket = 0; /* 0..15 */
	int index = 0;  /* 0..len-1 */
	PProfilerDataboardInterface pProfiler = pDataboard->pProfilerData;

	for (bucket = 15; bucket >= 0; bucket--) {
		int valIndex = (bucket + pProfiler->HitListOffset) % SAM_BUCKET_COUNT;
		GArray *pBucketArray = pProfiler->pGlobalHitList [valIndex];
		g_printf ("COF: SAM === HitList Bucket %i ===\n", bucket);
		for (index = pBucketArray->len -1; index >= 0; index--) {
			char *mn;
			MonoJitInfo *pEntry = (MonoJitInfo*) g_array_index (pBucketArray, uintptr_t,
				 index);
			mn = mono_method_full_name (pEntry->method, TRUE);

			/* 'aging' (correct the weight, if necessary) */
			int weight = 0;
			if (pProfiler->HitListOffset != pEntry->cof_hitlist_ltu_offset) {
				unsigned char generations;
				generations = (pProfiler->HitListOffset -
					pEntry->cof_hitlist_ltu_offset) & 0xf;

				DIV2ROUND (pEntry->cof_sam_weight);
				DIV2ROUND (pEntry->cof_sam_LTU);
				pEntry->cof_sam_weight += pEntry->cof_sam_LTU & 0x8000 ? 0x7fff :
					pEntry->cof_sam_LTU;
				pEntry->cof_sam_LTU = 0;

				while (generations > 1) {
					generations --;
					DIV2ROUND (pEntry->cof_sam_weight);
				}
				pEntry->cof_hitlist_ltu_offset = pProfiler->HitListOffset;
			}

			weight = DIV2ROUND_NOT_ASSIGN (pEntry->cof_sam_LTU) +
				DIV2ROUND_NOT_ASSIGN (pEntry->cof_sam_weight);

			g_printf ("COF: SAM        (%i) %s\n", weight, mn);
			g_free (mn);
		}
	}
	g_print ("COF: SAM Lost Samples %li\n", pProfiler->LostSamples);
}



/*******************************************************************************
 *                     Ages Sampling Data by division by two                   *
 * Attention: Not SMP safe loong Crit Section below.                           *
 *******************************************************************************/
static void
AgeSampleData (PDataboardInterface pDataboard)
{
	/*get the lock; FIXME: SMP systems */
	while (pDataboard->pProfilerData->Lock) pthread_yield ();

/* ~ ~ Crit Section Start ~ ~ */
/**/	mono_mutex_lock (&pDataboard->pProfilerData->sam_mutex);
/**/	pDataboard->pProfilerData->Lock = 1;
/**/
/**/	/*update ProfileTopWeight*/
/**/	int i, bucket, remainder, copied, todo;
/**/	copied = 0;
/**/	for (bucket = 15; bucket >= 0; bucket--) {
/**/		int valIndex = (bucket + pDataboard->pProfilerData->HitListOffset) % SAM_BUCKET_COUNT;
/**/		int bucketlen = pDataboard->pProfilerData->pGlobalHitList [valIndex]->len;
/**/		remainder = (DYNAMIC_PREDICTOR_CHUNK_SIZE) - copied;
/**/
/**/		if (remainder <= 0)
/**/			break;
/**/
/**/		todo = bucketlen < remainder ? bucketlen : remainder;
/**/		for (i = 0; i < todo; i++) {
/**/			MonoJitInfo *CopyElem = (MonoJitInfo*) g_array_index (
/**/				pDataboard->pProfilerData->pGlobalHitList [valIndex], uintptr_t, i);
/**/			/*g_print ("%p\n",CopyElem);*/
/**/			pDataboard->pProfilerData->ProfileTopWeight [copied].pJitInfo = CopyElem;
/**/			pDataboard->pProfilerData->ProfileTopWeight [copied].Weight =
/**/				CopyElem->cof_sam_weight;
/**/			pDataboard->pProfilerData->ProfileTopWeight [copied].Calls =
/**/				CopyElem->cof_sam_LTU;
/**/			pDataboard->pProfilerData->ProfileTopWeight [copied].IsProfileTopHit = 1;
/**/			copied++;
/**/		}
/**/
/**/	}
/**/	for (i = copied; i < DYNAMIC_PREDICTOR_CHUNK_SIZE; i++) {
/**/		pDataboard->pProfilerData->ProfileTopWeight [i].pJitInfo = NULL;
/**/	}
/**/
/**/	/*TODO: CALLBACK*/
/**/
/**/	/*age*/
/**/	pDataboard->pProfilerData->CurrentGeneration++;
/**/	SamplingProfiler_AgeHitList (pDataboard);
/**/
/**/	/* clear Increase hitlist */
/**/	pDataboard->pProfilerData->IncreaseBufferLen = 0;
/**/	int updateList = pDataboard->pProfilerData->Aged ? 1 : 0;
/**/	for (i = 0; i < DYNAMIC_PREDICTOR_CHUNK_SIZE; i++)
/**/		pDataboard->pProfilerData->ProfileTopClimb [updateList] [i].pJitInfo = NULL;
/**/
/**/	mono_cond_signal (&pDataboard->pProfilerData->sam_newgeneration_cv);
/**/	pDataboard->pProfilerData->Lock = 0;
/**/	mono_mutex_unlock (&pDataboard->pProfilerData->sam_mutex);
/* ~ ~ Crit Section End ~ ~ */

	/*signal that we've aged the data*/
	pDataboard->pProfilerData->Aged = ~pDataboard->pProfilerData->Aged;
	pDataboard->pProfilerData->AgeCount++;
}


/*******************************************************************************
 *        Frees a thread from profiler's threadlist.                           *
 *******************************************************************************/
static PThreadListEntry
FreeThread (PDataboardInterface pDataboard, PThreadListEntry pThread)
{
	/* dequeue this Thread; but only if not first */
	PThreadListEntry pThreadEntry = pDataboard->pLastThreadEntry;
	if (pThreadEntry && (!pthread_equal (pThread->ThreadId, pThreadEntry->ThreadId))) {
		/* walk the list... */
		while (pThreadEntry)
			if (pThreadEntry->PrevEntry &&
			   (pthread_equal (pThreadEntry->PrevEntry->ThreadId, pThread->ThreadId))) {

				PThreadListEntry temp = pThreadEntry->PrevEntry->PrevEntry;

				#ifdef SAMPLING_PROFILER_DEBUG_
				/*g_printf ("COF: SAM freed thread %li\n",(long int)
					pThreadEntry->PrevEntry->ThreadId);*/
				/* write data before freeing */
				/*SamplingProfiler_WriteThreadSamples (pThreadEntry->PrevEntry);*/
				#endif

				g_free (pThreadEntry->PrevEntry);
				pThreadEntry->PrevEntry = temp;
				return temp;
			}
			pThreadEntry =  pThreadEntry->PrevEntry;
		}
	return pThread->PrevEntry;
}



/*******************************************************************************
 *        Read thread->Samples and update hitlist resp. the MonoJitInfo        *
 *                                                                             *
 * ATTENTION: This function is quite expensive:                                *
 *    - about MAX_SAMPLES_PER_THREAD mono_jit_info_table_find calls            *
 *      (Binary searches)                                                      *
 *******************************************************************************/
static void
ProcessSampleData (PDataboardInterface pDataboard, PThreadListEntry pThread)
{
	MonoJitInfo *ji;
	guint32 recordedSamples = pThread->TotalSignals;
	int i;

	if (recordedSamples > MAX_SAMPLES_PER_THREAD) {
		pDataboard->pProfilerData->LostSamples += (recordedSamples - MAX_SAMPLES_PER_THREAD);
		recordedSamples = MAX_SAMPLES_PER_THREAD;
	}

	for (i = 0; i < recordedSamples; i++) {
		int index = (pThread->StartingSample + i) % MAX_SAMPLES_PER_THREAD;
		intptr_t ip = (intptr_t) pThread->Samples [index];
		intptr_t mask = (intptr_t)1 << (sizeof(void*)-1);

		ji = NULL;
#ifdef SAM_TRY_FETCH_JIT_INFO_FAST
		if (!(ip & mask)) {
			ji = (MonoJitInfo*) ip;
			/*g_assert (!((uintptr_t)ji & 0x7)) ;*/

		} else
#endif
		{
			ji = mono_jit_info_table_find (pThread->Domain, (gpointer)(ip & ~mask));
			/*g_assert (!((uintptr_t)ji & 0x7));*/
		}

		/*there might be cases our first filter did not work exactly - if enabled.*/
		if (ji && !ji->cof_sam_ignore) {
			if (!ji->cof_hitlist_queued) {
				guint16 generationDiff = pDataboard->pProfilerData->CurrentGeneration -
					ji->cof_sam_LTU;

				ji->cof_sam_weight = (ji->cof_sam_weight >> generationDiff) + 1;
				ji->cof_sam_LTU = pDataboard->pProfilerData->CurrentGeneration;

				if (ji->cof_sam_weight > SAM_HITLIST_ENTRY_WEIGHT)
					SamplingProfiler_AddToHitList (pDataboard, ji, pThread->Domain);
			} else
				SamplingProfiler_UpdateHitListEntry (pDataboard,  ji, 1);
		}
	}

	pThread->StartingSample = (pThread->StartingSample + recordedSamples) % MAX_SAMPLES_PER_THREAD;
}



/*******************************************************************************
 *          Sampling Profiler Thread; Arg is pointer to Databoard.             *
 *******************************************************************************/
guint32
SamplingProfiler_ThreadMain (gpointer Arg)
{
	PDataboardInterface pDataboard = (PDataboardInterface) Arg;

	/*Run this while not shut down*/
	int iterations = 0;
	while (!pDataboard->pProfilerData->Shutdown) {
#ifdef SAM_USE_CONDITION_ON_SAMPLES
		mono_mutex_lock (&pDataboard->pProfilerData->sam_mutex);
		mono_cond_wait (&pDataboard->pProfilerData->sam_newdata_cv,
				&pDataboard->pProfilerData->sam_mutex);
		mono_mutex_unlock (&pDataboard->pProfilerData->sam_mutex);
#endif

		PThreadListEntry pThread = pDataboard->pLastThreadEntry;
		while (pThread) {
			pThread->TotalSignals += InterlockedExchange(&pThread->NewSignals, 0);
#ifndef SAM_USE_CONDITION_ON_SAMPLES
			if (pThread->TotalSignals >= MIN_SAMPLES_PER_THREAD_TO_PROCESS) {
#endif
				iterations++;
				ProcessSampleData (pDataboard, pThread);
				pThread->TotalSignals = 0;
#ifndef SAM_USE_CONDITION_ON_SAMPLES
			}
#endif

			if (!pThread->DoRemove)
				pThread = pThread->PrevEntry;
			else
				pThread = FreeThread (pDataboard, pThread);
		}

		if (iterations >= ((guint32)1 << SAM_GENERATION_DELAY)) {
			iterations = 0;
			AgeSampleData (pDataboard);
			#ifdef SAMPLING_PROFILER_DEBUG_
			/*g_printf ("COF: SAM aged\n");*/
			#endif
		}

		/*Delay may be changed by changing SampleDelay entry in databoard;
		  We could also work with some alarm/timer, but as sampling should be
		  some background process and we do not 'need' strict time intervals, I
		  chose sleep for the time being. Alternatively pthread_yield is called,
		  which seems to work quite good. Check for 'LostSamples'..*/
#ifndef SAM_USE_CONDITION_ON_SAMPLES
		if (!pDataboard->pProfilerData->Shutdown) {
			if (!pDataboard->pProfilerData->SampleDelay)
				pthread_yield ();
			else {
				struct timespec req, rem;
				req.tv_sec = 0;
				req.tv_nsec= pDataboard->pProfilerData->SampleDelay;
				nanosleep(&req,&rem);
			}
		}
#endif
	}
	mono_mutex_lock (&pDataboard->pProfilerData->sam_mutex);
	mono_cond_broadcast (&pDataboard->pProfilerData->sam_newgeneration_cv);
	mono_mutex_unlock (&pDataboard->pProfilerData->sam_mutex);
	/*g_printf ("COF: SAM shutdown (%li)\n", pDataboard->pProfilerData->LostSamples);*/
	ExitThread (0);
}


