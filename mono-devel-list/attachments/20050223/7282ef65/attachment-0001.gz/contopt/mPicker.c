
#define MPICKER_INLINE_
#include "mPicker.h"
#include "mono/metadata/debug-helpers.h"
#include "mOptimizer.h"
#include "mono/io-layer/atomic.h"

OptimizationDescriptor optHintCheap = {
	otSpeed,
	ocCheap,
	opStatic,
	0};

OptimizationDescriptor optHintAverage = {
	otSpeed,
	ocCheap | ocAverage,
	opStandardProfileGuided | opStatic,
	 0};

/* checks for cheap, fast optimizations */
G_GNUC_UNUSED static int
Picker_CheckCheapRecompile (PDataboardInterface pDataboard,MonoJitInfo *pMethod)
{
	/* see what optimizer can give us on speedup */
	gint32 speedup = Optimizer_EstimateSpeedup (pDataboard, &optHintCheap, pMethod);
	/*  */
	if ((speedup > 0) && (speedup >= PO_MINIMUM_SPEEDUP_CHEAP)) {
		Optimizer_AddOptimizationCandidate (pDataboard, &optHintCheap, pMethod);
		return 1;
	}
	return 0;
}

static int
Picker_CheckAverageRecompile (PDataboardInterface pDataboard, MonoJitInfo *pMethod)
{
	/* see what optimizer can give us on speedup */
	gint32 speedup = Optimizer_EstimateSpeedup (pDataboard, &optHintAverage, pMethod);
	/*  */
	if ((speedup > 0) && (speedup >= PO_MINIMUM_SPEEDUP_AVERAGE)) {
		Optimizer_AddOptimizationCandidate (pDataboard, &optHintAverage, pMethod);
		return 1;
	} else
		return 0;
}

static void
Picker_RemoveMethodData (PDataboardInterface pDataboard, MonoJitInfo *pJitInfo)
{
	/* check if queued or we want to keep the data */
	if (! (pJitInfo->cof_picker_queued == 1 || pJitInfo->cof_optimizer_queued == 1 ||
	     pJitInfo->cof_keep_data == 1)) {
		PCofMethodDataEntry pData;
/**/		Databoard_Lock (pDataboard);
/**/		pData = g_tree_lookup (pDataboard->pMethodData, pJitInfo);
/**/		if (pData) {
/**/			g_tree_remove (pDataboard->pMethodData, pJitInfo);
/**/			g_free (pData);
/**/		}
/**/		Databoard_Unlock (pDataboard);
	}
	/* dequeue */
	pJitInfo->cof_picker_queued = 0;
}


G_GNUC_UNUSED static void
Picker_ProcessLoaderQueue ()
{
	/*may be fed by mono with first-time compiled methods.*/
	/*Do a Picker_CheckCheapRecompile here.*/
}

static void
Picker_ProcessMonitorQueue ()
{
	/*This is the queue that contains all methods we added instruction
	  profiling information to: See if enough information has been collected
	  and trigger removal (=recompilation) of the method.*/
}

/* Process the methods we get from sampling profiler: Try average optimizations, because
   this are hot methods here! Note: The static predictor might allow us for applying
   ocExpensive or ocNPcomplete optimizations under certain conditions. (Not yet supported) */
static void
Picker_ProcessDynamicPredictorQueue (PDataboardInterface pDataboard,
				     PDynamicPredictorDataboardInterface pPredictor)
{
	do {
		/*play a black whole for now...*/
		int nextpos = (pPredictor->ReadQueuePos + 1) % DYNAMIC_PREDICTOR_QUEUE_SIZE;
		MonoJitInfo *pEntry = pPredictor->PredictorQueue [nextpos].pJitInfo;
		/*check for method data still being there! (we could have some race)*/
		if (pEntry) {
#ifdef DYNAMIC_PICKER_DEBUG_
			int weight = pPredictor->PredictorQueue [nextpos].Weight;
			int calls = pPredictor->PredictorQueue [nextpos].Calls;
			char *mn = mono_method_full_name (pEntry->method, TRUE);
			g_print ("COF: P/O     %i   (%i, %i) %s\n",nextpos, calls, weight, mn);
			g_free (mn);
#endif
			if (!Picker_CheckAverageRecompile (pDataboard, pEntry)) {
				/*if we can not apply average optimizations skip it in
				  future. FIXME: Check for instrumentation if very hot*/
				pEntry->cof_sam_ignore = 1;
				Picker_RemoveMethodData (pDataboard, pEntry);
#ifdef DYNAMIC_PICKER_DEBUG_
				g_print ("COF: P/O Candidate; ignored\n");
#endif
			}
		}
		if (nextpos != pPredictor->WriteQueuePos)
			pPredictor->ReadQueuePos = nextpos;
		else
			break;
	} while (1);
}

/* Picker/Optimizer Thread */
guint32
Picker_ThreadMain (gpointer Arg)
{
	PDataboardInterface pDataboard = ((PDataboardInterface) Arg);
	PPickerDataboardInterface pPicker = pDataboard->pPickerData;
	PDynamicPredictorDataboardInterface pPredictor = pDataboard->pDynamicPredictorData;

	while (! pPicker->Shutdown) {
/**/		mono_mutex_lock (&pPicker->picker_mutex);
/**/		mono_cond_wait (&pPicker->picker_newdata_cv, &pPicker->picker_mutex);
/**/		mono_mutex_unlock (&pPicker->picker_mutex);
		int nextpos = (pPredictor->ReadQueuePos + 1) % DYNAMIC_PREDICTOR_QUEUE_SIZE;
		if (nextpos != pPredictor->WriteQueuePos)
			Picker_ProcessDynamicPredictorQueue (pDataboard, pPredictor);
		Picker_ProcessMonitorQueue ();
		while (Optimizer_OptimizeTopCandidate (pDataboard) != 0x80000000);
	}

	/*g_printf ("COF: P/O shutdown\n");*/
	ExitThread (0);
}
