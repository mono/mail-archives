#ifndef MOPTIMIZATIONOBJECT_H_
#define MOPTIMIZATIONOBJECT_H_	1
#include "mDataboard.h"
#include <intps.h>
#include <glib.h>

/*                     === OptimizationDescriptor Enums ===
 *
 * */

typedef enum {
	otSpeed,			/*optimize for speed*/
	otMemoryConsumtion		/*optimize for _less_ memory usage*/
} OptimizationTarget;

typedef enum {
	/*0 == wildcard*/
	ocCheap = 1,			/*cheap: can be applied to almost all methods*/
	ocAverage = 2,			/*average: only applied to hot methods*/
	ocExpensive = 4,		/*expensive: long running, hot methods*/
	ocNPComplete = 8		/*npcomplete: VERY expensive; very long running servers*/
} OptimizationComplexity;

typedef enum {
	/*0 == wildcard*/
	opStatic = 1,			/*does not need any profile data*/
	opStandardProfileGuided = 2,	/*only needs sampled profile data*/
	opCustomProfileGuided = 4,	/*needs custom instrumented profile data*/
} OptimizationNeededProfileData;

typedef enum {
	/*0 == wildcard*/
	oiStandard = 1,		/*operates on standard IR form*/
	oiSSA = 2		/*needs calculated SSA IR form*/
	/*room for additional IR formats*/
} OptimizationIR;



/*                    === OptimizationDescriptor ===
 *
 * Each optimization object has to supply some description so that the Manager can
 * hint the Optimizer in what optimizations shall be considered to be applied at a
 * time.
 *
 * The Optimization Descriptor is a quadruple (A,B,C,D) set of integers where A
 * denotes what to optimize for, B denots a complexity class of optimization, C
 * describes the data necessary for applying optimization and D specifies the IR
 * representation the Optimization operates on.
 *
 * "(Speed,Cheap,Static,*)" would be a valid optimization descriptor, and hint the
 * optimizer to look for quick, cheap optimizations that improve on program
 * performance.
 * Note that wildcards are possible for B and C: The Optimizer will pick the most
 * promising.
 * Another possibility would be "(Speed,Cheap,Static|SPG,*)" which would hint the
 * optimizer to pick the best cheap optimizations that even take sample profiling
 * data into account.
 * If mono runs some long running application (e.g. server applications), the
 * Manager might pass (Speed,Expensive,SPG) to the optimizer and explicitely ask for
 * expensive optimizations that do not need custom profiles.
 * In case the given application has some re-occuring intervals of low-load (and the
 * Manager knows this via phase change analysis), it might issue (Speed,Expensive,CPG)
 * to gain every speedup possible.
 * */

typedef struct OptimizationDescriptor OptimizationDescriptor;
typedef OptimizationDescriptor *POptimizationDescriptor;

struct OptimizationDescriptor {
	OptimizationTarget		Target;
	OptimizationComplexity		Complexity;
	OptimizationNeededProfileData	ProfileData;
	OptimizationIR			IR;
};


/*                    === ExOptimizationDescriptor ===
 * As the Optimizer, who is the 'manager' of all optimization objects needs
 * some more information about the optimizations it has to manage, the
 * Extended Optimization Descriptor is introduced.
 *
 * Every optimization object has *one* EOD.
 *
 * Upon loading an optimization object, the optimizer will assign each
 * optimization object some ID. This ID is later on used by the optimizer to
 * address a certain optimization object on some sort of command bus.
 *
 * To be able to distinguish between different Optimization Descriptors,
 * the optimization object interface is defined such that each function has a
 * parameter that indicates which of the supplied (0..N) optimization descriptors
 * is considered to be active.
 *
 * Note that the IDs can be statically assigned, if Optimization Objects are not
 * designed as loadable modules.
 * */

typedef struct _ExtendedOptimizationDescriptor ExOptimizationDescriptor;
typedef ExOptimizationDescriptor *PExOptimizationDescriptor;

struct _ExtendedOptimizationDescriptor {
	char	*Name;		/*Format: <InitialAuthor>.<CustomName>*/
	gint32	Version;	/*Initial value: 1*/
	gint32	Patchlevel;	/*Initial value: 1*/
	PExOptimizationDescriptor	(*ppDependencies)[];	/*array of extended opt. descr. (1)*/
	PExOptimizationDescriptor	(*ppConflicting)[];	/* -"- */
	POptimizationDescriptor		(*ppDescriptors)[];	/*array of opt. descr.*/
	gint16	OptimizationID; /*ID*/
};
/*(1) patchlevel of 0 means don't care; Last PExOptimizationDescriptor has to be NULL!*/


/*                          === OptimizationInterface ===
 *
 * Common interface of optimization modules: Defines entry points to all functions / methods
 * that an Optimization-Module (Object) must implement. Filling this struct with NULLs is not
 * allowed. For exceptions see comments.
 * */

typedef gint32 (*PMonoOptimization_EstimateSpeedupFast)	(gint32 OId, gint32 DId, PCofMethodDataEntry Data);
typedef gpointer (*PMonoOptimization_OptimizeAndCompile)(gint32 OId, gint32 DId, PCofMethodDataEntry Data, gint32* speedup);


typedef struct {
	PExOptimizationDescriptor		pDescriptor;		/*Needed; NULL not allowed*/
	PMonoOptimization_EstimateSpeedupFast	pEstimateSpeedupFast;	/*Needed; NULL not allowed*/
	PMonoOptimization_OptimizeAndCompile	pOptimizeAndCompile;	/*Needed; NULL not allowed*/
} OptimizationInterface, *POptimizationInterface;


/*                          === Static Optimization IDs ===
 *
 * Each Optimization Module gets some ID assigned. In the static - link - case the IDs are not
 * changeable and fixed.
 * Dynamically loaded Optimization modules have IDs higher than MONO_LAST_STATIC_OPTIMIZATION_ID.
 * */

#define MONO_NULLOPTIMIZATION_ID 0
#define MONO_STANDARDOPTIMIZATION_ID 1
#define MONO_LAST_STATIC_OPTIMIZATION_ID MONO_STANDARDOPTIMIZATION_ID


/*                        === NullOptimization's Interface ===
 *
 * Entrypoint to NullOptimization's Interface structure.
 * */

extern OptimizationInterface NullOptimization;

#endif /*MOPTIMIZATION_H_*/
