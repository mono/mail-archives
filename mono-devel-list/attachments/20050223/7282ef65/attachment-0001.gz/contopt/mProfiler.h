/*this header gets included ONLY from mDataboard.h*/
#include "mDataboard.h"

#ifndef MPROFILER_H_
#define MPROFILER_H_ 1

#include <glib/gprintf.h>
#include "mono/io-layer/wapi.h"
#include "mono/io-layer/atomic.h"
#include "mono/io-layer/mono-mutex.h"
#include <pthread.h>

#ifdef MPROFILER_INLINE_
#	define INLINE
#endif
#include <mInline.h>

/*               === Profiler Interface ===
 *
 * If disabled, no PGOs are possible. If enabled, a sampling profiler will run.
 * Further, custom, profile-objects are enabled on a method by method basis by the
 * Optimizer.
 *
 * Notes:
 * ~~~~~~
 * The Sampling Profiler ('SAM') offers you TopWeighters and TopClimbers. You may
 * not access the GlobalHitList from outside the SAM-thread. (=> HitList access is
 * NOT threadsafe!)
 * => Access to ProfileTopWeighters: After SAM has toggled Aged flag. Not 100%
 *	threadsafe; (TODO: Concurrent access could be possible; IOW access when SAM
 *	 ages the data.. MUTEX should work)
 * => Access to ProfileTopClimb [Aged] not 100% threadsafe. see above.
 * => Access to ProfileTopClimb [~Aged] forbidden.
 *
 * Notes about GlobalHitList:
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~
 * 	Is a datastructure that contains references to the hottest methods. Scope is
 *	global, so all threads add to the same HitList.
 *	The HitList supports following operations:
 *		(1) INSERT (List,Elem) in O(1)
 *		(2) DELETE (List,Elem) in O(1)
 *		(3) INCWEIGHT (List,Elem) in O(1)
 *		(4) AGE (List,Elem) in O(m) where m is the number of entries to retire.
 *	The current implementation supports weights up to 2^16-1 and aging by dividing the
 *	weight by two.
 *	Internally the datastructure is organized as follows:
 *		a.) The HitList is an array. Each entry is called 'bucket'. There are 16
 *		    buckets supported by the initial implementation. (0..15)
 *		b.) Each bucket's value is a pointer to a GArray. This GArray contains all
 *		    SAM-entries (pointers to MonoJitInfo structure) which have a ld(weight)
 *		    equal to the bucket index. (IOW: bucket 1 stores all samples
 *		    with ld(weight) == 1; which would include weights 2 and 3)
 *		c.) Aging is done by a round-robin system where each bucket index gets
 *		    incremented by one, divided by SAM_BUCKET_COUNT and the modulo is
 *		    then taken as new bucket index value. (Actually it's done by an offset..)
 *		    Before the index numbers are changed, all entries in bucket 0 are retired:
 *		    All elements of the GArray of bucket 0 are removed from the array.
 *		d.) Incrementing the weight is done as follows:
 *		     -) First, the element's weight is corrected (==aged==shifted).
 *		     -) Second, the element's corrected weight is incremented by X.
 *		     -) Third, ld(weight) is compared to the bucket index.
 *		     -) Forth, the element is moved into the next higher bucket, when necessary.
 *		     Note: It is assumed that one increment operation can only move the element
 *		     into the next higher bucket.
 *		e.) Inserting values for the first time is done by comparing the ld(weight) to
 *		    bucket indices (bsr might help). Upon a match, the element is added to the
 *		    GArray.
 *		f.) An element is deleted by calling the fast delete function of GArray plus
 *		    updating some internal element data. (Therefore the O(m) for aging)
 *
 *	Important properties of the HitList:
 *		I   Elements are not ordered.
 *		II  A maximum of 0xffff elements may be stored in the HitList
 *		III Only elements with a weight greater than or equal to 8 will be added to the list:
 *			- Bucket 0: retirement stage					w(eight)    1
 *			- Bucket 1: 'Not hot anymore'.					w     2-    3
 *			- Bucket 2: Standard in, but one generation aged;		w     4-    7
 *			- Bucket 3: ---> Entry level into the bucket list		w     8-   15
 *			- Bucket 4: hot functions					w    16-   31
 *			- Bucket 5: hot functions, lots of threads or highresProf	w    32-   63
 *			- Bucket 6: 							w    64-  127
 *			- Bucket 7:							w   128-  255
 *			- Bucket 8:							w   256-  511
 *			- Bucket 9:							w   512- 1023
 *			- Bucket 10:							w  1024- 2047
 *			- Bucket 11:							w  2048- 4095
 *			- Bucket 12:							w  4096- 8191
 *			- Bucket 13:							w  8192-16383
 *			- Bucket 14:							w 16384-32767
 *			- Bucket 15:							w 32768-65535
 *		IV  Depending on the number of threads, the chosen profiler and other circumstances,
 *		    the HitList might by filled differently.
 * */


typedef enum {profOff = 0, profOn = 1} ProfilerMode;
typedef struct _ProfilerDataboardInterface {
	guint64		LostSamples;
	guint32		SamplingThreadId;	/* Sampling Thread ID */
	guint32		SampleDelay;
	guint16		CurrentGeneration;	/* current generation */
	guint16		HitListEntries;		/* at abs. max 0xFFFF entries.. */
	guint16		Version;
	guint16		IncreaseBufferLen;

	ProfilerMode	Mode;			/* On/Off (set e.g. by static predictor) */
	ProfilerMode	SamMode;		/* On/Off (set by user via command line) */
	unsigned char	Lock;			/*1..X locked; 0.. access to arrays below poss.*/
	unsigned char	HitListOffset:7;	/* 0 to 15 in this impl. */
	unsigned char	Shutdown:1;		/* Shut down threads */
	unsigned char	Aged:1;			/* toggles 0 <-> 1; used to determine the Climb[]*/
	unsigned char	AgeCount:7;		/* incr. on each toggle; overflows */
	pthread_mutex_t sam_mutex;
	pthread_cond_t  sam_newgeneration_cv;
	pthread_cond_t	sam_newdata_cv;

	gpointer	pSamplingThread;	/* Sampling Thread Handle */
	GArray		*pGlobalHitList [SAM_BUCKET_COUNT];

	/*Top-weighters of current generation; NOT sorted; May miss the real top weight!*/
	WeightedSample	ProfileTopWeight [DYNAMIC_PREDICTOR_CHUNK_SIZE];
	/*Top-bucket-increments of current generation; Favours low-weighters.. ~ HEAP*/
	WeightedSample	ProfileTopClimb [2] [DYNAMIC_PREDICTOR_CHUNK_SIZE];
} ProfilerDataboardInterface, *PProfilerDataboardInterface;

/**/
#include "mSamplingProfiler.h"

INLINE void Profiler_Init(PDataboardInterface pDataboard);
INLINE void Profiler_ConfigureSystem(PDataboardInterface pDataboard);
INLINE void Profiler_Start(PDataboardInterface pDataboard);
INLINE void Profiler_Stop(PDataboardInterface pDataboard);
INLINE void Profiler_Free(PDataboardInterface pDataboard);




/* ---------------- implementation of inline stuff ----------------- */
/*called before databoard is set up*/
INLINE void
Profiler_Init(PDataboardInterface pDataboard)
{
	pDataboard->pProfilerData = (PProfilerDataboardInterface) pDataboard->TotalModuleMemory;
	pDataboard->TotalModuleMemory += sizeof(ProfilerDataboardInterface);
	/*load sub modules - until now we've only static ones*/
	/*TODO*/
}

/*called after databoard was set up and initialized. Before system starts.*/
INLINE void
Profiler_ConfigureSystem(PDataboardInterface pDataboard)
{
	int i;
	for (i=0; i < SAM_BUCKET_COUNT; i++)
		pDataboard->pProfilerData->pGlobalHitList [i] = g_array_new (FALSE, FALSE,
			 sizeof (MonoJitInfo*));
}

/*called after all was setup and configured.*/
INLINE void
Profiler_Start(PDataboardInterface pDataboard)
{
	pDataboard->pProfilerData->Shutdown = 0;
	pDataboard->pProfilerData->SampleDelay = 0; /*do a yield*/
	/*create mutex and cond var*/
	mono_mutex_init (&pDataboard->pProfilerData->sam_mutex, NULL);
	mono_cond_init (&pDataboard->pProfilerData->sam_newgeneration_cv, NULL);
#ifdef SAM_USE_CONDITION_ON_SAMPLES
	mono_cond_init (&pDataboard->pProfilerData->sam_newdata_cv, NULL);
#endif
	/*if profiling enabled:*/
	if (pDataboard->pProfilerData->SamMode == profOn)
	{
		/*create sampling thread*/
		gpointer param = pDataboard;
		pDataboard->pProfilerData->pSamplingThread = CreateThread (NULL,
			     0, & SamplingProfiler_ThreadMain,  param, CREATE_SUSPENDED,
			     &pDataboard->pProfilerData->SamplingThreadId);

		if (! pDataboard->pProfilerData->pSamplingThread)
		{
			g_printf("COF: Sampling Profiler Thread could not be created.\n Aborting.");
			exit(1);
		}
		/*start sampling thread*/
		/*g_printf("COF: Starting SAM\n");*/
		ResumeThread(pDataboard->pProfilerData->pSamplingThread);
	}
}


INLINE void
Profiler_Stop(PDataboardInterface pDataboard)
{
	pDataboard->pProfilerData->Shutdown = 1;
#ifdef SAM_USE_CONDITION_ON_SAMPLES
	mono_cond_signal (&pDataboard->pProfilerData->sam_newdata_cv);
#endif
}


INLINE void
Profiler_Free(PDataboardInterface pDataboard)
{
	/* free mutex and cond. var*/
	mono_mutex_destroy (&pDataboard->pProfilerData->sam_mutex);
	pthread_cond_destroy (&pDataboard->pProfilerData->sam_newgeneration_cv);
#ifdef SAM_USE_CONDITION_ON_SAMPLES
	pthread_cond_destroy (&pDataboard->pProfilerData->sam_newdata_cv);
#endif
	/*free up the ThreadList in a way that allows SAM to run at the same time*/
	PThreadListEntry thread = (PThreadListEntry) InterlockedExchangePointer(
		(gpointer)&pDataboard->pLastThreadEntry, NULL);
	while(thread)
	{
		PThreadListEntry next = thread->PrevEntry;
		/*g_printf("COF: SAM freed thread %li\n",(long int)thread->ThreadId);*/
		g_free(thread);
		thread = next;
	}
	/*free HitList*/
	int i;
	for (i=0; i < SAM_BUCKET_COUNT; i++)
		g_array_free (pDataboard->pProfilerData->pGlobalHitList [i], TRUE);
}

#undef INLINE
#endif /* MPROFILER_H_*/
