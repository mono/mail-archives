#ifndef MDATABOARD_H_
#define MDATABOARD_H_ 1

/*
  This header is somewhat special, as it pulls in several other COF headers:
	mDynamicPredictor.h
	mPicker.h
	mProfiler.h
	mStaticPredictor.h
  Note, if you #include one of the headers above, you are implicitely including
  this header.
*/


#include "intps.h"
#include <pthread.h>
#include "mini.h"

struct _DataboardInterface;
struct _StaticPredictorDataboardInterface;
struct _DynamicPredictorDataboardInterface;
struct _PickerDataboardInterface;
struct _ProfilerDataboardInterface;
struct _OptimizerMethodData;
typedef struct _DataboardInterface DataboardInterface, *PDataboardInterface;

#ifdef MDATABOARD_INLINE_
#	define INLINE
#endif
#include <mInline.h>

/*               === Databoard Interface ===
 * The Databoard (some sort of blackboard thing) is used by the COF as the public
 * interface for profile data access, configuration utility, ..: IOW: This is the
 * 'database' behind COF.
 * */

typedef void (*PDataboard_Init)(PDataboardInterface pSelf);
typedef void (*PDataboard_Free)(PDataboardInterface pSelf);

/* DEFINITIONS: USED TO TUNE COF */
#define MAX_SAMPLES_PER_THREAD 1024		/*(SAM) buffer where ip gets written to; 16 bits! */
#define MAX_SAMPLES_PER_THREAD_MASK 0x3ff	/*(SAM) mask for 'anding' */
#define MIN_SAMPLES_PER_THREAD_TO_PROCESS (3 * MAX_SAMPLES_PER_THREAD / 4) /*(SAM) trigger read*/
#define SAM_BUCKET_COUNT 16			/*(SAM) DO NOT CHANGE as weight is a guint16*/
#define SAM_HITLIST_ENTRY_WEIGHT 4		/*(SAM) Minimum weight to enter GlobalHitList*/
#define SAM_GENERATION_DELAY 2			/*(SAM) 2^x calls to updatesamples before aging*/
#define DYNAMIC_PREDICTOR_THRESHOLD 500		/*(PRE) 0...1000 */
#define DYNAMIC_PREDICTOR_CHUNK_SIZE 10		/*(PRE) Top X Hits + Top X Climber */
#define DYNAMIC_PREDICTOR_PROFILE_DATA_SIZE (8*DYNAMIC_PREDICTOR_CHUNK_SIZE) /*(PRE) History size*/
#define DYNAMIC_PREDICTOR_QUEUE_SIZE (DYNAMIC_PREDICTOR_CHUNK_SIZE + 1) /* (PRE) QUEUE size for picker */
#define PO_MINIMUM_SPEEDUP_CHEAP 1			/*(P/O) minimum speedup on cheap optimizatios*/
#define PO_MINIMUM_SPEEDUP_AVERAGE 1			/*(P/O) minimum speedup on average optimizatios*/
#define PO_MINIMUM_SPEEDUP 0				/*(P/O) minimum speedup to consider an optimization*/


#define SAM_USE_CONDITION_ON_SAMPLES		/*Use condition variable triggered in sighandler*/
#define _SAM_TRY_FETCH_JIT_INFO_FAST		/*DISABLED: This is bleeding edge..*/

struct _ThreadListEntry {
	pthread_t		ThreadId;
	struct _ThreadListEntry	*PrevEntry;
	MonoDomain		*Domain;
	gpointer		pDataboard;
	guint32			NewSignals;
	guint32			TotalSignals;
	guint16			CurrentSample;
	guint16			StartingSample;

	unsigned char		DoSampling:1;	   /*1.. take samples of this thread*/
	unsigned char		DoRemove:1;	   /*1.. remove thread from queue*/
	unsigned char		HighResSampling:1; /* indicates usage of RTC or itimer */
	unsigned char		ReportIp:1;	   /*1.. report patcher current IP*/
	unsigned char		Byte1;
	guint16			Skip;
	/* fast cache */
	intptr_t		ReportedIp;
	intptr_t		Samples[MAX_SAMPLES_PER_THREAD];
} ;
typedef struct _ThreadListEntry *PThreadListEntry;


struct _WeightedSample {
	MonoJitInfo	*pJitInfo;
	guint16		Weight;		/*Weight of last generation*/
	guint16		Calls;		/*Calls in current generation*/
	unsigned char	IsProfileTopHit :1;
	unsigned char	IsProfileTopClimb :1;
};
typedef struct _WeightedSample WeightedSample, *PWeightedSample;


struct _DynamicPredictorPhase {
	guint start;
	guint end;
};
typedef struct _DynamicPredictorPhase DynamicPredictorPhase, *PDynamicPredictorPhase;

/*
 * All ContinuousMethodData structs get stored in the pMethodData binary tree sorted by
 * the MonoJitInfo pointers.
 * When added to the global hitlist the entry is made; When deleted from hitlist and no
 * queue flag is set (and not cof_keep_data), the entry is deleted again. Else the
 * optimizer/picker is responsible for this entry. (Has to check the hitlist queues flag
 * if it do not want to keep the entry.. If not set, then the entry has to be freed.)
 */

extern guint16		OptimizationBitmapSize;  /*initialized by Optimizer..*/
extern guint16		(*OptimizationObjectOffset)[]; /*initialized by Optimizer..*/

/*Use the macros below to manipulate the AppliedOptimizationsBitmap in CofMethodDataEntry
  structure.*/
#define CofMethodDataEntryGetBit(x, nr) (((x)->AppliedOptimizationsBitmap [nr / 8] >> (nr % 8)) & 0x1)

#define CofMethodDataEntrySetBit(x, nr, in) \
	do { \
		unsigned char val = (in) & 0x1; \
		unsigned char mask = 0x1;\
		mask = mask << (nr % 8);\
		val = val << (nr % 8); \
		(x)->AppliedOptimizationsBitmap [nr / 8] &= ~mask;\
		(x)->AppliedOptimizationsBitmap [nr / 8] |= val; \
	} while (0);

typedef struct {
	MonoJitInfo	*pJitInfo;
	MonoDomain	*pDomain; /* currently only one supported... Is this a FIXME?*/
	/*code patching support*/
	gpointer	OldCodeStart;
	guint32		OldCodeSize;
	guint16		OldRefCount;
	/**/
	guint16		ConsideredOptimization_ID;	/* next optimization considered */
	guint16		ConsideredOptimization_Hint;
	gint16		ConsideredSpeedup;		/* speedup estimated by next optim.*/
	/* == data from optimizer == */
	unsigned char	MonitorQueued:1; /* Already queued for re-optimization */
	unsigned char	OptimizationAttempts:7; /*max OptimizerData entries..*/
	unsigned char	PatchInformation;
	unsigned char	AppliedOptimizationsBitmap [MONO_ZERO_LEN_ARRAY];
} CofMethodDataEntry, *PCofMethodDataEntry;

#define Databoard_Lock(x) EnterCriticalSection (&((x)->TreeLock));
#define Databoard_Unlock(x) LeaveCriticalSection (&((x)->TreeLock));

/*ATTENTION: If you change the struct below, also change the initializer in
             mDataboard.c!!! */
struct _DataboardInterface {
	PDataboard_Init	Init;			/*Init - allocate Mem*/
	PDataboard_Free	Free;			/*Free - free mem*/
	/*---*/
	void		*ModuleMemory;
	struct _StaticPredictorDataboardInterface  *pStaticPredictorData; /*Pointer to StaticPred. Conf Data*/
	struct _DynamicPredictorDataboardInterface *pDynamicPredictorData;/*Ptr to DynamicPred. Config Data*/
	struct _PickerDataboardInterface	   *pPickerData;	  /*Ptr to Picker Conf Data*/
	struct _ProfilerDataboardInterface	   *pProfilerData;	  /*Ptr to Profiler Conf Data*/
	/*---*/
	PThreadListEntry pLastThreadEntry;				  /*stack of threads*/
	/*---*/
	CRITICAL_SECTION    			   TreeLock;		  /*protects tree: Multi-read exclusive
									    write would be better! */
	GTree					   *pMethodData;	  /*Data from methods as long
									    as they are in the Hitlist
									    of another queue */
	/*---*/
	uintptr_t				    TotalModuleMemory;	  /*Modul Memory allocated*/
};

extern PDataboardInterface pGlobalDataboard;


typedef gpointer (*MonoRecompileMethod) (MonoJitInfo *methodInfo, MonoDomain *domain, guint32 *opt);
extern gpointer cof_mono_install_recompile_compile_method (MonoRecompileMethod func);


#undef INLINE
/*pull in dependand headers: Order important!*/
#include "mProfiler.h"
#include "mDynamicPredictor.h"
#include "mPicker.h"
#include "mStaticPredictor.h" /*needs to be last!*/

#endif /* MDATABOARD_H_*/
