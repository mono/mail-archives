
#define MDATABOARD_INLINE_
#include "mDataboard.h"
#include "glib.h"
#include "intps.h"

void Databoard_Init(PDataboardInterface pSelf);
void Databoard_Free(PDataboardInterface pSelf);

DataboardInterface GlobalDataboard = {
	&Databoard_Init,
	&Databoard_Free,
	/*---*/
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	/*---*/
	{0},
	NULL,
	/*---*/
	0
};

PDataboardInterface pGlobalDataboard = &GlobalDataboard;


gint Databoard_TreeCompare (gconstpointer a, gconstpointer b)
{
	return (uintptr_t) a - (uintptr_t) b;
}

void
Databoard_Init(PDataboardInterface pSelf)
{
	/*Important: Initialize Databoard last!*/
	pSelf->ModuleMemory = g_malloc0(pSelf->TotalModuleMemory);
	pSelf->pStaticPredictorData = pSelf->ModuleMemory + (uintptr_t) pSelf->pStaticPredictorData;
	pSelf->pDynamicPredictorData = pSelf->ModuleMemory + (uintptr_t) pSelf->pDynamicPredictorData;
	pSelf->pPickerData = pSelf->ModuleMemory + (uintptr_t) pSelf->pPickerData;
	pSelf->pProfilerData = pSelf->ModuleMemory + (uintptr_t) pSelf->pProfilerData;
	InitializeCriticalSection (& (pSelf->TreeLock));
	pSelf->pMethodData = g_tree_new (&Databoard_TreeCompare);
}

gint
Databoard_FreeCofMethod_cb (gpointer key, gpointer value, gpointer data)
{
	PCofMethodDataEntry pEntry = (PCofMethodDataEntry) value;
	g_free (pEntry);
	return FALSE;
}

void
Databoard_Free(PDataboardInterface pSelf)
{
/**/	Databoard_Lock (pSelf);
/**/	g_tree_traverse (pSelf->pMethodData, &Databoard_FreeCofMethod_cb, G_POST_ORDER, NULL);
/**/	g_tree_destroy (pSelf->pMethodData);
/**/	pSelf->pMethodData = NULL;
/**/	Databoard_Unlock (pSelf);
	DeleteCriticalSection (& (pSelf->TreeLock));
	g_free (pSelf->ModuleMemory);
}


