#include "mDataboard.h"

#ifndef MSAMPLINGPROFILER_H_
#define MSAMPLINGPROFILER_H_
#include "mini.h"
#include "glib.h"
#include "mono/utils/mono-codeman.h"
#include "signal.h"

/* Macros for dividing by two: Rounding for values > 1; truncating for values < 2 */
#define DIV2ROUND(x) (x) = (x) & 0x3 ? ((x) >> 1) + 1 : (x) >> 1
#define DIV2ROUND_NOT_ASSIGN(x) ((x) & 0x3 ? ((x) >> 1) + 1 : (x) >> 1)

/* threadsafe */
	void cof_sigprof_signal_handler (guchar *ip, void *context);
INLINE	gpointer cof_AddThread (PDataboardInterface pDataboard, gboolean HighResProfiler);
INLINE	void cof_RemoveThread (PThreadListEntry pThreadEntry);

/* thread */
	guint32 SamplingProfiler_ThreadMain (gpointer Arg);

/* called by signal handler */
INLINE	void cof_sigprof_signal_handler (guchar *ip, void *context);


/* NOT threadsafe: only called by SAM-Thread */
	void SamplingProfiler_WriteThreadSamples (PThreadListEntry thread);
	void SamplingProfiler_WriteAllThreadSamples (PDataboardInterface pDataboard);
	void SamplingProfiler_WriteHitList (PDataboardInterface pDataboard);
	int  FilterManaged (void *data, int csize, int size, void *user_data);


INLINE 	void SamplingProfiler_AddToHitList (PDataboardInterface pDataboard, MonoJitInfo *pEntry, MonoDomain *pDomain);
INLINE 	void SamplingProfiler_AgeHitList  (PDataboardInterface pDataboard);
INLINE 	void SamplingProfiler_UpdateClimbList (PDataboardInterface pDataboard, MonoJitInfo *pEntry);
INLINE 	void SamplingProfiler_UpdateHitListEntry (PDataboardInterface pDataboard, MonoJitInfo *pEntry, guint16 incr);
INLINE	void SamplingProfiler_RemoveFromHitList (PDataboardInterface pDataboard, MonoJitInfo *pEntry);


/* ---------------- implementation of inline stuff ----------------- */
INLINE void
SamplingProfiler_AddToHitList (PDataboardInterface pDataboard, MonoJitInfo *pEntry,
			       MonoDomain *pDomain)
{
	PProfilerDataboardInterface pProfiler = pDataboard->pProfilerData;
	if ((pEntry->cof_sam_weight > 1) && (pProfiler->HitListEntries < 0xffff))
	{
		int i;
		PCofMethodDataEntry pMethodData;

		/* calc ld(weight); could do a better search.. */
		for (i = SAM_BUCKET_COUNT - 1; i >= 0; i--)
			if ((pEntry->cof_sam_weight >> 1) & (((guint32) 1) << i))
				break;

		/* calc current bucket with that value */
		i = (i + pProfiler->HitListOffset) % SAM_BUCKET_COUNT;
		pEntry->cof_hitlist_queued = 1;
		pEntry->cof_hitlist_bucket_increase = 1;
		pEntry->cof_hitlist_bucket = i;
		pEntry->cof_sam_LTU = 0;			/*this is our call counter now*/
		pEntry->cof_sam_weight = (guint16) 1 << i; 	/*start with minimal weight*/
		pEntry->cof_hitlist_ltu_offset = pProfiler->HitListOffset;
		pEntry->cof_hitlist_index = pProfiler->pGlobalHitList [i]-> len;
		pProfiler->pGlobalHitList [i] = g_array_append_val (pProfiler->pGlobalHitList [i],
			 pEntry);
		pProfiler->HitListEntries++;
		/*now add to tree FIXME: SYNCHRONIZE?!*/
/**/		Databoard_Lock (pDataboard);
/**/		if ( ! g_tree_lookup (pDataboard->pMethodData, pEntry)) {
/**/			pMethodData = (PCofMethodDataEntry) g_malloc0 (sizeof (CofMethodDataEntry)
/**/				+ OptimizationBitmapSize);
/**/			pMethodData->pDomain = pDomain;
/**/			pMethodData->pJitInfo = pEntry;
/**/			g_tree_insert (pDataboard->pMethodData, pEntry, pMethodData);
/**/		}
/**/		Databoard_Unlock (pDataboard);
	}
}

/* removes an entry from hitlist - not really threadsafe. (But IMO close *g*)
   only used for dynamic methods, so consider not to queue them in hitlist..
 */
INLINE void
SamplingProfiler_RemoveFromHitList (PDataboardInterface pDataboard, MonoJitInfo *pEntry)
{
	if (pEntry && pEntry->cof_hitlist_queued) {
		PProfilerDataboardInterface pProfiler = pDataboard->pProfilerData;
		/*FIXME: LOCKING??*/
		pEntry->cof_sam_ignore = 1;
		pEntry->cof_hitlist_queued = 0;
		/* remove from current bucket */
		int bucketIndex = pEntry->cof_hitlist_bucket;
		int arrayIndex = pEntry->cof_hitlist_index;

		pProfiler->pGlobalHitList [bucketIndex] =
			g_array_remove_index_fast (pProfiler->pGlobalHitList [bucketIndex],
				pEntry->cof_hitlist_index);

		GArray *pBucket = pProfiler->pGlobalHitList [bucketIndex];
		if (pBucket->len > arrayIndex) {
			MonoJitInfo *pMovedEntry;

			pMovedEntry = (MonoJitInfo*) g_array_index (pBucket, uintptr_t, arrayIndex);

			pMovedEntry->cof_hitlist_index = arrayIndex;
		}
		pEntry->cof_hitlist_bucket_increase = 0;
		pEntry->cof_hitlist_bucket = 0;
		pEntry->cof_hitlist_ltu_offset = 0;
		pEntry->cof_hitlist_index = 0;
		pEntry->cof_sam_weight = 0;
		pEntry->cof_sam_LTU = pDataboard->pProfilerData->CurrentGeneration - 15;
	}
}


INLINE void
SamplingProfiler_AgeHitList  (PDataboardInterface pDataboard)
{
	PProfilerDataboardInterface pProfiler = pDataboard->pProfilerData;
	GArray *pRetireArray = pProfiler->pGlobalHitList [pProfiler->HitListOffset];

	/*g_print ("COF: SAM retiring %i entries\n", pRetireArray->len);*/
	int i;

	if (pRetireArray->len >0) {
/**/		Databoard_Lock (pDataboard);
/**/		for (i = 0; i < pRetireArray->len; i++)
/**/		{
/**/			PCofMethodDataEntry pData;
/**/			MonoJitInfo *pRetireEntry;
/**/			pRetireEntry = (MonoJitInfo*) g_array_index (pRetireArray, uintptr_t, i);
/**/			pRetireEntry->cof_hitlist_queued = 0;
/**/			/*See if we have to remove data*/
/**/			pData = (PCofMethodDataEntry) g_tree_lookup (pDataboard->pMethodData,
/**/				 pRetireEntry);
/**/			if (pData) {
/**/				if (! (pRetireEntry->cof_picker_queued
/**/				      || pRetireEntry->cof_optimizer_queued
/**/				      || pRetireEntry->cof_keep_data)) {
/**/					g_tree_remove (pDataboard->pMethodData, pRetireEntry);
/**/					g_free (pData);
/**/				}
/**/			}
/**/			pRetireEntry->cof_hitlist_bucket_increase = 0;
/**/			pRetireEntry->cof_hitlist_bucket = 0;
/**/			pRetireEntry->cof_hitlist_ltu_offset = 0;
/**/			pRetireEntry->cof_hitlist_index = 0;
/**/			pRetireEntry->cof_sam_weight = 0;
/**/			pRetireEntry->cof_sam_LTU = pDataboard->pProfilerData->CurrentGeneration - 15;
/**/		}
/**/		Databoard_Unlock (pDataboard);
		pProfiler->HitListEntries = pProfiler->HitListEntries - pRetireArray->len;
		g_array_free (pRetireArray, TRUE);
		pProfiler->pGlobalHitList [pProfiler->HitListOffset] = g_array_new (FALSE, FALSE,
			sizeof (MonoJitInfo*));
	}
	pProfiler->HitListOffset = (pProfiler->HitListOffset + 1) % SAM_BUCKET_COUNT;
}

#define DAD(i) (i - 1)
#define WEIGHT(e) (e.pJitInfo->cof_hitlist_bucket_increase)
#define ARRAY(a,i) (pProfiler->ProfileTopClimb [a] [i])
#define SWAP(a,x,y) \
	do { \
		WeightedSample tmp = ARRAY(a,x);\
		ARRAY(a,x) = ARRAY(a,y);\
		ARRAY(a,y) = tmp;\
	} while (0);
INLINE void
SamplingProfiler_UpdateClimbList (PDataboardInterface pDataboard, MonoJitInfo *pEntry)
{
	PProfilerDataboardInterface pProfiler = pDataboard->pProfilerData;
	int updateList = pProfiler->Aged ? 0 : 1; /*'not'*/
	int N = pProfiler->IncreaseBufferLen;
	guint16 incr = pEntry->cof_hitlist_bucket_increase;

	/*!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	  !!
	  !! FIXME: redo this - need a better algo..
	  !!
	  !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!*/

	MonoJitInfo *pReplaceElem = ARRAY (updateList,N).pJitInfo;


	if (pReplaceElem && pReplaceElem->cof_hitlist_bucket_increase >= incr)
		return; /* only replace if has some minimum size */

	int a;
	gboolean notInc = 0;
	int i = N;
	for (a = 0; a < DYNAMIC_PREDICTOR_CHUNK_SIZE; a++) {
		if (pEntry == ARRAY (updateList, a).pJitInfo) {
			i = a;
			pProfiler->ProfileTopClimb [updateList] [a].Calls = pEntry->cof_sam_LTU;
			pProfiler->ProfileTopClimb [updateList] [a].Weight = pEntry->cof_sam_weight;
			notInc = 1;
			break;
		}
	}
	if (i == N) {
		pProfiler->ProfileTopClimb [updateList] [N].pJitInfo = pEntry;
		pProfiler->ProfileTopClimb [updateList] [N].Calls = pEntry->cof_sam_LTU;
		pProfiler->ProfileTopClimb [updateList] [N].Weight = pEntry->cof_sam_weight;
		pProfiler->ProfileTopClimb [updateList] [N].IsProfileTopClimb = 1;
	}
	while (i >= 1 && WEIGHT (ARRAY (updateList,i)) > WEIGHT (ARRAY (updateList, DAD (i)))) {
		SWAP (updateList, i, DAD (i));
		i = DAD (i);
	}

	if ((notInc == 0) && ((N + 1) < (DYNAMIC_PREDICTOR_CHUNK_SIZE)))
		pProfiler->IncreaseBufferLen++;
}
#undef DAD
#undef WEIGHT
#undef ARRAY
#undef SWAP

/* Updates an entry in the hitlist; called by Sampling profiler thread. */
INLINE void
SamplingProfiler_UpdateHitListEntry (PDataboardInterface pDataboard, MonoJitInfo *pEntry, guint16 incr)
{
	if (!pEntry->cof_hitlist_queued) return;

	PProfilerDataboardInterface pProfiler = pDataboard->pProfilerData;

	if (pProfiler->HitListOffset != pEntry->cof_hitlist_ltu_offset) {
		unsigned char generations;
		generations = (pProfiler->HitListOffset - pEntry->cof_hitlist_ltu_offset) & 0xf;
		DIV2ROUND (pEntry->cof_sam_weight);
		DIV2ROUND (pEntry->cof_sam_LTU);
		pEntry->cof_sam_weight += pEntry->cof_sam_LTU & 0x8000 ? 0x7fff : pEntry->cof_sam_LTU;
		while (generations > 1) {
			generations --;
			DIV2ROUND (pEntry->cof_sam_weight);
		}
		pEntry->cof_hitlist_ltu_offset = pProfiler->HitListOffset;
		pEntry->cof_hitlist_bucket_increase = 0;
		pEntry->cof_sam_LTU = 0;
	}

	pEntry->cof_sam_LTU += incr;	/*this is our call counter now*/


	/* Next we determine the current bucket value; This works in any case, because on element
	   addition, we've added the original bucket value to the original offset and made a modulo
	   operation to stay inside the buffer: As any element gets kicked out of the buffer after
	   16 generations without moving one bucket up, the difference of bucket number and hitlist
	   offset will always return the correct bucket value! (Of course this only works on unsigned
	   datatypes and when truncating the result to 4 bits.)
	   A further note: Once an entry is in the retirenment bucket, two calls to this function and
	   an increment of at least 3 are needed to get it one above the retirenment bucket in the
	   next generation.
	   One call with any increment greater 0 will just save it from being kicked out of the hit-
	   list when aging. The other one (with increment so weight > 3) will  move it into the bucket
	   above the retirenment level (needs weight 4 at least!).
	   This behaviour favours functions that are called from many different threads (lots of calls
	   to this function by SAM) over functions that are called by one single thread.
	*/
	guint16 bucketValue = (pEntry->cof_hitlist_bucket - pProfiler->HitListOffset) & 0xf;
	guint16 currentWeight = DIV2ROUND_NOT_ASSIGN (pEntry->cof_sam_LTU) +
				DIV2ROUND_NOT_ASSIGN (pEntry->cof_sam_weight);
	if (currentWeight >= ((guint32) 1 << (bucketValue + 1))) {
		/* never reached if cof_hitlist_bucket + 1 > 15 because currentWeight is guint16.. */

		int climb = bucketValue + 1;
		if (currentWeight >= (((guint32) 1) << (bucketValue + 2)))
			for (climb = SAM_BUCKET_COUNT - 1; climb >= (bucketValue + 1); climb--)
				if (currentWeight >= (((guint32) 1) << (climb)))
					break;

		climb = climb - bucketValue;

		/* remove from current bucket */
		int bucketIndex = pEntry->cof_hitlist_bucket;
		int arrayIndex = pEntry->cof_hitlist_index;

		pProfiler->pGlobalHitList [bucketIndex] =
			g_array_remove_index_fast (pProfiler->pGlobalHitList [bucketIndex],
				pEntry->cof_hitlist_index);

		GArray *pBucket = pProfiler->pGlobalHitList [bucketIndex];
		if (pBucket->len > arrayIndex) {
			MonoJitInfo *pMovedEntry;

			pMovedEntry = (MonoJitInfo*) g_array_index (pBucket, uintptr_t, arrayIndex);

			pMovedEntry->cof_hitlist_index = arrayIndex;
		}



		/* update the Climb-Hit-List entries*/
		pEntry->cof_hitlist_bucket_increase += (climb & 0x7);
		SamplingProfiler_UpdateClimbList (pDataboard, pEntry);

		/* add to next higher bucket */
		pEntry->cof_hitlist_bucket = (pEntry->cof_hitlist_bucket + climb) % SAM_BUCKET_COUNT;
		pEntry->cof_hitlist_index = pProfiler->pGlobalHitList [pEntry->cof_hitlist_bucket] ->len;
		pProfiler->pGlobalHitList [pEntry->cof_hitlist_bucket] =
			g_array_append_val (pProfiler->pGlobalHitList [pEntry->cof_hitlist_bucket], pEntry);

	}
}

/*Adds a thread to the Thread queue*/
INLINE gpointer
cof_AddThread (PDataboardInterface pDataboard, gboolean HighResProfiler)
{
	/*if profiling enabled:*/
	if (pDataboard->pProfilerData->SamMode == profOn)
	{
		PThreadListEntry pThreadEntry = (PThreadListEntry) g_malloc0 (sizeof (
			struct _ThreadListEntry));
		pThreadEntry->ThreadId = pthread_self ();
		pThreadEntry->Domain = mono_domain_get ();
		pThreadEntry->DoSampling = 1;				/*turn on sampling by deflt.*/
		pThreadEntry->HighResSampling = (HighResProfiler != 0); /* do we need to call kill? */
		pThreadEntry->PrevEntry = pDataboard->pLastThreadEntry;
		pThreadEntry->pDataboard = (gpointer) pDataboard;

		/*Guard against concurrent changes:*/
		while (InterlockedCompareExchangePointer ((gpointer) &pDataboard->pLastThreadEntry,
			pThreadEntry, pThreadEntry->PrevEntry) != pThreadEntry->PrevEntry)
		{
			pThreadEntry->PrevEntry = pDataboard->pLastThreadEntry;
		}

		return (pThreadEntry);
	} else {
		return (NULL);
	}
}

/* flag the thread for removal */
INLINE void
cof_RemoveThread (PThreadListEntry pThreadEntry)
{
	pThreadEntry->DoRemove = 1;
}

#ifdef SAM_TRY_FETCH_JIT_INFO_FAST
/*******************************************************************************
 *   (Faster?) way of retrieving a MonoJitInfo pointer for a given IP addr.    *
 * This version does not lock the domain, but still does 25 memory fetches, so *
 * it might not be very efficient. For virtual methods, this, however, is the  *
 * simplest way to go..                                                        *
 *                      DISABLED BY DEFAULT    AMD64 ONLY                      *
 *******************************************************************************/

INLINE MonoJitInfo*
mono_arch_get_jit_info_fast (guchar *ip)
{

/* We're searching for (AMD64)
  -8:				MonoJitInfoPointer
   0:	55                   	push   %rbp
   1:	48 8b ec             	mov    %rsp,%rbp
   where push is 8 byte aligned. */

	guint32 *scanIp = (guint32*)((uintptr_t)ip & ~0x7);
	while ((*scanIp != 0xec8b4855) && ((uintptr_t)ip-(uintptr_t)scanIp <= 64))
		scanIp = scanIp - 2;

	if (*scanIp == 0xec8b4855) {
		MonoJitInfo *info = *((MonoJitInfo**)(scanIp - 2));
		uintptr_t ptr = (uintptr_t) info;
		if ( info /*((ptr & 0x7) == ((ptr >> 3) % 8)) && info */) {
			/*info = (MonoJitInfo*) (ptr & (~0x7));*/
			if (((void*)info->code_start == (void*)scanIp) &&
			    ((guchar*)info->code_start <= ip) &&
			    ((void*)(info->code_start + info->code_size) >= (void*)ip))
				return info;
		}
	}

	return NULL;
}

extern guchar* _etext;
extern guchar* _end;

/*******************************************************************************
 *   (Faster?) way of retrieving a MonoJitInfo pointer for a given IP addr.    *
 * This version does not lock the domain, but still does lots of memory        *
 * fetches. For known mono methods (== stack frame available) this might turn  *
 * out usefully - on instance methods only. For virtual methods, some guessing *
 * would have to be done..                                                     *
 *                      DISABLED BY DEFAULT   AMD64 ONLY                       *
 *******************************************************************************/

INLINE gpointer
mono_get_method_start_addr (MonoJitTlsData *jit_tls, void *context, guchar* ip)
{
	ucontext_t *ctx = (ucontext_t*)context;

	guint64 *stackframe = (guint64*) ctx->uc_mcontext.gregs [REG_RBP];
	guint64 *stackpointer = (guint64*) ctx->uc_mcontext.gregs [REG_RSP];
	/*we need a valid stack frame..*/
	if (stackpointer >= stackframe)
		return NULL;
	if (((uintptr_t)stackpointer & 0x7) || ((uintptr_t)stackframe & 0x7))
		return NULL;
	if (!(  (stackframe < (guint64*) jit_tls->end_of_stack)
	      &&(stackframe > (guint64*) jit_tls->end_of_stack - 0x40000)))
		return NULL;
	if (!(  (stackpointer < (guint64*) jit_tls->end_of_stack)
	      &&(stackpointer > (guint64*) jit_tls->end_of_stack - 0x40000)))
		return NULL;
	guint64 *oldframe = (guint64*)*stackframe;
	if (!(  (oldframe < (guint64*) jit_tls->end_of_stack)
	      &&(oldframe > (guint64*) jit_tls->end_of_stack - 0x40000)))
		return NULL;
	/*assume we found a valid stackframe - otherwise we might get sigsegv..*/
	stackframe += 1;
	guchar *caller = (guchar*) *stackframe;
	if ((caller < (guchar*)&_end) || (caller > (guchar*)0x7fffffffff))
		return NULL;

	int backtrack = 0;
	guchar *modrm = caller;
	caller--;
	while ((*caller != 0xff) && (backtrack < 5)) {
		modrm = caller;
		backtrack++;
		caller--;
	}
	if (*caller == 0xff) {
		if ((*modrm & 0xC0) == 0xC0) {
/*non-virtual calls:
  25:	49 bb 70 d2 78 96 2a 	mov    $0x2a9678d270,%r11
  2c:	00 00 00
  2f:	49 ff d3             	callq  *%r11 */
  			caller--;
			if ((*caller != 0x49) || (*modrm != 0xd3))
				return NULL;
			guint64 func = *((guint64*)(caller - 8));
			guint32 *scanIp = (guint32*) func;
			if (*scanIp != 0xec8b4855)
				return NULL;
			MonoJitInfo *info = *(MonoJitInfo**)(func - 8);
			uintptr_t ptr = (uintptr_t) info;
			if ( /*((ptr & 0x7) == ((ptr >> 3) % 8)) && */info ) {
				/*info = (MonoJitInfo*) (ptr & (~0x7));*/
				if (((guint64)info->code_start == func) &&
				    ((guchar*)info->code_start <= ip) &&
				    ((guchar*)(info->code_start + info->code_size) >= ip)) {
					return info;
				}
			}
		} else {
/*virtual calls:
  4d:	49 8b fe             	mov    %r14,%rdi
  50:	49 8b 06             	mov    (%r14),%rax
  53:	ff 50 58             	callq  *0x58(%rax) */
			gpointer result = mono_arch_get_jit_info_fast (ip);
			return result;
		}
	}
	return NULL;
}
#endif


/*******************************************************************************
 *      Signal PROF Handler: Executed in the context of a worker-thread.       *
 * (Not the SamplingProfilerThread!) --             THIS IS SIGNALHANDLER CODE *
 *******************************************************************************/
INLINE void
cof_sigprof_signal_handler (guchar *ip, void *context)
{
/*!*/	/* keep as simple and 'fast' as possible */
/*!*/	MonoJitTlsData *jit_tls;
/*!*/
/*!*/	uintptr_t ip_addr = 0; /* (uintptr_t) ip; */
/*!*/
/*!*/	jit_tls = TlsGetValue (mono_jit_tls_id);
/*!*/	if (jit_tls && jit_tls->databoardentry) {
/*!*/		PThreadListEntry pThread = (PThreadListEntry) jit_tls->databoardentry;
/*!*/		if (pThread->ReportIp) {
/*!*/			pThread->ReportedIp = (intptr_t) ip;
/*!*/			pThread->ReportIp = 0;
/*!*/		}
/*!*/		if (pThread->DoSampling) {
/*!*/			/* we don't care about dynamic code, that has another codeman.. */
/*!*/			/*mono_code_manager_foreach (pThread->Domain->code_mp, &FilterManaged, &ip_addr);*/
/*!*/			if (!ip_addr) {
#ifdef SAM_TRY_FETCH_JIT_INFO_FAST
/*!*/				intptr_t info = (intptr_t) mono_get_method_start_addr (jit_tls,
/*!*/					 context, ip);
/*!*/				if (info) {
/*!*/					/*g_assert (!((uintptr_t)info & 0x7));*/
/*!*/					pThread->Samples [pThread->CurrentSample] = info;
/*!*/				} else {
/*!*/					intptr_t ipaddr = ((intptr_t) ip) | ((intptr_t)1 << (sizeof(void*)-1));
#endif
#ifndef SAM_TRY_FETCH_JIT_INFO_FAST
/*!*/				{
/*!*/					intptr_t ipaddr = (intptr_t) ip;
#endif
/*!*/					pThread->Samples [pThread->CurrentSample] = ipaddr;
/*!*/				}
/*!*/				/*InterlockedIncrement(&pThread->NewSignals);*/
/*!*/				pThread->NewSignals++;
/*!*/				pThread->CurrentSample = (pThread->CurrentSample + 1) %
/*!*/					MAX_SAMPLES_PER_THREAD;
#ifdef SAM_USE_CONDITION_ON_SAMPLES
/*!*/				if (pThread->NewSignals >  MIN_SAMPLES_PER_THREAD_TO_PROCESS)
/*!*/					mono_cond_signal (& ((PDataboardInterface)pThread->pDataboard)
/*!*/						->pProfilerData->sam_newdata_cv);
#endif
/*!*/			}
/*!*/		}
/*!*/	}
}

#endif /* MSAMPLINGPROFILER_H_*/
