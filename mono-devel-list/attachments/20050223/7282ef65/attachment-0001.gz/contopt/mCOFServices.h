#ifndef MCOFSERVICES_H_
#define MCOFSERVICES_H_ 1

#ifdef MCOFSERVICES_INLINE_
#	define INLINE
#endif
#include <mInline.h>

/*               === Continuous Optimization Framework (COF) Interface ===
 *
 * Use this interface for turning on/off the mono COF support.
 * */
void COF_Init (gboolean staticPred, gboolean dynamicPred, gboolean profiler);

void COF_Shutdown (void);

#undef INLINE
#endif /* MCOFSERVICES_H_*/
