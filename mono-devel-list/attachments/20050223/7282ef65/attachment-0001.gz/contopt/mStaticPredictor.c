

#define MSTATICPREDICTOR_INLINE_
#include "mStaticPredictor.h"

StaticPredictor_Data SafePrediction = {
	aptCmdTool,
	0,		/*assume runtime < 5 minutes*/
	0,		/*number of 5 minute timeslices the app typically runs*/
	0,
	50,		/*max. calls per one 5 min. timeslice*/
	5,		/**/
	5,		/*avg load in minumum area*/
	{
		{0},
		0,
		5	/*Sum of 5 (one-minute-load-avg * 10) values */
	},
	{
		{0},
		0,
		5
	}
};

