/*this header gets included ONLY from mDataboard.h*/
#include "mDataboard.h"

#ifndef MSTATICPREDICTOR_H_
#define MSTATICPREDICTOR_H_ 1

#include "glib.h"
#ifdef MSTATICPREDICTOR_INLINE_
#	define INLINE
#endif
#include <mInline.h>

/*               === Static Predictor Interface ===
 *
 * The static predictor determines the complexity level of all optimizations that
 * are being applied. (First time comp. to some lesser extend)
 * If turned off, only cheap static and cheap default profile data depandand
 * optimizations are considered by the picker.
 * If turned on, the static predictor might even turn COF off altogether! On the
 * other hand very expensive custom profile guided optimizations can be turned on
 * by enabled static predictor.
 * */

/*Application type*/
typedef enum {aptOff, aptOn, aptServer, aptNormal, aptCmdTool} ApplicationType;

typedef struct {
	GDate	Date;
	GTime	Time;
	gint32	OneMinuteTimeAvgOverTimeSlice;	/*Sum of 5 (one-minute-load-avg * 10) values */
} StaticPredictor_SystemLoad;

/*File data format*/
typedef struct {
	ApplicationType	Type;
	gint32		Mode;		/*if several mode values are available, chose the smallest*/
	gint32		MeanRuntime;	/*number of 5 minute timeslices the app typically runs*/
	gint32		MeanRuntimeVariance;
	gint32		MaximumCallsPerTimeSlice;	/*max. calls per one 5 min. timeslice*/
	gint32		AvgLoad;			/**/
	gint32		AvgMinimumLoad;				/*avg load in minumum area*/
	StaticPredictor_SystemLoad	MinimumLoadStart;	/*Timeslice with minimum load*/
	StaticPredictor_SystemLoad	MinimumLoadStop;	/*end of minimum load timesl.*/
} StaticPredictor_Data, *PStaticPredictorData;


/*StaticPredictor data file is an array of StaticPredictor_Data:*/
#define STATICPREDICTOR_DATAFILESIZE 100

typedef PStaticPredictorData StaticPredictor_DataFile [STATICPREDICTOR_DATAFILESIZE];


typedef enum {statpreOn = 0, statpreOff = 1} StaticPredictorMode; /*std == on!*/

/*Databoard interface*/
typedef struct _StaticPredictorDataboardInterface {
	guint32			InterfaceVersion;
	StaticPredictorMode	Mode;
} StaticPredictorDataboardInterface, *PStaticPredictorDataboardInterface;

/*safe prediction*/
extern StaticPredictor_Data SafePrediction;

/*init static predictor - load pref. data*/
INLINE void StaticPredictor_Init (PDataboardInterface pDataboard);

/*Write initial Configuration to databoard.*/
INLINE void StaticPredictor_ConfigureSystem (PDataboardInterface pDataboard);

INLINE void StaticPredictor_Free (PDataboardInterface pDataboard);


/* ---------------- implementation of inline stuff ----------------- */

INLINE void
StaticPredictor_Init(PDataboardInterface pDataboard)
{
	pDataboard->pStaticPredictorData =  (PStaticPredictorDataboardInterface) pDataboard->TotalModuleMemory;
	pDataboard->TotalModuleMemory = pDataboard->TotalModuleMemory + sizeof(StaticPredictorDataboardInterface);
}

INLINE void
StaticPredictor_ConfigureSystem(PDataboardInterface pDataboard)
{
}


INLINE void
StaticPredictor_Free(PDataboardInterface pDataboard)
{
}

#undef INLINE
#endif /* MSTATICPREDICTOR_H_*/
