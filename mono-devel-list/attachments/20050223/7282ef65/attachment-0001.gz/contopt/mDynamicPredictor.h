/*this header gets included ONLY from mDataboard.h*/
#include "mDataboard.h"

#ifndef MDYNAMICPREDICTOR_H_
#define MDYNAMICPREDICTOR_H_ 1


#ifdef MDYNAMICPREDICTOR_INLINE_
#	define INLINE
#endif
#include <mInline.h>


/*               === DynamicPredictor Interface ===
 *
 * The DynamicPredictor serves as a program - phase change detector and might
 * even try to predict these changes..
 * If turned off, the COF won't do continuous optimization - instead only optimizations
 * triggered by the first time compilation!
 * */

typedef enum {dynpreOff = 0, dynpreOn = 1} DynamicPredictorMode;
typedef struct _DynamicPredictorDataboardInterface {
	gpointer	pPredictorThread;	/* Predictor Thread Handle */
	guint32		PredictorThreadId;	/* Predictor Thread ID */
	guint32		Version;
	guint32		ProfileDataFirstElement;
	guint16		ReadQueuePos;		/* Don't touch - picker only! */
	guint16		WriteQueuePos;		/* advanced written to pPredictor Queue */
	WeightedSample	PredictorQueue [DYNAMIC_PREDICTOR_QUEUE_SIZE];	/* picker queue */
	WeightedSample	ProfileDataHits [DYNAMIC_PREDICTOR_PROFILE_DATA_SIZE]; /*saved */
	WeightedSample	ProfileDataClimb [DYNAMIC_PREDICTOR_PROFILE_DATA_SIZE];/*saved */

	unsigned char	Shutdown:1;		/* Shut down threads */
	unsigned char	Phases;			/* how many phases we have */
	DynamicPredictorMode	Mode;
} DynamicPredictorDataboardInterface, *PDynamicPredictorDataboardInterface;


INLINE void DynamicPredictor_Init (PDataboardInterface pDataboard);
INLINE void DynamicPredictor_ConfigureSystem (PDataboardInterface pDataboard);
INLINE void DynamicPredictor_Start (PDataboardInterface pDataboard);
INLINE void DynamicPredictor_Stop  (PDataboardInterface pDataboard);
INLINE void DynamicPredictor_Free (PDataboardInterface pDataboard);

void DynamicPredictor_DoRun (PDataboardInterface pDataboard);
guint32 DynamicPredictor_ThreadMain (gpointer Arg);

/* ---------------- implementation of inline stuff ----------------- */

INLINE void
DynamicPredictor_Init(PDataboardInterface pDataboard)
{
	pDataboard->pDynamicPredictorData = (PDynamicPredictorDataboardInterface) pDataboard->TotalModuleMemory;
	pDataboard->TotalModuleMemory += sizeof(DynamicPredictorDataboardInterface);
}

INLINE void
DynamicPredictor_ConfigureSystem(PDataboardInterface pDataboard)
{
	if (pDataboard->pDynamicPredictorData->Mode)
	{
		/*turned on*/

	} else
	{
		/*turned off*/

	}
}


INLINE void
DynamicPredictor_Start (PDataboardInterface pDataboard)
{
	/*if dynamic predictor enabled:*/
	if (pDataboard->pDynamicPredictorData->Mode == dynpreOn)
	{
		pDataboard->pDynamicPredictorData->WriteQueuePos = 1;
		/*create background thread*/
		gpointer param = pDataboard;
		pDataboard->pDynamicPredictorData->pPredictorThread = CreateThread (NULL,
			     0, & DynamicPredictor_ThreadMain,  param, CREATE_SUSPENDED,
			     &pDataboard->pDynamicPredictorData->PredictorThreadId);

		if (! pDataboard->pDynamicPredictorData->pPredictorThread)
		{
			g_printf("COF: Sampling Profiler Thread could not be created.\n Aborting.");
			exit(1);
		}
		/*start sampling thread*/
		/*g_print ("COF: Starting PRE\n");*/
		ResumeThread (pDataboard->pDynamicPredictorData->pPredictorThread);
	}

}

INLINE void
DynamicPredictor_Stop  (PDataboardInterface pDataboard)
{
	pDataboard->pDynamicPredictorData->Shutdown = 1;
}

INLINE void
DynamicPredictor_Free(PDataboardInterface pDataboard)
{

}


#undef INLINE
#endif /* MDYNAMICPREDICTOR_H_*/
