#ifndef MPROFILEROBJECT_H_
#define MPROFILEROBJECT_H_ 1


#ifdef MPROFILEROBJECT_INLINE_
#	define INLINE
#endif
#include <mInline.h>

/*               === ProfilerObject Interface ===
 * */


#undef INLINE
#endif /* MPROFILEROBJECT_H_*/
