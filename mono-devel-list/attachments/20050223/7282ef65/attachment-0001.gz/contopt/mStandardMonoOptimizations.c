/* OptimizationObject that applies the standard mono optimizations
 */

#include "mOptimizationObject.h"
#include <string.h>
#include <glib.h>
#include "mono/metadata/appdomain.h"

MonoRecompileMethod MonoRecompileMethodFunc = NULL;

/*example of how to use the arrays in ExOptimizationDescriptor*/
OptimizationDescriptor MonoOptimizationDescriptor1 = {
	otSpeed,
	ocAverage,
	opStatic,
	oiStandard | oiSSA
};

POptimizationDescriptor MonoOptimizationDescriptors[] = {
	&MonoOptimizationDescriptor1,
	NULL /*important!! Last element has to be NULL in all arrays!!*/
};

/*Define Extended Optimization Descriptor*/
ExOptimizationDescriptor MonoOptimizationDescription = {
	"Mono.Standard",/*Author.Name*/
	1,		/*Initial Version number must be 1!*/
	1,		/*Initial patchlevel must be 1!*/
	NULL,		/*same scheme as below, if needed*/
	NULL,		/*same scheme as below, if needed*/
	(POptimizationDescriptor (*)[]) MonoOptimizationDescriptors,	/*C-Compiler needs cast here*/
	MONO_STANDARDOPTIMIZATION_ID	/*statically linked, so fixed ID*/
};

/*private Prototypes*/
gint32 MonoOptimization_EstimateSpeedupFast (gint32 OId, gint32 DId, PCofMethodDataEntry pData);
gpointer MonoOptimization_OptimizeAndCompile (gint32 OId, gint32 DId, PCofMethodDataEntry pData, gint32* speedup);


/*Define Optimization Interface*/
OptimizationInterface MonoOptimization = {
	&MonoOptimizationDescription,
	&MonoOptimization_EstimateSpeedupFast,
	&MonoOptimization_OptimizeAndCompile
};


/*--------------implementation-----------------*/

gint32
MonoOptimization_EstimateSpeedupFast (gint32 OId, gint32 DId, PCofMethodDataEntry pData)
{
	return 0x1; /*no estimate supported (yet)*/
}


gpointer
MonoOptimization_OptimizeAndCompile (gint32 OId, gint32 DId, PCofMethodDataEntry pData, gint32* speedup)
{
	gpointer result = NULL;
	*speedup = 1;
	if (MonoRecompileMethodFunc && mono_domain_set_appdomain_only (pData->pDomain)) {
		guint32 opt;
		/* select everything we have for now.. */
		opt = MONO_OPT_PEEPHOLE ||  MONO_OPT_ABCREM || MONO_OPT_SSAPRE
			|| MONO_OPT_BRANCH || MONO_OPT_INLINE || MONO_OPT_CFOLD ||
			MONO_OPT_CONSPROP || MONO_OPT_COPYPROP || MONO_OPT_DEADCE ||
			MONO_OPT_LINEARS || MONO_OPT_CMOV ||
			MONO_OPT_INTRINS || MONO_OPT_TAILC || MONO_OPT_LOOP || MONO_OPT_FCMOV ||
			MONO_OPT_LEAF ;

		pData->OldCodeStart = pData->pJitInfo->code_start;
		pData->OldCodeSize  = pData->pJitInfo->code_size;
		result = MonoRecompileMethodFunc(pData->pJitInfo, pData->pDomain, &opt);
		pData->OldRefCount  = opt;
	}
	return result;
}

gpointer
cof_mono_install_recompile_compile_method (MonoRecompileMethod func)
{
	gpointer result = MonoRecompileMethodFunc;
	MonoRecompileMethodFunc = func;
	return result;
}

