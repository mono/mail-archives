#include "mDataboard.h"

#define MCOFSERVICES_INLINE_
#include "mCOFServices.h"
#include "mOptimizer.h"
#include "time.h"
#include "errno.h"

time_t starttime;
time_t endtime;

void
COF_Init (gboolean staticPred, gboolean dynamicPred, gboolean profiler)
{
	/*g_print ("COF: Initializing (%x,%x,%x)\n", staticPred, dynamicPred, profiler);*/
	Optimizer_Init ();
	/* Init all modules: Set up internal state, reserve memory on databoard */
	StaticPredictor_Init(pGlobalDataboard);
	DynamicPredictor_Init(pGlobalDataboard);
	Profiler_Init(pGlobalDataboard);
	Picker_Init(pGlobalDataboard);

	/* 0: Init Databoard */
	pGlobalDataboard->Init(pGlobalDataboard);

	/* 0a: Set basic system configuration according to cmd line args */
	if (staticPred)
		pGlobalDataboard->pStaticPredictorData->Mode = aptOn;

	if (dynamicPred) {
		pGlobalDataboard->pProfilerData->SamMode = profOn;
		pGlobalDataboard->pDynamicPredictorData->Mode = dynpreOn;
		pGlobalDataboard->pPickerData->Mode = pickOn;
	}

	if (profiler) {
		pGlobalDataboard->pProfilerData->Mode = profOn;
		pGlobalDataboard->pPickerData->Mode = pickOn;
	}

	/*1.: Let the static predictor do the basic system configuration*/
	StaticPredictor_ConfigureSystem (pGlobalDataboard);
	/*2.: Let the dynamic predictor do further system configuration*/
	DynamicPredictor_ConfigureSystem (pGlobalDataboard);
	/*3.: Profiler sets up*/
	Profiler_ConfigureSystem (pGlobalDataboard);
	/*4.: Picker does initial configuration*/
	Picker_ConfigureSystem (pGlobalDataboard);

	/*System set up and configured. Now kick it off:*/
	Profiler_Start (pGlobalDataboard);
	DynamicPredictor_Start (pGlobalDataboard);
	Picker_Start (pGlobalDataboard);

	starttime = time (NULL);
	return;
}

void
COF_Shutdown (void)
{
	endtime = time (NULL);
	/*g_printf("Time: %li\n",endtime);*/
	/*g_print ("COF: Shutting down (%f)\n",difftime(endtime,starttime));*/

	/*DeInit & Free COF key modules*/
	Picker_Free(pGlobalDataboard);
	Profiler_Free(pGlobalDataboard);
	DynamicPredictor_Free(pGlobalDataboard);
	StaticPredictor_Free(pGlobalDataboard);
	/*Free Databoard*/
	pGlobalDataboard->Free(pGlobalDataboard);
	Optimizer_Free ();
	return;
}
