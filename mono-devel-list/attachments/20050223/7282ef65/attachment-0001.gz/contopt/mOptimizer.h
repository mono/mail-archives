#ifndef MOPTIMIZER_H
#define MOPTIMIZER_H	1

#include "mDataboard.h"
#include "mOptimizationObject.h"

#include <glib.h>

#ifdef MOPTIMIZER_INLINE_
#	define INLINE
#endif
#include <mInline.h>

/*                          === OptimizerInterface ===
 *
 * Common interface of the optimizer module: Defines entry points to all functions / methods
 * that the optimizer-module (object) implements.
 * */



/*e.g. load dynamic optimizations, setup internal state*/
gint32
Optimizer_Init(void);
/* clean up */
void
Optimizer_Free (void);

/*estimate achievable speedup in %. Only consider hinted optimizations...*/
gint32
Optimizer_EstimateSpeedup(PDataboardInterface pDataboard, POptimizationDescriptor pOptimizerHints,
			  MonoJitInfo *pMethod);

/*adds some candidate along with optimizer hints on what to do*/
INLINE void
Optimizer_AddOptimizationCandidate(PDataboardInterface pDataboard,
				   POptimizationDescriptor pOptimizerHints, MonoJitInfo *pMethod);

/*carry out optimizations on most promising candiate*/
gint32
Optimizer_OptimizeTopCandidate(PDataboardInterface pDataboard);








/* ---------------- implementation of inline stuff ----------------- */
extern GArray *pOptimizerQueue;		/*FIXME: Need a heap here*/

INLINE void
Optimizer_AddOptimizationCandidate(PDataboardInterface pDataboard,
				   POptimizationDescriptor pOptimizerHints, MonoJitInfo *pMethod)
{
	if (! pMethod->cof_optimizer_queued) {
		/* Set pMethod->cof_keep_data to 1, as we want to keep the data now! */
		pMethod->cof_keep_data = 1;
		pMethod->cof_optimizer_queued = 1; /* flag for optimizer queue*/
		pMethod->cof_picker_queued = 0;    /* not in picker queue anymore */
		/* Add it to OptimizationCandidates HEAP! */
		pOptimizerQueue = g_array_append_val(pOptimizerQueue, pMethod);
		/*g_print ("COF: OPT added %p\n", pMethod);*/
	} else
		g_assert (FALSE); /*we'd need to free the CofMEthodDataEntry here probably..*/
}

#undef INLINE
#endif
