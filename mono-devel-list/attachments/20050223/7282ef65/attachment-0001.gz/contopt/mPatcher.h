#ifndef MPATCHER_H_
#define MPATCHER_H_ 1

#include "mOptimizer.h"

#ifdef MPATCHER_INLINE_
#	define INLINE
#endif
#include <mInline.h>
#include "mono/io-layer/atomic.h"
#include "mono/metadata/appdomain.h"
#include "mono/metadata/tabledefs.h"



/*               === Patcher Interface ===
 *
 * The Patcher is responsible for emitting re-optimized methods.
 * */

#define PATCHER_PATCH_VMT 1
#define PATCHER_PATCH_INSTANCE 2

INLINE gpointer Patcher_ReplaceVmt (PCofMethodDataEntry pData, gpointer newcode);
INLINE gint Patcher_IsPatchable (PCofMethodDataEntry pData);
INLINE gpointer Patcher_Patch (PDataboardInterface pDataboard, PCofMethodDataEntry pData,
                               gpointer newcode);

gboolean Patcher_InstallTrampoline (PDataboardInterface pDataboard, PCofMethodDataEntry pMethod);
gboolean Patcher_PatchMonoStub (PDataboardInterface pDataboard, PCofMethodDataEntry pMethod);

void  PatchVMT_cb (gpointer key, gpointer value, gpointer user_data);

/* ---------------- implementation of inline stuff ----------------- */
INLINE gpointer
Patcher_ReplaceVmt (PCofMethodDataEntry pData, gpointer newcode)
{
	gpointer result = NULL;
	/*patch vmt*/
	if (pData && newcode) {
		MonoVTable *pTbl;
		int slot;
		pTbl = mono_class_vtable (pData->pDomain, pData->pJitInfo->method->klass);
		slot = pData->pJitInfo->method->slot;

		if (/*mono_aot_is_got_entry (code, (guint8*)vtable_slot)
		    ||*/ mono_domain_owns_vtable_slot (pData->pDomain, &pTbl->vtable[slot])) {

			if (pTbl->vtable[slot] != newcode) {
#ifdef PATCHER_DEBUG_
				g_print ("patching.. %p -> %p \n", pTbl->vtable[slot], newcode);
#endif
				result = InterlockedExchangePointer ( &pTbl->vtable[slot], newcode);
				/*patch all VMT entries - FIXME: make this faster!*/
				g_hash_table_foreach (pData->pDomain->class_vtable_hash, &PatchVMT_cb,
					pData);

				return result;
			} else
				return NULL;
		}
	}
	/*reached if one arg was NULL or we did not own the slot!*/
	g_assert (FALSE);
	return NULL;
}

INLINE gpointer
Patcher_Patch (PDataboardInterface pDataboard, PCofMethodDataEntry pData, gpointer newcode)
{
	gpointer result = NULL;
	if (!newcode)
		return NULL;

	g_assert (pData);

	switch (pData->PatchInformation) {
		case PATCHER_PATCH_VMT:
			g_assert ((result = Patcher_ReplaceVmt (pData, newcode)));
			g_assert (Patcher_InstallTrampoline (pDataboard, pData));
			return result;
		case PATCHER_PATCH_INSTANCE:
			result = pData->OldCodeStart;
			g_assert (Patcher_PatchMonoStub (pDataboard, pData));
			g_assert (Patcher_InstallTrampoline (pDataboard, pData));
			return result;
		default:
			g_assert (FALSE);
	}
	return NULL;
}


INLINE gint
Patcher_IsPatchable (PCofMethodDataEntry pData)
{
	g_assert (pData);
	if (pData->PatchInformation)
		return pData->PatchInformation;

	/* see, if we can patch the method: */
	pData->PatchInformation = FALSE;


	if ((pData->pJitInfo->method->flags & METHOD_ATTRIBUTE_VIRTUAL) &&
	    (!pData->pJitInfo->method->klass->valuetype)) {
		/* (1) Method virtual and class no value type:*/
		MonoVTable *pTbl;
		int slot;
		pTbl = mono_class_vtable (pData->pDomain, pData->pJitInfo->method->klass);
		slot = pData->pJitInfo->method->slot;
		if (mono_domain_owns_vtable_slot (pData->pDomain, &pTbl->vtable[slot])
		    /*|| mono_aot_is_got_entry (code, (guint8*)vtable_slot)*/)
			pData->PatchInformation = PATCHER_PATCH_VMT;
	} else if ((!pData->pJitInfo->method->klass->valuetype) &&
	     (!(pData->pJitInfo->method->flags & METHOD_ATTRIBUTE_STATIC)) &&
	     (!(pData->pJitInfo->method->flags & METHOD_IMPL_ATTRIBUTE_INTERNAL_CALL))&&
	     (!(pData->pJitInfo->method->flags & METHOD_ATTRIBUTE_PINVOKE_IMPL)) &&
	      (pData->pJitInfo->method->wrapper_type == MONO_WRAPPER_NONE)) {
		/*(2) normal instance method..*/
		pData->PatchInformation = PATCHER_PATCH_INSTANCE;
	}

	/*g_print ("0x%x 0x%x %i %i\n",pData->pJitInfo->method->flags, pData->pJitInfo->method->wrapper_type,
		pData->pJitInfo->method->klass->valuetype, pData->pJitInfo->code_size);*/

	if (pData->pJitInfo->code_size < 34) /*sync this with tramp size in mpatcher.c*/
		pData->PatchInformation = FALSE;


	return pData->PatchInformation;
}



#undef INLINE
#endif /* MPATCHER_H_*/
