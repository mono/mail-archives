/*
If you specify both inline and extern in the function definition, then the
definition is used only for inlining. In no case is the function compiled
on its own, not even if you refer to its address explicitly. Such an address
becomes an external reference, as if you had only declared the function,
and had not defined it.
This combination of inline and extern has almost the effect of a macro. The
way to use it is to put a function definition in a header file with these
keywords, and put another copy of the definition (lacking inline and extern)
in a library file. The definition in the header file will cause most calls
to the function to be inlined. If any uses of the function remain, they will
refer to the single copy in the library.
http://www.redhat.com/docs/manuals/enterprise/RHEL-3-Manual/gcc/inline.html

See also:   http://www.greenend.org.uk/rjk/2003/03/inline.html
*/

/*define inline to be extern inline in case no INLINE or ANCESTORS is
  defined*/
#ifndef INLINE
# if __GNUC__
#  define INLINE extern inline
# else
#  define INLINE inline
# endif
#endif

