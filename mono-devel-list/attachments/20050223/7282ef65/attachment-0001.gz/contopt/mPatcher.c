
#define MPATCHER_INLINE_
#define MA64_DIRECT_EMIT

#include "mPatcher.h"
#include "mono/metadata/debug-helpers.h"

#ifdef HAVE_CUSTOM_BACKEND
	#define MA64_DIRECT_EMIT
	#include "ma64IntermediateRepresentation.h"
#endif
#ifndef HAVE_CUSTOM_BACKEND
	#include <mono/arch/amd64/amd64-codegen.h>
#endif


gboolean
Patcher_PatchMonoStub (PDataboardInterface pDataboard, PCofMethodDataEntry pMethod)
{
	/*patch original mono trampoline in any case*/
	MonoDomain *curr_domain = pMethod->pDomain;
	gpointer addr = pMethod->pJitInfo->code_start;
	gboolean result = FALSE;
	mono_domain_lock (curr_domain);
	gpointer *trampinfo = g_hash_table_lookup (curr_domain->jit_trampoline_hash, pMethod->pJitInfo->method);
	gpointer jumpcode = g_hash_table_lookup (curr_domain->jump_trampoline_hash, pMethod->pJitInfo->method);
	mono_domain_unlock (curr_domain);

	g_assert (trampinfo || jumpcode);

	if (trampinfo) {
		/*patch normal mono stub*/
		guint8 * trampaddr = trampinfo;
		if ((trampaddr[0] == 0x49) && (trampaddr[1] == 0xbb)) {
			guint8 *icall = *(guint8**) (trampaddr + 2);
			if (icall == pMethod->OldCodeStart) {
				InterlockedExchangePointer ((gpointer*)(trampaddr + 2), addr);
				/*g_print ("COF: PTC                    Stub patched   (%i, %p)\n", pMethod->OldRefCount, trampaddr);*/
				result = TRUE;
			} else if (icall != addr) {
				g_print ("Unknown stub target: %p %p\n", pMethod->OldCodeStart, icall);
				mono_disassemble_code (icall, 34, "Unknown stub");
				g_assert (FALSE);
			}
		} else {
			g_print ("Unknown stub: %lx\n",*(guint64*)trampaddr);
			mono_disassemble_code (trampaddr, 34, "Unknown stub");
			g_assert (FALSE);
		}
	}

	if (jumpcode) {
		/*patch jump stub */
		guint8 * trampaddr = jumpcode;
		if ((trampaddr[0] == 0x49) && (trampaddr[1] == 0xbb)) {
			guint8 *icall = *(guint8**) (trampaddr + 2);
			if (icall == pMethod->OldCodeStart) {
				InterlockedExchangePointer ((gpointer*)(trampaddr + 2), addr);
				g_print ("COF: PTC                    JMP-Stub patched   (%i, %p)\n", pMethod->OldRefCount, trampaddr);
				result = TRUE;
			} else if (icall != addr) {
				g_print ("Unknown jump-stub target: %p %p\n", pMethod->OldCodeStart, icall);
				mono_disassemble_code (icall, 34, "Unknown stub");
				g_assert (FALSE);
			}
		} else {
			g_print ("Uninitialized jump-stub: %lx\n",*(guint64*)trampaddr);
		}
	}

	return result;
}


void
Patcher_InvalidateOldMethod (PCofMethodDataEntry pMethod)
{
#if defined(__i386__) || defined(__x86_64__)
	int fill_value = 0xcc; /* x86 break */
#else
	int fill_value = 0x2a;
#endif
	memset (pMethod->OldCodeStart, fill_value, pMethod->OldCodeSize);
}


gpointer method_moved_trampoline = NULL; /*points to tramp code*/
/*'callstack':
    -> Stub in overwritten method
    -> trampoline that saves all regs
    -> amd64_method_moved_service_routine
  Patches caller of the stub to directly jump to the recompiled method. Deletes
  the stub, if refcount < 0.
  Indirect parameter MonoJitInfo is -ptr size bytes before the first stub opcode,
  effectively at tramp - 8.
 */
gpointer
amd64_method_moved_service_routine (long *regs, guint8 *code, PCofMethodDataEntry pMethod,
			       guint8* tramp)
{
	/*code taken from magic tramp*/
	gpointer vtable_slot;
	gboolean callerPatched = FALSE;
	gpointer addr = pMethod->pJitInfo->code_start;

	vtable_slot = mono_amd64_get_vcall_slot_addr (code, regs);
	g_assert (!vtable_slot); /*no virtual calls to stub allowed!*/
	char* mn = mono_method_full_name (pMethod->pJitInfo->method, TRUE);

	/* Patch calling code */
	if ((code [-13] == 0x49) && (code [-12] == 0xbb)) {
		/* get the call addr and see if it goes over stubs */
		guint8 *calladdr = *(guint8**)(code - 11);
		if (calladdr == tramp) {
			/* direct call, so patch the caller*/
			InterlockedExchangePointer ((gpointer*)(code - 11), addr);
			callerPatched = TRUE;
			g_print ("COF: PTC        Tramp Called; (1) caller patched (%i, %p, %s)\n", pMethod->OldRefCount, code, mn);
		}
	}
	else if ((code [-7] == 0x41) && (code [-6] == 0xff) && (code [-5] == 0x15)) {
		/* call *<OFFSET>(%rip) */
		gpointer *got_entry = (gpointer*)((guint8*)code + (*(guint32*)(code - 4)));
		InterlockedExchangePointer (got_entry, addr);
		callerPatched = TRUE;
		g_print ("COF: PTC        Tramp Called; (2) caller patched (%s, %i, %p)\n",pMethod->pJitInfo->method->name, pMethod->OldRefCount, code);
	}
	else {
		/* FIXME: handle more cases */
		g_print ("COF: PTC        Tramp Called; NO caller patch (%s, %i, %p)\n",pMethod->pJitInfo->method->name, pMethod->OldRefCount, code);
		mono_disassemble_code (code - 20, 44, "Unknown caller opcode");
		g_assert (FALSE);
	}

	/* Don't patch stub... (we want to free it sometime!)*/
	if (callerPatched) {
		/*decrease refcount and possibly free the old method (with stub),
		  unlock method for new optimizations*/
		pMethod->OldRefCount--;
		if (!pMethod->OldRefCount) {
			Patcher_InvalidateOldMethod (pMethod);
			pMethod->OldCodeStart = NULL;
			pMethod->OldCodeSize = 0;
			g_print ("COF: PTC        Tramp freed %s\n", mn);
		}
	}

	g_free (mn);
	/*return addr of new method!!*/
	return addr;
}

gpointer amd64_method_moved_service_routine_ptr = &amd64_method_moved_service_routine;


/* BEFORE CALLING THIS FUNCTION TEST IF THE To-Be-Modified FUNCTION IS NOT ACTIVE!

   Overwrites first TRAMPOLINE_SIZE (34) bytes of a method that has been recompiled.
   This is the limiting factor for small methods not being recompilable!
   Done thread safe!
   The newly created stub calls a trampoline (that basically saves the cpu state) and
   calls into the service routine above.
*/
gboolean
amd64_create_specific_method_moved_stub (PDataboardInterface pDataboard, PCofMethodDataEntry
                                         pMethod)
{
	int missing;
	gpointer pBuffer = pMethod->OldCodeStart;
	gpointer pBufferPos = pBuffer;
	gpointer pBufferPatchPos = pBufferPos;

	g_assert (method_moved_trampoline);
	g_assert (pBuffer);
#ifndef HAVE_CUSTOM_BACKEND
	/*FIXME: make this thread safe!*/
	amd64_lea_membase (((guint8 *)pBufferPos), AMD64_R11, AMD64_RIP, -7);
	amd64_push_reg (((guint8 *)pBufferPos), AMD64_R11);
	amd64_mov_reg_imm (((guint8 *)pBufferPos), AMD64_R11, pMethod);
	amd64_push_reg (((guint8 *)pBufferPos), AMD64_R11);
	amd64_mov_reg_imm (((guint8 *)pBufferPos), AMD64_R11, method_moved_trampoline);
	amd64_jump_reg (((guint8 *)pBufferPos), AMD64_R11);
	g_assert ((pBufferPos - pBuffer) <= 34/*TRAMPOLINE_SIZE*/);
#endif
#ifdef HAVE_CUSTOM_BACKEND
	/*lea -7(%rip),%r11*/
	MA64OpcodeNew(lea,lea_rX4_m);
	MA64OpcodeOr(lea,amd64_modrm_reg_r11);
	MA64OpcodeOr(lea,amd64_modrm_mem_rip_disp4);
	MA64OpcodeOr(lea,amd64_go64);						         /**/
	MA64OpcodeImmDispPatchEmit(pBuffer,pBufferPos,lea,0,-7,0, missing);
	/*push %r11*/
	MA64OpcodeNew(push,push_reg);
	MA64OpcodeOr(push,amd64_r11);
	MA64OpcodeEmit(pBufferPos,push,0);
	/*mov pMethod(IMM), %r11*/
	MA64OpcodeNew(mov,mov_r8_i8);
	MA64OpcodeOr(mov,amd64_go64);						         /**/
	MA64OpcodeOr(mov,amd64_r11);
	MA64OpcodeImmDispEmit(pBuffer,pBufferPos,mov,0,0,pMethod);
	/*push %r11*/
	MA64OpcodeNew(push,push_reg);
	MA64OpcodeOr(push,amd64_r11);
	MA64OpcodeEmit(pBufferPos,push,0);
	/*mov method_moved_trampoline, %r11*/
	MA64OpcodeNew(mov,mov_r8_i8);
	MA64OpcodeOr(mov,amd64_go64);						         /**/
	MA64OpcodeOr(mov,amd64_r11);
	MA64OpcodeImmDispEmit(pBuffer,pBufferPos,mov,0,0,method_moved_trampoline);
	/*jump %r11*/
	MA64OpcodeNew(jmp,jmp_mreg8);
	MA64OpcodeOr(jmp,amd64_modrm_mem_r11);
	MA64OpcodeOr(jmp,amd64_go64);						         /**/
	MA64OpcodeEmit(pBufferPos,jmp,0);
	/* remove the self jump MA64OpcodeImmDispPatchEmit has introduced.. */
	MA64OpcodePatchRemove(pBufferPatchPos, missing);
	g_assert ((pBufferPos - pBuffer) == 34/*TRAMPOLINE_SIZE*/);
#endif

	mono_arch_flush_icache (pMethod->OldCodeStart,pMethod->OldCodeSize);
	return TRUE;
}

gboolean
Patcher_InstallTrampoline (PDataboardInterface pDataboard, PCofMethodDataEntry pMethod)
{
	/* insert a jump self*/
	int stop_bytes;
	*((guint16*)&stop_bytes) =  *((guint16*)pMethod->OldCodeStart);
	*((guint16*)pMethod->OldCodeStart) = 0xFEEB; /*write jump self*/
	/* FIXME: see if no other thread is active in the method we want to replace */
	/*PThreadListEntry thread = pDataboard->pLastThreadEntry;
	while(thread)
	{
		thread->ReportIp = 1;
		pthread_kill (thread->ThreadId, SIGPROF);
		PThreadListEntry next = thread->PrevEntry;
		thread = next;
	}
	thread = pDataboard->pLastThreadEntry;
	gboolean methodActive = FALSE;
	while(thread)
	{
		while (thread->ReportIp) {
			g_print ("Waiting %p\n",thread);
			pthread_yield ();
		}
		methodActive |= (pMethod->OldCodeStart + 3 <= (gpointer) thread->ReportedIp) &&
			(pMethod->OldCodeStart + pMethod->OldCodeSize > (gpointer) thread->ReportedIp);
		thread->ReportedIp = 0;
		PThreadListEntry next = thread->PrevEntry;
		thread = next;
	}
	if (methodActive) {
		*((guint16*)pMethod->OldCodeStart) = *((guint16*)&stop_bytes);
		return FALSE;
	}*/
	/* create stub */
	amd64_create_specific_method_moved_stub (pDataboard, pMethod);
	return TRUE;
}

void
PatchVMT_cb (gpointer key, gpointer value, gpointer user_data)
{
	/*value == MonoVTable*/
	MonoVTable *vt = (MonoVTable*) value;
	PCofMethodDataEntry pMethod = (PCofMethodDataEntry) user_data;

	int slot = pMethod->pJitInfo->method->slot;
	gpointer oldlocation = pMethod->OldCodeStart;
	gpointer newlocation = pMethod->pJitInfo->code_start;

	if (vt->klass->vtable_size > slot)
		if (vt->vtable[slot] == oldlocation)
			InterlockedExchangePointer ( &vt->vtable[slot], newlocation);
}
