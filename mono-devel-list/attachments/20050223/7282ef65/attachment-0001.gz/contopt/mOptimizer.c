#include <mOptimizationObject.h>
#define MOPTIMIZER_INLINE_
#include <mOptimizer.h>
#include "mPatcher.h"
#include "mono/metadata/debug-helpers.h"


guint16		OptimizationBitmapSize = 0;  	/*initialized by Optimizer..*/
guint16		(*OptimizationObjectOffset)[];	/*initialized by Optimizer..*/
GArray		*pOptimizerQueue;		/*FIXME: Need a heap here*/

/*defines available optimizations - this could be extended to some
  dynamic loading mechanism*/
#define Mono_OptimizationCount 2

extern OptimizationInterface MonoOptimization;

/* available optimizations - add new ones as needed! */
POptimizationInterface AvailableOptimizations[] = {
	&NullOptimization,
	&MonoOptimization
};





/* ------------- implementation -----------------------*/
gint32
Optimizer_Init (void)
{
	int OptimizationSum = 0;
	int i;
	/* init offset array */
	OptimizationObjectOffset = (guint16 (*) []) g_malloc0 (sizeof(guint16) * (Mono_OptimizationCount+1));
	for (i = 0; i < Mono_OptimizationCount; i++) {

		POptimizationDescriptor *pDescriptor;
		int a;
		/*set ids*/
		AvailableOptimizations [i]->pDescriptor->OptimizationID = i;
		(*OptimizationObjectOffset) [i] = OptimizationSum;
		pDescriptor = (POptimizationDescriptor *) AvailableOptimizations [i]->pDescriptor
			->ppDescriptors;
		a = 0;
		while (pDescriptor [a])
			a++;
		OptimizationSum += a;

	}
	/* calculate bitmap size (in bytes) */
	OptimizationBitmapSize = (OptimizationSum + 1) / 8;

	pOptimizerQueue = g_array_new (FALSE, FALSE, sizeof (MonoJitInfo*));
	return 0;
}


void
Optimizer_Free (void)
{
	/*free bitmap offsets*/
	g_free (OptimizationObjectOffset);
	g_array_free (pOptimizerQueue, TRUE);
}


/*compares two hints and returns <> 0 if A matches B*/
static int
Optimizer_OptimizationHintMatch (POptimizationDescriptor pHintA,
				 POptimizationDescriptor pHintB)
{
	if ( (pHintA->Target == pHintB->Target) &&
	     ((pHintA->Complexity == 0)  || (pHintA->Complexity & pHintB->Complexity)) &&
	     ((pHintA->ProfileData == 0) || (pHintA->ProfileData & pHintB->ProfileData)) &&
	     ((pHintA->IR == 0) || (pHintA->IR & pHintB->IR)) )
		return 1;
	else
		return 0;
}


/*estimate achievable speedup in %. Only consider hinted optimizations...*/
gint32
Optimizer_EstimateSpeedup(PDataboardInterface pDataboard,
			  POptimizationDescriptor pOptimizerHints,  MonoJitInfo *pMethod)
{
	/*iterate over all registered optimizations and collect speedup estimates. Take hint
	  as filter */
	int i;
	int max_speedup = 0x80000000;
/**/	Databoard_Lock (pDataboard);
/**/	PCofMethodDataEntry pMethodData = g_tree_lookup (pDataboard->pMethodData, pMethod);
/**/	Databoard_Unlock (pDataboard);
	if (!pMethodData)
		return 0x80000000;

	/* before we can optimize, we have to see if we can apply the optimized version!*/
	if (!Patcher_IsPatchable (pMethodData))
		return 0x80000002;

	for (i = 0; i < Mono_OptimizationCount; i++) {
		POptimizationDescriptor *pDescriptor;
		int a;
		pDescriptor = (POptimizationDescriptor *) AvailableOptimizations [i]->pDescriptor->
			ppDescriptors;
		a = 0;
		while (pDescriptor [a]) {
			gint offset = (*OptimizationObjectOffset) [i];
			offset += a;
			gint bit = CofMethodDataEntryGetBit (pMethodData, offset);
			/*g_print ("read bit: (%p) %x\n", pMethodData, bit);*/
			if (Optimizer_OptimizationHintMatch (pOptimizerHints, pDescriptor[a]) &&
			   (! bit)) {
				/* get estimated speedup */
				gint32 speedup;
				speedup = AvailableOptimizations [i]->pEstimateSpeedupFast (i, a,
					 pMethodData);
				if ((speedup >= PO_MINIMUM_SPEEDUP) && (speedup > max_speedup)) {
					/*consider this optimization*/
					max_speedup = speedup;
					pMethodData->ConsideredOptimization_ID = i;
					pMethodData->ConsideredOptimization_Hint = a;
					pMethodData->ConsideredSpeedup = speedup;
				}
			}
			a++;
		}
	}
	return max_speedup;
}


/*carry out optimizations on most promising candiate*/
gint32
Optimizer_OptimizeTopCandidate(PDataboardInterface pDataboard)
{
	/* Take most promising candidate from heap and apply optimization */
	/* FIXME: get the most promising, not the first in a list... */
	if (pOptimizerQueue->len > 0) {
		gpointer code;
		gint32 speedup;

		MonoJitInfo *pMethod = (MonoJitInfo*) g_array_index (pOptimizerQueue, uintptr_t, 0);
		pOptimizerQueue = g_array_remove_index_fast(pOptimizerQueue, 0);
		g_assert (pMethod);

/**/		Databoard_Lock (pDataboard);
/**/		PCofMethodDataEntry pMethodData = g_tree_lookup (pDataboard->pMethodData, pMethod);
/**/		Databoard_Unlock (pDataboard);
		g_assert (pMethodData);
		g_assert (Patcher_IsPatchable (pMethodData));

		guint16 id = pMethodData->ConsideredOptimization_ID;
		guint16 hint = pMethodData->ConsideredOptimization_Hint;
		/*remove CofMethodDataEntry from tree*/
		pMethod->cof_sam_ignore = 1; /*no longer active*/
/**/		Databoard_Lock (pDataboard);
/**/		g_tree_remove (pDataboard->pMethodData, pMethod);
/**/		Databoard_Unlock (pDataboard);

		pMethodData->OldCodeStart = NULL;
		pMethodData->OldCodeSize  = 0;
		pMethodData->OldRefCount  = 0;

		/*recompile*/
		code = AvailableOptimizations [id]->pOptimizeAndCompile (id, hint, pMethodData, &speedup);

		/*insert data into tree again*/
		g_assert (pMethodData->pJitInfo == pMethod);
		g_assert (code == pMethod->code_start);
		pMethod->cof_sam_ignore = 0;
		pMethod->cof_optimizer_queued = 1;
		pMethod->cof_keep_data = 1;
/**/		Databoard_Lock (pDataboard);
/**/		g_tree_insert (pDataboard->pMethodData, pMethod, pMethodData);
/**/		Databoard_Unlock (pDataboard);
		/*now patch*/
		gpointer oldcode = Patcher_Patch (pDataboard, pMethodData, code);
		if (!oldcode) {
			/*If patching wasn't completed 100% successfully, we keep both
			  methods, and disable any COF operations on this method in
			  future! FIXME: Make this more intelligent.*/
			pMethod->cof_sam_ignore = 1; /*no longer active*/
		} else
			pMethod->cof_sam_ignore = 0; /*re-activate*/
/*#ifdef OPTIMIZER_DEBUG_*/
		if (oldcode) {
			char *mn = mono_method_full_name (pMethodData->pJitInfo->method, TRUE);
			uint flags = pMethodData->pJitInfo->method->flags;
			uint iflags = pMethodData->pJitInfo->method->iflags;
			int refcount = pMethodData->OldRefCount;
			if (pMethodData->pJitInfo->method->flags & METHOD_ATTRIBUTE_VIRTUAL)
				g_print ("COF: OPT   VIRT Recompiled & patched: (%x, %x, %i) %p %s\n", flags, iflags, refcount, pMethodData, mn);
			else
				g_print ("COF: OPT        Recompiled & patched: (%x, %x, %i) %p %s\n", flags, iflags, refcount, pMethodData, mn);
			g_free (mn);
		}
/*#endif*/
		gint offset = (*OptimizationObjectOffset) [id];
		offset += hint;
		CofMethodDataEntrySetBit (pMethodData, offset, 1);

		pMethod->cof_optimizer_queued = 0;
		return speedup;
	} else
		return 0x80000000;
}
