/*this header gets included ONLY from mDataboard.h*/
#include "mDataboard.h"

#ifndef MPICKER_H_
#define MPICKER_H_ 1

#include "mono/io-layer/mono-mutex.h"
#ifdef MPICKER_INLINE_
#	define INLINE
#endif
#include <mInline.h>

/*               === Picker Interface ===
 *
 * There are two ways the picker is invoked:
 * (1) manually by first-time compilation
 * (2) automatically for continuous optimization
 *
 * Depending on the invocation method (1) or (2) the picker will do:
 * (1) - get some cheap optimizations and emit the method
 *     - insert method into candiate queue
 *
 * (2) depending on the predictor states and the profiler data, select
 *     appropriate method from candidate queue and queue method for recompilation.
 * */

typedef enum {pickOff = 0, pickOn = 1} PickerMode;
typedef struct _PickerDataboardInterface {
	gpointer	pPickerThread;	/* Picker/Optimizer Thread Handle */
	guint32		PickerThreadId;	/* Picker/Optimizer Thread ID */
	pthread_mutex_t picker_mutex;
	pthread_cond_t  picker_newdata_cv;
	guint32		Version;
	PickerMode	Mode;
	unsigned char	Shutdown;
} PickerDataboardInterface, *PPickerDataboardInterface;

INLINE void Picker_Init(PDataboardInterface pDataboard);
INLINE void Picker_ConfigureSystem(PDataboardInterface pDataboard);
INLINE void Picker_Start (PDataboardInterface pDataboard);
INLINE void Picker_Stop  (PDataboardInterface pDataboard);
INLINE void Picker_Free(PDataboardInterface pDataboard);
INLINE void Picker_Wakeup (PPickerDataboardInterface pPicker);

guint32 Picker_ThreadMain (gpointer Arg);

/* ---------------- implementation of inline stuff ----------------- */

INLINE void
Picker_Init(PDataboardInterface pDataboard)
{
	pDataboard->pPickerData = (PPickerDataboardInterface) pDataboard->TotalModuleMemory;
	pDataboard->TotalModuleMemory += sizeof(PickerDataboardInterface);
}

INLINE void
Picker_ConfigureSystem(PDataboardInterface pDataboard)
{
}

INLINE void
Picker_Start (PDataboardInterface pDataboard)
{
	mono_mutex_init (&pDataboard->pPickerData->picker_mutex, NULL);
	mono_cond_init (&pDataboard->pPickerData->picker_newdata_cv, NULL);

	PPickerDataboardInterface pPicker = pDataboard->pPickerData;
	if (pPicker->Mode == pickOn) {
		/*start thread*/
		gpointer param = pDataboard;
		pPicker->pPickerThread = CreateThread (NULL,
			     0, & Picker_ThreadMain,  param, CREATE_SUSPENDED,
			     &pPicker->PickerThreadId);

		if (! pPicker->pPickerThread)
		{
			g_printf("COF: Picker/Optimizer thread could not be created.\n Aborting.");
			exit(1);
		}
		/*start sampling thread*/
		/*g_print ("COF: Starting P/O\n");*/
		ResumeThread (pPicker->pPickerThread);
	}
}

INLINE void
Picker_Wakeup (PPickerDataboardInterface pPicker)
{
/**/	mono_mutex_lock (&pPicker->picker_mutex);
/**/	mono_cond_signal (&pPicker->picker_newdata_cv);
/**/	mono_mutex_unlock (&pPicker->picker_mutex);
}

INLINE void
Picker_Stop  (PDataboardInterface pDataboard)
{
	/*signal shutdown*/
	pDataboard->pPickerData->Shutdown = 1;
	Picker_Wakeup (pDataboard->pPickerData);
}

INLINE void
Picker_Free(PDataboardInterface pDataboard)
{
	mono_mutex_destroy (&pDataboard->pPickerData->picker_mutex);
	pthread_cond_destroy (&pDataboard->pPickerData->picker_newdata_cv);
}

 /*Interface for in thread ad hoc optimization (= OnCompilation)*/

#undef INLINE
#endif /* MPICKER_H_*/
