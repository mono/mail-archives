/*
 * test.dll.c
 * 
 * Copyright (C) Tom Spink 2011 <tspink@gmail.com>
 * All Rights Reserved
 */
#include <mono/jit/jit.h>
#include <mono/metadata/assembly.h>
#include <mono/metadata/image.h>
#include <mono/metadata/debug-helpers.h>
#include "support.h"

static void (*FnTest_TestClass_TestStaticMethod)(MonoException **exception);
__stub void Test_TestClass_TestStaticMethod(void)
{
	MonoException *exception;
	sp_ensure_runtime();
	
	if (FnTest_TestClass_TestStaticMethod == NULL) {
		FnTest_TestClass_TestStaticMethod = sp_get_method_thunk("Test.TestClass:TestStaticMethod()");
	}
	
	FnTest_TestClass_TestStaticMethod(&exception);
	if (exception != NULL) {
		mono_raise_exception(exception);
	}
}

static int (*FnTest_TestClass_TestStaticMethod2)(MonoException **exception);
__stub int Test_TestClass_TestStaticMethod2(void)
{
	MonoException *exception;
	sp_ensure_runtime();
	
	if (FnTest_TestClass_TestStaticMethod2 == NULL) {
		FnTest_TestClass_TestStaticMethod2 = sp_get_method_thunk("Test.TestClass:TestStaticMethod2()");
	}
	
	return FnTest_TestClass_TestStaticMethod2(&exception);
	if (exception != NULL) {
		mono_raise_exception(exception);
	}
}

static MonoClass *Test_TestClass;
__stub void *new_Test_TestClass(void)
{
	MonoObject *obj;
	
	sp_ensure_runtime();
	
	if (Test_TestClass == NULL) {
		Test_TestClass = mono_class_from_name(m_image, "Test", "TestClass");
	}
	
	obj = mono_object_new(m_domain, Test_TestClass);
	mono_runtime_object_init(obj);
	
	return obj;
}

static int (*Fnnew_Test_TestClass2)(MonoObject *this, int start, MonoException **exception);
__stub void *new_Test_TestClass2(int start)
{
	MonoException *exception;
	MonoObject *obj;
	
	sp_ensure_runtime();
	
	if (Test_TestClass == NULL) {
		Test_TestClass = mono_class_from_name(m_image, "Test", "TestClass");
	}
	
	obj = mono_object_new(m_domain, Test_TestClass);
	
	if (Fnnew_Test_TestClass2 == NULL) {
		Fnnew_Test_TestClass2 = sp_get_method_thunk("Test.TestClass:.ctor(int)");
	}
	
	Fnnew_Test_TestClass2(obj, start, &exception);
	if (exception != NULL) {
		mono_raise_exception(exception);
	}
	
	return obj;
}

static int (*FnTest_TestClass_TestMethod)(MonoObject *this, MonoException **exception);
__stub void Test_TestClass_TestMethod(void *this)
{
	MonoException *exception;
	
	sp_ensure_runtime();
	
	if (FnTest_TestClass_TestMethod == NULL) {
		FnTest_TestClass_TestMethod = sp_get_method_thunk("Test.TestClass:TestMethod()");
	}
	
	FnTest_TestClass_TestMethod((MonoObject *)this, &exception);
	if (exception != NULL) {
		mono_raise_exception(exception);
	}
}

static int (*FnTest_TestClass_TestMethod2)(MonoObject *this, MonoString *name, MonoException **exception);
__stub void Test_TestClass_TestMethod2(void *this, char *name)
{
	MonoException *exception;
	
	sp_ensure_runtime();

	if (FnTest_TestClass_TestMethod2 == NULL) {
		FnTest_TestClass_TestMethod2 = sp_get_method_thunk("Test.TestClass:TestMethod2(string)");
	}
	
	FnTest_TestClass_TestMethod2((MonoObject *)this, mono_string_new(m_domain, name), &exception);
	if (exception != NULL) {
		mono_raise_exception(exception);
	}
}

static int (*FnTest_TestClass_TestMethod3)(MonoObject *this, MonoException **exception);
__stub void Test_TestClass_TestMethod3(void *this)
{
	MonoException *exception;
	
	sp_ensure_runtime();

	if (FnTest_TestClass_TestMethod3 == NULL) {
		FnTest_TestClass_TestMethod3 = sp_get_method_thunk("Test.TestClass:TestMethod3()");
	}
	
	FnTest_TestClass_TestMethod3((MonoObject *)this, &exception);
	if (exception != NULL) {
		mono_raise_exception(exception);
	}
}
