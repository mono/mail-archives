// (c) Copyright Microsoft Corporation.
// This source is subject to the Microsoft Permissive License.
// See http://www.microsoft.com/resources/sharedsource/licensingbasics/sharedsourcelicenses.mspx.
// All other rights reserved.


// README
//
// There are two steps to adding a property:
//
// 1. Create a member variable to store your property
// 2. Add the get_ and set_ accessors for your property.
//
// Remember that both are case sensitive!
//

Type.registerNamespace('TextChanged');

TextChanged.TextChangedBehavior = function(element) {

    TextChanged.TextChangedBehavior.initializeBase(this, [element]);

    // TODO : (Step 1) Add your property variables here
    //
    this._text = '';
    this._timeout = 500;
    this._timer = null;
}

TextChanged.TextChangedBehavior.prototype = {

    initialize : function() {
        TextChanged.TextChangedBehavior.callBaseMethod(this, 'initialize');
        
        this._text = this.get_element().value;
        
        $addHandlers(this.get_element(), {keydown: this._onKeyDown}, this);
    },

    dispose : function() {
        if(this._timer) {
            this._timer = null;
        }
        
        $clearHandlers(this.get_element());
            
        TextChanged.TextChangedBehavior.callBaseMethod(this, 'dispose');
    },
    
    _onKeyDown : function() {
        this._stopTimer();
        this._startTimer();
    },

    _onTimerTick : function() {
        this._stopTimer();
        
        var elementText = this.get_element().value;
        
        if(this._text != elementText) {
            this._text = elementText;
            
            this._fireTextBoxChange();
            this._raiseEvent('textChanged');
        }
    },
    
    add_textChanged : function(handler) 
    {    
        this.get_events().addHandler('textChanged', handler);
    },

    remove_textChanged : function(handler) 
    {    
        this.get_events().removeHandler('textChanged', handler);
    },

    _raiseEvent : function(eventName, eventArgs) 
    {    
        var handler = this.get_events().getHandler(eventName);    
        
        if (handler) {     
            if (!eventArgs) {        
                eventArgs = Sys.EventArgs.Empty;     
            }     
            handler(this, eventArgs);    
        }
    },
    
    _fireTextBoxChange : function() {
        if (document.createEvent) {
            var onchangeEvent = document.createEvent('HTMLEvents');
            onchangeEvent.initEvent('change', true, false);
            
            this.get_element().dispatchEvent(onchangeEvent);
        } 
        else if(document.createEventObject) {
            this.get_element().fireEvent('onchange');
        }
    },
    
    _startTimer : function() {
        this._timer = window.setTimeout(Function.createDelegate(this, this._onTimerTick), this._timeout);
    },

    _stopTimer : function() {
        if(this._timer != null) {
            window.clearTimeout(this._timer);
        }
        this._timer = null;
    },
    
    // TODO: (Step 2) Add your property accessors here
    //
    get_timeout : function() {
        return this._timeout;
    },

    set_timeout : function(value) {
        this._timeout = value;

        this.raisePropertyChanged('timeout');
    }
}
TextChanged.TextChangedBehavior.registerClass('TextChanged.TextChangedBehavior', AjaxControlToolkit.BehaviorBase);
