using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Samples
{
    /// <summary>
    /// Summary description for FormattingExtender
    /// </summary>
    [TargetControlType(typeof(TextBox))]
    public class FormattingExtender : ExtenderControl
    {
        public string HoverCssClass
        {
            get { return (string)ViewState["HoverCssClass"]; }
            set { ViewState["HoverCssClass"] = value; }
        }

        public string FocusCssClass
        {
            get { return (string)ViewState["FocusCssClass"]; }
            set { ViewState["FocusCssClass"] = value; }
        }

        public string ScriptPath
        {
            get { return (string)ViewState["ScriptPath"]; }
            set { ViewState["ScriptPath"] = value; }
        }

        protected override IEnumerable<ScriptDescriptor> GetScriptDescriptors(Control targetControl)
        {
            ScriptBehaviorDescriptor desc = new ScriptBehaviorDescriptor("Samples.FormattingBehavior",
                targetControl.ClientID);

            desc.AddProperty("hoverCssClass", this.HoverCssClass);
            desc.AddProperty("focusCssClass", this.FocusCssClass);

            yield return desc;
        }

        protected override IEnumerable<ScriptReference> GetScriptReferences()
        {
            yield return new ScriptReference(Page.ResolveClientUrl(this.ScriptPath));
        }
    }
}
