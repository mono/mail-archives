using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace Samples.ShoppingCart
{
    /// <summary>
    /// Summary description for Article
    /// </summary>
    public interface IArticle
    {
        string Id { get; set; }
        int Quantity { get; set; }
        string Description { get; set; }
        string ImageUrl { get; set; }
    }
}
