using System;
using Samples.ShoppingCart;

/// <summary>
/// Summary description for IShoppingCart
/// </summary>
public interface IShoppingCart
{
    void Add(IArticle article);
}
