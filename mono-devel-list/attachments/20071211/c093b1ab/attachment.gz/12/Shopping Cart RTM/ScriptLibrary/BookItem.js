﻿Type.registerNamespace('Samples');

Samples.BookItem = function(element) {
   Samples.BookItem.initializeBase(this, [element]);
   
   this._addToCartElement = null;
   this._dragStartLocation = null;
}
Samples.BookItem.prototype = {
    initialize : function() {
        Samples.BookItem.callBaseMethod(this, 'initialize');
        
        $addHandlers(this.get_element(), {mousedown:this._onMouseDown}, this);
    },
    
    dispose : function() {
        $clearHandlers(this.get_element());
        Samples.BookItem.callBaseMethod(this, 'dispose');
    },
    
    _onMouseDown : function(evt) {
        window._event = evt;
        evt.preventDefault();
        
        this.startDragDrop(this.get_element());
    },
    
    startDragDrop : function(dragVisual) {
        Sys.Preview.UI.DragDropManager.startDragDrop(this, dragVisual, null);
    },
    
    get_dragDataType : function() {
        return '__bookItem';
    },

    getDragData : function(context) {
        return this.get_element();
    },

    get_dragMode : function() {
        return Sys.Preview.UI.DragMode.Move;
    },

    onDragStart : function() {
        //debug.trace('Drag and Drop started');
        
        this._dragStartLocation = Sys.UI.DomElement.getLocation(this.get_element());
    },

    onDrag : function() {
    },

    onDragEnd : function(cancelled) {
        //debug.trace('Drag and Drop ended');
        
        var element = this.get_element();
        Sys.UI.DomElement.setLocation(element, this._dragStartLocation.x, this._dragStartLocation.y);
        
        if (!cancelled) {
            this._addToCartElement.onclick();
        }
    },
    
    get_addToCartElement : function() {
        return this._addToCartElement;
    },

    set_addToCartElement : function(value) {
        this._addToCartElement = value;
    }
}
Samples.BookItem.registerClass('Samples.BookItem', 
    Sys.UI.Behavior, Sys.Preview.UI.IDragSource);
