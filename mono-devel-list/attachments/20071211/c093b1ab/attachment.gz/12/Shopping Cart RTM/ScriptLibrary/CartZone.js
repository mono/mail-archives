﻿Type.registerNamespace('Samples');

Samples.CartZone = function(element) {
    Samples.CartZone.initializeBase(this, [element]);
}
Samples.CartZone.prototype = {
    initialize : function() {
        Samples.CartZone.callBaseMethod(this, 'initialize');
        Sys.Preview.UI.DragDropManager.registerDropTarget(this);
    },
    
    dispose : function() {
        Sys.Preview.UI.DragDropManager.unregisterDropTarget(this);
        Samples.CartZone.callBaseMethod(this, 'dispose');
    },
    
    get_dropTargetElement : function() {
        //debug.trace('dropTargetElement');
        return this.get_element();
    },

    canDrop : function(dragMode, dataType, dragData) {
        //debug.trace('canDrop');
        return dataType == '__bookItem';
    },

    drop : function(dragMode, dataType, dragData) {
        //debug.trace('Item dropped');
    },

    onDragEnterTarget : function(dragMode, dataType, dragData) {
        this.get_element().style.backgroundColor = '#EFEFEF';
    },

    onDragInTarget : function(dragMode, dataType, dragData) {
    },

    onDragLeaveTarget : function(dragMode, dataType, dragData) {
        this.get_element().style.backgroundColor = '#FFFFFF';
    }
}
Samples.CartZone.registerClass('Samples.CartZone', 
    Sys.UI.Behavior, Sys.Preview.UI.IDropTarget);
