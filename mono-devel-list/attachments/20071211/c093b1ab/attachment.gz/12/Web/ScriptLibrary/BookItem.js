﻿Type.registerNamespace('Samples');

Samples.BookItem = function(element) {
   Samples.BookItem.initializeBase(this, [element]);
   
   this._bookId = null;                                                  
   this._dragStartLocation = null;                                       
}
Samples.BookItem.prototype = {
    initialize : function() {
        Samples.BookItem.callBaseMethod(this, 'initialize');
        
        $addHandlers(this.get_element(),                          
            {mousedown:this._onMouseDown}, this);               
    },
    
    dispose : function() {
        $clearHandlers(this.get_element());
        Samples.BookItem.callBaseMethod(this, 'dispose');
    },
    
    _onMouseDown : function(evt) {                                
        window._event = evt;                                      
        evt.preventDefault();                                     
                                                                  
        Sys.Preview.UI.DragDropManager.startDragDrop(this,        
            this.get_element(), null);                                      
    }, 
    
    get_dragDataType : function() {                                  
        return '__bookItem';                                         
    },

    getDragData : function(context) {
        return this.get_element();
    },

    get_dragMode : function() {
        return Sys.Preview.UI.DragMode.Move;                         
    },

    onDragStart : function() {
        Sys.Debug.trace('Drag and Drop started');
        
        this._dragStartLocation =                                    
            Sys.UI.DomElement.getLocation(this.get_element());       
    },

    onDrag : function() {
    },

    onDragEnd : function(cancelled) {
        Sys.Debug.trace('Drag and Drop ended');
        
        var element = this.get_element();
        
        if (cancelled) {
            Sys.UI.DomElement.setLocation(element, this._dragStartLocation.x, 
                this._dragStartLocation.y);                                   
        }
        else {
            alert('Item dropped! ISBN code: ' + this.get_bookId());
        }
    },

    get_bookId : function() {                                        
        return this._bookId;                                      
    },                                                            
                                                                  
    set_bookId : function(value) {                                
        this._bookId = value;                                     
    }                                                             
}
Samples.BookItem.registerClass('Samples.BookItem', Sys.UI.Control, Sys.Preview.UI.IDragSource);
