using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Runtime.InteropServices;

namespace ManagedEndianTest
{
	internal class ManagedEndianTest
	{
		[StructLayout(LayoutKind.Explicit)]
		private struct ExplicitLayout
		{
			[FieldOffset(0)]
			internal byte Byte0;
			[FieldOffset(1)]
			internal byte Byte1;
			[FieldOffset(2)]
			internal byte Byte2;
			[FieldOffset(3)]
			internal byte Byte3;
			[FieldOffset(0)]
			internal int Int32;
		}

		private static void Main()
		{
			byte[] byteArray = {0x12, 0x34, 0x56, 0x78};

			{
				Console.WriteLine("BinaryReader.ReadInt32: " + GetEndianness(new BinaryReader(new MemoryStream(byteArray)).ReadInt32()));
			}
			{
				Bitmap bitmap = new Bitmap(1, 1, PixelFormat.Format32bppArgb);
				BitmapData bitmapData = bitmap.LockBits(new Rectangle(0, 0, 1, 1), ImageLockMode.WriteOnly, PixelFormat.Format32bppArgb);
				Marshal.Copy(byteArray, 0, bitmapData.Scan0, 4);
				bitmap.UnlockBits(bitmapData);
				Console.WriteLine("Bitmap.LockBits:        " + GetEndianness(bitmap.GetPixel(0, 0).ToArgb()));
			}
			{
				int[] intArray = new int[1];
				Buffer.BlockCopy(byteArray, 0, intArray, 0, 4);
				Console.WriteLine("Buffer.BlockCopy:       " + GetEndianness(intArray[0]));
			}
			{
				ExplicitLayout explicitLayout = new ExplicitLayout();
				explicitLayout.Byte0 = byteArray[0];
				explicitLayout.Byte1 = byteArray[1];
				explicitLayout.Byte2 = byteArray[2];
				explicitLayout.Byte3 = byteArray[3];
				Console.WriteLine("LayoutKind.Explicit:    " + GetEndianness(explicitLayout.Int32));
			}
			{
				IntPtr unmanagedPointer = Marshal.AllocHGlobal(4);
				Marshal.Copy(byteArray, 0, unmanagedPointer, 4);
				Console.WriteLine("Marshal.Copy:           " + GetEndianness(Marshal.ReadInt32(unmanagedPointer)));
				Marshal.FreeHGlobal(unmanagedPointer);
			}
			{
				IntPtr unmanagedPointer = Marshal.AllocHGlobal(4);
				for (int index = 0; index < 4; index++)
					Marshal.WriteByte(unmanagedPointer, index, byteArray[index]);
				Console.WriteLine("Marshal.WriteByte:      " + GetEndianness(Marshal.ReadInt32(unmanagedPointer)));
				Marshal.FreeHGlobal(unmanagedPointer);
			}
			unsafe
			{
				fixed (byte* byteArrayPointer = byteArray)
					Console.WriteLine("Unsafe code:            " + GetEndianness(*(int*)byteArrayPointer));
			}

			Console.ReadLine();
		}

		private static string GetEndianness(int number)
		{
			switch (number)
			{
				case 0x12345678:
					return "big-endian";
				case 0x78563412:
					return "little-endian";
				default:
					return "unknown: 0x" + number.ToString("x8");
			}
		}
	}
}
