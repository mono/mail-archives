using System;
using System.Drawing;
using System.Configuration;
using System.Windows.Forms;

class Program
{
	static void Main ()
	{
		Application.Run (new MainForm ());
	}
}

class MainFormSettings : ApplicationSettingsBase
{
        [UserScopedSetting]
	[DefaultSettingValue("0, 0")]
	public virtual Point Location
	{
		get { return (Point)this["Location"]; }
		set { this["Location"] = value; }
	}
}

class MainForm : Form
{
	MainFormSettings settings = new MainFormSettings ();

	public MainForm ()
	{
		StartPosition = FormStartPosition.Manual;
		Location = settings.Location;
	}

	protected override void OnClosed (EventArgs e)
	{
		settings.Location = Location;
		settings.Save ();
		base.OnClosed (e);
	}
}
