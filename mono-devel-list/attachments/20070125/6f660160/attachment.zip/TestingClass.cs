using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Runtime.Serialization.Formatters.Binary;
using System.Reflection;

using System.ComponentModel;
using System.Drawing;
using System.Globalization;

namespace Aulofee.SerializationTester
{
	class TestingClass
	{
		#region Fields
		const string default_ext = ".bin_test";
		static BinaryFormatter _bf = new BinaryFormatter();
		static StreamWriter _logWriter;
		static int _successCount = 0;
		static int _errorCount = 0;

		#endregion Fields

		#region Main method
		static void Main(string[] args)
		{
			if (args.Length == 0)
			{
				Console.WriteLine("Argument should be either 'read' or 'write' (without quotation mark)");
				_errorCount++;
				return;
			}

			if (args[0] == "write")
				SerializeMostAssemblyTypesAndWriteToFiles(typeof(Guid).Assembly);
			else if (args[0] == "read")
				ReadFilesAndDeserialize();
			else
			{
				Console.WriteLine("Argument should be either 'read' or 'write' (without quotation mark)");
				_errorCount++;
			}

			Console.ReadLine();
		}

		#endregion Main method
        
		#region Methods
		/// <summary>
		/// Opens all the files ending with <see cref="default_ext"/> in the application's directory and deserializes
		/// their content by calling <see cref="ReadFileAndDeserialize"/>.
		/// </summary>
		static void ReadFilesAndDeserialize()
		{
			using (_logWriter = new StreamWriter("log_read.txt")) // Overwrite if file exists.
			{
				string[] testfiles = Directory.GetFiles(Directory.GetCurrentDirectory(), "*" + default_ext);
				foreach (string filename in testfiles)
					ReadFileAndDeserialize(filename);

				Console.WriteLine("Program done. " + _successCount + " success, " + _errorCount.ToString() + " error(s)");
				_logWriter.WriteLine("Program done. " + _successCount + " success, " + _errorCount.ToString() + " error(s)");
			}
		}

		/// <summary>
		/// Opens the given file and deserializes its content.
		/// </summary>
		/// <param name="filename">The name of the file whose content will be deserialized.</param>
		static object ReadFileAndDeserialize(string filename)
		{
			string shortName = Path.GetFileName(filename);

			try
			{
				using (FileStream ms = new FileStream(filename, FileMode.Open, FileAccess.Read))
				{
					object o = _bf.Deserialize(ms);
					Console.WriteLine("Successfully deserialized file: " + shortName);
					_logWriter.WriteLine("Successfully deserialized file: " + shortName);
					_successCount++;
					return o;
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine("Failed to deserialize file: " + shortName);
				_logWriter.WriteLine("Failed to deserialize file: " + shortName);
				_logWriter.WriteLine(ex.ToString());
				_logWriter.WriteLine("----------------------------------------------------------------------");

				_errorCount++;
				return null;
			}
		}

		/// <summary>
		/// Instantiates all the exported types which are both serializable and instantiable from an assembly (by calling 
		/// <see cref="GetExportedSerializedInstantiableTypes"/>), and serializes them into a file whose name is deduced
		/// from the type's name (by calling <see cref="SerializeAndWriteToFile"/>).
		/// </summary>
		/// <param name="assembly">The <see cref="Assembly"/> to explore.</param>
		/// <remarks>
		/// Note: The instantion of the types could be improved. We today use Activator.CreateInstance, which obviously
		/// fails when there is no constructor without argument (next version...)
		/// </remarks>
		static void SerializeMostAssemblyTypesAndWriteToFiles(Assembly assembly)
		{
			using (_logWriter = new StreamWriter("log_write.txt")) // Overwrite if file exists.
			{
				//SerializeAndWriteToFile(DateTimeFormatInfo.InvariantInfo, null);
				//SerializeAndWriteToFile(DateTime.Now, null);
				//SerializeAndWriteToFile(Guid.NewGuid(), null);
				//SerializeAndWriteToFile(new Rectangle(10, 20, 30, 40), null);
				//SerializeAndWriteToFile(new ArrayList(new int[] { 1, 2, 4, 6, 8 }), null);

				List<Type> systemTypes = GetExportedSerializedInstantiableTypes(assembly);
				_logWriter.WriteLine("Got " + systemTypes.Count + " types from " + assembly.GetName().Name);
				foreach (Type t in systemTypes)
				{
					object o;
					try
					{
						// TODO Should use t.GetConstructors() to see if we must use arguments. Next version...
						o = Activator.CreateInstance(t);
					}
					catch
					{
						Console.WriteLine("Cannot create type with Activator.CreateInstance: " + t.FullName);
						_logWriter.WriteLine("Cannot create type with Activator.CreateInstance: " + t.FullName);
						_errorCount++;
						continue;
					}
					SerializeAndWriteToFile(o, null);

				}

				Console.WriteLine("Program done. " + _successCount + " success, " + _errorCount.ToString() + " error(s)");
				_logWriter.WriteLine("Program done. " + _successCount + " success, " + _errorCount.ToString() + " error(s)");
			}
		}

		/// <summary>
		/// Serializes a <see cref="Type"/> into a file (with binary serialization).
		/// </summary>
		/// <param name="obj">The object to serialize. If <c>null</c>, the method does nothing.</param>
		/// <param name="filename">The filename to write to. If <c>null</c>, the method deduces it from the type of
		/// <paramref name="obj"/>.</param>
		static void SerializeAndWriteToFile(object obj, string filename)
		{
			if (obj == null)
				return;
			if (filename == null)
				filename = obj.GetType().ToString() + default_ext;

			try
			{
				using (FileStream ms = new FileStream(filename, FileMode.Create))
				{
					_bf.Serialize(ms, obj);
					Console.WriteLine("Successfully serialized object of type: " + obj.GetType().ToString());
					_logWriter.WriteLine("Successfully serialized object of type: " + obj.GetType().ToString());
					_successCount++;
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine("Failed to serialize object of type: " + obj.GetType().ToString());
				_logWriter.WriteLine("Failed to serialize object of type: " + obj.GetType().ToString());
				_logWriter.WriteLine(ex.ToString());
				_logWriter.WriteLine("----------------------------------------------------------------------");
				_errorCount++;
			}
		}

		/// <summary>
		/// Returns all the exported types which are both serializable and instantiable from an assembly.
		/// </summary>
		/// <param name="assembly">The <see cref="Assembly"/> to explore.</param>
		/// <remarks>
		/// Note: The tests again the types could be strengthened a bit (next version...)
		/// </remarks>
		static List<Type> GetExportedSerializedInstantiableTypes(Assembly assembly)
		{
			List<Type> expSerTypes = new List<Type>();
			Type[] expTypes = assembly.GetExportedTypes();
			foreach (Type t in expTypes)
				if (t.IsSerializable && !t.IsAbstract && !t.IsInterface && !t.ContainsGenericParameters)
					expSerTypes.Add(t);

			return expSerTypes;
		}

		#endregion Methods
	}
}

