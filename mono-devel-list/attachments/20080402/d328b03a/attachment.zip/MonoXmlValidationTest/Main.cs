using System;
using System.IO;
using System.Xml;
using System.Xml.Schema;

namespace MonoXmlValidationTest
{
	class MainClass
	{
		public static void Main(string[] args)
		{
			XmlReader reader = new XmlTextReader(File.OpenRead("EnrollmentRequest.hbm.xml"));
			XmlValidatingReader validatingReader = new XmlValidatingReader(reader);
		
			XmlSchemaCollection mappingSchemaCollection = new XmlSchemaCollection();
			mappingSchemaCollection.Add(XmlSchema.Read(File.OpenRead("nhibernate-mapping.xsd"), null));
			
			XmlDocument hbmDocument = new XmlDocument();
			validatingReader.ValidationEventHandler += new ValidationEventHandler(ValidationHandler);
			validatingReader.ValidationType = ValidationType.Schema;
			validatingReader.Schemas.Add(mappingSchemaCollection);
			
			hbmDocument.Load(validatingReader);
		}
		private static void ValidationHandler(object o, ValidationEventArgs args)
		{
			string message = string.Format("{0} {1} {2}", args.Exception.LineNumber, args.Exception.LinePosition,
                args.Exception.Message);
			throw new Exception(message);
		}
	}
}