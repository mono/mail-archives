#!/usr/bin/perl

use strict;

my @addrs = @ARGV;
my @addr_nums = map(oct, @addrs);

LINE: while (<STDIN>) {
    while (/(0x[0-9a-f]+)-(0x[0-9a-f]+)/g) {
	my $start = oct $1;
	my $end = oct $2;
	foreach my $addr (@addr_nums) {
	    if ($addr >= $start && $addr < $end) {
		print;
		next LINE;
	    }
	}
    }
    while (/[^-](0x[0-9a-f]+)/g) {
	my $num = oct $1;
	foreach my $addr (@addr_nums) {
	    if ($addr == $num) {
		print;
		next LINE;
	    }
	}
    }
    if (/Allocated( pinned| large)? object (0x[0-9a-f]+),.+, size: (\d+)/) {
	my $start = oct $2;
	my $length = $3;
	my $end = $start + $length;
	foreach my $addr (@addr_nums) {
	    if ($addr >= $start && $addr < $end) {
		print;
		next LINE;
	    }
	}
    }
    if (/Allocated pinned chunk (0x[0-9a-f]+), size: (\d+)/) {
	my $start = oct $1;
	my $length = $2;
	my $end = $start + $length;
	foreach my $addr (@addr_nums) {
	    if ($addr >= $start && $addr < $end) {
		print;
		next LINE;
	    }
	}
    }
    if (/Precise copy of (0x[0-9a-f]+) \(to (0x[0-9a-f]+), .* size: (\d+)\)/) {
	my $start_old = oct $1;
	my $start_new = oct $2;
	my $length = $3;
	my $end_old = $start_old + $length;
	my $end_new = $start_new + $length;
	foreach my $addr (@addr_nums) {
	    if (($addr >= $start_old && $addr < $end_old) || ($addr >= $start_new && $addr < $end_new)) {
		print;
		next LINE;
	    }
	}
    }
    if (/Start (nursery|major) collection|Clearing domain|alloced refobject_hash|marking mono hash table/) {
	print;
	next LINE;
    }
}
