using System;
using System.Collections;
using System.ComponentModel;
using System.Web;
using System.Web.SessionState;
using System.Web.Security;
using System.Security.Principal;

namespace testlogin 
{
	/// <summary>
	/// Summary description for Global.
	/// </summary>
	public class Global : System.Web.HttpApplication
	{
		const string mycookie = "TestCookie";

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		public Global()
		{
			InitializeComponent();
		}	
		
		protected void Application_Start(Object sender, EventArgs e)
		{

		}
 
		protected void Session_Start(Object sender, EventArgs e)
		{

		}

		protected void Application_BeginRequest(Object sender, EventArgs e)
		{

		}

		protected void Application_EndRequest(Object sender, EventArgs e)
		{

		}

		protected void Application_AuthenticateRequest(Object sender, EventArgs e)
		{
			if(Request.IsAuthenticated)
			{
				String[] roles = null;

				if((Request.Cookies[mycookie] == null)||(Request.Cookies[mycookie].Value == ""))
				{
					FormsAuthenticationTicket ticket = new FormsAuthenticationTicket(
						1,
						Context.User.Identity.Name,
						DateTime.Now,
						DateTime.Now.AddHours(1),
						false,
						"MyRole"
						);

					string cookiestr = FormsAuthentication.Encrypt(ticket);

					Response.Cookies[mycookie].Value = cookiestr;
					Response.Cookies[mycookie].Path = Request.ApplicationPath;
					Response.Cookies[mycookie].Expires = DateTime.Now.AddMinutes(5);
				}
				else
				{
					FormsAuthenticationTicket ticket = FormsAuthentication.Decrypt(Context.Request.Cookies[mycookie].Value);

					if(ticket.Name != Context.User.Identity.Name)
					{
						Context.Response.Cookies[mycookie].Expires = DateTime.Now;
						return;
					}
					else
					{
						ArrayList userRoles = new ArrayList();

						foreach (String role in ticket.UserData.Split( new char[] {';'} )) 
						{
							userRoles.Add(role);
						}

						roles = (String[]) userRoles.ToArray(typeof(String));
					}
				}
				Context.User = new GenericPrincipal(Context.User.Identity, roles);
			}
		}

		protected void Application_Error(Object sender, EventArgs e)
		{

		}

		protected void Session_End(Object sender, EventArgs e)
		{

		}

		protected void Application_End(Object sender, EventArgs e)
		{

		}
			
		#region Web Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.components = new System.ComponentModel.Container();
		}
		#endregion
	}
}

