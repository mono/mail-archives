﻿using System;
using System.Diagnostics;
using System.Windows.Forms;

namespace ComboBoxTest
{
	internal sealed class Assert
	{
		public static void AreEqual<T> (T a_correct, T a_found,
			string a_strMessage)
		{
			if (!a_correct.Equals (a_found))
				MessageBox.Show (a_strMessage
					+ ": expected " + a_correct.ToString()
					+ ", found " + a_found.ToString());
		}
		public static void AreNotEqual<T> (T a_correct, T a_found,
			string a_strMessage)
		{
			string strCorrect, strFound;
			bool bEquals = false;

			if (a_correct == null)
			{
				strCorrect = "null";
				if (a_found == null)
					bEquals = true;
			}
			else
			{
				strCorrect = a_correct.ToString();
				bEquals = a_correct.Equals (a_found);
			}
			strFound = (a_found == null) ? "null" : a_found.ToString();
			if (bEquals)
				MessageBox.Show (a_strMessage
					+ ": expected not " + strCorrect
					+ ", found " + strFound);
		}
		public static void IsNotNull<T> (T a_found, string a_strMessage)
		{
			AreNotEqual<T> (default (T), a_found, a_strMessage);
		}
	}
    internal sealed class Program
    {
		private class MyForm : Form
		{
			internal MyForm()
			: base()
			{
				this.Closed += new EventHandler (this_Closed);
				this.Load += new EventHandler (this_Load);
			}
			internal void this_Load (object sender, EventArgs e)
			{
				ComboBox cmbbox = new ComboBox ();
				//cmbbox.DropDownStyle = ComboBoxStyle.DropDownList;
				cmbbox.Parent = this;

				//Thread.CurrentThread.CurrentCulture = new CultureInfo ("tr-TR");

				//ComboBox cmbbox = new ComboBox ();
				Assert.IsNotNull (cmbbox.Text, "#A1");
				Assert.AreEqual (string.Empty, cmbbox.Text, "#A2");
				Assert.AreEqual (-1, cmbbox.SelectedIndex, "#A3");

				cmbbox.Items.Add ("Another");
				cmbbox.Items.Add ("Bad");
				cmbbox.Items.Add ("IN");
				cmbbox.Items.Add ("Combobox");
				cmbbox.Items.Add ("BAD");
				cmbbox.Items.Add ("iN");
				cmbbox.Items.Add ("Bad");

				Assert.IsNotNull (cmbbox.Text, "#B1");
				Assert.AreEqual (string.Empty, cmbbox.Text, "#B2");
				Assert.AreEqual (-1, cmbbox.SelectedIndex, "#B3");

				cmbbox.SelectedIndex = 3;
				Assert.IsNotNull (cmbbox.Text, "#C1");
				Assert.AreEqual ("Combobox", cmbbox.Text, "#C2");
				Assert.AreEqual (3, cmbbox.SelectedIndex, "#C3");

				cmbbox.Text = string.Empty;
				Assert.IsNotNull (cmbbox.Text, "#D1");
				Assert.AreEqual (string.Empty, cmbbox.Text, "#D2");
				Assert.AreEqual (3, cmbbox.SelectedIndex, "#D3");

				cmbbox.SelectedIndex = 1;
				Assert.IsNotNull (cmbbox.Text, "#E1");
				Assert.AreEqual ("Bad", cmbbox.Text, "#E2");
				Assert.AreEqual (1, cmbbox.SelectedIndex, "#E3");

				cmbbox.Text = null;
				Assert.IsNotNull (cmbbox.Text, "#F1");
				Assert.AreEqual (string.Empty, cmbbox.Text, "#F2");
				Assert.AreEqual (-1, cmbbox.SelectedIndex, "#F3");

				cmbbox.SelectedIndex = 0;
				cmbbox.Text = "Q";
				Assert.IsNotNull (cmbbox.Text, "#G1");
				Assert.AreEqual ("Q", cmbbox.Text, "#G2");
				Assert.AreEqual (0, cmbbox.SelectedIndex, "#G3");

				cmbbox.Text = "B";
				Assert.IsNotNull (cmbbox.Text, "#H1");
				Assert.AreEqual ("B", cmbbox.Text, "#H2");
				Assert.AreEqual (0, cmbbox.SelectedIndex, "#H3");

				cmbbox.Text = "BAD";
				Assert.IsNotNull (cmbbox.Text, "#I1");
				Assert.AreEqual ("BAD", cmbbox.Text, "#I2");
				Assert.AreEqual (4, cmbbox.SelectedIndex, "#I3");

				cmbbox.Text = "BAD";
				Assert.IsNotNull (cmbbox.Text, "#J1");
				Assert.AreEqual ("BAD", cmbbox.Text, "#J2");
				Assert.AreEqual (4, cmbbox.SelectedIndex, "#J3");

				cmbbox.Text = "Something";
				Assert.IsNotNull (cmbbox.Text, "#T1");
				Assert.AreEqual ("Something", cmbbox.Text, "#T2");
				Assert.AreEqual (4, cmbbox.SelectedIndex, "#T3");

				cmbbox.Text = "BAD";
				Assert.IsNotNull (cmbbox.Text, "#U1");
				Assert.AreEqual ("BAD", cmbbox.Text, "#U2");
				Assert.AreEqual (4, cmbbox.SelectedIndex, "#U3");

				cmbbox.Text = "baD";
				Assert.IsNotNull (cmbbox.Text, "#K1");
				Assert.AreEqual ("Bad", cmbbox.Text, "#K2");
				Assert.AreEqual (1, cmbbox.SelectedIndex, "#K3");

				cmbbox.SelectedIndex = -1;
				cmbbox.Text = "E";
				Assert.IsNotNull (cmbbox.Text, "#L1");
				Assert.AreEqual ("E", cmbbox.Text, "#L2");
				Assert.AreEqual (-1, cmbbox.SelectedIndex, "#L3");

				cmbbox.Text = "iN";
				Assert.IsNotNull (cmbbox.Text, "#M1");
				Assert.AreEqual ("iN", cmbbox.Text, "#M2");
				Assert.AreEqual (5, cmbbox.SelectedIndex, "#M3");

				cmbbox.Text = "In";
				Assert.IsNotNull (cmbbox.Text, "#N1");
				Assert.AreEqual ("IN", cmbbox.Text, "#N2");
				Assert.AreEqual (2, cmbbox.SelectedIndex, "#N3");

				cmbbox.Text = "Badd";
				Assert.IsNotNull (cmbbox.Text, "#O1");
				Assert.AreEqual ("Badd", cmbbox.Text, "#O2");
				Assert.AreEqual (2, cmbbox.SelectedIndex, "#O3");

				cmbbox.SelectedIndex = -1;
				Assert.IsNotNull (cmbbox.Text, "#P1");
				Assert.AreEqual (string.Empty, cmbbox.Text, "#P2");
				Assert.AreEqual (-1, cmbbox.SelectedIndex, "#P3");

				cmbbox.Text = "Something";
				Assert.IsNotNull (cmbbox.Text, "#Q1");
				Assert.AreEqual ("Something", cmbbox.Text, "#Q2");
				Assert.AreEqual (-1, cmbbox.SelectedIndex, "#Q3");

				cmbbox.SelectedIndex = -1;
				Assert.IsNotNull (cmbbox.Text, "#R1");
				Assert.AreEqual ("Something", cmbbox.Text, "#R2");
				Assert.AreEqual (-1, cmbbox.SelectedIndex, "#R3");

				cmbbox.Text = null;
				Assert.IsNotNull (cmbbox.Text, "#S1");
				Assert.AreEqual (string.Empty, cmbbox.Text, "#S2");
				Assert.AreEqual (-1, cmbbox.SelectedIndex, "#S3");
			}
			internal void this_Closed (object sender, EventArgs e)
			{
				Application.Exit();
			}
		}

        [STAThread]
        private static void Main(string[] args)
        {
			// Create a form with a combo box.
			Form form = new MyForm ();
			form.ShowInTaskbar = false;
			form.Show ();

			// Display the results.
			Application.Run();
        }
    }
}
