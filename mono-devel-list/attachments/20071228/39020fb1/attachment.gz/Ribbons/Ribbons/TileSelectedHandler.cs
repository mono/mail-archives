using System;

namespace Ribbons
{
	public delegate void TileSelectedHandler(object Sender, TileSelectedEventArgs e);
}
