using System;

namespace Ribbons
{
	public delegate void PageRemovedHandler(object Sender, PageEventArgs Args);
}
