using System;

namespace Ribbons
{
	/// <summary>Position of a widget in a group of widget.</summary>
	public enum GroupStyle
	{
		Alone, Left, Center, Right
	}
}
