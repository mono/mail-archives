using System;

namespace Ribbons
{
	public delegate void PageMovedHandler(object Sender, PageEventArgs Args);
}
