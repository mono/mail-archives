using System;

namespace Ribbons
{
	public delegate void PageSelectedHandler(object Sender, PageEventArgs Args);
}
