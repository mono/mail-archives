using System;

namespace Ribbons
{
	public delegate void PageAddedHandler(object Sender, PageEventArgs Args);
}
