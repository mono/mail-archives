﻿using System;
using System.Diagnostics;
using System.Windows.Forms;

namespace ComboBoxTest
{
	internal sealed class Assert
	{
		public static void AreEqual<T> (T a_correct, T a_found,
			string a_strMessage)
		{
			if (!a_correct.Equals (a_found))
				MessageBox.Show (a_strMessage
					+ ": expected " + a_correct.ToString()
					+ ", found " + a_found.ToString());
		}
		public static void AreNotEqual<T> (T a_correct, T a_found,
			string a_strMessage)
		{
			string strCorrect, strFound;
			bool bEquals = false;

			if (a_correct == null)
			{
				strCorrect = "null";
				if (a_found == null)
					bEquals = true;
			}
			else
			{
				strCorrect = a_correct.ToString();
				bEquals = a_correct.Equals (a_found);
			}
			strFound = (a_found == null) ? "null" : a_found.ToString();
			if (bEquals)
				MessageBox.Show (a_strMessage
					+ ": expected not " + strCorrect
					+ ", found " + strFound);
		}
		public static void IsNotNull<T> (T a_found, string a_strMessage)
		{
			AreNotEqual<T> (default (T), a_found, a_strMessage);
		}
	}
    internal sealed class Program
    {
		private class MyForm : Form
		{
			internal MyForm()
			: base()
			{
				this.Closed += new EventHandler (this_Closed);
				this.Load += new EventHandler (this_Load);
			}
			internal void this_Load (object sender, EventArgs e)
			{
				// A control with both rowspan and columnspan > 1 was getting
				// other controls put into its extent (i.e. c3 was ending up
				// at (1,1) instead of (2,1).
				TableLayoutPanel p = new TableLayoutPanel ();
				p.Parent = this;
				Control c1 = new Button ();
				Control c2 = new Button ();
				Control c3 = new Button ();

				p.ColumnCount = 3;
				p.RowCount = 3;

				p.SetRowSpan (c1, 2);
				p.SetColumnSpan (c1, 2);
				p.SetCellPosition (c1, new TableLayoutPanelCellPosition (0, 0));

				p.Controls.Add (c1);
				p.Controls.Add (c2);
				p.Controls.Add (c3);

				Assert.AreEqual (new TableLayoutPanelCellPosition (0, 0), p.GetPositionFromControl (c1), "C1");
				Assert.AreEqual (new TableLayoutPanelCellPosition (2, 0), p.GetPositionFromControl (c2), "C2");
				Assert.AreEqual (new TableLayoutPanelCellPosition (2, 1), p.GetPositionFromControl (c3), "C3");
			}
			internal void this_Closed (object sender, EventArgs e)
			{
				Application.Exit();
			}
		}

        [STAThread]
        private static void Main(string[] args)
        {
			// Create a form with a combo box.
			Form form = new MyForm ();
			form.ShowInTaskbar = false;
			form.Show ();

			// Display the results.
			Application.Run();
        }
    }
}
