// project created on 20/05/2003 at 16:55
using System;
using System.Collections;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Http;


using TestAssembly;

class MainClass
{
	public static void Main(string[] args)
	{
		Console.WriteLine("Client !");
		
		IDictionary channelProps = new Hashtable();
		channelProps["name"] = "http";
		channelProps["port"] = 0;
		
		IClientChannelSinkProvider clientChannelSinkProvider = new SoapClientFormatterSinkProvider();
		IServerChannelSinkProvider serverChannelSinkProvider = new SoapServerFormatterSinkProvider();
		HttpChannel chn = new HttpChannel(channelProps, clientChannelSinkProvider, serverChannelSinkProvider);
		ChannelServices.RegisterChannel(chn);
		
		RemotingConfiguration.RegisterActivatedClientType(typeof(MarshalObject), "http://localhost:4000");
	
		
		MarshalObject objMarshal = new MarshalObject();

		Console.WriteLine(objMarshal.Method2(6));
		objMarshal.Method3(0, "donald", new string[] {"riri", "fifi", "loulou"}, new OtherObject(8));
		
		string uncle;
		objMarshal.Method4(out uncle);
		Console.WriteLine(uncle);
		string deux, quatre;
		long ret = objMarshal.Method5(15, out deux, 145, out quatre);
		Console.WriteLine("ret:{0} deux:{1} quatre:{2}", ret, deux, quatre);
		objMarshal.Method1();

	}
}
