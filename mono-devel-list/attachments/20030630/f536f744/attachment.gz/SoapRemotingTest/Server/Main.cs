using System;
using System.Collections;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Http;

using TestAssembly;

class MainClass
{
	public static void Main(string[] args)
	{
		Console.WriteLine("Server !");
		
		IDictionary channelProps = new Hashtable();
		channelProps["name"] = "http";
		channelProps["port"] = 4000;
		IClientChannelSinkProvider clientSinkProvider = new SoapClientFormatterSinkProvider();
		IServerChannelSinkProvider serverSinkProvider = new SoapServerFormatterSinkProvider();
		HttpChannel chn = new HttpChannel(channelProps, clientSinkProvider, serverSinkProvider);
		ChannelServices.RegisterChannel(chn);
		
		RemotingConfiguration.RegisterActivatedServiceType(typeof(MarshalObject));
		
		Console.ReadLine();
	}
}
