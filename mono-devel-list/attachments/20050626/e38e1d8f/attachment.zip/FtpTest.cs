//
// FtpTest.cs: A sample for FtpWebRequest
//
// Author:
//      Martin Hinks <m.hinks@gmail.com>
//
// Copyright (C) 2004-2005 Novell, Inc. (http://www.novell.com)
//
// Permission is hereby granted, free of charge, to any person obtaining
// a copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to
// permit persons to whom the Software is furnished to do so, subject to
// the following conditions:
// 
// The above copyright notice and this permission notice shall be
// included in all copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
// NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
// LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
// OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
// WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
//



using System;
using System.Net;
using System.Net.Sockets;
using System.IO;

namespace FTPTest
{
	class MainClass
	{
		public static void Main(string[] args)
		{
			Console.WriteLine("FtpWebRequest Test");
			Console.WriteLine("M.Hinks 2005");
			System.Console.WriteLine("");
			
			if(args.GetUpperBound(0) != 0){
				System.Console.WriteLine("Usage: FtpTest.exe [ftp://<URL>] or [ftps://<URL>]");
			} else {
			
			
				FtpRequestCreator Creator = new FtpRequestCreator();
				WebRequest.RegisterPrefix("ftp:", Creator);
				WebRequest.RegisterPrefix("ftps:", Creator);
				
				FtpWebRequest test = WebRequest.Create(args[0]) as FtpWebRequest;

				test.UsePassive = true;
				test.KeepAlive = true;
				test.Timeout = 5000;
				//test.EnableSSL = false;
				
				test.Method = FtpMethods.Connect;
				FtpWebResponse resp = (FtpWebResponse)test.GetResponse();
				
				
				
				test.Method = FtpMethods.UserName;
				resp = (FtpWebResponse)test.GetResponse();
				
				test.Method = FtpMethods.Password;
				resp = (FtpWebResponse)test.GetResponse();
				
				test.Method = FtpMethods.SYST;
				resp = (FtpWebResponse)test.GetResponse();
				
				test.Method = FtpMethods.List;
				resp = (FtpWebResponse)test.GetResponse();
				
				//Get a NetworkStream for the data stream
				//Because this is just a list I load the data into a
				//nice MemoryStream object
				
				Stream nS = (Stream)test.GetRequestStream();
		  		MemoryStream ms = new MemoryStream();
		  		
		  		int BufferSize = 256;
		   		Byte [] recvbuffer = new Byte[BufferSize + 1]; 

				
				while(true) {
		   			int bytesread = 0;
		   			recvbuffer[bytesread] = (Byte)'\0';        
		        	bytesread = nS.Read(recvbuffer, 0, 1 );      
		        	if( bytesread <= 0 ) 
		        		break;       
		        	ms.Write(recvbuffer,0,bytesread);                            
		 			}
				ms.Seek(0,0);
				
				//TODO: Write a List parser that will give a nice structure to listed data
				
				System.Console.WriteLine("List length: " + ms.Length);
				System.Console.WriteLine("List Contents: ");
				
				Byte[] ba = new Byte[ms.Length + 1];
				ms.Read (ba,0,(int)ms.Length);
				string list = System.Text.ASCIIEncoding.ASCII.GetString(ba);
				
				System.Console.WriteLine(list);
				
				System.Console.WriteLine("Client log:" + Environment.NewLine + test.log.ToString());
				System.Console.WriteLine("Server log:" + Environment.NewLine + resp.log.ToString());
				
				
				
				test = null;
			}
		}
	}
	
	public class FtpRequestCreator : IWebRequestCreate
  {
    public FtpRequestCreator()
    {
    }

    public WebRequest Create(Uri Url)

    {
      return new FtpWebRequest(Url);
    }
  }
	
   			
		

}
