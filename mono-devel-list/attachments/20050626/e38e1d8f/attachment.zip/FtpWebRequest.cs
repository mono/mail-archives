//
// FtpWebRequest.cs: Implementation of .NET Framework v2.0 class
// System.Net.FtpWebRequest
//
// Author:
//      Martin Hinks <m.hinks@gmail.com>
//
// Copyright (C) 2004-2005 Novell, Inc. (http://www.novell.com)
//
// Permission is hereby granted, free of charge, to any person obtaining
// a copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to
// permit persons to whom the Software is furnished to do so, subject to
// the following conditions:
// 
// The above copyright notice and this permission notice shall be
// included in all copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
// NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
// LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
// OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
// WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
//

using System;
using System.Collections;
using System.Configuration;
using System.IO;
using System.Net.Cache;
using System.Net.Sockets;
using System.Runtime.Remoting.Messaging;
using System.Runtime.Serialization;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading;

namespace System.Net
{
	/// <summary>
	/// Implements a File Transfer Protocol (FTP) client.
	/// </summary>
	
	[Serializable]
	public class FtpWebRequest : WebRequest, ISerializable
	{
		#region Variables
		Uri requestUri;
		Uri actualUri;
		//X509CertificateCollection certificates;
		ServicePoint servicePoint;
		IWebProxy proxy;
		ICredentials credentials;
		X509CertificateCollection clientCertificates;
		System.Threading.Thread worker;
		System.Threading.Thread dataThread;
		FtpWebResponse response;
		Stream dataStream;
		FtpAsyncResult asyncStream;
		FtpAsyncResult asyncResult;
		ICredentials m_Credentials;
		Socket controlSocket;
		Socket dataSocket;
		internal StringBuilder log = new StringBuilder();
		private Mono.Security.Protocol.Tls.SslClientStream SSL;
    	private System.Security.Cryptography.X509Certificates.X509CertificateCollection certificates = new System.Security.Cryptography.X509Certificates.X509CertificateCollection();
		Stream net;
		
		bool usePassive = false;		
		bool hostChanged = false;
		bool requestInProgress = false;		
		bool readInProgress = false;
		bool connected = false;
		bool useBinary = true;
		bool keepAlive = true;
		bool enableSSL = false;
		string renameTo;
		string method;
		string connectionGroupName;
		string userName;
		string password;
		int timeout = System.Threading.Timeout.Infinite;
		int readWriteTimeout = 300000;
		long contentOffset = 0;
		long contentLength;
		
		
		#endregion
		
		#region Static Variables
		static RequestCachePolicy defaultCachePolicy;
		#endregion
		
		#region Properties
		/// <summary>
   		/// FtpWebRequest.UsePassive Property
   		/// </summary>
   		/// <value>
   		/// Gets or sets the behavior of a client application's data transfer process.
   		/// </value>
   		/// <remarks>
   		/// Setting the System.Net.FtpWebRequest.UsePassive property to true sends the "PASV" command to the server. This command requests the server to listen on a data port and to wait for a connection rather than initiate one upon receipt of a transfer command.
		/// For a description of the behaviors that are specified using System.Net.FtpWebRequest.UsePassive, see RFC 959, "File Transfer Protocol," Section 3.2, "Establishing Data Connections" and Section 4.1.2, "Transfer Parameter Commands," available at http://www.rfc-editor.org/.
   		/// </remarks>
		public bool UsePassive {
			get { return usePassive; }
			set { usePassive = value; }
		}
   		
   		/// <summary>
   		/// FtpWebRequest.UseDefaultCredentials Property
   		/// </summary>
   		/// <value>
   		/// Always throws a System.NotSupportedException.
   		/// </value>
   		/// <remarks>
   		/// The System.Net.FtpWebRequest.UseDefaultCredentials property is provided only for compatibility with other implementations of the System.Net.WebRequest and System.Net.WebResponse classes. There is no reason to use System.Net.FtpWebRequest.UseDefaultCredentials.
   		/// </remarks>
   		/// <exception cref="System.NotSupportedException.">
   		/// Default Credentials are not supported for FTP.
		/// </exception>
		public bool UseDefaultCredentials {
			get { 
   				throw new NotSupportedException();
   			}
			set { 
   				throw new NotSupportedException();
   			}
		}
   		
   		
   		/// <summary>
   		/// FtpWebRequest.UseBinary Property
   		/// </summary>
   		/// <value>
   		/// Gets or sets a System.Boolean value that specifies the data type for file transfers.
   		/// </value>
   		/// <remarks>
   		/// If you are sending binary data, such as an image, set this property to true. If you are sending text, set the property to false. Specifying true causes the System.Net.FtpWebRequest to send a "TYPE I" command to the server. Specifying false causes the System.Net.FtpWebRequest to send a "Type A" command to the server. FTP servers can ignore these commands.
   		/// Changing System.Net.FtpWebRequest.UseBinary after calling the System.Net.FtpWebRequest.GetRequestStream, System.Net.FtpWebRequest.BeginGetRequestStream, System.Net.FtpWebRequest.GetResponse, or System.Net.FtpWebRequest.BeginGetResponse method causes an System.InvalidOperationException exception.
   		/// </remarks>
   		/// <exception cref="System.InvalidOperationException">
   		/// A new value was specified for this property for a request that is already in progress. 
		/// </exception>
		public bool UseBinary {
			get { return useBinary; }
			set { 
   				if(requestInProgress){
					throw new InvalidOperationException("An attempt was made to change the value while an operation was in progress.");
   				} else {
   					useBinary = value;
   				}
   			}	
		}
   		
   		
   		/// <summary>
   		/// FtpWebRequest.Timeout Property
   		/// </summary>
   		/// <value>
   		/// Gets or sets the number of milliseconds to wait for a request.
   		/// </value>
   		/// <remarks>
   		/// To specify an infinite value, set the System.Net.FtpWebRequest.Timeout property to System.Threading.Timeout.Infinite (-1). This is the default value.
   		/// System.Net.FtpWebRequest.Timeout is the number of milliseconds that a synchronous request made with the System.Net.FtpWebRequest.GetResponse method waits for a response and that the System.Net.FtpWebRequest.GetRequestStream method waits for a stream. If a resource does not respond within the time-out period, the request throws a System.Net.WebException exception with the System.Net.WebException.Status property set to System.Net.WebExceptionStatus.Timeout.
   		/// Changing System.Net.FtpWebRequest.Timeout after calling the System.Net.FtpWebRequest.GetRequestStream, System.Net.FtpWebRequest.BeginGetRequestStream, System.Net.FtpWebRequest.GetResponse, or System.Net.FtpWebRequest.BeginGetResponse method causes an System.InvalidOperationException exception.
   		/// </remarks>
   		/// <exception cref="System.InvalidOperationException">
   		/// A new value was specified for this property for a request that is already in progress. 
		/// </exception>
		/// <exception cref="System.ArgumentOutOfRangeException">
		/// The value specified is less than zero and is not System.Threading.Timeout.Infinite. 
		/// </exception>
		/// 
		public override int Timeout {
			get { 
   				return timeout;
   			}
			set { 
   					CheckRequestStarted() ;
					if(value <= 0 && value != System.Threading.Timeout.Infinite){
						throw new System.ArgumentOutOfRangeException("Timeout","Timeout must be greater than zero or System.Threading.Timeout.Infinite");
					} else {
						timeout = value;
					}
   			}
		}
		
		
		/// <summary>
   		/// FtpWebRequest.ServicePoint Property
   		/// </summary>
   		/// <value>
   		/// Gets the System.Net.ServicePoint object used to connect to the FTP server.
   		/// </value>
   		/// <remarks>
   		/// If no System.Net.ServicePoint object exists, one is created for the FTP server. To set the maximum number of connections open for an FTP server, set the System.Net.ServicePoint.ConnectionLimit property of the System.Net.ServicePoint instance returned by this property.
   		/// </remarks>
   		public ServicePoint ServicePoint {
			get { return GetServicePoint(); }
		}
   		
   		/// <summary>
   		/// FtpWebRequest.RequestUri Property
   		/// </summary>
   		/// <value>
   		/// Gets the URI requested by this instance.
   		/// </value>
   		/// <remarks>
   		/// The value of the System.Net.FtpWebRequest.RequestUri property is the URI specified when the System.Net.WebRequest.Create method was called to obtain this instance.
   		/// </remarks>
   		public override Uri RequestUri {
   			get { return requestUri; }
   		}
   		
   		
   		/// <summary>
   		/// FtpWebRequest.RenameTo Property
   		/// </summary>
   		/// <value>
   		/// Gets or sets the new name of a file being renamed.
   		/// </value>
		public string RenameTo {
			get { return renameTo; }
			set { renameTo = value; }
		}
		
   		
   		/// <summary>
   		/// FtpWebRequest.ReadWriteTimeout Property
   		/// </summary>
   		/// <value>
   		/// Gets or sets a time-out when reading from or writing to a stream.
   		/// </value>
   		/// <remarks>
   		/// The System.Net.FtpWebRequest.ReadWriteTimeout is used when writing to the stream returned by the System.Net.FtpWebRequest.GetRequestStream method or reading from the stream returned by the System.Net.FtpWebResponse.GetResponseStream method.
   		/// Specifically, the System.Net.FtpWebRequest.ReadWriteTimeout property controls the time-out for the System.IO.Stream.Read method, which is used to read the stream returned by the System.Net.FtpWebResponse.GetResponseStream method, and for the System.IO.Stream.Write method, which is used to write to the stream returned by the System.Net.FtpWebRequest.GetRequestStream method.
   		/// To specify the amount of time to wait for the request to complete, use the System.Net.FtpWebRequest.Timeout property.
   		/// </remarks>
   		/// <exception cref="System.InvalidOperationException">
   		/// The request has already been sent. 
		/// </exception>
		/// <exception cref="System.ArgumentOutOfRangeException">
		/// The value specified for a set operation is less than zero and is not equal to System.Threading.Timeout.Infinite. 
		/// </exception>
		
		public int ReadWriteTimeout {
			get { 
   				return readWriteTimeout;
   			}
			set { 
   					CheckRequestStarted() ;
					if(value <= 0 && value != System.Threading.Timeout.Infinite){
						throw new System.ArgumentOutOfRangeException("ReadWriteTimeout","ReadWriteTimeout must be greater than zero or System.Threading.Timeout.Infinite");
					} else {
						readWriteTimeout = value;
					}
   			}
		}
		
		/// <summary>
   		/// FtpWebRequest.Proxy Property
   		/// </summary>
   		/// <value>
   		/// Gets or sets the proxy used to communicate with the FTP server.
   		/// </value>
   		/// <remarks>
   		/// The System.Net.FtpWebRequest.Proxy property identifies the System.Net.IWebProxy instance that communicates with the FTP server. The proxy is set by the system by using configuration files and the Internet Explorer Local Area Network settings. To specify that no proxy should be used, set System.Net.FtpWebRequest.Proxy to the proxy instance returned by the System.Net.GlobalProxySelection.GetEmptyWebProxy method. For additional information on automatic proxy detection, see Automatic Proxy Detection.
   		/// You must set System.Net.FtpWebRequest.Proxy before writing data to the request's stream or getting the response. Changing System.Net.FtpWebRequest.Proxy after calling the System.Net.FtpWebRequest.GetRequestStream, System.Net.FtpWebRequest.BeginGetRequestStream, System.Net.FtpWebRequest.GetResponse, or System.Net.FtpWebRequest.BeginGetResponse method causes an System.InvalidOperationException exception.
   		/// </remarks>
   		/// <exception cref="System.InvalidOperationException">
   		/// A new value was specified for this property for a request that is already in progress
		/// </exception>
		/// <exception cref="System.ArgumentNullException">
		/// This property cannot be set to null.
		/// </exception>
		public override IWebProxy Proxy { 
			get { return proxy; }
			set { 
				CheckRequestStarted ();
				if (value == null)
					throw new ArgumentNullException ("value");
				proxy = value;
				servicePoint = null; // we may need a new one
			}
		}
		
		/// <summary>
   		/// FtpWebRequest.PreAuthenticate Property
   		/// </summary>
   		/// <value>
   		/// Always throws a System.NotSupportedException.
   		/// </value>
   		/// <remarks>
   		/// The System.Net.FtpWebRequest.PreAuthenticate property is provided only for compatibility with other implementations of the System.Net.WebRequest and System.Net.WebResponse classes. There is no reason to use System.Net.FtpWebRequest.UseDefaultCredentials.
   		/// </remarks>
   		/// <exception cref="System.NotSupportedException.">
   		/// PreAuthentication is not supported for FTP.
		/// </exception>
		public bool PreAuthenticate {
			get { 
   				throw new NotSupportedException();
   			}
			set { 
   				throw new NotSupportedException();
   			}
		}
		
		
		/// <summary>
   		/// FtpWebRequest.Method Property
   		/// </summary>
   		/// <value>
   		/// Gets or sets the command to send to the FTP server.
   		/// </value>
   		/// <remarks>
   		/// The System.Net.FtpWebRequest.Method property determines which command is sent to the server. Typically, you set System.Net.FtpWebRequest.Method by using the strings defined in the System.Net.FtpMethods structure. When setting System.Net.FtpWebRequest.Method to System.Net.FtpMethods.UploadFile, you must do so before calling the System.Net.FtpWebRequest.GetRequestStream method. Failure to call these members in the correct order causes a System.Net.ProtocolViolationException exception when you attempt to get the request stream.
   		/// The credentials supplied for the System.Net.FtpWebRequest object must have permission to perform the specified method. If not, the FTP command fails.
   		/// You can set System.Net.FtpWebRequest.Method to any command recognized by the server and use the System.Net.FtpWebRequest object to send the command. This works as expected only if the command does not require you to send data and the server does not send data in response to the request. You can also send multiple commands in a single request by separating each command in the string with a new line ('\n') character. 
   		/// You must not send any command that alters the state of the connection. For example, do not use the "MODE", "PASV", or "PORT" commands. Using commands that change the state of the connection can leave the request and the underlying connection in an unusable state. To determine the success or failure of a command, check the System.Net.FtpWebResponse.Status and System.Net.FtpWebResponse.StatusDescription properties.
   		/// </remarks>
   		/// <exception cref="System.InvalidOperationException">
   		/// A new value was specified for this property for a request that is already in progress.
		/// </exception>		
		public string Method {
			get { 
   				return method;
   			}
			set { 
   				CheckRequestStarted() ;
				method = value;
   			}
		}
		
		
		/// <summary>
   		/// FtpWebRequest.KeepAlive Property
   		/// </summary>
   		/// <value>
   		/// Gets or sets a System.Boolean value that specifies whether the control connection to the FTP server is closed after the request completes.
   		/// </value>
   		/// <remarks>
   		/// When the System.Net.FtpWebRequest.KeepAlive property is set to false, the control connection is closed when you call the System.Net.FtpWebResponse.Close method.
   		/// Changing System.Net.FtpWebRequest.KeepAlive after calling the System.Net.FtpWebRequest.GetRequestStream, System.Net.FtpWebRequest.BeginGetRequestStream, System.Net.FtpWebRequest.GetResponse, or System.Net.FtpWebRequest.BeginGetResponse method causes an System.InvalidOperationException exception.
   		/// </remarks>
   		/// <exception cref="System.InvalidOperationException">
   		/// A new value was specified for this property for a request that is already in progress.
		/// </exception>		
		public bool KeepAlive {
			get { 
   				return keepAlive;
   			}
			set { 
   				CheckRequestStarted() ;
				keepAlive = value;
   			}
		}
		
		
		/// <summary>
   		/// FtpWebRequest.Headers Property
   		/// </summary>
   		/// <value>
   		/// Gets an empty System.Net.WebHeaderCollection object.
   		/// </value>
   		/// <remarks>
   		/// The System.Net.FtpWebRequest.Headers property is provided only for compatibility with other implementations of the System.Net.WebRequest and System.Net.WebResponse classes. There is no reason to use System.Net.FtpWebRequest.Headers.
   		/// </remarks>
   		public override WebHeaderCollection Headers {
   			get { return new WebHeaderCollection(); }
   		}
   		
   		
   		/// <summary>
   		/// FtpWebRequest.EnableSSL Property
   		/// </summary>
   		/// <value>
   		/// Gets or sets a System.Boolean that specifies that an SSL connection should be used.
   		/// </value>
   		/// <remarks>
   		/// Caution Unless the System.Net.FtpWebRequest.EnableSsl property is true, all data and commands, including your user name and password information, are sent to the server in clear text. Anyone monitoring network traffic can view your credentials and use them to connect to the server. If you are connecting to an FTP server that requires credentials and supports SSL, you should set System.Net.FtpWebRequest.EnableSsl to true.
   		/// The "AUTH TLS" command is sent to the server to request an encrypted session. If the server does not recognize this command, you receive a System.Net.WebException exception. 
   		/// </remarks>
   		/// <exception cref="System.InvalidOperationException">
   		/// The connection to the FTP server has already been established.
		/// </exception>		
		public bool EnableSSL {
			get { 
   				return enableSSL;
   			}
			set { 
				if (connected) { throw new System.InvalidOperationException("The connection to the FTP server has already been established.") ; }
				enableSSL = value;
   			}
		}
   		
		/// <summary>
   		/// FtpWebRequest.DefaultCachePolicy Property - NOT SUPPORTED YET
   		/// </summary>
   		/// <value>
   		/// Defines the default cache policy for all FTP requests.
   		/// </value>
   		public static RequestCachePolicy DefaultCachePolicy {
			get { 
				throw new System.NotSupportedException("Caching not implemented");
				return defaultCachePolicy;
			}
			set { 
				throw new System.NotSupportedException("Caching not implemented");
				defaultCachePolicy = value;
			}
		}
   		
   		
   		
   		/// <summary>
   		/// FtpWebRequest.Credentials Property
   		/// </summary>
   		/// <value>
   		/// Gets or sets the credentials used to communicate with the FTP server.
   		/// </value>
   		/// <remarks>
   		/// You are not required to specify credentials when connecting using anonymous logon. You must set the System.Net.FtpWebRequest.Credentials property by using a credential of type System.Net.NetworkCredential; this ensures that the user name and password can be read and sent to the server.
   		/// Caution Credentials information is not encrypted when transmitted to the server unless the System.Net.FtpWebRequest.EnableSsl property is set to true.
   		/// Changing System.Net.FtpWebRequest.Credentials after calling the System.Net.FtpWebRequest.GetRequestStream, System.Net.FtpWebRequest.BeginGetRequestStream, System.Net.FtpWebRequest.GetResponse, or System.Net.FtpWebRequest.BeginGetResponse method causes an System.InvalidOperationException exception.
   		/// </remarks>
   		/// <exception cref="System.InvalidOperationException">
   		/// The connection to the FTP server has already been established.
		/// </exception>		
		/// <exception cref="System.ArgumentNullException">
   		/// Cannot be null.
		/// </exception>
		/// <exception cref="System.ArgumentException">
   		/// A System.Net.ICredentials of a type other than System.Net.NetworkCredential was specified for a set operation.
		/// </exception>
		public override ICredentials Credentials {
			get { 
   				return credentials;
   			}
			set { 
				if (connected) { throw new System.InvalidOperationException("The connection to the FTP server has already been established.") ; }
				credentials = value;
				throw new System.NotSupportedException("Credentials should be passed from the original URL ftp://username:password@host:port");
   			}
		}
		
		
		/// <summary>
   		/// FtpWebRequest.ContentType Property
   		/// </summary>
   		/// <value>
   		/// Always throws a System.NotSupportedException.
   		/// </value>
   		/// <remarks>
   		/// The System.Net.FtpWebRequest.ContentType property is provided only for compatibility with other implementations of the System.Net.WebRequest and System.Net.WebResponse classes. There is no reason to use System.Net.FtpWebRequest.UseDefaultCredentials.
   		/// </remarks>
   		/// <exception cref="System.NotSupportedException.">
   		/// Content Types are not supported for FTP.
		/// </exception>
		public override string ContentType {
			get { 
   				throw new NotSupportedException();
   			}
			set { 
   				throw new NotSupportedException();
   			}
		}
		
		/// <summary>
   		/// FtpWebRequest.ContentOffset Property
   		/// </summary>
   		/// <value>
   		/// Gets or sets a byte offset into the file being downloaded by this request.
   		/// </value>
   		/// <remarks>
   		/// Set the System.Net.FtpWebRequest.ContentOffset property when downloading a file from an FTP server. This offset indicates the position in the server's file that marks the start of the data to be downloaded. The offset is specified as the number of bytes from the start of the file; the offset of the first byte is zero. 
   		/// Setting System.Net.FtpWebRequest.ContentOffset causes the System.Net.FtpWebRequest to send a restart (REST) command to the server. This command is ignored by most FTP server implementations if you are uploading data to the server.
   		/// Changing System.Net.FtpWebRequest.ContentOffset after calling the System.Net.FtpWebRequest.GetRequestStream, System.Net.FtpWebRequest.BeginGetRequestStream, System.Net.FtpWebRequest.GetResponse, or System.Net.FtpWebRequest.BeginGetResponse method causes an System.InvalidOperationException exception.
   		///</remarks>
   		/// <exception cref="System.InvalidOperationException">
   		/// The request has already been sent. 
		/// </exception>
		/// <exception cref="System.ArgumentOutOfRangeException">
		/// The value specified for a set operation is less than zero. 
		/// </exception>
		public long ContentOffset {
			get { return contentOffset; }
			set { 
				CheckRequestStarted() ;
					if(value <= 0){
						throw new System.ArgumentOutOfRangeException("ContentOffset","ContentOffset must be greater than zero");
					} else {
					contentOffset = value; 
				}
			}
		}
		
   		/// <summary>
   		/// FtpWebRequest.ContentLength Property
   		/// </summary>
   		/// <value>
   		/// Gets or sets a value that is ignored by the System.Net.FtpWebRequest class.
   		/// </value>
   		/// <remarks>
   		/// The System.Net.FtpWebRequest.ContentLength property is provided only for compatibility with other implementations of the System.Net.WebRequest and System.Net.WebResponse classes. There is no reason to use System.Net.FtpWebRequest.ContentLength.
   		/// </remarks>
		public long ContentLength {
			get { return contentLength; }
			set { contentLength = value; }
		}
   		
   		
   		/// <summary>
   		/// FtpWebRequest.ConnectionGroupName Property
   		/// </summary>
   		/// <value>
   		/// Gets or sets the name of the connection group that contains the service point used to send the current request.
   		/// </value>
   		/// <remarks>
   		/// Connection groups associate a set of requests with a particular connection or set of connections. The connections in a connection group can be re-used only by requests originating in the same application domain, when the credentials on the request are the same and the request specifies the connection group name. When a request does not specify a connection group name, any existing connection to the requested server that is not associated with a connection group can be used. When the credentials are not the same, the existing connection is closed and the new request must be re-authenticated.
   		/// Using connection groups can improve performance because this allows all of the requests for a user to re-use the connection authenticated with the user's credentials.
   		/// Changing the System.Net.FtpWebRequest.ConnectionGroupName property after calling the System.Net.FtpWebRequest.GetRequestStream, System.Net.FtpWebRequest.BeginGetRequestStream, System.Net.FtpWebRequest.GetResponse, or System.Net.FtpWebRequest.BeginGetResponse method causes an System.InvalidOperationException exception.
   		/// </remarks>
   		/// <exception cref="System.InvalidOperationException">
   		/// A new value was specified for this property for a request that is already in progress.
   		/// </exception>
		public string ConnectionGroupName {
			get { return connectionGroupName; }
			set { 
				if (connected) { throw new System.InvalidOperationException("The connection to the FTP server has already been established.") ; }
				connectionGroupName = value; }
		}
   		
   		
   		/// <summary>
   		/// FtpWebRequest.ClientCertificates Property
   		/// </summary>
   		/// <value>
   		/// Gets the certificates used for establishing an encrypted connection to the FTP server.
   		/// </value>
   		/// <remarks>
   		/// Client certificates are used to authenticate the client during the initial SSL connection negotiation. For additional information, see System.Net.FtpWebRequest.EnableSsl. 
   		/// </remarks>
		public X509CertificateCollection ClientCertificates {
			get { return clientCertificates; }
			set { clientCertificates = value; }
		}
		
		
   		#endregion
   		
   		#region Internal Methods
   		private void Thrower(Exception e){
   			//Throw an exception and mark operation as complete
   			asyncResult.SetCompleted(true,e);
   			throw e;
   		}
   		
   		internal ServicePoint GetServicePoint ()
		{
			if (!hostChanged && servicePoint != null)
				return servicePoint;

			lock (this) {
				if (hostChanged || servicePoint == null) {
					servicePoint = ServicePointManager.FindServicePoint (actualUri, proxy);
					hostChanged = false;
				}
			}

			return servicePoint;
		}
		
   		void CheckRequestStarted () 
		{
			if (requestInProgress)
				throw new InvalidOperationException ("Request already started");
		}
   		
   		private void doData() {
   			
   			MemoryStream responseStream = new MemoryStream();
		  	int BufferSize = 256;
		   	Byte [] recvbuffer = new Byte[BufferSize + 1]; 

   			
   			while(true) {
	        	int bytesread = 0;
	        	recvbuffer[bytesread] = (Byte)'\0';        
		        bytesread = dataSocket.Receive(recvbuffer, BufferSize, 0 );      
		        if( bytesread <= 0 ) 
		        	break;       
		        responseStream.Write(recvbuffer,0,bytesread);                            
		 	}
   			responseStream.Seek(0,0);
      		dataStream = responseStream;
      		asyncStream.SetCompleted(true,dataStream);
      		
   		}
   		
   		private void doDataNetworkStream() {
   			
   			Stream responseStream;
   			
   			if(this.EnableSSL){
   				/*
   				  M$s spec doesn't allow for non-encrypted data channel
   				  with encrypted control channel so by this point we
   				  need to have issued PBSZ 0 and PROT P.
   				*/
   				NetworkStream responseStream2 = new NetworkStream(dataSocket,true);
   				
   				Mono.Security.Protocol.Tls.SslClientStream responseStream3 = new Mono.Security.Protocol.Tls.SslClientStream(responseStream2, "127.0.0.1", false, Mono.Security.Protocol.Tls.SecurityProtocolType.Tls);
   				responseStream3.ServerCertValidationDelegate = new Mono.Security.Protocol.Tls.CertificateValidationCallback(CertificateValidator);
   				
				responseStream = responseStream3;   				
   			} else {
   				responseStream = new NetworkStream(dataSocket,true);
   			}

      		dataStream = responseStream;
      		asyncStream.SetCompleted(true,dataStream);
      		
   		}
   		
   		private void SendLoginName() {
   			
   			this.SendCommand("USER " + userName);
   			
   		}
   		
   		
   		private void SendPassword() {
   			
   			this.SendCommand("PASS " + password);
   			
   		}
   		
   		private void SendCommand(string CommandText) {
   			if(controlSocket == null) {
   				Thrower(new ProtocolViolationException("Control connection not open"));
   			}
   			
   			byte[] sendBuffer = Encoding.ASCII.GetBytes(CommandText + Environment.NewLine);
   			
   			net.Write(sendBuffer, 0, sendBuffer.GetLength(0));
   			
   			//controlSocket.Send(sendBuffer);
   			
   			writeLog(CommandText + Environment.NewLine,true);
   			//System.Console.WriteLine(CommandText);
   			MemoryStream responseStream = new MemoryStream();
      		
      		while(true)
      		{      
        		int bufferSize = 256;
        		Byte[] recvBuffer = new Byte[bufferSize + 1];      
        		int bytesRead = net.Read(recvBuffer, 0,bufferSize );      
        		responseStream.Write(recvBuffer,0,bytesRead);      
        		
        		if(isCompleteResponse(responseStream)) {
          			//Create the FtpWebResponse
        			response.UpdateCode(requestUri,method,responseStream, asyncResult);
        			asyncResult.response = response;
        			return;
        		}
      		}
      		
   		}
   		
   		
   		
   		private FtpWebResponse OpenCtlConnection(Uri uri)
    	{
    		//TODO: Use a proxy 
       		String Host = uri.Host;
      		int Port;
      		if (uri.Port <= 0) {
      			Port = 21;
      		} else {
      			Port = uri.Port;
      		}
      		

	      	if(controlSocket != null) // Control socket already open
	      	{
	        	Thrower(new ProtocolViolationException("Control connection already open"));
	      	}

      		controlSocket = new Socket( AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp );
      		
      		EndPoint clientEndPoint = new IPEndPoint(IPAddress.Any, 0);

      		try 
      		{
        		controlSocket.Bind(clientEndPoint);
      		} 
      		
      		catch(Exception ex)
      		{
        		controlSocket.Close();
        		controlSocket = null;      
        		Thrower(new WebException("Unable to bind to any client address", ex)); 
      		}

      		clientEndPoint = controlSocket.LocalEndPoint;
      
      		try
      		{
        		IPHostEntry serverHostEntry = Dns.GetHostByName(Host);
        		IPEndPoint serverEndPoint = new IPEndPoint( serverHostEntry.AddressList[0], Port );
	        	try 
	        	{
	          		controlSocket.Connect(serverEndPoint); 
	        	} 
	        	
	        	catch(Exception ex)
	        	{ 
	          		try {
						controlSocket.Close();
        				controlSocket = null;
        			} catch (Exception) {
        			
        			}
	        		Thrower(new WebException("Unable to connect", ex)); 
				}   
      		}
      		catch ( Exception ex)
      		{
        		try {
					controlSocket.Close();
        			controlSocket = null;
        		} catch (Exception) {
        			
        		}
        		
        		Thrower(new WebException("Unable to connect", ex));
      		}


      		// Create FtpWebResponse with banner
    		writeLog("Connected" + Environment.NewLine,false);
    		net = new NetworkStream(controlSocket);
      		MemoryStream responseStream = new MemoryStream();
      		while(true)
      		{      
        		int bufferSize = 256;
        		Byte[] recvBuffer = new Byte[bufferSize + 1];      
        		int bytesRead = controlSocket.Receive(recvBuffer, bufferSize, 0 );      
        		responseStream.Write(recvBuffer,0,bytesRead);      
        		
        		if(isCompleteResponse(responseStream)) {
          			//Create the FtpWebResponse
        			//FtpAsyncResult result = (FtpAsyncResult) BeginGetResponse(null, null);
        			response = new FtpWebResponse(this.requestUri, method, responseStream, asyncResult);
        			asyncResult.response = response;
        			return asyncResult.response;
        		}
      		}
      		return null;  
    	}
   		
   		
   		private bool isCompleteResponse(Stream responseStream)
    	{    
      		bool complete = false;    
      		int responseLength = (int) responseStream.Length;
      		responseStream.Position = 0;    
      		if(responseLength >= 5)
      		{
        		int status = -1;                  
        		Byte[] byteArray = new Byte[responseLength];      
        		String statusString;              
        		responseStream.Read(byteArray,0,responseLength);    
        		statusString = Encoding.ASCII.GetString(byteArray,0,responseLength);      
        		if (responseLength == 5 && byteArray[responseLength - 1] == '\n')  
        		{
        			complete = true;
        		}      
        		else if ((byteArray [responseLength - 1] == '\n') && (byteArray [responseLength - 2] == '\r'))  
        		{              
          			complete = true;
        		}      
        		if (responseLength == 5 && byteArray[responseLength - 1] == '\n')  
        		{
          			complete = true;
        		}      
        		if(complete)
        		{
          			try
          			{
            			status = Convert.ToInt16( statusString.Substring(0,3));
          			}
          			catch
          			{
            			status = -1;          
          			}    
          			if (statusString[3] == '-') 
          			{
            			int lastLine =0;
            			for(lastLine = responseLength - 2; lastLine >0; lastLine--)
            			{            
              				if ( byteArray [lastLine] == '\n' && byteArray [lastLine - 1] == '\r')
                			break;            
            			}          
	            		if(lastLine == 0) 
	            		{
	              			complete = false;
	            		}
	            		else if(statusString[lastLine + 4] != ' ')
	            		{
	              			complete = false;
	            		}
	            		else
	            		{
	              			int endCode = -1;            
	              			try
	              			{
	                			endCode = Convert.ToInt16( statusString.Substring(lastLine + 1,3));
	              			}
	              			catch
	              			{
	                			endCode = -1;
	              			}    
	              			if (endCode != status)
	                			complete = false;
	            		}
            
          			}
          			else if (statusString[3] != ' ')
          			{
            			status = -1;                            
          			}
        		}
      		}
      		else
      		{      
        		complete = false;            
      		}
      		return complete; 
    	}
   		
   		
   		private bool isCompleteResponse(Stream responseStream, int expectedCode)
    	{    
      		bool complete = false;    
      		int responseLength = (int) responseStream.Length;
      		responseStream.Position = 0;    
      		if(responseLength >= 5)
      		{
        		int status = -1;                  
        		Byte[] byteArray = new Byte[responseLength];      
        		String statusString;              
        		responseStream.Read(byteArray,0,responseLength);    
        		statusString = Encoding.ASCII.GetString(byteArray,0,responseLength);      
        		if (responseLength == 5 && byteArray[responseLength - 1] == '\n')  
        		{
        			complete = true;
        		}      
        		else if ((byteArray [responseLength - 1] == '\n') && (byteArray [responseLength - 2] == '\r'))  
        		{              
          			complete = true;
        		}      
        		if (responseLength == 5 && byteArray[responseLength - 1] == '\n')  
        		{
          			complete = true;
        		}      
        		if(complete)
        		{
          			try
          			{
            			status = Convert.ToInt16( statusString.Substring(0,3));
          			}
          			catch
          			{
            			status = -1;          
          			}    
          			
          			if (status != expectedCode) {
          				return false;
          			}
          			
          			if (statusString[3] == '-')
          			{
            			int lastLine =0;
            			for(lastLine = responseLength - 2; lastLine >0; lastLine--)
            			{            
              				if ( byteArray [lastLine] == '\n' && byteArray [lastLine - 1] == '\r')
                			break;            
            			}          
	            		if(lastLine == 0) 
	            		{
	              			complete = false;
	            		}
	            		else if(statusString[lastLine + 4] != ' ')
	            		{
	              			complete = false;
	            		}
	            		else
	            		{
	              			int endCode = -1;            
	              			try
	              			{
	                			endCode = Convert.ToInt16( statusString.Substring(lastLine + 1,3));
	              			}
	              			catch
	              			{
	                			endCode = -1;
	              			}    
	              			if (endCode != status)
	                			complete = false;
	            		}
            
          			}
          			else if (statusString[3] != ' ')
          			{
            			status = -1;                            
          			}
        		}
      		}
      		else
      		{      
        		complete = false;            
      		}
      		return complete; 
    	}
    	
    	private int Port1(int Port){
    		
    		for(int x=2;x+1*256<=Port;x++){
				if(x*256 >= Port){
					return x-1;
				}
				 	
			}
			
			return 0; //Never happens
    	}
    	
    	private Socket doActive() {
			//Use Active mode
			Socket dataConnection = this.openDataConnection();
			
			IPEndPoint tmp = (IPEndPoint)(dataConnection.LocalEndPoint);
			
			int port = tmp.Port; 
			string ip = tmp.Address.ToString();			
			
			ip = ip.Replace('.',',');
			
			int p1;
			int p2;
			p1 = Port1(port);
			p2 = p2 = port - (p1 * 256);
	
	    	this.writeLog("Listening for an active connection on port " + port + Environment.NewLine,false);
	    	
	    	this.SendCommand("PORT " + ip + "," + p1 + "," + p2);
	    	
	    	return dataConnection;
	    		    		
    	}
    	
    	private void doPASV() {
			string pasvIP;
			int pasvPort;
			Socket dataConnection;
		
			//Use Passive mode
			this.SendCommand("PASV");
			string pasvIPLine = asyncResult.response.StatusDescription;
			string[] iPSplit = pasvIPLine.Split(' ');
			string pasvIPConnect;
			pasvIPConnect = iPSplit[iPSplit.GetUpperBound(0)];
			
			pasvIPConnect = pasvIPConnect.Replace("(","");
			pasvIPConnect = pasvIPConnect.Replace(")","");
			pasvIPConnect = pasvIPConnect.Replace(",",".");
			
			iPSplit = pasvIPConnect.Split('.');
			pasvIPConnect = "";
			
			for (int x=0;x<4;x++){
				if(x==3) {
					pasvIPConnect = pasvIPConnect + iPSplit[x];
				} else {
					pasvIPConnect = pasvIPConnect + iPSplit[x] + ".";
				}
			}
			
			pasvIP = pasvIPConnect;
			pasvPort = (int.Parse(iPSplit[4]) * 256) + int.Parse(iPSplit[5]);
			
			writeLog("Passive FTP information obtained:" + Environment.NewLine,false);
			writeLog("IP: " + pasvIP + Environment.NewLine,false);
			writeLog("Port: " + pasvPort + Environment.NewLine,false);
			writeLog("Connecting to specified passive socket..." + Environment.NewLine,false);
			
			dataConnection = this.openDataConnection(pasvIP, pasvPort);
			dataSocket = dataConnection;
			
			if(dataConnection != null){
				writeLog("Connected to passive socket!" + Environment.NewLine,false);
			} else {
				Thrower(new WebException("Unable to connect to passive socket"));
			}
    		
    	}
    	
    	
    	private bool CertificateValidator(System.Security.Cryptography.X509Certificates.X509Certificate certificate, int[] certificateErrors) {
       		return true;
    	}
    	
    	private static System.Security.Cryptography.AsymmetricAlgorithm GetPrivateKey (X509Certificate certificate, string targetHost) 
          { 
               Mono.Security.Authenticode.PrivateKey key = Mono.Security.Authenticode.PrivateKey.CreateFromFile ("/home/w-h/Desktop/test.pvk"); 
               return key.RSA; 
          } 
    	
    	private void doOperations () {
    		//determine which operation to run
    		//build a list of commands to execute
    		//run them
    		switch(method) {
    		case "501":
    			//Open control conn
    			this.OpenCtlConnection(this.requestUri);
    			
    			if(this.EnableSSL==true){
    				//Negotiate TLS
    				this.SendCommand("AUTH TLS");
    				//System.Security.Cryptography.X509Certificates.X509Certificate cert = System.Security.Cryptography.X509Certificates.X509Certificate.CreateFromCertFile("/home/w-h/Desktop/test.crt");
					//certificates.Add(cert);
					SSL = new Mono.Security.Protocol.Tls.SslClientStream(net, "127.0.0.1", false, Mono.Security.Protocol.Tls.SecurityProtocolType.Tls);
					SSL.ServerCertValidationDelegate = new Mono.Security.Protocol.Tls.CertificateValidationCallback(CertificateValidator);
					SSL.PrivateKeyCertSelectionDelegate = new Mono.Security.Protocol.Tls.PrivateKeySelectionCallback (GetPrivateKey); 

					net = SSL;
					
					this.SendCommand("PBSZ 0");
					this.SendCommand("PROT C");
					//break;
    			}
    			
    			break;
    		case "502":
    			//Send login name
    			this.SendLoginName();
    			break;
    		case "503":
    			//Send password
    			this.SendPassword();
    			break;
    		case "504":
    			//Send "SYST"(em) command
    			this.SendCommand("SYST");
    			break;
    		case "505":
    			//List
    			if (this.enableSSL) {
    				this.SendCommand("PBSZ 0");
    				this.SendCommand("PROT P");
    			}
    			if (this.usePassive) {
    				//Use Passive mode
    				this.doPASV();
    				this.SendCommand("LIST");		
    			} else {
    				//Use Active mode:
    				//Bind listener on external IP
    				//Send IP address to server using "PORT"
    				Socket tmp = this.doActive();
    				this.SendCommand("LIST");
    				dataSocket = tmp.Accept();
    			}			
    			break;
    		default:
    			this.SendCommand(method);
    			break;
    		}
    		
    		
    		asyncResult.SetCompleted (true, (Stream)null);
			asyncResult.DoCallback ();
    	}
   		

   		private Socket openDataConnection(){
   			//Active FTP overload
   			
   			Socket dataConnection = new Socket( AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp );
      		
      		IPEndPoint tmp = (IPEndPoint)this.controlSocket.LocalEndPoint;
      		
      		EndPoint clientEndPoint = new IPEndPoint(tmp.Address, 0);

      		try 
      		{
        		dataConnection.Bind(clientEndPoint);
      		} 
      		
      		catch(Exception ex)
      		{
        		dataConnection.Close();
        		dataConnection = null;      
        		Thrower(new WebException("Unable to bind to any client address for active data connection", ex)); 
      		}
			
			dataConnection.Listen(2);

   			return dataConnection;
   		}
   		
   		private Socket openDataConnection(string host, int port) {
   			//Passive FTP overload
   			Socket dataConnection = new Socket( AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp );
      		
      		EndPoint dataEndPoint = new IPEndPoint(IPAddress.Any, 0);

      		try 
      		{
        		dataConnection.Bind(dataEndPoint);
      		} 
      		
      		catch(Exception ex)
      		{
        		dataConnection.Close();
        		dataConnection = null;      
        		Thrower(new WebException("Unable to bind to any client address to open passive socket", ex)); 
      		}

      		dataEndPoint = dataConnection.LocalEndPoint;
      
      		try
      		{
        		IPHostEntry serverHostEntry = Dns.GetHostByName(host);
        		IPEndPoint serverEndPoint = new IPEndPoint( serverHostEntry.AddressList[0], port );
	        	try 
	        	{
	          		dataConnection.Connect(serverEndPoint); 
	        	} 
	        	
	        	catch(Exception ex)
	        	{ 
	          		try {
						dataConnection.Close();
        				dataConnection = null;
        			} catch (Exception) {
        			
        			}
	        		Thrower(new WebException("Unable to connect to passive socket", ex)); 
				}   
      		}
      		catch ( Exception ex)
      		{
        		try {
					dataConnection.Close();
        			dataConnection = null;
        		} catch (Exception) {
        			
        		}
        		
        		Thrower(new WebException("Unable to connect to passive socket", ex));
      		}
			return dataConnection;
   		}
   		
   		private void writeLog(string logEntry, bool isRaw) {
   			if(isRaw){
   				log.Append("Command sent: " + logEntry);
   			} else {
   				log.Append("Information: " + logEntry);
   			}
   		}
   		#endregion
   		
		#region #ctors
		internal FtpWebRequest (Uri uri) 
		{
			if(uri.ToString().StartsWith("ftps")){
				this.enableSSL = true;	
			}
			this.requestUri = uri;
			this.actualUri = uri;
			this.proxy = GlobalProxySelection.Select;
				
			if(requestUri.UserInfo != "" && requestUri.UserInfo != null) {
				try {
					userName = requestUri.UserInfo.Split(':')[0];
					password = requestUri.UserInfo.Split(':')[1];
				} catch (Exception) {
					
				}
			}
				
			
			if((userName == null) || (userName == ""))
	              userName = "anonymous";
	          
	        if((password == null) || (password == ""))
	              password = "User@";
	            
			m_Credentials = new NetworkCredential( userName, password );
			
			if(m_Credentials != null)
          	{
            	NetworkCredential cred = m_Credentials.GetCredential(uri,null);
        
	            if(cred != null) 
	            {
	              userName = cred.UserName;
	              password = cred.Password;
	            }            
          }
		}		
		
		protected FtpWebRequest (SerializationInfo serializationInfo, StreamingContext streamingContext) 
		{
			SerializationInfo info = serializationInfo;

			requestUri = (Uri) info.GetValue ("requestUri", typeof (Uri));
			actualUri = (Uri) info.GetValue ("actualUri", typeof (Uri));
			clientCertificates = (X509CertificateCollection) info.GetValue ("clientCertificates", typeof (X509CertificateCollection));
			connectionGroupName = info.GetString ("connectionGroupName");
			contentOffset = info.GetInt64 ("contentOffset");
			contentLength = info.GetInt64 ("contentLength");
			keepAlive = info.GetBoolean ("keepAlive");
			method = info.GetString ("method");
			proxy = (IWebProxy) info.GetValue ("proxy", typeof (IWebProxy));
			timeout = info.GetInt32 ("timeout");
		}
		
		
		#endregion
		
		#region Public Methods
		
		/// <summary>
		/// FtpWebRequest.GetResponse Method
		/// </summary>
		/// <value>
		/// Returns the FTP server response.
		/// </value>
		/// <returns>
		/// A System.Net.WebResponse reference containing an System.Net.FtpWebResponse instance. This object contains the FTP server's response to the request.
		/// </returns>
		/// <exception cref="System.Net.WebException">
		/// System.Net.FtpWebRequest.EnableSsl is set to true, but the server does not support this feature.
		/// </exception>
		/// <exception cref="System.InvalidOperationException">
		/// System.Net.FtpWebRequest.GetResponse or System.Net.FtpWebRequest.BeginGetResponse has already been called for this instance.
		/// </exception>
		/// <remarks>
		/// To access the FTP-specific properties, you must cast the System.Net.WebResponse object returned by this method to System.Net.FtpWebResponse.
		/// System.Net.FtpWebRequest.GetResponse causes a control connection to be established, and might also create a data connection. System.Net.FtpWebRequest.GetResponse blocks until the response is received. To prevent this, you can perform this operation asynchronously by calling the System.Net.FtpWebRequest.BeginGetResponse and System.Net.FtpWebRequest.EndGetResponse methods in place of System.Net.FtpWebRequest.GetResponse.
		/// If the System.Net.FtpWebRequest.Proxy property is set, either directly or in a configuration file, communications with the FTP server are made through the proxy.
		/// </remarks>
		public override WebResponse GetResponse(){
			CheckRequestStarted();
			FtpAsyncResult result = (FtpAsyncResult) BeginGetResponse (null, null);
			return EndGetResponse (result);
		}
		
		/// <summary>
		/// FtpWebRequest.GetRequestStream Method
		/// </summary>
		/// <value>
		/// Retrieves the stream used to upload data to an FTP server.
		/// </value>
		/// <returns>
		/// A writable System.IO.Stream instance used to store data to be sent to the server by the current request.
		/// </returns>
		/// <exception cref="System.InvalidOperationException">
		/// System.Net.FtpWebRequest.BeginGetRequestStream has been called and has not completed. 
		/// </exception>
		/// <exception cref="System.Net.WebException">
		/// A connection to the FTP server could not be established. 
		/// </exception>
		/// <exception cref="System.Net.ProtocolViolationException">
		/// The System.Net.FtpWebRequest.Method property is not set to System.Net.FtpMethods.UploadFile or System.Net.FtpMethods.AppendFile. 
		/// </exception>
		/// <remarks>
		/// Set the request properties before calling the System.Net.FtpWebRequest.GetRequestStream method. After writing the data to the stream, you must close the stream prior to sending the request.
		/// If you have not set the System.Net.FtpWebRequest.Method property to System.Net.FtpMethods.UploadFile or System.Net.FtpMethods.AppendFile, you cannot get the stream.
		/// System.Net.FtpWebRequest.GetRequestStream blocks while waiting for the stream. To prevent this, call the System.Net.FtpWebRequest.BeginGetRequestStream method in place of System.Net.FtpWebRequest.GetRequestStream.
		/// </remarks>
		public override Stream GetRequestStream(){
			CheckRequestStarted();
			//Blocking operation
			IAsyncResult result = (FtpAsyncResult) BeginGetRequestStream (null, null);
			Stream stream = (Stream)EndGetRequestStream(result);
			//writeLog("Received " + stream.Length + " bytes through the data channel." + Environment.NewLine,false);
			
			return (Stream)stream;
		}
		
		/// <summary>
		/// FtpWebRequest.EndGetResponse Method
		/// </summary>
		/// <value>
		/// Ends a pending asynchronous operation started with System.Net.FtpWebRequest.BeginGetResponse.
		/// </value>
		/// <returns>
		/// A System.Net.WebResponse reference containing an System.Net.FtpWebResponse instance. This object contains the FTP server's response to the request.
		/// </returns>
		/// <exception cref="System.InvalidOperationException">
		/// This method was already called for the operation identified by asyncResult. 
		/// </exception>
		/// <exception cref="System.ArgumentException">
		/// asyncResult was not obtained by calling System.Net.FtpWebRequest.BeginGetResponse.
		/// </exception>
		/// <exception cref="System.ArgumentNullException">
		/// asyncResult is null. 
		/// </exception>
		/// <remarks>
		/// If the operation has not completed at the time the System.Net.FtpWebRequest.EndGetResponse method is called, System.Net.FtpWebRequest.EndGetResponse blocks until the operation completes. To prevent blocking, check the System.IAsyncResult.IsCompleted property before calling System.Net.FtpWebRequest.EndGetResponse.
		/// In addition to the exceptions noted in "Exceptions", System.Net.FtpWebRequest.EndGetResponse rethrows exceptions thrown while communicating with the server.
		/// </remarks>
		public override WebResponse EndGetResponse(IAsyncResult asyncResult){
			if (asyncResult == null) {
				//return null;
				throw new ArgumentNullException ("asyncResult");
			}

			FtpAsyncResult result = asyncResult as FtpAsyncResult;
			if (result == null)
				throw new ArgumentException ("Invalid IAsyncResult", "asyncResult");

			if (!result.WaitUntilComplete (timeout, false)) {
				Abort ();
				throw new WebException("The request timed out", WebExceptionStatus.Timeout);
			}

			if (result.GotException)
				throw result.Exception;

			return result.Response;
		}
		
		
		
		/// <summary>
		/// FtpWebRequest.EndGetRequestStream Method
		/// </summary>
		/// <value>
		/// Ends a pending asynchronous operation started with System.Net.FtpWebRequest.BeginGetRequestStream.
		/// </value>
		/// <returns>
		/// A Stream reference containing a Stream instance. This object contains the FTP server's data connection.
		/// </returns>
		/// <exception cref="System.InvalidOperationException">
		/// This method was already called for the operation identified by asyncResult. 
		/// </exception>
		/// <exception cref="System.ArgumentException">
		/// asyncResult was not obtained by calling System.Net.FtpWebRequest.BeginGetRequestStream.
		/// </exception>
		/// <exception cref="System.ArgumentNullException">
		/// asyncResult is null. 
		/// </exception>
		/// <remarks>
		/// If the operation has not completed at the time the System.Net.FtpWebRequest.EndGetRequestStream method is called, System.Net.FtpWebRequest.EndGetRequestStream blocks until the operation completes. To prevent blocking, check the System.IAsyncResult.IsCompleted property before calling System.Net.FtpWebRequest.EndGetRequestStream.
		/// In addition to the exceptions noted in "Exceptions", System.Net.FtpWebRequest.EndGetResponse rethrows exceptions thrown while communicating with the server.
		/// The type of stream returned is a NetworkStream.
		/// </remarks>
		public override Stream EndGetRequestStream(IAsyncResult asyncResult) {
			
			if (asyncResult == null) {
				//return null;
				throw new ArgumentNullException ("asyncResult");
			}

			FtpAsyncResult result = asyncStream as FtpAsyncResult;
			if (result == null)
				throw new ArgumentException ("Invalid IAsyncResult", "asyncResult");

			if (!result.WaitUntilComplete (timeout, false)) {
				Abort ();
				throw new WebException("The request timed out", WebExceptionStatus.Timeout);
			}

			if (result.GotException)
				throw result.Exception;

			return dataStream;
		}
		
		/// <summary>
		/// FtpWebRequest.BeginGetResponse Method
		/// </summary>
		/// <value>
		/// Begins sending a request and receiving a response from an FTP server asynchronously.
		/// </value>
		/// <returns>
		/// A System.IAsyncResult instance that indicates the status of the operation.
		/// </returns>
		/// <exception cref="System.InvalidOperationException">
		/// System.Net.FtpWebRequest.GetResponse or System.Net.FtpWebRequest.BeginGetResponse has already been called for this instance. 
		/// </exception>
		/// <remarks>
		/// You must complete the asynchronous operation by calling the System.Net.FtpWebRequest.EndGetResponse method. Typically, System.Net.FtpWebRequest.EndGetResponse is called by the method referenced by callback. To determine the state of the operation, check the properties in the System.IAsyncResult object returned by the System.Net.FtpWebRequest.BeginGetResponse method.
		/// If the System.Net.FtpWebRequest.Proxy property is set, either directly or in a configuration file, communications with the FTP server are made through the specified proxy.
		/// System.Net.FtpWebRequest.BeginGetResponse does not block while waiting for the response from the server. To block, call the System.Net.FtpWebRequest.GetResponse method in place of System.Net.FtpWebRequest.BeginGetResponse.
		/// </remarks>
		public override IAsyncResult BeginGetResponse(AsyncCallback callback, object state) {
			asyncResult = new FtpAsyncResult(this, callback, state);
			
			//Run asynchronous request
			System.Threading.ThreadStart threadStart = new System.Threading.ThreadStart(doOperations);
			worker = new System.Threading.Thread(threadStart);
		
			worker.Start();
			return asyncResult;
		}
		


		/// <summary>
		/// FtpWebRequest.BeginGetRequestStream Method
		/// </summary>
		/// <value>
		/// Begins getting a data stream from an FTP server asynchronously.
		/// </value>
		/// <returns>
		/// A System.IAsyncResult instance that indicates the status of the operation.
		/// </returns>
		/// <exception cref="System.InvalidOperationException">
		/// System.Net.FtpWebRequest.GetRequestStream or System.Net.FtpWebRequest.BeginGetRequestStream has already been called for this instance. 
		/// </exception>
		/// <remarks>
		/// You must complete the asynchronous operation by calling the System.Net.FtpWebRequest.EndGetRequestStream method. Typically, System.Net.FtpWebRequest.EndGetRequestStream is called by the method referenced by callback. To determine the state of the operation, check the properties in the System.IAsyncResult object returned by the System.Net.FtpWebRequest.BeginGetRequest method.
		/// If the System.Net.FtpWebRequest.Proxy property is set, either directly or in a configuration file, communications with the FTP server are made through the specified proxy.
		/// System.Net.FtpWebRequest.BeginGetRequestStream does not block while waiting for the response from the server. To block, call the System.Net.FtpWebRequest.GetRequestStream method in place of System.Net.FtpWebRequest.BeginGetRequestStream.
		/// </remarks>
		public override IAsyncResult BeginGetRequestStream(AsyncCallback callback, object state){

			asyncStream = new FtpAsyncResult(this, callback, state);
			
			//Run asynchronous request
			System.Threading.ThreadStart threadStart = new System.Threading.ThreadStart(doDataNetworkStream);
			dataThread = new System.Threading.Thread(threadStart);
		
			dataThread.Start();
			return asyncStream;
		
		}
		
		/// <summary>
		/// FtpWebRequest.Abort Method
		/// </summary>
		/// <value>
		/// Aborts an FTP operation.
		/// </value>
		/// <exception cref="System.InvalidOperationException">
		/// No operation was in progress to abort. 
		/// </exception>
		/// <remarks>
		/// The FTP Abort command is somewhat tempremental in many server implementations. Although you may instruct the server to halt it's current progress it may not take immediate action upon your request. This is especially noticeable when receiving data when the server has sent a large chunk and it has not yet arrived. The abort will not take effect until all sent data has been received.
		/// You should also be prepared for your streams to close if they are open after this command.
		/// </remarks>
		public override void Abort(){
			this.SendCommand("ABORT");
		}
		
		#endregion
	}
}
