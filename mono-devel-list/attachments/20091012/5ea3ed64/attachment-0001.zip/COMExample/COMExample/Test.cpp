// Test.cpp : Implementation of CTest

#include "stdafx.h"
#include "Test.h"
#include <atlsafe.h>
#include <string>


// CTest

STDMETHODIMP CTest::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_ITest
	};

	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

