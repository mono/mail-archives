#define TEST2
using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;

using COMExampleLib;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            ITest t = new TestClass();
        }
    }
}
