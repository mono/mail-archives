using System;

namespace ACME
{
	public interface IServerApi
	{
		void Test ();
		void AddListener (IEvents ev);
		void RemoveListener (IEvents ev);
	}

	public interface IEvents
	{
		void OnTest (object sender, EventArgs e);
	}
}
