using System;
using System.Configuration;
using System.Diagnostics;
using System.Runtime.Remoting;

namespace ACME
{
	public class Client
	{
		public static void Main ()
		{
			RemotingConfiguration.Configure ("client.exe.config", false);

			IServerApi server = (IServerApi) RemotingServices
				.Connect(typeof(IServerApi),
					 ConfigurationManager.AppSettings ["serverUrl"]);

			IEvents events = new Events ();
			server.AddListener (events);
			server.Test ();
			server.RemoveListener (events);
			Console.ReadLine ();
		}
	}

	public class Events : MarshalByRefObject, IEvents
	{
		public void OnTest (object sender, EventArgs e)
		{
			Console.WriteLine ("Client: OnTest () called");
		}

		public override object InitializeLifetimeService ()
		{
			return null; // live forever
		}
	}
}
