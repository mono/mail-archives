using System;
using System.Runtime.Remoting.Messaging;
using System.Threading;

namespace ACME
{
	public class AsyncEvent<T> : MarshalByRefObject where T: EventArgs
	{
		event EventHandler<T> eventList;

		public void Add (EventHandler<T> handler)
		{
			eventList += handler;
		}

		public void Remove (EventHandler<T> handler)
		{
			eventList -= handler;
		}

		public void Raise (T args)
		{
			Thread t = new Thread (new ParameterizedThreadStart (ThreadProc));
			t.IsBackground = true;
			t.Start (args);
		}

		void ThreadProc (object state)
		{
			T args = (T) state;

			Delegate[] list = null;
			lock (this) {
				if (eventList != null)
					list = eventList.GetInvocationList ();
			}

			if (list != null) {
				foreach (EventHandler<T> h in list) {
					h.BeginInvoke (this, args,
						       new AsyncCallback (Callback), null);
				}
			}
		}

		void Callback (IAsyncResult ar)
		{
			EventHandler<T> h = (EventHandler<T>)((AsyncResult)ar).AsyncDelegate;
			try {
				h.EndInvoke (ar);
			}
			catch (Exception ex) {
				Console.WriteLine (ex.Message);
				eventList -= h;
			}
		}
	}
}
