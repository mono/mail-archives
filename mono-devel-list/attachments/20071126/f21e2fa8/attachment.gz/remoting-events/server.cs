using System;
using System.Runtime.Remoting;

namespace ACME
{
	public class Server : MarshalByRefObject, IServerApi
	{
		AsyncEvent<EventArgs> testEvent = new AsyncEvent <EventArgs> ();
		
		public override object InitializeLifetimeService ()
		{
			return null;
		}
		
		public void Test ()
		{
			Console.WriteLine ("Server: Test () called");
			RaiseTest (EventArgs.Empty);
		}

		public void AddListener (IEvents e)
		{
			testEvent.Add (new EventHandler<EventArgs> (e.OnTest));
		}

		public void RemoveListener (IEvents e)
		{
			testEvent.Remove (new EventHandler<EventArgs> (e.OnTest));
		}

		void RaiseTest (EventArgs args)
		{
			testEvent.Raise (args);
		}
	}

	public class App
	{
		public static void Main()
		{
			RemotingConfiguration.Configure ("server.exe.config", false);
			Console.WriteLine ("Ready...");
			Console.ReadLine ();
		}
	}
}
