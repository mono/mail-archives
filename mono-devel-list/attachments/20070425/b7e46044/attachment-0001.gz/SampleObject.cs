using System;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;

namespace CodeGuru.Remoting
{
  /// <remarks>
  /// Sample object to demonstrate the use of .NET Remoting.
  /// </remarks>
  public class SampleObject : MarshalByRefObject 
  {
   /// <summary>
   /// Constructor
   /// </summary> 
   public SampleObject()
   {
   }

   /// <summary>
   /// Return a hello message
   /// </summary>
   /// <returns>Hello world message</returns>
   public string HelloWorld()
   {
     return "nothing";
   }
  }
}
