using System;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;

namespace CodeGuru.Remoting
{
  /// <remarks>
  /// Sample client to demonstrate the use of .NET Remoting.
  /// </remarks>
  public class SampleClient
  {
   public static int Main(string [] args)
   {
     // Create a channel for communicating w/ the remote object
     // Notice no port is specified on the client
     TcpChannel chan = new TcpChannel();
     ChannelServices.RegisterChannel(chan);

     // Create an instance of the remote object
     SampleObject obj = (SampleObject) Activator.GetObject( 
         typeof(CodeGuru.Remoting.SampleObject),
         "tcp://localhost:8080/HelloWorld" );

     // Use the object
     if( obj.Equals(null) )
     {
       System.Console.WriteLine("Error: unable to locate server");
     }
     else
     {
       Console.WriteLine(obj.HelloWorld());
     }
     return 0;
   } 
  }
}