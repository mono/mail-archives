using System;
using System.Text;
using System.Diagnostics;

namespace CodeGuru.Remoting
{
  /// <remarks>
  /// Sample object to demonstrate the use of .NET Remoting.
  /// </remarks>
  public class SampleObject : System.MarshalByRefObject 
  {
   /// <summary>
   /// Constructor
   /// </summary> 
   public SampleObject()
   {
   }

   /// <summary>
   /// Return a hello message
   /// </summary>
   /// <returns>Hello world message</returns>
   public string HelloWorld()
   {
     return "Hello World!";
   }
  }
}
