using System;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;

namespace CodeGuru.Remoting
{
  /// <remarks>
  /// Sample server to demonstrate the use of .NET Remoting.
  /// </remarks>
  public class SampleServer
  {
   public static int Main(string [] args) 
   {
    // Create an instance of a channel
     TcpChannel channel = new TcpChannel(8080);
     ChannelServices.RegisterChannel(channel);
   
     // Register as an available service with the name HelloWorld
     RemotingConfiguration.RegisterWellKnownServiceType( 
         typeof(SampleObject), 
         "HelloWorld", 
         WellKnownObjectMode.SingleCall );

     System.Console.WriteLine("Press the enter key to exit...");
     System.Console.ReadLine();
     return 0;
   }

  }
}
