//
// FtpWebResponse.cs: Implementation of .NET Framework v2.0 class
// System.Net.FtpWebResponse
//
// Author:
//      Martin Hinks <m.hinks@gmail.com>
//
// Copyright (C) 2004-2005 Novell, Inc. (http://www.novell.com)
//
// Permission is hereby granted, free of charge, to any person obtaining
// a copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to
// permit persons to whom the Software is furnished to do so, subject to
// the following conditions:
// 
// The above copyright notice and this permission notice shall be
// included in all copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
// NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
// LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
// OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
// WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
//

using System;
using System.Collections;
using System.Configuration;
using System.IO;
using System.Net.Cache;
using System.Net.Sockets;
using System.Runtime.Remoting.Messaging;
using System.Runtime.Serialization;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading;

namespace System.Net
{
	
	[Serializable]
	public class FtpWebResponse : WebResponse, IDisposable {
		#region Variables
		FtpStatusCode statusCode;
		Uri responseUri;
		DateTime lastModified;
		Stream returnStream;
		
		string welcomeMessage;
		string statusDescription;
		string exitMessage;
		string bannerMessage;
		
		FtpAsyncResult asyncResult;
		
		internal StringBuilder log = new StringBuilder();
		
		bool disposed = false;
		
		int responseLength;
		Byte[] byteArray;
		#endregion
		
		#region Properties
		
		public string WelcomeMessage {
			get { return welcomeMessage; }
		}
		
		
		
		public string StatusDescription {
			get { return statusDescription; }
		}
		
		
		
		public FtpStatusCode StatusCode {
			get { return statusCode; }
		}
		
	
		public override Uri ResponseUri {
			get { return responseUri; }
		}
		
		
	
		public DateTime LastModified {
			get { return lastModified; }
		}
		
		public override WebHeaderCollection Headers {
			//Always returns blank object
			get { return new WebHeaderCollection(); }
		}
		
		
		public string ExitMessage {
			get { return exitMessage; }
		}
		
		
		public override long ContentLength {
			get {
				throw new System.NotSupportedException(); 
				return returnStream.Length; 
			}
		}
		
		
		public string BannerMessage {
			get { return bannerMessage; }
		}
			
		#endregion
		
		#region Public Methods
		public override void Close ()
		{
			((IDisposable) this).Dispose ();
		}
		
		#endregion
		
		#region Private Methods
		
		private void Thrower(Exception e){
   			//Throw an exception and mark operation as complete
   			asyncResult.SetCompleted(true,e);
   			throw e;
   		}
		
		void IDisposable.Dispose ()
		{
			Dispose (true);
			GC.SuppressFinalize (this);  
		}
		
		protected virtual void Dispose (bool disposing) 
		{
			if (this.disposed)
				return;
			this.disposed = true;
			
			if (disposing) {
				// release managed resources
				responseUri = null;
				statusDescription = null;
				welcomeMessage = null;
				exitMessage = null;
				bannerMessage = null;
			}
			
			// release unmanaged resources
			returnStream = null;
			if (returnStream != null)
				returnStream.Close ();
		}
		
		private void CheckDisposed () 
		{
			if (disposed)
				throw new ObjectDisposedException (GetType ().FullName);
		}
		
   			      
		internal void UpdateCode (Uri uri, string method, MemoryStream responseStream, FtpAsyncResult result) {
			this.asyncResult=result;
			responseLength = (int)responseStream.Length;
			byteArray = new Byte[responseLength];
			string message;
			int code;
			switch (method) {
				case "501":
					//Connect              
	        		responseStream.Seek(0,0);
	        		responseStream.Read(byteArray,0,responseLength);
	        		bannerMessage = Encoding.ASCII.GetString(byteArray,0,responseLength);
	        		log.Append(bannerMessage);
	        		this.statusCode = FtpStatusCode.SendUserCommand;
	        		this.statusDescription = bannerMessage;
					break;
				case "502":
					//LoginName              
	        		responseStream.Seek(0,0);
	        		responseStream.Read(byteArray,0,responseLength);
	        		message = Encoding.ASCII.GetString(byteArray,0,responseLength);
	        		log.Append(message);
	        		try {
	        			code = int.Parse(message.Substring(0,3));
	        		} catch (Exception) {
	        			code = -1;
	        		}
	        		if(code!=331){
	        			this.statusCode = FtpStatusCode.NotLoggedIn;
	        			this.statusDescription = message;
	        			Thrower(new ProtocolViolationException("Invalid credential: Username"));
	        		}
	        		this.statusCode = FtpStatusCode.SendPasswordCommand;
	        		this.statusDescription = message;
					break;
				case "503":
					//Password
	        		responseStream.Seek(0,0);
	        		responseStream.Read(byteArray,0,responseLength);
	        		message = Encoding.ASCII.GetString(byteArray,0,responseLength);
	        		log.Append(message);
	        		
	        		try {
	        			code = int.Parse(message.Substring(0,3));
	        		} catch (Exception) {
	        			code = -1;
	        		}
	        		
	        		if(code!=230){
	        			this.statusCode = FtpStatusCode.NotLoggedIn;
	        			this.statusDescription = message;
	        			
	        			Thrower(new ProtocolViolationException("Invalid credential: Password"));
	        		}
	        		this.statusCode = FtpStatusCode.LoggedInProceed;
	        		this.statusDescription = message;
					break;
				case "504":
					//SYST
	        		responseStream.Seek(0,0);
	        		responseStream.Read(byteArray,0,responseLength);
	        		message = Encoding.ASCII.GetString(byteArray,0,responseLength);
	        		log.Append(message);
	        		
	        		try {
	        			code = int.Parse(message.Substring(0,3));
	        		} catch (Exception) {
	        			code = -1;
	        		}
	        		//if(code!=215){
	        			//this.statusCode = FtpStatusCode.CommandNotImplemented;
	        			//this.statusDescription = message;
	        			//throw new ProtocolViolationException("Invalid credential: Password");
	        		//}
	        		this.statusCode = FtpStatusCode.CommandOK;
	        		this.statusDescription = message;
					break;
				case "505":
					//LIST
					responseStream.Seek(0,0);
	        		responseStream.Read(byteArray,0,responseLength);
	        		message = Encoding.ASCII.GetString(byteArray,0,responseLength);
	        		log.Append(message);
	        		
	        		try {
	        			code = int.Parse(message.Substring(0,3));
	        		} catch (Exception) {
	        			code = -1;
	        		}
	        		
	        		this.statusCode = FtpStatusCode.OpeningData;
	        		this.statusDescription = message;
					break;
				default:
					responseStream.Seek(0,0);
	        		responseStream.Read(byteArray,0,responseLength);
	        		message = Encoding.ASCII.GetString(byteArray,0,responseLength);
	        		log.Append(message);
	        		
	        		try {
	        			code = int.Parse(message.Substring(0,3));
	        		} catch (Exception) {
	        			code = -1;
	        		}
	        		this.statusCode = FtpStatusCode.CommandOK;
	        		this.statusDescription = message;
					break;
			}
		}      
			
		#endregion
		
		#region ctors
		// Constructors
		
		internal FtpWebResponse (Uri uri, string method, MemoryStream responseStream, FtpAsyncResult result)
		{   this.asyncResult = result;
			this.responseUri = uri;
			
			responseLength = (int)responseStream.Length;
			byteArray = new Byte[responseLength];
			
			switch (method) {
			case "501":
				//Connect              
        		responseStream.Seek(0,0);
        		responseStream.Read(byteArray,0,responseLength);
        		bannerMessage = Encoding.ASCII.GetString(byteArray,0,responseLength);
				log.Append(bannerMessage);
				break;
			default:
				System.Console.WriteLine("OTHER");
				break;
			}
			
		}

		protected FtpWebResponse (SerializationInfo serializationInfo, StreamingContext streamingContext)
		{
			SerializationInfo info = serializationInfo;
			responseUri = (Uri) info.GetValue ("uri", typeof (Uri));
			statusDescription = info.GetString ("statusDescription");
			statusCode = (FtpStatusCode) info.GetValue ("statusCode", typeof (FtpStatusCode));
		}
		#endregion
	}
}
