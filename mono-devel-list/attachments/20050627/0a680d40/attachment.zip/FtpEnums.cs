//
// FTPMethods.cs - FTPMethods enum
//
// Author:
//      Martin Hinks <m.hinks@gmail.com>
//
// Copyright (C) 2004-2005 Novell, Inc. (http://www.novell.com)
//
// Permission is hereby granted, free of charge, to any person obtaining
// a copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to
// permit persons to whom the Software is furnished to do so, subject to
// the following conditions:
// 
// The above copyright notice and this permission notice shall be
// included in all copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
// NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
// LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
// OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
// WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
//

using System;

namespace System.Net
{
	public enum FtpStatusCode {
		AccountNeeded, //Specifies that a user account on the server is required. 
		ActionAbortedLocalProcessingError, //Specifies that an error occurred that prevented the request action from completing. 
		ActionAbortedUnknownPageType, //Specifies that the requested action cannot be taken because the specified page type is unknown. Page types are described in RFC 959 Section 3.1.2.3 
		ActionNotTakenFilenameNotAllowed, //Specifies that the requested action cannot be performed on the specfied file. 
		ActionNotTakenFileUnavailable, //Specifies that the requested action cannot be performed on the specfied file because the file is not available. 
		ActionNotTakenFileUnavailableOrBusy, //Specifies that the requested action cannot be performed on the specfied file because the file is not available or is being used. 
		ActionNotTakenInsufficientSpace,  
		ArgumentSyntaxError, //Specifies that one or more command arguments has a syntax error. 
		BadCommandSequence, //Specifies that the sequence of commands is not in the correct order. 
		CantOpenData, //Specifies that the data connection cannot be opened. 
		ClosingControl, //Specifies that the server is closing the control connection. 
		ClosingData, //Specifies that the server is closing the data connection and that the requested file action was successful. 
		CommandExtraneous, //Specifies that the command is not implemented by the server because it is not needed. 
		CommandNotImplemented, //Specifies that the command is not implemented by the FTP server. 
		CommandOK, //Specifies that the command completed successfully. 
		CommandSyntaxError, //Specifies that the command has a syntax error or is not a command recognized by the server. 
		ConnectionClosed, //Specifies that the connection has been closed. 
		DataAlreadyOpen, //Specifies that the data connection is already open and the requested transfer is starting. 
		DirectoryStatus, //Specifies the status of a directory. 
		EnteringPassive, //Specifies that the server is entering passive mode. 
		FileActionAborted, //Specifies that the requested action cannot be performed. 
		FileActionOK, //Specifies that the requested file action completed successfully. 
		FileCommandPending, //Specifies that the requested file action requires additional information. 
		FileStatus, //Specifies the status of a file. 
		LoggedInProceed, //Specifies that the user is logged in and can send commands. 
		NeedLoginAccount, //Specifies that the server requires a login account to be supplied. 
		NotLoggedIn, //Specifies that login information must be sent to the server. 
		OpeningData, //Specifies that the server is opening the data connection. 
		PathnameCreated, //Specifies that the requested path name was created. 
		RestartMarker, //Specifies that the response contains a restart marker reply. The text of the description that accompanies this status contains the user data stream marker and the server marker. 
		SendPasswordCommand, //Specifies that the server expects a password to be supplied. 
		SendUserCommand, //Specifies that the server is ready for a user login operation. 
		ServerWantsSecureSession, //Specifies that the server accepts the authentication mechanism specified by the client, and the exchange of security data is complete. 
		ServiceNotAvailable,  
		ServiceTemporarilyNotAvailable,  
		SystemType, //Specifies the system type name using the system names published in the Assigned Numbers document published by the Internet Assigned Numbers Authority. 
		Undefined, //Included for completeness, this value is never returned by servers. 
	}
	
	public class FtpMethods {
		public static string Connect = "501";
		public static string UserName = "502";
		public static string Password = "503";
		public static string SYST = "504";
		public static string List = "505";
		public static string NegotiateTLS = "506";		
	}	
}
