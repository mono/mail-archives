imports System
imports System.Web
imports System.Web.UI
imports System.Web.UI.WebControls
imports System.Web.UI.HtmlControls

Namespace GHTTests.System_Web_dll.System_Web_UI
Public Class Control_ClientID
    Inherits GHTControlBase
#Region " Web Form Designer	Generated Code "
    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is	required by	the	Web	Form Designer.
    'Do	not	delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do	not	modify it using	the	code editor.
        InitializeComponent()
    End Sub
#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Dim frm As System.Web.UI.HtmlControls.HtmlForm = FindControl("Form1")
      GHTTestBegin(frm)
      For Each currentType As Type In TypesToTest
        GHTHeader(currentType.ToString())
        Test(currentType)
      Next
      GHTTestEnd()
    End Sub

    Private Sub Test(ByRef ctrlType As Type)
            'ClientId - server generated.
            'Because the id is random, then it cannot be compared between two servers,
            'There for I only test that a value is automatically set, and does
            'not add the control to the subtest.
            Try
                GHTSubTestBegin(ctrlType, "ClientId - server generated", False)
                GHTAddToActiveForm(TestedControl)
                If Not TestedControl.ClientID = String.Empty Then
                    GHTSubTestAddResult("Passed, ClientID is set by the server.")
                Else
                    GHTSubTestAddResult("Failed, ClientID is not set by the server.")
                End If
            Catch ex As Exception
                GHTSubTestUnexpectedExceptionCaught(ex)
            End Try
            GHTSubTestEnd()

            'ClientId - Id property set to String.empty
            'As in previous subtest, the ClientID is a random number, and cannot be compared,
            'There for I only test that the value is not string.empty, 
            'and does not add the control to the subtest.
            Try
                GHTSubTestBegin(ctrlType, "ClientId - Id property set to String.empty", False)
                GHTAddToActiveForm(TestedControl)
                TestedControl.ID = String.Empty
                If Not TestedControl.ClientID = String.Empty Then
                    GHTSubTestAddResult("Passed, ClientID is set by the server.")
                Else
                    GHTSubTestAddResult("Failed, ClientID is not set by the server.")
                End If
            Catch ex As Exception
                GHTSubTestUnexpectedExceptionCaught(ex)
            End Try
            GHTSubTestEnd()

            'ClientId - overriden by Id property:
            Try
                GHTSubTestBegin(ctrlType, "ClientId - overriden by Id property")
                TestedControl.ID = ctrlType.ToString() + "_Id"
            Catch ex As Exception
                GHTSubTestUnexpectedExceptionCaught(ex)
            End Try
            GHTSubTestEnd()

        End Sub
End Class
End Namespace