imports System
Imports System.Data
Imports System.Collections
Imports System.Web
imports System.Web.UI
imports System.Web.UI.WebControls
imports System.Web.UI.HtmlControls

Namespace GHTTests.System_Web_dll.System_Web_UI_WebControls
Public Class DataGrid_EditItemStyle
    Inherits GHTBaseWeb
#Region " Web Form Designer	Generated Code "
    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub
        Protected WithEvents DataGrid5 As System.Web.UI.WebControls.DataGrid
        Protected WithEvents GHTSubTest5 As GHTWebControls.GHTSubTest
        Protected WithEvents DataGrid4 As System.Web.UI.WebControls.DataGrid
        Protected WithEvents GHTSubTest4 As GHTWebControls.GHTSubTest
        Protected WithEvents DataGrid3 As System.Web.UI.WebControls.DataGrid
        Protected WithEvents GHTSubTest3 As GHTWebControls.GHTSubTest
        Protected WithEvents DataGrid2 As System.Web.UI.WebControls.DataGrid
        Protected WithEvents GHTSubTest2 As GHTWebControls.GHTSubTest
        Protected WithEvents DataGrid1 As System.Web.UI.WebControls.DataGrid
        Protected WithEvents GHTSubTest1 As GHTWebControls.GHTSubTest

    'NOTE: The following placeholder declaration is	required by	the	Web	Form Designer.
    'Do	not	delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do	not	modify it using	the	code editor.
        InitializeComponent()
    End Sub
#End Region

#Region "Data Source creation functions"
        Private Function ds_array_list() As ArrayList
            Dim array_list As New ArrayList

            array_list.Add("one")
            array_list.Add("two")
            array_list.Add("three")
            array_list.Add("four")
            array_list.Add("five")
            array_list.Add("six")
            array_list.Add("seven")
            array_list.Add("eight")
            array_list.Add("nine")
            array_list.Add("ten")

            Return array_list
        End Function
        Private Function ds_data_set() As DataSet

            Dim ds As New DataSet("CustOrdersDS")

            Dim dtCusts As New DataTable("Customers")
            ds.Tables.Add(dtCusts)

            Dim dtOrders As New DataTable("Orders")
            ds.Tables.Add(dtOrders)

            ' add ID column with autoincrement numbering
            ' and Unique constraint
            Dim dc As DataColumn = dtCusts.Columns.Add("ID", GetType(Integer))
            dc.AllowDBNull = False
            dc.AutoIncrement = True
            dc.AutoIncrementSeed = 1
            dc.AutoIncrementStep = 1
            dc.Unique = True

            ' make the ID column part of the PrimaryKey
            ' for the table
            dtCusts.PrimaryKey = New DataColumn() {dc}

            ' add name and company columns with length restrictions
            ' and default values
            dc = dtCusts.Columns.Add("Name", GetType(String))
            dc.MaxLength = 14
            dc.DefaultValue = "nobody"
            dc = dtCusts.Columns.Add("Company", GetType(String))
            dc.MaxLength = 14
            dc.DefaultValue = "nonexistent"

            ' fill the table
            Dim tmp_array As ArrayList = ds_array_list()
            Dim items As IEnumerator = tmp_array.GetEnumerator()
            While items.MoveNext()
                Dim dr As DataRow = dtCusts.NewRow()
                dr("Name") = "n_" & CType(items.Current, String)
                dr("Company") = "c_" & CType(items.Current, String)
                dtCusts.Rows.Add(dr)
            End While

            ' add ID columns with autoincrement numbering
            ' and Unique constraint
            dc = dtOrders.Columns.Add("ID", GetType(Integer))
            dc.AllowDBNull = False
            dc.AutoIncrement = True
            dc.AutoIncrementSeed = 1
            dc.AutoIncrementStep = 1
            dc.Unique = True

            ' add custid, date and total columns
            dtOrders.Columns.Add("CustID", GetType(Integer))
            dtOrders.Columns.Add("Date", GetType(DateTime))
            dtOrders.Columns.Add("Total", GetType(Decimal))

            Dim i As Integer
            For i = 1 To 10
                Dim dr As DataRow = dtOrders.NewRow()
                dr("CustID") = i
                dr("Date") = CDate(#7:00:00 AM#)
                dr("Total") = i * i
                dtOrders.Rows.Add(dr)
            Next

            ' make the ID column part of the PrimaryKey
            ' for the table
            dtOrders.PrimaryKey = New DataColumn() {dc}

            Return ds
        End Function
        Private Function ds_data_table() As DataTable

            Dim dt As New DataTable("Customers")

            ' add ID column with autoincrement numbering
            ' and Unique constraint
            Dim dc As DataColumn = dt.Columns.Add("ID", GetType(Integer))
            dc.AllowDBNull = False
            dc.AutoIncrement = True
            dc.AutoIncrementSeed = 1
            dc.AutoIncrementStep = 1
            dc.Unique = True

            ' make the ID column part of the PrimaryKey
            ' for the table
            dt.PrimaryKey = New DataColumn() {dc}

            ' add name and company columns with length restrictions
            ' and default values
            dc = dt.Columns.Add("Name", GetType(String))
            dc.MaxLength = 14
            dc.DefaultValue = "nobody"
            dc = dt.Columns.Add("Company", GetType(String))
            dc.MaxLength = 14
            dc.DefaultValue = "nonexistent"

            ' fill the table
            Dim tmp_array As ArrayList = ds_array_list()
            Dim items As IEnumerator = tmp_array.GetEnumerator()
            While items.MoveNext()
                Dim dr As DataRow = dt.NewRow()
                dr("Name") = "n_" & CType(items.Current, String)
                dr("Company") = "c_" & CType(items.Current, String)
                dt.Rows.Add(dr)
            End While

            Return dt
        End Function
#End Region

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            'Put user code to initialize the page here

            Dim frm As System.Web.UI.HtmlControls.HtmlForm = Me.FindControl("Form1")
            GHTTestBegin(frm)

            GHTActiveSubTest = GHTSubTest1
            Try
                DataGrid1.DataSource = ds_data_table()
                DataGrid1.EditItemIndex = 7
                DataGrid1.DataBind()
                GHTSubTestAddResult(DataGrid1.EditItemIndex)
            Catch ex As Exception
                GHTSubTestUnexpectedExceptionCaught(ex)
            End Try

            GHTActiveSubTest = GHTSubTest2
            Try
                DataGrid2.DataSource = ds_data_table()
                DataGrid2.EditItemIndex = 4
                DataGrid2.DataBind()
                GHTSubTestAddResult(DataGrid2.EditItemIndex)
            Catch ex As Exception
                GHTSubTestUnexpectedExceptionCaught(ex)
            End Try

            GHTActiveSubTest = GHTSubTest3
            Try
                DataGrid3.DataSource = ds_data_table()
                DataGrid3.EditItemIndex = 2
                DataGrid3.DataBind()
                GHTSubTestAddResult(DataGrid3.EditItemIndex)
            Catch ex As Exception
                GHTSubTestUnexpectedExceptionCaught(ex)
            End Try

            GHTActiveSubTest = GHTSubTest4
            Try
                DataGrid4.DataSource = ds_data_table()
                DataGrid4.EditItemIndex = 7
                DataGrid4.DataBind()
                GHTSubTestAddResult(DataGrid4.EditItemIndex)
            Catch ex As Exception
                GHTSubTestUnexpectedExceptionCaught(ex)
            End Try

            GHTActiveSubTest = GHTSubTest5
            Try
                DataGrid5.DataSource = ds_data_table()
                DataGrid5.EditItemIndex = 4
                DataGrid5.DataBind()
                GHTSubTestAddResult(DataGrid5.EditItemIndex)
            Catch ex As Exception
                GHTSubTestUnexpectedExceptionCaught(ex)
            End Try

            GHTSubTestBegin("GHTSubTest6")
            Try
                Dim dg As New System.Web.UI.WebControls.DataGrid
                GHTActiveSubTest.Controls.Add(dg)

                dg.EditItemStyle.HorizontalAlign = HorizontalAlign.Right
                dg.EditItemIndex = 4
                dg.DataSource = ds_data_table()
                dg.DataBind()
            Catch ex As Exception
                GHTSubTestUnexpectedExceptionCaught(ex)
            End Try
            GHTSubTestEnd()

            GHTSubTestBegin("GHTSubTest7")
            Try
                Dim dg As New System.Web.UI.WebControls.DataGrid
                GHTActiveSubTest.Controls.Add(dg)

                dg.EditItemStyle.HorizontalAlign = HorizontalAlign.Right
                dg.EditItemStyle.VerticalAlign = VerticalAlign.Top
                dg.EditItemStyle.Wrap = False
                dg.EditItemIndex = 4
                dg.DataSource = ds_data_table()
                dg.DataBind()
            Catch ex As Exception
                GHTSubTestUnexpectedExceptionCaught(ex)
            End Try
            GHTSubTestEnd()

            GHTTestEnd()
        End Sub
End Class
End Namespace