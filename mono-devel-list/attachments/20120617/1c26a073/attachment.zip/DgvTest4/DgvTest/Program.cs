﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace DgvTest
{
	internal sealed class Assert
	{
		public static void AreEqual<T> (T a_correct, T a_found,
			string a_strMessage)
		{
			if (!a_correct.Equals (a_found))
				MessageBox.Show (a_strMessage
					+ ": expected " + a_correct.ToString()
					+ ", found " + a_found.ToString());
		}
		public static void AreNotEqual<T> (T a_correct, T a_found,
			string a_strMessage)
		{
			string strCorrect, strFound;
			bool bEquals = false;

			if (a_correct == null)
			{
				strCorrect = "null";
				if (a_found == null)
					bEquals = true;
			}
			else
			{
				strCorrect = a_correct.ToString();
				bEquals = a_correct.Equals (a_found);
			}
			strFound = (a_found == null) ? "null" : a_found.ToString();
			if (bEquals)
				MessageBox.Show (a_strMessage
					+ ": expected not " + strCorrect
					+ ", found " + strFound);
		}
	}
	internal sealed class Program
	{
		// Send a mouse event in Win32.
		[DllImport("user32.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
		public static extern void mouse_event(long dwFlags, long dx, long dy, long dwData, long dwExtraInfo);
		private const int MOUSEEVENTF_LEFTDOWN = 0x02;
		private const int MOUSEEVENTF_LEFTUP = 0x04;
		private const int MOUSEEVENTF_RIGHTDOWN = 0x08;
		private const int MOUSEEVENTF_RIGHTUP = 0x10;
		private const int MOUSEEVENTF_ABSOLUTE = 0x8000;

		// Set the mouse-pointer position in Win32.
		[DllImport("user32.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
		public static extern long SetCursorPos (int x, int y);

		// Convert from window coordinates to screen coordinates in Win32.
		[DllImport("user32.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
		public static extern bool ClientToScreen (IntPtr hWnd, ref Win32Point point);
		[StructLayout (LayoutKind.Sequential)]
		public struct Win32Point
		{
			public int x;
			public int y;
		};

		private class MyForm : Form
		{
			// A custom data-grid-view, created solely so that
			// mouse clicks can be faked on it.
			public class MyDataGridView : DataGridView
			{
				public MyDataGridView()
				: base()
				{
				}

				internal void OnMouseDownInternal (MouseEventArgs e)
				{
					OnMouseDown (e);
				}

				internal void OnMouseUpInternal (MouseEventArgs e)
				{
					OnMouseUp (e);
				}
			};

			DataGridViewCellMouseEventHandler m_ehCellMouseDown;
			void cell_MouseDown (object sender, DataGridViewCellMouseEventArgs e)
			{
				Console.WriteLine ("cell_MouseDown: x is " + e.X + ", y is " + e.Y);
			}
			MouseEventHandler m_ehCbMouseDown;
			void cb_MouseDown (object sender, MouseEventArgs e)
			{
				Console.WriteLine ("cb_MouseDown: x is " + e.X + ", y is " + e.Y);
			}

			void dgv_EditingControlShowing (object sender,
				DataGridViewEditingControlShowingEventArgs e)
			{
				Console.WriteLine ("EditingControlShowing event");
				DataGridView dgv = sender as DataGridView;
				if (dgv.CurrentCellAddress.X == 0)
				{
					// Get the combo-box control.
					ComboBox cb = e.Control as ComboBox;

					// Install the mouse-down event handler.
					cb.MouseDown -= m_ehCbMouseDown;
					cb.MouseDown += m_ehCbMouseDown;
				}
				else
					Assert.AreEqual (0, 1, "1-5");
			}

			internal MyForm()
			: base()
			{
				m_ehCbMouseDown = new MouseEventHandler (cb_MouseDown);
				m_ehCellMouseDown = new DataGridViewCellMouseEventHandler (cell_MouseDown);
				this.Closed += new EventHandler (this_Closed);
				this.Load += new EventHandler (this_Load);
			}
			internal void this_Load (object sender, EventArgs e)
			{
				Label label = new Label();
				label.Text = "Label";
				label.Parent = this;
				MyDataGridView dgv = new MyDataGridView ();
				dgv.Parent = this;
				DataGridViewComboBoxColumn cbCol;

				// Add the event-handler.
				/* dgv.EditingControlShowing
					+= new DataGridViewEditingControlShowingEventHandler
						(dgv_EditingControlShowing); */

				// Create a combo-box column.
				cbCol = new DataGridViewComboBoxColumn ();
				cbCol.HeaderText = "Name";
				dgv.Columns.Add (cbCol);

				// .NET requires that all possible values for combo-boxes
				// in a column are added to the column.
				cbCol.Items.Add ("Item1");
				cbCol.Items.Add ("Item2");
				cbCol.Items.Add ("Item3");
				cbCol.Items.Add ("Item4");

				// Set up the contents of the data-grid.
				dgv.Rows.Add ("Item1");
				dgv.Rows.Add ("Item2");

				// Set up the cell event-handler.
				//dgv.CellMouseDown += m_ehCellMouseDown;

				// Select the cell.
				dgv.CurrentCell = dgv.Rows[0].Cells[0];

				// Focus the data-grid-view.  (Without this, its Leave
				// event won't get called when something outside of the
				// data-grid-view gets focused.)
				dgv.Focus();

				// Show the form, let it draw.
				this.Show();
				Application.DoEvents();

				// Locate the drop-down button.  (This code is taken from mono-winforms,
				// from the private method DataGridViewComboBoxCell.CalculateButtonArea(),
				// and was then hacked mercilessly.)
				Rectangle button_area = Rectangle.Empty;
				{
					int border = 3 /* ThemeEngine.Current.Border3DSize.Width */;
					const int button_width = 16;
					Rectangle text_area = dgv.GetCellDisplayRectangle (0, 0, false);
					button_area.X = text_area.Right - button_width - border;
					button_area.Y = text_area.Y + border;
//					button_area.X = text_area.Width - button_width - border;
//					button_area.Y = border;
					button_area.Width = button_width;
					button_area.Height = text_area.Height - 2 * border;
				}

				// Click on the drop-down button.
				int x = button_area.X + (button_area.Width / 2);
				int y = button_area.Y + (button_area.Height / 2);
				if (Environment.OSVersion.Platform == PlatformID.Win32NT
				&& Type.GetType ("Mono.Runtime") == null)
				{
					// Calling OnMouseDownInternal() in Win32 doesn't work.
					// My best guess as to why is that the WinForms ComboBox
					// is a wrapper around the ComCtl control, e.g. similar
					// to the reason that Paint event-handlers don't work on
					// TreeView.  So we go through all this rigamarole to
					// simulate a mouse click.

					// First, get the location of the desired mouse-click, in
					// data-grid-view coordinates.
					Win32Point ptGlobal = new Win32Point();
					ptGlobal.x = x + dgv.Location.X;
					ptGlobal.y = y + dgv.Location.Y;

					// Convert that to screen coordinates.
					ClientToScreen (this.Handle, ref ptGlobal);

					// Move the mouse-pointer there.  (Yes, this really appears
					// to be necessary.)
					SetCursorPos (ptGlobal.x, ptGlobal.y);

					// Convert screen coordinates to mouse coordinates.
					ptGlobal.x *= (65535 / SystemInformation.VirtualScreen.Width);
					ptGlobal.y *= (65535 / SystemInformation.VirtualScreen.Height);

					// Finally, fire a mouse-down and mouse-up event.
					mouse_event (MOUSEEVENTF_LEFTDOWN|MOUSEEVENTF_ABSOLUTE,
						ptGlobal.x, ptGlobal.y, 0, 0);
					mouse_event (MOUSEEVENTF_LEFTUP|MOUSEEVENTF_ABSOLUTE,
						ptGlobal.x, ptGlobal.y, 0, 0);

					// Let the system process these events.
					Application.DoEvents();
				}
				else
				{
					// And this is how the same code is done under Linux.
					// (No one should wonder why I prefer Mono to MS Windows .NET ;-)
					MouseEventArgs me = new MouseEventArgs (MouseButtons.Left, 1, x, y, 0);
					DataGridViewCellMouseEventArgs cme = new DataGridViewCellMouseEventArgs (0, 0, x, y, me);
					dgv.OnMouseDownInternal (cme);
					dgv.OnMouseUpInternal (cme);
				}

				// Make sure that created an editing control.
				ComboBox cb = dgv.EditingControl as ComboBox;
				Assert.AreNotEqual (null, cb, "1-1");

				// Make sure that dropped down the menu.
				Assert.AreEqual (true, cb.DroppedDown, "1-2");

				// Close the menu.
				cb.DroppedDown = false;

				// Change the selection on the menu.
				cb.SelectedIndex = 2 /* "Item3" */;

				// Leave the data-grid-view.
				label.Focus();

				// That should have ended editing and saved the value.
				string cellValue = (string)(dgv.Rows[0].Cells[0].FormattedValue);
				Assert.AreEqual ("Item3", cellValue, "1-3");
			}
			internal void this_Closed (object sender, EventArgs e)
			{
				Application.Exit();
			}
		}

		[STAThread]
		private static void Main(string[] args)
		{
			// Create a form with a combo box.
			Form form = new MyForm ();
			form.ShowInTaskbar = false;
			form.Show ();

			// Display the results.
			Application.Run();
		}
	}
}
