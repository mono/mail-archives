// Permission is hereby granted, free of charge, to any person obtaining
// a copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to
// permit persons to whom the Software is furnished to do so, subject to
// the following conditions:
// 
// The above copyright notice and this permission notice shall be
// included in all copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
// NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
// LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
// OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
//
// Authors:
//	Alejandro Serrano "Serras"	(trupill@yahoo.es)
//

using System;
using System.Collections.Generic;

namespace System.Query
{	
	public static partial class Sequence
	{
		#region ToSequence
		
		[System.Runtime.CompilerServices.Extension]
		public static IEnumerable<T> ToSequence<T> (
			IEnumerable<T> source)
		{
			return (IEnumerable<T>)source;
		}
		
		#endregion
		
		#region ToArray
		
		[System.Runtime.CompilerServices.Extension]
		public static T[] ToArray<T> (
			IEnumerable<T> source)
		{
			if (source == null)
				throw new ArgumentNullException();
			
			List<T> list = new List<T>(source);
			return list.ToArray();
		}
		
		#endregion
		
		#region ToList
		
		[System.Runtime.CompilerServices.Extension]
		public static List<T> ToList<T> (
			IEnumerable<T> source)
		{
			if (source == null)
				throw new ArgumentNullException();
			
			return new List<T>(source);
		}
		
		#endregion
		
		#region ToDictionary
		
		[System.Runtime.CompilerServices.Extension]
		public static Dictionary<K, T> ToDictionary<T, K> (
			IEnumerable<T> source,
			Func<T, K> keySelector)
		{
			if (source == null || keySelector == null)
				throw new ArgumentNullException();
			
			Dictionary<K, T> dictionary = new Dictionary<K, T>();
			
			foreach (T element in source)
			{
				K key = keySelector(element);
				
				if (key == null)
					throw new ArgumentNullException();
				else if (dictionary.ContainsKey(key))
					throw new ArgumentException();
				else
					dictionary.Add(key, element);
			}
			
			return dictionary;
		}
		
		[System.Runtime.CompilerServices.Extension]
		public static Dictionary<K, E> ToDictionary<T, K, E> (
			IEnumerable<T> source,
			Func<T, K> keySelector,
			Func<T, E> elementSelector)
		{
			if (source == null || keySelector == null || elementSelector == null)
				throw new ArgumentNullException();
			
			Dictionary<K, E> dictionary = new Dictionary<K, E>();
			
			foreach (T element in source)
			{
				K key = keySelector(element);
				
				if (key == null)
					throw new ArgumentNullException();
				else if (dictionary.ContainsKey(key))
					throw new ArgumentException();
				else
					dictionary.Add(key, elementSelector(element));
			}
			
			return dictionary;
		}
		
		#endregion
		
		#region OfType
		
		[System.Runtime.CompilerServices.Extension]
		public static IEnumerable<T> OfType<T> (
			System.Collections.IEnumerable source)
		{
			if (source == null)
				throw new ArgumentNullException();
			
			foreach (object element in source)
			{
				if (element is T)
					yield return (T)element;
			}
		}
		
		#endregion
	}
}
