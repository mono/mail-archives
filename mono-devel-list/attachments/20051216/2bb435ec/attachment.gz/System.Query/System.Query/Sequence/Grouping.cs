// Permission is hereby granted, free of charge, to any person obtaining
// a copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to
// permit persons to whom the Software is furnished to do so, subject to
// the following conditions:
// 
// The above copyright notice and this permission notice shall be
// included in all copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
// NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
// LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
// OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
//
// Authors:
//	Alejandro Serrano "Serras"	(trupill@yahoo.es)
//

using System;
using System.Collections.Generic;

namespace System.Query
{	
	public static partial class Sequence
	{
		
		/** A NOTE ON IMPLEMENTATION REGARDING NULL KEYS
		 * 
		 *  GroupBy specification states that null ke values
		 *  are allowed. However, all implementations of 
		 *  Dictionary<K, T> bans null keys.
		 *  Because of this, a small trick has to be done:
		 * 	a special List<T> variable is created in order to
		 *  be filled with this null-key values.
		 *  Also, groups must be yielded in the order their
		 *  keys were found for first time, so we need to keep
		 *  a record on when the null-key values appeared
		 *  (that is nullCounter).
		 *  Then, when results are iterated and yielded, we
		 *  mantain a counter and if null-key values were
		 *  found, they are yielded in the order needed.
		 *  Because K can be a valuetype, compilers expose a
		 *  restriction on null values, that's why default(T)
		 *  is used. **/
		
		#region GroupBy
		
		private static List<T> ContainsGroup<K, T>(
			Dictionary<K, List<T>> items, K key, IEqualityComparer<K> comparer)
		{
			foreach (KeyValuePair<K, List<T>> value in items)
			{
				if (comparer.Equals(value.Key, key))
				    return value.Value;
			}
			return null;
		}
		
		[System.Runtime.CompilerServices.Extension]
		public static IEnumerable<Grouping<K, T>> GroupBy<T, K> (
			IEnumerable<T> source,
			Func<T, K> keySelector)
		{
			if (source == null || keySelector == null)
				throw new ArgumentNullException();
			
			Dictionary<K, List<T>> groups = new Dictionary<K, List<T>>();
			List<T> nullList = new List<T>();
			
			int counter = 0;
			int nullCounter = -1;
			
			foreach (T element in source)
			{
				K key = keySelector (element);
				if (key == null)
				{
					nullList.Add(element);
					if (nullCounter == -1)
					{
						nullCounter = counter;
						counter++;
					}
				}
				else
				{
					List<T> group = ContainsGroup(groups, key, EqualityComparer<K>.Default);
					if (group == null)
					{
						group = new List<T>();
						groups.Add(key, group);
						counter++;
					}
					group.Add(element);
				}
			}
			
			counter = 0;
			foreach (KeyValuePair<K, List<T>> group in groups)
			{
				if (counter == nullCounter)
				{
					Grouping<K, T> nullGroup = new Grouping<K, T>(default(K), nullList);
					yield return nullGroup;
					counter++;
				}
				Grouping<K, T> grouping = new Grouping<K, T>(group.Key, group.Value);
				yield return grouping;
				counter++;
			}
		}
		
		[System.Runtime.CompilerServices.Extension]
		public static IEnumerable<Grouping<K, T>> GroupBy<T, K> (
			IEnumerable<T> source,
			Func<T, K> keySelector,
			IEqualityComparer<K> comparer)
		{
			if (source == null || keySelector == null || comparer == null)
				throw new ArgumentNullException();
			
			Dictionary<K, List<T>> groups = new Dictionary<K, List<T>>();
			List<T> nullList = new List<T>();
			
			int counter = 0;
			int nullCounter = -1;
			
			foreach (T element in source)
			{
				K key = keySelector (element);
				if (key == null)
				{
					nullList.Add(element);
					if (nullCounter == -1)
					{
						nullCounter = counter;
						counter++;
					}
				}
				else
				{
					List<T> group = ContainsGroup(groups, key, comparer);
					if (group == null)
					{
						group = new List<T>();
						groups.Add(key, group);
						counter++;
					}
					group.Add(element);
				}
			}
			
			counter = 0;
			foreach (KeyValuePair<K, List<T>> group in groups)
			{
				if (counter == nullCounter)
				{
					Grouping<K, T> nullGroup = new Grouping<K, T>(default(K), nullList);
					yield return nullGroup;
					counter++;
				}
				Grouping<K, T> grouping = new Grouping<K, T>(group.Key, group.Value);
				yield return grouping;
				counter++;
			}
		}
		
		[System.Runtime.CompilerServices.Extension]
		public static IEnumerable<Grouping<K, E>> GroupBy<T, K, E> (
			IEnumerable<T> source,
			Func<T, K> keySelector,
			Func<T, E> elementSelector)
		{
			if (source == null || keySelector == null || elementSelector == null)
				throw new ArgumentNullException();
			
			Dictionary<K, List<E>> groups = new Dictionary<K, List<E>>();
			List<E> nullList = new List<E>();
			
			int counter = 0;
			int nullCounter = -1;

			foreach (T item in source)
			{
				K key = keySelector (item);
				E element = elementSelector(item);
				if (key == null)
				{
					nullList.Add(element);
					if (nullCounter == -1)
					{
						nullCounter = counter;
						counter++;
					}
				}
				else
				{
					List<E> group = ContainsGroup(groups, key, EqualityComparer<K>.Default);
					if (group == null)
					{
						group = new List<E>();
						groups.Add(key, group);
						counter++;
					}
					group.Add(element);
				}
			}
			
			counter = 0;
			foreach (KeyValuePair<K, List<E>> group in groups)
			{
				if (counter == nullCounter)
				{
					Grouping<K, E> nullGroup = new Grouping<K, E>(default(K), nullList);
					yield return nullGroup;
					counter++;
				}
				Grouping<K, E> grouping = new Grouping<K, E>(group.Key, group.Value);
				yield return grouping;
				counter++;
			}
		}
		
		[System.Runtime.CompilerServices.Extension]
		public static IEnumerable<Grouping<K, E>> GroupBy<T, K, E> (
			IEnumerable<T> source,
			Func<T, K> keySelector,
			Func<T, E> elementSelector,
			IEqualityComparer<K> comparer)
		{
			if (source == null || keySelector == null || comparer == null || elementSelector == null)
				throw new ArgumentNullException();
			
			Dictionary<K, List<E>> groups = new Dictionary<K, List<E>>();
			List<E> nullList = new List<E>();
			
			int counter = 0;
			int nullCounter = -1;

			foreach (T item in source)
			{
				K key = keySelector (item);
				E element = elementSelector(item);
				if (key == null)
				{
					nullList.Add(element);
					if (nullCounter == -1)
					{
						nullCounter = counter;
						counter++;
					}
				}
				else
				{
					List<E> group = ContainsGroup(groups, key, comparer);
					if (group == null)
					{
						group = new List<E>();
						groups.Add(key, group);
						counter++;
					}
					group.Add(element);
				}
			}
			
			counter = 0;
			foreach (KeyValuePair<K, List<E>> group in groups)
			{
				if (counter == nullCounter)
				{
					Grouping<K, E> nullGroup = new Grouping<K, E>(default(K), nullList);
					yield return nullGroup;
					counter++;
				}
				Grouping<K, E> grouping = new Grouping<K, E>(group.Key, group.Value);
				yield return grouping;
				counter++;
			}
		}
		
		#endregion
	}
}
