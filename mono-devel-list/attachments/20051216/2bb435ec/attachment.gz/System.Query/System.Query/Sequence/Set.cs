// Permission is hereby granted, free of charge, to any person obtaining
// a copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to
// permit persons to whom the Software is furnished to do so, subject to
// the following conditions:
// 
// The above copyright notice and this permission notice shall be
// included in all copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
// NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
// LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
// OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
//
// Authors:
//	Alejandro Serrano "Serras"	(trupill@yahoo.es)
//

using System;
using System.Collections.Generic;

namespace System.Query
{	
	public static partial class Sequence
	{

		#region Distinct
		
		[System.Runtime.CompilerServices.Extension]
		public static IEnumerable<T> Distinct<T> (
			IEnumerable<T> source)
		{
			if (source == null)
				throw new ArgumentNullException();
			
			List<T> items = new List<T>();
			
			foreach (T element in source)
			{
				if (IndexOf(items, element) == -1)
				{
					items.Add(element);
					yield return element;
				}
			}
		}
		
		#endregion
		
		#region Union
		
		[System.Runtime.CompilerServices.Extension]
		public static IEnumerable<T> Union<T> (
			IEnumerable<T> first,
			IEnumerable<T> second)
		{
			if (first == null || second == null)
				throw new ArgumentNullException();
			
			List<T> items = new List<T>();
			
			foreach (T element in first)
			{
				if (IndexOf(items, element) == -1)
				{
					items.Add(element);
					yield return element;
				}
			}
			
			foreach (T element in second)
			{
				if (IndexOf(items, element) == -1)
				{
					items.Add(element);
					yield return element;
				}
			}
		}
		
		#endregion
		
		#region Intersect
		
		[System.Runtime.CompilerServices.Extension]
		public static IEnumerable<T> Intersect<T> (
			IEnumerable<T> first,
			IEnumerable<T> second)
		{
			if (first == null || second == null)
				throw new ArgumentNullException();

			List<T> items = new List<T>(Distinct(first));
			bool[] marked = new bool[items.Count];
			for (int i = 0; i < marked.Length; i++)
				marked[i] = false;
			
			foreach (T element in second)
			{
				int index = IndexOf(items, element);
				if (index != -1)
					marked[index] = true;
			}
			
			for (int i = 0; i < marked.Length; i++)
			{
				if (marked[i])
					yield return items[i];
			}
		}
		
		#endregion
		
		#region Except
		
		[System.Runtime.CompilerServices.Extension]
		public static IEnumerable<T> Except<T> (
			IEnumerable<T> first,
			IEnumerable<T> second)
		{
			if (first == null || second == null)
				throw new ArgumentNullException();

			List<T> items = new List<T>(Distinct(first));

			foreach (T element in second)
			{
				int index = IndexOf(items, element);
				if (index == -1)
					items.Add(element);
				else
					items.RemoveAt(index);
			}
			
			foreach (T item in items)
				yield return item;
		}
		
		#endregion
	}
}
