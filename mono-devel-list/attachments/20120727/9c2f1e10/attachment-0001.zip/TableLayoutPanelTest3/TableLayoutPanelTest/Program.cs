﻿using System;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;

namespace ComboBoxTest
{
	internal sealed class Assert
	{
		public static void AreEqual<T> (T a_correct, T a_found,
			string a_strMessage)
		{
			if (!a_correct.Equals (a_found))
				MessageBox.Show (a_strMessage
					+ ": expected " + a_correct.ToString()
					+ ", found " + a_found.ToString());
		}
		public static void AreNotEqual<T> (T a_correct, T a_found,
			string a_strMessage)
		{
			string strCorrect, strFound;
			bool bEquals = false;

			if (a_correct == null)
			{
				strCorrect = "null";
				if (a_found == null)
					bEquals = true;
			}
			else
			{
				strCorrect = a_correct.ToString();
				bEquals = a_correct.Equals (a_found);
			}
			strFound = (a_found == null) ? "null" : a_found.ToString();
			if (bEquals)
				MessageBox.Show (a_strMessage
					+ ": expected not " + strCorrect
					+ ", found " + strFound);
		}
		public static void IsNotNull<T> (T a_found, string a_strMessage)
		{
			AreNotEqual<T> (default (T), a_found, a_strMessage);
		}
		public static void GreaterOrEqual (int a_iArg1, int a_iArg2,
			string a_strMessage)
		{
			if (a_iArg1 < a_iArg2)
				MessageBox.Show (a_strMessage
					+ ": expected " + a_iArg1.ToString()
					+ " >= " + a_iArg2.ToString());
		}
		public static void LessOrEqual (int a_iArg1, int a_iArg2,
			string a_strMessage)
		{
			if (a_iArg1 > a_iArg2)
				MessageBox.Show (a_strMessage
					+ ": expected " + a_iArg1.ToString()
					+ " <= " + a_iArg2.ToString());
		}
	}
    internal sealed class Program
    {
		private class MyForm : Form
		{
			internal MyForm()
			: base()
			{
				this.Closed += new EventHandler (this_Closed);
				this.Load += new EventHandler (this_Load);
			}
			internal void this_Load (object sender, EventArgs e)
			{
				// AutoSize Columns/Rows, and column-spanning controls, but
				// no control starts in column 1.
				// Mono's old behavior was for column 1 to have a zero width.
				TableLayoutPanel p = new TableLayoutPanel ();
				p.Parent = this;
				Control c1 = new Button ();
				Control c2 = new Button ();
				Control c3 = new Button ();

				c1.Size = new Size (150, 25);
				c2.Size = new Size (75, 25);
				c3.Size = new Size (150, 25);

				p.ColumnCount = 4;
				p.RowCount = 3;

				p.RowStyles.Add (new RowStyle (SizeType.AutoSize));
				p.RowStyles.Add (new RowStyle (SizeType.AutoSize));
				p.RowStyles.Add (new RowStyle (SizeType.AutoSize));
				p.ColumnStyles.Add (new ColumnStyle (SizeType.AutoSize));
				p.ColumnStyles.Add (new ColumnStyle (SizeType.AutoSize));
				p.ColumnStyles.Add (new ColumnStyle (SizeType.AutoSize));
				p.ColumnStyles.Add (new ColumnStyle (SizeType.AutoSize));

				p.SetColumnSpan (c1, 2);
				p.SetColumnSpan (c3, 2);

				p.Controls.Add (c1, 0, 0);
				p.Controls.Add (c2, 0, 1);
				p.Controls.Add (c3, 1, 1);

				// The bug fix gets Mono to behave very closely to .NET,
				// but not exactly...3 pixels off somewhere...
				Assert.AreEqual (31, p.GetRowHeights ()[0], "D1");
				Assert.AreEqual (31, p.GetRowHeights ()[1], "D2");
				Assert.AreEqual (81, p.GetColumnWidths ()[0], "D3");
				Assert.LessOrEqual (75, p.GetColumnWidths ()[1], "D4");
				Assert.GreaterOrEqual (78, p.GetColumnWidths ()[1], "D5");
				Assert.LessOrEqual (78, p.GetColumnWidths ()[2], "D6");
				Assert.GreaterOrEqual (81, p.GetColumnWidths ()[2], "D7");
			}
			internal void this_Closed (object sender, EventArgs e)
			{
				Application.Exit();
			}
		}

        [STAThread]
        private static void Main(string[] args)
        {
			// Create a form with a combo box.
			MyForm form = new MyForm ();
			form.ShowInTaskbar = false;
			form.Show ();

			// Display the results.
			Application.Run();
        }
    }
}
