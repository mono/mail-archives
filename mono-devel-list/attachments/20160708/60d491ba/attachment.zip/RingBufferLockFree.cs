﻿#define VOLATILE_FIELD
//#define VOLATILE_CLASS
//#define FULL_BARRIER

using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Threading;


namespace RingBufferLockFreeSpace
{
    /// <summary>
    /// Implementation of a lock free ring buffer
    /// </summary>
    /// <typeparam name="T">the type of item to be stored</typeparam>
    public class RingBufferLockFree<T>
    {
        private readonly T[] _entries;
        // Data is added at _producerCursor and removed from _consumerCursor.  _producerCursor points to an empty node where it will store data. If
        // _producerCursor==_consumerCursor the list is empty. We lose one slot with this convention because if we wrap around
        // we'll still need to keep one free slot for _consumerCursor.
        private VolatileWrapper _consumerCursor = new VolatileWrapper(0);
        private VolatileWrapper _producerCursor = new VolatileWrapper(0);

        /// <summary>
        /// Creates a new RingBuffer with the given capacity
        /// </summary>
        /// <param name="capacity">The capacity of the buffer</param>
        /// <remarks>Only a single thread may attempt to consume at any one time</remarks>
        public RingBufferLockFree(int capacity)
        {
            _entries = new T[capacity];
        }

        public T this[long index]
        {
            get { unchecked { return _entries[index]; } }
            set { unchecked { _entries[index] = value; } }
        }

        /// <summary>
        /// The maximum number of items that can be stored
        /// </summary>
        public int Capacity
        {
            get { return _entries.Length; }
        }

        /// <summary>
        /// Removes an item from the buffer.
        /// </summary>
        /// <returns>The next available item</returns>
        public T Dequeue()
        {
            var consumer = _consumerCursor.ReadAcquireFence();
            var consumerNext = (consumer == _entries.Length - 1) ? 0 : (consumer + 1);

            while (consumer == _producerCursor.ReadAcquireFence())
            {
                Thread.SpinWait(0);
            }

            var item = this[consumer];
            _consumerCursor.WriteReleaseFence(consumerNext);
            return item;
        }


        /// <summary>
        /// Add an item to the buffer
        /// </summary>
        /// <param name="item"></param>
        public bool Enqueue(T item)
        {
            var producer = _producerCursor.ReadAcquireFence();
            var producerNext = (producer == _entries.Length - 1) ? 0 : (producer + 1);

            while (producerNext == _consumerCursor.ReadAcquireFence())
            {
                Thread.SpinWait(0);
            }

            this[producer] = item;
            _producerCursor.WriteReleaseFence(producerNext);

            return true;
        }

    }

    // http://preshing.com/20120913/acquire-and-release-semantics/
    public class VolatileWrapper
    {
        /*
         * The write and read methods use release and acquire semantics. There are 3 implementations.
         * One uses full-barrier which is more expensive and more than we need. The other 2,
         * the Volatile class or Volatile fiels, use half fences, which is exactely what we need and is cheeper.
         */

#if VOLATILE_FIELD
        private volatile int _value; // read and writes to ints are atomic
#else
        private int _value;
#endif

        /// <summary>
        /// Create a new <see cref="VolatileWrapper"/> with the given initial value.
        /// </summary>
        /// <param name="value">Initial value</param>
        public VolatileWrapper(int value)
        {
            _value = value;
        }

        /// <summary>
        /// Read the value without applying any fence
        /// </summary>
        /// <returns>The current value</returns>
        public int ReadUnfenced()
        {
            return _value;
        }

        /// <summary>
        /// Write the value applying release fence semantic
        /// </summary>
        /// <param name="newValue">The new value</param>
        public void WriteReleaseFence(int newValue)
        {
#if VOLATILE_FIELD
                _value = newValue;
#elif VOLATILE_CLASS
            System.Threading.Volatile.Write(ref _value, newValue);
#elif FULL_BARRIER
                Thread.MemoryBarrier();
                _value = newValue;
#endif
        }

        /// <summary>
        /// Read the value applying acquire fence semantic
        /// </summary>
        /// <returns>The current value</returns>
        public int ReadAcquireFence()
        {
#if VOLATILE_FIELD
                return _value;
#elif VOLATILE_CLASS
            return System.Threading.Volatile.Read(ref _value);
#elif FULL_BARRIER
                var value = _value;
                Thread.MemoryBarrier();
                return value;
#endif

        }

    }


}

