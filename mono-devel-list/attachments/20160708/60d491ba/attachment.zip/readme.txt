2 test scripts are included:

1)Program.cs
2)VolatileTest.cs that uses RingBufferLockFree.cs

Both tests rely on the correct implementation of read-acquire and write-release semantics.

The first test reproduces the Volatile field bug in Android.

The second test reprocesses the Volatile field bug in both Android and iOS due to the fact that it has much more repetitions. The test is a bit more complex due to the fact that a circular buffer is used in order to warp around when enqueueing and dequeuing items. THis way we can have more repetitions without allocating a huge array. The test also measures how much time was needed to complete the process, which can be used for benchmarking.

The RingBufferLockFree has a macro that can switch between the following modes:
1) Volatile field
2) Volatile class
3) Full memory barrier

All of them should work correctly. The last one makes more guarantees that we actually need.