﻿using RingBufferLockFreeSpace;
using System;
using System.Diagnostics;
using System.Threading;

namespace ConsoleApplication2
{

    /*
     * In this test, data (of increasing numbers) are enqueued in the RingBufferLockFree queue from the producer thread. The
     * consumer, reads the data from its thread when they become available and validates them.
     *
     * The RingBufferLockFree is lock free ring buffer  and takes advantage of the write-release and read-acuire semantics to guarante that
     * the data are correct. Inside the class there is a macro that controls what synchronization method is used:
     * 1) Volatile field
     * 2) Volatile class
     * 3) Full memory barrier
     *
     * The test fails in Mono in Android and iOS when Volatile fields are used.
     */
    class VolatileTest
    {
        private const long Count = 50000000;
        private const long BatchSize = 20000;

        private Thread _consumerThread;
        private Thread _producerThread;

        // Intead of adding ints to the ringbuffer, we add boxed ints. 
        // This makes the volatile bug more easily reproducible in iOS.
        class Box
        {
            public int number;
            public Box(int value)
            {
                number = value;
            }
        }

        readonly RingBufferLockFree<Box> queue = new RingBufferLockFree<Box>(4000);


        public void StartTest()
        {
            StartConsumerThread();
            StartProducerThread();
        }

        static void Main(string[] args)
        {
            VolatileTest program = new VolatileTest();
            program.StartTest();

            Console.WriteLine("Press any key to exit.");
            Console.ReadKey();
        }

        private void StartConsumerThread()
        {
            _consumerThread = new Thread(() =>
            {
                Thread.Sleep(100);
                Stopwatch sw = new Stopwatch();
                Console.WriteLine("Started consumer");
                sw.Start();
                long counter = 0;
                int previous = 0;
                for (long i = 0; i < Count;)
                {
                    Box box = queue.Dequeue();
                    int value = (box == null) ? -1 : box.number;
                    // Validate
                    if (value != i)
                    {
                        Console.WriteLine("wrong value " + value + " correct: " + i + " previous: " + previous);
                    }
                    ++i;

                    previous = value;
                    counter = i;
                }
                sw.Stop();
                Console.WriteLine(string.Format("Consumer done {0} {1}", sw.Elapsed, counter));
            });
            _consumerThread.Start();
        }


        private void StartProducerThread()
        {
            _producerThread = new Thread(() =>
            {
                Thread.Sleep(100);
                Stopwatch sw = new Stopwatch();
                Console.WriteLine("Started producer");
                sw.Start();
                int queued = 0;
                int valueToEnqueue = 0;
                while (true)
                {
                    for (long i = 0; i < BatchSize && queued < Count; ++i)
                    {
                        Box box = new Box(valueToEnqueue);
                        queue.Enqueue(box);
                        valueToEnqueue++;

                        ++queued;
                    }
                    if (queued >= Count)
                    {
                        sw.Stop();
                        Console.WriteLine(string.Format("Producer done {0} {1}", sw.Elapsed, queued));
                        break;
                    }
                    //Thread.Sleep(5);

                }
            });
            _producerThread.Start();
        }

    }
}
