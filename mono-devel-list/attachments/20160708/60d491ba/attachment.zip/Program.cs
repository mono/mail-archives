﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ConsoleApplication2
{
    /*
     * In this test, data (of increasing numbers) are stored in _entries array from the producer thread. The
     * consumer, reads the data from its thread when they become available and validates them. No locks are used.
     * The data are guaranteed to be correct because of the release-acquire semantics used in _producerCursor.
     *
     * The test fails in Mono in Android and iOS. Actually in iOS it requires more iterations and a slightly more complex test to
     * reproduce the issue 100% but it's there.
     *
     * Replacing the access to the volatile field with Volatile.Read()/Write() works correctly.
     */

    class Program
    {
        static void Main(string[] args)
        {
            Program program = new Program();
            program.StartTest();

            Console.WriteLine("Press any key to exit.");
            //Console.ReadKey();
        }

        public void StartTest()
        {
            StartConsumerThread();
            StartProducerThread();
        }

        private volatile int _producerCursor = 0;

        class Box
        {
            public int number;
        }

        private readonly Box[] _entries = new Box[5000000];
        private readonly int COUNT = 5000000;

        private void StartConsumerThread()
        {
            Thread consumerThread = new Thread(() =>
            {
                Console.WriteLine("Started consumer");
                int previousValue = -1;
                int counter = 0;
                for (int i = 0; i < COUNT; i++)
                {
                    //while (i >= Volatile.Read(ref _producerCursor))      
                    while (i >= _producerCursor)                    // read-acquire fence ***
                    {
                        Thread.SpinWait(0);
                    }
                    Box box = _entries[i];                          // read from array the published value 

                    // Validate
                    int value = (box == null) ? -1 : box.number; 
                    if (i != value)
                    {
                        Console.WriteLine("wrong value " + value + " correct: " + i + " previous: " + previousValue);
                    }
                    previousValue = value;
                    counter++;
                }
                Console.WriteLine(string.Format("Consumer done {0}", counter));
            });
            consumerThread.Start();
        }

        // *** The write-release fence makes sure that the data are written on _entries before _producerCursor advances
        // The read-acquire fence makses sure that if can see the new _producerCursor value, we can also see the data on _entries

        private void StartProducerThread()
        {
            Thread producerThread = new Thread(() =>
            {
                Thread.Sleep(2000);
                Console.WriteLine("Started producer");
                int counter = 0;
                for (int i = 0; i < COUNT; i++)
                {
                    int producerCursorNext = _producerCursor + 1;
                    Box box = new Box();
                    box.number = i;
                    _entries[_producerCursor] = box;            // write to array
                    _producerCursor = producerCursorNext;       // write-release fence ***
                    //Volatile.Write(ref _producerCursor, producerCursorNext);
                    counter++;
                }
                Console.WriteLine(string.Format("Producer done {0}", counter));
            });
            producerThread.Start();
        }
    }
}
