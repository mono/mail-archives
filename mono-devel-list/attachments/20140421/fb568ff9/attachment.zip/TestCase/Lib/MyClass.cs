﻿using System;

namespace Lib
{
	public class MyClass
	{
		void ApplyCollision(Action<int, bool> func){
		}

		public MyClass ()
		{
		}
	}
}

