//
// Locale.cs
//
// Author:
//   Miguel de Icaza (miguel@ximian.com)
//   Andreas Nahr (ClassDevelopment@A-SoftTech.com)
//   Peter Bartok (pbartok@novell.com)
//   Korn�l P�l <http://www.kornelpal.hu/>
//
// (C) 2001 - 2003 Ximian, Inc (http://www.ximian.com)
// Copyright (C) 2005 Korn�l P�l
//

//
// Copyright (C) 2004 Novell, Inc (http://www.novell.com)
//
// Permission is hereby granted, free of charge, to any person obtaining
// a copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to
// permit persons to whom the Software is furnished to do so, subject to
// the following conditions:
//
// The above copyright notice and this permission notice shall be
// included in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
// NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
// LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
// OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
// WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
//

using System;
using System.Globalization;
using System.Reflection;
using System.Resources;
using System.Threading;

internal sealed class Locale
{
	// gettext () style resource manager
	private sealed class GetTextResourceManager : ResourceManager
	{
		// gettext () style resource set for neutral culture
		// Only GetString and GetObject methods are implemented
		private sealed class GetTextResourceSet : ResourceSet
		{
			private readonly string baseName;
			private readonly Assembly assembly;
			private ResourceSet baseResourceSet;

			internal GetTextResourceSet (string baseName, Assembly assembly) : base ()
			{
				this.baseName = baseName;
				this.assembly = assembly;
			}

			public override string GetString (string name, bool ignoreCase)
			{
				return name;
			}

			public override string GetString (string name)
			{
				return name;
			}

			public override object GetObject (string name, bool ignoreCase)
			{
				return GetBaseResourceSet ().GetObject (name, ignoreCase);
			}

			public override object GetObject (string name)
			{
				return GetBaseResourceSet ().GetObject (name);
			}

			private ResourceSet GetBaseResourceSet ()
			{
				if (baseResourceSet == null)
					baseResourceSet = new ResourceManager (baseName, assembly).GetResourceSet (CultureInfo.InvariantCulture, true, true);
				return baseResourceSet;
			}
		}

		internal GetTextResourceManager (string baseName, Assembly assembly) : base (baseName, assembly)
		{
			ResourceSets [CultureInfo.InvariantCulture] = new GetTextResourceSet (baseName, assembly);
		}
	}

#if INSIDE_CORLIB
	private static bool getTextLock;
#endif
	private static readonly object resourcesLock = new object ();
	private static ResourceManager resources;

	private Locale ()
	{
	}

	// Required to avoid TypeInitializationException that uses resources
	// itself and may cause the stack tracke not to be written to output on
	// fatal errors because uses inner exceptions.
	private static ResourceManager GetResourceManager ()
	{
		if (resources == null)
			lock (resourcesLock) {
				if (resources == null) {
					ResourceManager newResources = new GetTextResourceManager (typeof (Locale).Assembly.GetName ().Name, typeof (Locale).Assembly);
					Thread.MemoryBarrier();
					resources = newResources;
				}
			}

		return resources;
	}

#if INSIDE_CORLIB
	// Prevents infinite GetText recursion
#endif
	internal static string GetText (string message)
	{
#if INSIDE_CORLIB
		ResourceManager resources = GetResourceManager ();

		lock (resources) {
			if (getTextLock)
				// Do not localize
				return "GetText recursion: " + message;

			getTextLock = true;
			try {
				return resources.GetString (message, null);
			}
			finally {
				getTextLock = false;
			}
		}
#else
		return GetResourceManager ().GetString (message, null);
#endif
	}

	internal static string GetText (string format, params object [] args)
	{
		return string.Format (GetText (format), args);
	}

#if INSIDE_CORLIB
	// Intended to be used in error reporting
	// The runtime uses Exception.StackTrace to show stack trace for unhandled
	// exceptions thus it must succeed even when exception ocurred in GetText.
	internal static string SafeGetText (string message)
	{
		try {
			return GetText (message);
		}
		catch {
			return message;
		}
	}

	internal static string SafeGetText (string format, params object [] args)
	{
		return string.Format (SafeGetText (format), args);
	}
#endif

	internal static object GetResource (string name)
	{
		return GetResourceManager ().GetObject (name);
	}
}