using System;
using Gtk;
using Gdk;
using System.Reflection;
using System.Collections.Generic;

//// TODO: You are showing twice methods when
//// displaying inherited ones

namespace Alve
{
    public class AssemblyView:
	ScrolledWindow
	{
	    public AssemblyView()
	    {
		initialize();
	    }

	    public AssemblyView(System.IntPtr handle):
		base(handle)
		{
		    initialize();
		}

	    public bool showInherited {
		get {
		    return show_inherited;
		}
		set {
		    show_inherited = value;
		    synchronizeModel();
		}
	    }

	    public bool showNonPublic {
		get {
		    return show_nonpublic;
		}
		set {
		    show_nonpublic = value;
		    synchronizeModel();
		}
	    }

	    public void initialize()
	    {
		my_tree_view = new TreeView();
		model = new TreeStore(typeof(Pixbuf) ,typeof(string));
		assembly_list = new List<Assembly>();
		my_tree_view.Model = model;
		my_tree_view.AppendColumn("what", new CellRendererPixbuf(), "pixbuf",0);
		my_tree_view.AppendColumn("name", new CellRendererText(), "text",1);
		my_tree_view.HeadersVisible = true;
		Add(my_tree_view);

		loadImages();

		Show();
	    }


	    protected void loadImages()
	    {
		p_array = Pixbuf.LoadFromResource("array.png");
		p_class = Pixbuf.LoadFromResource("class.png");
		p_field = Pixbuf.LoadFromResource("field.png");
		p_method = Pixbuf.LoadFromResource("method.png");
		p_assembly = Pixbuf.LoadFromResource("assembly.png");
		p_inherited_method = Pixbuf.LoadFromResource("inherited_method.png");
		p_parameter = Pixbuf.LoadFromResource("parameter.png");
		p_protected_inherited_method = Pixbuf.LoadFromResource("protected_inherited_method.png");
		p_protected_method = Pixbuf.LoadFromResource("protected_method.png");
		p_static_method = Pixbuf.LoadFromResource("static_method.png");
		p_nonpublic_static_method = Pixbuf.LoadFromResource("nonpublic_static_method.png");
		p_constructor = Pixbuf.LoadFromResource("constructor.png");
		p_nonpublic_constructor = Pixbuf.LoadFromResource("nonpublic_constructor.png");
		p_property = Pixbuf.LoadFromResource("property.png");
		p_nonpublic_property = Pixbuf.LoadFromResource("nonpublic_property.png");
		p_inherited_property = Pixbuf.LoadFromResource("inherited_property.png");
		p_inherited_nonpublic_property = Pixbuf.LoadFromResource("inherited_nonpublic_property.png");


	    }

	    public void addAssembly(System.Reflection.Assembly assembly)
	    {
		assembly_list.Add(assembly);
		synchronizeModel();
	    }

	    public void synchronizeModel()
	    {/*{{{*/
		model.Clear();
		foreach  (Assembly assembly in assembly_list)
		{
		    System.Type[] exported_types = assembly.GetExportedTypes();
		    // Clear the model
		    // The root path
		    TreeIter root_iter;
		    object[] pair=new object[2];
		    pair[0] = p_assembly;
		    pair[1] = assembly.FullName;
		    root_iter = model.AppendValues(pair);
		    foreach (Type t in exported_types)
		    {
			detailType(root_iter, t);
		    }
		}
	    }/*}}}*/

	    protected void detailType(TreeIter model_parent, Type t)
	    {/*{{{*/
		object[] pair = new object[2];
		if (t.IsArray)
		{
		    pair[0] = p_array;
		    pair[1] = t.FullName;
		    TreeIter iter = model.AppendValues(model_parent, pair);
		}else if(t.IsClass)
		{
		    pair[0] = p_class;
		    pair[1] = String.Format(
			    "class {0}: {1}",
			    t.FullName, t.BaseType.FullName);
		    TreeIter iter = model.AppendValues(model_parent, pair);
		    detailTypeMembers(iter, t);
		}
	    }/*}}}*/

	    protected void detailTypeMethods(TreeIter model_parent, Type t)
	    {/*{{{*/
		// Getting public instance methods defined in this class
		BindingFlags bf = BindingFlags.Instance | BindingFlags.Public | BindingFlags.DeclaredOnly;
		MethodInfo[] public_methods = t.GetMethods(bf);
		foreach(MethodInfo mi in public_methods)
		{
		    object[] pair = new object[2]; 
		    pair[0]=p_method;
		    MethodInfo method_info = (MethodInfo)mi;
		    pair[1]=
			createMethodDecl(method_info);
		    TreeIter iter = model.AppendValues(model_parent,pair);
		    detailMethod(iter, method_info);
		}

		if (show_inherited)
		{
		    BindingFlags i_bf = BindingFlags.Instance | BindingFlags.Public ;
		    MethodInfo[] public_inherited_methods = t.GetMethods(i_bf);
		    foreach(MethodInfo mi in public_inherited_methods)
		    {
			if (mi.DeclaringType!=t)
			{
			    object[] pair = new object[2]; 
			    pair[0]=p_inherited_method;
			    MethodInfo method_info = (MethodInfo)mi;
			    pair[1] =
				createMethodDecl(method_info);
			    TreeIter iter = model.AppendValues(model_parent,pair);
			    detailMethod(iter, method_info);
			}
		    }
		}

		// Showing static members
		BindingFlags public_static_bf = BindingFlags.Static | BindingFlags.Public;
		MethodInfo[] public_static_methods = t.GetMethods(public_static_bf);
		foreach (MethodInfo mi in public_static_methods)
		{
		    object[] pair = new object[2];
		    pair[0] = p_static_method;
		    pair[1] =
			createMethodDecl(mi);
		    TreeIter iter = model.AppendValues(model_parent,pair);
		    detailMethod(iter, mi);
		}


		if (show_nonpublic)
		{
		    // Display non-public methods
		    // Getting non-public instance methods defined in this class
		    BindingFlags np_bf = BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.DeclaredOnly;
		    MethodInfo[] non_public_methods = t.GetMethods(np_bf);
		    foreach(MethodInfo mi in non_public_methods)
		    {
			object[] pair = new object[2]; 
			pair[0]=p_protected_method;
			MethodInfo method_info = (MethodInfo)mi;
			pair[1] = 
			    createMethodDecl(method_info);
			TreeIter iter = model.AppendValues(model_parent,pair);
			detailMethod(iter, method_info);
		    }

		    if (show_inherited)
		    {
			BindingFlags i_bf = BindingFlags.Instance | BindingFlags.NonPublic ;
			MethodInfo[] nonpublic_inherited_methods = t.GetMethods(i_bf);
			foreach(MethodInfo mi in nonpublic_inherited_methods)
			{
			    if (mi.DeclaringType!=t)
			    {
				object[] pair = new object[2]; 
				pair[0]=p_protected_inherited_method;
				MethodInfo method_info = (MethodInfo)mi;
				pair[1]=
				    createMethodDecl(method_info);
				TreeIter iter = model.AppendValues(model_parent,pair);
				detailMethod(iter, method_info);
			    }
			}
		    }
		    // Showing static members
		    BindingFlags nonpublic_static_bf = BindingFlags.Static | BindingFlags.NonPublic;
		    MethodInfo[] nonpublic_static_methods = t.GetMethods(nonpublic_static_bf);
		    foreach (MethodInfo mi in nonpublic_static_methods)
		    {
			object[] pair = new object[2];
			pair[0] = p_nonpublic_static_method;
			pair[1] =
			    createMethodDecl(mi);
			TreeIter iter = model.AppendValues(model_parent,pair);
			detailMethod(iter, mi);
		    }

		}
	    }/*}}}*/

	    protected void detailTypeConstructors(TreeIter model_parent, Type t)
	    {/*{{{*/
		// First, public constructors
		BindingFlags publics_bf = BindingFlags.Public | BindingFlags.Instance;
		ConstructorInfo[] constructors = t.GetConstructors(publics_bf);	
		foreach (ConstructorInfo ci in constructors)
		{
		    // The string to put here
		    object[] pair= new object[2];
		    pair[0]=p_constructor;
		    pair[1]=createConstructorDecl(ci) ;
		    TreeIter iter = model.AppendValues(model_parent, pair);
		    detailMethod(iter, ci);
		}
		// Then, nonpublic constructors if user 
		// requests them
		if (show_nonpublic)
		{
		    BindingFlags nonpublics_bf = BindingFlags.NonPublic | BindingFlags.Instance;
		    ConstructorInfo[] nonpublics_constructors = t.GetConstructors(nonpublics_bf);	
		    foreach (ConstructorInfo ci in nonpublics_constructors)
		    {
			// The string to put here
			object[] pair= new object[2];
			pair[0]=p_nonpublic_constructor;
			pair[1]=createConstructorDecl(ci) ;
			TreeIter iter = model.AppendValues(model_parent, pair);
			detailMethod(iter, ci);
		    }
		}
	    }/*}}}*/

	    protected void detailTypeMembers(TreeIter model_parent, Type t)
	    {/*{{{*/
		detailTypeConstructors(model_parent, t);
		detailTypeMethods(model_parent, t);
		detailTypeProperties(model_parent, t);
	    }/*}}}*/

	    protected void detailTypeProperties(TreeIter model_parent, Type t)
	    {
		// Getting public properties
		BindingFlags public_bf = BindingFlags.Public | BindingFlags.Instance | BindingFlags.DeclaredOnly;
		PropertyInfo[] public_properties = t.GetProperties(public_bf);
		foreach (PropertyInfo pi in public_properties)
		{
		    object[] pair = new object[2];
		    pair[0] = p_property;
		    pair[1] = 
			String.Format(
				"{0} : {1}",
				pi.Name,
				pi.PropertyType.FullName
				);
		    model.AppendValues(model_parent ,pair);
		}
		// Getting nonpublic properties
		if (show_nonpublic)
		{
		    BindingFlags nonpublic_bf = BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.DeclaredOnly;
		    PropertyInfo[] nonpublic_properties = t.GetProperties(nonpublic_bf);
		    foreach (PropertyInfo pi in nonpublic_properties)
		    {
			object[] pair = new object[2];
			pair[0] = p_nonpublic_property;
			pair[1] = 
			    String.Format(
				    "{0} : {1}",
				    pi.Name,
				    pi.PropertyType.FullName
				    );
			model.AppendValues(model_parent ,pair);
		    }
		}
		if (show_inherited)
		{
		    // Getting public inherited properties
		    BindingFlags ipublic_bf = BindingFlags.Public | BindingFlags.Instance ;
		    PropertyInfo[] ipublic_properties = t.GetProperties(ipublic_bf);
		    foreach (PropertyInfo pi in ipublic_properties)
		    {
			if (pi.DeclaringType != t)
			{
			    object[] pair = new object[2];
			    pair[0] = p_inherited_property;
			    pair[1] = 
				String.Format(
					"{0} : {1}",
					pi.Name,
					pi.PropertyType.FullName
					);
			    model.AppendValues(model_parent ,pair);
			}
		    }
		    // Getting nonpublic properties
		    if (show_nonpublic)
		    {
			BindingFlags inonpublic_bf = BindingFlags.NonPublic | BindingFlags.Instance ;
			PropertyInfo[] inonpublic_properties = t.GetProperties(inonpublic_bf);
			foreach (PropertyInfo pi in inonpublic_properties)
			{
			    if (pi.DeclaringType != t)
			    {
				object[] pair = new object[2];
				pair[0] = p_inherited_nonpublic_property;
				pair[1] = 
				    String.Format(
					    "{0} : {1}",
					    pi.Name,
					    pi.PropertyType.FullName
					    );
				model.AppendValues(model_parent ,pair);
			    }
			}
		    }
		}
	    }

	    protected void detailMethod(TreeIter model_parent, MethodBase mi)
	    {/*{{{*/
		ParameterInfo[] parameters = mi.GetParameters();
		foreach (ParameterInfo pi  in parameters)
		{
		    object[] pair = new object[2];
		    pair[0] = p_parameter;
		    pair[1]=String.Format(
			    "{0}:{1}",
			    pi.Name,
			    pi.ParameterType.FullName
			    );
		    model.AppendValues(model_parent, pair);
		}
	    }/*}}}*/

	    protected string createMethodDecl(MethodInfo mi)
	    {/*{{{*/
		string rt_name = mi.ReturnType.FullName;
		ParameterInfo[] parameters = mi.GetParameters();
		System.Text.StringBuilder sb=new System.Text.StringBuilder(rt_name);
		sb.Append(" ");
		sb.Append(mi.Name);
		sb.Append("( ");

		bool entered_loop = false;
		foreach (ParameterInfo pi in parameters)
		{
		    entered_loop = true;
		    sb.Append(pi.ParameterType.FullName);
		    sb.Append(" ");
		    sb.Append(pi.Name);
		    sb.Append(", ");
		}
		if (entered_loop)
		    sb.Remove(sb.Length-2,2);
		sb.Append(")");
		return sb.ToString();
	    }/*}}}*/

	    protected string createConstructorDecl(ConstructorInfo ci)
	    {/*{{{*/
		ParameterInfo[] parameters = ci.GetParameters();
		System.Text.StringBuilder sb=new System.Text.StringBuilder(".ctor");
		sb.Append(" ");
		sb.Append("( ");

		bool entered_loop = false;
		foreach (ParameterInfo pi in parameters)
		{
		    entered_loop = true;
		    sb.Append(pi.ParameterType.FullName);
		    sb.Append(" ");
		    sb.Append(pi.Name);
		    sb.Append(", ");
		}
		if (entered_loop)
		    sb.Remove(sb.Length-2,2);
		sb.Append(")");
		return sb.ToString();
	    }/*}}}*/

	    //System.Reflection.Assembly assembly;
	    List<Assembly> assembly_list;

	    TreeView my_tree_view;
	    TreeStore model;

	    Pixbuf p_array;
	    Pixbuf p_class;
	    Pixbuf p_assembly;
	    Pixbuf p_field;
	    Pixbuf p_method;
	    Pixbuf p_inherited_method;
	    Pixbuf p_parameter;
	    Pixbuf p_protected_method;
	    Pixbuf p_protected_inherited_method;
	    Pixbuf p_static_method;
	    Pixbuf p_nonpublic_static_method;
	    Pixbuf p_constructor;
	    Pixbuf p_nonpublic_constructor;
	    Pixbuf p_property;
	    Pixbuf p_nonpublic_property;
	    Pixbuf p_inherited_property;
	    Pixbuf p_inherited_nonpublic_property;


	    bool show_inherited;
	    bool show_nonpublic;

	}

}
