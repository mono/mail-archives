using Gtk;
using System.Collections.Generic;
using System;
using System.Reflection;

namespace Alve
{
    public class AView {

	public static void Main (string [] args)
	{              
	    AView app = new AView(args);
	}

	public AView(string[] args)
	{
	    Application.Init ();
	    glade = new Glade.XML("interface.glade","main_window",null);
	    Window win = (Window)glade.GetWidget("main_window");
	    win.DeleteEvent += new DeleteEventHandler (delete_cb);
	    ScrolledWindow s_window = (ScrolledWindow)glade.GetWidget("scrolledwindow");
	    if (s_window==null)
	    {
		Console.WriteLine("!!");
	    }else
	    {
		Console.WriteLine("--");
	    }

	    assembly_view = new AssemblyView (s_window.Handle);

	    foreach (string assembly_name in args)
	    {
		//Check file exists
		if (System.IO.File.Exists(assembly_name))
		{
		    try{
			Assembly assembly = Assembly.LoadFrom(assembly_name); 
			assembly_view.addAssembly(assembly);
		    }catch (Exception e)
		    {
			Console.WriteLine(
			    String.Format("Assembly could not be loaded: {0}", assembly_name)
			    );
			Console.WriteLine(
			    String.Format("Exception message was: {0}", e.Message)
			    );
		    }
		}else
		{
		    Console.WriteLine(
			String.Format("Your file doesn't seem to exist: {0}", assembly_name)
			);
		}
	    }
	    if (args.Length > 0)
	    {
	        win.ShowAll ();
	        glade.Autoconnect(this);
		Application.Run ();
	    }
	    else{
		Console.WriteLine("No assemblies in command line!");
		Application.Quit();
	    }
	}


	private void delete_cb (System.Object o, DeleteEventArgs args)
	{
	    Application.Quit ();
	    args.RetVal = true;
	}
	
	void on_showInheritedToggletoolbutton_toggled(object o, EventArgs args)
	{
	    assembly_view.showInherited = ! assembly_view.showInherited;
	}

	void on_showNonPublicToggletoolbutton_toggled(object o, EventArgs args)
	{
	    assembly_view.showNonPublic = ! assembly_view.showNonPublic;
	    Console.WriteLine("--");
	}
	
	Glade.XML glade;
	AssemblyView assembly_view;
    }

}



