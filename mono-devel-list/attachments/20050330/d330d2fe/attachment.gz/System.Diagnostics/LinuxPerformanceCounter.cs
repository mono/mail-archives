using System ;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Diagnostics;
using System.IO ;

	internal class LinuxPerformanceCounter : IPerformanceCounter 
	{
		private string categoryName;
		private string counterName;
		private string instanceName;
		private string machineName;
		private long rawValue ;
		private bool readOnly;
		
		
		public LinuxPerformanceCounter()
		{
			categoryName = counterName = instanceName = "";
			machineName = ".";
			
		}
		
		public LinuxPerformanceCounter (string categoryName,
			string counterName,
			string instanceName,
			bool readOnly)
		{
			CategoryName = categoryName;
			CounterName = counterName;

			if (categoryName == "" || counterName == "")
				throw new InvalidOperationException ();

			InstanceName = instanceName;
			this.instanceName = instanceName;
			this.machineName = ".";
			this.readOnly = readOnly;
		}	
			
			public  float NextValue () 
			{
				float flt = float.Parse("0") ;
				if(this.CategoryName.Equals("Memory"))
				{
					flt = float.Parse(GetMemoryCounter(this.CounterName).ToString()) ;
				}
				return flt ;
			}
			public void BeginInit ()
			{
				NextValue() ;
			}
			public string CategoryName {
				get {return categoryName;}
				set {
					if (value == null)
						throw new ArgumentNullException ("categoryName");
					categoryName = value;
				}
			}
			
			public string CounterName 
			{
				get {return counterName;}
				set {
					if (value == null)
						throw new ArgumentNullException ("counterName");
					counterName = value;
				}
			}
			
			public string InstanceName 
			{
				get {return instanceName;}
				set {instanceName = value;}
			}
		    
		    public string MachineName {
				get {return machineName;}
				set {machineName = value;}
			}
			public long RawValue {
			get {return rawValue;}
			set {
					rawValue = value ;
			}
			}
				/*
			private float GetPhysicalDiskCounter(string counterName)
			{
		
	<InstanceName>0 C:</InstanceName>
    <PerformanceCounter>Current Disk Queue Length</PerformanceCounter>
    <InstanceName>0 C:</InstanceName>
    <PerformanceCounter>% Disk Time</PerformanceCounter>
    <InstanceName>0 C:</InstanceName>
    <PerformanceCounter>Avg. Disk Queue Length</PerformanceCounter>
    <InstanceName>0 C:</InstanceName>
    <PerformanceCounter>% Disk Read Time</PerformanceCounter>
    <InstanceName>0 C:</InstanceName>
    <PerformanceCounter>Avg. Disk Read Queue Length</PerformanceCounter>
    <InstanceName>0 C:</InstanceName>
    <PerformanceCounter>% Disk Write Time</PerformanceCounter>
    <InstanceName>0 C:</InstanceName>
    <PerformanceCounter>Avg. Disk Write Queue Length</PerformanceCounter>
    <InstanceName>0 C:</InstanceName>
    <PerformanceCounter>Avg. Disk sec/Transfer</PerformanceCounter>
    <InstanceName>0 C:</InstanceName>
    <PerformanceCounter>Avg. Disk sec/Read</PerformanceCounter>
    <InstanceName>0 C:</InstanceName>
    <PerformanceCounter>Avg. Disk sec/Write</PerformanceCounter>
    <InstanceName>0 C:</InstanceName>
    <PerformanceCounter>Disk Transfers/sec</PerformanceCounter>
    <InstanceName>0 C:</InstanceName>
    <PerformanceCounter>Disk Reads/sec</PerformanceCounter>
    <InstanceName>0 C:</InstanceName>
    <PerformanceCounter>Disk Writes/sec</PerformanceCounter>
    <InstanceName>0 C:</InstanceName>
    <PerformanceCounter>Disk Bytes/sec</PerformanceCounter>
    <InstanceName>0 C:</InstanceName>
    <PerformanceCounter>Disk Read Bytes/sec</PerformanceCounter>
    <InstanceName>0 C:</InstanceName>
    <PerformanceCounter>Disk Write Bytes/sec</PerformanceCounter>
    <InstanceName>0 C:</InstanceName>
    <PerformanceCounter>Avg. Disk Bytes/Transfer</PerformanceCounter>
    <InstanceName>0 C:</InstanceName>
    <PerformanceCounter>Avg. Disk Bytes/Read</PerformanceCounter>
    <InstanceName>0 C:</InstanceName>
    <PerformanceCounter>Avg. Disk Bytes/Write</PerformanceCounter>
    <InstanceName>0 C:</InstanceName>
    <PerformanceCounter>% Idle Time</PerformanceCounter>
    <InstanceName>0 C:</InstanceName>
    <PerformanceCounter>Split IO/Sec</PerformanceCounter>
    
   <!-- Going to do these first --> 
    <InstanceName>_Total</InstanceName>
    <PerformanceCounter>Current Disk Queue Length</PerformanceCounter>
    <InstanceName>_Total</InstanceName>
    <PerformanceCounter>% Disk Time</PerformanceCounter>
    <InstanceName>_Total</InstanceName>
    <PerformanceCounter>Avg. Disk Queue Length</PerformanceCounter>
    <InstanceName>_Total</InstanceName>
    <PerformanceCounter>% Disk Read Time</PerformanceCounter>
    <InstanceName>_Total</InstanceName>
    <PerformanceCounter>Avg. Disk Read Queue Length</PerformanceCounter>
    <InstanceName>_Total</InstanceName>
    <PerformanceCounter>% Disk Write Time</PerformanceCounter>
    <PerformanceCounter>Avg. Disk Write Queue Length</PerformanceCounter>
    <InstanceName>_Total</InstanceName>
    <PerformanceCounter>Avg. Disk sec/Transfer</PerformanceCounter>
    <InstanceName>_Total</InstanceName>
    <PerformanceCounter>Avg. Disk sec/Read</PerformanceCounter>
    <InstanceName>_Total</InstanceName>
    <PerformanceCounter>Avg. Disk sec/Write</PerformanceCounter>
    <InstanceName>_Total</InstanceName>
    <PerformanceCounter>Disk Transfers/sec</PerformanceCounter>
    <InstanceName>_Total</InstanceName>
    <PerformanceCounter>Disk Reads/sec</PerformanceCounter>
    <InstanceName>_Total</InstanceName>
    <PerformanceCounter>Disk Writes/sec</PerformanceCounter>
    <InstanceName>_Total</InstanceName>
    <PerformanceCounter>Disk Bytes/sec</PerformanceCounter>
    <InstanceName>_Total</InstanceName>
    <PerformanceCounter>Disk Read Bytes/sec</PerformanceCounter>
    <InstanceName>_Total</InstanceName>
    <PerformanceCounter>Disk Write Bytes/sec</PerformanceCounter>
    <InstanceName>_Total</InstanceName>
    <PerformanceCounter>Avg. Disk Bytes/Transfer</PerformanceCounter>
    <InstanceName>_Total</InstanceName>
    <PerformanceCounter>Avg. Disk Bytes/Read</PerformanceCounter>
    <InstanceName>_Total</InstanceName>
    <PerformanceCounter>Avg. Disk Bytes/Write</PerformanceCounter>
    <InstanceName>_Total</InstanceName>
    <PerformanceCounter>% Idle Time</PerformanceCounter>
    <InstanceName>_Total</InstanceName>
    <PerformanceCounter>Split IO/Sec</PerformanceCounter>
   
   
			}
			private float GetSystemCounter(string systemName)
			{
				float mem = float.Parse("0") ;
						string line ;
						
						using (StreamReader sr = new StreamReader("/proc/stat"))
						{
							try
							{	
								while ((line = sr.ReadLine()) != null) 
               					{
                    				Console.WriteLine(line);
                				}
											
							}catch (FileNotFoundException fnfe){
								throw ;
							}catch (IOException ioe){
								throw ;
							}
						}
						return mem ;
			}*/
			private float GetMemoryCounter(string counterName)
			{
						float mem = float.Parse("0") ;
						string line ;
						string memInfoName = "" ; 
						if(counterName.Equals("Committed Bytes"))
						{
							memInfoName = "Committed_AS" ;
						}
						else if(counterName.Equals("Available KBytes"))
						{
							memInfoName = "MemFree" ;
						}
						
						using (StreamReader sr = new StreamReader("/proc/meminfo"))
						{
							try
							{	
								while ((line = sr.ReadLine()) != null) 
               					{
               						
               						//We have found the data!
               						if(line.IndexOf(memInfoName) > -1)
               						{
								Console.WriteLine("Getting " + memInfoName + " from " + "\"" + line + "\"") ;
               							string[] arr = line.Split(' ') ;
								mem = long.Parse(arr[arr.Length - 2]) ;
								break ;

               						}
               					}

/*
 	//System Cache Resident Bytes
    //Committed_AS
    <PerformanceCounter>Page Faults/sec</PerformanceCounter>
    <PerformanceCounter>Available Bytes</PerformanceCounter>
    <PerformanceCounter>Committed Bytes</PerformanceCounter>
    <PerformanceCounter>Commit Limit</PerformanceCounter>
    <PerformanceCounter>Write Copies/sec</PerformanceCounter>
    <PerformanceCounter>Transition Faults/sec</PerformanceCounter>
    <PerformanceCounter>Cache Faults/sec</PerformanceCounter>
    <PerformanceCounter>Demand Zero Faults/sec</PerformanceCounter>
    <PerformanceCounter>Pages/sec</PerformanceCounter>
    <PerformanceCounter>Pages Input/sec</PerformanceCounter>
    <PerformanceCounter>Page Reads/sec</PerformanceCounter>
    <PerformanceCounter>Pages Output/sec</PerformanceCounter>
    <PerformanceCounter>Pool Paged Bytes</PerformanceCounter>
    <PerformanceCounter>Pool Nonpaged Bytes</PerformanceCounter>
    <PerformanceCounter>Page Writes/sec</PerformanceCounter>
    <PerformanceCounter>Pool Paged Allocs</PerformanceCounter>
    <PerformanceCounter>Pool Nonpaged Allocs</PerformanceCounter>
    <PerformanceCounter>Free System Page Table Entries</PerformanceCounter>
    <PerformanceCounter>Cache Bytes</PerformanceCounter>
    <PerformanceCounter>Cache Bytes Peak</PerformanceCounter>
    <PerformanceCounter>Pool Paged Resident Bytes</PerformanceCounter>
    <PerformanceCounter>System Code Total Bytes</PerformanceCounter>
	<PerformanceCounter>System Code Resident Bytes</PerformanceCounter>
    <PerformanceCounter>System Driver Total Bytes</PerformanceCounter>
    <PerformanceCounter>System Driver Resident Bytes</PerformanceCounter>
    <PerformanceCounter>System Cache Resident Bytes</PerformanceCounter>
    <PerformanceCounter>% Committed Bytes In Use</PerformanceCounter>
    <PerformanceCounter>Available KBytes</PerformanceCounter>
    <PerformanceCounter>Available MBytes</PerformanceCounter>

//Output from /proc/meminfo 
MemTotal:       768080 kB
MemFree:          4624 kB
Buffers:        162676 kB
Cached:         117072 kB
SwapCached:          0 kB
Active:         323996 kB
Inactive:       120916 kB
HighTotal:           0 kB
HighFree:            0 kB
LowTotal:       768080 kB
LowFree:          4624 kB
SwapTotal:     1975952 kB
SwapFree:      1975936 kB
Dirty:              76 kB
Writeback:           0 kB
Mapped:         221032 kB
Slab:           281052 kB
Committed_AS:   275528 kB
PageTables:       1700 kB
VmallocTotal:   253944 kB
VmallocUsed:     21652 kB
VmallocChunk:   232196 kB
HugePages_Total:     0
HugePages_Free:      0
Hugepagesize:     4096 k*/
                    		
											
							}catch (FileNotFoundException fnfe){
								throw ;
							}catch (IOException ioe){
								throw ;
							}
						}
						return mem ; 
			}	
			private float GetCpuPerformance()
	{
		string read = "";
		using (StreamReader sr = new StreamReader("/proc/stat"))
		{
			try
			{
					while(true)
					{
						    
						read = sr.ReadLine() ;
						string[] arr = read.Split(' ') ;
						//It is not an instance
						if(this.instanceName.Equals(""))
						{
							
						}
						if(arr[0].StartsWith("cpu"))
						{
							Console.WriteLine("read " + read) ;
							//UNDONE: Test for Instance
							/*if(arr[0].LastIndexOfAny(_nos) > 0)
							{
								//cpuo._isInstance = true ;
							}
							else
							{
								//cpuo._isInstance = false ;
							}	*/
				
//							cpuo._user = arr[1];
   // 						cpuo._nice = arr[2];
   // 						cpuo._system = arr[3] ;
   // 						cpuo._idle = arr[4];
    						
    					}else{
    						break ;
    					 } 
					}
			}
			catch (FileNotFoundException fnfe){
			throw ;
			}
			catch (IOException ioe){
			throw ;
			}
			
		}
		float flt = float.Parse("0")  ;
		return flt ;
	}
		}//End of Linux performance counter
