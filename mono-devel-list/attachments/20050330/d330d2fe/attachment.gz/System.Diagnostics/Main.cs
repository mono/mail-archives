// project created on 03/22/2005 at 16:54
using System;
using System.Diagnostics ;

class MainClass
{
	public static void Main(string[] args)
	{
		Console.WriteLine("OS			: " + System.Environment.OSVersion);
		Console.WriteLine(".Net Runtime		: " + System.Environment.Version) ;
		PerformanceCounter pcAvailKb = new PerformanceCounter("Memory", "Available KBytes", "", false) ;
		Console.WriteLine("Available KBytes	: " + pcAvailKb.NextValue()) ; 		
		Console.WriteLine("Exiting") ;
	}
}
