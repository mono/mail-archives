using System ;

internal class WindowsPerformaceCounter : IPerformanceCounter 
{
	private string categoryName;
	private string counterName;
	private string instanceName;
	private string machineName;
	private bool readOnly;
			
	public  float NextValue () 
	{
		float flt = float.Parse("0") ;
		return flt ;
	}
			
	public void BeginInit ()
	{
		NextValue() ;
	}
	
	public string CategoryName {
		get {return categoryName;}
		set {
			if (value == null)
				throw new ArgumentNullException ("categoryName");
			
			categoryName = value;
		}
	}
			
	public string CounterName 
	{
		get {return counterName;}
		set {
				if (value == null)
					throw new ArgumentNullException ("counterName");
				
				counterName = value;
		}
	}
			
	public string InstanceName 
	{
		get {return instanceName;}
		set {instanceName = value;}
	}
		    
	public string MachineName 
	{
		get {return machineName;}
		set {machineName = value;}
	}
	
	public long RawValue {
		get {return 0;}
		set {
			throw new NotImplementedException ();
		}
	}
}

