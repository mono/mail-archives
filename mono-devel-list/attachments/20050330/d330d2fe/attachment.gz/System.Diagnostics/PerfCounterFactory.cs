using System ;

internal sealed class PerfCounterFactory 
{
	public static IPerformanceCounter CreatePerformanceCounter ()
	{
		LinuxPerformanceCounter linuxperfcounter = new LinuxPerformanceCounter() ;
		Console.WriteLine("Gone to the factory") ;
		return 	linuxperfcounter ;
	}
	
	public static IPerformanceCounter CreatePerformanceCounter (string categoryName,
			string counterName,
			string instanceName,
			bool readOnly)
	{
		LinuxPerformanceCounter linuxperfcounter = 
		new LinuxPerformanceCounter(categoryName, counterName, instanceName ,readOnly) ;
			
		return 	linuxperfcounter ;
	}
}
