internal interface IPerformanceCounter 
{		 
	float NextValue () ;
	void BeginInit () ;
	string CategoryName { get; set;} 
	string CounterName { get; set;}
	string InstanceName { get; set;}
	string MachineName { get; set;}
	long RawValue{get; set;}
}
