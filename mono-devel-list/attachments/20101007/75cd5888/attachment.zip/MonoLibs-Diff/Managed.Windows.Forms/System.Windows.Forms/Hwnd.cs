// Permission is hereby granted, free of charge, to any person obtaining
// a copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to
// permit persons to whom the Software is furnished to do so, subject to
// the following conditions:
//
// The above copyright notice and this permission notice shall be
// included in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
// NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
// LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
// OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
// WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
//
// Copyright (c) 2005-2006 Novell, Inc. (http://www.novell.com)
//
// Authors:
//	Peter Bartok	(pbartok@novell.com)
//
// Updated by:
//  Ralph Leckett <rleckett@gmail.com>
//

// NOT COMPLETE

using System;
using System.Collections;
using System.Drawing;
using System.Runtime.InteropServices;

// NOTE: Possible optimization:
// Several properties calculate dimensions on the fly; instead; they can
// be stored in a field and only be recalculated when a style is changed (DefaultClientRect, for example)

namespace System.Windows.Forms
{
    internal class Hwnd : IDisposable
    {
        #region Class Variables

        internal enum State
        {
            ObjectCreated,
            WindowCreated,
            WindowDestroyed,
            ObjectDisposed
        }

        private State _state;
        private IntPtr _frameWindow; //the widow handle for the non-client area (fake for mac, not used for pc)
        private IntPtr _clientWindow; //thw window handle for the client area (fake for mac, native for pc)
        private IntPtr _nativeHandle; //the native window handle that the Mac uses (not used for pc)

        private int _x;
        private int _y;
        private int _width;
        private int _height;
        private CreateParams _cp;
        private Rectangle _nc_invalid;
        private Rectangle _clientRect;
        private Region _userClip;
        private IntPtr _cursor;

        internal Menu menu;
        internal TitleStyle title_style;
        internal FormBorderStyle border_style;
        internal bool border_static;
        internal bool allow_drop;
        internal Hwnd parent;
        internal bool visible;
        internal bool mapped;
        internal uint opacity;
        internal bool enabled;
        internal bool zero_sized;
        private ArrayList invalid_list;
        internal bool expose_pending;
        internal bool nc_expose_pending;
        internal bool configure_pending;
        internal bool resizing_or_moving; // Used by the X11 backend to track form resize/move
        internal bool reparented;
        internal Stack drawing_stack;
        internal object user_data;
        private ArrayList marshal_free_list;
        internal int caption_height;
        internal int tool_caption_height;
        internal bool fixed_size;
        internal XEventQueue queue;
        internal WindowExStyles initial_ex_style;
        internal WindowStyles initial_style;
        internal FormWindowState cached_window_state = (FormWindowState)(-1);  /* X11 only field */
        internal static Point previous_main_startup_location = new Point(int.MinValue, int.MinValue);
        internal Point previous_child_startup_location = new Point(int.MinValue, int.MinValue);
        private ArrayList children;

        [ThreadStatic] //each thread gets its own
        private static Bitmap _ContextBitmap;

        [ThreadStatic] //each thread gets its own
        private static Graphics _ContextGraphics;

        static readonly object handleLock = new object();
        private static Hwnd HwndChain; //let us all join hands
        private Hwnd _hwndNext; //and sing the praises of a linked list

        // locks for some operations (used in XplatUIX11.cs)
        internal object configure_lock = new object();
        internal object expose_lock = new object();

        #endregion	// Class Variables

        #region Constructors and destructors

        internal Hwnd()
            : this(0, 0, 0, 0, null)
        {
        }

        internal Hwnd(CreateParams cp)
            : this(0, 0, 0, 0, cp)
        {
        }

        internal Hwnd(int x, int y, int width, int height, CreateParams cp)
        {
            _state = State.ObjectCreated;
            _frameWindow = IntPtr.Zero;
            _clientWindow = IntPtr.Zero;
            _nativeHandle = IntPtr.Zero;

            _x = x;
            _y = y;
            _width = width;
            _height = height;
            _cp = cp;

            _nc_invalid = Rectangle.Empty;
            _clientRect = Rectangle.Empty; //for now
            _cursor = IntPtr.Zero;

            visible = false;
            menu = null;
            border_style = FormBorderStyle.None;
            parent = null;
            invalid_list = new ArrayList();
            expose_pending = false;
            nc_expose_pending = false;
            enabled = true;
            reparented = false;
            opacity = 0xffffffff;
            fixed_size = false;
            drawing_stack = new Stack();
            children = new ArrayList();
            resizing_or_moving = false;

            AddObjectToChain(this);
        }

        public void Dispose()
        {
            if (_state != State.WindowDestroyed)
                throw new ArgumentNullException("Hwnd.Dispose", "State Error, should be = WindowDestroyed, found = " + _state.ToString());

            _state = State.ObjectDisposed;

            RemoveObjectFromChain(this);
        }

        #endregion

        #region	Static Methods

        private static void AddObjectToChain(Hwnd hwndAdd)
        {
            lock (handleLock)
            {
                hwndAdd._hwndNext = HwndChain; //newcomers go to the front of the line
                HwndChain = hwndAdd;
            }
        }

        private static void RemoveObjectFromChain(Hwnd hwndRemove)
        {
            Hwnd hwndThis;
            lock (handleLock)
            {
                Hwnd hwndPrev = null;
                hwndThis = HwndChain;
                while (hwndThis != null)
                {
                    Hwnd hwndNext = hwndThis._hwndNext;
                    if (hwndThis == hwndRemove)
                    {
                        if (hwndPrev != null)
                            hwndPrev._hwndNext = hwndNext;
                        else //first in line removed
                            HwndChain = hwndNext;
                        break;
                    }
                    hwndPrev = hwndThis;
                    hwndThis = hwndNext;
                }
            }

            if (hwndThis == null)
                throw new ArgumentNullException("Hwnd.RemoveObjectFromChain", "Object not found in hwnd chain");
        }

        internal static Hwnd ObjectFromWindow(IntPtr window)
        {
            return ObjectFromHandle(window);
        }

        internal static Hwnd ObjectFromHandle(IntPtr handle)
        {
            if (handle == IntPtr.Zero)
                return null;

            Hwnd hwndThis;
            lock (handleLock)
            {
                Hwnd hwndPrev = null;
                hwndThis = HwndChain;
                while (hwndThis != null)
                {
                    Hwnd hwndNext = hwndThis._hwndNext;
                    if (hwndThis._frameWindow == handle ||
                        hwndThis._clientWindow == handle)
                    {
                        if (hwndPrev != null)
                        {
                            hwndPrev._hwndNext = hwndNext; //pull out of the lineup
                            hwndThis._hwndNext = HwndChain; //and move to front of line
                            HwndChain = hwndThis; //to speed up (likely) next search (ie. most frequent to front)
                        }
                        break;
                    }
                    hwndPrev = hwndThis;
                    hwndThis = hwndNext;
                }
            }
            return hwndThis;
        }

        internal static Hwnd ObjectFromNativeHandle(IntPtr nativeHandle)
        {
            if (nativeHandle == IntPtr.Zero)
                return null;

            Hwnd hwndThis;
            lock (handleLock)
            {
                Hwnd hwndPrev = null;
                hwndThis = HwndChain;
                while (hwndThis != null)
                {
                    Hwnd hwndNext = hwndThis._hwndNext;
                    if (hwndThis._nativeHandle == nativeHandle)
                    {
                        if (hwndPrev != null)
                        {
                            hwndPrev._hwndNext = hwndNext; //pull out of the lineup
                            hwndThis._hwndNext = HwndChain; //and move to front of line
                            HwndChain = hwndThis; //to speed up (likely) next search (ie. most frequent to front)
                        }
                        break;
                    }
                    hwndPrev = hwndThis;
                    hwndThis = hwndNext;
                }
            }
            return hwndThis;
        }

        internal static Hwnd GetObjectFromWindow(IntPtr window)
        {
            return ObjectFromHandle(window);
        }

        internal static IntPtr GetHandleFromWindow(IntPtr window) //window could be frame or client
        {
            Hwnd hwnd = ObjectFromHandle(window);
            return (hwnd != null ? hwnd._clientWindow : IntPtr.Zero); //but we always return client or nothing
        }

        internal static Borders GetBorderWidth(CreateParams cp)
        {
            Borders border_size = new Borders();

            Size windowborder = ThemeEngine.Current.BorderSize; /*new Size (1, 1);*/ // This is the only one that can be changed from the display properties in windows.
            Size border = ThemeEngine.Current.BorderStaticSize; /*new Size (1, 1);*/
            Size clientedge = ThemeEngine.Current.Border3DSize; /*new Size (2, 2);*/
            Size thickframe = new Size(2 + windowborder.Width, 2 + windowborder.Height);
            Size dialogframe = ThemeEngine.Current.BorderSizableSize; /* new Size (3, 3);*/

            if (cp.IsSet(WindowStyles.WS_CAPTION))
                border_size.Inflate(dialogframe);
            else if (cp.IsSet(WindowStyles.WS_BORDER))
            {
                if (cp.IsSet(WindowExStyles.WS_EX_DLGMODALFRAME))
                {
                    if (cp.IsSet(WindowStyles.WS_THICKFRAME) && (cp.IsSet(WindowExStyles.WS_EX_STATICEDGE) || cp.IsSet(WindowExStyles.WS_EX_CLIENTEDGE)))
                        border_size.Inflate(border);
                }
                else
                    border_size.Inflate(border);
            }
            else if (cp.IsSet(WindowStyles.WS_DLGFRAME))
                border_size.Inflate(dialogframe);

            if (cp.IsSet(WindowStyles.WS_THICKFRAME))
            {
                if (cp.IsSet(WindowStyles.WS_DLGFRAME))
                    border_size.Inflate(border);
                else
                    border_size.Inflate(thickframe);
            }

            bool only_small_border;
            Size small_border = Size.Empty;

            only_small_border = cp.IsSet(WindowStyles.WS_THICKFRAME) || cp.IsSet(WindowStyles.WS_DLGFRAME);
            if (only_small_border && cp.IsSet(WindowStyles.WS_THICKFRAME) && !cp.IsSet(WindowStyles.WS_BORDER) && !cp.IsSet(WindowStyles.WS_DLGFRAME))
                small_border = border;

            if (cp.IsSet(WindowExStyles.WS_EX_CLIENTEDGE | WindowExStyles.WS_EX_DLGMODALFRAME))
                border_size.Inflate(clientedge + (only_small_border ? small_border : dialogframe));
            else if (cp.IsSet(WindowExStyles.WS_EX_STATICEDGE | WindowExStyles.WS_EX_DLGMODALFRAME))
                border_size.Inflate(only_small_border ? small_border : dialogframe);
            else if (cp.IsSet(WindowExStyles.WS_EX_STATICEDGE | WindowExStyles.WS_EX_CLIENTEDGE))
                border_size.Inflate(border + (only_small_border ? Size.Empty : clientedge));
            else
            {
                if (cp.IsSet(WindowExStyles.WS_EX_CLIENTEDGE))
                    border_size.Inflate(clientedge);

                if (cp.IsSet(WindowExStyles.WS_EX_DLGMODALFRAME) && !cp.IsSet(WindowStyles.WS_DLGFRAME))
                    border_size.Inflate(cp.IsSet(WindowStyles.WS_THICKFRAME) ? border : dialogframe);

                if (cp.IsSet(WindowExStyles.WS_EX_STATICEDGE))
                {
                    if (cp.IsSet(WindowStyles.WS_THICKFRAME) || cp.IsSet(WindowStyles.WS_DLGFRAME))
                        border_size.Inflate(new Size(-border.Width, -border.Height));
                    else
                        border_size.Inflate(border);
                }
            }

            return border_size;
        }

        internal static Rectangle GetWindowRectangle(CreateParams cp, Menu menu)
        {
            return GetWindowRectangle(cp, menu, Rectangle.Empty);
        }

        internal static Rectangle GetWindowRectangle(CreateParams cp, Menu menu, Rectangle client_rect)
        {
            Borders borders = GetBorders(cp, menu);
            Rectangle rect;
            rect = new Rectangle(Point.Empty, client_rect.Size);
            rect.Y -= borders.top;
            rect.Height += borders.top + borders.bottom;
            rect.X -= borders.left;
            rect.Width += borders.left + borders.right;
#if debug
			Console.WriteLine ("GetWindowRectangle ({0}, {1}, {2}): {3}", cp, menu != null, client_rect, rect);
#endif
            return rect;
        }

        internal static Borders GetBorders(CreateParams cp, Menu menu)
        {

            Borders borders = new Borders();

            if (menu != null)
            {
                int menu_height = menu.Rect.Height;
                if (menu_height == 0)
                    menu_height = ThemeEngine.Current.CalcMenuBarSize(GraphicsContext, menu, cp.Width);
                borders.top += menu_height;
            }

            if (cp.IsSet(WindowStyles.WS_CAPTION))
            {
                int caption_height;
                if (cp.IsSet(WindowExStyles.WS_EX_TOOLWINDOW))
                    caption_height = ThemeEngine.Current.ToolWindowCaptionHeight;
                else
                    caption_height = ThemeEngine.Current.CaptionHeight;

                borders.top += caption_height;
            }

            Borders border_width = GetBorderWidth(cp);

            borders.left += border_width.left;
            borders.right += border_width.right;
            borders.top += border_width.top;
            borders.bottom += border_width.bottom;

            return borders;
        }

        internal static Rectangle GetClientRectangle(CreateParams cp, Menu menu, int width, int height)
        {
            Borders borders = GetBorders(cp, menu);
            Rectangle rect;
            rect = new Rectangle(0, 0, width, height);
            rect.Y += borders.top;
            rect.Height -= borders.top + borders.bottom;
            rect.X += borders.left;
            rect.Width -= borders.left + borders.right;
#if debug
			Console.WriteLine ("GetClientRectangle ({0}, {1}, {2}, {3}): {4}", cp, menu != null, width, height, rect);
#endif
            return rect;
        }

        internal static Graphics GraphicsContext
        {
            get
            {
                if (_ContextBitmap == null)
                    _ContextBitmap = new Bitmap(1, 1, System.Drawing.Imaging.PixelFormat.Format32bppArgb);
                if (_ContextGraphics == null)
                    _ContextGraphics = Graphics.FromImage(_ContextBitmap, true);
                return _ContextGraphics;
            }
        }

        internal static void CheckAllWindowsDisposed()
        {
            lock (handleLock)
            {
                bool bFirst = true;

                Hwnd hwnd = HwndChain;
                while (hwnd != null)
                {
                    CreateParams cp = hwnd._cp;
                    if (cp.X > 0 || cp.Y > 0 || cp.Width > 0 || cp.Height > 0) //ignore the base window
                    {
                        if (bFirst)
                        {
                            Console.WriteLine("The following windows were not properly disposed:");
                            bFirst = false;
                        }
                        Console.WriteLine(
                            "    Class = " + cp.ClassName +
                            ", Caption = " + cp.Caption +
                            ", X = " + cp.X.ToString() +
                            ", Y = " + cp.Y.ToString() +
                            ", Width = " + cp.Width.ToString() +
                            ", Height = " + cp.Height.ToString() +
                            ", Style = " + cp.WindowStyle.ToString() +
                            ", ExStyle = " + cp.WindowExStyle.ToString());
                    }
                    hwnd = hwnd._hwndNext;
                }

                if (bFirst)
                    Console.WriteLine("All windows properly disposed");
            }
        }

        #endregion	// Static Methods

        #region Instance Properties

        internal State HandleState
        {
            get { return _state; }
        }

        internal bool IsAlive
        {
            get { return _state == State.WindowCreated; }
        }

        internal bool Zombie
        {
            get { return _state == State.WindowDestroyed; }
        }

        internal IntPtr FrameWindow
        {
            get
            {
                if (_frameWindow == IntPtr.Zero)
                    throw new ArgumentNullException("Hwnd.FrameWindow", "Handle is not assigned, window state = " + _state.ToString());

                return _frameWindow;
            }
        }

        internal IntPtr ClientWindow
        {
            get
            {
                if (_clientWindow == IntPtr.Zero)
                    throw new ArgumentNullException("Hwnd.ClientWindow", "Handle is not assigned, window state = " + _state.ToString());

                return _clientWindow;
            }
        }

        internal IntPtr Handle //same as ClientWindow (D'OH!!!)
        {
            get
            {
                if (_clientWindow == IntPtr.Zero)
                    throw new ArgumentNullException("Hwnd.Handle", "Handle is not assigned, window state = " + _state.ToString());

                return _clientWindow;
            }
        }

        internal bool IsNative
        {
            get { return _nativeHandle != IntPtr.Zero; }
        }

        internal IntPtr NativeHandle
        {
            get
            {
                if (_nativeHandle == IntPtr.Zero)
                    throw new ArgumentNullException("Hwnd.NativeHandle", "Native Handle is not assigned");

                return _nativeHandle;
            }
        }

        internal int X
        {
            get { return _x; }
            set { _x = value; }
        }

        internal int Y
        {
            get { return _y; }
            set { _y = value; }
        }

        internal int Width
        {
            get { return _width; }
            set { _width = value; }
        }

        internal int Height
        {
            get { return _height; }
            set { _height = value; }
        }

        internal Rectangle Rect
        {
            get { return new Rectangle(_x, _y, _width, _height); }
        }

        internal Rectangle ClientRect
        {
            get
            {
                if (_clientRect == Rectangle.Empty)
                    return DefaultClientRect;
                return _clientRect;
            }
            set { _clientRect = value; }
        }

        internal CreateParams Params
        {
            get { return _cp; }
        }

        internal FormBorderStyle BorderStyle
        {
            get { return border_style; }
            set { border_style = value; }
        }

        internal IntPtr Cursor
        {
            get { return _cursor; }
            set { _cursor = value; }
        }

        internal Region UserClip
        {
            get { return _userClip; }
            set { _userClip = value; }
        }

        internal Rectangle DefaultClientRect
        {
            get
            {
                // We pass a Zero for the menu handle so the menu size is
                // not computed this is done via an WM_NCCALC
                CreateParams cp = new CreateParams();
                cp.WindowStyle = initial_style;
                cp.WindowExStyle = initial_ex_style;
                return GetClientRectangle(cp, null, _width, _height);
            }
        }

        internal bool ExposePending
        {
            get { return expose_pending; }
        }

        internal Menu Menu
        {
            get { return menu; }
            set { menu = value; }
        }

        internal bool Reparented
        {
            get { return reparented; }
            set { reparented = value; }
        }

        internal uint Opacity
        {
            get { return opacity; }
            set { opacity = value; }
        }

        internal XEventQueue Queue
        {
            get { return queue; }
            set { queue = value; }
        }

        internal bool Enabled
        {
            get
            {
                if (!enabled)
                    return false;

                if (parent != null)
                    return parent.Enabled;

                return true;
            }
            set { enabled = value; }
        }

        internal IntPtr EnabledHwnd
        {
            get
            {
                if (Enabled || parent == null)
                    return Handle;

                return parent.EnabledHwnd;
            }
        }

        internal Point MenuOrigin
        {
            get
            {
                Form frm = Control.FromHandle(ClientWindow) as Form;
                if (frm != null && frm.window_manager != null)
                    return frm.window_manager.GetMenuOrigin();

                Size border_3D_size = ThemeEngine.Current.Border3DSize;
                Point pt = new Point(0, 0);

                if (border_style == FormBorderStyle.Fixed3D)
                {
                    pt.X += border_3D_size.Width;
                    pt.Y += border_3D_size.Height;
                }
                else if (border_style == FormBorderStyle.FixedSingle)
                {
                    pt.X += 1;
                    pt.Y += 1;
                }

                if (this.title_style == TitleStyle.Normal)
                    pt.Y += caption_height;
                else if (this.title_style == TitleStyle.Normal)
                    pt.Y += tool_caption_height;

                return pt;
            }
        }

        internal Rectangle Invalid
        {
            get
            {
                if (invalid_list.Count == 0)
                    return Rectangle.Empty;

                Rectangle result = (Rectangle)invalid_list[0];
                for (int i = 1; i < invalid_list.Count; i++)
                {
                    result = Rectangle.Union(result, (Rectangle)invalid_list[i]);
                }
                return result;
            }
        }

        internal Rectangle[] ClipRectangles
        {
            get { return (Rectangle[])invalid_list.ToArray(typeof(Rectangle)); }
        }

        internal Rectangle NCInvalid
        {
            get { return _nc_invalid; }
            set { _nc_invalid = value; }
        }

        internal bool NCExposePending
        {
            get { return nc_expose_pending; }
        }

        internal Hwnd Parent
        {
            get { return parent; }
            set
            {
                if (parent != null)
                    parent.children.Remove(this);
                parent = value;
                if (parent != null)
                    parent.children.Add(this);
            }
        }

        internal bool Mapped
        {
            get
            {
                if (!mapped)
                    return false;

                if (parent != null)
                    return parent.Mapped;

                return true;
            }
            set { mapped = value; }
        }

        internal int CaptionHeight
        {
            get { return caption_height; }
            set { caption_height = value; }
        }

        internal int ToolCaptionHeight
        {
            get { return tool_caption_height; }
            set { tool_caption_height = value; }
        }

        internal TitleStyle TitleStyle
        {
            get { return title_style; }
            set { title_style = value; }
        }

        internal object UserData
        {
            get { return user_data; }
            set { user_data = value; }
        }

        internal bool Visible
        {
            get { return visible; }
            set { visible = value; }
        }

        #endregion	// Instance properties

        #region Methods

        internal void SetWindows(IntPtr frameWindow, IntPtr clientWindow, IntPtr nativeHandle)
        {
            if (_state != State.ObjectCreated)
                throw new ArgumentNullException("Hwnd.SetWindows", "State Error, should be = ObjectCreated, found = " + _state.ToString());

            _state = State.WindowCreated;

            _frameWindow = frameWindow;
            _clientWindow = clientWindow;
            _nativeHandle = nativeHandle;
        }

        internal void SetWindowsDestroyed()
        {
            if (_state != State.WindowCreated)
                throw new ArgumentNullException("Hwnd.SetWindowsDestroyed", "State Error, should be = WindowCreated, found = " + _state.ToString());

            _state = State.WindowDestroyed;

            _frameWindow = IntPtr.Zero;
            _clientWindow = IntPtr.Zero;
            _nativeHandle = IntPtr.Zero;

            expose_pending = false;
            nc_expose_pending = false;
            Parent = null;

            if (marshal_free_list != null)
            {
                for (int i = 0; i < marshal_free_list.Count; i++)
                {
                    Marshal.FreeHGlobal((IntPtr)marshal_free_list[i]);
                }
                marshal_free_list.Clear();
                marshal_free_list = null;
            }
        }

        internal Rectangle GetClientRectangle(int width, int height)
        {
            CreateParams cp = new CreateParams();
            cp.WindowStyle = initial_style;
            cp.WindowExStyle = initial_ex_style;
            return GetClientRectangle(cp, menu, width, height);
        }

        // This could be greatly optimized by caching the outputs and only updating when something is moved
        // in the parent planar space.  To do that we need to track z-order in the parent space as well
        internal ArrayList GetClippingRectangles()
        {
            ArrayList masks = new ArrayList();

            if (_x < 0)
            {
                masks.Add(new Rectangle(0, 0, _x * -1, Height));
                if (_y < 0)
                    masks.Add(new Rectangle(_x * -1, 0, Width, _y * -1));
            }
            else if (_y < 0)
                masks.Add(new Rectangle(0, 0, Width, _y * -1));

            foreach (Hwnd child in children)
            {
                if (child.visible)
                    masks.Add(new Rectangle(child.X, child.Y, child.Width, child.Height));
            }

            if (parent == null)
                return masks;

            ArrayList siblings = parent.children;

            foreach (Hwnd sibling in siblings)
            {
                IntPtr sibling_handle = FrameWindow;

                if (sibling == this)
                    continue;

                // This entire method should be cached to find all higher views at the time of query
                do
                {
                    sibling_handle = XplatUI.GetPreviousWindow(sibling_handle);

                    if (sibling_handle == sibling.FrameWindow && sibling.visible)
                    {

                        Rectangle intersect = Rectangle.Intersect(new Rectangle(X, Y, Width, Height), new Rectangle(sibling.X, sibling.Y, sibling.Width, sibling.Height));

                        if (intersect == Rectangle.Empty)
                            continue;

                        intersect.X -= X;
                        intersect.Y -= Y;

                        masks.Add(intersect);
                    }
                } while (sibling_handle != IntPtr.Zero);
            }

            return masks;
        }

        internal void AddInvalidArea(int x, int y, int width, int height)
        {
            AddInvalidArea(new Rectangle(x, y, width, height));
        }

        internal void AddInvalidArea(Rectangle rect)
        {
            ArrayList tmp = new ArrayList();
            foreach (Rectangle r in invalid_list)
            {
                if (!rect.Contains(r))
                    tmp.Add(r);
            }
            tmp.Add(rect);
            invalid_list = tmp;
        }

        internal void ClearInvalidArea()
        {
            invalid_list.Clear();
            expose_pending = false;
        }

        internal void AddNcInvalidArea(int x, int y, int width, int height)
        {
            if (_nc_invalid == Rectangle.Empty)
            {
                _nc_invalid = new Rectangle(x, y, width, height);
                return;
            }

            int right = Math.Max(_nc_invalid.Right, x + width);
            int bottom = Math.Max(_nc_invalid.Bottom, y + height);
            _nc_invalid.X = Math.Min(_nc_invalid.X, x);
            _nc_invalid.Y = Math.Min(_nc_invalid.Y, y);

            _nc_invalid.Width = right - _nc_invalid.X;
            _nc_invalid.Height = bottom - _nc_invalid.Y;
        }

        internal void AddNcInvalidArea(Rectangle rect)
        {
            _nc_invalid = (_nc_invalid == Rectangle.Empty ? rect : Rectangle.Union(_nc_invalid, rect));
        }

        internal void ClearNcInvalidArea()
        {
            _nc_invalid = Rectangle.Empty;
            nc_expose_pending = false;
        }

        public override string ToString()
        {
            return String.Format("Hwnd, Mapped:{3} ClientWindow:0x{0:X}, FrameWindow:0x{1:X}, State={4}, Parent:[{2:X}]",
                _clientWindow != IntPtr.Zero ? _clientWindow.ToInt32() : 0,
                _frameWindow != IntPtr.Zero ? _frameWindow.ToInt32() : 0,
                parent != null ? parent.ToString() : "<null>",
                Mapped,
                _state);
        }

        internal static Point GetNextStackedFormLocation(CreateParams cp, Hwnd parent_hwnd)
        {
            if (cp.control == null)
                return Point.Empty;

            int x = cp.X;
            int y = cp.Y;
            Point previous, next;
            Rectangle within;

            if (parent_hwnd != null)
            {
                Control parent = cp.control.Parent;
                previous = parent_hwnd.previous_child_startup_location;
                if (parent_hwnd._clientRect == Rectangle.Empty && parent != null)
                    within = parent.ClientRectangle;
                else
                    within = parent_hwnd._clientRect;
            }
            else
            {
                previous = Hwnd.previous_main_startup_location;
                within = System.Windows.Forms.Screen.PrimaryScreen.WorkingArea;
            }

            if (previous.X == int.MinValue || previous.Y == int.MinValue)
                next = Point.Empty;
            else
                next = new Point(previous.X + 22, previous.Y + 22);

            if (!within.Contains(next.X * 3, next.Y * 3))
                next = Point.Empty;

            if (next == Point.Empty && cp.Parent == IntPtr.Zero)
                next = new Point(22, 22);

            if (parent_hwnd != null)
                parent_hwnd.previous_child_startup_location = next;
            else
                Hwnd.previous_main_startup_location = next;

            if (x == int.MinValue && y == int.MinValue)
            {
                x = next.X;
                y = next.Y;
            }

            return new Point(x, y);
        }

        internal void AddDropTarget(IntPtr drop_target)
        {
            if (marshal_free_list == null)
                marshal_free_list = new ArrayList(2);

            marshal_free_list.Add(drop_target);
        }

        #endregion	// Methods

        internal struct Borders
        {
            internal int top;
            internal int bottom;
            internal int left;
            internal int right;

            internal void Inflate(Size size)
            {
                left += size.Width;
                right += size.Width;
                top += size.Height;
                bottom += size.Height;
            }

            public override string ToString()
            {
                return string.Format("{{top={0}, bottom={1}, left={2}, right={3}}}", top, bottom, left, right);
            }

            public static bool operator ==(Borders a, Borders b)
            {
                return (a.left == b.left && a.right == b.right && a.top == b.top && a.bottom == b.bottom);
            }

            public static bool operator !=(Borders a, Borders b)
            {
                return !(a == b);
            }

            public override bool Equals(object obj)
            {
                return base.Equals(obj);
            }

            public override int GetHashCode()
            {
                return base.GetHashCode();
            }
        }
    }
}
