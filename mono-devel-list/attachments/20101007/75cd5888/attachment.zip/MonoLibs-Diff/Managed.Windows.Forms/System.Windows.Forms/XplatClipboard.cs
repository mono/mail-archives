﻿// Permission is hereby granted, free of charge, to any person obtaining
// a copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to
// permit persons to whom the Software is furnished to do so, subject to
// the following conditions:
// 
// The above copyright notice and this permission notice shall be
// included in all copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
// NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
// LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
// OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
// WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
//
// Authors:
//  Ralph Leckett <rleckett@gmail.com>
//

using System;
using System.Collections.Specialized;
using System.Drawing;
using System.IO;

namespace System.Windows.Forms
{
    internal abstract class XplatClipboard
    {
        internal abstract void Clear();

        internal abstract bool ContainsAudio();

        internal abstract bool ContainsData(string format);

        internal abstract bool ContainsFileDropList();

        internal abstract bool ContainsImage();

        internal abstract bool ContainsText();
#if NET_2_0
        internal abstract bool ContainsText(TextDataFormat format);
#endif
        internal abstract Stream GetAudioStream();

        internal abstract object GetData(string format);

        internal abstract IDataObject GetDataObject();

        internal abstract StringCollection GetFileDropList();

        internal abstract Image GetImage();

        internal abstract string GetText();
#if NET_2_0
        internal abstract string GetText(TextDataFormat format);
#endif
        internal abstract void SetAudio(byte[] audioBytes);

        internal abstract void SetAudio(Stream audioStream);

        internal abstract void SetData(string format, object data);

        internal abstract void SetDataObject(IDataObject dataObject);

        internal abstract void SetDataObject(IDataObject dataObject, bool copy);

        internal abstract void SetDataObject(IDataObject dataObject, bool copy, int retryTimes, int retryDelay);

        internal abstract void SetFileDropList(StringCollection filePaths);

        internal abstract void SetImage(Image image);

        internal abstract void SetText(string text);
#if NET_2_0
        internal abstract void SetText(string text, TextDataFormat format);
#endif
        internal abstract int GetID(string format);
    }
}
