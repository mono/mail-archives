// Permission is hereby granted, free of charge, to any person obtaining
// a copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to
// permit persons to whom the Software is furnished to do so, subject to
// the following conditions:
//
// The above copyright notice and this permission notice shall be
// included in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
// NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
// LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
// OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
// WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
//
// Copyright (c) 2004-2007 Novell, Inc.
//
// Authors:
//	Geoff Norton  <gnorton@novell.com>
//
// Updated by:
//  Ralph Leckett <rleckett@gmail.com>
//

using System;
using System.Collections;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Threading;
using CARBON = System.Windows.Forms.CarbonInternal;

/// Carbon Version
namespace System.Windows.Forms
{
    internal delegate Rectangle[] HwndDelegate(IntPtr handle);

    internal class XplatUICarbon : XplatUIDriver
    {
        #region Local Variables

        //locking semaphores
        static readonly object instanceLock = new object();
        static readonly object queueLock = new object();
        static readonly object timerLock = new object();

        // General driver variables
        private static XplatUICarbon Instance;
        private static int RefCount;
        private static bool themes_enabled;

        // Internal members available to the event handler sub-system
        internal static IntPtr FocusWindow;
        internal static IntPtr ActiveWindow;
        private static IntPtr ReverseWindow;
        private static Rectangle ReverseRect;
        private static Point ReversePt1;
        private static Point ReversePt2;
        private static IntPtr CaretWindow;

        internal static Hwnd MouseHwnd;
        internal static MouseButtons MouseState;
        private static CARBON.Hover Hover;

        private static HwndDelegate HwndDelegate = new HwndDelegate(GetClippingRectangles);

        // Instance members
        internal Point mouse_position;

        // Event handlers
        internal CARBON.ApplicationHandler ApplicationHandler;
        internal CARBON.ControlHandler ControlHandler;
        internal CARBON.HIObjectHandler HIObjectHandler;
        internal CARBON.KeyboardHandler KeyboardHandler;
        internal CARBON.MouseHandler MouseHandler;
        internal CARBON.WindowHandler WindowHandler;

        internal override event EventHandler Idle;

        // Carbon Specific
        internal static GrabStruct Grab;
        internal static CARBON.Caret Caret;
        private static CARBON.Dnd Dnd;
        private static IntPtr FosterParent;
        private static IntPtr Subclass;
        private static int MenuBarHeight;
        internal static ArrayList UtilityWindows;

        // Message loop
        private static Queue MessageQueue;

        //Paint messages
        private class PaintEvent //paint events are "special"
        {
            public PaintEvent Next; //linked list chain
            public Hwnd hwnd;
            public bool wm_paint;
            public bool wm_ncpaint;
            public Region ncpaintRegion;

            public PaintEvent(PaintEvent next, Hwnd hwnd, bool wm_paint, bool wm_ncpaint, Region ncpaintRegion)
            {
                this.Next = next;
                this.hwnd = hwnd;
                this.wm_paint = wm_paint;
                this.wm_ncpaint = wm_ncpaint;
                this.ncpaintRegion = ncpaintRegion;
            }
        }
        private static PaintEvent PaintList; //linked list start

        // Timers
        private class TimerEvent
        {
            public TimerEvent Next; //linked list chain
            public Timer timer;

            public TimerEvent(TimerEvent next, Timer timer)
            {
                this.Next = next;
                this.timer = timer;
            }
        }
        private static TimerEvent TimerList; //linked list start

        private static bool GetMessageResult;
        private static bool in_doevents;

        #endregion

        #region Constructors

        private XplatUICarbon()
        {
            RefCount = 0;
            MessageQueue = new Queue();
            in_doevents = false;

            // Initialize the event handlers
            CARBON.EventHandler.Driver = this;
            ApplicationHandler = new CARBON.ApplicationHandler(this);
            ControlHandler = new CARBON.ControlHandler(this);
            HIObjectHandler = new CARBON.HIObjectHandler(this);
            KeyboardHandler = new CARBON.KeyboardHandler(this);
            MouseHandler = new CARBON.MouseHandler(this);
            WindowHandler = new CARBON.WindowHandler(this);

            // Initilize the mouse controls
            Hover.Interval = 500;
            Hover.Timer = new Timer();
            Hover.Timer.Enabled = false;
            Hover.Timer.Interval = Hover.Interval;
            Hover.Timer.Tick += new EventHandler(HoverCallback);
            Hover.X = -1;
            Hover.Y = -1;
            MouseState = MouseButtons.None;
            mouse_position = Point.Empty;

            // Initialize the Caret
            Caret.Timer = new Timer();
            Caret.Timer.Interval = 500;
            Caret.Timer.Tick += new EventHandler(CaretCallback);

            // Initialize the D&D
            Dnd = new CARBON.Dnd();

            // Initialize the Carbon Specific stuff
            UtilityWindows = new ArrayList();

            // Initialize the FosterParent
            CARBON.Rect rect = new CARBON.Rect();
            SetRect(ref rect, (short)0, (short)0, (short)0, (short)0);
            CARBON.ProcessSerialNumber psn = new CARBON.ProcessSerialNumber();

            GetCurrentProcess(ref psn);
            TransformProcessType(ref psn, 1);
            SetFrontProcess(ref psn);

            HIObjectRegisterSubclass(
                __CFStringMakeConstantString("com.novell.mwfview"),
                __CFStringMakeConstantString("com.apple.hiview"),
                0,
                CARBON.EventHandler.EventHandlerDelegate,
                (uint)CARBON.EventHandler.HIObjectEvents.Length,
                CARBON.EventHandler.HIObjectEvents,
                IntPtr.Zero,
                ref Subclass);

            CARBON.EventHandler.InstallApplicationHandler();

            CreateNewWindow(
                CARBON.WindowClass.kDocumentWindowClass,
                CARBON.WindowAttributes.kWindowStandardHandlerAttribute |
                CARBON.WindowAttributes.kWindowCloseBoxAttribute |
                CARBON.WindowAttributes.kWindowFullZoomAttribute |
                CARBON.WindowAttributes.kWindowCollapseBoxAttribute |
                CARBON.WindowAttributes.kWindowResizableAttribute |
                CARBON.WindowAttributes.kWindowCompositingAttribute,
                ref rect,
                ref FosterParent);

            CreateNewWindow(
                CARBON.WindowClass.kOverlayWindowClass,
                CARBON.WindowAttributes.kWindowNoUpdatesAttribute |
                CARBON.WindowAttributes.kWindowNoActivatesAttribute,
                ref rect,
                ref ReverseWindow);
            ReverseRect = Rectangle.Empty;

            CreateNewWindow(
                CARBON.WindowClass.kOverlayWindowClass,
                CARBON.WindowAttributes.kWindowNoUpdatesAttribute |
                CARBON.WindowAttributes.kWindowNoActivatesAttribute,
                ref rect,
                ref CaretWindow);

            // Get some values about bar heights
            CARBON.Rect structRect = new CARBON.Rect();
            CARBON.Rect contentRect = new CARBON.Rect();
            GetWindowBounds(FosterParent, 32, ref structRect);
            GetWindowBounds(FosterParent, 33, ref contentRect);

            MenuBarHeight = GetMBarHeight();

            // Focus
            FocusWindow = IntPtr.Zero;

            // Message loop
            GetMessageResult = true;
        }

        ~XplatUICarbon()
        {
            // FIXME: Clean up the FosterParent here.
        }

        #endregion

        #region Singleton specific code

        public static XplatUICarbon GetInstance()
        {
            lock (instanceLock)
            {
                if (Instance == null)
                    Instance = new XplatUICarbon();

                RefCount++;
            }
            return Instance;
        }

        public int Reference
        {
            get { return RefCount; }
        }

        #endregion

        #region Internal methods

        internal void AddExpose(Hwnd hwnd, bool client, CARBON.HIRect rect)
        {
            AddExpose(hwnd, client, (int)rect.origin.x, (int)rect.origin.y, (int)rect.size.width, (int)rect.size.height);
        }

        internal void AddExpose(Hwnd hwnd, bool client, Rectangle rect)
        {
            AddExpose(hwnd, client, (int)rect.X, (int)rect.Y, (int)rect.Width, (int)rect.Height);
        }

        internal void FlushQueue()
        {
            CheckTimers(DateTime.UtcNow);
            lock (queueLock)
            {
                while (MessageQueue.Count > 0)
                {
                    object queueobj = MessageQueue.Dequeue();
                    if (queueobj is MSG)
                    {
                        MSG msg = (MSG)queueobj;
                        SendMessage(msg.hwnd, msg.message, msg.wParam, msg.lParam);
                    }
                    else if (queueobj is AsyncMethodData)
                    {
                        AsyncMethodData method = queueobj as AsyncMethodData;
                        XplatUIDriverSupport.ExecuteClientMessage(method);
                    }
                    else
                        Console.WriteLine("Unknown queue object = " + queueobj.ToString());
                }

                //paint events are lower priority than all other events
                while (PaintList != null)
                {
                    PaintEvent paintEvent = PaintList;

                    if (paintEvent.hwnd.IsAlive)
                    {
                        if (paintEvent.wm_ncpaint)
                        {
                            Region rgn = paintEvent.ncpaintRegion;
                            IntPtr hrgn = rgn.GetHrgn(null); // Graphics object isn't needed
                            SendMessage(paintEvent.hwnd.Handle, Msg.WM_NCPAINT, (hrgn == IntPtr.Zero ? (IntPtr)1 : hrgn), IntPtr.Zero);
                        }

                        if (paintEvent.wm_paint)
                            SendMessage(paintEvent.hwnd.Handle, Msg.WM_PAINT, IntPtr.Zero, IntPtr.Zero);
                    }

                    PaintList = paintEvent.Next;
                }
            }
        }

        internal static Rectangle[] GetClippingRectangles(IntPtr handle)
        {
            Hwnd hwnd = Hwnd.ObjectFromHandle(handle);
            if (hwnd == null)
                return null;

            if (hwnd.Handle != handle)
                return new Rectangle[] { hwnd.ClientRect };

            return (Rectangle[])hwnd.GetClippingRectangles().ToArray(typeof(Rectangle));
        }

        internal IntPtr GetMousewParam(int Delta)
        {
            int result = 0;

            if ((MouseState & MouseButtons.Left) != 0)
                result |= (int)MsgButtons.MK_LBUTTON;

            if ((MouseState & MouseButtons.Middle) != 0)
                result |= (int)MsgButtons.MK_MBUTTON;

            if ((MouseState & MouseButtons.Right) != 0)
                result |= (int)MsgButtons.MK_RBUTTON;

            Keys mods = ModifierKeys;
            if ((mods & Keys.Control) != 0)
                result |= (int)MsgButtons.MK_CONTROL;

            if ((mods & Keys.Shift) != 0)
                result |= (int)MsgButtons.MK_SHIFT;

            result |= Delta << 16;

            return (IntPtr)result;
        }

        internal IntPtr HandleToWindow(IntPtr handle)
        {
            Hwnd hwnd = Hwnd.ObjectFromNativeHandle(handle);
            return (hwnd != null ? hwnd.Handle : IntPtr.Zero);
        }

        internal void PerformNCCalc(Hwnd hwnd)
        {
            if (hwnd == null || !hwnd.IsAlive)
                return;

            Rectangle rect = new Rectangle(0, 0, hwnd.Width, hwnd.Height);
            XplatUIWin32.NCCALCSIZE_PARAMS ncp = new XplatUIWin32.NCCALCSIZE_PARAMS();
            IntPtr ptr = Marshal.AllocHGlobal(Marshal.SizeOf(ncp));

            ncp.rgrc1.left = rect.Left;
            ncp.rgrc1.top = rect.Top;
            ncp.rgrc1.right = rect.Right;
            ncp.rgrc1.bottom = rect.Bottom;

            Marshal.StructureToPtr(ncp, ptr, true);
            SendMessage(hwnd.ClientWindow, Msg.WM_NCCALCSIZE, (IntPtr)1, ptr);
            ncp = (XplatUIWin32.NCCALCSIZE_PARAMS)Marshal.PtrToStructure(ptr, typeof(XplatUIWin32.NCCALCSIZE_PARAMS));
            Marshal.FreeHGlobal(ptr);


            rect = new Rectangle(ncp.rgrc1.left, ncp.rgrc1.top, ncp.rgrc1.right - ncp.rgrc1.left, ncp.rgrc1.bottom - ncp.rgrc1.top);
            hwnd.ClientRect = rect;

            rect = TranslateClientRectangleToQuartzClientRectangle(hwnd);

            if (hwnd.visible)
            {
                CARBON.HIRect r = new CARBON.HIRect(rect.X, rect.Y, rect.Width, rect.Height);
                HIViewSetFrame(hwnd.ClientWindow, ref r);
            }

            AddExpose(hwnd, false, 0, 0, hwnd.Width, hwnd.Height);
        }

        internal static Rectangle TranslateClientRectangleToQuartzClientRectangle(Hwnd hwnd)
        {
            return
                (hwnd == null || !hwnd.IsAlive ?
                Rectangle.Empty :
                TranslateClientRectangleToQuartzClientRectangle(hwnd, Control.FromHandle(hwnd.Handle)));
        }

        internal static Rectangle TranslateClientRectangleToQuartzClientRectangle(Hwnd hwnd, Control ctrl)
        {
            /* From XplatUIX11
             * If this is a form with no window manager, X is handling all the border and caption painting
             * so remove that from the area (since the area we set of the window here is the part of the window
             * we're painting in only)
             */
            Rectangle rect = hwnd.ClientRect;
            Form form = ctrl as Form;
            CreateParams cp = null;

            if (form != null)
                cp = form.GetCreateParams();

            if (form != null && (form.window_manager == null || cp.IsSet(WindowExStyles.WS_EX_TOOLWINDOW)))
            {
                Hwnd.Borders borders = Hwnd.GetBorders(cp, null);
                Rectangle qrect = rect;

                qrect.Y -= borders.top;
                qrect.X -= borders.left;
                qrect.Width += borders.left + borders.right;
                qrect.Height += borders.top + borders.bottom;

                rect = qrect;
            }

            if (rect.Width < 1 || rect.Height < 1)
            {
                rect.Width = 1;
                rect.Height = 1;
                rect.X = -5;
                rect.Y = -5;
            }

            return rect;
        }

        internal static Size TranslateWindowSizeToQuartzWindowSize(CreateParams cp)
        {
            return TranslateWindowSizeToQuartzWindowSize(cp, new Size(cp.Width, cp.Height));
        }

        internal static Size TranslateWindowSizeToQuartzWindowSize(CreateParams cp, Size size)
        {
            /* From XplatUIX11
             * If this is a form with no window manager, X is handling all the border and caption painting
             * so remove that from the area (since the area we set of the window here is the part of the window
             * we're painting in only)
             */
            Form form = cp.control as Form;
            if (form != null && (form.window_manager == null || cp.IsSet(WindowExStyles.WS_EX_TOOLWINDOW)))
            {
                Hwnd.Borders borders = Hwnd.GetBorders(cp, null);
                Size qsize = size;

                qsize.Width -= borders.left + borders.right;
                qsize.Height -= borders.top + borders.bottom;

                size = qsize;
            }

            if (size.Height == 0)
                size.Height = 1;
            if (size.Width == 0)
                size.Width = 1;
            return size;
        }

        internal static Size TranslateQuartzWindowSizeToWindowSize(CreateParams cp, int width, int height)
        {
            /* From XplatUIX11
             * If this is a form with no window manager, X is handling all the border and caption painting
             * so remove that from the area (since the area we set of the window here is the part of the window
             * we're painting in only)
             */
            Size size = new Size(width, height);
            Form form = cp.control as Form;
            if (form != null && (form.window_manager == null || cp.IsSet(WindowExStyles.WS_EX_TOOLWINDOW)))
            {
                Hwnd.Borders borders = Hwnd.GetBorders(cp, null);
                Size qsize = size;

                qsize.Width += borders.left + borders.right;
                qsize.Height += borders.top + borders.bottom;

                size = qsize;
            }

            return size;
        }

        #endregion

        #region Callbacks

        private void CaretCallback(object sender, EventArgs e)
        {
            if (Caret.Paused)
                return;

            if (!Caret.On)
                ShowCaret();
            else
                HideCaret();
        }

        private void HoverCallback(object sender, EventArgs e)
        {
            if ((Hover.X == mouse_position.X) && (Hover.Y == mouse_position.Y))
            {
                MSG msg = new MSG();
                msg.hwnd = Hover.Hwnd;
                msg.message = Msg.WM_MOUSEHOVER;
                msg.wParam = GetMousewParam(0);
                msg.lParam = (IntPtr)((ushort)Hover.X << 16 | (ushort)Hover.X);
                EnqueueMessage(msg);
            }
        }

        #endregion

        #region Private Methods

        private Point ConvertScreenPointToClient(IntPtr handle, Point point)
        {
            CARBON.Rect window_bounds = new CARBON.Rect();
            GetWindowBounds(HIViewGetWindow(handle), 32, ref window_bounds);

            CARBON.CGPoint native_point =
                new CARBON.CGPoint(point.X - window_bounds.left, point.Y - window_bounds.top);

            HIViewConvertPoint(ref native_point, IntPtr.Zero, handle);
            return new Point((int)native_point.x, (int)native_point.y);
        }

        private Point ConvertClientPointToScreen(IntPtr handle, Point point)
        {
            Point converted_point = new Point();
            CARBON.Rect window_bounds = new CARBON.Rect();
            CARBON.CGPoint native_point = new CARBON.CGPoint();

            GetWindowBounds(HIViewGetWindow(handle), 32, ref window_bounds);

            native_point.x = point.X;
            native_point.y = point.Y;

            HIViewConvertPoint(ref native_point, handle, IntPtr.Zero);

            converted_point.X = (int)(native_point.x + window_bounds.left);
            converted_point.Y = (int)(native_point.y + window_bounds.top);

            return converted_point;
        }

        private double NextTimeout()
        {
            DateTime now = DateTime.UtcNow;
            int timeout = 0x7FFFFFF;

            lock (timerLock)
            {
                TimerEvent timerEvent = TimerList;
                while (timerEvent != null)
                {
                    int next = (int)(timerEvent.timer.Expires - now).TotalMilliseconds;

                    if (next < 0)
                        return 0;

                    if (next < timeout)
                        timeout = next;

                    timerEvent = timerEvent.Next;
                }
            }

            if (timeout < Timer.Minimum)
                timeout = Timer.Minimum;

            return (double)((double)timeout / 1000);
        }

        private void CheckTimers(DateTime now)
        {
            lock (timerLock)
            {
                TimerEvent timerEvent = TimerList;
                while (timerEvent != null)
                {
                    if (timerEvent.timer.Enabled && timerEvent.timer.Expires <= now)
                    {
                        // Timer ticks:
                        //  - Before MainForm.OnLoad if DoEvents () is called.
                        //  - After MainForm.OnLoad if not.
                        //
                        if (in_doevents ||
                            (Application.MWFThread.Current.Context != null &&
                             Application.MWFThread.Current.Context.MainForm != null &&
                             Application.MWFThread.Current.Context.MainForm.IsLoaded))
                        {
                            timerEvent.timer.FireTick();
                            timerEvent.timer.Update(now);
                        }
                    }
                    timerEvent = timerEvent.Next;
                }
            }
        }

        private void WaitForHwndMessage(Hwnd hwnd, Msg message)
        {
            MSG msg = new MSG();
            bool done = false;

            do
            {
                if (GetMessage(null, ref msg, IntPtr.Zero, 0, 0))
                {
                    if ((Msg)msg.message == Msg.WM_QUIT)
                    {
                        PostQuitMessage(0);
                        done = true;
                    }
                    else if (hwnd != null && hwnd.IsAlive)
                    {
                        if (msg.hwnd == hwnd.Handle)
                        {
                            if ((Msg)msg.message == message)
                                break;

                            if ((Msg)msg.message == Msg.WM_DESTROY)
                                done = true;
                        }
                    }

                    TranslateMessage(ref msg);
                    DispatchMessage(ref msg);
                }
            } while (!done);
        }

        private void SendParentNotify(IntPtr child, Msg cause, int x, int y)
        {
            if (child == IntPtr.Zero)
                return;

            Hwnd hwnd = Hwnd.GetObjectFromWindow(child);
            if (hwnd == null)
                return;

            if (ExStyleSet((int)hwnd.initial_ex_style, WindowExStyles.WS_EX_NOPARENTNOTIFY))
                return;

            if (hwnd.Parent == null || !hwnd.Parent.IsAlive)
                return;

            if (cause == Msg.WM_CREATE || cause == Msg.WM_DESTROY)
                SendMessage(hwnd.Parent.Handle, Msg.WM_PARENTNOTIFY, Control.MakeParam((int)cause, 0), child);
            else
                SendMessage(hwnd.Parent.Handle, Msg.WM_PARENTNOTIFY, Control.MakeParam((int)cause, 0), Control.MakeParam(x, y));

            SendParentNotify(hwnd.Parent.Handle, cause, x, y);
        }

        private bool StyleSet(int s, WindowStyles ws)
        {
            return (s & (int)ws) == (int)ws;
        }

        private bool ExStyleSet(int ex, WindowExStyles exws)
        {
            return (ex & (int)exws) == (int)exws;
        }

        private void DeriveStyles(int Style, int ExStyle, out FormBorderStyle border_style, out bool border_static, out TitleStyle title_style, out int caption_height, out int tool_caption_height)
        {

            caption_height = 0;
            tool_caption_height = 0;
            border_static = false;

            if (StyleSet(Style, WindowStyles.WS_CHILD))
            {
                if (ExStyleSet(ExStyle, WindowExStyles.WS_EX_CLIENTEDGE))
                    border_style = FormBorderStyle.Fixed3D;
                else if (ExStyleSet(ExStyle, WindowExStyles.WS_EX_STATICEDGE))
                {
                    border_style = FormBorderStyle.Fixed3D;
                    border_static = true;
                }
                else if (!StyleSet(Style, WindowStyles.WS_BORDER))
                    border_style = FormBorderStyle.None;
                else
                    border_style = FormBorderStyle.FixedSingle;

                title_style = TitleStyle.None;

                if (StyleSet(Style, WindowStyles.WS_CAPTION))
                {
                    caption_height = 0;
                    if (ExStyleSet(ExStyle, WindowExStyles.WS_EX_TOOLWINDOW))
                        title_style = TitleStyle.Tool;
                    else
                        title_style = TitleStyle.Normal;
                }

                if (ExStyleSet(ExStyle, WindowExStyles.WS_EX_MDICHILD))
                {
                    caption_height = 0;

                    if (StyleSet(Style, WindowStyles.WS_OVERLAPPEDWINDOW) ||
                        ExStyleSet(ExStyle, WindowExStyles.WS_EX_TOOLWINDOW))
                        border_style = (FormBorderStyle)0xFFFF;
                    else
                        border_style = FormBorderStyle.None;
                }

            }
            else
            {
                title_style = TitleStyle.None;
                if (StyleSet(Style, WindowStyles.WS_CAPTION))
                {
                    if (ExStyleSet(ExStyle, WindowExStyles.WS_EX_TOOLWINDOW))
                        title_style = TitleStyle.Tool;
                    else
                        title_style = TitleStyle.Normal;
                }

                border_style = FormBorderStyle.None;

                if (StyleSet(Style, WindowStyles.WS_THICKFRAME))
                {
                    if (ExStyleSet(ExStyle, WindowExStyles.WS_EX_TOOLWINDOW))
                        border_style = FormBorderStyle.SizableToolWindow;
                    else
                        border_style = FormBorderStyle.Sizable;
                }
                else
                {
                    if (StyleSet(Style, WindowStyles.WS_CAPTION))
                    {
                        if (ExStyleSet(ExStyle, WindowExStyles.WS_EX_CLIENTEDGE))
                            border_style = FormBorderStyle.Fixed3D;
                        else if (ExStyleSet(ExStyle, WindowExStyles.WS_EX_STATICEDGE))
                        {
                            border_style = FormBorderStyle.Fixed3D;
                            border_static = true;
                        }
                        else if (ExStyleSet(ExStyle, WindowExStyles.WS_EX_DLGMODALFRAME))
                            border_style = FormBorderStyle.FixedDialog;
                        else if (ExStyleSet(ExStyle, WindowExStyles.WS_EX_TOOLWINDOW))
                            border_style = FormBorderStyle.FixedToolWindow;
                        else if (StyleSet(Style, WindowStyles.WS_BORDER))
                            border_style = FormBorderStyle.FixedSingle;
                    }
                    else if (StyleSet(Style, WindowStyles.WS_BORDER))
                        border_style = FormBorderStyle.FixedSingle;
                }
            }
        }

        private void SetHwndStyles(Hwnd hwnd, CreateParams cp)
        {
            DeriveStyles(cp.Style, cp.ExStyle, out hwnd.border_style, out hwnd.border_static, out hwnd.title_style, out hwnd.caption_height, out hwnd.tool_caption_height);
        }

        private void ShowCaret()
        {
            if (Caret.On)
                return;

            Caret.On = true;
            ShowWindow(CaretWindow);
            Graphics g = Graphics.FromHwnd(HIViewGetRoot(CaretWindow));

            g.FillRectangle(new SolidBrush(Color.Black), new Rectangle(0, 0, Caret.Width, Caret.Height));
            g.Dispose();
        }

        private void HideCaret()
        {
            if (!Caret.On)
                return;

            Caret.On = false;
            HideWindow(CaretWindow);
        }

        private void AddExpose(Hwnd hwnd, bool client, int x, int y, int width, int height)
        {
            // Don't waste time
            if ((hwnd == null) || (x > hwnd.Width) || (y > hwnd.Height) || ((x + width) < 0) || ((y + height) < 0))
                return;

            // Keep the invalid area as small as needed
            if ((x + width) > hwnd.Width)
                width = hwnd.Width - x;

            if ((y + height) > hwnd.Height)
                height = hwnd.Height - y;

            if (client)
            {
                hwnd.AddInvalidArea(x, y, width, height);
                if (!hwnd.expose_pending && hwnd.visible)
                {
                    AddToPaintList(hwnd, true, false, null);
                    hwnd.expose_pending = true;
                }
            }
            else
            {
                hwnd.AddNcInvalidArea(x, y, width, height);
                if (!hwnd.nc_expose_pending && hwnd.visible)
                {
                    AddToPaintList(hwnd, false, true, new Region(hwnd.Invalid));
                    hwnd.nc_expose_pending = true;

                }
            }
        }

        private void AddToPaintList(Hwnd hwndAdd, bool wm_paint, bool wm_ncpaint, Region ncpaintRegion)
        {
            if (hwndAdd == null || hwndAdd.Width <= 0 || hwndAdd.Height <= 0) //ignore windows with nothing to paint
                return;

            lock (queueLock)
            {
                PaintEvent paintEventPrev = null;
                PaintEvent paintEvent = PaintList;
                while (paintEvent != null)
                {
                    if (paintEvent.hwnd == hwndAdd) //avoid duplicates, once is enough
                    {
                        //pick up hitchhikers
                        if (wm_paint)
                            paintEvent.wm_paint = true;

                        if (wm_ncpaint)
                        {
                            paintEvent.wm_ncpaint = true;
                            paintEvent.ncpaintRegion = ncpaintRegion;
                        }

                        //no sense painting NC area if same as Client area
                        if (paintEvent.wm_paint && paintEvent.wm_ncpaint &&
                            paintEvent.hwnd.NCInvalid == paintEvent.hwnd.ClientRect)
                            paintEvent.wm_ncpaint = false;

                        return;
                    }

                    Hwnd parent = paintEvent.hwnd.Parent;
                    while (parent != null)
                    {
                        if (parent == hwndAdd) //honorable ancestors go first
                        {
                            //cut in here
                            PaintEvent paintEventInsert =
                                new PaintEvent(paintEvent, hwndAdd, wm_paint, wm_ncpaint, ncpaintRegion);

                            if (paintEventPrev != null)
                                paintEventPrev.Next = paintEventInsert;
                            else
                                PaintList = paintEventInsert;

                            return;
                        }
                        parent = parent.Parent;
                    }

                    paintEventPrev = paintEvent;
                    paintEvent = paintEvent.Next;
                }

                int xAdd = hwndAdd.X;
                int yAdd = hwndAdd.Y;

                paintEventPrev = null;
                paintEvent = PaintList;
                while (paintEvent != null) //order same level elements into top-down, left-right priority
                {
                    int y = paintEvent.hwnd.Y;
                    if (yAdd < y || (yAdd == y && xAdd < paintEvent.hwnd.X))
                    {
                        //cut in here
                        PaintEvent paintEventInsert =
                            new PaintEvent(paintEvent, hwndAdd, wm_paint, wm_ncpaint, ncpaintRegion);

                        if (paintEventPrev != null)
                            paintEventPrev.Next = paintEventInsert;
                        else
                            PaintList = paintEventInsert;

                        return;
                    }

                    paintEventPrev = paintEvent;
                    paintEvent = paintEvent.Next;
                }

                //join the end of the line
                PaintEvent paintEventAppend =
                    new PaintEvent(null, hwndAdd, wm_paint, wm_ncpaint, ncpaintRegion);

                if (paintEventPrev != null)
                    paintEventPrev.Next = paintEventAppend;
                else
                    PaintList = paintEventAppend;
            }
        }

        #endregion

        #region Public Methods

        internal void EnqueueMessage(MSG msg)
        {
            if (msg.message == Msg.WM_PAINT)
                AddToPaintList(Hwnd.ObjectFromHandle(msg.hwnd), true, false, null);
            else if (msg.message == Msg.WM_NCPAINT)
                AddToPaintList(Hwnd.ObjectFromHandle(msg.hwnd), false, true, (Region)msg.refobject);
            else
                lock (queueLock)
                {
                    MessageQueue.Enqueue(msg);
                }
        }

        internal override void RaiseIdle(EventArgs e)
        {
            if (Idle != null)
                Idle(this, e);
        }

        internal override IntPtr InitializeDriver()
        {
            return IntPtr.Zero;
        }

        internal override void ShutdownDriver(IntPtr token)
        {
        }

        internal override void EnableThemes()
        {
            themes_enabled = true;
        }

        internal override void Activate(IntPtr handle)
        {
            if (ActiveWindow != IntPtr.Zero)
                ActivateWindow(HIViewGetWindow(ActiveWindow), false);

            ActivateWindow(HIViewGetWindow(handle), true);
            ActiveWindow = handle;
        }

        internal override void AudibleAlert(AlertType alert)
        {
            AlertSoundPlay();
        }

        internal override void CaretVisible(IntPtr hwnd, bool visible)
        {
            if (Caret.Hwnd == hwnd)
            {
                if (visible)
                {
                    if (Caret.Visible < 1)
                    {
                        Caret.Visible++;
                        Caret.On = false;
                        if (Caret.Visible == 1)
                        {
                            ShowCaret();
                            Caret.Timer.Start();
                        }
                    }
                }
                else
                {
                    Caret.Visible--;
                    if (Caret.Visible == 0)
                    {
                        Caret.Timer.Stop();
                        HideCaret();
                    }
                }
            }
        }

        internal override bool CalculateWindowRect(ref Rectangle ClientRect, CreateParams cp, Menu menu, out Rectangle WindowRect)
        {
            WindowRect = Hwnd.GetWindowRectangle(cp, menu, ClientRect);
            return true;
        }

        internal override void ClientToScreen(IntPtr handle, ref int x, ref int y)
        {
            Hwnd hwnd = Hwnd.ObjectFromHandle(handle);
            if (hwnd != null)
            {
                Point point = ConvertClientPointToScreen(hwnd.ClientWindow, new Point(x, y));
                x = point.X;
                y = point.Y;
            }
        }

        internal override void MenuToScreen(IntPtr handle, ref int x, ref int y)
        {
            Hwnd hwnd = Hwnd.ObjectFromHandle(handle);
            if (hwnd != null)
            {
                Point point = ConvertClientPointToScreen(hwnd.ClientWindow, new Point(x, y));
                x = point.X;
                y = point.Y;
            }
        }

        internal override void CreateCaret(IntPtr hwnd, int width, int height)
        {
            if (Caret.Hwnd != IntPtr.Zero)
                DestroyCaret(Caret.Hwnd);

            Caret.Hwnd = hwnd;
            Caret.Width = width;
            Caret.Height = height;
            Caret.Visible = 0;
            Caret.On = false;
        }

        internal override IntPtr CreateWindow(CreateParams cp)
        {
            int x = cp.X;
            int y = cp.Y;
            int width = cp.Width;
            int height = cp.Height;

            if (width < 0)
                width = 0;
            if (height < 0)
                height = 0;

            Hwnd parent_hwnd = null;
            IntPtr parentHandle = IntPtr.Zero;

            if (cp.Parent != IntPtr.Zero)
            {
                parent_hwnd = Hwnd.ObjectFromHandle(cp.Parent);
                if (parent_hwnd != null)
                    parentHandle = parent_hwnd.ClientWindow;
            }
            else if (StyleSet(cp.Style, WindowStyles.WS_CHILD))
                HIViewFindByID(HIViewGetRoot(FosterParent), new CARBON.HIViewID(CARBON.EventHandler.kEventClassWindow, 1), ref parentHandle);

            if (cp.control is Form)
            {
                Point next = Hwnd.GetNextStackedFormLocation(cp, parent_hwnd);
                x = next.X;
                y = next.Y;
            }

            Hwnd hwnd = new Hwnd(x, y, width, height, cp);

            hwnd.Parent = Hwnd.ObjectFromHandle(cp.Parent);
            hwnd.initial_style = cp.WindowStyle;
            hwnd.initial_ex_style = cp.WindowExStyle;
            hwnd.visible = false;

            if (StyleSet(cp.Style, WindowStyles.WS_DISABLED))
                hwnd.enabled = false;

            Size QWindowSize = TranslateWindowSizeToQuartzWindowSize(cp);
            Rectangle QClientRect = TranslateClientRectangleToQuartzClientRectangle(hwnd, cp.control);

            SetHwndStyles(hwnd, cp);
            /* FIXME */
            IntPtr nativeHandle = IntPtr.Zero;
            if (parentHandle == IntPtr.Zero)
            {
                IntPtr WindowView = IntPtr.Zero;
                IntPtr GrowBox = IntPtr.Zero;
                CARBON.WindowClass windowklass = CARBON.WindowClass.kOverlayWindowClass;
                CARBON.WindowAttributes attributes = CARBON.WindowAttributes.kWindowCompositingAttribute | CARBON.WindowAttributes.kWindowStandardHandlerAttribute;
                if (StyleSet(cp.Style, WindowStyles.WS_MINIMIZEBOX))
                    attributes |= CARBON.WindowAttributes.kWindowCollapseBoxAttribute;

                if (StyleSet(cp.Style, WindowStyles.WS_MAXIMIZEBOX))
                    attributes |= CARBON.WindowAttributes.kWindowResizableAttribute | CARBON.WindowAttributes.kWindowHorizontalZoomAttribute | CARBON.WindowAttributes.kWindowVerticalZoomAttribute;

                if (StyleSet(cp.Style, WindowStyles.WS_SYSMENU))
                    attributes |= CARBON.WindowAttributes.kWindowCloseBoxAttribute;

                if (StyleSet(cp.Style, WindowStyles.WS_CAPTION))
                    windowklass = CARBON.WindowClass.kDocumentWindowClass;

                if (hwnd.border_style == FormBorderStyle.FixedToolWindow)
                    windowklass = CARBON.WindowClass.kUtilityWindowClass;
                else if (hwnd.border_style == FormBorderStyle.SizableToolWindow)
                {
                    attributes |= CARBON.WindowAttributes.kWindowResizableAttribute;
                    windowklass = CARBON.WindowClass.kUtilityWindowClass;
                }

                if (windowklass == CARBON.WindowClass.kOverlayWindowClass)
                    attributes = CARBON.WindowAttributes.kWindowCompositingAttribute | CARBON.WindowAttributes.kWindowStandardHandlerAttribute;

                attributes |= CARBON.WindowAttributes.kWindowLiveResizeAttribute;

                CARBON.Rect rect = new CARBON.Rect();
                if (StyleSet(cp.Style, WindowStyles.WS_POPUP))
                    SetRect(ref rect, (short)x, (short)(y), (short)(x + QWindowSize.Width), (short)(y + QWindowSize.Height));
                else
                    SetRect(ref rect, (short)x, (short)(y + MenuBarHeight), (short)(x + QWindowSize.Width), (short)(y + MenuBarHeight + QWindowSize.Height));

                CreateNewWindow(windowklass, attributes, ref rect, ref nativeHandle);

                CARBON.EventHandler.InstallWindowHandler(nativeHandle);
                HIViewFindByID(HIViewGetRoot(nativeHandle), new CARBON.HIViewID(CARBON.EventHandler.kEventClassWindow, 1), ref WindowView);
                HIViewFindByID(HIViewGetRoot(nativeHandle), new CARBON.HIViewID(CARBON.EventHandler.kEventClassWindow, 7), ref GrowBox);
                HIGrowBoxViewSetTransparent(GrowBox, true);
                SetAutomaticControlDragTrackingEnabledForWindow(nativeHandle, true);
                parentHandle = WindowView;
            }

            IntPtr frameWindow = IntPtr.Zero;
            IntPtr clientWindow = IntPtr.Zero;
            HIObjectCreate(__CFStringMakeConstantString("com.novell.mwfview"), 0, ref frameWindow);
            HIObjectCreate(__CFStringMakeConstantString("com.novell.mwfview"), 0, ref clientWindow);

            CARBON.EventHandler.InstallControlHandler(frameWindow);
            CARBON.EventHandler.InstallControlHandler(clientWindow);

            // Enable embedding on controls
            HIViewChangeFeatures(frameWindow, 1 << 1, 0);
            HIViewChangeFeatures(clientWindow, 1 << 1, 0);

            IntPtr FrameWindowTracking = IntPtr.Zero;
            IntPtr ClientWindowTracking = IntPtr.Zero;
            HIViewNewTrackingArea(frameWindow, IntPtr.Zero, (UInt64)frameWindow, ref FrameWindowTracking);
            HIViewNewTrackingArea(clientWindow, IntPtr.Zero, (UInt64)clientWindow, ref ClientWindowTracking);

            CARBON.HIRect FrameRect;
            if (nativeHandle != IntPtr.Zero)
                FrameRect = new CARBON.HIRect(0, 0, QWindowSize.Width, QWindowSize.Height);
            else
                FrameRect = new CARBON.HIRect(x, y, QWindowSize.Width, QWindowSize.Height);

            CARBON.HIRect ClientRect = new CARBON.HIRect(QClientRect.X, QClientRect.Y, QClientRect.Width, QClientRect.Height);
            HIViewSetFrame(frameWindow, ref FrameRect);
            HIViewSetFrame(clientWindow, ref ClientRect);

            HIViewAddSubview(parentHandle, frameWindow);
            HIViewAddSubview(frameWindow, clientWindow);

            hwnd.SetWindows(frameWindow, clientWindow, nativeHandle);

            if (nativeHandle != IntPtr.Zero)
            {
                if (hwnd.border_style == FormBorderStyle.FixedToolWindow || hwnd.border_style == FormBorderStyle.SizableToolWindow)
                    UtilityWindows.Add(nativeHandle);
            }

            // Allow dnd on controls
            Dnd.SetAllowDrop(hwnd, true);

            Text(hwnd.Handle, cp.Caption);

            SendMessage(hwnd.Handle, Msg.WM_CREATE, (IntPtr)1, IntPtr.Zero /* XXX unused */);
            SendParentNotify(hwnd.Handle, Msg.WM_CREATE, int.MaxValue, int.MaxValue);

            if (StyleSet(cp.Style, WindowStyles.WS_VISIBLE))
            {
                if (nativeHandle != IntPtr.Zero)
                {
                    if (Control.FromHandle(hwnd.Handle) is Form)
                    {
                        Form f = Control.FromHandle(hwnd.Handle) as Form;
                        if (f.WindowState == FormWindowState.Normal)
                            SendMessage(hwnd.Handle, Msg.WM_SHOWWINDOW, (IntPtr)1, IntPtr.Zero);
                    }
                    ShowWindow(nativeHandle);
                    WaitForHwndMessage(hwnd, Msg.WM_SHOWWINDOW);
                }
                HIViewSetVisible(frameWindow, true);
                HIViewSetVisible(clientWindow, true);
                hwnd.visible = true;
                if (!(Control.FromHandle(hwnd.Handle) is Form))
                    SendMessage(hwnd.Handle, Msg.WM_SHOWWINDOW, (IntPtr)1, IntPtr.Zero);
            }

            if (StyleSet(cp.Style, WindowStyles.WS_MINIMIZE))
                SetWindowState(hwnd.Handle, FormWindowState.Minimized);
            else if (StyleSet(cp.Style, WindowStyles.WS_MAXIMIZE))
                SetWindowState(hwnd.Handle, FormWindowState.Maximized);

            return hwnd.Handle;
        }

        internal override IntPtr CreateWindow(IntPtr Parent, int x, int y, int width, int height)
        {
            CreateParams create_params = new CreateParams();

            create_params.Caption = "";
            create_params.X = x;
            create_params.Y = y;
            create_params.Width = width;
            create_params.Height = height;

            create_params.ClassName = XplatUI.DefaultClassName;
            create_params.ClassStyle = 0;
            create_params.ExStyle = 0;
            create_params.Parent = IntPtr.Zero;
            create_params.Param = 0;

            return CreateWindow(create_params);
        }

        internal override Bitmap DefineStdCursorBitmap(StdCursor id)
        {
            return CARBON.Cursor.DefineStdCursorBitmap(id);
        }

        internal override IntPtr DefineCursor(Bitmap bitmap, Bitmap mask, Color cursor_pixel, Color mask_pixel, int xHotSpot, int yHotSpot)
        {
            return CARBON.Cursor.DefineCursor(bitmap, mask, cursor_pixel, mask_pixel, xHotSpot, yHotSpot);
        }

        internal override IntPtr DefineStdCursor(StdCursor id)
        {
            return CARBON.Cursor.DefineStdCursor(id);
        }

        internal override IntPtr DefWndProc(ref Message msg)
        {
            Hwnd hwnd = Hwnd.ObjectFromHandle(msg.HWnd);
            if (hwnd != null)
            {
                switch ((Msg)msg.Msg)
                {
                    case Msg.WM_IME_COMPOSITION:
                        string s = KeyboardHandler.ComposedString;
                        foreach (char c in s)
                            SendMessage(msg.HWnd, Msg.WM_IME_CHAR, (IntPtr)c, msg.LParam);
                        break;

                    case Msg.WM_IME_CHAR:
                        // On Windows API it sends two WM_CHAR messages for each byte, but
                        // I wonder if it is worthy to emulate it (also no idea how to
                        // reconstruct those bytes into chars).
                        SendMessage(msg.HWnd, Msg.WM_CHAR, msg.WParam, msg.LParam);
                        return IntPtr.Zero;

                    case Msg.WM_QUIT:
                        if (hwnd.IsNative)
                            Exit();
                        break;

                    case Msg.WM_PAINT:
                        hwnd.expose_pending = false;
                        break;

                    case Msg.WM_NCPAINT:
                        hwnd.nc_expose_pending = false;
                        break;

                    case Msg.WM_NCCALCSIZE:
                        if (msg.WParam == (IntPtr)1 && hwnd.IsAlive)
                        {
                            XplatUIWin32.NCCALCSIZE_PARAMS ncp;
                            ncp = (XplatUIWin32.NCCALCSIZE_PARAMS)Marshal.PtrToStructure(msg.LParam, typeof(XplatUIWin32.NCCALCSIZE_PARAMS));

                            // Add all the stuff X is supposed to draw.
                            Control ctrl = Control.FromHandle(hwnd.Handle);
                            if (ctrl != null)
                            {
                                Hwnd.Borders rect = Hwnd.GetBorders(ctrl.GetCreateParams(), null);

                                ncp.rgrc1.top += rect.top;
                                ncp.rgrc1.bottom -= rect.bottom;
                                ncp.rgrc1.left += rect.left;
                                ncp.rgrc1.right -= rect.right;

                                Marshal.StructureToPtr(ncp, msg.LParam, true);
                            }
                        }
                        break;

                    case Msg.WM_SETCURSOR:
                        if (hwnd.IsAlive)
                        {
                            // Pass to parent window first
                            while ((hwnd.parent != null) && (msg.Result == IntPtr.Zero))
                            {
                                hwnd = hwnd.parent;
                                msg.Result = SendMessage(hwnd.Handle, Msg.WM_SETCURSOR, msg.HWnd, msg.LParam);
                            }
                        }

                        if (msg.Result == IntPtr.Zero)
                        {
                            IntPtr handle;

                            switch ((HitTest)(msg.LParam.ToInt32() & 0xffff))
                            {
                                case HitTest.HTBOTTOM: handle = Cursors.SizeNS.handle; break;
                                case HitTest.HTBORDER: handle = Cursors.SizeNS.handle; break;
                                case HitTest.HTBOTTOMLEFT: handle = Cursors.SizeNESW.handle; break;
                                case HitTest.HTBOTTOMRIGHT: handle = Cursors.SizeNWSE.handle; break;
                                case HitTest.HTERROR:
                                    if ((msg.LParam.ToInt32() >> 16) == (int)Msg.WM_LBUTTONDOWN)
                                    {
                                        //FIXME: AudibleAlert();
                                    }
                                    handle = Cursors.Default.handle;
                                    break;
                                case HitTest.HTHELP: handle = Cursors.Help.handle; break;
                                case HitTest.HTLEFT: handle = Cursors.SizeWE.handle; break;
                                case HitTest.HTRIGHT: handle = Cursors.SizeWE.handle; break;
                                case HitTest.HTTOP: handle = Cursors.SizeNS.handle; break;
                                case HitTest.HTTOPLEFT: handle = Cursors.SizeNWSE.handle; break;
                                case HitTest.HTTOPRIGHT: handle = Cursors.SizeNESW.handle; break;
#if SameAsDefault
						        case HitTest.HTGROWBOX:
						        case HitTest.HTSIZE:
						        case HitTest.HTZOOM:
						        case HitTest.HTVSCROLL:
						        case HitTest.HTSYSMENU:
						        case HitTest.HTREDUCE:
						        case HitTest.HTNOWHERE:
						        case HitTest.HTMAXBUTTON:
						        case HitTest.HTMINBUTTON:
						        case HitTest.HTMENU:
						        case HitTest.HSCROLL:
						        case HitTest.HTBOTTOM:
						        case HitTest.HTCAPTION:
						        case HitTest.HTCLIENT:
						        case HitTest.HTCLOSE:
#endif
                                default: handle = Cursors.Default.handle; break;
                            }

                            SetCursor(msg.HWnd, handle);
                        }

                        return (IntPtr)1;
                }
            }
            return IntPtr.Zero;
        }

        internal override void DestroyCaret(IntPtr hwnd)
        {
            if (Caret.Hwnd == hwnd)
            {
                if (Caret.Visible == 1)
                {
                    Caret.Timer.Stop();
                    HideCaret();
                }
                Caret.Hwnd = IntPtr.Zero;
                Caret.Visible = 0;
                Caret.On = false;
            }
        }

        [MonoTODO]
        internal override void DestroyCursor(IntPtr cursor)
        {
            throw new NotImplementedException();
        }

        internal override void DestroyWindow(IntPtr handle)
        {
            Hwnd hwnd = Hwnd.ObjectFromHandle(handle);
            if (hwnd == null)
                return;

            if (hwnd.IsNative)
                HideWindow(hwnd.NativeHandle);

            SendParentNotify(hwnd.Handle, Msg.WM_DESTROY, int.MaxValue, int.MaxValue);
            DestroyControl(Control.FromHandle(hwnd.Handle));
        }

        private void DestroyControl(Control ctrl)
        {
            if (ctrl != null && ctrl.IsHandleCreated && !ctrl.IsDisposed)
            {
                Control[] kids = ctrl.Controls.GetAllControls();
                foreach (Control c in kids)
                {
                    DestroyControl(c);
                }

                Hwnd hwnd = Hwnd.ObjectFromHandle(ctrl.Handle);
                if (hwnd != null)
                {
                    IntPtr handle = hwnd.Handle;
                    if (handle == ActiveWindow)
                    {
                        SendMessage(handle, Msg.WM_ACTIVATE, (IntPtr)WindowActiveFlags.WA_INACTIVE, IntPtr.Zero);
                        ActiveWindow = IntPtr.Zero;
                    }

                    if (handle == FocusWindow)
                    {
                        SendMessage(handle, Msg.WM_KILLFOCUS, IntPtr.Zero, IntPtr.Zero);
                        FocusWindow = IntPtr.Zero;
                    }

                    if (handle == Grab.Hwnd)
                    {
                        Grab.Hwnd = IntPtr.Zero;
                        Grab.Area = Rectangle.Empty;
                        Grab.Confined = false;
                        Grab.Dragging = false;
                    }

                    DestroyCaret(handle);
                    SendMessage(handle, Msg.WM_DESTROY, IntPtr.Zero, IntPtr.Zero);

                    hwnd.SetWindowsDestroyed();
                    hwnd.Dispose();
                }

                ctrl.Dispose();
            }
        }

        internal override IntPtr DispatchMessage(ref MSG msg)
        {
            return NativeWindow.WndProc(msg.hwnd, msg.message, msg.wParam, msg.lParam);
        }

        internal override void DoEvents()
        {
            in_doevents = true;

            MSG msg = new MSG();
            while (PeekMessage(null, ref msg, IntPtr.Zero, 0, 0, (uint)PeekMessageFlags.PM_REMOVE))
            {
                TranslateMessage(ref msg);
                DispatchMessage(ref msg);
            }

            in_doevents = false;
        }

        internal override void EnableWindow(IntPtr handle, bool Enable)
        {
            //Like X11 we need not do anything here
        }

        internal override void EndLoop(Thread thread)
        {
        }

        internal void Exit()
        {
            GetMessageResult = false;
        }

        internal override IntPtr GetActive()
        {
            return ActiveWindow;
        }

        internal override Region GetClipRegion(IntPtr hwnd)
        {
            return null;
        }

        [MonoTODO]
        internal override void GetCursorInfo(IntPtr cursor, out int width, out int height, out int hotspot_x, out int hotspot_y)
        {
            width = 12;
            height = 12;
            hotspot_x = 0;
            hotspot_y = 0;
        }

        internal override void GetDisplaySize(out Size size)
        {
            CARBON.HIRect bounds = CGDisplayBounds(CGMainDisplayID());
            size = new Size((int)bounds.size.width, (int)bounds.size.height);
        }

        internal override IntPtr GetParent(IntPtr handle)
        {
            Hwnd hwnd = Hwnd.ObjectFromHandle(handle);
            return
                (hwnd != null && hwnd.Parent != null && hwnd.Parent.IsAlive ?
                hwnd.Parent.Handle :
                IntPtr.Zero);
        }

        internal override IntPtr GetPreviousWindow(IntPtr handle)
        {
            return HIViewGetPreviousView(handle);
        }

        internal override void GetCursorPos(IntPtr handle, out int x, out int y)
        {
            CARBON.QDPoint pt = new CARBON.QDPoint();
            GetGlobalMouse(ref pt);
            x = pt.x;
            y = pt.y;
        }

        internal override IntPtr GetFocus()
        {
            return FocusWindow;
        }


        internal override bool GetFontMetrics(Graphics g, Font font, out int ascent, out int descent)
        {
            FontFamily ff = font.FontFamily;
            ascent = ff.GetCellAscent(font.Style);
            descent = ff.GetCellDescent(font.Style);
            return true;
        }

        internal override Point GetMenuOrigin(IntPtr handle)
        {
            Hwnd hwnd = Hwnd.ObjectFromHandle(handle);
            if (hwnd != null)
                return hwnd.MenuOrigin;

            return Point.Empty;
        }

        internal override bool GetMessage(object queue_id, ref MSG msg, IntPtr hWnd, int wFilterMin, int wFilterMax)
        {
            IntPtr evtRef = IntPtr.Zero;
            IntPtr target = GetEventDispatcherTarget();
            CheckTimers(DateTime.UtcNow);
            ReceiveNextEvent(0, IntPtr.Zero, 0, true, ref evtRef);
            if (evtRef != IntPtr.Zero && target != IntPtr.Zero)
            {
                SendEventToEventTarget(evtRef, target);
                ReleaseEvent(evtRef);
            }

            lock (queueLock)
            {
                for (; ; ) //forever and ever and ever...
                {
                    if (MessageQueue.Count > 0)
                    {
                        object queueobj = MessageQueue.Dequeue();
                        if (queueobj is MSG)
                        {
                            msg = (MSG)queueobj;
                            return GetMessageResult;
                        }

                        if (queueobj is AsyncMethodData)
                        {
                            AsyncMethodData method = queueobj as AsyncMethodData;
                            XplatUIDriverSupport.ExecuteClientMessage(method);
                        }
                        else
                            Console.WriteLine("Unknown queue object = " + queueobj.ToString());
                    }
                    else if (PaintList != null)
                    {
                        PaintEvent paintEvent = PaintList;
                        if (paintEvent.hwnd.IsAlive)
                        {
                            if (paintEvent.wm_ncpaint)
                            {
                                Region rgn = paintEvent.ncpaintRegion;
                                IntPtr hrgn = rgn.GetHrgn(null); // Graphics object isn't needed

                                msg.hwnd = paintEvent.hwnd.Handle;
                                msg.message = Msg.WM_NCPAINT;
                                msg.wParam = (hrgn == IntPtr.Zero ? (IntPtr)1 : hrgn);
                                msg.refobject = rgn;

                                paintEvent.wm_ncpaint = false; //done
                                if (!paintEvent.wm_paint)
                                    PaintList = paintEvent.Next;

                                return GetMessageResult;
                            }

                            if (paintEvent.wm_paint)
                            {
                                msg.hwnd = paintEvent.hwnd.Handle;
                                msg.message = Msg.WM_PAINT;

                                PaintList = paintEvent.Next;
                                return GetMessageResult;
                            }
                        }

                        PaintList = paintEvent.Next; //ignore and remove
                    }
                    else
                    {
                        if (Idle != null)
                            Idle(this, EventArgs.Empty);
                        else if (TimerList != null)
                        {
                            ReceiveNextEvent(0, IntPtr.Zero, NextTimeout(), true, ref evtRef);
                            if (evtRef != IntPtr.Zero && target != IntPtr.Zero)
                            {
                                SendEventToEventTarget(evtRef, target);
                                ReleaseEvent(evtRef);
                            }
                        }
                        else
                        {
                            ReceiveNextEvent(0, IntPtr.Zero, 0.15, true, ref evtRef);
                            if (evtRef != IntPtr.Zero && target != IntPtr.Zero)
                            {
                                SendEventToEventTarget(evtRef, target);
                                ReleaseEvent(evtRef);
                            }
                        }

                        msg.hwnd = IntPtr.Zero;
                        msg.message = Msg.WM_ENTERIDLE;
                        return GetMessageResult;
                    }
                }
            }
        }

        [MonoTODO]
        internal override bool GetText(IntPtr handle, out string text)
        {
            throw new NotImplementedException();
        }

        internal override void GetWindowPos(IntPtr handle, bool is_toplevel, out int x, out int y, out int width, out int height, out int client_width, out int client_height)
        {
            Hwnd hwnd = Hwnd.ObjectFromHandle(handle);
            if (hwnd != null)
            {
                x = hwnd.X;
                y = hwnd.Y;
                width = hwnd.Width;
                height = hwnd.Height;

                PerformNCCalc(hwnd);

                client_width = hwnd.ClientRect.Width;
                client_height = hwnd.ClientRect.Height;

                return;
            }

            // Should we throw an exception or fail silently?
            // throw new ArgumentException("Called with an invalid window handle", "handle");

            x = 0;
            y = 0;
            width = 0;
            height = 0;
            client_width = 0;
            client_height = 0;
        }

        internal override FormWindowState GetWindowState(IntPtr hwnd)
        {
            IntPtr window = HIViewGetWindow(hwnd);

            if (IsWindowCollapsed(window))
                return FormWindowState.Minimized;

            if (IsWindowInStandardState(window, IntPtr.Zero, IntPtr.Zero))
                return FormWindowState.Maximized;

            return FormWindowState.Normal;
        }

        internal override void GrabInfo(out IntPtr handle, out bool GrabConfined, out Rectangle GrabArea)
        {
            handle = Grab.Hwnd;
            GrabConfined = Grab.Confined;
            GrabArea = Grab.Area;
        }

        internal override void GrabWindow(IntPtr handle, IntPtr confine_to_handle)
        {
            Grab.Hwnd = handle;
            Hwnd hwnd = Hwnd.ObjectFromHandle(handle);
            if (hwnd != null)
                Grab.Area = hwnd.Rect;
            Grab.Confined = confine_to_handle != IntPtr.Zero;
            Grab.Dragging = false;
        }

        internal override void DragWindow(IntPtr handle)
        {
            Grab.Hwnd = handle;
            Hwnd hwnd = Hwnd.ObjectFromHandle(handle);
            if (hwnd != null)
                Grab.Area = hwnd.Rect;
            Grab.Confined = false;
            Grab.Dragging = true;
        }

        internal override void UngrabWindow(IntPtr hwnd)
        {
            bool was_grabbed = Grab.Hwnd != IntPtr.Zero;

            Grab.Hwnd = IntPtr.Zero;
            Grab.Area = Rectangle.Empty;
            Grab.Confined = false;
            Grab.Dragging = false;

            if (was_grabbed)
            {
                // lparam should be the handle to the window gaining the mouse capture,
                // but we dont have that information like X11.
                // Also only generate WM_CAPTURECHANGED if the window actually was grabbed.
                SendMessage(hwnd, Msg.WM_CAPTURECHANGED, IntPtr.Zero, IntPtr.Zero);

                if (ReverseRect != Rectangle.Empty)
                {
                    HideWindow(ReverseWindow);
                    ReverseRect = Rectangle.Empty;
                }
            }
        }

        internal override void HandleException(Exception e)
        {
            StackTrace st = new StackTrace(e);
            Console.WriteLine("Exception '{0}'", e.Message + st.ToString());
            Console.WriteLine("{0}{1}", e.Message, st.ToString());
        }

        internal override void Invalidate(IntPtr handle, Rectangle rc, bool clear)
        {
            Hwnd hwnd = Hwnd.ObjectFromHandle(handle);
            if (hwnd != null)
            {
                if (clear)
                    AddExpose(hwnd, true, hwnd.X, hwnd.Y, hwnd.Width, hwnd.Height);
                else
                    AddExpose(hwnd, true, rc.X, rc.Y, rc.Width, rc.Height);
            }
        }

        internal override void InvalidateNC(IntPtr handle)
        {
            Hwnd hwnd = Hwnd.ObjectFromHandle(handle);
            if (hwnd != null)
                AddExpose(hwnd, false, 0, 0, hwnd.Width, hwnd.Height);
        }

        internal override bool IsEnabled(IntPtr handle)
        {
            Hwnd hwnd = Hwnd.ObjectFromHandle(handle);
            return (hwnd != null ? hwnd.Enabled : false);
        }

        internal override bool IsVisible(IntPtr handle)
        {
            Hwnd hwnd = Hwnd.ObjectFromHandle(handle);
            return (hwnd != null ? hwnd.visible : false);
        }

        internal override void KillTimer(Timer timer)
        {
            lock (timerLock)
            {
                TimerEvent eventPrev = null;
                TimerEvent eventThis = TimerList;
                while (eventThis != null)
                {
                    TimerEvent eventNext = eventThis.Next;
                    if (eventThis.timer == timer)
                    {
                        if (eventPrev != null)
                            eventPrev.Next = eventNext;
                        else
                            TimerList = eventNext;

                        timer.Dispose();
                        break;
                    }
                    eventPrev = eventThis;
                    eventThis = eventNext;
                }
            }
        }

        internal override void OverrideCursor(IntPtr cursor)
        {
        }

        internal override PaintEventArgs PaintEventStart(ref Message msg, IntPtr handle, bool client)
        {
            Hwnd hwnd = Hwnd.ObjectFromHandle(msg.HWnd);
            Hwnd paint_hwnd = (msg.HWnd == handle ? hwnd : Hwnd.ObjectFromHandle(handle));

            if (paint_hwnd == null)
                return null;

            if (Caret.Visible == 1)
            {
                Caret.Paused = true;
                HideCaret();
            }

            Graphics dc;
            PaintEventArgs paint_event;
            if (client)
            {
                dc = Graphics.FromHwnd(paint_hwnd.ClientWindow);

                Region clip_region = new Region();
                clip_region.MakeEmpty();

                foreach (Rectangle r in hwnd.ClipRectangles)
                {
                    /* Expand the region slightly.
                     * See bug 464464.
                     */
                    Rectangle r2 = Rectangle.FromLTRB(r.Left, r.Top, r.Right, r.Bottom + 1);
                    clip_region.Union(r2);
                }

                if (hwnd.UserClip != null)
                    clip_region.Intersect(hwnd.UserClip);

                // FIXME: Clip region is hosed
                dc.Clip = clip_region;
                paint_event = new PaintEventArgs(dc, hwnd.Invalid);
                hwnd.expose_pending = false;
                hwnd.ClearInvalidArea();
            }
            else
            {
                dc = Graphics.FromHwnd(paint_hwnd.FrameWindow);

                if (!hwnd.NCInvalid.IsEmpty)
                {
                    // FIXME: Clip region is hosed
                    dc.SetClip(hwnd.NCInvalid);
                    paint_event = new PaintEventArgs(dc, hwnd.NCInvalid);
                }
                else
                    paint_event = new PaintEventArgs(dc, new Rectangle(0, 0, hwnd.Width, hwnd.Height));

                hwnd.nc_expose_pending = false;
                hwnd.ClearNcInvalidArea();
            }

            hwnd.drawing_stack.Push(paint_event);
            hwnd.drawing_stack.Push(dc);
            return paint_event;
        }

        internal override void PaintEventEnd(ref Message msg, IntPtr handle, bool client)
        {
            Hwnd hwnd = Hwnd.ObjectFromHandle(handle);
            if (hwnd != null)
            {
                // FIXME: Pop is causing invalid stack ops sometimes; race condition?
                try
                {
                    Graphics dc = (Graphics)hwnd.drawing_stack.Pop();
                    if (dc != null)
                        dc.Dispose();

                    PaintEventArgs pea = (PaintEventArgs)hwnd.drawing_stack.Pop();
                    if (pea != null)
                    {
                        pea.SetGraphics(null);
                        pea.Dispose();
                    }
                }
                catch { }
            }

            if (Caret.Visible == 1)
            {
                ShowCaret();
                Caret.Paused = false;
            }
        }

        internal override bool PeekMessage(Object queue_id, ref MSG msg, IntPtr hWnd, int wFilterMin, int wFilterMax, uint flags)
        {
            IntPtr evtRef = IntPtr.Zero;
            IntPtr target = GetEventDispatcherTarget();
            CheckTimers(DateTime.UtcNow);
            ReceiveNextEvent(0, IntPtr.Zero, 0, true, ref evtRef);
            if (evtRef != IntPtr.Zero && target != IntPtr.Zero)
            {
                SendEventToEventTarget(evtRef, target);
                ReleaseEvent(evtRef);
            }

            lock (queueLock)
            {
                for (; ; ) //forever and ever and ever...
                {
                    if (MessageQueue.Count > 0)
                    {
                        object queueobj =
                            (flags == (uint)PeekMessageFlags.PM_REMOVE ?
                            MessageQueue.Dequeue() :
                            MessageQueue.Peek());

                        if (queueobj is MSG)
                        {
                            msg = (MSG)queueobj;
                            return true;
                        }

                        if (queueobj is AsyncMethodData)
                        {
                            AsyncMethodData method = queueobj as AsyncMethodData;
                            XplatUIDriverSupport.ExecuteClientMessage(method);
                        }
                        else
                            Console.WriteLine("Unknown queue object = " + queueobj.ToString());

                        if (flags != (uint)PeekMessageFlags.PM_REMOVE)
                            return false;
                    }
                    else if (PaintList != null)
                    {
                        PaintEvent paintEvent = PaintList;
                        if (paintEvent.hwnd.IsAlive)
                        {
                            if (paintEvent.wm_ncpaint)
                            {
                                Region rgn = paintEvent.ncpaintRegion;
                                IntPtr hrgn = rgn.GetHrgn(null); // Graphics object isn't needed

                                msg.hwnd = paintEvent.hwnd.Handle;
                                msg.message = Msg.WM_NCPAINT;
                                msg.wParam = (hrgn == IntPtr.Zero ? (IntPtr)1 : hrgn);
                                msg.refobject = rgn;

                                if (flags == (uint)PeekMessageFlags.PM_REMOVE)
                                {
                                    paintEvent.wm_ncpaint = false; //done
                                    if (!paintEvent.wm_paint)
                                        PaintList = paintEvent.Next;
                                }

                                return true;
                            }

                            if (paintEvent.wm_paint)
                            {
                                msg.hwnd = paintEvent.hwnd.Handle;
                                msg.message = Msg.WM_PAINT;

                                if (flags == (uint)PeekMessageFlags.PM_REMOVE)
                                    PaintList = paintEvent.Next;

                                return true;
                            }
                        }

                        PaintList = paintEvent.Next; //ignore and remove
                    }
                    else
                        return false;
                }
            }
        }

        internal override bool PostMessage(IntPtr hwnd, Msg message, IntPtr wParam, IntPtr lParam)
        {
            MSG msg = new MSG();
            msg.hwnd = hwnd;
            msg.message = message;
            msg.wParam = wParam;
            msg.lParam = lParam;
            EnqueueMessage(msg);
            return true;
        }

        internal override void PostQuitMessage(int exitCode)
        {
            PostMessage(FosterParent, Msg.WM_QUIT, IntPtr.Zero, IntPtr.Zero);
        }

        internal override void RequestAdditionalWM_NCMessages(IntPtr hwnd, bool hover, bool leave)
        {
        }

        internal override void RequestNCRecalc(IntPtr handle)
        {
            Hwnd hwnd = Hwnd.ObjectFromHandle(handle);
            if (hwnd == null)
                return;

            PerformNCCalc(hwnd);
            SendMessage(handle, Msg.WM_WINDOWPOSCHANGED, IntPtr.Zero, IntPtr.Zero);
            InvalidateNC(handle);
        }

        [MonoTODO]
        internal override void ResetMouseHover(IntPtr handle)
        {
            throw new NotImplementedException();
        }

        internal override void ScreenToClient(IntPtr handle, ref int x, ref int y)
        {
            Hwnd hwnd = Hwnd.ObjectFromHandle(handle);
            if (hwnd != null)
            {
                Point point = ConvertScreenPointToClient(hwnd.ClientWindow, new Point(x, y));
                x = point.X;
                y = point.Y;
            }
        }

        internal override void ScreenToMenu(IntPtr handle, ref int x, ref int y)
        {
            Hwnd hwnd = Hwnd.ObjectFromHandle(handle);
            if (hwnd != null)
            {
                Point point = ConvertScreenPointToClient(hwnd.FrameWindow, new Point(x, y));
                x = point.X;
                y = point.Y;
            }
        }

        internal override void ScrollWindow(IntPtr handle, Rectangle area, int XAmount, int YAmount, bool clear)
        {
            /*
             * This used to use a HIViewScrollRect but this causes issues with the fact that we dont coalesce
             * updates properly with our short-circuiting of the window manager.  For now we'll do a less
             * efficient invalidation of the entire handle which appears to fix the problem
             * see bug #381084
             */
            Hwnd hwnd = Hwnd.ObjectFromHandle(handle);
            if (hwnd != null)
                Invalidate(handle, new Rectangle(0, 0, hwnd.Width, hwnd.Height), false);
        }


        internal override void ScrollWindow(IntPtr handle, int XAmount, int YAmount, bool clear)
        {
            Hwnd hwnd = Hwnd.ObjectFromHandle(handle);
            if (hwnd != null)
                Invalidate(handle, new Rectangle(0, 0, hwnd.Width, hwnd.Height), false);
        }

        [MonoTODO]
        internal override void SendAsyncMethod(AsyncMethodData method)
        {
            // Fake async
            lock (queueLock)
            {
                MessageQueue.Enqueue(method);
            }
        }

        [MonoTODO]
        internal override IntPtr SendMessage(IntPtr hwnd, Msg message, IntPtr wParam, IntPtr lParam)
        {
            return NativeWindow.WndProc(hwnd, message, wParam, lParam);
        }

        internal override int SendInput(IntPtr hwnd, Queue keys)
        {
            return 0;
        }

        internal override void SetCaretPos(IntPtr hwnd, int x, int y)
        {
            if (hwnd != IntPtr.Zero && hwnd == Caret.Hwnd)
            {
                Caret.X = x;
                Caret.Y = y;
                ClientToScreen(hwnd, ref x, ref y);
                SizeWindow(new Rectangle(x, y, Caret.Width, Caret.Height), CaretWindow);
                Caret.Timer.Stop();
                HideCaret();
                if (Caret.Visible == 1)
                {
                    ShowCaret();
                    Caret.Timer.Start();
                }
            }
        }

        internal override void SetClipRegion(IntPtr hwnd, Region region)
        {
            throw new NotImplementedException();
        }

        internal override void SetCursor(IntPtr window, IntPtr cursor)
        {
            Hwnd hwnd = Hwnd.ObjectFromHandle(window);
            if (hwnd != null && hwnd.Cursor != cursor)
            {
                hwnd.Cursor = cursor;
                CARBON.Cursor.SetCursor(cursor);
            }
        }

        internal override void SetCursorPos(IntPtr handle, int x, int y)
        {
            CGDisplayMoveCursorToPoint(CGMainDisplayID(), new CARBON.CGPoint(x, y));
        }

        internal override void SetFocus(IntPtr handle)
        {
            if (FocusWindow != IntPtr.Zero)
                PostMessage(FocusWindow, Msg.WM_KILLFOCUS, handle, IntPtr.Zero);

            PostMessage(handle, Msg.WM_SETFOCUS, FocusWindow, IntPtr.Zero);
            FocusWindow = handle;
        }

        internal override void SetIcon(IntPtr handle, Icon icon)
        {
            Hwnd hwnd = Hwnd.ObjectFromHandle(handle);
            if (hwnd != null && hwnd.IsNative)
            {
                if (icon == null)
                    RestoreApplicationDockTileImage();
                else
                {
                    int size;
                    IntPtr[] data;
                    int index;

                    Bitmap bitmap = new Bitmap(128, 128);
                    using (Graphics g = Graphics.FromImage(bitmap))
                    {
                        g.DrawImage(icon.ToBitmap(), 0, 0, 128, 128);
                    }
                    index = 0;
                    size = bitmap.Width * bitmap.Height;
                    data = new IntPtr[size];

                    for (int y = 0; y < bitmap.Height; y++)
                    {
                        for (int x = 0; x < bitmap.Width; x++)
                        {
                            int pixel = bitmap.GetPixel(x, y).ToArgb();
                            if (BitConverter.IsLittleEndian)
                            {
                                byte a = (byte)((pixel >> 24) & 0xFF);
                                byte r = (byte)((pixel >> 16) & 0xFF);
                                byte g = (byte)((pixel >> 8) & 0xFF);
                                byte b = (byte)(pixel & 0xFF);
                                data[index++] = (IntPtr)(a + (r << 8) + (g << 16) + (b << 24));
                            }
                            else
                                data[index++] = (IntPtr)pixel;
                        }
                    }
                    bitmap.Dispose();

                    IntPtr provider = CGDataProviderCreateWithData(IntPtr.Zero, data, size * 4, IntPtr.Zero);
                    IntPtr image = CGImageCreate(128, 128, 8, 32, 4 * 128, CGColorSpaceCreateDeviceRGB(), 4, provider, IntPtr.Zero, 0, 0);
                    SetApplicationDockTileImage(image);
                }
            }
        }


        internal override void SetModal(IntPtr handle, bool Modal)
        {
            Hwnd hwnd = Hwnd.ObjectFromHandle(handle);
            if (hwnd != null)
            {
                IntPtr window = HIViewGetWindow(hwnd.FrameWindow);
                if (Modal)
                    BeginAppModalStateForWindow(window);
                else
                    EndAppModalStateForWindow(window);
            }
            return;
        }

        internal override IntPtr SetParent(IntPtr handle, IntPtr parent)
        {
            Hwnd hwnd = Hwnd.ObjectFromHandle(handle);
            if (hwnd != null)
            {
                if (HIViewGetSuperview(hwnd.FrameWindow) != IntPtr.Zero)
                    HIViewRemoveFromSuperview(hwnd.FrameWindow);

                hwnd.Parent = Hwnd.ObjectFromHandle(parent);
                if (hwnd.Parent != null)
                    HIViewAddSubview(hwnd.Parent.ClientWindow, hwnd.FrameWindow);
                else
                {
                    IntPtr parentHandle = IntPtr.Zero;
                    HIViewFindByID(HIViewGetRoot(FosterParent), new CARBON.HIViewID(CARBON.EventHandler.kEventClassWindow, 1), ref parentHandle);
                    HIViewAddSubview(parentHandle, hwnd.FrameWindow);
                }

                HIViewPlaceInSuperviewAt(hwnd.FrameWindow, hwnd.X, hwnd.Y);
                HIViewAddSubview(hwnd.FrameWindow, hwnd.ClientWindow);
                HIViewPlaceInSuperviewAt(hwnd.ClientWindow, hwnd.ClientRect.X, hwnd.ClientRect.Y);
            }
            return IntPtr.Zero;
        }

        internal override void SetTimer(Timer timer)
        {
            lock (timerLock)
            {
                TimerList = new TimerEvent(TimerList, timer); //new kid goes to the front of the line
            }
        }

        internal override bool SetTopmost(IntPtr hWnd, bool Enabled)
        {
            HIViewSetZOrder(hWnd, 1, IntPtr.Zero);
            return true;
        }

        internal override bool SetOwner(IntPtr hWnd, IntPtr hWndOwner)
        {
            // TODO: Set window owner.
            return true;
        }

        internal override bool SetVisible(IntPtr handle, bool visible, bool activate)
        {
            Hwnd hwnd = Hwnd.ObjectFromHandle(handle);
            if (hwnd != null)
            {
                if (hwnd.IsNative)
                {
                    if (visible)
                        ShowWindow(hwnd.NativeHandle);
                    else
                        HideWindow(hwnd.NativeHandle);
                }

                if (visible)
                    SendMessage(handle, Msg.WM_WINDOWPOSCHANGED, IntPtr.Zero, IntPtr.Zero);

                HIViewSetVisible(hwnd.FrameWindow, visible);
                HIViewSetVisible(hwnd.ClientWindow, visible);

                hwnd.visible = visible;
                hwnd.Mapped = true;
            }
            return true;
        }

        internal override void SetAllowDrop(IntPtr handle, bool value)
        {
            // Like X11 we allow drop on al windows and filter in our handler
        }

        internal override DragDropEffects StartDrag(IntPtr handle, object data, DragDropEffects allowed_effects)
        {
            Hwnd hwnd = Hwnd.ObjectFromHandle(handle);
            if (hwnd == null)
                throw new ArgumentException("Attempt to begin drag from invalid window handle (" + handle.ToInt32() + ").");

            return Dnd.StartDrag(hwnd.ClientWindow, data, allowed_effects);
        }

        internal override void SetBorderStyle(IntPtr handle, FormBorderStyle border_style)
        {
            Form form = Control.FromHandle(handle) as Form;
            if (form != null && form.window_manager == null && (border_style == FormBorderStyle.FixedToolWindow ||
                border_style == FormBorderStyle.SizableToolWindow))
            {
                form.window_manager = new ToolWindowManager(form);
            }

            RequestNCRecalc(handle);
        }

        internal override void SetMenu(IntPtr handle, Menu menu)
        {
            Hwnd hwnd = Hwnd.ObjectFromHandle(handle);
            if (hwnd != null)
                hwnd.menu = menu;

            RequestNCRecalc(handle);
        }

        internal override void SetWindowMinMax(IntPtr handle, Rectangle maximized, Size min, Size max)
        {
        }

        internal override void SetWindowPos(IntPtr handle, int x, int y, int width, int height)
        {
            Hwnd hwnd = Hwnd.ObjectFromHandle(handle);
            if (hwnd == null)
                return;

            // Win32 automatically changes negative width/height to 0.
            if (width < 0)
                width = 0;
            if (height < 0)
                height = 0;

            // X requires a sanity check for width & height; otherwise it dies
            if (hwnd.zero_sized && width > 0 && height > 0)
            {
                if (hwnd.visible)
                    HIViewSetVisible(hwnd.FrameWindow, true);

                hwnd.zero_sized = false;
            }

            if ((width < 1) || (height < 1))
            {
                hwnd.zero_sized = true;
                HIViewSetVisible(hwnd.FrameWindow, false);
            }

            // Save a server roundtrip (and prevent a feedback loop)
            if ((hwnd.X == x) && (hwnd.Y == y) && (hwnd.Width == width) && (hwnd.Height == height))
                return;

            if (!hwnd.zero_sized)
            {
                hwnd.X = x;
                hwnd.Y = y;
                hwnd.Width = width;
                hwnd.Height = height;
                SendMessage(hwnd.ClientWindow, Msg.WM_WINDOWPOSCHANGED, IntPtr.Zero, IntPtr.Zero);

                Control ctrl = Control.FromHandle(handle);
                CreateParams cp = ctrl.GetCreateParams();
                Size TranslatedSize = TranslateWindowSizeToQuartzWindowSize(cp, new Size(width, height));
                CARBON.Rect rect = new CARBON.Rect();

                if (hwnd.IsNative)
                {
                    if (StyleSet(cp.Style, WindowStyles.WS_POPUP))
                        SetRect(ref rect, (short)x, (short)y, (short)(x + TranslatedSize.Width), (short)(y + TranslatedSize.Height));
                    else
                        SetRect(ref rect, (short)x, (short)(y + MenuBarHeight), (short)(x + TranslatedSize.Width), (short)(y + MenuBarHeight + TranslatedSize.Height));

                    SetWindowBounds(hwnd.NativeHandle, 33, ref rect);
                    CARBON.HIRect frame_rect = new CARBON.HIRect(0, 0, TranslatedSize.Width, TranslatedSize.Height);
                    HIViewSetFrame(hwnd.FrameWindow, ref frame_rect);
                    SetCaretPos(Caret.Hwnd, Caret.X, Caret.Y);
                }
                else
                {
                    CARBON.HIRect frame_rect = new CARBON.HIRect(x, y, TranslatedSize.Width, TranslatedSize.Height);
                    HIViewSetFrame(hwnd.FrameWindow, ref frame_rect);
                }
                PerformNCCalc(hwnd);
            }

            hwnd.X = x;
            hwnd.Y = y;
            hwnd.Width = width;
            hwnd.Height = height;
        }

        internal override void SetWindowState(IntPtr handle, FormWindowState state)
        {
            IntPtr window = HIViewGetWindow(handle);

            switch (state)
            {
                case FormWindowState.Minimized:
                    CollapseWindow(window, true);
                    break;

                case FormWindowState.Normal:
                    ZoomWindow(window, 7, false);
                    break;

                case FormWindowState.Maximized:
                    Hwnd hwnd = Hwnd.ObjectFromHandle(handle);
                    if (hwnd != null)
                    {
                        Form form = Control.FromHandle(hwnd.Handle) as Form;
                        if (form != null && form.FormBorderStyle == FormBorderStyle.None)
                        {
                            CARBON.HIRect bounds = CGDisplayBounds(CGMainDisplayID());
                            if (hwnd.IsNative)
                            {
                                CARBON.Rect rect = new CARBON.Rect();
                                SetRect(ref rect, (short)0, (short)0, (short)bounds.size.width, (short)bounds.size.height);
                                SetWindowBounds(hwnd.NativeHandle, 33, ref rect);
                            }
                            HIViewSetFrame(hwnd.FrameWindow, ref bounds);
                        }
                        else
                            ZoomWindow(window, 8, false);
                    }
                    break;
            }
        }

        internal override void SetWindowStyle(IntPtr handle, CreateParams cp)
        {
            Hwnd hwnd = Hwnd.ObjectFromHandle(handle);
            if (hwnd != null)
            {
                SetHwndStyles(hwnd, cp);

                if (hwnd.IsNative)
                {
                    CARBON.WindowAttributes attributes = CARBON.WindowAttributes.kWindowCompositingAttribute | CARBON.WindowAttributes.kWindowStandardHandlerAttribute;
                    if ((cp.Style & ((int)WindowStyles.WS_MINIMIZEBOX)) != 0)
                        attributes |= CARBON.WindowAttributes.kWindowCollapseBoxAttribute;

                    if ((cp.Style & ((int)WindowStyles.WS_MAXIMIZEBOX)) != 0)
                        attributes |= CARBON.WindowAttributes.kWindowResizableAttribute | CARBON.WindowAttributes.kWindowHorizontalZoomAttribute | CARBON.WindowAttributes.kWindowVerticalZoomAttribute;

                    if ((cp.Style & ((int)WindowStyles.WS_SYSMENU)) != 0)
                        attributes |= CARBON.WindowAttributes.kWindowCloseBoxAttribute;

                    if ((cp.ExStyle & ((int)WindowExStyles.WS_EX_TOOLWINDOW)) != 0)
                        attributes = CARBON.WindowAttributes.kWindowStandardHandlerAttribute | CARBON.WindowAttributes.kWindowCompositingAttribute;

                    attributes |= CARBON.WindowAttributes.kWindowLiveResizeAttribute;

                    CARBON.WindowAttributes outAttributes = CARBON.WindowAttributes.kWindowNoAttributes;
                    GetWindowAttributes(hwnd.NativeHandle, ref outAttributes);
                    ChangeWindowAttributes(hwnd.NativeHandle, attributes, outAttributes);
                }
            }
        }

        internal override void SetWindowTransparency(IntPtr handle, double transparency, Color key)
        {
        }

        internal override double GetWindowTransparency(IntPtr handle)
        {
            return 1.0;
        }

        internal override TransparencySupport SupportsTransparency()
        {
            return TransparencySupport.None;
        }

        internal override bool SetZOrder(IntPtr handle, IntPtr after_handle, bool Top, bool Bottom)
        {
            Hwnd hwnd = Hwnd.ObjectFromHandle(handle);
            if (hwnd != null)
            {
                if (Top)
                {
                    HIViewSetZOrder(hwnd.FrameWindow, 2, IntPtr.Zero);
                    return true;
                }

                if (Bottom)
                {
                    HIViewSetZOrder(hwnd.FrameWindow, 1, IntPtr.Zero);
                    return true;
                }

                Hwnd after_hwnd = Hwnd.ObjectFromHandle(after_handle);
                HIViewSetZOrder(hwnd.FrameWindow, 2, (after_handle == IntPtr.Zero ? IntPtr.Zero : after_hwnd.FrameWindow));
            }
            return false;
        }

        internal override void ShowCursor(bool show)
        {
            if (show)
                CGDisplayShowCursor(CGMainDisplayID());
            else
                CGDisplayHideCursor(CGMainDisplayID());
        }

        internal override object StartLoop(Thread thread)
        {
            return new object();
        }

        [MonoTODO]
        internal override bool SystrayAdd(IntPtr hwnd, string tip, Icon icon, out ToolTip tt)
        {
            throw new NotImplementedException();
        }

        [MonoTODO]
        internal override bool SystrayChange(IntPtr hwnd, string tip, Icon icon, ref ToolTip tt)
        {
            throw new NotImplementedException();
        }

        [MonoTODO]
        internal override void SystrayRemove(IntPtr hwnd, ref ToolTip tt)
        {
            throw new NotImplementedException();
        }

#if NET_2_0
        [MonoTODO]
        internal override void SystrayBalloon(IntPtr hwnd, int timeout, string title, string text, ToolTipIcon icon)
        {
            throw new NotImplementedException();
        }
#endif

        internal override bool Text(IntPtr handle, string text)
        {
            Hwnd hwnd = Hwnd.ObjectFromHandle(handle);
            if (hwnd == null)
                return false;

            if (hwnd.IsNative)
                SetWindowTitleWithCFString(hwnd.NativeHandle, __CFStringMakeConstantString(text));

            SetControlTitleWithCFString(hwnd.FrameWindow, __CFStringMakeConstantString(text));
            SetControlTitleWithCFString(hwnd.ClientWindow, __CFStringMakeConstantString(text));
            return true;
        }

        internal override void UpdateWindow(IntPtr handle)
        {
            Hwnd hwndUpdate = Hwnd.ObjectFromHandle(handle);
            if (hwndUpdate != null)
            {
                if (!hwndUpdate.visible || !HIViewIsVisible(handle))
                    return;

                lock (queueLock)
                {
                    while (PaintList != null)
                    {
                        PaintEvent paintEvent = PaintList;

                        if (paintEvent.hwnd.IsAlive)
                        {
                            if (paintEvent.wm_ncpaint)
                            {
                                Region rgn = paintEvent.ncpaintRegion;
                                IntPtr hrgn = rgn.GetHrgn(null); // Graphics object isn't needed
                                SendMessage(paintEvent.hwnd.Handle, Msg.WM_NCPAINT, (hrgn == IntPtr.Zero ? (IntPtr)1 : hrgn), IntPtr.Zero);
                            }

                            if (paintEvent.wm_paint)
                                SendMessage(paintEvent.hwnd.Handle, Msg.WM_PAINT, IntPtr.Zero, IntPtr.Zero);
                        }

                        PaintList = paintEvent.Next;

                        if (paintEvent.hwnd == hwndUpdate)
                            break;
                    }
                }
            }
        }

        internal override bool TranslateMessage(ref MSG msg)
        {
            return CARBON.EventHandler.TranslateMessage(ref msg);
        }

        #region Reversible regions

        /*
		 * Quartz has no concept of XOR drawing due to its compositing nature
		 * We fake this by mapping a overlay window on the first draw and mapping it on the second.
		 * This has some issues with it because its POSSIBLE for ControlPaint.DrawReversible* to actually
		 * reverse two regions at once.  We dont do this in MWF, but this behaviour woudn't work.
		 * We could in theory cache the Rectangle/Color combination to handle this behaviour.
		 *
		 * PROBLEMS: This has some flicker / banding
		 */
        internal void SizeWindow(Rectangle rect, IntPtr window)
        {
            CARBON.Rect qrect = new CARBON.Rect();
            SetRect(ref qrect, (short)rect.Left, (short)rect.Top, (short)rect.Right, (short)rect.Bottom);
            SetWindowBounds(window, 33, ref qrect);
        }

        internal override void DrawReversibleLine(Point start, Point end, Color backColor)
        {
            int x, y, width, height;
            if (start.X < end.X)
            {
                x = start.X;
                width = end.X - x + 1;
            }
            else
            {
                x = end.X;
                width = start.X - x + 1;
            }
            if (start.Y < end.Y)
            {
                y = start.Y;
                height = end.Y - y + 1;
            }
            else
            {
                y = end.Y;
                height = start.Y - y + 1;
            }
            Rectangle view_rect = new Rectangle(x, y, width, height);
            if (view_rect != ReverseRect)
            {
                SizeWindow(view_rect, ReverseWindow);
                Graphics g = Graphics.FromHwnd(HIViewGetRoot(ReverseWindow));

                if (ReverseRect != Rectangle.Empty)
                    g.DrawLine(ThemeEngine.Current.ResPool.GetPen(Color.White), ReversePt1, ReversePt2);

                ReversePt1 = new Point(start.X - x, start.Y - y);
                ReversePt2 = new Point(end.X - x, end.Y - y);
                g.DrawLine(ThemeEngine.Current.ResPool.GetPen(Color.Black), ReversePt1, ReversePt2);

                g.Dispose();
                ShowWindow(ReverseWindow);
                ReverseRect = view_rect;
            }
        }

        internal override void FillReversibleRectangle(Rectangle rectangle, Color backColor)
        {
            //			throw new NotImplementedException();
        }

        internal override void DrawReversibleFrame(Rectangle rectangle, Color backColor, FrameStyle style)
        {
            if (rectangle != ReverseRect)
            {
                SizeWindow(rectangle, ReverseWindow);
                Graphics g = Graphics.FromHwnd(HIViewGetRoot(ReverseWindow));

                if (ReverseRect != Rectangle.Empty)
                    g.DrawRectangle(ThemeEngine.Current.ResPool.GetPen(Color.White), 0, 0, ReverseRect.Width - 1, ReverseRect.Height - 1);

                g.DrawRectangle(ThemeEngine.Current.ResPool.GetPen(backColor), 0, 0, rectangle.Width - 1, rectangle.Height - 1);

                g.Dispose();
                ShowWindow(ReverseWindow);
                ReverseRect = rectangle;
            }
        }

        internal override void DrawReversibleRectangle(IntPtr handle, Rectangle rect, int line_width, bool bReverse)
        {
            if (bReverse)
            {
                int x = rect.X;
                int y = rect.Y;
                ClientToScreen(handle, ref x, ref y);
                Rectangle view_rect = new Rectangle(x, y, rect.Width, rect.Height);
                if (view_rect != ReverseRect)
                {
                    SizeWindow(view_rect, ReverseWindow);

                    Graphics g = Graphics.FromHwnd(HIViewGetRoot(ReverseWindow));
                    Rectangle draw_rect = new Rectangle(0, 0, rect.Width - 1, rect.Height - 1);

                    for (int i = 0; i < line_width; i++)
                    {
                        g.DrawRectangle(ThemeEngine.Current.ResPool.GetPen(Color.Black), draw_rect);
                        draw_rect.X += 1;
                        draw_rect.Y += 1;
                        draw_rect.Width -= 2;
                        draw_rect.Height -= 2;
                    }

                    g.Dispose();
                    ShowWindow(ReverseWindow);
                    ReverseRect = view_rect;
                }
            }
        }

        #endregion

        internal override SizeF GetAutoScaleSize(Font font)
        {
            Bitmap b = new Bitmap(1, 1);
            Graphics g = Graphics.FromImage(b);

            string magic_string = "The quick brown fox jumped over the lazy dog.";
            double magic_number = 44.549996948242189;
            float width = (float)(g.MeasureString(magic_string, font).Width / magic_number);
            SizeF siz = new SizeF(width, font.Height);

            g.Dispose();
            b.Dispose();
            return siz;
        }

        internal override Point MousePosition
        {
            get { return mouse_position; }
        }

        #endregion

        #region System information

        internal override int KeyboardSpeed { get { throw new NotImplementedException(); } }
        internal override int KeyboardDelay { get { throw new NotImplementedException(); } }

        internal override int CaptionHeight
        {
            get { return 19; }
        }

        internal override Size CursorSize { get { throw new NotImplementedException(); } }
        internal override bool DragFullWindows { get { throw new NotImplementedException(); } }
        internal override Size DragSize
        {
            get { return new Size(4, 4); }
        }

        internal override Size FrameBorderSize
        {
            get { return new Size(2, 2); }
        }

        internal override Size IconSize { get { throw new NotImplementedException(); } }
        internal override Size MaxWindowTrackSize { get { throw new NotImplementedException(); } }
        internal override bool MenuAccessKeysUnderlined
        {
            get { return false; }
        }
        internal override Size MinimizedWindowSpacingSize { get { throw new NotImplementedException(); } }

        internal override Size MinimumWindowSize
        {
            get { return new Size(110, 22); }
        }

        internal override Keys ModifierKeys
        {
            get { return KeyboardHandler.ModifierKeys; }
        }
        internal override Size SmallIconSize { get { throw new NotImplementedException(); } }
        internal override int MouseButtonCount { get { throw new NotImplementedException(); } }
        internal override bool MouseButtonsSwapped { get { throw new NotImplementedException(); } }
        internal override bool MouseWheelPresent { get { throw new NotImplementedException(); } }

        internal override MouseButtons MouseButtons
        {
            get { return MouseState; }
        }

        internal override Rectangle VirtualScreen
        {
            get { return WorkingArea; }
        }

        internal override Rectangle WorkingArea
        {
            get
            {
                CARBON.HIRect bounds = CGDisplayBounds(CGMainDisplayID());
                return new Rectangle((int)bounds.origin.x, (int)bounds.origin.y, (int)bounds.size.width, (int)bounds.size.height);
            }
        }
        internal override bool ThemesEnabled
        {
            get { return XplatUICarbon.themes_enabled; }
        }


        #endregion

        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        private static extern int HIViewConvertPoint(ref CARBON.CGPoint point, IntPtr pView, IntPtr cView);
        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        private static extern int HIViewChangeFeatures(IntPtr aView, ulong bitsin, ulong bitsout);
        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        private static extern int HIViewFindByID(IntPtr rootWnd, CARBON.HIViewID id, ref IntPtr outPtr);
        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        private static extern int HIGrowBoxViewSetTransparent(IntPtr GrowBox, bool transparency);
        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        private static extern IntPtr HIViewGetRoot(IntPtr hWnd);
        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        private static extern int HIObjectCreate(IntPtr cfStr, uint what, ref IntPtr hwnd);
        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        private static extern int HIObjectRegisterSubclass(IntPtr classid, IntPtr superclassid, uint options, CARBON.EventDelegate upp, uint count, CARBON.EventTypeSpec[] list, IntPtr state, ref IntPtr cls);
        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        private static extern int HIViewPlaceInSuperviewAt(IntPtr view, float x, float y);
        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        private static extern int HIViewAddSubview(IntPtr parentHnd, IntPtr childHnd);
        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        private static extern IntPtr HIViewGetPreviousView(IntPtr aView);
        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        private static extern IntPtr HIViewGetSuperview(IntPtr aView);
        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        private static extern int HIViewRemoveFromSuperview(IntPtr aView);
        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        private static extern int HIViewSetVisible(IntPtr vHnd, bool visible);
        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        private static extern bool HIViewIsVisible(IntPtr vHnd);
        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        private static extern int HIViewGetBounds(IntPtr vHnd, ref CARBON.HIRect r);
        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        private static extern int HIViewScrollRect(IntPtr vHnd, ref CARBON.HIRect rect, float x, float y);
        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        private static extern int HIViewSetZOrder(IntPtr hWnd, int cmd, IntPtr oHnd);
        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        private static extern int HIViewNewTrackingArea(IntPtr inView, IntPtr inShape, UInt64 inID, ref IntPtr outRef);
        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        private static extern IntPtr HIViewGetWindow(IntPtr aView);
        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        private static extern int HIViewSetFrame(IntPtr view_handle, ref CARBON.HIRect bounds);
        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        internal static extern int HIViewSetNeedsDisplayInRect(IntPtr view_handle, ref CARBON.HIRect rect, bool needs_display);

        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        private static extern void SetRect(ref CARBON.Rect r, short left, short top, short right, short bottom);
        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        private static extern int ActivateWindow(IntPtr windowHnd, bool inActivate);
        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        private static extern bool IsWindowActive(IntPtr windowHnd);
        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        private static extern int SetAutomaticControlDragTrackingEnabledForWindow(IntPtr window, bool enabled);

        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        private static extern IntPtr GetEventDispatcherTarget();
        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        private static extern int SendEventToEventTarget(IntPtr evt, IntPtr target);
        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        private static extern int ReleaseEvent(IntPtr evt);
        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        private static extern int ReceiveNextEvent(uint evtCount, IntPtr evtTypes, double timeout, bool processEvt, ref IntPtr evt);

        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        private static extern bool IsWindowCollapsed(IntPtr hWnd);
        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        private static extern bool IsWindowInStandardState(IntPtr hWnd, IntPtr a, IntPtr b);
        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        private static extern void CollapseWindow(IntPtr hWnd, bool collapse);
        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        private static extern void ZoomWindow(IntPtr hWnd, short partCode, bool front);
        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        private static extern int GetWindowAttributes(IntPtr hWnd, ref CARBON.WindowAttributes outAttributes);
        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        private static extern int ChangeWindowAttributes(IntPtr hWnd, CARBON.WindowAttributes inAttributes, CARBON.WindowAttributes outAttributes);
        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        internal static extern int GetGlobalMouse(ref CARBON.QDPoint outData);

        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        private static extern int BeginAppModalStateForWindow(IntPtr window);
        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        private static extern int EndAppModalStateForWindow(IntPtr window);
        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        private static extern int CreateNewWindow(CARBON.WindowClass klass, CARBON.WindowAttributes attributes, ref CARBON.Rect r, ref IntPtr window);
        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        private static extern int DisposeWindow(IntPtr hWnd);
        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        internal static extern int ShowWindow(IntPtr hWnd);
        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        internal static extern int HideWindow(IntPtr hWnd);
        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        internal static extern bool IsWindowVisible(IntPtr hWnd);
        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        private static extern int SetWindowBounds(IntPtr hWnd, uint reg, ref CARBON.Rect rect);
        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        private static extern int GetWindowBounds(IntPtr hWnd, uint reg, ref CARBON.Rect rect);

        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        private static extern int SetControlTitleWithCFString(IntPtr hWnd, IntPtr titleCFStr);
        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        private static extern int SetWindowTitleWithCFString(IntPtr hWnd, IntPtr titleCFStr);
        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        internal static extern IntPtr __CFStringMakeConstantString(string cString);

        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        internal static extern int CFRelease(IntPtr hWnd);
        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        private static extern short GetMBarHeight();

        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        private static extern void AlertSoundPlay();

        #region Cursor imports

        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        private static extern CARBON.HIRect CGDisplayBounds(IntPtr displayID);
        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        private static extern IntPtr CGMainDisplayID();
        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        private static extern void CGDisplayShowCursor(IntPtr display);
        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        private static extern void CGDisplayHideCursor(IntPtr display);
        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        private static extern void CGDisplayMoveCursorToPoint(IntPtr display, CARBON.CGPoint point);

        #endregion

        #region Process imports

        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        private static extern int GetCurrentProcess(ref CARBON.ProcessSerialNumber psn);
        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        private static extern int TransformProcessType(ref CARBON.ProcessSerialNumber psn, uint type);
        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        private static extern int SetFrontProcess(ref CARBON.ProcessSerialNumber psn);

        #endregion

        #region Dock tile imports

        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        private static extern IntPtr CGColorSpaceCreateDeviceRGB();
        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        private static extern IntPtr CGDataProviderCreateWithData(IntPtr info, IntPtr[] data, int size, IntPtr releasefunc);
        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        private static extern IntPtr CGImageCreate(int width, int height, int bitsPerComponent, int bitsPerPixel, int bytesPerRow, IntPtr colorspace, uint bitmapInfo, IntPtr provider, IntPtr decode, int shouldInterpolate, int intent);
        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        private static extern void SetApplicationDockTileImage(IntPtr imageRef);
        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        private static extern void RestoreApplicationDockTileImage();

        #endregion
    }
}
