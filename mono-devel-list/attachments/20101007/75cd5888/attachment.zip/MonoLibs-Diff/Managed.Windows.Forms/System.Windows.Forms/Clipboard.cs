// Permission is hereby granted, free of charge, to any person obtaining
// a copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to
// permit persons to whom the Software is furnished to do so, subject to
// the following conditions:
// 
// The above copyright notice and this permission notice shall be
// included in all copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
// NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
// LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
// OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
// WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
//
// Authors:
//  Ralph Leckett <rleckett@gmail.com>
//

using System;
using System.Collections.Specialized;
using System.Drawing;
using System.IO;

namespace System.Windows.Forms
{
    public sealed class Clipboard
    {
        internal static XplatClipboard _Clipboard; //set in XplatUI

        public static void Clear()
        {
            _Clipboard.Clear();
        }

        public static bool ContainsAudio()
        {
            return _Clipboard.ContainsAudio();
        }

        public static bool ContainsData(string format)
        {
            return _Clipboard.ContainsData(format);
        }

        public static bool ContainsFileDropList()
        {
            return _Clipboard.ContainsFileDropList();
        }

        public static bool ContainsImage()
        {
            return _Clipboard.ContainsImage();
        }

        public static bool ContainsText()
        {
            return _Clipboard.ContainsText();
        }
#if NET_2_0
        public static bool ContainsText(TextDataFormat format)
        {
            return _Clipboard.ContainsText(format);
        }
#endif
        public static Stream GetAudioStream()
        {
            return _Clipboard.GetAudioStream();
        }

        public static object GetData(string format)
        {
            return _Clipboard.GetData(format);
        }

        public static IDataObject GetDataObject()
        {
            return _Clipboard.GetDataObject();
        }

        public static StringCollection GetFileDropList()
        {
            return _Clipboard.GetFileDropList();
        }

        public static Image GetImage()
        {
            return _Clipboard.GetImage();
        }

        public static string GetText()
        {
            return _Clipboard.GetText();
        }
#if NET_2_0
        public static string GetText(TextDataFormat format)
        {
            return _Clipboard.GetText(format);
        }
#endif
        public static void SetAudio(byte[] audioBytes)
        {
            _Clipboard.SetAudio(audioBytes);
        }

        public static void SetAudio(Stream audioStream)
        {
            _Clipboard.SetAudio(audioStream);
        }

        public static void SetData(string format, object data)
        {
            _Clipboard.SetData(format, data);
        }

        public static void SetDataObject(IDataObject dataObject)
        {
            _Clipboard.SetDataObject(dataObject);
        }

        public static void SetDataObject(IDataObject dataObject, bool copy)
        {
            _Clipboard.SetDataObject(dataObject, copy);
        }

        public static void SetDataObject(IDataObject dataObject, bool copy, int retryTimes, int retryDelay)
        {
            _Clipboard.SetDataObject(dataObject, copy, retryTimes, retryDelay);
        }

        public static void SetFileDropList(StringCollection filePaths)
        {
            _Clipboard.SetFileDropList(filePaths);
        }

        public static void SetImage(Image image)
        {
            _Clipboard.SetImage(image);
        }

        public static void SetText(string text)
        {
            _Clipboard.SetText(text);
        }
#if NET_2_0
        public static void SetText(string text, TextDataFormat format)
        {
            _Clipboard.SetText(text, format);
        }
#endif
        internal static int GetID(string format)
        {
            return _Clipboard.GetID(format);
        }
    }
}
