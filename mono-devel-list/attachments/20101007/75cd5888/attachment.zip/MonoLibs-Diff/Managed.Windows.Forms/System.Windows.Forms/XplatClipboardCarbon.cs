﻿// Permission is hereby granted, free of charge, to any person obtaining
// a copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to
// permit persons to whom the Software is furnished to do so, subject to
// the following conditions:
// 
// The above copyright notice and this permission notice shall be
// included in all copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
// NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
// LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
// OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
// WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
//
// Authors:
//  Ralph Leckett <rleckett@gmail.com>
//

using System;
using System.Collections.Specialized;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Runtime.InteropServices;

namespace System.Windows.Forms
{
    internal class XplatClipboardCarbon : XplatClipboard
    {
        private const string FLAVOR_TEXT8 = "public.utf8-plain-text";
        private const string FLAVOR_TEXT16 = "public.utf16-plain-text";
        private const string FLAVOR_RTF = "public.rtf";
        private const string FLAVOR_TIFF = "public.tiff";
        private const string FLAVOR_DROP = "public.file-url";

        private class Mask
        {
            public bool all = false;
            public bool text8 = false;
            public bool text16 = false;
            public bool rtf = false;
            public bool tiff = false;
            public bool drop = false;
        }

        private IntPtr _pasteboard;

        internal XplatClipboardCarbon()
        {
            int status = PasteboardCreate(
                __CFStringMakeConstantString("com.apple.pasteboard.clipboard"),
                ref _pasteboard);
            if (status != 0)
                Console.WriteLine("PasteboardCreate status = " + Status(status));
        }

        internal override void Clear()
        {
            int status = PasteboardClear(_pasteboard);
            if (status != 0)
                Console.WriteLine("PasteboardClear status = " + Status(status));
        }

        internal override bool ContainsAudio()
        {
            //TODO
            return false;
        }

        internal override bool ContainsData(string format)
        {
            Mask mask = new Mask();
            if (format == DataFormats.Text)
                mask.text8 = true;
            else if (format == DataFormats.UnicodeText)
                mask.text16 = true;
            else if (format == DataFormats.Rtf)
                mask.rtf = true;
            else if (format == DataFormats.Bitmap)
                mask.tiff = true;
            else if (format == DataFormats.FileDrop)
                mask.drop = true;
            else
                return false;
            DataObject dataObject;
            return GetMaskedDataObject(mask, false, out dataObject);
        }

        internal override bool ContainsFileDropList()
        {
            Mask mask = new Mask();
            mask.drop = true;
            DataObject dataObject;
            return GetMaskedDataObject(mask, false, out dataObject);
        }

        internal override bool ContainsImage()
        {
            Mask mask = new Mask();
            mask.tiff = true;
            DataObject dataObject;
            return GetMaskedDataObject(mask, false, out dataObject);
        }

        internal override bool ContainsText()
        {
            Mask mask = new Mask();
            mask.text8 = true;
            mask.text16 = true;
            mask.rtf = true;
            DataObject dataObject;
            return GetMaskedDataObject(mask, false, out dataObject);
        }
#if NET_2_0
        internal override bool ContainsText(TextDataFormat format)
        {
            Mask mask = new Mask();
            if (format == TextDataFormat.Text)
                mask.text8 = true;
            else if (format == TextDataFormat.UnicodeText)
                mask.text16 = true;
            else if (format == TextDataFormat.Rtf)
                mask.rtf = true;
            else
                return false;
            DataObject dataObject;
            return GetMaskedDataObject(mask, false, out dataObject);
        }
#endif
        internal override Stream GetAudioStream()
        {
            //TODO
            return null;
        }

        internal override object GetData(string format)
        {
            Mask mask = new Mask();
            if (format == DataFormats.Text)
                mask.text8 = true;
            else if (format == DataFormats.UnicodeText)
                mask.text16 = true;
            else if (format == DataFormats.Rtf)
                mask.rtf = true;
            else if (format == DataFormats.Bitmap)
                mask.tiff = true;
            else if (format == DataFormats.FileDrop)
                mask.drop = true;
            else
                return null;
            DataObject dataObject;
            if (GetMaskedDataObject(mask, true, out dataObject))
                return dataObject.GetData(format);
            return null;
        }

        internal override IDataObject GetDataObject()
        {
            Mask mask = new Mask();
            mask.all = true;
            DataObject dataObject;
            GetMaskedDataObject(mask, true, out dataObject);
            return dataObject;
        }

        internal override StringCollection GetFileDropList()
        {
#if NET_2_0
            Mask mask = new Mask();
            mask.drop = true;
            DataObject dataObject;
            if (GetMaskedDataObject(mask, true, out dataObject))
                return dataObject.GetFileDropList();
#endif
            return null;
        }

        internal override Image GetImage()
        {
#if NET_2_0
            Mask mask = new Mask();
            mask.tiff = true;
            DataObject dataObject;
            if (GetMaskedDataObject(mask, true, out dataObject))
                return dataObject.GetImage();
#endif
            return null;
        }

        internal override string GetText()
        {
#if NET_2_0
            Mask mask = new Mask();
            mask.text8 = true;
            mask.text16 = true;
            mask.rtf = true;
            DataObject dataObject;
            if (GetMaskedDataObject(mask, true, out dataObject))
                return dataObject.GetText();
#endif
            return null;
        }
#if NET_2_0
        internal override string GetText(TextDataFormat format)
        {
            Mask mask = new Mask();
            if (format == TextDataFormat.Text)
                mask.text8 = true;
            else if (format == TextDataFormat.UnicodeText)
                mask.text16 = true;
            else if (format == TextDataFormat.Rtf)
                mask.rtf = true;
            else
                return null;
            DataObject dataObject;
            if (GetMaskedDataObject(mask, true, out dataObject))
                return dataObject.GetText(format);
            return null;
        }
#endif
        private bool GetMaskedDataObject(Mask mask, bool bGet, out DataObject dataObject)
        {
            bool bFound = false;
            dataObject = null;

            int status = PasteboardSynchronize(_pasteboard);
            if (status != 0)
                Console.WriteLine("PasteboardSynchronize status = " + Status(status));

            UInt32 itemCount = 0;
            status = PasteboardGetItemCount(_pasteboard, ref itemCount);
            if (status != 0)
                Console.WriteLine("PasteboardGetItemCount status = " + Status(status));

            bool bSearching = true;
            for (UInt32 itemIndex = 1; itemIndex <= itemCount && bSearching; itemIndex++)
            {
                UInt32 itemID = 0;
                status = PasteboardGetItemIdentifier(_pasteboard, itemIndex, ref itemID);
                if (status != 0)
                    Console.WriteLine("PasteboardGetItemIdentifier status = " + Status(status));

                IntPtr flavorTypeArray = IntPtr.Zero;
                status = PasteboardCopyItemFlavors(_pasteboard, itemID, ref flavorTypeArray);
                if (status != 0)
                    Console.WriteLine("PasteboardCopyItemFlavors status = " + Status(status));

                Int32 flavorCount = CFArrayGetCount(flavorTypeArray);

                for (Int32 flavorIndex = 0; flavorIndex < flavorCount && bSearching; flavorIndex++)
                {
                    IntPtr flavorType = CFArrayGetValueAtIndex(flavorTypeArray, flavorIndex);
                    IntPtr flavorCStr = CFStringGetCStringPtr(flavorType, 0);
                    string flavor = Marshal.PtrToStringAnsi(flavorCStr);

                    if (flavor == FLAVOR_TEXT8)
                    {
                        if (mask.all || mask.text8)
                        {
                            bFound = true;
                            if (bGet)
                                dataObject = GetText8(GetCFData(itemID, flavorType));
                        }
                        bSearching = false;
                    }
                    else if (flavor == FLAVOR_TEXT16)
                    {
                        if (mask.all || mask.text16)
                        {
                            bFound = true;
                            if (bGet)
                                dataObject = GetText16(GetCFData(itemID, flavorType));
                        }
                        bSearching = false;
                    }
                    else if (flavor == FLAVOR_RTF)
                    {
                        if (mask.all || mask.rtf)
                        {
                            bFound = true;
                            if (bGet)
                                dataObject = GetRtf(GetCFData(itemID, flavorType));
                        }
                        bSearching = false;
                    }
                    else if (flavor == FLAVOR_TIFF)
                    {
                        if (mask.all || mask.tiff)
                        {
                            bFound = true;
                            if (bGet)
                                dataObject = GetBitmap(GetCFData(itemID, flavorType));
                        }
                        bSearching = false;
                    }
                    else if (flavor == FLAVOR_DROP)
                    {
                        if (mask.all || mask.drop)
                        {
                            bFound = true;
                            if (bGet)
                                dataObject = GetDrop(GetCFData(itemID, flavorType));
                        }
                        bSearching = false;
                    }
                }
                CFRelease(flavorTypeArray);
            }
            return bFound;
        }

        private IntPtr GetCFData(UInt32 itemID, IntPtr flavorType)
        {
            IntPtr data = IntPtr.Zero;
            int status = PasteboardCopyItemFlavorData(_pasteboard, itemID, flavorType, ref data);
            if (status != 0)
                Console.WriteLine("PasteboardCopyItemFlavorData status = " + Status(status));
            return data;
        }

        private DataObject GetText8(IntPtr data)
        {
            IntPtr dataPtr = CFDataGetBytePtr(data);
            Int32 dataLen = CFDataGetLength(data);

            DataObject dataObject = new DataObject(DataFormats.Text,
                Marshal.PtrToStringAnsi(dataPtr, dataLen));
            CFRelease(data);
            return dataObject;
        }

        private DataObject GetText16(IntPtr data)
        {
            IntPtr dataPtr = CFDataGetBytePtr(data);
            Int32 dataLen = CFDataGetLength(data);

            DataObject dataObject = new DataObject(DataFormats.UnicodeText,
                Marshal.PtrToStringUni(dataPtr, dataLen));
            CFRelease(data);
            return dataObject;
        }

        private DataObject GetRtf(IntPtr data)
        {
            IntPtr dataPtr = CFDataGetBytePtr(data);
            Int32 dataLen = CFDataGetLength(data);

            DataObject dataObject = new DataObject(DataFormats.Rtf,
                Marshal.PtrToStringAnsi(dataPtr, dataLen));
            CFRelease(data);
            return dataObject;
        }

        private DataObject GetBitmap(IntPtr data)
        {
            IntPtr dataPtr = CFDataGetBytePtr(data);
            Int32 dataLen = CFDataGetLength(data);

            byte[] buffer = new byte[dataLen];
            Marshal.Copy(dataPtr, buffer, 0, dataLen);

            Stream stream = new MemoryStream(buffer);
            Image image = Image.FromStream(stream);
            stream.Close();
#if NET_2_0
            stream.Dispose();
#endif
            DataObject dataObject = new DataObject(DataFormats.Bitmap, image);
            CFRelease(data);
            return dataObject;
        }

        private DataObject GetDrop(IntPtr data)
        {
#if NET_2_0
            IntPtr dataPtr = CFDataGetBytePtr(data);
            Int32 dataLen = CFDataGetLength(data);

            string fileName = (string)Marshal.PtrToStringAnsi(dataPtr, dataLen);
            if (fileName.StartsWith("file://localhost/"))
                fileName = "/" + fileName.Substring(16);
            StringCollection fileCollection = new StringCollection();
            fileCollection.Add(fileName);

            DataObject dataObject = new DataObject(DataFormats.FileDrop, null);
            dataObject.SetFileDropList(fileCollection);

            CFRelease(data);
            return dataObject;
#else
            return null;
#endif
        }

        internal override void SetAudio(byte[] audioBytes)
        {
            //TODO
        }

        internal override void SetAudio(Stream audioStream)
        {
            //TODO
        }

        internal override void SetData(string format, object data)
        {
            if (format == DataFormats.Text)
                SetDataObject(new DataObject(DataFormats.Text, data), true);
            else if (format == DataFormats.UnicodeText)
                SetDataObject(new DataObject(DataFormats.UnicodeText, data), true);
            else if (format == DataFormats.Rtf)
                SetDataObject(new DataObject(DataFormats.Rtf, data), true);
            else if (format == DataFormats.Bitmap)
                SetDataObject(new DataObject(DataFormats.Bitmap, data), true);
        }

        internal override void SetDataObject(IDataObject dataObject)
        {
            SetDataObject(dataObject, false);
        }

        internal override void SetDataObject(IDataObject dataObject, bool copy)
        {
            int status = PasteboardClear(_pasteboard);
            if (status != 0)
                Console.WriteLine("PasteboardClear status = " + Status(status));

            string[] formatList = dataObject.GetFormats();

            for (int i = 0; i < formatList.Length; i++)
            {
                string format = formatList[i];

                if (format == DataFormats.Text)
                {
                    SetCFData(
                        SetText8((string)dataObject.GetData(DataFormats.Text)),
                        FLAVOR_TEXT8);
                    break;
                }
                if (format == DataFormats.UnicodeText)
                {
                    SetCFData(
                        SetText16((string)dataObject.GetData(DataFormats.UnicodeText)),
                        FLAVOR_TEXT16);
                    break;
                }
                if (format == DataFormats.Rtf)
                {
                    SetCFData(
                        SetText8((string)dataObject.GetData(DataFormats.Rtf)),
                        FLAVOR_RTF);
                    break;
                }
                if (format == DataFormats.Bitmap)
                {
                    SetCFData(
                        SetBitmap((Image)dataObject.GetData(DataFormats.Bitmap)),
                        FLAVOR_TIFF);
                    break;
                }
            }
        }

        internal override void SetDataObject(IDataObject dataObject, bool copy, int retryTimes, int retryDelay)
        {
            SetDataObject(dataObject, copy);
        }

        internal override void SetFileDropList(StringCollection filePaths)
        {
            //TODO
        }

        internal override void SetImage(Image image)
        {
            SetDataObject(new DataObject(DataFormats.Bitmap, image), true);
        }

        internal override void SetText(string text)
        {
            SetDataObject(new DataObject(DataFormats.Text, text), true);
        }
#if NET_2_0
        internal override void SetText(string text, TextDataFormat format)
        {
            if (format == TextDataFormat.Text)
                SetDataObject(new DataObject(DataFormats.Text, text), true);
            else if (format == TextDataFormat.UnicodeText)
                SetDataObject(new DataObject(DataFormats.UnicodeText, text), true);
            else if (format == TextDataFormat.Rtf)
                SetDataObject(new DataObject(DataFormats.Rtf, text), true);
        }
#endif
        private IntPtr SetText8(string text)
        {
            IntPtr memory = Marshal.StringToHGlobalAnsi(text);
            IntPtr data = CFDataCreate(IntPtr.Zero, memory, text.Length + 1);
            Marshal.FreeHGlobal(memory);
            return data;
        }

        private IntPtr SetText16(string text)
        {
            IntPtr memory = Marshal.StringToHGlobalUni(text);
            IntPtr data = CFDataCreate(IntPtr.Zero, memory, (text.Length + 1) * 2);
            Marshal.FreeHGlobal(memory);
            return data;
        }

        private IntPtr SetBitmap(Image image_parm)
        {
            Image image = new Bitmap(image_parm); //must make a copy so GDI doesn't get upset
            string fileName = Path.GetTempFileName();
            image.Save(fileName, ImageFormat.Tiff);
            image.Dispose();

            Stream stream = new FileStream(fileName, FileMode.Open, FileAccess.Read);
            int size = (int)stream.Length;
            byte[] buffer = new byte[size];
            stream.Read(buffer, 0, size);
            stream.Close();
#if NET_2_0
            stream.Dispose();
#endif
            File.Delete(fileName);

            IntPtr memory = Marshal.AllocHGlobal(size);
            Marshal.Copy(buffer, 0, memory, size);

            IntPtr data = CFDataCreate(IntPtr.Zero, memory, size);
            Marshal.FreeHGlobal(memory);
            return data;
        }

        private void SetCFData(IntPtr data, string flavor)
        {
            int status = PasteboardPutItemFlavor(_pasteboard, 789514,
                __CFStringMakeConstantString(flavor), data, 0);
            if (status != 0)
                Console.WriteLine("PasteboardPutItemFlavor status = " + Status(status));
        }

        private string Status(int status)
        {
            const int badPasteboardSyncErr = -25130;
            const int badPasteboardIndexErr = -25131;
            const int badPasteboardItemErr = -25132;
            const int badPasteboardFlavorErr = -25133;
            const int duplicatePasteboardFlavorErr = -25134;
            const int notPasteboardOwnerErr = -25135;
            const int noPasteboardPromiseKeeperErr = -25136;

            switch (status)
            {
                case badPasteboardSyncErr: return "Bad Pasteboard Sync Err";
                case badPasteboardIndexErr: return "Bad Pasteboard Index Err";
                case badPasteboardItemErr: return "Bad Pasteboard Item Err";
                case badPasteboardFlavorErr: return "Bad Pasteboard Flavor Err";
                case duplicatePasteboardFlavorErr: return "Duplicate Pasteboard Flavor Err";
                case notPasteboardOwnerErr: return "Not Pasteboard Owner Err";
                case noPasteboardPromiseKeeperErr: return "No Pasteboard Promise Keeper Err";
                default: return status.ToString();
            }
        }

        internal override int GetID(string format)
        {
            if (format == "Text") return (int)ClipboardFormats.CF_TEXT;
            else if (format == "Bitmap") return (int)ClipboardFormats.CF_BITMAP;
            else if (format == "MetaFilePict") return (int)ClipboardFormats.CF_METAFILEPICT;
            else if (format == "SymbolicLink") return (int)ClipboardFormats.CF_SYLK;
            else if (format == "DataInterchangeFormat") return (int)ClipboardFormats.CF_DIF;
            else if (format == "Tiff") return (int)ClipboardFormats.CF_TIFF;
            else if (format == "OEMText") return (int)ClipboardFormats.CF_OEMTEXT;
            else if (format == "DeviceIndependentBitmap") return (int)ClipboardFormats.CF_DIB;
            else if (format == "Palette") return (int)ClipboardFormats.CF_PALETTE;
            else if (format == "PenData") return (int)ClipboardFormats.CF_PENDATA;
            else if (format == "RiffAudio") return (int)ClipboardFormats.CF_RIFF;
            else if (format == "WaveAudio") return (int)ClipboardFormats.CF_WAVE;
            else if (format == "UnicodeText") return (int)ClipboardFormats.CF_UNICODETEXT;
            else if (format == "EnhancedMetafile") return (int)ClipboardFormats.CF_ENHMETAFILE;
            else if (format == "FileDrop") return (int)ClipboardFormats.CF_HDROP;
            else if (format == "Locale") return (int)ClipboardFormats.CF_LOCALE;

            return 0; //don't know
        }

        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        static extern IntPtr __CFStringMakeConstantString(string cString);

        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        static extern Int32 CFArrayGetCount(IntPtr array);

        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        static extern IntPtr CFArrayGetValueAtIndex(IntPtr array, Int32 index);

        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        static extern IntPtr CFDataCreate(IntPtr allocator, IntPtr data, Int32 length);

        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        static extern IntPtr CFDataGetBytePtr(IntPtr data);

        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        static extern Int32 CFDataGetLength(IntPtr data);

        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        static extern void CFRelease(IntPtr data);

        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        static extern IntPtr CFStringGetCStringPtr(IntPtr cfstr, UInt32 encoding);

        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        static extern int PasteboardClear(IntPtr pasteboard);

        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        static extern int PasteboardCreate(IntPtr name, ref IntPtr pasteboard);

        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        static extern int PasteboardCopyItemFlavorData(IntPtr pasteboard, UInt32 itemID, IntPtr flavorType, ref IntPtr data);

        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        static extern int PasteboardCopyItemFlavors(IntPtr pasteboard, UInt32 itemID, ref IntPtr flavorTypeArray);

        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        static extern int PasteboardGetItemCount(IntPtr pasteboard, ref UInt32 itemCount);

        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        static extern int PasteboardGetItemIdentifier(IntPtr pasteboard, UInt32 itemIndex, ref UInt32 itemID);

        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        static extern int PasteboardPutItemFlavor(IntPtr pasteboard, UInt32 itemID, IntPtr flavorType, IntPtr data, UInt32 flags);

        [DllImport("/System/Library/Frameworks/Carbon.framework/Versions/Current/Carbon")]
        static extern int PasteboardSynchronize(IntPtr pasteboard);
    }
}
