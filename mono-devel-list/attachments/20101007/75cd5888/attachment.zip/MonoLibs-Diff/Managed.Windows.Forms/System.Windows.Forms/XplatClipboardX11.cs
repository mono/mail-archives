﻿// Permission is hereby granted, free of charge, to any person obtaining
// a copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to
// permit persons to whom the Software is furnished to do so, subject to
// the following conditions:
// 
// The above copyright notice and this permission notice shall be
// included in all copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
// NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
// LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
// OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
// WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
//
// Copyright (c) 2005 Novell, Inc. (http://www.novell.com)
//
// Authors:
//	Peter Bartok	(pbartok@novell.com)
//
//

// COMPLETE

using System;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;
using System.Collections;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Threading;

namespace System.Windows.Forms
{
    internal class XplatClipboardX11 : XplatClipboard
    {
        private static IntPtr ClipMagic;

        private XplatUIX11 driver;

        internal XplatClipboardX11(XplatUIDriver driver)
        {
            this.driver = driver as XplatUIX11;
        }

        internal override void Clear()
        {
            IntPtr clipboard_handle;

            clipboard_handle = ClipboardOpen(false);
            ClipboardStore(clipboard_handle, null, 0, null);
        }

        internal override bool ContainsAudio()
        {
            return ClipboardContainsFormat(DataFormats.WaveAudio);
        }

        internal override bool ContainsData(string format)
        {
            return ClipboardContainsFormat(format);
        }

        internal override bool ContainsFileDropList()
        {
            return ClipboardContainsFormat(DataFormats.FileDrop);
        }

        internal override bool ContainsImage()
        {
            return ClipboardContainsFormat(DataFormats.Bitmap);
        }

        internal override bool ContainsText()
        {
            return ClipboardContainsFormat(DataFormats.Text, DataFormats.UnicodeText);
        }
#if NET_2_0
        internal override bool ContainsText(TextDataFormat format)
        {
            switch (format)
            {
                case TextDataFormat.Text:
                    return ClipboardContainsFormat(DataFormats.Text);
                case TextDataFormat.UnicodeText:
                    return ClipboardContainsFormat(DataFormats.UnicodeText);
                case TextDataFormat.Rtf:
                    return ClipboardContainsFormat(DataFormats.Rtf);
                case TextDataFormat.Html:
                    return ClipboardContainsFormat(DataFormats.Html);
                case TextDataFormat.CommaSeparatedValue:
                    return ClipboardContainsFormat(DataFormats.CommaSeparatedValue);
            }

            return false;
        }
#endif
        private bool ClipboardContainsFormat(params string[] formats)
        {
            IntPtr clipboard_handle;
            int[] native_formats;
            DataFormats.Format item_format;

            clipboard_handle = ClipboardOpen(false);
            native_formats = ClipboardAvailableFormats(clipboard_handle);

            if (native_formats == null)
                return false;

            foreach (int i in native_formats)
            {
                // We might get a format we don't understand or know
                item_format = DataFormats.GetFormat(i);

                if (item_format != null)
                    if (((IList)formats).Contains(item_format.Name))
                        return true;
            }

            return false;
        }

        internal override Stream GetAudioStream()
        {
            IDataObject data = GetDataObject();

            if (data == null)
                return null;

            return (Stream)data.GetData(DataFormats.WaveAudio, true);
        }

        internal override object GetData(string format)
        {
            IDataObject data = GetDataObject();

            if (data == null)
                return null;

            return data.GetData(format, true);
        }

        internal override IDataObject GetDataObject()
        {
            return GetDataObject(false);
        }

        private IDataObject GetDataObject(bool primary_selection)
        {
            DataObject clipboard;
            IntPtr clipboard_handle;
            int[] native_formats;
            DataFormats.Format item_format;
            object managed_clipboard_item;
            ClipboardData.ClipboardToObject converter;

            converter = new ClipboardData.ClipboardToObject(ConvertFromClipboardData);

            clipboard_handle = ClipboardOpen(primary_selection);
            native_formats = ClipboardAvailableFormats(clipboard_handle);
            if (native_formats == null)
            {
                return null;	// Clipboard empty
            }

            // Build the IDataObject
            clipboard = new DataObject();
            for (int i = 0; i < native_formats.Length; i++)
            {
                // We might get a format we don't understand or know
                item_format = DataFormats.GetFormat(native_formats[i]);

                if (item_format != null)
                {
                    managed_clipboard_item = ClipboardRetrieve(clipboard_handle, native_formats[i], converter);

                    if (managed_clipboard_item != null)
                    {
                        clipboard.SetData(item_format.Name, managed_clipboard_item);
                        // We don't handle 'bitmap' since it involves handles, so we'll equate it to dib
                        if (item_format.Name == DataFormats.Dib)
                        {
                            clipboard.SetData(DataFormats.Bitmap, managed_clipboard_item);
                        }
                    }
                }
            }

            ClipboardClose(clipboard_handle);

            return clipboard;
        }

        internal override StringCollection GetFileDropList()
        {
            IDataObject data = GetDataObject();

            if (data == null)
                return null;

            return (StringCollection)data.GetData(DataFormats.FileDrop, true);
        }

        internal override Image GetImage()
        {
            IDataObject data = GetDataObject();

            if (data == null)
                return null;

            return (Image)data.GetData(DataFormats.Bitmap, true);
        }

#if NET_2_0
        internal override string GetText()
        {
            return GetText(TextDataFormat.UnicodeText);
        }
#else
        internal override string GetText()
        {
            return null;
        }
#endif

#if NET_2_0
        internal override string GetText(TextDataFormat format)
        {
            if (!Enum.IsDefined(typeof(TextDataFormat), format))
                throw new InvalidEnumArgumentException(string.Format("Enum argument value '{0}' is not valid for TextDataFormat", format));

            IDataObject data = GetDataObject();

            if (data == null)
                return string.Empty;

            string retval;

            switch (format)
            {
                case TextDataFormat.Text:
                default:
                    retval = (string)data.GetData(DataFormats.Text, true);
                    break;
                case TextDataFormat.UnicodeText:
                    retval = (string)data.GetData(DataFormats.UnicodeText, true);
                    break;
                case TextDataFormat.Rtf:
                    retval = (string)data.GetData(DataFormats.Rtf, true);
                    break;
                case TextDataFormat.Html:
                    retval = (string)data.GetData(DataFormats.Html, true);
                    break;
                case TextDataFormat.CommaSeparatedValue:
                    retval = (string)data.GetData(DataFormats.CommaSeparatedValue, true);
                    break;
            }

            return retval == null ? string.Empty : retval;
        }
#endif
        internal override void SetAudio(byte[] audioBytes)
        {
            if (audioBytes == null)
                throw new ArgumentNullException("audioBytes");

            MemoryStream ms = new MemoryStream(audioBytes);

            SetAudio(ms);
        }

        internal override void SetAudio(Stream audioStream)
        {
            if (audioStream == null)
                throw new ArgumentNullException("audioStream");

            SetData(DataFormats.WaveAudio, audioStream);
        }

        internal override void SetData(string format, object data)
        {
            if (data == null)
                throw new ArgumentNullException("data");

            DataObject data_object = new DataObject(format, data);
            SetDataObject(data_object);
        }

        internal override void SetDataObject(IDataObject dataObject)
        {
            SetDataObject(dataObject, false);  // MSDN says default behavior is to place non-persistent data to clipboard
        }

        internal override void SetDataObject(IDataObject dataObject, bool copy)
        {
            SetDataObject(dataObject, copy, 10, 100);   // MSDN says default behavior is to try 10 times with 100 ms delay
        }

        internal override void SetDataObject(IDataObject dataObject, bool copy, int retryTimes, int retryDelay)
        {
            if (dataObject == null)
                throw new ArgumentNullException("data");
            if (retryTimes < 0)
                throw new ArgumentOutOfRangeException("retryTimes");
            if (retryDelay < 0)
                throw new ArgumentOutOfRangeException("retryDelay");

            // MS implementation actually puts data to clipboard even when retryTimes == 0
            bool retry = true;
            do
            {
                retry = false;
                --retryTimes;
                try
                {
                    SetDataObjectImpl(dataObject, copy);
                }
                catch (ExternalException)
                {
                    if (retryTimes <= 0)
                        throw;
                    retry = true;
                    Thread.Sleep(retryDelay);
                }
            } while (retry && retryTimes > 0);
        }

        private void SetDataObjectImpl(object data, bool copy)
        {
            IntPtr clipboard_handle;
            ClipboardData.ObjectToClipboard converter;
            int native_format;
            DataFormats.Format item_format;

            converter = new ClipboardData.ObjectToClipboard(ConvertToClipboardData);

            clipboard_handle = ClipboardOpen(false);
            ClipboardStore(clipboard_handle, null, 0, null);	// Empty clipboard

            native_format = -1;

            if (data is IDataObject)
            {
                string[] formats;

                IDataObject data_object = data as IDataObject;
                formats = data_object.GetFormats();
                for (int i = 0; i < formats.Length; i++)
                {
                    item_format = DataFormats.GetFormat(formats[i]);
                    if ((item_format != null) && (item_format.Name != DataFormats.StringFormat))
                    {
                        native_format = item_format.Id;
                    }

                    object obj = data_object.GetData(formats[i]);

                    // this is used only by custom formats
                    if (IsDataSerializable(obj))
                        item_format.is_serializable = true;

                    ClipboardStore(clipboard_handle, obj, native_format, converter);
                }
            }
            else
            {
                item_format = DataFormats.Format.Find(data.GetType().FullName);
                if ((item_format != null) && (item_format.Name != DataFormats.StringFormat))
                {
                    native_format = item_format.Id;
                }

                ClipboardStore(clipboard_handle, data, native_format, converter);
            }
            ClipboardClose(clipboard_handle);
        }

        private bool IsDataSerializable(object obj)
        {
            if (obj is ISerializable)
                return true;

            AttributeCollection attrs = TypeDescriptor.GetAttributes(obj);
            return attrs[typeof(SerializableAttribute)] != null;
        }

        [MonoInternalNote("Needs additional checks for valid paths, see MSDN")]
        internal override void SetFileDropList(StringCollection filePaths)
        {
            if (filePaths == null)
                throw new ArgumentNullException("filePaths");

            SetData(DataFormats.FileDrop, filePaths);
        }

        internal override void SetImage(Image image)
        {
            if (image == null)
                throw new ArgumentNullException("image");

            SetData(DataFormats.Bitmap, image);
        }

        internal override void SetText(string text)
        {
#if NET_2_0
            if (string.IsNullOrEmpty(text))
                throw new ArgumentNullException("text");
#endif
            SetData(DataFormats.UnicodeText, text);
        }
#if NET_2_0
        internal override void SetText(string text, TextDataFormat format)
        {
            if (string.IsNullOrEmpty(text))
                throw new ArgumentNullException("text");
            if (!Enum.IsDefined(typeof(TextDataFormat), format))
                throw new InvalidEnumArgumentException(string.Format("Enum argument value '{0}' is not valid for TextDataFormat", format));

            switch (format)
            {
                case TextDataFormat.Text:
                    SetData(DataFormats.Text, text);
                    break;
                case TextDataFormat.UnicodeText:
                    SetData(DataFormats.UnicodeText, text);
                    break;
                case TextDataFormat.Rtf:
                    SetData(DataFormats.Rtf, text);
                    break;
                case TextDataFormat.Html:
                    SetData(DataFormats.Html, text);
                    break;
                case TextDataFormat.CommaSeparatedValue:
                    SetData(DataFormats.CommaSeparatedValue, text);
                    break;
            }
        }
#endif
        private bool ConvertToClipboardData(ref int type, object obj, out byte[] data)
        {
            data = null;
            return false;
        }

        private bool ConvertFromClipboardData(int type, IntPtr data, out object obj)
        {
            obj = null;
            if (data == IntPtr.Zero)
            {
                return false;
            }
            return false;
        }

        internal override int GetID(string format)
        {
            if (format == "Text") return (int)Atom.XA_STRING;
            else if (format == "Bitmap") return (int)Atom.XA_BITMAP;
            //else if (format == "MetaFilePict" ) return 3;
            //else if (format == "SymbolicLink" ) return 4;
            //else if (format == "DataInterchangeFormat" ) return 5;
            //else if (format == "Tiff" ) return 6;
            else if (format == "OEMText") return XplatUIX11.OEMTEXT.ToInt32();
            else if (format == "DeviceIndependentBitmap") return (int)Atom.XA_PIXMAP;
            else if (format == "Palette") return (int)Atom.XA_COLORMAP;	// Useless
            //else if (format == "PenData" ) return 10;
            //else if (format == "RiffAudio" ) return 11;
            //else if (format == "WaveAudio" ) return 12;
            else if (format == "UnicodeText") return XplatUIX11.UTF16_STRING.ToInt32();
            //else if (format == "EnhancedMetafile" ) return 14;
            //else if (format == "FileDrop" ) return 15;
            //else if (format == "Locale" ) return 16;
            else if (format == "Rich Text Format") return XplatUIX11.RICHTEXTFORMAT.ToInt32();

            return XplatUIX11.XInternAtom(XplatUIX11.DisplayHandle, format, false).ToInt32();
        }

        //%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        // stuff formerly in XplatUIX11
        //%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        private int[] ClipboardAvailableFormats(IntPtr handle)
        {
            DataFormats.Format f;
            int[] result;

            f = DataFormats.Format.List;

            if (XplatUIX11.XGetSelectionOwner(XplatUIX11.DisplayHandle, XplatUIX11.CLIPBOARD) == IntPtr.Zero)
            {
                return null;
            }

            XplatUIX11.Clipboard.Formats = new ArrayList();

            while (f != null)
            {
                XplatUIX11.XConvertSelection(XplatUIX11.DisplayHandle, XplatUIX11.CLIPBOARD, (IntPtr)f.Id, (IntPtr)f.Id, XplatUIX11.FosterParent, IntPtr.Zero);

                XplatUIX11.Clipboard.Enumerating = true;
                while (XplatUIX11.Clipboard.Enumerating)
                {
                    driver.UpdateMessageQueue(null);
                }
                f = f.Next;
            }

            result = new int[XplatUIX11.Clipboard.Formats.Count];

            for (int i = 0; i < XplatUIX11.Clipboard.Formats.Count; i++)
            {
                result[i] = ((IntPtr)XplatUIX11.Clipboard.Formats[i]).ToInt32();
            }

            XplatUIX11.Clipboard.Formats = null;
            return result;
        }

        private void ClipboardClose(IntPtr handle)
        {
            if (handle != ClipMagic)
            {
                throw new ArgumentException("handle is not a valid clipboard handle");
            }
            return;
        }

        private IntPtr ClipboardOpen(bool primary_selection)
        {
            if (!primary_selection)
                ClipMagic = XplatUIX11.CLIPBOARD;
            else
                ClipMagic = XplatUIX11.PRIMARY;
            return ClipMagic;
        }

        private object ClipboardRetrieve(IntPtr handle, int type, ClipboardData.ClipboardToObject converter)
        {
            XplatUIX11.XConvertSelection(XplatUIX11.DisplayHandle, handle, (IntPtr)type, (IntPtr)type, XplatUIX11.FosterParent, IntPtr.Zero);

            XplatUIX11.Clipboard.Retrieving = true;
            while (XplatUIX11.Clipboard.Retrieving)
            {
                driver.UpdateMessageQueue(null);
            }

            return XplatUIX11.Clipboard.Item;
        }

        private void ClipboardStore(IntPtr handle, object obj, int type, ClipboardData.ObjectToClipboard converter)
        {
            XplatUIX11.Clipboard.Converter = converter;

            if (obj != null)
            {
                XplatUIX11.Clipboard.AddSource(type, obj);
                XplatUIX11.XSetSelectionOwner(XplatUIX11.DisplayHandle, XplatUIX11.CLIPBOARD, XplatUIX11.FosterParent, IntPtr.Zero);
            }
            else
            {
                // Clearing the selection
                XplatUIX11.Clipboard.ClearSources();
                XplatUIX11.XSetSelectionOwner(XplatUIX11.DisplayHandle, XplatUIX11.CLIPBOARD, IntPtr.Zero, IntPtr.Zero);
            }
        }
    }
}
