﻿// Permission is hereby granted, free of charge, to any person obtaining
// a copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to
// permit persons to whom the Software is furnished to do so, subject to
// the following conditions:
// 
// The above copyright notice and this permission notice shall be
// included in all copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
// NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
// LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
// OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
// WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
//
// Authors:
//  Ralph Leckett <rleckett@gmail.com>
//

using System;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;
using System.Collections;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Threading;

namespace System.Windows.Forms
{
    internal class XplatClipboardWin32 : XplatClipboard
    {
        #region	Delegates
        public delegate bool ClipboardToObject(int type, IntPtr data, out object obj);
        public delegate bool ObjectToClipboard(ref int type, object obj, out byte[] data);
        #endregion	// Delegates

        private static IntPtr clip_magic = new IntPtr(27051977);

        internal override void Clear()
        {
            IntPtr clipboard_handle;

            clipboard_handle = ClipboardOpen(false);
            ClipboardStore(clipboard_handle, null, 0, null);
        }

        internal override bool ContainsAudio()
        {
            return ClipboardContainsFormat(DataFormats.WaveAudio);
        }

        internal override bool ContainsData(string format)
        {
            return ClipboardContainsFormat(format);
        }

        internal override bool ContainsFileDropList()
        {
            return ClipboardContainsFormat(DataFormats.FileDrop);
        }

        internal override bool ContainsImage()
        {
            return ClipboardContainsFormat(DataFormats.Bitmap);
        }

        internal override bool ContainsText()
        {
            return ClipboardContainsFormat(DataFormats.Text, DataFormats.UnicodeText);
        }
#if NET_2_0
        internal override bool ContainsText(TextDataFormat format)
        {
            switch (format)
            {
                case TextDataFormat.Text:
                    return ClipboardContainsFormat(DataFormats.Text);
                case TextDataFormat.UnicodeText:
                    return ClipboardContainsFormat(DataFormats.UnicodeText);
                case TextDataFormat.Rtf:
                    return ClipboardContainsFormat(DataFormats.Rtf);
                case TextDataFormat.Html:
                    return ClipboardContainsFormat(DataFormats.Html);
                case TextDataFormat.CommaSeparatedValue:
                    return ClipboardContainsFormat(DataFormats.CommaSeparatedValue);
            }

            return false;
        }
#endif
        private bool ClipboardContainsFormat(params string[] formats)
        {
            IntPtr clipboard_handle;
            int[] native_formats;
            DataFormats.Format item_format;

            clipboard_handle = ClipboardOpen(false);
            native_formats = ClipboardAvailableFormats(clipboard_handle);

            if (native_formats == null)
                return false;

            foreach (int i in native_formats)
            {
                // We might get a format we don't understand or know
                item_format = DataFormats.GetFormat(i);

                if (item_format != null)
                    if (((IList)formats).Contains(item_format.Name))
                        return true;
            }

            return false;
        }

        internal override Stream GetAudioStream()
        {
            IDataObject data = GetDataObject();

            if (data == null)
                return null;

            return (Stream)data.GetData(DataFormats.WaveAudio, true);
        }

        internal override object GetData(string format)
        {
            IDataObject data = GetDataObject();

            if (data == null)
                return null;

            return data.GetData(format, true);
        }

        internal override IDataObject GetDataObject()
        {
            return GetDataObject(false);
        }

        private IDataObject GetDataObject(bool primary_selection)
        {
            DataObject clipboard;
            IntPtr clipboard_handle;
            int[] native_formats;
            DataFormats.Format item_format;
            object managed_clipboard_item;
            ClipboardToObject converter;

            converter = new ClipboardToObject(ConvertFromClipboardData);

            clipboard_handle = ClipboardOpen(primary_selection);
            native_formats = ClipboardAvailableFormats(clipboard_handle);
            if (native_formats == null)
            {
                return null;	// Clipboard empty
            }

            // Build the IDataObject
            clipboard = new DataObject();
            for (int i = 0; i < native_formats.Length; i++)
            {
                // We might get a format we don't understand or know
                item_format = DataFormats.GetFormat(native_formats[i]);

                if (item_format != null)
                {
                    managed_clipboard_item = ClipboardRetrieve(clipboard_handle, native_formats[i], converter);

                    if (managed_clipboard_item != null)
                    {
                        clipboard.SetData(item_format.Name, managed_clipboard_item);
                        // We don't handle 'bitmap' since it involves handles, so we'll equate it to dib
                        if (item_format.Name == DataFormats.Dib)
                        {
                            clipboard.SetData(DataFormats.Bitmap, managed_clipboard_item);
                        }
                    }
                }
            }

            ClipboardClose(clipboard_handle);

            return clipboard;
        }

        internal override StringCollection GetFileDropList()
        {
            IDataObject data = GetDataObject();

            if (data == null)
                return null;

            return (StringCollection)data.GetData(DataFormats.FileDrop, true);
        }

        internal override Image GetImage()
        {
            IDataObject data = GetDataObject();

            if (data == null)
                return null;

            return (Image)data.GetData(DataFormats.Bitmap, true);
        }

#if NET_2_0
        internal override string GetText()
        {
            return GetText(TextDataFormat.UnicodeText);
        }
#else
        internal override string GetText()
        {
            return null;
        }
#endif

#if NET_2_0
        internal override string GetText(TextDataFormat format)
        {
            if (!Enum.IsDefined(typeof(TextDataFormat), format))
                throw new InvalidEnumArgumentException(string.Format("Enum argument value '{0}' is not valid for TextDataFormat", format));

            IDataObject data = GetDataObject();

            if (data == null)
                return string.Empty;

            string retval;

            switch (format)
            {
                case TextDataFormat.Text:
                default:
                    retval = (string)data.GetData(DataFormats.Text, true);
                    break;
                case TextDataFormat.UnicodeText:
                    retval = (string)data.GetData(DataFormats.UnicodeText, true);
                    break;
                case TextDataFormat.Rtf:
                    retval = (string)data.GetData(DataFormats.Rtf, true);
                    break;
                case TextDataFormat.Html:
                    retval = (string)data.GetData(DataFormats.Html, true);
                    break;
                case TextDataFormat.CommaSeparatedValue:
                    retval = (string)data.GetData(DataFormats.CommaSeparatedValue, true);
                    break;
            }

            return retval == null ? string.Empty : retval;
        }
#endif
        internal override void SetAudio(byte[] audioBytes)
        {
            if (audioBytes == null)
                throw new ArgumentNullException("audioBytes");

            MemoryStream ms = new MemoryStream(audioBytes);

            SetAudio(ms);
        }

        internal override void SetAudio(Stream audioStream)
        {
            if (audioStream == null)
                throw new ArgumentNullException("audioStream");

            SetData(DataFormats.WaveAudio, audioStream);
        }

        internal override void SetData(string format, object data)
        {
            if (data == null)
                throw new ArgumentNullException("data");

            DataObject data_object = new DataObject(format, data);
            SetDataObject(data_object);
        }

        internal override void SetDataObject(IDataObject dataObject)
        {
            SetDataObject(dataObject, false);  // MSDN says default behavior is to place non-persistent data to clipboard
        }

        internal override void SetDataObject(IDataObject dataObject, bool copy)
        {
            SetDataObject(dataObject, copy, 10, 100);   // MSDN says default behavior is to try 10 times with 100 ms delay
        }

        internal override void SetDataObject(IDataObject dataObject, bool copy, int retryTimes, int retryDelay)
        {
            if (dataObject == null)
                throw new ArgumentNullException("data");
            if (retryTimes < 0)
                throw new ArgumentOutOfRangeException("retryTimes");
            if (retryDelay < 0)
                throw new ArgumentOutOfRangeException("retryDelay");

            // MS implementation actually puts data to clipboard even when retryTimes == 0
            bool retry = true;
            do
            {
                retry = false;
                --retryTimes;
                try
                {
                    SetDataObjectImpl(dataObject, copy);
                }
                catch (ExternalException)
                {
                    if (retryTimes <= 0)
                        throw;
                    retry = true;
                    Thread.Sleep(retryDelay);
                }
            } while (retry && retryTimes > 0);
        }

        private void SetDataObjectImpl(object data, bool copy)
        {
            IntPtr clipboard_handle;
            ObjectToClipboard converter;
            int native_format;
            DataFormats.Format item_format;

            converter = new ObjectToClipboard(ConvertToClipboardData);

            clipboard_handle = ClipboardOpen(false);
            ClipboardStore(clipboard_handle, null, 0, null);	// Empty clipboard

            native_format = -1;

            if (data is IDataObject)
            {
                string[] formats;

                IDataObject data_object = data as IDataObject;
                formats = data_object.GetFormats();
                for (int i = 0; i < formats.Length; i++)
                {
                    item_format = DataFormats.GetFormat(formats[i]);
                    if ((item_format != null) && (item_format.Name != DataFormats.StringFormat))
                    {
                        native_format = item_format.Id;
                    }

                    object obj = data_object.GetData(formats[i]);

                    // this is used only by custom formats
                    if (IsDataSerializable(obj))
                        item_format.is_serializable = true;

                    ClipboardStore(clipboard_handle, obj, native_format, converter);
                }
            }
            else
            {
                item_format = DataFormats.Format.Find(data.GetType().FullName);
                if ((item_format != null) && (item_format.Name != DataFormats.StringFormat))
                {
                    native_format = item_format.Id;
                }

                ClipboardStore(clipboard_handle, data, native_format, converter);
            }
            ClipboardClose(clipboard_handle);
        }

        private bool IsDataSerializable(object obj)
        {
            if (obj is ISerializable)
                return true;

            AttributeCollection attrs = TypeDescriptor.GetAttributes(obj);
            return attrs[typeof(SerializableAttribute)] != null;
        }

        [MonoInternalNote("Needs additional checks for valid paths, see MSDN")]
        internal override void SetFileDropList(StringCollection filePaths)
        {
            if (filePaths == null)
                throw new ArgumentNullException("filePaths");

            SetData(DataFormats.FileDrop, filePaths);
        }

        internal override void SetImage(Image image)
        {
            if (image == null)
                throw new ArgumentNullException("image");

            SetData(DataFormats.Bitmap, image);
        }

        internal override void SetText(string text)
        {
#if NET_2_0
            if (string.IsNullOrEmpty(text))
                throw new ArgumentNullException("text");
#endif
            SetData(DataFormats.UnicodeText, text);
        }
#if NET_2_0
        internal override void SetText(string text, TextDataFormat format)
        {
            if (string.IsNullOrEmpty(text))
                throw new ArgumentNullException("text");
            if (!Enum.IsDefined(typeof(TextDataFormat), format))
                throw new InvalidEnumArgumentException(string.Format("Enum argument value '{0}' is not valid for TextDataFormat", format));

            switch (format)
            {
                case TextDataFormat.Text:
                    SetData(DataFormats.Text, text);
                    break;
                case TextDataFormat.UnicodeText:
                    SetData(DataFormats.UnicodeText, text);
                    break;
                case TextDataFormat.Rtf:
                    SetData(DataFormats.Rtf, text);
                    break;
                case TextDataFormat.Html:
                    SetData(DataFormats.Html, text);
                    break;
                case TextDataFormat.CommaSeparatedValue:
                    SetData(DataFormats.CommaSeparatedValue, text);
                    break;
            }
        }
#endif
        private bool ConvertToClipboardData(ref int type, object obj, out byte[] data)
        {
            data = null;
            return false;
        }

        private bool ConvertFromClipboardData(int type, IntPtr data, out object obj)
        {
            obj = null;
            if (data == IntPtr.Zero)
            {
                return false;
            }
            return false;
        }

        internal override int GetID(string format)
        {
            if (format == "Text") return (int)ClipboardFormats.CF_TEXT;
            else if (format == "Bitmap") return (int)ClipboardFormats.CF_BITMAP;
            else if (format == "MetaFilePict") return (int)ClipboardFormats.CF_METAFILEPICT;
            else if (format == "SymbolicLink") return (int)ClipboardFormats.CF_SYLK;
            else if (format == "DataInterchangeFormat") return (int)ClipboardFormats.CF_DIF;
            else if (format == "Tiff") return (int)ClipboardFormats.CF_TIFF;
            else if (format == "OEMText") return (int)ClipboardFormats.CF_OEMTEXT;
            else if (format == "DeviceIndependentBitmap") return (int)ClipboardFormats.CF_DIB;
            else if (format == "Palette") return (int)ClipboardFormats.CF_PALETTE;
            else if (format == "PenData") return (int)ClipboardFormats.CF_PENDATA;
            else if (format == "RiffAudio") return (int)ClipboardFormats.CF_RIFF;
            else if (format == "WaveAudio") return (int)ClipboardFormats.CF_WAVE;
            else if (format == "UnicodeText") return (int)ClipboardFormats.CF_UNICODETEXT;
            else if (format == "EnhancedMetafile") return (int)ClipboardFormats.CF_ENHMETAFILE;
            else if (format == "FileDrop") return (int)ClipboardFormats.CF_HDROP;
            else if (format == "Locale") return (int)ClipboardFormats.CF_LOCALE;

            return (int)Win32RegisterClipboardFormat(format);
        }

        //%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        // stuff formerly in XplatUIWin32
        //%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        private void ClipboardClose(IntPtr handle)
        {
            if (handle != clip_magic)
            {
                throw new ArgumentException("handle is not a valid clipboard handle");
            }
            Win32CloseClipboard();
        }

        private IntPtr ClipboardOpen(bool primary_selection)
        {
            // Win32 does not have primary selection
            Win32OpenClipboard(XplatUIWin32.FosterParent);
            return clip_magic;
        }

        private int[] ClipboardAvailableFormats(IntPtr handle)
        {
            uint format;
            int[] result;
            int count;

            if (handle != clip_magic)
            {
                return null;
            }

            // Count first
            count = 0;
            format = 0;
            do
            {
                format = Win32EnumClipboardFormats(format);
                if (format != 0)
                {
                    count++;
                }
            } while (format != 0);

            // Now assign
            result = new int[count];
            count = 0;
            format = 0;
            do
            {
                format = Win32EnumClipboardFormats(format);
                if (format != 0)
                {
                    result[count++] = (int)format;
                }
            } while (format != 0);

            return result;
        }

        private object ClipboardRetrieve(IntPtr handle, int type, ClipboardToObject converter)
        {
            IntPtr hmem;
            IntPtr data;
            object obj;

            if (handle != clip_magic)
            {
                throw new ArgumentException("handle is not a valid clipboard handle");
            }

            hmem = Win32GetClipboardData((uint)type);
            if (hmem == IntPtr.Zero)
            {
                return null;
            }

            data = XplatUIWin32.Win32GlobalLock(hmem);
            if (data == IntPtr.Zero)
            {
                uint error = XplatUIWin32.Win32GetLastError();
                Console.WriteLine("Error: {0}", error);
                return null;
            }

            obj = null;

            if (type == DataFormats.GetFormat(DataFormats.Rtf).Id)
            {
                obj = XplatUIWin32.AnsiToString(data);
            }
            else switch ((ClipboardFormats)type)
                {
                    case ClipboardFormats.CF_TEXT:
                        {
                            obj = XplatUIWin32.AnsiToString(data);
                            break;
                        }

                    case ClipboardFormats.CF_DIB:
                        {
                            obj = XplatUIWin32.DIBtoImage(data);
                            break;
                        }

                    case ClipboardFormats.CF_UNICODETEXT:
                        {
                            obj = XplatUIWin32.UnicodeToString(data);
                            break;
                        }

                    default:
                        {
                            if (converter != null && !converter(type, data, out obj))
                            {
                                obj = null;
                            }
                            break;
                        }
                }
            XplatUIWin32.Win32GlobalUnlock(hmem);

            return obj;
        }

        private void ClipboardStore(IntPtr handle, object obj, int type, ObjectToClipboard converter)
        {
            byte[] data = null;

            if (handle != clip_magic)
            {
                throw new ArgumentException("handle is not a valid clipboard handle");
            }

            if (obj == null)
            {
                // Just clear it
                if (!Win32EmptyClipboard())
                    throw new ExternalException("Win32EmptyClipboard");
                return;
            }

            if (type == -1)
            {
                if (obj is string)
                {
                    type = (int)ClipboardFormats.CF_UNICODETEXT;
                }
                else if (obj is Image)
                {
                    type = (int)ClipboardFormats.CF_DIB;
                }
            }

            if (type == DataFormats.GetFormat(DataFormats.Rtf).Id)
            {
                data = XplatUIWin32.StringToAnsi((string)obj);
            }
            else switch ((ClipboardFormats)type)
                {
                    case ClipboardFormats.CF_UNICODETEXT:
                        {
                            data = XplatUIWin32.StringToUnicode((string)obj);
                            break;
                        }

                    case ClipboardFormats.CF_TEXT:
                        {
                            data = XplatUIWin32.StringToAnsi((string)obj);
                            break;
                        }

                    case ClipboardFormats.CF_BITMAP:
                    case ClipboardFormats.CF_DIB:
                        {
                            data = XplatUIWin32.ImageToDIB((Image)obj);
                            type = (int)ClipboardFormats.CF_DIB;
                            break;
                        }

                    default:
                        {
                            if (converter != null && !converter(ref type, obj, out data))
                            {
                                data = null; // ensure that a failed conversion leaves null.
                            }
                            break;
                        }
                }
            if (data != null)
            {
                SetClipboardData((uint)type, data);
            }
        }

        private void SetClipboardData(uint type, byte[] data)
        {
            if (data.Length == 0)
                // Shouldn't call Win32SetClipboard with NULL, as, from MSDN:
                // "This parameter can be NULL, indicating that the window provides data 
                //  in the specified clipboard format (renders the format) upon request."
                // and I don't think we support that...
                // Note this is unrelated to the fact that passing a null obj to 
                // ClipboardStore is actually a request to empty the clipboard!
                return;
            IntPtr hmem = XplatUIWin32.CopyToMoveableMemory(data);
            if (hmem == IntPtr.Zero)
                // As above, should not call with null.
                // (Not that CopyToMoveableMemory should ever return null!)
                throw new ExternalException("CopyToMoveableMemory failed.");
            if (Win32SetClipboardData(type, hmem) == IntPtr.Zero)
                throw new ExternalException("Win32SetClipboardData");
        }

        [DllImport("user32.dll", EntryPoint = "OpenClipboard", CallingConvention = CallingConvention.StdCall)]
        private extern static bool Win32OpenClipboard(IntPtr hwnd);

        [DllImport("user32.dll", EntryPoint = "EmptyClipboard", CallingConvention = CallingConvention.StdCall)]
        private extern static bool Win32EmptyClipboard();

        [DllImport("user32.dll", EntryPoint = "RegisterClipboardFormatW", CharSet = CharSet.Unicode, CallingConvention = CallingConvention.StdCall)]
        private extern static uint Win32RegisterClipboardFormat(string format);

        [DllImport("user32.dll", EntryPoint = "CloseClipboard", CallingConvention = CallingConvention.StdCall)]
        private extern static bool Win32CloseClipboard();

        [DllImport("user32.dll", EntryPoint = "EnumClipboardFormats", CallingConvention = CallingConvention.StdCall)]
        private extern static uint Win32EnumClipboardFormats(uint format);

        [DllImport("user32.dll", EntryPoint = "GetClipboardData", CallingConvention = CallingConvention.StdCall)]
        private extern static IntPtr Win32GetClipboardData(uint format);

        [DllImport("user32.dll", EntryPoint = "SetClipboardData", CallingConvention = CallingConvention.StdCall)]
        private extern static IntPtr Win32SetClipboardData(uint format, IntPtr handle);

    }
}
