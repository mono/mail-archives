//
// System.Drawing.Graphics.cs
//
// Authors:
//	Gonzalo Paniagua Javier (gonzalo@ximian.com) (stubbed out)
//      Alexandre Pigolkine(pigolkine@gmx.de)
//	Jordi Mas i Hernandez (jordi@ximian.com)
//	Sebastien Pouliot  <sebastien@ximian.com>
//
// Copyright (C) 2003 Ximian, Inc. (http://www.ximian.com)
// Copyright (C) 2004-2006 Novell, Inc. (http://www.novell.com)
//
// Permission is hereby granted, free of charge, to any person obtaining
// a copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to
// permit persons to whom the Software is furnished to do so, subject to
// the following conditions:
// 
// The above copyright notice and this permission notice shall be
// included in all copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
// NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
// LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
// OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
// WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
//
// Updated by:
//  Ralph Leckett <rleckett@gmail.com>
//

using System;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Drawing.Text;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Security.Permissions;
using System.Text;

namespace System.Drawing
{
#if !NET_2_0
	[ComVisible(false)]  
#endif
    public sealed class Graphics : MarshalByRefObject, IDisposable
#if NET_2_0
, IDeviceContext
#endif
    {
        private IntPtr nativeObject;
        private IntPtr _context;
        private bool _keep;

        private bool _disposed = false;
        private static float defDpiX = 0;
        private static float defDpiY = 0;
        private IntPtr deviceContextHdc;

        private void Trace(string from)
        {
            if (_disposed)
                throw new ObjectDisposedException(from, "Graphics object already disposed");
            //Console.WriteLine("Graphics." + from);
        }

#if !NET_2_0
		[ComVisible(false)]
#endif
        public delegate bool EnumerateMetafileProc(
            EmfPlusRecordType recordType,
            int flags,
            int dataSize,
            IntPtr data,
            PlayRecordCallback callbackData);

#if !NET_2_0
		[ComVisible (false)]
#endif
        public delegate bool DrawImageAbort(IntPtr callbackData);

        private Graphics(IntPtr native)
            : this(native, IntPtr.Zero, false)
        {
        }

        private Graphics(IntPtr native, IntPtr context)
            : this(native, context, false)
        {
        }

        private Graphics(IntPtr native, bool keep)
            : this(native, IntPtr.Zero, keep)
        {
        }

        private Graphics(IntPtr native, IntPtr context, bool keep)
        {
            this.nativeObject = native;
            this._context = context;
            this._keep = keep;
        }

        ~Graphics()
        {
            Dispose();
        }

        static internal float systemDpiX
        {
            get
            {
                if (defDpiX == 0)
                {
                    Bitmap bmp = new Bitmap(1, 1);
                    Graphics g = Graphics.FromImage(bmp);
                    defDpiX = g.DpiX;
                    defDpiY = g.DpiY;
                    g.Dispose();
                    bmp.Dispose();
                }
                return defDpiX;
            }
        }

        static internal float systemDpiY
        {
            get
            {
                if (defDpiY == 0)
                {
                    Bitmap bmp = new Bitmap(1, 1);
                    Graphics g = Graphics.FromImage(bmp);
                    defDpiX = g.DpiX;
                    defDpiY = g.DpiY;
                    g.Dispose();
                    bmp.Dispose();
                }
                return defDpiY;
            }
        }

        internal IntPtr NativeObject
        {
            get
            {
                Trace("NativeObject.get");
                return nativeObject;
            }
        }

        [MonoTODO("Metafiles, both WMF and EMF formats, aren't supported.")]
        public void AddMetafileComment(byte[] data)
        {
            throw new NotImplementedException();
        }

        public GraphicsContainer BeginContainer()
        {
            Trace("BeginContainer-1");
            uint state;
            Status status = GDIPlus.GdipBeginContainer2(nativeObject, out state);
            GDIPlus.CheckStatus(status);

            return new GraphicsContainer(state);
        }

        [MonoTODO("The rectangles and unit parameters aren't supported in libgdiplus")]
        public GraphicsContainer BeginContainer(Rectangle dstrect, Rectangle srcrect, GraphicsUnit unit)
        {
            Trace("BeginContainer-2");
            uint state;
            Status status = GDIPlus.GdipBeginContainerI(nativeObject, ref dstrect, ref srcrect, unit, out state);
            GDIPlus.CheckStatus(status);

            return new GraphicsContainer(state);
        }

        [MonoTODO("The rectangles and unit parameters aren't supported in libgdiplus")]
        public GraphicsContainer BeginContainer(RectangleF dstrect, RectangleF srcrect, GraphicsUnit unit)
        {
            Trace("BeginContainer-3");
            uint state;
            Status status = GDIPlus.GdipBeginContainer(nativeObject, ref dstrect, ref srcrect, unit, out state);
            GDIPlus.CheckStatus(status);

            return new GraphicsContainer(state);
        }

        public void Clear(Color color)
        {
            Trace("Clear");
            Status status = GDIPlus.GdipGraphicsClear(nativeObject, color.ToArgb());
            GDIPlus.CheckStatus(status);
        }
#if NET_2_0
        [MonoLimitation("Works on Win32 and on X11 (but not on Cocoa and Quartz)")]
        public void CopyFromScreen(Point upperLeftSource, Point upperLeftDestination, Size blockRegionSize)
        {
            Trace("CopyFromScreen-1/");
            CopyFromScreen(upperLeftSource.X, upperLeftSource.Y, upperLeftDestination.X, upperLeftDestination.Y,
                blockRegionSize, CopyPixelOperation.SourceCopy);
        }

        [MonoLimitation("Works on Win32 and (for CopyPixelOperation.SourceCopy only) on X11 but not on Cocoa and Quartz")]
        public void CopyFromScreen(Point upperLeftSource, Point upperLeftDestination, Size blockRegionSize, CopyPixelOperation copyPixelOperation)
        {
            Trace("CopyFromScreen-2/");
            CopyFromScreen(upperLeftSource.X, upperLeftSource.Y, upperLeftDestination.X, upperLeftDestination.Y,
                blockRegionSize, copyPixelOperation);
        }

        [MonoLimitation("Works on Win32 and on X11 (but not on Cocoa and Quartz)")]
        public void CopyFromScreen(int sourceX, int sourceY, int destinationX, int destinationY, Size blockRegionSize)
        {
            Trace("CopyFromScreen-3/");
            CopyFromScreen(sourceX, sourceY, destinationX, destinationY, blockRegionSize,
                CopyPixelOperation.SourceCopy);
        }

        [MonoLimitation("Works on Win32 and (for CopyPixelOperation.SourceCopy only) on X11 but not on Cocoa and Quartz")]
        public void CopyFromScreen(int sourceX, int sourceY, int destinationX, int destinationY, Size blockRegionSize, CopyPixelOperation copyPixelOperation)
        {
            Trace("CopyFromScreen-4/");
            if (!Enum.IsDefined(typeof(CopyPixelOperation), copyPixelOperation))
                throw new InvalidEnumArgumentException(Locale.GetText("Enum argument value '{0}' is not valid for CopyPixelOperation", copyPixelOperation));

            if (GDIPlus.UseX11Drawable)
            {
                CopyFromScreenX11(sourceX, sourceY, destinationX, destinationY, blockRegionSize, copyPixelOperation);
            }
            else if (GDIPlus.UseCarbonDrawable)
            {
                CopyFromScreenMac(sourceX, sourceY, destinationX, destinationY, blockRegionSize, copyPixelOperation);
            }
            else
            {
                CopyFromScreenWin32(sourceX, sourceY, destinationX, destinationY, blockRegionSize, copyPixelOperation);
            }
        }

        private void CopyFromScreenWin32(int sourceX, int sourceY, int destinationX, int destinationY, Size blockRegionSize, CopyPixelOperation copyPixelOperation)
        {
            IntPtr window = GDIPlus.GetDesktopWindow();
            IntPtr srcDC = GDIPlus.GetDC(window);
            IntPtr dstDC = GetHdc();

            GDIPlus.BitBlt(dstDC, destinationX, destinationY, blockRegionSize.Width,
                blockRegionSize.Height, srcDC, sourceX, sourceY, (int)copyPixelOperation);

            GDIPlus.ReleaseDC(IntPtr.Zero, srcDC);
            ReleaseHdc(dstDC);
        }

        private void CopyFromScreenMac(int sourceX, int sourceY, int destinationX, int destinationY, Size blockRegionSize, CopyPixelOperation copyPixelOperation)
        {
            throw new NotImplementedException();
        }

        private void CopyFromScreenX11(int sourceX, int sourceY, int destinationX, int destinationY, Size blockRegionSize, CopyPixelOperation copyPixelOperation)
        {
            int AllPlanes = ~0, nitems = 0, pixel;

            if (copyPixelOperation != CopyPixelOperation.SourceCopy)
                throw new NotImplementedException("Operation not implemented under X11");

            if (GDIPlus.Display == IntPtr.Zero)
                GDIPlus.Display = GDIPlus.XOpenDisplay(IntPtr.Zero);

            IntPtr window = GDIPlus.XRootWindow(GDIPlus.Display, 0);
            IntPtr defvisual = GDIPlus.XDefaultVisual(GDIPlus.Display, 0);
            XVisualInfo visual = new XVisualInfo();

            /* Get XVisualInfo for this visual */
            visual.visualid = GDIPlus.XVisualIDFromVisual(defvisual);
            IntPtr vPtr = GDIPlus.XGetVisualInfo(GDIPlus.Display, 0x1 /* VisualIDMask */, ref visual, ref nitems);
            visual = (XVisualInfo)Marshal.PtrToStructure(vPtr, typeof(XVisualInfo));
#if false
			Console.WriteLine ("visual\t{0}", visual.visual);
			Console.WriteLine ("visualid\t{0}", visual.visualid);
			Console.WriteLine ("screen\t{0}", visual.screen);
			Console.WriteLine ("depth\t{0}", visual.depth);
			Console.WriteLine ("klass\t{0}", visual.klass);
			Console.WriteLine ("red_mask\t{0:X}", visual.red_mask);
			Console.WriteLine ("green_mask\t{0:X}", visual.green_mask);
			Console.WriteLine ("blue_mask\t{0:X}", visual.blue_mask);
			Console.WriteLine ("colormap_size\t{0}", visual.colormap_size);
			Console.WriteLine ("bits_per_rgb\t{0}", visual.bits_per_rgb);
#endif
            IntPtr image = GDIPlus.XGetImage(GDIPlus.Display, window, sourceX, sourceY, blockRegionSize.Width,
                blockRegionSize.Height, AllPlanes, 2 /* ZPixmap*/);

            Bitmap bmp = new Bitmap(blockRegionSize.Width, blockRegionSize.Height);
            int red, blue, green;
            int red_mask = (int)visual.red_mask;
            int blue_mask = (int)visual.blue_mask;
            int green_mask = (int)visual.green_mask;
            for (int y = 0; y < blockRegionSize.Height; y++)
            {
                for (int x = 0; x < blockRegionSize.Width; x++)
                {
                    pixel = GDIPlus.XGetPixel(image, x, y);

                    switch (visual.depth)
                    {
                        case 16: /* 16bbp pixel transformation */
                            red = (int)((pixel & red_mask) >> 8) & 0xff;
                            green = (int)(((pixel & green_mask) >> 3)) & 0xff;
                            blue = (int)((pixel & blue_mask) << 3) & 0xff;
                            break;
                        case 24:
                        case 32:
                            red = (int)((pixel & red_mask) >> 16) & 0xff;
                            green = (int)(((pixel & green_mask) >> 8)) & 0xff;
                            blue = (int)((pixel & blue_mask)) & 0xff;
                            break;
                        default:
                            string text = Locale.GetText("{0}bbp depth not supported.", visual.depth);
                            throw new NotImplementedException(text);
                    }

                    bmp.SetPixel(x, y, Color.FromArgb(255, red, green, blue));
                }
            }

            DrawImage(bmp, destinationX, destinationY);
            bmp.Dispose();
            GDIPlus.XDestroyImage(image);
            GDIPlus.XFree(vPtr);
        }
#endif

        public void Dispose()
        {
            if (!_disposed && !_keep)
            {
                if (GDIPlus.UseCarbonDrawable && _context != IntPtr.Zero)
                {
                    Flush();
                    Carbon.ReleaseContext(_context);
                }

                Status status = GDIPlus.GdipDeleteGraphics(nativeObject);
                GDIPlus.CheckStatus(status);
                nativeObject = IntPtr.Zero;

                GC.SuppressFinalize(this);
                _disposed = true;
            }
        }


        public void DrawArc(Pen pen, Rectangle rect, float startAngle, float sweepAngle)
        {
            Trace("DrawArc-1/");
            DrawArc(pen, rect.X, rect.Y, rect.Width, rect.Height, startAngle, sweepAngle);
        }


        public void DrawArc(Pen pen, RectangleF rect, float startAngle, float sweepAngle)
        {
            Trace("DrawArc-2/");
            DrawArc(pen, rect.X, rect.Y, rect.Width, rect.Height, startAngle, sweepAngle);
        }


        public void DrawArc(Pen pen, float x, float y, float width, float height, float startAngle, float sweepAngle)
        {
            Trace("DrawArc-3");
            if (pen == null)
                throw new ArgumentNullException("pen");

            Status status = GDIPlus.GdipDrawArc(nativeObject, pen.nativeObject,
                                        x, y, width, height, startAngle, sweepAngle);
            GDIPlus.CheckStatus(status);
        }

        // Microsoft documentation states that the signature for this member should be
        // public void DrawArc( Pen pen,  int x,  int y,  int width,  int height,   int startAngle,
        // int sweepAngle. However, GdipDrawArcI uses also float for the startAngle and sweepAngle params
        public void DrawArc(Pen pen, int x, int y, int width, int height, int startAngle, int sweepAngle)
        {
            Trace("DrawArc-4");
            if (pen == null)
                throw new ArgumentNullException("pen");
            Status status = GDIPlus.GdipDrawArcI(nativeObject, pen.nativeObject,
                        x, y, width, height, startAngle, sweepAngle);
            GDIPlus.CheckStatus(status);
        }

        public void DrawBezier(Pen pen, PointF pt1, PointF pt2, PointF pt3, PointF pt4)
        {
            Trace("DrawBezier-1");
            if (pen == null)
                throw new ArgumentNullException("pen");
            Status status = GDIPlus.GdipDrawBezier(nativeObject, pen.nativeObject,
                            pt1.X, pt1.Y, pt2.X, pt2.Y, pt3.X,
                            pt3.Y, pt4.X, pt4.Y);
            GDIPlus.CheckStatus(status);
        }

        public void DrawBezier(Pen pen, Point pt1, Point pt2, Point pt3, Point pt4)
        {
            Trace("DrawBezier-2");
            if (pen == null)
                throw new ArgumentNullException("pen");
            Status status = GDIPlus.GdipDrawBezierI(nativeObject, pen.nativeObject,
                            pt1.X, pt1.Y, pt2.X, pt2.Y, pt3.X,
                            pt3.Y, pt4.X, pt4.Y);
            GDIPlus.CheckStatus(status);
        }

        public void DrawBezier(Pen pen, float x1, float y1, float x2, float y2, float x3, float y3, float x4, float y4)
        {
            Trace("DrawBezier-3");
            if (pen == null)
                throw new ArgumentNullException("pen");
            Status status = GDIPlus.GdipDrawBezier(nativeObject, pen.nativeObject, x1,
                            y1, x2, y2, x3, y3, x4, y4);
            GDIPlus.CheckStatus(status);
        }

        public void DrawBeziers(Pen pen, Point[] points)
        {
            Trace("DrawBeziers-1");
            if (pen == null)
                throw new ArgumentNullException("pen");
            if (points == null)
                throw new ArgumentNullException("points");

            int length = points.Length;

            if (length < 4)
                return;

            for (int i = 0; i < length - 1; i += 3)
            {
                Point p1 = points[i];
                Point p2 = points[i + 1];
                Point p3 = points[i + 2];
                Point p4 = points[i + 3];

                Status status = GDIPlus.GdipDrawBezier(
                    nativeObject, pen.nativeObject,
                    p1.X, p1.Y, p2.X, p2.Y,
                    p3.X, p3.Y, p4.X, p4.Y);
                GDIPlus.CheckStatus(status);
            }
        }

        public void DrawBeziers(Pen pen, PointF[] points)
        {
            Trace("DrawBeziers-2");
            if (pen == null)
                throw new ArgumentNullException("pen");
            if (points == null)
                throw new ArgumentNullException("points");

            int length = points.Length;

            if (length < 4)
                return;

            for (int i = 0; i < length - 1; i += 3)
            {
                PointF p1 = points[i];
                PointF p2 = points[i + 1];
                PointF p3 = points[i + 2];
                PointF p4 = points[i + 3];

                Status status = GDIPlus.GdipDrawBezier(
                    nativeObject, pen.nativeObject,
                    p1.X, p1.Y, p2.X, p2.Y,
                    p3.X, p3.Y, p4.X, p4.Y);
                GDIPlus.CheckStatus(status);
            }
        }


        public void DrawClosedCurve(Pen pen, PointF[] points)
        {
            Trace("DrawClosedCurve-1");
            if (pen == null)
                throw new ArgumentNullException("pen");
            if (points == null)
                throw new ArgumentNullException("points");

            Status status = GDIPlus.GdipDrawClosedCurve(nativeObject, pen.nativeObject, points, points.Length);
            GDIPlus.CheckStatus(status);
        }

        public void DrawClosedCurve(Pen pen, Point[] points)
        {
            Trace("DrawClosedCurve-2");
            if (pen == null)
                throw new ArgumentNullException("pen");
            if (points == null)
                throw new ArgumentNullException("points");

            Status status = GDIPlus.GdipDrawClosedCurveI(nativeObject, pen.nativeObject, points, points.Length);
            GDIPlus.CheckStatus(status);
        }

        // according to MSDN fillmode "is required but ignored" which makes _some_ sense since the unmanaged 
        // GDI+ call doesn't support it (issue spotted using Gendarme's AvoidUnusedParametersRule)
        public void DrawClosedCurve(Pen pen, Point[] points, float tension, FillMode fillmode)
        {
            Trace("DrawClosedCurve-3");
            if (pen == null)
                throw new ArgumentNullException("pen");
            if (points == null)
                throw new ArgumentNullException("points");

            Status status = GDIPlus.GdipDrawClosedCurve2I(nativeObject, pen.nativeObject, points, points.Length, tension);
            GDIPlus.CheckStatus(status);
        }

        // according to MSDN fillmode "is required but ignored" which makes _some_ sense since the unmanaged 
        // GDI+ call doesn't support it (issue spotted using Gendarme's AvoidUnusedParametersRule)
        public void DrawClosedCurve(Pen pen, PointF[] points, float tension, FillMode fillmode)
        {
            Trace("DrawClosedCurve-4");
            if (pen == null)
                throw new ArgumentNullException("pen");
            if (points == null)
                throw new ArgumentNullException("points");

            Status status = GDIPlus.GdipDrawClosedCurve2(nativeObject, pen.nativeObject, points, points.Length, tension);
            GDIPlus.CheckStatus(status);
        }

        public void DrawCurve(Pen pen, Point[] points)
        {
            Trace("DrawCurve-1");
            if (pen == null)
                throw new ArgumentNullException("pen");
            if (points == null)
                throw new ArgumentNullException("points");

            Status status = GDIPlus.GdipDrawCurveI(nativeObject, pen.nativeObject, points, points.Length);
            GDIPlus.CheckStatus(status);
        }

        public void DrawCurve(Pen pen, PointF[] points)
        {
            Trace("DrawCurve-2");
            if (pen == null)
                throw new ArgumentNullException("pen");
            if (points == null)
                throw new ArgumentNullException("points");

            Status status = GDIPlus.GdipDrawCurve(nativeObject, pen.nativeObject, points, points.Length);
            GDIPlus.CheckStatus(status);
        }

        public void DrawCurve(Pen pen, PointF[] points, float tension)
        {
            Trace("DrawCurve-3");
            if (pen == null)
                throw new ArgumentNullException("pen");
            if (points == null)
                throw new ArgumentNullException("points");

            Status status = GDIPlus.GdipDrawCurve2(nativeObject, pen.nativeObject, points, points.Length, tension);
            GDIPlus.CheckStatus(status);
        }

        public void DrawCurve(Pen pen, Point[] points, float tension)
        {
            Trace("DrawCurve-4");
            if (pen == null)
                throw new ArgumentNullException("pen");
            if (points == null)
                throw new ArgumentNullException("points");

            Status status = GDIPlus.GdipDrawCurve2I(nativeObject, pen.nativeObject, points, points.Length, tension);
            GDIPlus.CheckStatus(status);
        }

        public void DrawCurve(Pen pen, PointF[] points, int offset, int numberOfSegments)
        {
            Trace("DrawCurve-5");
            if (pen == null)
                throw new ArgumentNullException("pen");
            if (points == null)
                throw new ArgumentNullException("points");

            Status status = GDIPlus.GdipDrawCurve3(nativeObject, pen.nativeObject,
                            points, points.Length, offset,
                            numberOfSegments, 0.5f);
            GDIPlus.CheckStatus(status);
        }

        public void DrawCurve(Pen pen, Point[] points, int offset, int numberOfSegments, float tension)
        {
            Trace("DrawCurve-6");
            if (pen == null)
                throw new ArgumentNullException("pen");
            if (points == null)
                throw new ArgumentNullException("points");

            Status status = GDIPlus.GdipDrawCurve3I(nativeObject, pen.nativeObject,
                            points, points.Length, offset,
                            numberOfSegments, tension);
            GDIPlus.CheckStatus(status);
        }

        public void DrawCurve(Pen pen, PointF[] points, int offset, int numberOfSegments, float tension)
        {
            Trace("DrawCurve-7");
            if (pen == null)
                throw new ArgumentNullException("pen");
            if (points == null)
                throw new ArgumentNullException("points");

            Status status = GDIPlus.GdipDrawCurve3(nativeObject, pen.nativeObject,
                            points, points.Length, offset,
                            numberOfSegments, tension);
            GDIPlus.CheckStatus(status);
        }

        public void DrawEllipse(Pen pen, Rectangle rect)
        {
            Trace("DrawEllipse-1/");
            if (pen == null)
                throw new ArgumentNullException("pen");

            DrawEllipse(pen, rect.X, rect.Y, rect.Width, rect.Height);
        }

        public void DrawEllipse(Pen pen, RectangleF rect)
        {
            Trace("DrawEllipse-2/");
            if (pen == null)
                throw new ArgumentNullException("pen");
            DrawEllipse(pen, rect.X, rect.Y, rect.Width, rect.Height);
        }

        public void DrawEllipse(Pen pen, int x, int y, int width, int height)
        {
            Trace("DrawEllipse-3");
            if (pen == null)
                throw new ArgumentNullException("pen");
            Status status = GDIPlus.GdipDrawEllipseI(nativeObject, pen.nativeObject, x, y, width, height);
            GDIPlus.CheckStatus(status);
        }

        public void DrawEllipse(Pen pen, float x, float y, float width, float height)
        {
            Trace("DrawEllipse-4");
            if (pen == null)
                throw new ArgumentNullException("pen");
            Status status = GDIPlus.GdipDrawEllipse(nativeObject, pen.nativeObject, x, y, width, height);
            GDIPlus.CheckStatus(status);
        }

        public void DrawIcon(Icon icon, Rectangle targetRect)
        {
            Trace("DrawIcon-1/");
            if (icon == null)
                throw new ArgumentNullException("icon");

            DrawImage(icon.GetInternalBitmap(), targetRect);
        }

        public void DrawIcon(Icon icon, int x, int y)
        {
            Trace("DrawIcon-2/");
            if (icon == null)
                throw new ArgumentNullException("icon");

            DrawImage(icon.GetInternalBitmap(), x, y);
        }

        public void DrawIconUnstretched(Icon icon, Rectangle targetRect)
        {
            Trace("DrawIconUnstretched/");
            if (icon == null)
                throw new ArgumentNullException("icon");

            DrawImageUnscaled(icon.GetInternalBitmap(), targetRect);
        }

        public void DrawImage(Image image, RectangleF rect)
        {
            Trace("DrawImage-1");
            if (image == null)
                throw new ArgumentNullException("image");

            Status status = GDIPlus.GdipDrawImageRect(nativeObject, image.NativeObject, rect.X, rect.Y, rect.Width, rect.Height);
            GDIPlus.CheckStatus(status);
        }

        public void DrawImage(Image image, PointF point)
        {
            Trace("DrawImage-2");
            if (image == null)
                throw new ArgumentNullException("image");

            Status status = GDIPlus.GdipDrawImage(nativeObject, image.NativeObject, point.X, point.Y);
            GDIPlus.CheckStatus(status);
        }

        public void DrawImage(Image image, Point[] destPoints)
        {
            Trace("DrawImage-3");
            if (image == null)
                throw new ArgumentNullException("image");
            if (destPoints == null)
                throw new ArgumentNullException("destPoints");

            Status status = GDIPlus.GdipDrawImagePointsI(nativeObject, image.NativeObject, destPoints, destPoints.Length);
            GDIPlus.CheckStatus(status);
        }

        public void DrawImage(Image image, Point point)
        {
            Trace("DrawImage-4/");
            if (image == null)
                throw new ArgumentNullException("image");
            DrawImage(image, point.X, point.Y);
        }

        public void DrawImage(Image image, Rectangle rect)
        {
            Trace("DrawImage-5/");
            if (image == null)
                throw new ArgumentNullException("image");
            DrawImage(image, rect.X, rect.Y, rect.Width, rect.Height);
        }

        public void DrawImage(Image image, PointF[] destPoints)
        {
            Trace("DrawImage-6");
            if (image == null)
                throw new ArgumentNullException("image");
            if (destPoints == null)
                throw new ArgumentNullException("destPoints");
            Status status = GDIPlus.GdipDrawImagePoints(nativeObject, image.NativeObject, destPoints, destPoints.Length);
            GDIPlus.CheckStatus(status);
        }

        public void DrawImage(Image image, int x, int y)
        {
            Trace("DrawImage-7");
            if (image == null)
                throw new ArgumentNullException("image");
            Status status = GDIPlus.GdipDrawImageI(nativeObject, image.NativeObject, x, y);
            GDIPlus.CheckStatus(status);
        }

        public void DrawImage(Image image, float x, float y)
        {
            Trace("DrawImage-8");
            if (image == null)
                throw new ArgumentNullException("image");
            Status status = GDIPlus.GdipDrawImage(nativeObject, image.NativeObject, x, y);
            GDIPlus.CheckStatus(status);
        }

        public void DrawImage(Image image, Rectangle destRect, Rectangle srcRect, GraphicsUnit srcUnit)
        {
            Trace("DrawImage-9");
            if (image == null)
                throw new ArgumentNullException("image");
            Status status = GDIPlus.GdipDrawImageRectRectI(nativeObject, image.NativeObject,
                destRect.X, destRect.Y, destRect.Width, destRect.Height,
                srcRect.X, srcRect.Y, srcRect.Width, srcRect.Height,
                srcUnit, IntPtr.Zero, null, IntPtr.Zero);
            GDIPlus.CheckStatus(status);
        }

        public void DrawImage(Image image, RectangleF destRect, RectangleF srcRect, GraphicsUnit srcUnit)
        {
            Trace("DrawImage-10");
            if (image == null)
                throw new ArgumentNullException("image");
            Status status = GDIPlus.GdipDrawImageRectRect(nativeObject, image.NativeObject,
                destRect.X, destRect.Y, destRect.Width, destRect.Height,
                srcRect.X, srcRect.Y, srcRect.Width, srcRect.Height,
                srcUnit, IntPtr.Zero, null, IntPtr.Zero);
            GDIPlus.CheckStatus(status);
        }

        public void DrawImage(Image image, Point[] destPoints, Rectangle srcRect, GraphicsUnit srcUnit)
        {
            Trace("DrawImage-11");
            if (image == null)
                throw new ArgumentNullException("image");
            if (destPoints == null)
                throw new ArgumentNullException("destPoints");

            Status status = GDIPlus.GdipDrawImagePointsRectI(nativeObject, image.NativeObject,
                destPoints, destPoints.Length, srcRect.X, srcRect.Y,
                srcRect.Width, srcRect.Height, srcUnit, IntPtr.Zero,
                null, IntPtr.Zero);
            GDIPlus.CheckStatus(status);
        }

        public void DrawImage(Image image, PointF[] destPoints, RectangleF srcRect, GraphicsUnit srcUnit)
        {
            Trace("DrawImage-12");
            if (image == null)
                throw new ArgumentNullException("image");
            if (destPoints == null)
                throw new ArgumentNullException("destPoints");

            Status status = GDIPlus.GdipDrawImagePointsRect(nativeObject, image.NativeObject,
                destPoints, destPoints.Length, srcRect.X, srcRect.Y,
                srcRect.Width, srcRect.Height, srcUnit, IntPtr.Zero,
                null, IntPtr.Zero);
            GDIPlus.CheckStatus(status);
        }

        public void DrawImage(Image image, Point[] destPoints, Rectangle srcRect, GraphicsUnit srcUnit,
                                ImageAttributes imageAttr)
        {
            Trace("DrawImage-13");
            if (image == null)
                throw new ArgumentNullException("image");
            if (destPoints == null)
                throw new ArgumentNullException("destPoints");
            Status status = GDIPlus.GdipDrawImagePointsRectI(nativeObject, image.NativeObject,
                destPoints, destPoints.Length, srcRect.X, srcRect.Y,
                srcRect.Width, srcRect.Height, srcUnit,
                imageAttr != null ? imageAttr.NativeObject : IntPtr.Zero, null, IntPtr.Zero);
            GDIPlus.CheckStatus(status);
        }

        public void DrawImage(Image image, float x, float y, float width, float height)
        {
            Trace("DrawImage-14");
            if (image == null)
                throw new ArgumentNullException("image");
            Status status = GDIPlus.GdipDrawImageRect(nativeObject, image.NativeObject, x, y,
                           width, height);
            GDIPlus.CheckStatus(status);
        }

        public void DrawImage(Image image, PointF[] destPoints, RectangleF srcRect, GraphicsUnit srcUnit,
                                ImageAttributes imageAttr)
        {
            Trace("DrawImage-15");
            if (image == null)
                throw new ArgumentNullException("image");
            if (destPoints == null)
                throw new ArgumentNullException("destPoints");
            Status status = GDIPlus.GdipDrawImagePointsRect(nativeObject, image.NativeObject,
                destPoints, destPoints.Length, srcRect.X, srcRect.Y,
                srcRect.Width, srcRect.Height, srcUnit,
                imageAttr != null ? imageAttr.NativeObject : IntPtr.Zero, null, IntPtr.Zero);
            GDIPlus.CheckStatus(status);
        }

        public void DrawImage(Image image, int x, int y, Rectangle srcRect, GraphicsUnit srcUnit)
        {
            Trace("DrawImage-16");
            if (image == null)
                throw new ArgumentNullException("image");
            Status status = GDIPlus.GdipDrawImagePointRectI(nativeObject, image.NativeObject, x, y, srcRect.X, srcRect.Y, srcRect.Width, srcRect.Height, srcUnit);
            GDIPlus.CheckStatus(status);
        }

        public void DrawImage(Image image, int x, int y, int width, int height)
        {
            Trace("DrawImage-17");
            if (image == null)
                throw new ArgumentNullException("image");
            Status status = GDIPlus.GdipDrawImageRectI(nativeObject, image.nativeObject, x, y, width, height);
            GDIPlus.CheckStatus(status);
        }

        public void DrawImage(Image image, float x, float y, RectangleF srcRect, GraphicsUnit srcUnit)
        {
            Trace("DrawImage-18");
            if (image == null)
                throw new ArgumentNullException("image");
            Status status = GDIPlus.GdipDrawImagePointRect(nativeObject, image.nativeObject, x, y, srcRect.X, srcRect.Y, srcRect.Width, srcRect.Height, srcUnit);
            GDIPlus.CheckStatus(status);
        }

        public void DrawImage(Image image, PointF[] destPoints, RectangleF srcRect, GraphicsUnit srcUnit, ImageAttributes imageAttr, DrawImageAbort callback)
        {
            Trace("DrawImage-19");
            if (image == null)
                throw new ArgumentNullException("image");
            if (destPoints == null)
                throw new ArgumentNullException("destPoints");
            Status status = GDIPlus.GdipDrawImagePointsRect(nativeObject, image.NativeObject,
                destPoints, destPoints.Length, srcRect.X, srcRect.Y,
                srcRect.Width, srcRect.Height, srcUnit,
                imageAttr != null ? imageAttr.NativeObject : IntPtr.Zero, callback, IntPtr.Zero);
            GDIPlus.CheckStatus(status);
        }

        public void DrawImage(Image image, Point[] destPoints, Rectangle srcRect, GraphicsUnit srcUnit, ImageAttributes imageAttr, DrawImageAbort callback)
        {
            Trace("DrawImage-20");
            if (image == null)
                throw new ArgumentNullException("image");
            if (destPoints == null)
                throw new ArgumentNullException("destPoints");

            Status status = GDIPlus.GdipDrawImagePointsRectI(nativeObject, image.NativeObject,
                destPoints, destPoints.Length, srcRect.X, srcRect.Y,
                srcRect.Width, srcRect.Height, srcUnit,
                imageAttr != null ? imageAttr.NativeObject : IntPtr.Zero, callback, IntPtr.Zero);
            GDIPlus.CheckStatus(status);
        }

        public void DrawImage(Image image, Point[] destPoints, Rectangle srcRect, GraphicsUnit srcUnit, ImageAttributes imageAttr, DrawImageAbort callback, int callbackData)
        {
            Trace("DrawImage-21");
            if (image == null)
                throw new ArgumentNullException("image");
            if (destPoints == null)
                throw new ArgumentNullException("destPoints");

            Status status = GDIPlus.GdipDrawImagePointsRectI(nativeObject, image.NativeObject,
                destPoints, destPoints.Length, srcRect.X, srcRect.Y,
                srcRect.Width, srcRect.Height, srcUnit,
                imageAttr != null ? imageAttr.NativeObject : IntPtr.Zero, callback, (IntPtr)callbackData);
            GDIPlus.CheckStatus(status);
        }

        public void DrawImage(Image image, Rectangle destRect, float srcX, float srcY, float srcWidth, float srcHeight, GraphicsUnit srcUnit)
        {
            Trace("DrawImage-22");
            if (image == null)
                throw new ArgumentNullException("image");
            Status status = GDIPlus.GdipDrawImageRectRect(nativeObject, image.NativeObject,
                                destRect.X, destRect.Y, destRect.Width, destRect.Height,
                            srcX, srcY, srcWidth, srcHeight, srcUnit, IntPtr.Zero,
                            null, IntPtr.Zero);
            GDIPlus.CheckStatus(status);
        }

        public void DrawImage(Image image, PointF[] destPoints, RectangleF srcRect, GraphicsUnit srcUnit, ImageAttributes imageAttr, DrawImageAbort callback, int callbackData)
        {
            Trace("DrawImage-23");
            Status status = GDIPlus.GdipDrawImagePointsRect(nativeObject, image.NativeObject,
                destPoints, destPoints.Length, srcRect.X, srcRect.Y,
                srcRect.Width, srcRect.Height, srcUnit,
                imageAttr != null ? imageAttr.NativeObject : IntPtr.Zero, callback, (IntPtr)callbackData);
            GDIPlus.CheckStatus(status);
        }

        public void DrawImage(Image image, Rectangle destRect, int srcX, int srcY, int srcWidth, int srcHeight, GraphicsUnit srcUnit)
        {
            Trace("DrawImage-24");
            if (image == null)
                throw new ArgumentNullException("image");
            Status status = GDIPlus.GdipDrawImageRectRectI(nativeObject, image.NativeObject,
                                destRect.X, destRect.Y, destRect.Width, destRect.Height,
                            srcX, srcY, srcWidth, srcHeight, srcUnit, IntPtr.Zero,
                            null, IntPtr.Zero);
            GDIPlus.CheckStatus(status);
        }

        public void DrawImage(Image image, Rectangle destRect, float srcX, float srcY, float srcWidth, float srcHeight, GraphicsUnit srcUnit, ImageAttributes imageAttrs)
        {
            Trace("DrawImage-25");
            if (image == null)
                throw new ArgumentNullException("image");
            Status status = GDIPlus.GdipDrawImageRectRect(nativeObject, image.NativeObject,
                                destRect.X, destRect.Y, destRect.Width, destRect.Height,
                            srcX, srcY, srcWidth, srcHeight, srcUnit,
                imageAttrs != null ? imageAttrs.NativeObject : IntPtr.Zero, null, IntPtr.Zero);
            GDIPlus.CheckStatus(status);
        }

        public void DrawImage(Image image, Rectangle destRect, int srcX, int srcY, int srcWidth, int srcHeight, GraphicsUnit srcUnit, ImageAttributes imageAttr)
        {
            Trace("DrawImage-26");
            if (image == null)
                throw new ArgumentNullException("image");
            Status status = GDIPlus.GdipDrawImageRectRectI(nativeObject, image.NativeObject,
                                        destRect.X, destRect.Y, destRect.Width,
                    destRect.Height, srcX, srcY, srcWidth, srcHeight,
                    srcUnit, imageAttr != null ? imageAttr.NativeObject : IntPtr.Zero, null, IntPtr.Zero);
            GDIPlus.CheckStatus(status);
        }

        public void DrawImage(Image image, Rectangle destRect, int srcX, int srcY, int srcWidth, int srcHeight, GraphicsUnit srcUnit, ImageAttributes imageAttr, DrawImageAbort callback)
        {
            Trace("DrawImage-27");
            if (image == null)
                throw new ArgumentNullException("image");
            Status status = GDIPlus.GdipDrawImageRectRectI(nativeObject, image.NativeObject,
                                        destRect.X, destRect.Y, destRect.Width,
                    destRect.Height, srcX, srcY, srcWidth, srcHeight,
                    srcUnit, imageAttr != null ? imageAttr.NativeObject : IntPtr.Zero, callback,
                    IntPtr.Zero);
            GDIPlus.CheckStatus(status);
        }

        public void DrawImage(Image image, Rectangle destRect, float srcX, float srcY, float srcWidth, float srcHeight, GraphicsUnit srcUnit, ImageAttributes imageAttrs, DrawImageAbort callback)
        {
            Trace("DrawImage-28");
            if (image == null)
                throw new ArgumentNullException("image");
            Status status = GDIPlus.GdipDrawImageRectRect(nativeObject, image.NativeObject,
                                        destRect.X, destRect.Y, destRect.Width,
                    destRect.Height, srcX, srcY, srcWidth, srcHeight,
                    srcUnit, imageAttrs != null ? imageAttrs.NativeObject : IntPtr.Zero,
                    callback, IntPtr.Zero);
            GDIPlus.CheckStatus(status);
        }

        public void DrawImage(Image image, Rectangle destRect, float srcX, float srcY, float srcWidth, float srcHeight, GraphicsUnit srcUnit, ImageAttributes imageAttrs, DrawImageAbort callback, IntPtr callbackData)
        {
            Trace("DrawImage-29");
            if (image == null)
                throw new ArgumentNullException("image");
            Status status = GDIPlus.GdipDrawImageRectRect(nativeObject, image.NativeObject,
                destRect.X, destRect.Y, destRect.Width, destRect.Height,
                srcX, srcY, srcWidth, srcHeight, srcUnit,
                imageAttrs != null ? imageAttrs.NativeObject : IntPtr.Zero, callback, callbackData);
            GDIPlus.CheckStatus(status);
        }

        public void DrawImage(Image image, Rectangle destRect, int srcX, int srcY, int srcWidth, int srcHeight, GraphicsUnit srcUnit, ImageAttributes imageAttrs, DrawImageAbort callback, IntPtr callbackData)
        {
            Trace("DrawImage-30");
            if (image == null)
                throw new ArgumentNullException("image");
            Status status = GDIPlus.GdipDrawImageRectRect(nativeObject, image.NativeObject,
                            destRect.X, destRect.Y, destRect.Width, destRect.Height,
                srcX, srcY, srcWidth, srcHeight, srcUnit,
                imageAttrs != null ? imageAttrs.NativeObject : IntPtr.Zero, callback, callbackData);
            GDIPlus.CheckStatus(status);
        }

        public void DrawImageUnscaled(Image image, Point point)
        {
            Trace("DrawImageUnscaled-1/");
            DrawImageUnscaled(image, point.X, point.Y);
        }

        public void DrawImageUnscaled(Image image, Rectangle rect)
        {
            Trace("DrawImageUnscaled-2/");
            DrawImageUnscaled(image, rect.X, rect.Y, rect.Width, rect.Height);
        }

        public void DrawImageUnscaled(Image image, int x, int y)
        {
            Trace("DrawImageUnscaled-3/");
            if (image == null)
                throw new ArgumentNullException("image");
            DrawImage(image, x, y, image.Width, image.Height);
        }

        public void DrawImageUnscaled(Image image, int x, int y, int width, int height)
        {
            Trace("DrawImageUnscaled-4/");
            if (image == null)
                throw new ArgumentNullException("image");

            // avoid creating an empty, or negative w/h, bitmap...
            if ((width <= 0) || (height <= 0))
                return;

            using (Image tmpImg = new Bitmap(width, height))
            {
                using (Graphics g = FromImage(tmpImg))
                {
                    g.DrawImage(image, 0, 0, image.Width, image.Height);
                    DrawImage(tmpImg, x, y, width, height);
                }
            }
        }

#if NET_2_0
        public void DrawImageUnscaledAndClipped(Image image, Rectangle rect)
        {
            Trace("DrawImageUnscaledAndClipped/");
            if (image == null)
                throw new ArgumentNullException("image");

            int width = (image.Width > rect.Width) ? rect.Width : image.Width;
            int height = (image.Height > rect.Height) ? rect.Height : image.Height;

            DrawImageUnscaled(image, rect.X, rect.Y, width, height);
        }
#endif

        public void DrawLine(Pen pen, PointF pt1, PointF pt2)
        {
            Trace("DrawLine-1");
            if (pen == null)
                throw new ArgumentNullException("pen");
            Status status = GDIPlus.GdipDrawLine(nativeObject, pen.nativeObject,
                            pt1.X, pt1.Y, pt2.X, pt2.Y);
            GDIPlus.CheckStatus(status);
        }

        public void DrawLine(Pen pen, Point pt1, Point pt2)
        {
            Trace("DrawLine-2");
            if (pen == null)
                throw new ArgumentNullException("pen");
            Status status = GDIPlus.GdipDrawLineI(nativeObject, pen.nativeObject,
                            pt1.X, pt1.Y, pt2.X, pt2.Y);
            GDIPlus.CheckStatus(status);
        }

        public void DrawLine(Pen pen, int x1, int y1, int x2, int y2)
        {
            Trace("DrawLine-3");
            if (pen == null)
                throw new ArgumentNullException("pen");
            Status status = GDIPlus.GdipDrawLineI(nativeObject, pen.nativeObject, x1, y1, x2, y2);
            GDIPlus.CheckStatus(status);
        }

        public void DrawLine(Pen pen, float x1, float y1, float x2, float y2)
        {
            Trace("DrawLine-4");
            if (pen == null)
                throw new ArgumentNullException("pen");
            Status status = GDIPlus.GdipDrawLine(nativeObject, pen.nativeObject, x1, y1, x2, y2);
            GDIPlus.CheckStatus(status);
        }

        public void DrawLines(Pen pen, PointF[] points)
        {
            Trace("DrawLines-1");
            if (pen == null)
                throw new ArgumentNullException("pen");
            if (points == null)
                throw new ArgumentNullException("points");
            Status status = GDIPlus.GdipDrawLines(nativeObject, pen.nativeObject, points, points.Length);
            GDIPlus.CheckStatus(status);
        }

        public void DrawLines(Pen pen, Point[] points)
        {
            Trace("DrawLines-2");
            if (pen == null)
                throw new ArgumentNullException("pen");
            if (points == null)
                throw new ArgumentNullException("points");
            Status status = GDIPlus.GdipDrawLinesI(nativeObject, pen.nativeObject, points, points.Length);
            GDIPlus.CheckStatus(status);
        }

        public void DrawPath(Pen pen, GraphicsPath path)
        {
            Trace("DrawPath");
            if (pen == null)
                throw new ArgumentNullException("pen");
            if (path == null)
                throw new ArgumentNullException("path");
            Status status = GDIPlus.GdipDrawPath(nativeObject, pen.nativeObject, path.nativePath);
            GDIPlus.CheckStatus(status);
        }

        public void DrawPie(Pen pen, Rectangle rect, float startAngle, float sweepAngle)
        {
            Trace("DrawPie-1/");
            if (pen == null)
                throw new ArgumentNullException("pen");
            DrawPie(pen, rect.X, rect.Y, rect.Width, rect.Height, startAngle, sweepAngle);
        }

        public void DrawPie(Pen pen, RectangleF rect, float startAngle, float sweepAngle)
        {
            Trace("DrawPie-2/");
            if (pen == null)
                throw new ArgumentNullException("pen");
            DrawPie(pen, rect.X, rect.Y, rect.Width, rect.Height, startAngle, sweepAngle);
        }

        public void DrawPie(Pen pen, float x, float y, float width, float height, float startAngle, float sweepAngle)
        {
            Trace("DrawPie-3");
            if (pen == null)
                throw new ArgumentNullException("pen");
            Status status = GDIPlus.GdipDrawPie(nativeObject, pen.nativeObject, x, y, width, height, startAngle, sweepAngle);
            GDIPlus.CheckStatus(status);
        }

        // Microsoft documentation states that the signature for this member should be
        // public void DrawPie(Pen pen, int x,  int y,  int width,   int height,   int startAngle
        // int sweepAngle. However, GdipDrawPieI uses also float for the startAngle and sweepAngle params
        public void DrawPie(Pen pen, int x, int y, int width, int height, int startAngle, int sweepAngle)
        {
            Trace("DrawPie-4");
            if (pen == null)
                throw new ArgumentNullException("pen");
            Status status = GDIPlus.GdipDrawPieI(nativeObject, pen.nativeObject, x, y, width, height, startAngle, sweepAngle);
            GDIPlus.CheckStatus(status);
        }

        public void DrawPolygon(Pen pen, Point[] points)
        {
            Trace("DrawPolygon-1");
            if (pen == null)
                throw new ArgumentNullException("pen");
            if (points == null)
                throw new ArgumentNullException("points");
            Status status = GDIPlus.GdipDrawPolygonI(nativeObject, pen.nativeObject, points, points.Length);
            GDIPlus.CheckStatus(status);
        }

        public void DrawPolygon(Pen pen, PointF[] points)
        {
            Trace("DrawPolygon-2");
            if (pen == null)
                throw new ArgumentNullException("pen");
            if (points == null)
                throw new ArgumentNullException("points");
            Status status = GDIPlus.GdipDrawPolygon(nativeObject, pen.nativeObject, points, points.Length);
            GDIPlus.CheckStatus(status);
        }

        public void DrawRectangle(Pen pen, Rectangle rect)
        {
            Trace("DrawRectangle-1/");
            if (pen == null)
                throw new ArgumentNullException("pen");
            DrawRectangle(pen, rect.Left, rect.Top, rect.Width, rect.Height);
        }

        public void DrawRectangle(Pen pen, float x, float y, float width, float height)
        {
            Trace("DrawRectangle-2");
            if (pen == null)
                throw new ArgumentNullException("pen");
            Status status = GDIPlus.GdipDrawRectangle(nativeObject, pen.nativeObject, x, y, width, height);
            GDIPlus.CheckStatus(status);
        }

        public void DrawRectangle(Pen pen, int x, int y, int width, int height)
        {
            Trace("DrawRectangle-3");
            if (pen == null)
                throw new ArgumentNullException("pen");
            Status status = GDIPlus.GdipDrawRectangleI(nativeObject, pen.nativeObject, x, y, width, height);
            GDIPlus.CheckStatus(status);
        }

        public void DrawRectangles(Pen pen, RectangleF[] rects)
        {
            Trace("DrawRectangles-1");
            if (pen == null)
                throw new ArgumentNullException("image");
            if (rects == null)
                throw new ArgumentNullException("rects");
            Status status = GDIPlus.GdipDrawRectangles(nativeObject, pen.nativeObject, rects, rects.Length);
            GDIPlus.CheckStatus(status);
        }

        public void DrawRectangles(Pen pen, Rectangle[] rects)
        {
            Trace("DrawRectangles-2");
            if (pen == null)
                throw new ArgumentNullException("image");
            if (rects == null)
                throw new ArgumentNullException("rects");
            Status status = GDIPlus.GdipDrawRectanglesI(nativeObject, pen.nativeObject, rects, rects.Length);
            GDIPlus.CheckStatus(status);
        }

        public void DrawString(string s, Font font, Brush brush, RectangleF layoutRectangle)
        {
            Trace("DrawString-1/");
            DrawString(s, font, brush, layoutRectangle, null);
        }

        public void DrawString(string s, Font font, Brush brush, PointF point)
        {
            Trace("DrawString-2/");
            DrawString(s, font, brush, new RectangleF(point.X, point.Y, 0, 0), null);
        }

        public void DrawString(string s, Font font, Brush brush, PointF point, StringFormat format)
        {
            Trace("DrawString-3/");
            DrawString(s, font, brush, new RectangleF(point.X, point.Y, 0, 0), format);
        }

        public void DrawString(string s, Font font, Brush brush, float x, float y)
        {
            Trace("DrawString-4/");
            DrawString(s, font, brush, new RectangleF(x, y, 0, 0), null);
        }

        public void DrawString(string s, Font font, Brush brush, float x, float y, StringFormat format)
        {
            Trace("DrawString-5/");
            DrawString(s, font, brush, new RectangleF(x, y, 0, 0), format);
        }

        public void DrawString(string s, Font font, Brush brush, RectangleF layoutRectangle, StringFormat format)
        {
            Trace("DrawString-6");
            if (font == null)
                throw new ArgumentNullException("font");
            if (brush == null)
                throw new ArgumentNullException("brush");
            if (s == null || s.Length == 0)
                return;

            Status status = GDIPlus.GdipDrawString(nativeObject, s, s.Length, font.NativeObject, ref layoutRectangle, format != null ? format.NativeObject : IntPtr.Zero, brush.nativeObject);
            GDIPlus.CheckStatus(status);
        }

        public void EndContainer(GraphicsContainer container)
        {
            Trace("EndContainer");
#if NET_2_0
            if (container == null)
                throw new ArgumentNullException("container");
#endif
            Status status = GDIPlus.GdipEndContainer(nativeObject, container.NativeObject);
            GDIPlus.CheckStatus(status);
        }

        private const string MetafileEnumeration = "Metafiles enumeration, for both WMF and EMF formats, isn't supported.";

        [MonoTODO(MetafileEnumeration)]
        public void EnumerateMetafile(Metafile metafile, Point[] destPoints, EnumerateMetafileProc callback)
        {
            throw new NotImplementedException();
        }

        [MonoTODO(MetafileEnumeration)]
        public void EnumerateMetafile(Metafile metafile, RectangleF destRect, EnumerateMetafileProc callback)
        {
            throw new NotImplementedException();
        }

        [MonoTODO(MetafileEnumeration)]
        public void EnumerateMetafile(Metafile metafile, PointF[] destPoints, EnumerateMetafileProc callback)
        {
            throw new NotImplementedException();
        }

        [MonoTODO(MetafileEnumeration)]
        public void EnumerateMetafile(Metafile metafile, Rectangle destRect, EnumerateMetafileProc callback)
        {
            throw new NotImplementedException();
        }

        [MonoTODO(MetafileEnumeration)]
        public void EnumerateMetafile(Metafile metafile, Point destPoint, EnumerateMetafileProc callback)
        {
            throw new NotImplementedException();
        }

        [MonoTODO(MetafileEnumeration)]
        public void EnumerateMetafile(Metafile metafile, PointF destPoint, EnumerateMetafileProc callback)
        {
            throw new NotImplementedException();
        }

        [MonoTODO(MetafileEnumeration)]
        public void EnumerateMetafile(Metafile metafile, PointF destPoint, EnumerateMetafileProc callback, IntPtr callbackData)
        {
            throw new NotImplementedException();
        }

        [MonoTODO(MetafileEnumeration)]
        public void EnumerateMetafile(Metafile metafile, Rectangle destRect, EnumerateMetafileProc callback, IntPtr callbackData)
        {
            throw new NotImplementedException();
        }

        [MonoTODO(MetafileEnumeration)]
        public void EnumerateMetafile(Metafile metafile, PointF[] destPoints, EnumerateMetafileProc callback, IntPtr callbackData)
        {
            throw new NotImplementedException();
        }

        [MonoTODO(MetafileEnumeration)]
        public void EnumerateMetafile(Metafile metafile, Point destPoint, EnumerateMetafileProc callback, IntPtr callbackData)
        {
            throw new NotImplementedException();
        }

        [MonoTODO(MetafileEnumeration)]
        public void EnumerateMetafile(Metafile metafile, Point[] destPoints, EnumerateMetafileProc callback, IntPtr callbackData)
        {
            throw new NotImplementedException();
        }

        [MonoTODO(MetafileEnumeration)]
        public void EnumerateMetafile(Metafile metafile, RectangleF destRect, EnumerateMetafileProc callback, IntPtr callbackData)
        {
            throw new NotImplementedException();
        }

        [MonoTODO(MetafileEnumeration)]
        public void EnumerateMetafile(Metafile metafile, PointF destPoint, RectangleF srcRect, GraphicsUnit srcUnit, EnumerateMetafileProc callback)
        {
            throw new NotImplementedException();
        }

        [MonoTODO(MetafileEnumeration)]
        public void EnumerateMetafile(Metafile metafile, Point destPoint, Rectangle srcRect, GraphicsUnit srcUnit, EnumerateMetafileProc callback)
        {
            throw new NotImplementedException();
        }

        [MonoTODO(MetafileEnumeration)]
        public void EnumerateMetafile(Metafile metafile, PointF[] destPoints, RectangleF srcRect, GraphicsUnit srcUnit, EnumerateMetafileProc callback)
        {
            throw new NotImplementedException();
        }

        [MonoTODO(MetafileEnumeration)]
        public void EnumerateMetafile(Metafile metafile, Point[] destPoints, Rectangle srcRect, GraphicsUnit srcUnit, EnumerateMetafileProc callback)
        {
            throw new NotImplementedException();
        }

        [MonoTODO(MetafileEnumeration)]
        public void EnumerateMetafile(Metafile metafile, RectangleF destRect, RectangleF srcRect, GraphicsUnit srcUnit, EnumerateMetafileProc callback)
        {
            throw new NotImplementedException();
        }

        [MonoTODO(MetafileEnumeration)]
        public void EnumerateMetafile(Metafile metafile, Rectangle destRect, Rectangle srcRect, GraphicsUnit srcUnit, EnumerateMetafileProc callback)
        {
            throw new NotImplementedException();
        }

        [MonoTODO(MetafileEnumeration)]
        public void EnumerateMetafile(Metafile metafile, RectangleF destRect, EnumerateMetafileProc callback, IntPtr callbackData, ImageAttributes imageAttr)
        {
            throw new NotImplementedException();
        }

        [MonoTODO(MetafileEnumeration)]
        public void EnumerateMetafile(Metafile metafile, Point destPoint, EnumerateMetafileProc callback, IntPtr callbackData, ImageAttributes imageAttr)
        {
            throw new NotImplementedException();
        }

        [MonoTODO(MetafileEnumeration)]
        public void EnumerateMetafile(Metafile metafile, PointF destPoint, EnumerateMetafileProc callback, IntPtr callbackData, ImageAttributes imageAttr)
        {
            throw new NotImplementedException();
        }

        [MonoTODO(MetafileEnumeration)]
        public void EnumerateMetafile(Metafile metafile, Point[] destPoints, EnumerateMetafileProc callback, IntPtr callbackData, ImageAttributes imageAttr)
        {
            throw new NotImplementedException();
        }

        [MonoTODO(MetafileEnumeration)]
        public void EnumerateMetafile(Metafile metafile, PointF[] destPoints, EnumerateMetafileProc callback, IntPtr callbackData, ImageAttributes imageAttr)
        {
            throw new NotImplementedException();
        }

        [MonoTODO(MetafileEnumeration)]
        public void EnumerateMetafile(Metafile metafile, Rectangle destRect, EnumerateMetafileProc callback, IntPtr callbackData, ImageAttributes imageAttr)
        {
            throw new NotImplementedException();
        }

        [MonoTODO(MetafileEnumeration)]
        public void EnumerateMetafile(Metafile metafile, Rectangle destRect, Rectangle srcRect, GraphicsUnit srcUnit, EnumerateMetafileProc callback, IntPtr callbackData)
        {
            throw new NotImplementedException();
        }

        [MonoTODO(MetafileEnumeration)]
        public void EnumerateMetafile(Metafile metafile, PointF[] destPoints, RectangleF srcRect, GraphicsUnit srcUnit, EnumerateMetafileProc callback, IntPtr callbackData)
        {
            throw new NotImplementedException();
        }

        [MonoTODO(MetafileEnumeration)]
        public void EnumerateMetafile(Metafile metafile, RectangleF destRect, RectangleF srcRect, GraphicsUnit srcUnit, EnumerateMetafileProc callback, IntPtr callbackData)
        {
            throw new NotImplementedException();
        }

        [MonoTODO(MetafileEnumeration)]
        public void EnumerateMetafile(Metafile metafile, PointF destPoint, RectangleF srcRect, GraphicsUnit srcUnit, EnumerateMetafileProc callback, IntPtr callbackData)
        {
            throw new NotImplementedException();
        }

        [MonoTODO(MetafileEnumeration)]
        public void EnumerateMetafile(Metafile metafile, Point destPoint, Rectangle srcRect, GraphicsUnit srcUnit, EnumerateMetafileProc callback, IntPtr callbackData)
        {
            throw new NotImplementedException();
        }

        [MonoTODO(MetafileEnumeration)]
        public void EnumerateMetafile(Metafile metafile, Point[] destPoints, Rectangle srcRect, GraphicsUnit srcUnit, EnumerateMetafileProc callback, IntPtr callbackData)
        {
            throw new NotImplementedException();
        }

        [MonoTODO(MetafileEnumeration)]
        public void EnumerateMetafile(Metafile metafile, Point[] destPoints, Rectangle srcRect, GraphicsUnit unit, EnumerateMetafileProc callback, IntPtr callbackData, ImageAttributes imageAttr)
        {
            throw new NotImplementedException();
        }

        [MonoTODO(MetafileEnumeration)]
        public void EnumerateMetafile(Metafile metafile, Rectangle destRect, Rectangle srcRect, GraphicsUnit unit, EnumerateMetafileProc callback, IntPtr callbackData, ImageAttributes imageAttr)
        {
            throw new NotImplementedException();
        }

        [MonoTODO(MetafileEnumeration)]
        public void EnumerateMetafile(Metafile metafile, Point destPoint, Rectangle srcRect, GraphicsUnit unit, EnumerateMetafileProc callback, IntPtr callbackData, ImageAttributes imageAttr)
        {
            throw new NotImplementedException();
        }

        [MonoTODO(MetafileEnumeration)]
        public void EnumerateMetafile(Metafile metafile, RectangleF destRect, RectangleF srcRect, GraphicsUnit unit, EnumerateMetafileProc callback, IntPtr callbackData, ImageAttributes imageAttr)
        {
            throw new NotImplementedException();
        }

        [MonoTODO(MetafileEnumeration)]
        public void EnumerateMetafile(Metafile metafile, PointF[] destPoints, RectangleF srcRect, GraphicsUnit unit, EnumerateMetafileProc callback, IntPtr callbackData, ImageAttributes imageAttr)
        {
            throw new NotImplementedException();
        }

        [MonoTODO(MetafileEnumeration)]
        public void EnumerateMetafile(Metafile metafile, PointF destPoint, RectangleF srcRect, GraphicsUnit unit, EnumerateMetafileProc callback, IntPtr callbackData, ImageAttributes imageAttr)
        {
            throw new NotImplementedException();
        }

        public void ExcludeClip(Rectangle rect)
        {
            Trace("ExcludeClip-1");
            Status status = GDIPlus.GdipSetClipRectI(nativeObject, rect.X, rect.Y, rect.Width, rect.Height, CombineMode.Exclude);
            GDIPlus.CheckStatus(status);
        }

        public void ExcludeClip(Region region)
        {
            Trace("ExcludeClip-2");
            if (region == null)
                throw new ArgumentNullException("region");
            Status status = GDIPlus.GdipSetClipRegion(nativeObject, region.NativeObject, CombineMode.Exclude);
            GDIPlus.CheckStatus(status);
        }


        public void FillClosedCurve(Brush brush, PointF[] points)
        {
            Trace("FillClosedCurve-1");
            if (brush == null)
                throw new ArgumentNullException("brush");
            if (points == null)
                throw new ArgumentNullException("points");
            Status status = GDIPlus.GdipFillClosedCurve(nativeObject, brush.NativeObject, points, points.Length);
            GDIPlus.CheckStatus(status);
        }

        public void FillClosedCurve(Brush brush, Point[] points)
        {
            Trace("FillClosedCurve-2");
            if (brush == null)
                throw new ArgumentNullException("brush");
            if (points == null)
                throw new ArgumentNullException("points");
            Status status = GDIPlus.GdipFillClosedCurveI(nativeObject, brush.NativeObject, points, points.Length);
            GDIPlus.CheckStatus(status);
        }


        public void FillClosedCurve(Brush brush, PointF[] points, FillMode fillmode)
        {
            Trace("FillClosedCurve-3/");
            if (brush == null)
                throw new ArgumentNullException("brush");
            if (points == null)
                throw new ArgumentNullException("points");
            FillClosedCurve(brush, points, fillmode, 0.5f);
        }

        public void FillClosedCurve(Brush brush, Point[] points, FillMode fillmode)
        {
            Trace("FillClosedCurve-4/");
            if (brush == null)
                throw new ArgumentNullException("brush");
            if (points == null)
                throw new ArgumentNullException("points");
            FillClosedCurve(brush, points, fillmode, 0.5f);
        }

        public void FillClosedCurve(Brush brush, PointF[] points, FillMode fillmode, float tension)
        {
            Trace("FillClosedCurve-5");
            if (brush == null)
                throw new ArgumentNullException("brush");
            if (points == null)
                throw new ArgumentNullException("points");
            Status status = GDIPlus.GdipFillClosedCurve2(nativeObject, brush.NativeObject, points, points.Length, tension, fillmode);
            GDIPlus.CheckStatus(status);
        }

        public void FillClosedCurve(Brush brush, Point[] points, FillMode fillmode, float tension)
        {
            Trace("FillClosedCurve-6");
            if (brush == null)
                throw new ArgumentNullException("brush");
            if (points == null)
                throw new ArgumentNullException("points");
            Status status = GDIPlus.GdipFillClosedCurve2I(nativeObject, brush.NativeObject, points, points.Length, tension, fillmode);
            GDIPlus.CheckStatus(status);
        }

        public void FillEllipse(Brush brush, Rectangle rect)
        {
            Trace("FillEllipse-1/");
            if (brush == null)
                throw new ArgumentNullException("brush");
            FillEllipse(brush, rect.X, rect.Y, rect.Width, rect.Height);
        }

        public void FillEllipse(Brush brush, RectangleF rect)
        {
            Trace("FillEllipse-2/");
            if (brush == null)
                throw new ArgumentNullException("brush");
            FillEllipse(brush, rect.X, rect.Y, rect.Width, rect.Height);
        }

        public void FillEllipse(Brush brush, float x, float y, float width, float height)
        {
            Trace("FillEllipse-3");
            if (brush == null)
                throw new ArgumentNullException("brush");
            Status status = GDIPlus.GdipFillEllipse(nativeObject, brush.nativeObject, x, y, width, height);
            GDIPlus.CheckStatus(status);
        }

        public void FillEllipse(Brush brush, int x, int y, int width, int height)
        {
            Trace("FillEllipse-4");
            if (brush == null)
                throw new ArgumentNullException("brush");
            Status status = GDIPlus.GdipFillEllipseI(nativeObject, brush.nativeObject, x, y, width, height);
            GDIPlus.CheckStatus(status);
        }

        public void FillPath(Brush brush, GraphicsPath path)
        {
            Trace("FillPath");
            if (brush == null)
                throw new ArgumentNullException("brush");
            if (path == null)
                throw new ArgumentNullException("path");
            Status status = GDIPlus.GdipFillPath(nativeObject, brush.NativeObject, path.NativeObject);
            GDIPlus.CheckStatus(status);
        }

        public void FillPie(Brush brush, Rectangle rect, float startAngle, float sweepAngle)
        {
            Trace("FillPie-1");
            if (brush == null)
                throw new ArgumentNullException("brush");
            Status status = GDIPlus.GdipFillPie(nativeObject, brush.NativeObject, rect.X, rect.Y, rect.Width, rect.Height, startAngle, sweepAngle);
            GDIPlus.CheckStatus(status);
        }

        public void FillPie(Brush brush, int x, int y, int width, int height, int startAngle, int sweepAngle)
        {
            Trace("FillPie-2");
            if (brush == null)
                throw new ArgumentNullException("brush");
            Status status = GDIPlus.GdipFillPieI(nativeObject, brush.NativeObject, x, y, width, height, startAngle, sweepAngle);
            GDIPlus.CheckStatus(status);
        }

        public void FillPie(Brush brush, float x, float y, float width, float height, float startAngle, float sweepAngle)
        {
            Trace("FillPie-3");
            if (brush == null)
                throw new ArgumentNullException("brush");
            Status status = GDIPlus.GdipFillPie(nativeObject, brush.NativeObject, x, y, width, height, startAngle, sweepAngle);
            GDIPlus.CheckStatus(status);
        }

        public void FillPolygon(Brush brush, PointF[] points)
        {
            Trace("FillPolygon-1");
            if (brush == null)
                throw new ArgumentNullException("brush");
            if (points == null)
                throw new ArgumentNullException("points");
            Status status = GDIPlus.GdipFillPolygon2(nativeObject, brush.nativeObject, points, points.Length);
            GDIPlus.CheckStatus(status);
        }

        public void FillPolygon(Brush brush, Point[] points)
        {
            Trace("FillPolygon-2");
            if (brush == null)
                throw new ArgumentNullException("brush");
            if (points == null)
                throw new ArgumentNullException("points");
            Status status = GDIPlus.GdipFillPolygon2I(nativeObject, brush.nativeObject, points, points.Length);
            GDIPlus.CheckStatus(status);
        }

        public void FillPolygon(Brush brush, Point[] points, FillMode fillMode)
        {
            Trace("FillPolygon-3");
            if (brush == null)
                throw new ArgumentNullException("brush");
            if (points == null)
                throw new ArgumentNullException("points");
            Status status = GDIPlus.GdipFillPolygonI(nativeObject, brush.nativeObject, points, points.Length, fillMode);
            GDIPlus.CheckStatus(status);
        }

        public void FillPolygon(Brush brush, PointF[] points, FillMode fillMode)
        {
            Trace("FillPolygon-4");
            if (brush == null)
                throw new ArgumentNullException("brush");
            if (points == null)
                throw new ArgumentNullException("points");
            Status status = GDIPlus.GdipFillPolygon(nativeObject, brush.nativeObject, points, points.Length, fillMode);
            GDIPlus.CheckStatus(status);
        }

        public void FillRectangle(Brush brush, RectangleF rect)
        {
            Trace("FillRectangle-1/");
            if (brush == null)
                throw new ArgumentNullException("brush");
            FillRectangle(brush, rect.Left, rect.Top, rect.Width, rect.Height);
        }

        public void FillRectangle(Brush brush, Rectangle rect)
        {
            Trace("FillRectangle-2/");
            if (brush == null)
                throw new ArgumentNullException("brush");
            FillRectangle(brush, rect.Left, rect.Top, rect.Width, rect.Height);
        }

        public void FillRectangle(Brush brush, int x, int y, int width, int height)
        {
            Trace("FillRectangle-3");
            if (brush == null)
                throw new ArgumentNullException("brush");

            Status status = GDIPlus.GdipFillRectangleI(nativeObject, brush.nativeObject, x, y, width, height);
            GDIPlus.CheckStatus(status);
        }

        public void FillRectangle(Brush brush, float x, float y, float width, float height)
        {
            Trace("FillRectangle-4");
            if (brush == null)
                throw new ArgumentNullException("brush");

            Status status = GDIPlus.GdipFillRectangle(nativeObject, brush.nativeObject, x, y, width, height);
            GDIPlus.CheckStatus(status);
        }

        public void FillRectangles(Brush brush, Rectangle[] rects)
        {
            Trace("FillRectangles-1");
            if (brush == null)
                throw new ArgumentNullException("brush");
            if (rects == null)
                throw new ArgumentNullException("rects");

            Status status = GDIPlus.GdipFillRectanglesI(nativeObject, brush.nativeObject, rects, rects.Length);
            GDIPlus.CheckStatus(status);
        }

        public void FillRectangles(Brush brush, RectangleF[] rects)
        {
            Trace("FillRectangles-2");
            if (brush == null)
                throw new ArgumentNullException("brush");
            if (rects == null)
                throw new ArgumentNullException("rects");

            Status status = GDIPlus.GdipFillRectangles(nativeObject, brush.nativeObject, rects, rects.Length);
            GDIPlus.CheckStatus(status);
        }


        public void FillRegion(Brush brush, Region region)
        {
            Trace("FillRegion");
            if (brush == null)
                throw new ArgumentNullException("brush");
            if (region == null)
                throw new ArgumentNullException("region");

            Status status = GDIPlus.GdipFillRegion(nativeObject, brush.NativeObject, region.NativeObject);
            GDIPlus.CheckStatus(status);
        }


        public void Flush()
        {
            Trace("Flush-1/");
            Flush(FlushIntention.Flush);
        }


        public void Flush(FlushIntention intention)
        {
            Trace("Flush-2");
            if (nativeObject == IntPtr.Zero)
            {
                return;
            }

            Status status = GDIPlus.GdipFlush(nativeObject, intention);
            GDIPlus.CheckStatus(status);
        }

        [EditorBrowsable(EditorBrowsableState.Advanced)]
        public static Graphics FromHdc(IntPtr hdc)
        {
            IntPtr native;
            Status status = GDIPlus.GdipCreateFromHDC(hdc, out native);
            GDIPlus.CheckStatus(status);
            return new Graphics(native);
        }

        [MonoTODO]
        [EditorBrowsable(EditorBrowsableState.Advanced)]
        public static Graphics FromHdc(IntPtr hdc, IntPtr hdevice)
        {
            throw new NotImplementedException();
        }

        [EditorBrowsable(EditorBrowsableState.Advanced)]
        [SecurityPermission(SecurityAction.LinkDemand, UnmanagedCode = true)]
        public static Graphics FromHdcInternal(IntPtr hdc)
        {
            GDIPlus.Display = hdc;
            return null;
        }

        [EditorBrowsable(EditorBrowsableState.Advanced)]
        public static Graphics FromHwnd(IntPtr hwnd)
        {
            IntPtr native;

            if (GDIPlus.UseCarbonDrawable)
            {
                CarbonContext cC = Carbon.GetCGContextForView(hwnd);
                GDIPlus.GdipCreateFromContext_macosx(cC.context, cC.width, cC.height, out native);
                return new Graphics(native, cC.context);
            }

            if (GDIPlus.UseX11Drawable)
            {
                if (GDIPlus.Display == IntPtr.Zero)
                {
                    GDIPlus.Display = GDIPlus.XOpenDisplay(IntPtr.Zero);
                    if (GDIPlus.Display == IntPtr.Zero)
                        throw new NotSupportedException("Could not open display (X-Server required. Check you DISPLAY environment variable)");
                }
                if (hwnd == IntPtr.Zero)
                {
                    hwnd = GDIPlus.XRootWindow(GDIPlus.Display, GDIPlus.XDefaultScreen(GDIPlus.Display));
                }
                return FromXDrawable(hwnd, GDIPlus.Display);
            }

            Status status = GDIPlus.GdipCreateFromHWND(hwnd, out native);
            GDIPlus.CheckStatus(status);
            return new Graphics(native);
        }

        [EditorBrowsable(EditorBrowsableState.Advanced)]
        [SecurityPermission(SecurityAction.LinkDemand, UnmanagedCode = true)]
        public static Graphics FromHwndInternal(IntPtr hwnd)
        {
            return FromHwnd(hwnd);
        }

        public static Graphics FromImage(Image image)
        {
            return FromImage(image, false);
        }

        public static Graphics FromImage(Image image, bool keep)
        {
            if (image == null)
                throw new ArgumentNullException("image");

            if ((image.PixelFormat & PixelFormat.Indexed) != 0)
                throw new Exception(Locale.GetText("Cannot create Graphics from an indexed bitmap."));

            IntPtr native;
            Status status = GDIPlus.GdipGetImageGraphicsContext(image.nativeObject, out native);
            GDIPlus.CheckStatus(status);
            Graphics graphics = new Graphics(native, keep);

            if (GDIPlus.RunningOnUnix())
            {
                Rectangle rect = new Rectangle(0, 0, image.Width, image.Height);
                GDIPlus.GdipSetVisibleClip_linux(graphics.NativeObject, ref rect);
            }

            return graphics;
        }

        internal static Graphics FromXDrawable(IntPtr drawable, IntPtr display)
        {
            IntPtr native;
            Status s = GDIPlus.GdipCreateFromXDrawable_linux(drawable, display, out native);
            GDIPlus.CheckStatus(s);
            return new Graphics(native);
        }

        [MonoTODO]
        public static IntPtr GetHalftonePalette()
        {
            throw new NotImplementedException();
        }

#if !NET_2_0
		[EditorBrowsable (EditorBrowsableState.Advanced)]
#endif
        public IntPtr GetHdc()
        {
            Trace("GetHdc");
            GDIPlus.CheckStatus(GDIPlus.GdipGetDC(this.nativeObject, out deviceContextHdc));
            return deviceContextHdc;
        }

        public Color GetNearestColor(Color color)
        {
            Trace("GetNearestColor");
            int argb;

            Status status = GDIPlus.GdipGetNearestColor(nativeObject, out argb);
            GDIPlus.CheckStatus(status);

            return Color.FromArgb(argb);
        }


        public void IntersectClip(Region region)
        {
            Trace("IntersectClip-1");
            if (region == null)
                throw new ArgumentNullException("region");
            Status status = GDIPlus.GdipSetClipRegion(nativeObject, region.NativeObject, CombineMode.Intersect);
            GDIPlus.CheckStatus(status);
        }

        public void IntersectClip(RectangleF rect)
        {
            Trace("IntersectClip-2");
            Status status = GDIPlus.GdipSetClipRect(nativeObject, rect.X, rect.Y, rect.Width, rect.Height, CombineMode.Intersect);
            GDIPlus.CheckStatus(status);
        }

        public void IntersectClip(Rectangle rect)
        {
            Trace("IntersectClip-3");
            Status status = GDIPlus.GdipSetClipRectI(nativeObject, rect.X, rect.Y, rect.Width, rect.Height, CombineMode.Intersect);
            GDIPlus.CheckStatus(status);
        }

        public bool IsVisible(Point point)
        {
            Trace("IsVisible-1");
            bool isVisible = false;

            Status status = GDIPlus.GdipIsVisiblePointI(nativeObject, point.X, point.Y, out isVisible);
            GDIPlus.CheckStatus(status);

            return isVisible;
        }


        public bool IsVisible(RectangleF rect)
        {
            Trace("IsVisible-2");
            bool isVisible = false;

            Status status = GDIPlus.GdipIsVisibleRect(nativeObject, rect.X, rect.Y, rect.Width, rect.Height, out isVisible);
            GDIPlus.CheckStatus(status);

            return isVisible;
        }

        public bool IsVisible(PointF point)
        {
            Trace("IsVisible-3");
            bool isVisible = false;

            Status status = GDIPlus.GdipIsVisiblePoint(nativeObject, point.X, point.Y, out isVisible);
            GDIPlus.CheckStatus(status);

            return isVisible;
        }

        public bool IsVisible(Rectangle rect)
        {
            Trace("IsVisible-4");
            bool isVisible = false;

            Status status = GDIPlus.GdipIsVisibleRectI(nativeObject, rect.X, rect.Y, rect.Width, rect.Height, out isVisible);
            GDIPlus.CheckStatus(status);

            return isVisible;
        }

        public bool IsVisible(float x, float y)
        {
            Trace("IsVisible-5/");
            return IsVisible(new PointF(x, y));
        }

        public bool IsVisible(int x, int y)
        {
            Trace("IsVisible-6/");
            return IsVisible(new Point(x, y));
        }

        public bool IsVisible(float x, float y, float width, float height)
        {
            Trace("IsVisible-7/");
            return IsVisible(new RectangleF(x, y, width, height));
        }


        public bool IsVisible(int x, int y, int width, int height)
        {
            Trace("IsVisible-8/");
            return IsVisible(new Rectangle(x, y, width, height));
        }


        public Region[] MeasureCharacterRanges(string text, Font font, RectangleF layoutRect, StringFormat stringFormat)
        {
            Trace("MeasureCharacterRanges");
            if ((text == null) || (text.Length == 0))
                return new Region[0];

            if (font == null)
                throw new ArgumentNullException("font");

            if (stringFormat == null)
                throw new ArgumentException("stringFormat");

            int regcount = stringFormat.GetMeasurableCharacterRangeCount();
            if (regcount == 0)
                return new Region[0];

            IntPtr[] native_regions = new IntPtr[regcount];
            Region[] regions = new Region[regcount];

            for (int i = 0; i < regcount; i++)
            {
                regions[i] = new Region();
                native_regions[i] = regions[i].NativeObject;
            }

            Status status = GDIPlus.GdipMeasureCharacterRanges(nativeObject, text, text.Length,
                font.NativeObject, ref layoutRect, stringFormat.NativeObject, regcount, out native_regions[0]);
            GDIPlus.CheckStatus(status);

            return regions;
        }

        private SizeF GdipMeasureString(string text, Font font, ref RectangleF layoutRect, IntPtr stringFormat)
        {
            if ((text == null) || (text.Length == 0))
                return SizeF.Empty;

            if (font == null)
                throw new ArgumentNullException("font");

            RectangleF boundingBox = new RectangleF();
            unsafe
            {
                Status status = GDIPlus.GdipMeasureString(nativeObject, text, text.Length, font.NativeObject,
                    ref layoutRect, stringFormat, out boundingBox, null, null);
                GDIPlus.CheckStatus(status);
            }
            return new SizeF(boundingBox.Width, boundingBox.Height);
        }

        public SizeF MeasureString(string text, Font font)
        {
            Trace("MeasureString-1/");
            return MeasureString(text, font, SizeF.Empty);
        }

        public SizeF MeasureString(string text, Font font, SizeF layoutArea)
        {
            Trace("MeasureString-2/");
            RectangleF rect = new RectangleF(0, 0, layoutArea.Width, layoutArea.Height);
            return GdipMeasureString(text, font, ref rect, IntPtr.Zero);
        }

        public SizeF MeasureString(string text, Font font, int width)
        {
            Trace("MeasureString-3/");
            RectangleF rect = new RectangleF(0, 0, width, Int32.MaxValue);
            return GdipMeasureString(text, font, ref rect, IntPtr.Zero);
        }

        public SizeF MeasureString(string text, Font font, SizeF layoutArea, StringFormat stringFormat)
        {
            Trace("MeasureString-4/");
            RectangleF rect = new RectangleF(0, 0, layoutArea.Width, layoutArea.Height);
            IntPtr format = (stringFormat == null) ? IntPtr.Zero : stringFormat.NativeObject;
            return GdipMeasureString(text, font, ref rect, format);
        }

        public SizeF MeasureString(string text, Font font, int width, StringFormat format)
        {
            Trace("MeasureString-5/");
            RectangleF rect = new RectangleF(0, 0, width, Int32.MaxValue);
            IntPtr stringFormat = (format == null) ? IntPtr.Zero : format.NativeObject;
            return GdipMeasureString(text, font, ref rect, stringFormat);
        }

        public SizeF MeasureString(string text, Font font, PointF origin, StringFormat stringFormat)
        {
            Trace("MeasureString-6/");
            RectangleF rect = new RectangleF(origin.X, origin.Y, 0, 0);
            IntPtr format = (stringFormat == null) ? IntPtr.Zero : stringFormat.NativeObject;
            return GdipMeasureString(text, font, ref rect, format);
        }

        public SizeF MeasureString(string text, Font font, SizeF layoutArea, StringFormat stringFormat,
            out int charactersFitted, out int linesFilled)
        {
            Trace("MeasureString-7");
            charactersFitted = 0;
            linesFilled = 0;

            if ((text == null) || (text.Length == 0))
                return SizeF.Empty;

            if (font == null)
                throw new ArgumentNullException("font");

            RectangleF boundingBox = new RectangleF();
            RectangleF rect = new RectangleF(0, 0, layoutArea.Width, layoutArea.Height);

            IntPtr format = (stringFormat == null) ? IntPtr.Zero : stringFormat.NativeObject;

            unsafe
            {
                fixed (int* pc = &charactersFitted, pl = &linesFilled)
                {
                    Status status = GDIPlus.GdipMeasureString(nativeObject, text, text.Length,
                    font.NativeObject, ref rect, format, out boundingBox, pc, pl);
                    GDIPlus.CheckStatus(status);
                }
            }
            return new SizeF(boundingBox.Width, boundingBox.Height);
        }

        public void MultiplyTransform(Matrix matrix)
        {
            Trace("MultiplyTransform-1/");
            MultiplyTransform(matrix, MatrixOrder.Prepend);
        }

        public void MultiplyTransform(Matrix matrix, MatrixOrder order)
        {
            Trace("MultiplyTransform-2");
            if (matrix == null)
                throw new ArgumentNullException("matrix");

            Status status = GDIPlus.GdipMultiplyWorldTransform(nativeObject, matrix.nativeMatrix, order);
            GDIPlus.CheckStatus(status);
        }

        [EditorBrowsable(EditorBrowsableState.Advanced)]
        [SecurityPermission(SecurityAction.Demand, UnmanagedCode = true)]
        public void ReleaseHdc(IntPtr hdc)
        {
            Trace("ReleaseHdc-1/");
            ReleaseHdcInternal(hdc);
        }

#if NET_2_0
        [SecurityPermission(SecurityAction.LinkDemand, UnmanagedCode = true)]
        public void ReleaseHdc()
        {
            Trace("ReleaseHdc-2/");
            ReleaseHdcInternal(deviceContextHdc);
        }
#endif

        [MonoLimitation("Can only be used when hdc was provided by Graphics.GetHdc() method")]
#if NET_2_0
        [EditorBrowsable(EditorBrowsableState.Never)]
#else
		[EditorBrowsable (EditorBrowsableState.Advanced)]
#endif
        [SecurityPermission(SecurityAction.LinkDemand, UnmanagedCode = true)]
        public void ReleaseHdcInternal(IntPtr hdc)
        {
            Trace("ReleaseHdcInternal");
            Status status = Status.InvalidParameter;
            if (hdc == deviceContextHdc)
            {
                status = GDIPlus.GdipReleaseDC(nativeObject, deviceContextHdc);
                deviceContextHdc = IntPtr.Zero;
            }
            GDIPlus.CheckStatus(status);
        }

        public void ResetClip()
        {
            Trace("ResetClip");
            Status status = GDIPlus.GdipResetClip(nativeObject);
            GDIPlus.CheckStatus(status);
        }

        public void ResetTransform()
        {
            Trace("ResetTransform");
            Status status = GDIPlus.GdipResetWorldTransform(nativeObject);
            GDIPlus.CheckStatus(status);
        }

        public void Restore(GraphicsState gstate)
        {
            Trace("Restore");
            // the possible NRE thrown by gstate.nativeState match MS behaviour
            Status status = GDIPlus.GdipRestoreGraphics(nativeObject, gstate.nativeState);
            GDIPlus.CheckStatus(status);
        }

        public void RotateTransform(float angle)
        {
            Trace("RotateTransform-1/");
            RotateTransform(angle, MatrixOrder.Prepend);
        }

        public void RotateTransform(float angle, MatrixOrder order)
        {
            Trace("RotateTransform-2");
            Status status = GDIPlus.GdipRotateWorldTransform(nativeObject, angle, order);
            GDIPlus.CheckStatus(status);
        }

        public GraphicsState Save()
        {
            Trace("Save");
            uint saveState;
            Status status = GDIPlus.GdipSaveGraphics(nativeObject, out saveState);
            GDIPlus.CheckStatus(status);

            GraphicsState state = new GraphicsState();
            state.nativeState = saveState;
            return state;
        }

        public void ScaleTransform(float sx, float sy)
        {
            Trace("ScaleTransform-1/");
            ScaleTransform(sx, sy, MatrixOrder.Prepend);
        }

        public void ScaleTransform(float sx, float sy, MatrixOrder order)
        {
            Trace("ScaleTransform-2");
            Status status = GDIPlus.GdipScaleWorldTransform(nativeObject, sx, sy, order);
            GDIPlus.CheckStatus(status);
        }


        public void SetClip(RectangleF rect)
        {
            Trace("SetClip-1/");
            SetClip(rect, CombineMode.Replace);
        }


        public void SetClip(GraphicsPath path)
        {
            Trace("SetClip-2/");
            SetClip(path, CombineMode.Replace);
        }


        public void SetClip(Rectangle rect)
        {
            Trace("SetClip-3/");
            SetClip(rect, CombineMode.Replace);
        }


        public void SetClip(Graphics g)
        {
            Trace("SetClip-4/");
            SetClip(g, CombineMode.Replace);
        }


        public void SetClip(Graphics g, CombineMode combineMode)
        {
            Trace("SetClip-5");
            if (g == null)
                throw new ArgumentNullException("g");

            Status status = GDIPlus.GdipSetClipGraphics(nativeObject, g.NativeObject, combineMode);
            GDIPlus.CheckStatus(status);
        }


        public void SetClip(Rectangle rect, CombineMode combineMode)
        {
            Trace("SetClip-6");
            Status status = GDIPlus.GdipSetClipRectI(nativeObject, rect.X, rect.Y, rect.Width, rect.Height, combineMode);
            GDIPlus.CheckStatus(status);
        }


        public void SetClip(RectangleF rect, CombineMode combineMode)
        {
            Trace("SetClip-7");
            Status status = GDIPlus.GdipSetClipRect(nativeObject, rect.X, rect.Y, rect.Width, rect.Height, combineMode);
            GDIPlus.CheckStatus(status);
        }


        public void SetClip(Region region, CombineMode combineMode)
        {
            Trace("SetClip-8");
            if (region == null)
                throw new ArgumentNullException("region");
            Status status = GDIPlus.GdipSetClipRegion(nativeObject, region.NativeObject, combineMode);
            GDIPlus.CheckStatus(status);
        }


        public void SetClip(GraphicsPath path, CombineMode combineMode)
        {
            Trace("SetClip-9");
            if (path == null)
                throw new ArgumentNullException("path");
            Status status = GDIPlus.GdipSetClipPath(nativeObject, path.NativeObject, combineMode);
            GDIPlus.CheckStatus(status);
        }


        public void TransformPoints(CoordinateSpace destSpace, CoordinateSpace srcSpace, PointF[] pts)
        {
            Trace("TransformPoints-1");
            if (pts == null)
                throw new ArgumentNullException("pts");

            IntPtr ptrPt = GDIPlus.FromPointToUnManagedMemory(pts);

            Status status = GDIPlus.GdipTransformPoints(nativeObject, destSpace, srcSpace, ptrPt, pts.Length);
            GDIPlus.CheckStatus(status);

            GDIPlus.FromUnManagedMemoryToPoint(ptrPt, pts);
        }


        public void TransformPoints(CoordinateSpace destSpace, CoordinateSpace srcSpace, Point[] pts)
        {
            Trace("TransformPoints-2");
            if (pts == null)
                throw new ArgumentNullException("pts");
            IntPtr ptrPt = GDIPlus.FromPointToUnManagedMemoryI(pts);

            Status status = GDIPlus.GdipTransformPointsI(nativeObject, destSpace, srcSpace, ptrPt, pts.Length);
            GDIPlus.CheckStatus(status);

            GDIPlus.FromUnManagedMemoryToPointI(ptrPt, pts);
        }


        public void TranslateClip(int dx, int dy)
        {
            Trace("TranslateClip-1");
            Status status = GDIPlus.GdipTranslateClipI(nativeObject, dx, dy);
            GDIPlus.CheckStatus(status);
        }


        public void TranslateClip(float dx, float dy)
        {
            Trace("TranslateClip-2");
            Status status = GDIPlus.GdipTranslateClip(nativeObject, dx, dy);
            GDIPlus.CheckStatus(status);
        }

        public void TranslateTransform(float dx, float dy)
        {
            Trace("TranslateTransform-1/");
            TranslateTransform(dx, dy, MatrixOrder.Prepend);
        }


        public void TranslateTransform(float dx, float dy, MatrixOrder order)
        {
            Trace("TranslateTransform-2");
            Status status = GDIPlus.GdipTranslateWorldTransform(nativeObject, dx, dy, order);
            GDIPlus.CheckStatus(status);
        }

        public Region Clip
        {
            get
            {
                Trace("Clip.get");
                Region reg = new Region();
                Status status = GDIPlus.GdipGetClip(nativeObject, reg.NativeObject);
                GDIPlus.CheckStatus(status);
                return reg;
            }
            set
            {
                Trace("Clip.set");
                SetClip(value, CombineMode.Replace);
            }
        }

        public RectangleF ClipBounds
        {
            get
            {
                Trace("ClipBounds.get");
                RectangleF rect = new RectangleF();
                Status status = GDIPlus.GdipGetClipBounds(nativeObject, out rect);
                GDIPlus.CheckStatus(status);
                return rect;
            }
        }

        public CompositingMode CompositingMode
        {
            get
            {
                Trace("CompositingMode.get");
                CompositingMode mode;
                Status status = GDIPlus.GdipGetCompositingMode(nativeObject, out mode);
                GDIPlus.CheckStatus(status);

                return mode;
            }
            set
            {
                Trace("CompositingMode.set");
                Status status = GDIPlus.GdipSetCompositingMode(nativeObject, value);
                GDIPlus.CheckStatus(status);
            }

        }

        public CompositingQuality CompositingQuality
        {
            get
            {
                Trace("CompositingQuality.get");
                CompositingQuality quality;

                Status status = GDIPlus.GdipGetCompositingQuality(nativeObject, out quality);
                GDIPlus.CheckStatus(status);
                return quality;
            }
            set
            {
                Trace("CompositingQuality.set");
                Status status = GDIPlus.GdipSetCompositingQuality(nativeObject, value);
                GDIPlus.CheckStatus(status);
            }
        }

        public float DpiX
        {
            get
            {
                Trace("DpiX.get");
                float x;

                Status status = GDIPlus.GdipGetDpiX(nativeObject, out x);
                GDIPlus.CheckStatus(status);
                return x;
            }
        }

        public float DpiY
        {
            get
            {
                Trace("DpiY.get");
                float y;

                Status status = GDIPlus.GdipGetDpiY(nativeObject, out y);
                GDIPlus.CheckStatus(status);
                return y;
            }
        }

        public InterpolationMode InterpolationMode
        {
            get
            {
                Trace("InterpolationMode.get");
                InterpolationMode imode = InterpolationMode.Invalid;
                Status status = GDIPlus.GdipGetInterpolationMode(nativeObject, out imode);
                GDIPlus.CheckStatus(status);
                return imode;
            }
            set
            {
                Trace("InterpolationMode.set");
                Status status = GDIPlus.GdipSetInterpolationMode(nativeObject, value);
                GDIPlus.CheckStatus(status);
            }
        }

        public bool IsClipEmpty
        {
            get
            {
                Trace("IsClipEmpty.get");
                bool isEmpty = false;

                Status status = GDIPlus.GdipIsClipEmpty(nativeObject, out isEmpty);
                GDIPlus.CheckStatus(status);
                return isEmpty;
            }
        }

        public bool IsVisibleClipEmpty
        {
            get
            {
                Trace("IsVisibleClipEmpty.get");
                bool isEmpty = false;

                Status status = GDIPlus.GdipIsVisibleClipEmpty(nativeObject, out isEmpty);
                GDIPlus.CheckStatus(status);
                return isEmpty;
            }
        }

        public float PageScale
        {
            get
            {
                Trace("PageScale.get");
                float scale;

                Status status = GDIPlus.GdipGetPageScale(nativeObject, out scale);
                GDIPlus.CheckStatus(status);
                return scale;
            }
            set
            {
                Trace("PageScale.set");
                Status status = GDIPlus.GdipSetPageScale(nativeObject, value);
                GDIPlus.CheckStatus(status);
            }
        }

        public GraphicsUnit PageUnit
        {
            get
            {
                Trace("PageUnit.get");
                GraphicsUnit unit;

                Status status = GDIPlus.GdipGetPageUnit(nativeObject, out unit);
                GDIPlus.CheckStatus(status);
                return unit;
            }
            set
            {
                Trace("PageUnit.set");
                Status status = GDIPlus.GdipSetPageUnit(nativeObject, value);
                GDIPlus.CheckStatus(status);
            }
        }

        [MonoTODO("This property does not do anything when used with libgdiplus.")]
        public PixelOffsetMode PixelOffsetMode
        {
            get
            {
                Trace("PixelOffsetMode.get");
                PixelOffsetMode pixelOffset = PixelOffsetMode.Invalid;

                Status status = GDIPlus.GdipGetPixelOffsetMode(nativeObject, out pixelOffset);
                GDIPlus.CheckStatus(status);
                return pixelOffset;
            }
            set
            {
                Trace("PixelOffsetMode.set");
                Status status = GDIPlus.GdipSetPixelOffsetMode(nativeObject, value);
                GDIPlus.CheckStatus(status);
            }
        }

        public Point RenderingOrigin
        {
            get
            {
                Trace("RenderingOrigin.get");
                int x, y;
                Status status = GDIPlus.GdipGetRenderingOrigin(nativeObject, out x, out y);
                GDIPlus.CheckStatus(status);
                return new Point(x, y);
            }

            set
            {
                Trace("RenderingOrigin.set");
                Status status = GDIPlus.GdipSetRenderingOrigin(nativeObject, value.X, value.Y);
                GDIPlus.CheckStatus(status);
            }
        }

        public SmoothingMode SmoothingMode
        {
            get
            {
                Trace("SmoothingMode.get");
                SmoothingMode mode = SmoothingMode.Invalid;

                Status status = GDIPlus.GdipGetSmoothingMode(nativeObject, out mode);
                GDIPlus.CheckStatus(status);
                return mode;
            }

            set
            {
                Trace("SmoothingMode.set");
                Status status = GDIPlus.GdipSetSmoothingMode(nativeObject, value);
                GDIPlus.CheckStatus(status);
            }
        }

        [MonoTODO("This property does not do anything when used with libgdiplus.")]
        public int TextContrast
        {
            get
            {
                Trace("TextContrast.get");
                int contrast;

                Status status = GDIPlus.GdipGetTextContrast(nativeObject, out contrast);
                GDIPlus.CheckStatus(status);
                return contrast;
            }

            set
            {
                Trace("TextContrast.set");
                Status status = GDIPlus.GdipSetTextContrast(nativeObject, value);
                GDIPlus.CheckStatus(status);
            }
        }

        public TextRenderingHint TextRenderingHint
        {
            get
            {
                Trace("TextRenderingHint.get");
                TextRenderingHint hint;

                Status status = GDIPlus.GdipGetTextRenderingHint(nativeObject, out hint);
                GDIPlus.CheckStatus(status);
                return hint;
            }

            set
            {
                Trace("TextRenderingHint.set");
                Status status = GDIPlus.GdipSetTextRenderingHint(nativeObject, value);
                GDIPlus.CheckStatus(status);
            }
        }

        public Matrix Transform
        {
            get
            {
                Trace("Transform.get");
                Matrix matrix = new Matrix();
                Status status = GDIPlus.GdipGetWorldTransform(nativeObject, matrix.nativeMatrix);
                GDIPlus.CheckStatus(status);
                return matrix;
            }
            set
            {
                Trace("Transform.set");
                if (value == null)
                    throw new ArgumentNullException("value");

                Status status = GDIPlus.GdipSetWorldTransform(nativeObject, value.nativeMatrix);
                GDIPlus.CheckStatus(status);

                //the following code is to fix a bug in Carbon, otherwise harmless
                Matrix matrix2 = new Matrix();

                status = GDIPlus.GdipGetWorldTransform(nativeObject, matrix2.nativeMatrix);
                GDIPlus.CheckStatus(status);

                status = GDIPlus.GdipTranslateMatrix(
                    value.nativeMatrix,
                    value.OffsetX - matrix2.OffsetX,
                    value.OffsetY - matrix2.OffsetY,
                    MatrixOrder.Prepend);
                GDIPlus.CheckStatus(status);

                status = GDIPlus.GdipSetWorldTransform(nativeObject, value.nativeMatrix);
                GDIPlus.CheckStatus(status);

                matrix2.Dispose();
            }
        }

        public RectangleF VisibleClipBounds
        {
            get
            {
                Trace("VisibleClipBounds.get");
                RectangleF rect;
                Status status = GDIPlus.GdipGetVisibleClipBounds(nativeObject, out rect);
                GDIPlus.CheckStatus(status);
                return rect;
            }
        }

#if NET_2_0
        [MonoTODO]
        [EditorBrowsable(EditorBrowsableState.Never)]
        public object GetContextInfo()
        {
            // only known source of information @ http://blogs.wdevs.com/jdunlap/Default.aspx
            throw new NotImplementedException();
        }
#endif
    }
}
