//
// System.ComponentModel.Int16Converter
//
// Authors:
//      Martin Willemoes Hansen (mwh@sysrq.dk)
//
// (C) 2003 Martin Willemoes Hansen
//

namespace System.ComponentModel
{
        public class Int16Converter : BaseNumberConverter
	{
		[MonoTODO]
		public Int16Converter()
		{
		}

		[MonoTODO]
		~Int16Converter()
		{
		}
	}
}
