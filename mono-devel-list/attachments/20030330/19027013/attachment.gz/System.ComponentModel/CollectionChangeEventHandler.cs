//
// System.ComponentModel.CollectionChangeEventHandler.cs
//
// Author:
//   Rodrigo Moya (rodrigo@ximian.com)
//
// (C) Ximian, Inc
//

namespace System.ComponentModel
{
	public delegate void CollectionChangeEventHandler (object sender,
							   CollectionChangeEventArgs e);
}	
