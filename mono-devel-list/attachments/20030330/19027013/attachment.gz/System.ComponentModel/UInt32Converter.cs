//
// System.ComponentModel.UInt32Converter
//
// Authors:
//      Martin Willemoes Hansen (mwh@sysrq.dk)
//
// (C) 2003 Martin Willemoes Hansen
//

namespace System.ComponentModel
{
	public class UInt32Converter : BaseNumberConverter
	{
		[MonoTODO]
		public UInt32Converter()
		{
		}

		[MonoTODO]
		~UInt32Converter()
		{
		}
	}
}
