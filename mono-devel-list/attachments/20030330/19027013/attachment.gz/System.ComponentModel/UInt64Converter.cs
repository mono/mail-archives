//
// System.ComponentModel.UInt64Converter
//
// Authors:
//      Martin Willemoes Hansen (mwh@sysrq.dk)
//
// (C) 2003 Martin Willemoes Hansen
//

namespace System.ComponentModel
{
	public class UInt64Converter : BaseNumberConverter
	{
		[MonoTODO]
		public UInt64Converter()
		{
		}

		[MonoTODO]
		~UInt64Converter()
		{
		}
	}
}
