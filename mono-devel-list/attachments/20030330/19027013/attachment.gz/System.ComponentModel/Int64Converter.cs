//
// System.ComponentModel.Int64Converter
//
// Authors:
//      Martin Willemoes Hansen (mwh@sysrq.dk)
//
// (C) 2003 Martin Willemoes Hansen
//

namespace System.ComponentModel
{
        public class Int64Converter : BaseNumberConverter
	{
		[MonoTODO]
		public Int64Converter()
		{
		}

		[MonoTODO]
		~Int64Converter()
		{
		}
	}
}
