//
// System.ComponentModel.ExpandableObjectConverter.cs
//
// Author:
//   Tim Coleman (tim@timcoleman.com)
//
// Copyright (C) Tim Coleman, 2002
//

using System;

namespace System.ComponentModel {
	public class ExpandableObjectConverter : TypeConverter {

		#region Constructors

		[MonoTODO]
		public ExpandableObjectConverter ()
		{
			throw new NotImplementedException ();
		}

		#endregion // Constructors

		#region Methods

		[MonoTODO]
		public override PropertyDescriptorCollection GetProperties (ITypeDescriptorContext context, object value, Attribute[] attributes)
		{
			throw new NotImplementedException ();
		}

		[MonoTODO]
		public override bool GetPropertiesSupported (ITypeDescriptorContext context)
		{
			throw new NotImplementedException ();
		}

		#endregion // Methods
	}
}
