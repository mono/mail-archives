//
// System.ComponentModel.SingleConverter
//
// Authors:
//      Martin Willemoes Hansen (mwh@sysrq.dk)
//
// (C) 2003 Martin Willemoes Hansen
//

namespace System.ComponentModel
{
	public class SingleConverter : BaseNumberConverter
	{
		[MonoTODO]
		public SingleConverter()
		{
		}

		[MonoTODO]
		~SingleConverter()
		{
		}

	}
}
