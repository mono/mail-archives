//------------------------------------------------------------------------------
// 
// System.ComponentModel.CancelEventHandler.
//
// Author:  Asier Llano Palacios, asierllano@infonegocio.com
//
//------------------------------------------------------------------------------

using System;

namespace System.ComponentModel {

	[Serializable]
	public delegate void CancelEventHandler( object sender, CancelEventArgs e );
}


