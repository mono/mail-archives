//
// System.ComponentModel.ByteConverter
//
// Authors:
//      Martin Willemoes Hansen (mwh@sysrq.dk)
//
// (C) 2003 Martin Willemoes Hansen
//

namespace System.ComponentModel
{
        public class ByteConverter : BaseNumberConverter
	{
		[MonoTODO]
		public ByteConverter()
		{
		}

		[MonoTODO]
		~ByteConverter()
		{
		}
	}
}
