namespace System.ComponentModel {

	public enum PropertyTabScope {
		Static,
		Global,
		Document,
		Component
	}
}
