//
// System.ComponentModel.DoubleConverter
//
// Authors:
//      Martin Willemoes Hansen (mwh@sysrq.dk)
//
// (C) 2003 Martin Willemoes Hansen
//

namespace System.ComponentModel
{
        public class DoubleConverter : BaseNumberConverter
	{
		[MonoTODO]
		public DoubleConverter()
		{
		}

		[MonoTODO]
		~DoubleConverter()
		{
		}
	}
}
