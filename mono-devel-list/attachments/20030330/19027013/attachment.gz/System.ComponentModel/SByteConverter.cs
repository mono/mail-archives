//
// System.ComponentModel.SByteConverter
//
// Authors:
//      Martin Willemoes Hansen (mwh@sysrq.dk)
//
// (C) 2003 Martin Willemoes Hansen
//

namespace System.ComponentModel
{
	public class SByteConverter : BaseNumberConverter
	{
		[MonoTODO]
		public SByteConverter()
		{
		}

		[MonoTODO]
		~SByteConverter()
		{
		}
	}
}
