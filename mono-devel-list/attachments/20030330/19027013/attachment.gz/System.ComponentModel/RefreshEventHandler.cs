//
// System.ComponentModel.RefreshEventHandler
//
// Author:
//   Gonzalo Paniagua Javier (gonzalo@ximian.com)
//
// (C) 2002 Ximian, Inc (http://www.ximian.com)
//

namespace System.ComponentModel
{
	public delegate void RefreshEventHandler (RefreshEventArgs e);
}

