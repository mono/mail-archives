//
// System.ComponentModel.BaseNumberConverter.cs
//
//

namespace System.ComponentModel {
	public class BaseNumberConverter : TypeConverter {
	}
}
