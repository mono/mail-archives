//
// System.ComponentModel.Int32Converter
//
//

namespace System.ComponentModel {
	public class Int32Converter : BaseNumberConverter {
		
	}
}
