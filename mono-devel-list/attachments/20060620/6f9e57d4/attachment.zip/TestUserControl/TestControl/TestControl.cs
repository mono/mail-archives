using System;

namespace TestUserControl
{
	/// <summary>
	/// Summary description for TestControl.
	/// </summary>
	public class TestControl: System.Web.UI.WebControls.LinkButton
	{
		public TestControl(){
		}

		protected override void Render(System.Web.UI.HtmlTextWriter writer) {
			// with only this line the __doPostBack function is missing
			writer.Write("test");
			// uncommenting this line the __doPostBack function is created
			//writer.Write(Page.GetPostBackClientEvent(this,"aaa")); 
		}
	}
}
