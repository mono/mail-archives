using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;
using ShellControls.Interop;

namespace ShellControls {
    public enum ShellLocation {
        ApplicationData = 0x001a,
        RecycleBin = 0x000a,
        CDBurn = 0x003b,
        CommonApplicationData = 0x0023,
        CommonDesktopDirectory = 0x0019,
        CommonDocuments = 0x002e,
        CommonFavourites = 0x001f,
        CommonMusic = 0x0035,
        CommonPictures = 0x0036,
        CommonPrograms = 0X0017,
        CommonStartMenu = 0x0016,
        CommonStartup = 0x0018,
        CommonTemplates = 0x002d,
        CommonVideo = 0x0037,
        ComputersNearMe = 0x003d,
        ControlPanel = 0x0003,
        Desktop = 0x0000,
        DesktopDirectory = 0x0010,
        Favourites = 0x0006,
        Fonts = 0x0014,
        History = 0x0022,
        LocalApplicationData = 0x001c,
        MyComputer = 0x0011,
        MyDocuments = 0x000c,
        MyMusic = 0x000d,
        MyPictures = 0x0027,
        MyVideo = 0x000e,
        NetworkConnections = 0x0031,
        NetworkNeighbourhood = 0x0012,
        Personal = 0x0005,
        Printers = 0x0004,
        ProgramFiles = 0x0026,
        ProgramFilesCommon = 0x002b,
        Programs = 0x0002,
        RecentDocuments = 0x0008,
        StartMenu = 0x000b,
        Startup = 0x0007,
        Templates = 0x0015,
        Windows = 0x0024,
        WindowsSystem = 0x0025,
    }

    public class ShellFolder : IShellItem, IEnumerable<RelativePidl> {
        public ShellFolder(ShellLocation location) {
            IntPtr pidl;
            Marshal.ThrowExceptionForHR(
                Shell32.SHGetFolderLocation(IntPtr.Zero, (CSIDL)location,
                    IntPtr.Zero, 0, out pidl));
            m_Pidl = new AbsolutePidl(pidl, true);
            m_ComInterface = GetIShellFolder(m_Pidl);
        }

        public ShellFolder(string path) {
            uint attributes = 0;
            uint eaten;
            IntPtr pidl;

            try {
                Desktop.m_ComInterface.ParseDisplayName(IntPtr.Zero, IntPtr.Zero,
                    path, out eaten, out pidl, ref attributes);

                m_Pidl = new AbsolutePidl(pidl, true);
                m_ComInterface = GetIShellFolder(m_Pidl);
            } catch (FileNotFoundException e) {
                throw new DirectoryNotFoundException(
                    string.Format("'{0}' is not a valid folder", path),
                    e);
            }
        }

        public ShellFolder(AbsolutePidl pidl) {
            try {
                m_Pidl = pidl;
                m_ComInterface = GetIShellFolder(m_Pidl);
            } catch (FileNotFoundException e) {
                throw new DirectoryNotFoundException(e.Message, e);
            }
        }

        public ShellFolder(IntPtr iunknown, AbsolutePidl pidl) {
            m_Pidl = pidl;
            m_ComInterface = (IShellFolder)
                Marshal.GetTypedObjectForIUnknown(iunknown,
                    typeof(IShellFolder));
        }

        public override bool Equals(object obj) {
            if (obj is ShellFolder) {
                return m_Pidl == ((ShellFolder)obj).m_Pidl;
            } else {
                return false;
            }
        }

        public IShellView CreateViewObject(IntPtr hwndOwner) {
            IntPtr result;
            m_ComInterface.CreateViewObject(hwndOwner, Shell32.IID_IShellView, 
                out result);
            return (IShellView)
                Marshal.GetTypedObjectForIUnknown(result,
                    typeof(IShellView));
        }

        public SFGAO GetAttributes(SFGAO mask) {
            RelativePidl relativePidl;
            ShellFolder parent = GetParent(out relativePidl);
            return parent.GetChildAttributes(relativePidl, mask);
        }

        public ShellFolder GetChild(RelativePidl child) {
            IntPtr result;

            m_ComInterface.BindToObject(child.Handle, IntPtr.Zero,
                Shell32.IID_IShellFolder, out result);
            return new ShellFolder(result, m_Pidl + child);
        }

        public SFGAO GetChildAttributes(RelativePidl child, SFGAO mask) {
            SFGAO result = mask;
            m_ComInterface.GetAttributesOf(1, new IntPtr[] { child.Handle }, ref result);
            return result & mask;
        }

        public string GetChildDisplayName(RelativePidl child) {
            return GetDisplayName(SHGDN.SHGDN_INFOLDER, child);
        }

        public void GetChildIcons(RelativePidl child, out Icon smallIcon, 
                                  out Icon largeIcon) {
            IntPtr result;
            IExtractIcon extractIcon;
            StringBuilder file = new StringBuilder(Windows.MAX_PATH);
            int index;
            GIL flags;
            IntPtr largeIconHandle;
            IntPtr smallIconHandle;

            m_ComInterface.GetUIObjectOf(IntPtr.Zero, 1, 
                new IntPtr[] { child.Handle },
                Shell32.IID_IExtractIcon, 0, out result);
            extractIcon = (IExtractIcon)
                Marshal.GetTypedObjectForIUnknown(result,
                    typeof(IExtractIcon));

            extractIcon.GetIconLocation(GIL.GIL_FORSHELL,
                file, (uint)file.Capacity, out index, out flags);
            extractIcon.Extract(file.ToString(), index, out largeIconHandle,
                out smallIconHandle, 32 | (16 << 16));

            smallIcon = Icon.FromHandle(smallIconHandle);
            largeIcon = Icon.FromHandle(largeIconHandle);
        }

        public string GetChildInfoTip(RelativePidl child) {
            IntPtr result;
            IQueryInfo queryInfo;
            IntPtr infoTipPtr;
            string infoTip;

            m_ComInterface.GetUIObjectOf(IntPtr.Zero, 1, 
                new IntPtr[] { child.Handle },
                Shell32.IID_IQueryInfo, 0, out result);
            queryInfo = (IQueryInfo)
                Marshal.GetTypedObjectForIUnknown(result,
                    typeof(IQueryInfo));
            queryInfo.GetInfoTip(0, out infoTipPtr);
            infoTip = Marshal.PtrToStringUni(infoTipPtr);
            Ole32.CoTaskMemFree(infoTipPtr);
            return infoTip;
        }

        public string GetChildPath(RelativePidl child) {
            return GetDisplayName(SHGDN.SHGDN_FORPARSING, child);
        }

        public ShellContextMenu GetChildContextMenu(RelativePidl[] children) {
            IntPtr[] pidls = new IntPtr[children.Length];
            IntPtr result;
            int n = 0;

            foreach (RelativePidl pidl in children) {
                pidls[n++] = pidl.Handle;
            }

            m_ComInterface.GetUIObjectOf(IntPtr.Zero, (uint)pidls.Length, pidls,
                Shell32.IID_IContextMenu, 0, out result);
            return new ShellContextMenu((IContextMenu)
                Marshal.GetTypedObjectForIUnknown(result,
                    typeof(IContextMenu)));
        }

        public IEnumerator<RelativePidl> GetEnumerator() {
            return GetEnumerator(SHCONTF.SHCONTF_FOLDERS | 
                                 SHCONTF.SHCONTF_NONFOLDERS);
        }

        public IEnumerator<RelativePidl> GetEnumerator(SHCONTF filter) {
            IntPtr result;
            int hresult = m_ComInterface.EnumObjects(IntPtr.Zero,
                filter, out result);

            if (hresult == HRESULT.S_FALSE) {
                return new ShellFolderEnumerator(null);
            }

            Marshal.ThrowExceptionForHR(hresult);
            return new ShellFolderEnumerator(
                (IEnumIDList)Marshal.GetTypedObjectForIUnknown(result,
                    typeof(IEnumIDList)));
        }

        public ShellFolder GetParent(out RelativePidl relative) {
            IntPtr parentFolder;
            IntPtr relativePidl;

            Marshal.ThrowExceptionForHR(
                Shell32.SHBindToParent(m_Pidl.Handle, Shell32.IID_IShellFolder,
                    out parentFolder, out relativePidl));
            relative = new RelativePidl(relativePidl, true);
            return new ShellFolder(parentFolder, m_Pidl.Parent);
        }

        public IShellFolder ComInterface {
            get { return m_ComInterface; }
            set { m_ComInterface = value; }
        }

        public bool HasFileSystemChildren {
            get { return GetAttributes(SFGAO.SFGAO_FILESYSANCESTOR) != 0; }
        }

        public bool IsFileSystem {
            get { return GetAttributes(SFGAO.SFGAO_FILESYSTEM) != 0; }
        }

        public bool IsFolder { 
            get { return true; } 
        }

        public bool IsImmediateParentOf(ShellFolder folder) {
            return m_Pidl.IsImmediateParentOf(folder.Pidl);
        }

        public bool IsParentOf(ShellFolder folder) {
            return m_Pidl.IsParentOf(folder.Pidl);
        }

        public string DisplayName {
            get {
                RelativePidl relativePidl;
                ShellFolder parent = GetParent(out relativePidl);
                return parent.GetChildDisplayName(relativePidl);
            }
        }

        public Icon LargeIcon {
            get {
                SHFILEINFO info = new SHFILEINFO();
                IntPtr result = Shell32.SHGetFileInfo(m_Pidl.Handle, 0, out info,
                    Marshal.SizeOf(info),
                    SHGFI.SHGFI_ADDOVERLAYS | SHGFI.SHGFI_ICON |
                    SHGFI.SHGFI_LARGEICON | SHGFI.SHGFI_PIDL);

                if (result == IntPtr.Zero) {
                    throw new Exception("Error retreiving shell folder icon");
                }

                return Icon.FromHandle(info.hIcon);
            }
        }

        public ShellFolder Parent {
            get {
                RelativePidl relativePidl;
                return GetParent(out relativePidl);
            }
        }

        public string Path {
            get {
                StringBuilder b = new StringBuilder(Windows.MAX_PATH);

                if (IsFileSystem) {
                    Shell32.SHGetPathFromIDList(m_Pidl.Handle, b);
                    return b.ToString();
                } else {
                    throw new Exception("Folder is a virtual folder");
                }
            }
        }

        public AbsolutePidl Pidl {
            get { return m_Pidl; }
        }

        public Icon ShellIcon {
            get {
                SHFILEINFO info = new SHFILEINFO();
                IntPtr result = Shell32.SHGetFileInfo(m_Pidl.Handle, 0, out info,
                    Marshal.SizeOf(info),
                    SHGFI.SHGFI_ADDOVERLAYS | SHGFI.SHGFI_ICON |
                    SHGFI.SHGFI_SHELLICONSIZE | SHGFI.SHGFI_PIDL);

                if (result == IntPtr.Zero) {
                    throw new Exception("Error retreiving shell folder icon");
                }

                return Icon.FromHandle(info.hIcon);
            }
        }

        public Icon SmallIcon {
            get {
                SHFILEINFO info = new SHFILEINFO();
                IntPtr result = Shell32.SHGetFileInfo(m_Pidl.Handle, 0, out info,
                    Marshal.SizeOf(info),
                    SHGFI.SHGFI_ADDOVERLAYS | SHGFI.SHGFI_ICON |
                    SHGFI.SHGFI_SMALLICON | SHGFI.SHGFI_PIDL);

                if (result == IntPtr.Zero) {
                    throw new Exception("Error retreiving shell folder icon");
                }

                return Icon.FromHandle(info.hIcon);
            }
        }

        public string ToolTipText {
            get {
                RelativePidl relative;
                ShellFolder parent = GetParent(out relative);
                return parent.GetChildInfoTip(relative);
            }
        }

        public static ShellFolder Desktop {
            get {
                if (m_Desktop == null) {
                    IntPtr result;
                    IntPtr pidl;

                    Marshal.ThrowExceptionForHR(
                        Shell32.SHGetDesktopFolder(out result));
                    Marshal.ThrowExceptionForHR(
                        Shell32.SHGetFolderLocation(IntPtr.Zero, CSIDL.CSIDL_DESKTOP,
                            IntPtr.Zero, 0, out pidl));
                    m_Desktop = new ShellFolder(result, new AbsolutePidl(pidl, true));
                }
                return m_Desktop;
            }
        }

        public static bool operator ==(ShellFolder a, ShellFolder b) {
            if (object.ReferenceEquals(a, null)) {
                return object.ReferenceEquals(b, null);
            } else {
                return a.Equals(b);
            }
        }

        public static bool operator !=(ShellFolder a, ShellFolder b) {
            if (object.ReferenceEquals(a, null)) {
                return !object.ReferenceEquals(b, null);
            } else {
                return !a.Equals(b);
            }
        }

        #region IEnumerable Members

        IEnumerator IEnumerable.GetEnumerator() {
            return ((IEnumerable<IntPtr>)this).GetEnumerator();
        }

        #endregion

        string GetDisplayName(SHGDN flags, RelativePidl child) {
            STRRET pstr;
            StringBuilder builder = new StringBuilder(Windows.MAX_PATH);

            m_ComInterface.GetDisplayNameOf(child.Handle, flags, out pstr);
            ShlWapi.StrRetToBuf(ref pstr, IntPtr.Zero, builder,
                (uint)builder.Capacity);
            return builder.ToString();
        }

        static IShellFolder GetIShellFolder(AbsolutePidl pidl) {
            IntPtr result;

            if (Marshal.ReadInt16(pidl.Handle) != 0) {
                Desktop.m_ComInterface.BindToObject(pidl.Handle, IntPtr.Zero,
                    Shell32.IID_IShellFolder, out result);
                return (IShellFolder)
                    Marshal.GetTypedObjectForIUnknown(result,
                        typeof(IShellFolder));
            } else {
                return Desktop.m_ComInterface;
            }
        }

        IShellFolder m_ComInterface;
        AbsolutePidl m_Pidl;
        static ShellFolder m_Desktop;
    }

    class ShellFolderEnumerator : IEnumerator<RelativePidl> {
        public ShellFolderEnumerator(IEnumIDList enumerator) {
            m_Enumerator = enumerator;
        }

        public RelativePidl Current {
            get { return m_Current; }
        }

        object IEnumerator.Current {
            get { return m_Current; }
        }

        public void Dispose() {
            Marshal.ReleaseComObject(m_Enumerator);
        }

        public bool MoveNext() {
            uint count;
            IntPtr pidl;

            int hresult = m_Enumerator.Next(1, out pidl, out count);

            if (hresult == HRESULT.S_OK) {
                m_Current = new RelativePidl(pidl, true);
                return true;
            } else if (hresult == HRESULT.S_FALSE) {
                return false;
            } else {
                Marshal.ThrowExceptionForHR(hresult);
                return false;
            }
        }

        public void Reset() {
            m_Enumerator.Reset();
        }

        IEnumIDList m_Enumerator;
        RelativePidl m_Current;
    }
}
