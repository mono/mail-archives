using System;
using System.Collections;
using System.Configuration;
using System.Reflection;
using System.Xml;

namespace ConfigurationSectionTestCase
{
    public class TestSectionHandler : IConfigurationSectionHandler
    {
        #region IConfigurationSectionHandler Members

        public object Create(object parent, object configContext, XmlNode section)
        {
            System.Diagnostics.Debug.WriteLine(string.Format("configContext is null = {0}", configContext == null));
            if (configContext == null)
                throw new ArgumentException("configContext should not be null when called from ASP.NET!");

            return this;
        }

        #endregion
    }
}
