
#include <stdio.h>
#include <sys/time.h>
#include "Matrix.hpp"

using namespace std;


static void Populate (Matrix* mat, double alpha)
{
	int ncols = mat->getNoOfColumns();
	int nrows = mat->getNoOfRows();
	
	double v = alpha;
	for (int ci = 0 ; ci < ncols ; ci++)
	{
		for (int ri = 0 ; ri < nrows ; ri++)
		{
			mat->set(ri,ci, v++); 
		}
	}
}


static long CurrentTimeMilli ()
{
	struct timeval T;
	gettimeofday(&T, NULL);
	
	return (long)T.tv_sec * 1000L + (long)T.tv_usec / 1000L;
}


static void TestSafe (int dim, int iterations)
{
	Matrix* A = new Matrix (dim,dim);
	Matrix* B = new Matrix (dim,dim);
	Matrix* R = new Matrix (dim,dim);

	long Tstart = CurrentTimeMilli();
	
	double sum = 0;
	double alpha = 1e-5;
	for (int i = 0 ; i < iterations ; i++)
	{
		Populate (A, alpha);
		Populate (B, alpha / 10.0);
		
		multiply (A,B, R);
		int idx = (i % dim);
		sum += R->get(idx,idx);
	}
	
	long Tend = CurrentTimeMilli();
	long Telapsed = (Tend-Tstart);
	
	printf ("safe value: %lf, elapsed: %02d:%02d:%03d\n", sum, (int)(Telapsed / 60000), (int)(Telapsed % 60000) / 1000, (int)(Telapsed % 1000));
}



static void TestJustMultiply (int dim, int iterations)
{
	Matrix* A = new Matrix (dim,dim);
	Matrix* B = new Matrix (dim,dim);
	Matrix* R = new Matrix (dim,dim);

	double alpha = 1e-5;
	Populate (A, alpha);
	Populate (B, alpha / 10.0);

	long Tstart = CurrentTimeMilli();
	
	double sum = 0;
	for (int i = 0 ; i < iterations ; i++)
	{
		multiply (A,B, R);
		int idx = (i % dim);
		sum += R->get(idx,idx);
	}
	
	long Tend = CurrentTimeMilli();
	long Telapsed = (Tend-Tstart);
	
	printf ("mul value: %lf, elapsed: %02d:%02d:%03d\n", sum, (int)(Telapsed / 60000), (int)(Telapsed % 60000) / 1000, (int)(Telapsed % 1000));
}


int main (int argc, char *argv[])
{
	TestJustMultiply (200, 10000);
	TestSafe (200, 10000);
	
	return 0;
}

