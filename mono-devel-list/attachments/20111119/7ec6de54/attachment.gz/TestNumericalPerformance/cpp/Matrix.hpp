
class Matrix
{
	public:
	
		Matrix (int nrow, int ncol)
			: _data(new double[nrow*ncol]), _nrow(nrow), _ncol(ncol) { }

		~Matrix ()
			{ delete _data; }
			
		int getNoOfColumns () const
			{ return _ncol; }
	
		int getNoOfRows () const
			{ return _nrow; }
			
		double get (int row, int col)
			{ return _data[row*col]; }
			
		void set (int row, int col, double v)
			{ _data[row*col] = v; }
	
		friend Matrix* multiply (Matrix* A, Matrix* B, Matrix* R);
	
	private:
	
		double*		_data;
		int			_nrow;
		int			_ncol;
};

