
#include "Matrix.hpp"


Matrix* multiply (Matrix* A, Matrix* B, Matrix* R)
{
	int stride = A->_nrow;
	int rows = R->_nrow;
	int cols = R->_ncol;
			
	int acols = A->_ncol;
	int brows = B->_nrow;
	
	int aidx = 0;
	int bidx = 0;
	int ridx = 0;
	
	double* va = A->_data;
	double* vb = B->_data;
	double* vr = R->_data;
	
	for (int ci = 0 ; ci < cols ; ci++)
	{
		for (int ri = 0 ; ri < rows ; ri++)
		{
			double sprod = 0;
			for (int aci = 0 ; aci < acols ; aci++)
			{
				sprod += va[aidx] * vb[bidx];
				aidx += stride;
				bidx++;
			}
			
			vr[ridx++] = sprod;
			
			// advance A index to next row, reset B column index
			aidx -= (stride*acols) - 1;
			bidx -= brows;
		}
		
		aidx = 0;
		bidx = (ci * brows);
	}
	
	return R;
}
