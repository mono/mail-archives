
package test;

public final class SafeMatrix implements IMatrix
{
    public SafeMatrix (int nrow, int ncol)
	{
	    _data = new double[nrow*ncol];
	    _nrow = nrow;
	    _ncol = ncol;
	}
		
    // Properties
				
    public int getColumns()
    	{ return _ncol; }
		
    public int getRows()
    	{ return _ncol; }

		
    /// <summary>
    /// Gets or sets the row,col item of matrix
    /// </summary>
    /// <param name='row'>
    /// Row.
    /// </param>
    /// <param name='col'>
    /// Col.
    /// </param>
    public double get (int row, int col)
    { 
		return _data[col*_nrow + row];
    }
		
    /// <summary>
    /// Gets or sets the row,col item of matrix
    /// </summary>
    /// <param name='row'>
    /// Row.
    /// </param>
    /// <param name='col'>
    /// Col.
    /// </param>
    public void set (int row, int col, double v)
    { 
		_data[col*_nrow + row] = v;
    }
		
		
    // Functions
		
		
    /// <summary>
    /// Multiple the specified A & B matrices, putting result into R
    /// </summary>
    /// <param name='a'>
    /// A.
    /// </param>
    /// <param name='b'>
    /// B.
    /// </param>
    /// <param name='r'>
    /// R.
    /// </param>
    public static SafeMatrix multiply (SafeMatrix a, SafeMatrix b, SafeMatrix r)
    {			
		int stride = a._nrow;
		int rows = r._nrow;
		int cols = r._ncol;
						
		int acols = a._ncol;
		int brows = b._nrow;
				
		int aidx = 0;
		int bidx = 0;
		int ridx = 0;
				
		double[] va = a._data;
		double[] vb = b._data;
		double[] vr = r._data;
				
		for (int ci = 0 ; ci < cols ; ci++)
		{
			for (int ri = 0 ; ri < rows ; ri++)
			{
				double sprod = 0;
				for (int aci = 0 ; aci < acols ; aci++)
				{
					sprod += va[aidx] * vb[bidx];
					aidx += stride;
					bidx++;
				}
						
				vr[ridx++] = sprod;
						
				// advance A index to next row, reset B column index
				aidx -= (stride*acols) - 1;
				bidx -= brows;
			}
					
			aidx = 0;
			bidx = (ci * brows);
		}
				
		return r;
    }
					
					
		
    // Variables
		
    private double[]	_data;
    private int		_nrow;
    private int		_ncol;
}
