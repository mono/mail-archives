
package test;

interface IMatrix
{
	int getColumns();
	int getRows();

	double get(int row, int col);
	void set (int row, int col, double v);
}