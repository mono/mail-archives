
package test;

class TestPerformance
{
    private static void Populate (IMatrix mat, double alpha)
    {
		int ncols = mat.getColumns();
		int nrows = mat.getRows();
			
		double v = alpha;
		for (int ci = 0 ; ci < ncols ; ci++)
		{
			for (int ri = 0 ; ri < nrows ; ri++)
			{
				mat.set (ri,ci, v++); 
			}
		}
    }
		
		
    private static void TestSafe (int dim, int iterations)
    {
		SafeMatrix A = new SafeMatrix (dim,dim);
		SafeMatrix B = new SafeMatrix (dim,dim);
		SafeMatrix R = new SafeMatrix (dim,dim);
		
		long Tstart = System.currentTimeMillis();
					
		double sum = 0;
		double alpha = 1e-5;
		for (int i = 0 ; i < iterations ; i++)
	    {
			Populate (A, alpha);
			Populate (B, alpha / 10.0);
					
			SafeMatrix.multiply (A,B, R);
			int idx = (i % dim);
			sum += R.get(idx,idx);
	    }
			
		long Tend = System.currentTimeMillis();
	
		System.err.println ("safe value: " + sum + ", elapsed: " + elapsed (Tend - Tstart));
    }

    private static String elapsed (long ms)
    {
		int nmin = (int)(ms / 60000);
		int sec = (int)(ms % 60000) / 1000;
		int msec = (int)(ms % 1000);
	
		return String.format ("%02d:%02d.%03d", nmin, sec, msec);
    }
		
    public static void main (String[] args)
    {
		TestSafe (200,10000);
    }
}
