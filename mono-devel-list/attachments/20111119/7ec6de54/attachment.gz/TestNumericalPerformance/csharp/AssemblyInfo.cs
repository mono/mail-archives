//  
//  	Authors
//  		Jonathan Shore
//  
//  	Copyright:
//  		2011 Genetic Finance LLC 
//  		2002 Systematic Trading LLC
//  
//  		This software is only to be used for the purpose for which
//  		it has been provided.  No part of it is to be reproduced,
//  		disassembled, transmitted, stored in a retrieval system nor
//  		translated in any human or computer language in any way or
//  		for any other purposes whatsoever without the prior written
//  		consent of Genetic Finance LLC and Systematic Trading LLC
// 
//  
// 
using System.Reflection;
using System.Runtime.CompilerServices;

// Information about this assembly is defined by the following attributes. 
// Change them to the values specific to your project.

[assembly: AssemblyTitle("TestNumericalPerformance")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("")]
[assembly: AssemblyCopyright("jshore")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// The assembly version has the format "{Major}.{Minor}.{Build}.{Revision}".
// The form "{Major}.{Minor}.*" will automatically update the build and revision,
// and "{Major}.{Minor}.{Build}.*" will update just the revision.

[assembly: AssemblyVersion("1.0.*")]

// The following attributes are used to specify the signing key for the assembly, 
// if desired. See the Mono documentation for more information about signing.

//[assembly: AssemblyDelaySign(false)]
//[assembly: AssemblyKeyFile("")]

