//  
//  	Authors
//  		Jonathan Shore
//  
//  	Copyright:
//  		2011 Genetic Finance LLC 
//  		2002 Systematic Trading LLC
//  
//  		This software is only to be used for the purpose for which
//  		it has been provided.  No part of it is to be reproduced,
//  		disassembled, transmitted, stored in a retrieval system nor
//  		translated in any human or computer language in any way or
//  		for any other purposes whatsoever without the prior written
//  		consent of Genetic Finance LLC and Systematic Trading LLC
// 
//  
// 
using System;
using System.Diagnostics;

namespace TestNumericalPerformance
{
	class MainClass
	{
		private static void Populate<T> (T mat, double alpha) where T : IMatrix
		{
			var ncols = mat.Columns;
			var nrows = mat.Rows;
			
			double v = alpha;
			for (int ci = 0 ; ci < ncols ; ci++)
			{
				for (int ri = 0 ; ri < nrows ; ri++)
				{
					mat[ri,ci] = v++; 
				}
			}
		}
		
		
		private static void TestSafe (int dim, int iterations)
		{
			SafeMatrix A = new SafeMatrix (dim,dim);
			SafeMatrix B = new SafeMatrix (dim,dim);
			SafeMatrix R = new SafeMatrix (dim,dim);
			
			Stopwatch watch = new Stopwatch ();
			watch.Start();
			
			double sum = 0;
			double alpha = 1e-5;
			for (int i = 0 ; i < iterations ; i++)
			{
				Populate (A, alpha);
				Populate (B, alpha / 10.0);
				
				SafeMatrix.multiply (A,B, R);
				var idx = (i % dim);
				sum += R[idx,idx];
			}
			
			watch.Stop();
			Console.WriteLine ("safe value: " + sum + ", elapsed: " + watch.Elapsed);
		}
		
		private static void TestUnSafe (int dim, int iterations)
		{
			UnSafeMatrix A = new UnSafeMatrix (dim,dim);
			UnSafeMatrix B = new UnSafeMatrix (dim,dim);
			UnSafeMatrix R = new UnSafeMatrix (dim,dim);
			
			Stopwatch watch = new Stopwatch ();
			watch.Start();
			
			double sum = 0;
			double alpha = 1e-5;
			for (int i = 0 ; i < iterations ; i++)
			{
				Populate (A, alpha);
				Populate (B, alpha / 10.0);
				
				UnSafeMatrix.multiply (A,B, R);
				var idx = (i % dim);
				sum += R[idx,idx];
			}
			
			watch.Stop();
			Console.WriteLine ("unsafe value: " + sum + ", elapsed: " + watch.Elapsed);
		}

		
		private static void TestJustMultiply (int dim, int iterations)
		{
			UnSafeMatrix A = new UnSafeMatrix (dim,dim);
			UnSafeMatrix B = new UnSafeMatrix (dim,dim);
			UnSafeMatrix R = new UnSafeMatrix (dim,dim);

			double alpha = 1e-5;
			Populate (A, alpha);
			Populate (B, alpha / 10.0);

			Stopwatch watch = new Stopwatch ();
			watch.Start();
			
			double sum = 0;
			for (int i = 0 ; i < iterations ; i++)
			{
				UnSafeMatrix.multiply (A,B, R);
				var idx = (i % dim);
				sum += R[idx,idx];
			}
			
			watch.Stop();
			Console.WriteLine ("just mul value: " + sum + ", elapsed: " + watch.Elapsed);
		}
		
		
		public static void Main (string[] args)
		{			
			TestJustMultiply (200,10000);
			TestUnSafe (200,10000);
			TestSafe (200,10000);
		}
	}
}
