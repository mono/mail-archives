//  
//  	Authors
//  		Jonathan Shore
//  
//  	Copyright:
//  		2011 Genetic Finance LLC 
//  		2002 Systematic Trading LLC
//  
//  		This software is only to be used for the purpose for which
//  		it has been provided.  No part of it is to be reproduced,
//  		disassembled, transmitted, stored in a retrieval system nor
//  		translated in any human or computer language in any way or
//  		for any other purposes whatsoever without the prior written
//  		consent of Genetic Finance LLC and Systematic Trading LLC
// 
//  
// 
using System;

namespace TestNumericalPerformance
{
	public sealed class SafeMatrix : IMatrix
	{
		public SafeMatrix (int nrow, int ncol)
		{
			_data = new double[nrow*ncol];
			_nrow = nrow;
			_ncol = ncol;
		}
		
		// Properties
				
		public int Columns
			{ get { return _ncol; } }
		
		public int Rows
			{ get { return _ncol; } }

		
		/// <summary>
		/// Gets or sets the row,col item of matrix
		/// </summary>
		/// <param name='row'>
		/// Row.
		/// </param>
		/// <param name='col'>
		/// Col.
		/// </param>
		public double this [int row, int col]
		{ 
			get { return _data[col*_nrow + row]; }
			set { _data[col*_nrow + row] = value; }
		}
		
		
		// Functions
		
		
		/// <summary>
		/// Multiple the specified A & B matrices
		/// </summary>
		/// <param name='a'>
		/// A.
		/// </param>
		/// <param name='b'>
		/// B.
		/// </param>
		public static SafeMatrix operator* (SafeMatrix a, SafeMatrix b)
		{
			return multiply (a,b, new SafeMatrix(a._nrow, b._ncol));
		}

		
		/// <summary>
		/// Multiple the specified A & B matrices, putting result into R
		/// </summary>
		/// <param name='a'>
		/// A.
		/// </param>
		/// <param name='b'>
		/// B.
		/// </param>
		/// <param name='r'>
		/// R.
		/// </param>
		public static SafeMatrix multiply (SafeMatrix a, SafeMatrix b, SafeMatrix r)
		{			
			var stride = a._nrow;
			var rows = r._nrow;
			var cols = r._ncol;
					
			var acols = a._ncol;
			var brows = b._nrow;
			
			var aidx = 0;
			var bidx = 0;
			var ridx = 0;
			
			var va = a._data;
			var vb = b._data;
			var vr = r._data;
			
			for (int ci = 0 ; ci < cols ; ci++)
			{
				for (int ri = 0 ; ri < rows ; ri++)
				{
					double sprod = 0;
					for (int aci = 0 ; aci < acols ; aci++)
					{
						sprod += va[aidx] * vb[bidx];
						aidx += stride;
						bidx++;
					}
					
					vr[ridx++] = sprod;
					
					// advance A index to next row, reset B column index
					aidx -= (stride*acols) - 1;
					bidx -= brows;
				}
				
				aidx = 0;
				bidx = (ci * brows);
			}
			
			return r;
		}
					
					
		
		// Variables
		
		private double[]	_data;
		private int			_nrow;
		private int			_ncol;
	}
}

