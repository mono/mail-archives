#!/bin/bash
xsp --port 8088 --applications /MainsoftWebApp:./ --nonstop &