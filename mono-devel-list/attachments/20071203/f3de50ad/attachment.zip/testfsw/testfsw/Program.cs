using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Threading;

namespace testfsw
{
    class Program
    {
        private FileSystemWatcher fs = new FileSystemWatcher();
        private String PathToWatch = null;

        public Program(String path)
        {

            this.PathToWatch = path;

            Thread nt = new Thread(run);
            nt.Start();

        }

        static void Main(string[] args)
        {
            if (RunningOnMono())
                new Program("/");
            else
                new Program("C:\\");
        }

        void run()
        {
            fs.Path = PathToWatch;

            fs.NotifyFilter = ((System.IO.NotifyFilters)((((System.IO.NotifyFilters.FileName | System.IO.NotifyFilters.DirectoryName)
                        | System.IO.NotifyFilters.LastWrite)
                        | System.IO.NotifyFilters.CreationTime)
                        ));

            fs.IncludeSubdirectories = true;
            fs.EnableRaisingEvents = true;

            fs.Changed += new FileSystemEventHandler(fsw_Changed);
            fs.Created += new FileSystemEventHandler(fsw_Changed);
            fs.Renamed += new RenamedEventHandler(fsw_Renamed);
            fs.Deleted += new FileSystemEventHandler(fsw_Changed);

            try
            {
                Console.WriteLine(DateTime.Now + " Starting testfsw for ... " + fs.Path.ToString());

                while (true)
                {
                    try
                    {
                        fs.WaitForChanged(WatcherChangeTypes.All);
                    }
                    catch (ThreadAbortException ex)
                    {
                        Console.WriteLine(DateTime.Now + ex.Message);
                    }
                }
            }
            catch (Exception ex)
            {

                Console.WriteLine(DateTime.Now + ex.Message);
            }

        }

        public void fsw_Changed(object sender, System.IO.FileSystemEventArgs e)
        {
            Console.WriteLine(DateTime.Now + " Type: " + e.ChangeType + " Fullpath: "
                            + e.FullPath + " Name: " + e.Name);

        }

        private void fsw_Renamed(object sender, RenamedEventArgs e)
        {
            Console.WriteLine(DateTime.Now + " Type: " + e.ChangeType + " Fullpath: " + e.FullPath + " OldFullpath:" + e.OldFullPath +
                     " Name: " + e.Name + " OldName: " + e.OldName);

        }

        private static bool RunningOnMono()
        {
            bool bMono = false;
            try
            {
                Type t = Type.GetType("Mono.Runtime");
                if (t != null)
                {
                    bMono = true;
                }
                else
                {
                    bMono = false;
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(DateTime.Now + ex.Message);
            }
            finally
            {
            }
            return bMono;
        }

    }
}
