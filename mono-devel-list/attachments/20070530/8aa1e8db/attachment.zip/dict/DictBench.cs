using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;

using HotFeet;

namespace Test {
	class DictionaryBench {
		static bool useNewVersion = false;
		
		static void Main(string[] args) {
			if(args.Length < 2) {
				Console.WriteLine("Usage: mono DictPerf.exe [number of seconds] [old|new]");
				return;
			}		
		
			int seconds = int.Parse(args[0]);
			useNewVersion = (args[1] == "new");
				
			Console.WriteLine(
				"Using {0}.Dictionary<K,V>",
				(useNewVersion ? "Test" : "System.Collections.Generic")
			);
			Console.WriteLine();
	
			Type t = typeof(DictionaryBench);
			MethodInfo[] methods = {
				t.GetMethod("ClassicHashtable"),
				t.GetMethod("SmallDict"),
				t.GetMethod("DictIntInt"),
				t.GetMethod("DictIntInt"),
				t.GetMethod("DictIntInt2"),
				t.GetMethod("DictObjObj"),
				t.GetMethod("DictDoubleDouble")
			};
			
			CodeBench.Run(methods, seconds);
		}			
		
		public static void ClassicHashtable() {
			Random rnd = new Random(12345);
			System.Collections.Hashtable ht = new System.Collections.Hashtable();
		
			for(int j = 0; j < 25000; j++) {
				int num = rnd.Next() % 10000000;
				if(ht.ContainsKey(num))
					ht[num] = num;
				else
					ht.Add(num, num);
			}
			for(int j = 0; j < 25000; j++) {
				int num = rnd.Next() % 10000000;
				if(ht.ContainsKey(num))
					ht.Remove(num);
				else
					ht.Add(num, num);
			}
		}
		
		public static void SmallDict() {
			IDictionary<string, int> dict;
			if(useNewVersion)
				dict = new Test.Dictionary<string, int> ();
			else
				dict = new System.Collections.Generic.Dictionary<string, int> ();

			string[] ss = new string[] { "BestFitMapping", "CallingConvention",
					"ExactSpelling", "SetLastError", "ThrowOnUnmappableChar", "xx", "oo", "uu", "tt", "yy" };
			int i = 0;
			foreach (string s in ss)
				dict.Add (s, i++);

			for (int ii = 0; ii < 50000; ++ii)
				dict.TryGetValue ("xx", out i);
		}

		public static void DictIntInt() {
			Random rnd = new Random(12345);		 	
			IDictionary<int, int> dict;
			if(useNewVersion)
				dict = new Test.Dictionary<int, int> ();
			else
				dict = new System.Collections.Generic.Dictionary<int, int> ();
			
			for(int i = 0; i < 5000; i++) {
				int num = rnd.Next() % 10000000;
				dict[num] = num;
			}
			
			int x, j;
			for (int ii = 0; ii < 25000; ++ii)
			{
				dict.TryGetValue (ii % 1000, out j);
				if(dict.ContainsKey(ii % 1000 + 1))
					x = dict[ii % 1000 + 1];
			}
			x++;
		}			
			
		public static void DictIntInt2() {
			Random rnd = new Random(12345);
			IDictionary<int, int> dict;
			if(useNewVersion)
				dict = new Test.Dictionary<int, int> ();
			else
				dict = new System.Collections.Generic.Dictionary<int, int> ();
			
			for(int i = 0; i < 2500; i++) {
				int num = rnd.Next() % 10000000;
				if(dict.ContainsKey(num))
					dict[num] = num;
				else
					dict.Add(num, num);
			}
			for(int i = 0; i < 2500; i++) {
				int num = rnd.Next() % 10000000;
				if(dict.ContainsKey(num))
					dict.Remove(num);
				else
					dict.Add(num, num);
			}
		}

		public static void DictObjObj() { 	
			Random rnd = new Random(12345);
			IDictionary<object, object> dict;
			if(useNewVersion)
				dict = new Test.Dictionary<object, object> ();
			else
				dict = new System.Collections.Generic.Dictionary<object, object> ();
			
			for(int i = 0; i < 2500; i++) {
				int num = rnd.Next() % 10000000;
				if(dict.ContainsKey(num))
					dict[num] = num;
				else
					dict.Add(num, num);
			}
			for(int i = 0; i < 2500; i++) {
				int num = rnd.Next() % 10000000;
				if(dict.ContainsKey(num))
					dict.Remove(num);
				else
					dict.Add(num, num);
			}
		}

		public static void DictDoubleDouble() { 	
			Random rnd = new Random(12345);
			IDictionary<double, double> dict;
			if(useNewVersion)
				dict = new Test.Dictionary<double, double> ();
			else
				dict = new System.Collections.Generic.Dictionary<double, double> ();
			
			for(int i = 0; i < 2500; i++) {
				double num = rnd.NextDouble();
				if(dict.ContainsKey(num))
					dict[num] = num;
				else
					dict.Add(num, num);
			}
			for(int i = 0; i < 2500; i++) {
				double num = rnd.NextDouble();
				if(dict.ContainsKey(num))
					dict.Remove(num);
				else
					dict.Add(num, num);
			}
		}
	}
}
