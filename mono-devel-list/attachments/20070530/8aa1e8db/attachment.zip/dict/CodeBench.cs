using System;
using System.Collections;
using System.Reflection;

namespace HotFeet {
	public class CodeBench {
		struct MethodTiming {
			public MethodInfo Method;
			public long TotalTicks;
		}
		
		public static void Run(MethodInfo[] methodsToTest, int seconds) {
			Console.WriteLine("Following methods will be tested (= one cycle):");
			for(int i = 0; i < methodsToTest.Length; i++)
				Console.WriteLine("  {0}", methodsToTest[i]);
			Console.WriteLine();
		
			long totalDuration = seconds * TimeSpan.TicksPerSecond;
	
			MethodTiming[] methods = new MethodTiming[methodsToTest.Length];
			for(int i = 0; i < methods.Length; i++)
				methods[i].Method = methodsToTest[i];
	
			Console.Write("Testing how many full cycles fit in one second... ");
			long start = DateTime.Now.Ticks;
			long end = start + TimeSpan.TicksPerSecond;
			
			int fullRuns = 0;
			while(DateTime.Now.Ticks < end) {
				for(int i = 0; i < methods.Length; i++) {
					long s = DateTime.Now.Ticks;
					methods[i].Method.Invoke(null, null); 
					methods[i].TotalTicks += DateTime.Now.Ticks - s;
				}
				fullRuns++;
			}
			long initDuration = DateTime.Now.Ticks - start;
			Console.WriteLine("{0}.", fullRuns);
			
			// calc how many full cycles fit in remaining seconds (rounding up)
			int fullCycles = (int)((totalDuration + initDuration - 1) / initDuration - 1) * fullRuns;
			
			// spread method calls evenly
			int[] testComposition = new int[fullCycles * methods.Length];
			for(int i = 0; i < fullCycles; i++) {
				for(int j = 0; j < methods.Length; j++)
					testComposition[i * methods.Length + j] = j;
			}
			Shuffle(testComposition);
			
			for(int i = 0; i < methods.Length; i++)
				methods[i].TotalTicks = 0;
			
			Console.Write("Doing the testing ({0} full cycles)... ", fullCycles);
			start = DateTime.Now.Ticks;
			for(int idx = 0; idx < testComposition.Length; idx++) {
				int i = testComposition[idx];
					long s = DateTime.Now.Ticks;
					methods[i].Method.Invoke(null, null); 
					methods[i].TotalTicks += DateTime.Now.Ticks - s;
			}
			Console.WriteLine("done.");
			Console.WriteLine();		
			
			Console.WriteLine("Results:");
			for(int i = 0; i < methods.Length; i++) {
				Console.WriteLine(
					"  {0}: {1} [ticks/run]",
					methods[i].Method,
					(methods[i].TotalTicks + fullCycles >> 1) / fullCycles
				);
			}
		}

		static void Shuffle(IList list) {
			Random rnd = new Random();
		
			for(int i = 0; i < list.Count - 1; i++)
				Swap(list, i, i + rnd.Next(list.Count - i));
		}
		
		static void Swap(IList list, int index1, int index2) {
			object temp = list[index1];
			list[index1] = list[index2];
			list[index2] = temp; 
		}
	}
}