using System;

namespace Test {
	public class Hashtable
	{
		private static readonly int [] primeTbl = {
			11, // +8, 3
			19, // +18, 4
			37, // +36, 5
			73, // +36, 6
			109, // +54, 6
			163, // +88, 7 => 88/2 = 44
			251, // +116, 7 => 116/2 = 58
			367, // +190, 8 => 190/3 = 63
			557, // +266, 9 => 266/4 = 66
			823, // +414, 9 => 414/4 = 103
			1237, // +636, 10 => 636/5 = 127
			1861, // +916, 10 => 916/5 = 183
			2777, // +1400, 11 => 1400/6 = 233
			4177, // +2070, 12 => 2070/7 = 295
			6247, // +3124, 12 => 3124/7 = 446
			9371, // +4686, 13 => 4686/8 = 585
			14057, // +7032, 13 => 7032/8 = 879
			21089, // +10538, 14 => 10538/9 = 1170
			31627, // +15804, 14 => 15804/9 = 1756
			47431, // +23712, 15 => 23712/10 = 2371
			71143, // +35578, 16 => 35578/11 = 3234
			106721, // 16
			160073, // 17
			240101, // 17
			360163, // 18
			540217, // 19
			810343, // 19
			1215497, // 20
			1823231, // 20
			2734867, // 21
			4102283, // 21
			6153409, // 22
			9230113, // 23
			13845163 // 23
		};

		internal static bool TestPrime (int x)
		{
			if ((x & 1) != 0) {
				int top = (int)Math.Sqrt (x);
				
				for (int n = 3; n < top; n += 2) {
					if ((x % n) == 0)
						return false;
				}
				return true;
			}
			// There is only one even prime - 2.
			return (x == 2);
		}

		internal static int CalcPrime (int x)
		{
			for (int i = (x & (~1))-1; i< Int32.MaxValue; i += 2) {
				if (TestPrime (i)) return i;
			}
			return x;
		}

		internal static int ToPrime (int x)
		{
			for (int i = 0; i < primeTbl.Length; i++) {
				if (x <= primeTbl [i])
					return primeTbl [i];
			}
			return CalcPrime (x);
		}
	}
}
