﻿namespace Interface
{
    public interface IHello
    {
        void SayHello(string sender, IHello remoteRef);
        void Hello(string sender);
    }
}
