﻿using System;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Http;
using Interface;

namespace Client
{
    public class HelloClientImpl : MarshalByRefObject, IHello
    {
        public void SayHello(string sender, IHello remoteRef)
        {
            Console.Out.WriteLine("SayHello from {0}", sender);
        }

        public void Hello(string sender)
        {
            Console.Out.WriteLine("Hello from {0}", sender);
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            int port = 7324;
            
            BinaryServerFormatterSinkProvider serverProv = new BinaryServerFormatterSinkProvider();
            serverProv.TypeFilterLevel = System.Runtime.Serialization.Formatters.TypeFilterLevel.Full;
            BinaryClientFormatterSinkProvider clientProv = new BinaryClientFormatterSinkProvider();
            System.Collections.IDictionary props = new System.Collections.Hashtable();
            props["port"] =  7324; 

            HttpChannel channel = new HttpChannel(props, clientProv,serverProv); //Create a new channel
            ChannelServices.RegisterChannel(channel, false); //Register channel

            HelloClientImpl helloImpl = new HelloClientImpl();
            var helloObjRef = RemotingServices.Marshal(helloImpl, "client", typeof(IHello));
            
            Console.WriteLine("Client listening on port {0}", port);

            var uri = "http://" + args[0] + ":7326/server";

            Console.Out.WriteLine("Looking up {0}", uri);
            var remoteObjRef = (IHello) Activator.GetObject(typeof(IHello), uri);

            Console.Out.WriteLine("Calling Hello");
            remoteObjRef.Hello("client");
            Console.Out.WriteLine("Done");

            Console.Out.WriteLine("Calling SayHello");
            remoteObjRef.SayHello("client", helloImpl);
            Console.Out.WriteLine("Done");
        }
    }
}
