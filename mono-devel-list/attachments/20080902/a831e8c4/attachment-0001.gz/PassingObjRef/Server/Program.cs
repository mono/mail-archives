﻿using System;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Http;
using Interface;

namespace Server
{
    public class HelloPingback : MarshalByRefObject, IHello
    {
        public void SayHello(string sender, IHello remoteRef)
        {
            Console.Out.WriteLine("SayHello from {0}", sender);
            try
            {
                remoteRef.Hello("server");
            }
            catch (Exception e)
            {
                Console.Out.WriteLine(e);
            }
            Console.Out.WriteLine("Exit SayHello from {0}", sender);
        }

        public void Hello(string sender)
        {
            Console.Out.WriteLine("Hello from {0}", sender);
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            BinaryServerFormatterSinkProvider serverProv = new BinaryServerFormatterSinkProvider();
            serverProv.TypeFilterLevel = System.Runtime.Serialization.Formatters.TypeFilterLevel.Full;
            BinaryClientFormatterSinkProvider clientProv = new BinaryClientFormatterSinkProvider();
            System.Collections.IDictionary props = new System.Collections.Hashtable();
            props["port"] = 7326;

            HttpChannel channel = new HttpChannel(props, clientProv, serverProv);
            ChannelServices.RegisterChannel(channel, false);

            HelloPingback hello = new HelloPingback();
            var helloObjRef = RemotingServices.Marshal(hello, "server", typeof(IHello));
            
            Console.WriteLine("Press enter to stop the server.");
            Console.ReadLine();
        }
    }
}
