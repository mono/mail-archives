using System;

public partial class _default : System.Web.UI.Page
{
    public void Page_Load(object sender, EventArgs e)
    {
       System.Web.Security.Membership.Provider.GetUser ("sontek", true);
    }
}
