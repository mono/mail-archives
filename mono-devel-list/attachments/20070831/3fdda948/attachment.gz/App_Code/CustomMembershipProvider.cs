using System;
using System.Configuration.Provider;
using System.Collections.Specialized;
using System.Web.Security;
using System.Xml;
namespace ProviderTest
{
    public class CustomMembershipProvider : MembershipProvider
    {
        public override string ApplicationName
        {
          get { throw new NotSupportedException(); }
          set { throw new NotSupportedException(); }
        }
        public override bool EnablePasswordRetrieval
        {
          get { return false; }
        }
        public override bool EnablePasswordReset
        {
          get { return false; }
        }
        public override int MaxInvalidPasswordAttempts
        {
          get { return 0; }
        }
        public override int MinRequiredNonAlphanumericCharacters
        {
          get { return 0; }
        }
        public override int MinRequiredPasswordLength
        {
          get { return 0; }
        }
        public override int PasswordAttemptWindow
        {
          get { throw new NotSupportedException(); }
        }
        public override MembershipPasswordFormat PasswordFormat
        {
          get { return MembershipPasswordFormat.Clear; }
        }
        public override string PasswordStrengthRegularExpression
        {
          get { throw new NotSupportedException(); }
        }
        public override bool RequiresQuestionAndAnswer
        {
          get { return false; }
        }
        public override bool RequiresUniqueEmail
        {
          get { return false; }
        }
        public override void Initialize (string name,
            NameValueCollection config)
        {
            if(string.IsNullOrEmpty (config["description"]))
            {
                config.Add ("description", "My Custom Provider");
            }
            base.Initialize(name, config);
            if (config.Count > 0)
                throw new Exception("Config should not have properties by now");
        }
        public override bool ValidateUser(string username, string password)
        {
            return false;
        }
        public override MembershipUser GetUser(string username, bool userIsOnline)
        {
          return default(MembershipUser);
        }
        public override MembershipUserCollection GetAllUsers(int pageIndex, int pageSize, out int totalRecords)
        {
            totalRecords = 0;
            return null;
        }
        public override bool ChangePassword(string username, string oldPassword, string newPassword)
        {
          return false;
        }
        public override MembershipUser CreateUser(string username, string password, string email, string passwordQuestion, string passwordAnswer, bool isApproved, object providerUserKey, out MembershipCreateStatus status)
        {
            status = default(MembershipCreateStatus);
            return default(MembershipUser);
        }
        public override bool DeleteUser(string username, bool deleteAllRelatedData)
        {
          return false;
        }
        public override MembershipUser GetUser(object providerUserKey, bool userIsOnline)
        {
          return default(MembershipUser);
        }
        public override string GetUserNameByEmail(string email)
        {
          return null;
        }
        public override void UpdateUser(MembershipUser user)
        {
          
        }
       
        /// <summary>
        /// 
        /// </summary>
        /// <param name="username"></param>
        /// <param name="answer"></param>
        /// <returns></returns>
        public override string ResetPassword(string username, string answer)
        {
          throw new NotSupportedException();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="userName"></param>
        /// <returns></returns>
        public override bool UnlockUser(string userName)
        {
          throw new NotSupportedException();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="emailToMatch"></param>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <param name="totalRecords"></param>
        /// <returns></returns>
        public override MembershipUserCollection FindUsersByEmail(string emailToMatch, int pageIndex, int pageSize, out int totalRecords)
        {
          throw new NotSupportedException();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="usernameToMatch"></param>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <param name="totalRecords"></param>
        /// <returns></returns>
        public override MembershipUserCollection FindUsersByName(string usernameToMatch, int pageIndex, int pageSize, out int totalRecords)
        {
          throw new NotSupportedException();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public override int GetNumberOfUsersOnline()
        {
          throw new NotSupportedException();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="username"></param>
        /// <param name="password"></param>
        /// <param name="newPasswordQuestion"></param>
        /// <param name="newPasswordAnswer"></param>
        /// <returns></returns>
        public override bool ChangePasswordQuestionAndAnswer(string username, string password, string newPasswordQuestion, string newPasswordAnswer)
        {
          throw new NotSupportedException();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="username"></param>
        /// <param name="answer"></param>
        /// <returns></returns>
        public override string GetPassword(string username, string answer)
        {
          throw new NotSupportedException();
        }
    }
}
