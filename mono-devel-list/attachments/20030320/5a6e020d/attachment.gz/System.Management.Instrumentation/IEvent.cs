//
// System.Management.Instrumentation.IEvent
//
// Authors:
//      Martin Willemoes Hansen (mwh@sysrq.dk)
//
// (C) 2003 Martin Willemoes Hansen
//

namespace System.Management.Instrumentation
{
        public interface IEvent {
		void Fire();
	}
}
