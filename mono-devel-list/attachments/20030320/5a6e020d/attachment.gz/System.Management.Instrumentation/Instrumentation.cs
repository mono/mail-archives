//
// System.Management.Instrumentation.Instrumentation
//
// Authors:
//      Martin Willemoes Hansen (mwh@sysrq.dk)
//
// (C) 2003 Martin Willemoes Hansen
//

using System.Reflection;

namespace System.Management.Instrumentation
{
        public class Instrumentation {

		[MonoTODO]
		public Instrumentation()
		{
		}

		[MonoTODO]
		public static void Fire (object eventData)
		{
			throw new NotImplementedException();
		}

		[MonoTODO]
		public static bool IsAssemblyRegistered (Assembly assemblyToRegister)
		{
			throw new NotImplementedException();
		}

		[MonoTODO]
		public static void Publish (object instanceData)
		{
			throw new NotImplementedException();
		}

		[MonoTODO]
		public static void RegisterAssembly (Assembly assemblyToRegister) 
                {
			throw new NotImplementedException();
		}

		[MonoTODO]
		public static void Revoke (object instanceData)
	        {
			throw new NotImplementedException();
		}

		[MonoTODO]
		public static void SetBatchSize (Type instrumentationClass, 
						 int batchSize)
	        {
			throw new NotImplementedException();
		}

		[MonoTODO]
		~Instrumentation()
		{
		}
	}
}
