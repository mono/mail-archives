//
// System.Management.Instrumentation.DefaultManagementProjectInstaller
//
// Authors:
//      Martin Willemoes Hansen (mwh@sysrq.dk)
//
// (C) 2003 Martin Willemoes Hansen
//

using System.Configuration.Install;

namespace System.Management.Instrumentation
{
        public class DefaultManagementProjectInstaller : Installer {

		[MonoTODO]
		public DefaultManagementProjectInstaller()
		{
		}

		[MonoTODO]
		~DefaultManagementProjectInstaller()
		{
		}
	}
}
