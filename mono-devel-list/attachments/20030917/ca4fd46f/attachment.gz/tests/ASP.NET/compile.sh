mcs -recurse:DataGrid*.cs -reference:System.Web.dll -r:System.Data -r:bin/Npgsql.dll /t:library -out:bin/Tests.dll
