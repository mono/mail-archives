namespace BitmapTest
{
	public class BitmapTester
	{
		public static void Main(string[] args)
		{
			Bitmap bitmap = new Bitmap(100, 100);
		}
	}
}
