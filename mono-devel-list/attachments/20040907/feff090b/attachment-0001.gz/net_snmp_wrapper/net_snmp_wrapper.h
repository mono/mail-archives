/***************************************************************************
 *            net_snmp_wrapper.h
 *
 *  Thu Sep  2 17:51:22 2004
 *  Copyright  2004 Frederic RUAUDEL
 *  grumz@users.sf.net
 ****************************************************************************/

/*
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Library General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */
 
#ifndef _NET_SNMP_WRAPPER_H
#define _NET_SNMP_WRAPPER_H

#ifdef __cplusplus
extern "C"
{
#endif

#include <net-snmp/net-snmp-config.h>
#include <net-snmp/net-snmp-includes.h>

typedef enum {
	asn_boolean = 1,
	asn_integer = 2,
	asn_bit_str = 3,
	asn_octet_str = 4,
	asn_null = 5,
	asn_object_id = 6,
	asn_sequence = 7,
	asn_set = 8
} wsnmp_asn1_type;
	
void init_wsnmp (const char* type);

void wsnmp_sess_init_v1 (netsnmp_session* session);
void wsnmp_sess_init_v2c (netsnmp_session* session);

void wsnmp_set_peername (netsnmp_session* session, const char* peername);
void wsnmp_set_community (netsnmp_session* session, const char* community, int community_len);

netsnmp_session* wsnmp_open (netsnmp_session* session);
int wsnmp_check_opened_session (netsnmp_session* session);

netsnmp_pdu* wsnmp_pdu_create_get (void);
netsnmp_pdu* wsnmp_pdu_create_getnext (void);

int wsnmp_get_node (const char* name, oid* objid, size_t* objid_len);
netsnmp_variable_list* wsnmp_add_null_var (netsnmp_pdu* pdu, const oid* objid, size_t objid_len);

int wsnmp_synch_response (netsnmp_session* session, netsnmp_pdu* pdu, netsnmp_pdu** response);
int wsnmp_check_response (int status, netsnmp_pdu* response, netsnmp_session* session);

struct variable_list* wsnmp_get_var_list (netsnmp_pdu* response);
struct variable_list* wsnmp_get_next_var (struct variable_list* var_list);

oid* wsnmp_get_var_name (struct variable_list* var_list);
size_t wsnmp_get_var_name_len (struct variable_list* var_list);

int wsnmp_snprint_variable (char* buf, size_t buf_len, const oid* objid, size_t objid_len, const netsnmp_variable_list* var_list);
int wsnmp_snprint_objid (char* buf, size_t buf_len, const oid* objid, size_t objid_len);
int wsnmp_snprint_value (char* buf, size_t buf_len, const oid* objid, size_t objid_len, const netsnmp_variable_list* var_list);
int wsnmp_snprint_description (char* buf, size_t buf_len, oid* objid, size_t objid_len, int width);

int wsnmp_get_var_type (struct variable_list* var_list);
int wsnmp_get_var_value_len (struct variable_list* var_list);

const char* wsnmp_get_var_value_as_string (struct variable_list* var_list);
long wsnmp_get_var_value_as_integer (struct variable_list* var_list);
oid wsnmp_get_var_value_as_oid (struct variable_list* var_list);
u_char wsnmp_get_var_value_as_bitstring (struct variable_list* var_list);
struct counter64 wsnmp_get_var_value_as_counter (struct variable_list* var_list);

int wsnmp_close (netsnmp_session* session);

void wsnmp_free_pdu (netsnmp_pdu* pdu);
void wsnmp_free_session (netsnmp_session* session);

#ifdef __cplusplus
}
#endif

#endif /* _NET_SNMP_WRAPPER_H */
