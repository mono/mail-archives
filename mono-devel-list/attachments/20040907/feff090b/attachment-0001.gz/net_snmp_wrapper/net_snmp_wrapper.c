/***************************************************************************
 *            net_snmp_wrapper.c
 *
 *  Thu Sep  2 17:41:44 2004
 *  Copyright  2004  Frederic Ruaudel
 *  grumz@users.sf.net
 ****************************************************************************/

/*
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Library General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */
 
#include <net_snmp_wrapper_priv.h>

void init_wsnmp (const char* type)
{
	DEBUG(("type : %s\n", type));
	init_snmp (type);
}

void wsnmp_sess_init_v1 (netsnmp_session* session)
{
	DEBUG(("wsnmp_sess_init_v1(before) : %p\n", session));
	snmp_sess_init (session);
	DEBUG(("wsnmp_sess_init_v1(after) : %p\n", session));
	session->version = SNMP_VERSION_1;
}

void wsnmp_sess_init_v2c (netsnmp_session* session)
{
	DEBUG(("wsnmp_sess_init_v2c(before) : %p\n", session));
	snmp_sess_init (session);
	DEBUG(("wsnmp_sess_init_v2c(after) : %p\n", session));
	session->version = SNMP_VERSION_2c;
}

void wsnmp_set_peername (netsnmp_session* session, const char* peername)
{
	DEBUG(("wsnmp_set_peername(before) : %p - %s\n", session, peername));
	session->peername = strdup (peername);
}

void wsnmp_set_community (netsnmp_session* session, const char* community, int community_len)
{
	DEBUG(("wsnmp_set_community(before) : %p - %s(%d)\n", session, community, community_len));
	session->community = strdup (community);
	session->community_len = community_len;
}

netsnmp_session* wsnmp_open (netsnmp_session* session)
{
	SOCK_STARTUP;
	DEBUG(("wsnmp_open(before) : %p\n", session));
	netsnmp_session* retv = snmp_open (session);
	DEBUG2(("wsnmp_open(after) : %p\n", retv));
	return retv;
}

int wsnmp_check_opened_session (netsnmp_session* session)
{
	int retv = 1;
	
	DEBUG2(("wsnmp_check_opened_session(before) : %p\n", session));
	if (session == NULL)
	{
		snmp_perror ("snmp_open");
		snmp_log (LOG_ERR, "Can't open SNMP session\n");
		SOCK_CLEANUP;
		retv = 0;
	}
	
	return retv;
}

netsnmp_pdu* wsnmp_pdu_create_get (void)
{
	netsnmp_pdu* retv = snmp_pdu_create(SNMP_MSG_GET);
	DEBUG2(("wsnmp_pdu_create_get(after) : %p - %d\n", retv, retv->command));	
	return retv;
}

netsnmp_pdu* wsnmp_pdu_create_getnext (void)
{
	netsnmp_pdu* retv = snmp_pdu_create(SNMP_MSG_GETNEXT);
	return retv;
}

int wsnmp_get_node (const char* name, oid* objid, size_t* objid_len)
{
	DEBUG(("wsnmp_get_node(before) : %s - %p : %ld - %lu\n", name, objid, *objid, *objid_len));
	int retv = get_node (name, objid, objid_len);
	DEBUG(("wsnmp_get_node(after) : %s - %p : %ld - %lu\n", name, objid, *objid, *objid_len));
	return retv;
}

netsnmp_variable_list* wsnmp_add_null_var (netsnmp_pdu* pdu, const oid* objid, size_t objid_len)
{
	DEBUG2(("wsnmp_add_null_var(before) : %p - %p : %ld - %lu\n", pdu, objid, *objid, objid_len));
	return snmp_add_null_var (pdu, objid, objid_len);
}

int wsnmp_synch_response (netsnmp_session* session, netsnmp_pdu* pdu, netsnmp_pdu** response)
{
	DEBUG(("wsnmp_synch_response(before) : %p - %p - %p - %p\n", session, pdu, response, *response));
	int retv = snmp_synch_response (session, pdu, response);
	DEBUG(("wsnmp_synch_response(after) : %p - %p - %p - %p\n", session, pdu, response, *response));
	return retv;
}

int wsnmp_check_response (int status, netsnmp_pdu* response, netsnmp_session* session)
{
	int retv = 1;
	if (!(status == STAT_SUCCESS && response->errstat == SNMP_ERR_NOERROR))
	{
		if (status == STAT_SUCCESS)
		{
			snmp_log (LOG_ERR, snmp_errstring (response->errstat));
		}
		else
		{
			snmp_sess_perror ("snmp_synch_response", session);
		}
		retv = 0;
	}
	
	return retv;
}

struct variable_list* wsnmp_get_var_list (netsnmp_pdu* response)
{
	return response->variables;
}

struct variable_list* wsnmp_get_next_var (struct variable_list* var_list)
{
	return var_list->next_variable;
}

oid* wsnmp_get_var_name (struct variable_list* var_list)
{
	return var_list->name;
}

size_t wsnmp_get_var_name_len (struct variable_list* var_list)
{
	return var_list->name_length;
}

int wsnmp_snprint_variable (char* buf, size_t buf_len, const oid* objid, size_t objid_len, const netsnmp_variable_list* var_list)
{
	return snprint_variable (buf, buf_len, objid, objid_len, var_list);
}

int wsnmp_snprint_objid (char* buf, size_t buf_len, const oid* objid, size_t objid_len)
{
	return snprint_objid (buf, buf_len, objid, objid_len);
}

int wsnmp_snprint_value (char* buf, size_t buf_len, const oid* objid, size_t objid_len, const netsnmp_variable_list* var_list)
{
	return snprint_value (buf, buf_len, objid, objid_len, var_list);
}

int wsnmp_snprint_description (char* buf, size_t buf_len, oid* objid, size_t objid_len, int width)
{
	return snprint_description (buf, buf_len, objid, objid_len, width);
}

int wsnmp_get_var_type (struct variable_list* var_list)
{
	int retv = asn_null;
	
	switch (var_list->type)
	{
		case ASN_BOOLEAN:
			retv = asn_boolean;
			break;
		case ASN_INTEGER:
			retv = asn_integer;
			break;
		case ASN_BIT_STR:
			retv = asn_bit_str;
			break;
		case ASN_OCTET_STR:
			retv = asn_octet_str;
			break;
		case ASN_NULL:
			retv = asn_null;
			break;
		case ASN_OBJECT_ID:
			retv = asn_object_id;
			break;
		case ASN_SEQUENCE:
			retv = asn_sequence;
			break;
		case ASN_SET:
			retv = asn_set;
			break;
	}
	
	return retv;
}

int wsnmp_get_var_value_len (struct variable_list* var_list)
{
	return var_list->val_len;
}

const char* wsnmp_get_var_value_as_string (struct variable_list* var_list)
{
	return var_list->val.string;
}

long wsnmp_get_var_value_as_integer (struct variable_list* var_list)
{
	return *(var_list->val.integer);
}

oid wsnmp_get_var_value_as_oid (struct variable_list* var_list)
{
	return *(var_list->val.objid);
}

u_char wsnmp_get_var_value_as_bitstring (struct variable_list* var_list)
{
	return *(var_list->val.bitstring);
}

struct counter64 wsnmp_get_var_value_as_counter (struct variable_list* var_list)
{
	return *(var_list->val.counter64);
}

int wsnmp_close (netsnmp_session* session)
{
	int retv = -1;
	
	if (session != NULL)
	{
		int retv = snmp_close (session);
		SOCK_CLEANUP;
	}
	
	return retv;
}

void wsnmp_free_pdu (netsnmp_pdu* pdu)
{
	if (pdu != NULL)
	{
		snmp_free_pdu (pdu);
	}
}

void wsnmp_free_session (netsnmp_session* session)
{
	if (session != NULL)
	{
		if (session->peername != NULL)
		{
			free (session->peername);
			session->peername = NULL;
		}
		if (session->community != NULL)
		{
			free (session->community);
			session->community = NULL;
			session->community_len = 0;
		}
	}
}
