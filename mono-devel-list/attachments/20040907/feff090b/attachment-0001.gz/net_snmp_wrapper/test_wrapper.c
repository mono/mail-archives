/***************************************************************************
 *            test_wrapper.c
 *
 *  Thu Sep  2 17:53:12 2004
 *  Copyright  2004  Frederic RUAUDEL
 *  grumz@users.sf.net
 ****************************************************************************/

/*
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Library General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */
 
#include <stdio.h>
#include <stdlib.h>
#include <net_snmp_wrapper.h>
 
int main (int argc, char* argv[])
{
	//void* session;
	char buf[1024];
	netsnmp_session *session, *ss;
	netsnmp_pdu *response;
	//netsnmp_pdu *pdu;
	void* pdu;
    oid anOID[MAX_OID_LEN];
	oid* objid;
    size_t anOID_len = MAX_OID_LEN;
	struct variable_list *vars;
    int status;	
	int i;
	
	if (argc != 2)
	{
		printf ("Syntax: %s community_string\n", argv[0]);
		exit (EXIT_FAILURE);
	}
	init_wsnmp ("test_wrapper");
	wsnmp_sess_init_v2c (session);
	wsnmp_set_peername (session, "localhost");
	wsnmp_set_community (session, argv[1], strlen (argv[1]));
	ss = wsnmp_open (session);
	if (!wsnmp_check_opened_session (ss))
	{
		wsnmp_free_session (session);
		exit (EXIT_FAILURE);
	}
	
	pdu = wsnmp_pdu_create_get ();
	wsnmp_get_node("sysDescr.0", anOID, &anOID_len);
	wsnmp_add_null_var (pdu, anOID, anOID_len);
	wsnmp_get_node("sysLocation.0", anOID, &anOID_len);
	wsnmp_add_null_var (pdu, anOID, anOID_len);	
	wsnmp_get_node("sysUpTime.0", anOID, &anOID_len);
	wsnmp_add_null_var (pdu, anOID, anOID_len);		
	status = wsnmp_synch_response(ss, pdu, &response);
	if (wsnmp_check_response (status, response, ss))
	{
		vars = wsnmp_get_var_list (response);
		while (vars != NULL)
		{
			printf ("Name: ");
			objid = wsnmp_get_var_name (vars);
			for (i = 0; i < wsnmp_get_var_name_len (vars); i++)
			{
				printf (".%d", objid[i]);
			}
			//wsnmp_snprint_variable (buf, 1024, objid, wsnmp_get_var_name_len (vars), vars);
			wsnmp_snprint_objid (buf, 1024, objid, wsnmp_get_var_name_len (vars));
			printf (" = %s - Type : %d", buf, wsnmp_get_var_type (vars));
/*			
			if (wsnmp_get_var_type (vars) == asn_octet_str)
			{
				printf (" - Value : %s", wsnmp_get_var_value_as_string (vars));
			}
			printf ("\n");
*/
			wsnmp_snprint_value (buf, 1024, objid, wsnmp_get_var_name_len (vars), vars);
			printf (" - Value : %s\n", buf);
			
			vars = wsnmp_get_next_var (vars);
		}
	}

	wsnmp_free_pdu (response);
	wsnmp_close (ss);
	wsnmp_free_session (session);
	exit (EXIT_SUCCESS);
}
