// project created on 9/3/2004 at 10:33 AM
using System;
using System.Text;
using System.Runtime.InteropServices;

public class NetSnmp : IDisposable
{
	IntPtr session, ss, pdu, response, vars;
	
	public NetSnmp (string peername, string community, string oid_name)
	{
		long[] anOID = new long[128];
		int anOID_len = 128;
		int status;
		
		this.session = IntPtr.Zero;
		this.response = IntPtr.Zero;
		this.pdu = IntPtr.Zero;
		this.ss = IntPtr.Zero;
		this.vars = IntPtr.Zero;
		
		NetSnmp.init_wsnmp ("Net-Snmp#");
		NetSnmp.wsnmp_sess_init_v2c (ref this.session);
		NetSnmp.wsnmp_set_peername (ref this.session, peername);
		NetSnmp.wsnmp_set_community (ref this.session, community, community.Length);
		
		this.ss = NetSnmp.wsnmp_open (ref this.session);
		
		if (NetSnmp.wsnmp_check_opened_session (this.ss) != 0)
		{
			this.pdu = NetSnmp.wsnmp_pdu_create_get ();
			
			NetSnmp.wsnmp_get_node (oid_name, ref anOID, ref anOID_len);
			NetSnmp.wsnmp_add_null_var (ref this.pdu, ref anOID, anOID_len);
			
			status = NetSnmp.wsnmp_synch_response (this.ss, this.pdu, ref this.response);
			
			if (NetSnmp.wsnmp_check_response (status, this.response, this.ss) != 0)
			{
				StringBuilder buf = new StringBuilder (1024);
				this.vars = NetSnmp.wsnmp_get_var_list (this.response);
				anOID = NetSnmp.wsnmp_get_var_name (this.vars);
				NetSnmp.wsnmp_snprint_variable (buf, buf.Capacity, ref anOID, NetSnmp.wsnmp_get_var_name_len (this.vars), ref this.vars);
				System.Console.WriteLine("Result: " + buf.ToString ());
			}
		}
	}
	
	~NetSnmp ()
	{
		this.Dispose (false);
	}

	public void Dispose ()
	{
	   this.Dispose (true);
	   GC.SuppressFinalize (this);
	}
	
	protected virtual void Dispose (bool disposing)
	{
		NetSnmp.wsnmp_free_pdu (this.pdu);
		NetSnmp.wsnmp_close (this.ss);
		NetSnmp.wsnmp_free_session (this.session);
		Console.WriteLine ("Free OK !");
	}	
		
	[DllImport ("net_snmp_wrapper")]
	private static extern void init_wsnmp (string type);
	
	[DllImport ("net_snmp_wrapper")]
	private static extern void wsnmp_sess_init_v1 (ref IntPtr session);
	
	[DllImport ("net_snmp_wrapper")]
	private static extern void wsnmp_sess_init_v2c (ref IntPtr session);
	
	[DllImport ("net_snmp_wrapper")]
	private static extern void wsnmp_set_peername (ref IntPtr session, string peername);
	
	[DllImport ("net_snmp_wrapper")]
	private static extern void wsnmp_set_community (ref IntPtr session, string community, int community_len);
	
	[DllImport ("net_snmp_wrapper")]
	private static extern IntPtr wsnmp_open (ref IntPtr session);
	
	[DllImport ("net_snmp_wrapper")]
	private static extern int wsnmp_check_opened_session (IntPtr session);
	
	[DllImport ("net_snmp_wrapper")]
	private static extern IntPtr wsnmp_pdu_create_get ();
	
	[DllImport ("net_snmp_wrapper")]
	private static extern IntPtr wsnmp_pdu_create_getnext ();
	
	[DllImport ("net_snmp_wrapper")]
	private static extern int wsnmp_get_node (string name, ref long[] objid, ref int objid_len);
	
	[DllImport ("net_snmp_wrapper")]
	private static extern IntPtr wsnmp_add_null_var (ref IntPtr pdu, ref long[] objid, int objid_len);
	
	[DllImport ("net_snmp_wrapper")]
	private static extern int wsnmp_synch_response (IntPtr session, IntPtr pdu, ref IntPtr response);
	
	[DllImport ("net_snmp_wrapper")]
	private static extern int wsnmp_check_response (int status, IntPtr response, IntPtr session);
	
	[DllImport ("net_snmp_wrapper")]
	private static extern IntPtr wsnmp_get_var_list (IntPtr response);
	
	[DllImport ("net_snmp_wrapper")]
	private static extern IntPtr wsnmp_get_next_var (IntPtr var_list);
	
	[DllImport ("net_snmp_wrapper")]
	private static extern long[] wsnmp_get_var_name (IntPtr var_list);
	
	[DllImport ("net_snmp_wrapper")]
	private static extern int wsnmp_get_var_name_len (IntPtr var_list);
	
	[DllImport ("net_snmp_wrapper", CharSet=CharSet.Auto)]
	private static extern int wsnmp_snprint_variable (StringBuilder buf, int buf_len, ref long[] objid, int objid_len, ref IntPtr var_list);
	
	[DllImport ("net_snmp_wrapper", CharSet=CharSet.Auto)]
	private static extern int wsnmp_snprint_objid (StringBuilder buf, int buf_len, ref long objid, int objid_len);
	
	[DllImport ("net_snmp_wrapper", CharSet=CharSet.Auto)]
	private static extern int wsnmp_snprint_value (StringBuilder buf, int buf_len, ref long objid, int objid_len, IntPtr var_list);
	
	[DllImport ("net_snmp_wrapper", CharSet=CharSet.Auto)]
	private static extern int wsnmp_snprint_description (StringBuilder buf, int buf_len, ref long objid, int objid_len, int width);
/*	
	[DllImport ("net_snmp_wrapper")]
	private static extern int wsnmp_get_var_type (struct variable_list* var_list);
	
	[DllImport ("net_snmp_wrapper")]
	private static extern int wsnmp_get_var_value_len (struct variable_list* var_list);
	
	[DllImport ("net_snmp_wrapper")]
	private static extern const char* wsnmp_get_var_value_as_string (struct variable_list* var_list);
	
	[DllImport ("net_snmp_wrapper")]
	private static extern long wsnmp_get_var_value_as_integer (struct variable_list* var_list);
	
	[DllImport ("net_snmp_wrapper")]
	private static extern oid wsnmp_get_var_value_as_oid (struct variable_list* var_list);
	
	[DllImport ("net_snmp_wrapper")]
	private static extern u_char wsnmp_get_var_value_as_bitstring (struct variable_list* var_list);
	
	[DllImport ("net_snmp_wrapper")]
	private static extern struct counter64 wsnmp_get_var_value_as_counter (struct variable_list* var_list);
*/	
	[DllImport ("net_snmp_wrapper")]
	private static extern int wsnmp_close (IntPtr session);
	
	[DllImport ("net_snmp_wrapper")]
	private static extern void wsnmp_free_pdu (IntPtr pdu);
	
	[DllImport ("net_snmp_wrapper")]
	private static extern void wsnmp_free_session (IntPtr session);
}