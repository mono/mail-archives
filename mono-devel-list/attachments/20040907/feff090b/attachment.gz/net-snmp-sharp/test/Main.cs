// project created on 9/3/2004 at 1:08 PM
using System;

class MainClass
{
	public static void Main(string[] args)
	{
		Console.WriteLine("Hello World!");
		NetSnmp snmpreq = new NetSnmp ("localhost", "public", "sysDescr.1");
	}
}