//
// Microsoft.Win32/Win32RegistryApi.cs: wrapper for win32 registry API
//
// Authos:
//	Erik LeBel (eriklebel@yahoo.ca)
//
// Copyright (C) Erik LeBel 2004
// 

using System;
using System.Runtime.InteropServices;
using System.Text;

namespace Microsoft.Win32
{
	/// <summary>
	///	Function stubs, constants and helper functions for
	///	the Win32 registry manipulation utilities.
	/// </summary>
	internal class Win32RegistryApi
	{
		// bit masks for registry key open access permissions
		public const int OpenRegKeyRead = 0x00020019;
		public const int OpenRegKeyWrite = 0x00020006;

		
		// type values for registry value data
		public const int RegStringType = 1;
		public const int RegEnvironmentString = 2;
		public const int RegBinaryType = 3;
		public const int RegDwordType = 4;
		public const int RegStringArrayType = 7;
	
		
		/// <summary>
		///	Create a registry key.
		/// </summary>
		[DllImport ("advapi32.dll", CharSet=CharSet.Unicode)]
		public static extern int RegCreateKey (IntPtr keyBase, 
				string keyName, out IntPtr keyHandle);
		
		
		/// <summary>
		///	Close a registry key.
		/// </summary>
		[DllImport ("advapi32.dll", CharSet=CharSet.Unicode)]
		public static extern int RegCloseKey (IntPtr keyHandle);
		

		/// <summary>
		///	Flush a registry key's current state to disk.
		/// </summary>
		[DllImport ("advapi32.dll", CharSet=CharSet.Unicode)]
		public static extern int RegFlushKey (IntPtr keyHandle);
	
		
		/// <summary>
		///	Open a registry key.
		///	'unknown' must be zero.
		/// </summary>
		[DllImport ("advapi32.dll", CharSet=CharSet.Unicode)]
		public static extern int RegOpenKeyEx (IntPtr keyBase,
				string keyName, IntPtr reserved, int access,
				out IntPtr keyHandle);
	
		
		/// <summary>
		///	Delete a registry key.
		/// </summary>
		[DllImport ("advapi32.dll", CharSet=CharSet.Unicode)]
		public static extern int RegDeleteKey (IntPtr keyHandle, 
				string valueName);

		
		/// <summary>
		///	Delete a registry value.
		/// </summary>
		[DllImport ("advapi32.dll", CharSet=CharSet.Unicode)]
		public static extern int RegDeleteValue (IntPtr keyHandle, 
				string valueName);


		/// <summary>
		///	Fetch registry key subkeys itteratively.
		/// </summary>
		[DllImport ("advapi32.dll", CharSet=CharSet.Unicode)]
		public static extern int RegEnumKey (IntPtr keyBase, int index,
				[Out] byte[] nameBuffer, int bufferLength);
	
		
		/// <summary>
		///	Fetch registry key value names itteratively.
		///
		///	Arguments 'reserved', 'data', 'dataLength' 
		///	should be set to IntPtr.Zero.
		/// </summary>
		[DllImport ("advapi32.dll", CharSet=CharSet.Unicode)]
		public static extern int RegEnumValue (IntPtr keyBase, 
				int index, StringBuilder nameBuffer, 
				ref int nameLength, IntPtr reserved, 
				ref int type, IntPtr data, IntPtr dataLength);
	

		/// <summary>
		///	Set a registry value with string builder data.
		/// </summary>
		[DllImport ("advapi32.dll", CharSet=CharSet.Unicode)]
		public static extern int RegSetValueEx (IntPtr keyBase, 
				string valueName, IntPtr reserved, int type,
				StringBuilder data, int rawDataLength);

		
		/// <summary>
		///	Set a registry value with string data.
		/// </summary>
		[DllImport ("advapi32.dll", CharSet=CharSet.Unicode)]
		public static extern int RegSetValueEx (IntPtr keyBase, 
				string valueName, IntPtr reserved, int type,
				string data, int rawDataLength);

		
		/// <summary>
		///	Set a registry value with binary data (a byte array).
		/// </summary>
		[DllImport ("advapi32.dll", CharSet=CharSet.Unicode)]
		public static extern int RegSetValueEx (IntPtr keyBase, 
				string valueName, IntPtr reserved, int type,
				byte[] rawData, int rawDataLength);

		
		/// <summary>
		///	Set a registry value to a DWORD value.
		/// </summary>
		[DllImport ("advapi32.dll", CharSet=CharSet.Unicode)]
		public static extern int RegSetValueEx (IntPtr keyBase, 
				string valueName, IntPtr reserved, int type,
				ref int data, int rawDataLength);


		/// <summary>
		///	Get a registry value's info. No data.
		/// </summary>
		[DllImport ("advapi32.dll", CharSet=CharSet.Unicode)]
		public static extern int RegQueryValueEx (IntPtr keyBase,
				string valueName, IntPtr reserved, ref int type,
				IntPtr zero, ref int dataSize);
		
		/// <summary>
		///	Get a registry value. Binary data.
		/// </summary>
		[DllImport ("advapi32.dll", CharSet=CharSet.Unicode)]
		public static extern int RegQueryValueEx (IntPtr keyBase,
				string valueName, IntPtr reserved, ref int type,
				[Out] byte[] data, ref int dataSize);

		
		/// <summary>
		///	Get a registry value. DWORD data.
		/// </summary>
		[DllImport ("advapi32.dll", CharSet=CharSet.Unicode)]
		public static extern int RegQueryValueEx (IntPtr keyBase,
				string valueName, IntPtr reserved, ref int type,
				ref int data, ref int dataSize);
	}
}
