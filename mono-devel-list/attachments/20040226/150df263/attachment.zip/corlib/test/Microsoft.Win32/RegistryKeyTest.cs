//
// MonoTests/Microsoft.Win32/RegistryKeyTest.cs: unit tests for win32 registry operations
//
// Authos:
//	Erik LeBel (eriklebel@yahoo.ca)
//
// Copyright (C) Erik LeBel 2004
// 

using System;
using System.Collections.Specialized;
using System.Configuration;
using NUnit.Core;
using NUnit.Framework;
using Microsoft.Win32;


namespace MonoTests.Microsoft.Win32
{
	public class RegistryKeyTestBase
	{
		// setting keys:
		const string UnlikelyKeySetting = "unlikely.key";
		const string ExpectedKeySetting = "expected.key";
		const string ExpectedKey2Setting = "expected.key.2";
		
		
		protected const string HKCU = "HKEY_CURRENT_USER";
		
		protected string SomeUnlikelyKey = "__SomeUnlikelyName";

		protected string ExpectedKey = "Software";
		protected string ExpectedKeyFullName;

		protected string ExpectedKey2 = "Microsoft";
		protected string ExpectedKey2FullName;

		protected const string LongKeyName = "abcdefghijklmnopABCDEFGHIJKLMNOP" +
				"abcdefghijklmnopABCDEFGHIJKLMNOP" +
				"abcdefghijklmnopABCDEFGHIJKLMNOP" +
				"abcdefghijklmnopABCDEFGHIJKLMNOP" +
				"abcdefghijklmnopABCDEFGHIJKLMNOP" +
				"abcdefghijklmnopABCDEFGHIJKLMNOP" +
				"abcdefghijklmnopABCDEFGHIJKLMNOP" +
				"abcdefghijklmnopABCDEFGHIJKLMNOP" +
				"abcdefghijklmnopABCDEFGHIJKLMNOP" +
				"abcdefghijklmnopABCDEFGHIJKLMNOP" +
				"abcdefghijklmnopABCDEFGHIJKLMNOP" +
				"abcdefghijklmnopABCDEFGHIJKLMNOP" +
				"abcdefghijklmnopABCDEFGHIJKLMNOP" +
				"abcdefghijklmnopABCDEFGHIJKLMNOP" +
				"abcdefghijklmnopABCDEFGHIJKLMNOP" +
				"abcdefghijklmnopABCDEFGHIJKLMNOP" +
				"Z";
		
		protected RegistryKeyTestBase ()
		{
			// initialize above values from config file
			SomeUnlikelyKey = GetSetting (UnlikelyKeySetting, SomeUnlikelyKey);
			ExpectedKey = GetSetting (ExpectedKeySetting, ExpectedKey);
			ExpectedKeyFullName = HKCU + "\\" + ExpectedKey;
			ExpectedKey2 = GetSetting (ExpectedKey2Setting, ExpectedKey2);
			ExpectedKey2FullName = ExpectedKeyFullName + "\\" + ExpectedKey2;
			
			
			if (Registry.CurrentUser.OpenSubKey (SomeUnlikelyKey) != null)
			{
				string message = String.Format ("The 'HKCU\\{0}' registry setting exists, and thus " +
						"cannot be used in this test. Please re-configure this test before " +
						"re-executing it", SomeUnlikelyKey);
				throw new NunitException (message);
			}
		}


		private string GetSetting (string settingName, string defaultValue)
		{
			NameValueCollection settings = ConfigurationSettings.AppSettings;
			string setting = settings.Get (settingName);
			if (setting != null && setting != String.Empty)
			{
				return setting;
			}
			
			return defaultValue;
		}
	}

	
	[TestFixture]
	public class SimpleRegistryKeyTest : RegistryKeyTestBase
	{
		public SimpleRegistryKeyTest () : base ()
		{
		}
		
		[Test]
		public void HKeyCurrentUserIsValid ()
		{
			Assertion.AssertNotNull (Registry.CurrentUser);
			Assertion.AssertEquals (HKCU, Registry.CurrentUser.Name);
		}

		
		[Test]
		public void HKeyCurrentUserDoesNotClose ()
		{
			Registry.CurrentUser.Close ();
			RegistryKey regKey = Registry.CurrentUser.OpenSubKey (ExpectedKey);
			Assertion.AssertNotNull (regKey);
			regKey.Close ();
		}

		
		[Test]
		[ExpectedException (typeof (ArgumentNullException))]
		public void OpenSubKeyWithNullName ()
		{
			Registry.CurrentUser.OpenSubKey (null);
		}
	
		
		[Test]
		[ExpectedException (typeof (ArgumentException))]
		public void OpenSubKeyWithLongName ()
		{
			Registry.CurrentUser.OpenSubKey (LongKeyName);
		}

		
		[Test]
		public void OpenSubKeyWithNonExistingName ()
		{
			RegistryKey regKey = Registry.CurrentUser.OpenSubKey (SomeUnlikelyKey);
			Assertion.AssertNull (regKey);
		}


		/*
		[Test]
		public void OpenSubKeyWithInvalidName ()
		{
			RegistryKey regKey = Registry.CurrentUser.OpenSubKey (InvalidKey + "\\" + SomeUnlikelyKey);
			Assertion.AssertNull (regKey);
		}*/

		
		[Test]
		public void OpenSubKeyWithExpectedName ()
		{
			RegistryKey regKey = Registry.CurrentUser.OpenSubKey (ExpectedKey);
			Assertion.AssertNotNull (regKey);
			Assertion.AssertEquals (ExpectedKeyFullName, regKey.Name);
			regKey.Close ();
		}

		[Test]
		[ExpectedException (typeof (ObjectDisposedException))]
		public void OpenSubKeyWithClosedNode ()
		{
			RegistryKey regKey = Registry.CurrentUser.OpenSubKey (ExpectedKey);
			Assertion.AssertNotNull (regKey);
			regKey.Close ();
			regKey.OpenSubKey (ExpectedKey);
		}

		
		[Test]
		public void OpenSubKeyWithExpectedDoubleName ()
		{
			RegistryKey regKey = Registry.CurrentUser.OpenSubKey (ExpectedKey + "\\" + ExpectedKey2);
			Assertion.AssertNotNull (regKey);
			Assertion.AssertEquals (ExpectedKey2FullName, regKey.Name);
			regKey.Close ();
		}

		
		[Test]
		public void OpenSubKeyForWrite ()
		{
			RegistryKey regKey = Registry.CurrentUser.OpenSubKey (ExpectedKey, true);
			Assertion.AssertNotNull (regKey);
			Assertion.AssertEquals (ExpectedKeyFullName, regKey.Name);
			regKey.Close ();
		}

		
		[Test]
		public void OpenSubKeyForWriteWhenAlreadyOpenForRead ()
		{
			RegistryKey regKey = Registry.CurrentUser.OpenSubKey (ExpectedKey);
			Assertion.AssertNotNull (regKey);
			Assertion.AssertEquals (ExpectedKeyFullName, regKey.Name);
			
			RegistryKey regKey2 = Registry.CurrentUser.OpenSubKey (ExpectedKey, true);
			Assertion.AssertNotNull (regKey2);
			Assertion.AssertEquals (ExpectedKeyFullName, regKey2.Name);
			
			regKey.Close ();
			regKey2.Close();
		}

		
		[Test]
		public void OpenSubKeyForWriteWhenAlreadyOpenForWrite ()
		{
			RegistryKey regKey = Registry.CurrentUser.OpenSubKey (ExpectedKey, true);
			Assertion.AssertNotNull (regKey);
			Assertion.AssertEquals (ExpectedKeyFullName, regKey.Name);
			
			RegistryKey regKey2 = Registry.CurrentUser.OpenSubKey (ExpectedKey, true);
			Assertion.AssertNotNull (regKey2);
			Assertion.AssertEquals (ExpectedKeyFullName, regKey2.Name);
			
			regKey.Close ();
			regKey2.Close();
		}
	}

	
	[TestFixture]
	public class CreateRegistryKeyTest : RegistryKeyTestBase
	{
		public CreateRegistryKeyTest () : base ()
		{
		}
		

		[SetUp]
		[TearDown]
		public void Clean ()
		{
			try
			{
				Registry.CurrentUser.DeleteSubKeyTree (SomeUnlikelyKey);
			}
			catch (Exception)
			{
			}
		}

		
		[Test]
		[ExpectedException (typeof (ArgumentNullException))]
		public void CreateSubKeyWithNullName ()
		{
			Registry.CurrentUser.CreateSubKey (null);
		}
	
		
		[Test]
		[ExpectedException (typeof (ArgumentException))]
		public void CreateSubKeyWithLongName ()
		{
			Registry.CurrentUser.CreateSubKey (LongKeyName);
		}

		
		[Test]
		public void CreateSubKeyWithExistingName ()
		{
			RegistryKey regKey = Registry.CurrentUser.CreateSubKey (ExpectedKey);
			Assertion.AssertNotNull (regKey);
			Assertion.AssertEquals (ExpectedKeyFullName, regKey.Name);
			regKey.Close ();
		}

		
		[Test]
		public void CreateSubKeyName ()
		{
			RegistryKey regKey = Registry.CurrentUser.CreateSubKey (SomeUnlikelyKey);
			Assertion.AssertNotNull (regKey);
			Assertion.AssertEquals (HKCU + "\\" + SomeUnlikelyKey, regKey.Name);
			regKey.Close ();
		}
		
		
		[Test]
		public void CreateDoubleSubKeyName ()
		{
			RegistryKey regKey = Registry.CurrentUser.CreateSubKey (SomeUnlikelyKey 
					+ "\\" + SomeUnlikelyKey);
			Assertion.AssertNotNull (regKey);
			Assertion.AssertEquals (HKCU + "\\" + SomeUnlikelyKey + "\\" 
					+ SomeUnlikelyKey, regKey.Name);
			regKey.Close ();
		}
	}
	
	
	[TestFixture]
	public class DeleteRegistryKeyTest : RegistryKeyTestBase
	{
		public DeleteRegistryKeyTest () : base ()
		{
		}
	
		
		[SetUp]
		public void Init ()
		{
			Registry.CurrentUser.CreateSubKey (SomeUnlikelyKey);
		}
		
		
		[TearDown]
		public void Clean ()
		{
			try
			{
				Registry.CurrentUser.DeleteSubKeyTree (SomeUnlikelyKey);
			}
			catch (Exception)
			{
			}
		}

		
		[Test]
		[ExpectedException (typeof (ArgumentNullException))]
		public void DeleteSubKeyWithNullName ()
		{
			Registry.CurrentUser.DeleteSubKey (null);
		}
	
		
		[Test]
		[ExpectedException (typeof (ArgumentException))]
		public void DeleteSubKeyWithLongName ()
		{
			Registry.CurrentUser.DeleteSubKey (LongKeyName);
		}

		
		[Test]
		public void DeleteSubKeyWithExistingName ()
		{
			Registry.CurrentUser.DeleteSubKey (SomeUnlikelyKey);
		}
	}
	
	
	[TestFixture]
	public class RegistryKeyTreeTest : RegistryKeyTestBase
	{
		StringCollection SubKeys;
		
		public RegistryKeyTreeTest () : base ()
		{
			SubKeys = new StringCollection ();
			SubKeys.Add (SomeUnlikelyKey);
			SubKeys.Add (ExpectedKey);
			SubKeys.Add (ExpectedKey2);
		}
		
		
		[SetUp]
		public void Init ()
		{
			RegistryKey reg = Registry.CurrentUser.CreateSubKey (SomeUnlikelyKey);
			reg.CreateSubKey (SomeUnlikelyKey);
			reg.CreateSubKey (ExpectedKey);
			reg.CreateSubKey (ExpectedKey2);
			reg.Close ();
		}
		
		
		[TearDown]
		public void Clean ()
		{
			try
			{
				Registry.CurrentUser.DeleteSubKeyTree (SomeUnlikelyKey);
			}
			catch (Exception)
			{
			}
		}

		
		[Test]
		[ExpectedException (typeof (ArgumentNullException))]
		public void DeleteSubKeyWithNullName ()
		{
			Registry.CurrentUser.DeleteSubKey (null);
		}


		[Test]
		public void EnumSubKeys ()
		{
			RegistryKey reg = Registry.CurrentUser.OpenSubKey (SomeUnlikelyKey);
			string[] keys = reg.GetSubKeyNames ();
			reg.Close ();
			
			StringCollection negativeTest = new StringCollection ();
			foreach (string key in keys)
			{
				Assertion.AssertEquals (true, SubKeys.Contains (key));
				Assertion.AssertEquals (false, negativeTest.Contains (key));
				negativeTest.Add (key);
			}
		}
	
		
		[Test]
		public void CountSubKeys ()
		{
			RegistryKey reg = Registry.CurrentUser.OpenSubKey (SomeUnlikelyKey);
			int count = reg.SubKeyCount;
			reg.Close ();
			
			Assertion.AssertEquals (SubKeys.Count, count);
		}

		
		[Test]
		public void EnumSubKeysWhenNoneExist ()
		{
			RegistryKey reg = Registry.CurrentUser.OpenSubKey (SomeUnlikelyKey + "\\" + ExpectedKey);
			string[] keys = reg.GetSubKeyNames ();
			reg.Close ();
			Assertion.AssertEquals (0, keys.Length);
		}
	
		
		[Test]
		public void CountSubKeysWhenNonExist ()
		{
			RegistryKey reg = Registry.CurrentUser.OpenSubKey (SomeUnlikelyKey + "\\" + ExpectedKey);
			int count = reg.SubKeyCount;
			reg.Close ();
			
			Assertion.AssertEquals (0, count);
		}
		
		[Test]
		public void DeleteSubKeyTree ()
		{
			Registry.CurrentUser.DeleteSubKeyTree (SomeUnlikelyKey);
		}
		
		[Test]
		public void DeleteLeafKey ()
		{
			RegistryKey reg = Registry.CurrentUser.OpenSubKey (SomeUnlikelyKey, true);
			reg.DeleteSubKey (ExpectedKey);
			Assertion.AssertEquals (SubKeys.Count - 1, reg.SubKeyCount);
			reg.Close ();
		}
		
		
		[Test]
		[ExpectedException (typeof (InvalidOperationException))]
		public void DeleteKeyTreeNodeWithChildren ()
		{
			Registry.CurrentUser.DeleteSubKey (SomeUnlikelyKey);
		}
	}

	
	/*[TestFixture]
	public class RegistryKeyValueEnumTest : RegistryKeyTestBase
	{
		public RegistryKeyValueEnumTest () : base ()
		{
		}
	}*/
	
	
	[TestFixture]
	public class RegistryKeyValueTest : RegistryKeyTestBase
	{
		const string SomeString = "Hello";
		
		public RegistryKeyValueTest () : base ()
		{
		}
		
		
		RegistryKey Reg;
		
		[SetUp]
		public void Init ()
		{
			Reg = Registry.CurrentUser.CreateSubKey (SomeUnlikelyKey);
			//Reg.CreateSubKey (SomeUnlikelyKey); ???

			// FIXME CREATE some three values!!!
		}
		
		[TearDown]
		public void Clean ()
		{
			Reg.Close ();
			try
			{
				Registry.CurrentUser.DeleteSubKeyTree (SomeUnlikelyKey);
			}
			catch (Exception)
			{
			}
		}
		

		private object Set {
			set { Reg.SetValue (SomeUnlikelyKey, value); }
		}

		private object Get {
			get { return Reg.GetValue (SomeUnlikelyKey); }
		}
		
		private object SetDefault {
			set { Reg.SetValue (null, value); }
		}

		private object GetDefault {
			get { return Reg.GetValue (null); }
		}
		
		
		[Test]
		[ExpectedException (typeof (ArgumentNullException))]
		public void NullValue ()
		{
			Set = null;
		}

		
		[Test]
		public void EmptyStringValue ()
		{
			Set = String.Empty;
			Assertion.AssertEquals (String.Empty, Get);
		}
		
		
		[Test]
		public void StringValue ()
		{
			Set = SomeString;
			Assertion.AssertEquals (SomeString, Get);
		}
		
		
		[Test]
		public void DefaultValueString ()
		{
			SetDefault = SomeString;
			Assertion.AssertEquals (SomeString, GetDefault);
		}

		
		[Test]
		public void IntegerValue ()
		{
			const int SomeInt = 13;
			Set = SomeInt;
			Assertion.AssertEquals (SomeInt, Get);
		}

		
		[Test]
		public void UnsignedIntegerValue ()
		{
			Set = (uint)15;
			Assertion.AssertEquals ("15", Get);
		}
		
		
		[Test]
		public void BooleanValue ()
		{
			Set = true;
			Assertion.AssertEquals (Boolean.TrueString, Get);
		}
		

		[Test]
		public void LongValue ()
		{
			Set = -1L;
			Assertion.AssertEquals ("-1", Get);
		}
		
		[Test]
		public void FloatValue ()
		{
			Set = 3.14;
			Assertion.AssertEquals ("3.14", Get);
		}
		
		[Test]
		public void BinaryValue ()
		{
			byte[] raw = new byte[] { 1, 2, 3, 4, 5};
			Set = raw;
			byte[] back = (byte[]) Get;
			
			Assertion.AssertEquals (raw.Length, back.Length);
			for (int i = 0; i < raw.Length; i ++)
			{
				Assertion.AssertEquals (raw[i], back[i]);
			}
		}
		
		[Test]
		[ExpectedException (typeof (ArgumentException))]
		public void InvalidArray ()
		{
			Set = new int[] {1, 2, 3, 4, 5};
		}


		[Test]
		public void CharacterValue ()
		{
			Set = 'Z';
			Assertion.AssertEquals ("Z", Get);
		}

		
		[Test]
		public void ByteValue ()
		{
			Set = (byte) 13;
			Assertion.AssertEquals ("13", Get);
		}
		

		[Test]
		public void StringArrayTest ()
		{
			string[] someArray = new string[] {"hello", "cruel", "world"};
			Set = someArray;
			string[] anotherArray = (string[]) Get;
			Assertion.AssertEquals (someArray.Length, anotherArray.Length);
			for (int i = 0; i < someArray.Length; i ++)
			{
				Assertion.AssertEquals (someArray[i], anotherArray[i]);
			}
		}
		
		
		[Test]
		public void StringArrayWithSpaces ()
		{
			string[] someArray = new string[] {"hello", "cruel world"};
			Set = someArray;
			string[] anotherArray = (string[]) Get;
			Assertion.AssertEquals (someArray.Length, anotherArray.Length);
			for (int i = 0; i < someArray.Length; i ++)
			{
				Assertion.AssertEquals (someArray[i], anotherArray[i]);
			}
		}
		

		[Test]
		public void GuidValue ()
		{
			Guid someGuid = Guid.NewGuid ();
			Set = someGuid;
			Guid anotherGuid = new Guid ((string)Get);
			Assertion.AssertEquals (someGuid, anotherGuid);
		}
		

		[Test]
		public void DeleteExistingValue ()
		{
			Set = "A";
			Reg.DeleteValue (SomeUnlikelyKey);
			Assertion.AssertEquals (0, Reg.ValueCount);
		}
		

		[Test]
		[ExpectedException (typeof (ArgumentException))]
		public void DeleteNonExistentKey ()
		{
			Reg.DeleteValue (SomeUnlikelyKey);
		}
	
		
		[Test]
		public void DeleteNonExistentKeyWithIgnore ()
		{
			Reg.DeleteValue (SomeUnlikelyKey, false);
		}
		
		/*
			FIXME: implement these tests
			- enum values
			- get with default values

			test for more exceptions
		*/
	}
}
