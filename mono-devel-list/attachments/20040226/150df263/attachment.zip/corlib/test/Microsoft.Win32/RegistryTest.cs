//
// MonoTests/Microsoft.Win32/RegistryTest.cs: unit tests for win32 registry
//
// Authos:
//	Erik LeBel (eriklebel@yahoo.ca)
//
// Copyright (C) Erik LeBel 2004
// 

using NUnit.Framework;
using Microsoft.Win32;


namespace MonoTests.Microsoft.Win32
{
	[TestFixture]	
	public class RegistryTest
	{
		[Test]
		public void TestClassesRoot ()
		{
			RegistryKey reg = Registry.ClassesRoot;
			Assertion.AssertNotNull (reg);
			Assertion.AssertEquals ("HKEY_CLASSES_ROOT", reg.Name);
		}
	
		
		[Test]
		public void TestCurrentConfig ()
		{
			RegistryKey reg = Registry.CurrentConfig;
			Assertion.AssertNotNull (reg);
			Assertion.AssertEquals ("HKEY_CURRENT_CONFIG", reg.Name);
		}

		
		[Test]
		public void TestCurrentUser ()
		{
			RegistryKey reg = Registry.CurrentUser;
			Assertion.AssertNotNull (reg);
			Assertion.AssertEquals ("HKEY_CURRENT_USER", reg.Name);
		}

		
		[Test]
		public void TestDynData ()
		{
			RegistryKey reg = Registry.DynData;
			Assertion.AssertNotNull (reg);
			Assertion.AssertEquals ("HKEY_DYN_DATA", reg.Name);
		}

		
		[Test]
		public void TestPerformanceData ()
		{
			RegistryKey reg = Registry.PerformanceData;
			Assertion.AssertNotNull (reg);
			Assertion.AssertEquals ("HKEY_PERFORMANCE_DATA", reg.Name);
		}

		
		[Test]
		public void TestUsers ()
		{
			RegistryKey reg = Registry.Users;
			Assertion.AssertNotNull (reg);
			Assertion.AssertEquals ("HKEY_USERS", reg.Name);
		}
	}
}
