using System;
using System.Collections;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using Mono.WindowsShell.Interop;

namespace Mono.WindowsShell {
    public class ShellFolder : IShellItem, IEnumerable {
        public ShellFolder(Environment.SpecialFolder folder) {
            IntPtr pidl;
            Marshal.ThrowExceptionForHR(
                Shell32.SHGetFolderLocation(IntPtr.Zero, folder,
                    IntPtr.Zero, 0, out pidl));
            this.pidl = new AbsolutePidl(pidl, true);
            this.com_interface = GetComInterface(this.pidl);
        }

        public ShellFolder(string path) {
            uint attributes = 0;
            uint eaten;
            IntPtr pidl;

            try {
                Desktop.com_interface.ParseDisplayName(IntPtr.Zero, IntPtr.Zero,
                    path, out eaten, out pidl, ref attributes);

                this.pidl = new AbsolutePidl(pidl, true);
                this.com_interface = GetComInterface(this.pidl);
            } catch (FileNotFoundException e) {
                throw new DirectoryNotFoundException(
                    string.Format("'{0}' is not a valid folder", path),
                    e);
            }
        }

        public IEnumerator GetEnumerator() {
            const int S_FALSE = 1;
            IntPtr result;
            int hresult = com_interface.EnumObjects(IntPtr.Zero,
                SHCONTF.SHCONTF_FOLDERS |
                SHCONTF.SHCONTF_NONFOLDERS, 
                out result);

            if (hresult == S_FALSE) {
                return new ShellFolderEnumerator(this, null);
            }

            Marshal.ThrowExceptionForHR(hresult);
            return new ShellFolderEnumerator(this,
                (IEnumIDList)Marshal.GetTypedObjectForIUnknown(result,
                    typeof(IEnumIDList)));
        }

        public bool IsImmediateParentOf(ShellFolder folder) {
            return this.pidl.IsImmediateParentOf(folder.pidl);
        }

        public bool IsParentOf(ShellFolder folder) {
            return this.pidl.IsParentOf(folder.pidl);
        }

        public bool HasFileSystemChildren {
            get { return GetAttributes(SFGAO.SFGAO_FILESYSANCESTOR) != 0; }
        }

        public bool IsFileSystem {
            get { return GetAttributes(SFGAO.SFGAO_FILESYSTEM) != 0; }
        }

        public bool IsFolder {
            get { return true; }
        }

        public string DisplayName {
            get {
                RelativePidl relativePidl;
                ShellFolder parent = GetParent(out relativePidl);
                return parent.GetChildDisplayName(relativePidl);
            }
        }

        public Icon LargeIcon {
            get {
                SHFILEINFO info = new SHFILEINFO();
                IntPtr result = Shell32.SHGetFileInfo(this.pidl.Handle, 
                    0, out info, Marshal.SizeOf(info),
                    SHGFI.SHGFI_ADDOVERLAYS | SHGFI.SHGFI_ICON |
                    SHGFI.SHGFI_LARGEICON | SHGFI.SHGFI_PIDL);

                if (result == IntPtr.Zero) {
                    throw new Exception("Error retreiving shell folder icon");
                }

                return Icon.FromHandle(info.hIcon);
            }
        }

        public ShellFolder Parent {
            get {
                if (this.parent == null) {
                    RelativePidl pidl;
                    this.parent = GetParent(out pidl);
                }

                return this.parent;
            }
        }

        public string Path {
            get {
                StringBuilder b = new StringBuilder(MAX_PATH);

                if (IsFileSystem) {
                    Shell32.SHGetPathFromIDList(pidl.Handle, b);
                    return b.ToString();
                } else {
                    throw new Exception("Folder is a virtual folder");
                }
            }
        }

        public Icon SmallIcon {
            get {
                SHFILEINFO info = new SHFILEINFO();
                IntPtr result = Shell32.SHGetFileInfo(pidl.Handle, 0, out info,
                    Marshal.SizeOf(info),
                    SHGFI.SHGFI_ADDOVERLAYS | SHGFI.SHGFI_ICON |
                    SHGFI.SHGFI_SMALLICON | SHGFI.SHGFI_PIDL);

                if (result == IntPtr.Zero) {
                    throw new Exception("Error retreiving shell folder icon");
                }

                return Icon.FromHandle(info.hIcon);
            }
        }

        internal ShellFolder CreateChildFolder(RelativePidl child) {
            return new ShellFolder(pidl + child);
        }

        internal SFGAO GetChildAttributes(RelativePidl child, SFGAO mask) {
            SFGAO result = mask;
            com_interface.GetAttributesOf(1, new IntPtr[] { child.Handle }, ref result);
            return result & mask;
        }

        internal string GetChildDisplayName(RelativePidl child) {
            return GetDisplayName(SHGDN.SHGDN_INFOLDER, child);
        }

        internal void GetChildIcons(RelativePidl child, out Icon smallIcon,
                                    out Icon largeIcon) {
            IntPtr result;
            IExtractIcon extractIcon;
            StringBuilder file = new StringBuilder(MAX_PATH);
            int index;
            GIL flags;
            IntPtr largeIconHandle;
            IntPtr smallIconHandle;

            com_interface.GetUIObjectOf(IntPtr.Zero, 1,
                new IntPtr[] { child.Handle },
                Shell32.IID_IExtractIcon, 0, out result);
            extractIcon = (IExtractIcon)
                Marshal.GetTypedObjectForIUnknown(result,
                    typeof(IExtractIcon));

            extractIcon.GetIconLocation(GIL.GIL_FORSHELL,
                file, (uint)file.Capacity, out index, out flags);
            extractIcon.Extract(file.ToString(), index, out largeIconHandle,
                out smallIconHandle, 32 | (16 << 16));

            smallIcon = Icon.FromHandle(smallIconHandle);
            largeIcon = Icon.FromHandle(largeIconHandle);
        }

        internal string GetChildPath(RelativePidl child) {
            return GetDisplayName(SHGDN.SHGDN_FORPARSING, child);
        }

        internal RelativePidl GetChildPidl(string filename) {
            uint eaten;
            IntPtr result;
            uint flags = 0;

            com_interface.ParseDisplayName(IntPtr.Zero,
                IntPtr.Zero, filename, out eaten, out result, ref flags);
            return new RelativePidl(result, true);
        }

        ShellFolder(AbsolutePidl pidl) {
            try {
                this.pidl = pidl;
                this.com_interface = GetComInterface(pidl);
            } catch (FileNotFoundException e) {
                throw new DirectoryNotFoundException(e.Message, e);
            }
        }

        ShellFolder(IntPtr iunknown, AbsolutePidl pidl) {
            this.pidl = pidl;
            this.com_interface = (IShellFolder)
                Marshal.GetTypedObjectForIUnknown(iunknown,
                    typeof(IShellFolder));
        }

        SFGAO GetAttributes(SFGAO mask) {
            RelativePidl relativePidl;
            ShellFolder parent = GetParent(out relativePidl);
            return parent.GetChildAttributes(relativePidl, mask);
        }

        string GetDisplayName(SHGDN flags, RelativePidl child) {
            STRRET pstr;
            StringBuilder builder = new StringBuilder(MAX_PATH);

            com_interface.GetDisplayNameOf(child.Handle, flags, out pstr);
            ShlWapi.StrRetToBuf(ref pstr, IntPtr.Zero, builder,
                (uint)builder.Capacity);
            return builder.ToString();
        }

        ShellFolder GetParent(out RelativePidl relative) {
            IntPtr parentFolder;
            IntPtr relativePidl;

            Marshal.ThrowExceptionForHR(
                Shell32.SHBindToParent(this.pidl.Handle, 
                    Shell32.IID_IShellFolder,
                    out parentFolder, 
                    out relativePidl));
            relative = new RelativePidl(relativePidl, true);
            return new ShellFolder(parentFolder, this.pidl.Parent);
        }

        static IShellFolder GetComInterface(AbsolutePidl pidl) {
            IntPtr result;

            if (Marshal.ReadInt16(pidl.Handle) != 0) {
                Desktop.com_interface.BindToObject(pidl.Handle, IntPtr.Zero,
                    Shell32.IID_IShellFolder, out result);
                return (IShellFolder)
                    Marshal.GetTypedObjectForIUnknown(result,
                        typeof(IShellFolder));
            } else {
                return Desktop.com_interface;
            }
        }

        static ShellFolder Desktop {
            get {
                if (m_Desktop == null) {
                    IntPtr result;
                    IntPtr pidl;

                    Marshal.ThrowExceptionForHR(
                        Shell32.SHGetDesktopFolder(out result));
                    Marshal.ThrowExceptionForHR(
                        Shell32.SHGetFolderLocation(IntPtr.Zero, 
                            Environment.SpecialFolder.Desktop,
                            IntPtr.Zero, 0, out pidl));
                    m_Desktop = new ShellFolder(result, new AbsolutePidl(pidl, true));
                }
                return m_Desktop;
            }
        }

        ShellFolder parent;
        AbsolutePidl pidl;
        IShellFolder com_interface;
        static ShellFolder m_Desktop;
        const int MAX_PATH = 260;
    }
}
