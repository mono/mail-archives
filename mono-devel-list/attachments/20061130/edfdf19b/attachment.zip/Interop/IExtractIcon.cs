using System;
using System.Runtime.InteropServices;
using System.Text;

namespace Mono.WindowsShell.Interop {
    enum GIL {
        GIL_OPENICON = 0x0001,
        GIL_FORSHELL = 0x0002,
        GIL_ASYNC = 0x0020,
        GIL_DEFAULTICON = 0x0040,
        GIL_FORSHORTCUT = 0x0080,
        GIL_SIMULATEDOC = 0x0001,
        GIL_PERINSTANCE = 0x0002,
        GIL_PERCLASS = 0x0004,
        GIL_NOTFILENAME = 0x0008,
        GIL_DONTCACHE = 0x0010,
    }

    [ComImport]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    [Guid("000214eb-0000-0000-c000-000000000046")]
    interface IExtractIcon {
        void GetIconLocation(GIL uFlags, StringBuilder szIconFile,
            uint cchMax, out int piIndex, out GIL pwFlags);
        void Extract(string pszFile, int nIconIndex, out IntPtr phiconLarge,
            out IntPtr phiconSmall, uint nIconSize );
    }
}
