using System;
using System.Runtime.InteropServices;

namespace Mono.WindowsShell.Interop {
    [ComImport]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    [Guid("000214F2-0000-0000-C000-000000000046")]
    public interface IEnumIDList {
        [PreserveSig]
        int Next(uint celt,
            out IntPtr rgelt, 
            out uint pceltFetched);

        [PreserveSig]
        uint Skip(uint celt);

        [PreserveSig]
        uint Reset();

        [PreserveSig()]
        uint Clone(out IEnumIDList ppenum);
    }
}
