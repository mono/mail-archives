using System;
using System.Runtime.InteropServices;

namespace Mono.WindowsShell.Interop {
    [ComImport]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    [Guid("000214E6-0000-0000-C000-000000000046")]
    public interface IShellFolder {
        void ParseDisplayName(IntPtr hwnd, IntPtr pbc, 
                              [MarshalAs(UnmanagedType.LPWStr)]
                              string pszDisplayName,
                              out uint pchEaten, out IntPtr ppidl,
                              ref uint pdwAttributes);

        [PreserveSig]
        Int32 EnumObjects(IntPtr hwnd, SHCONTF grfFlags,
                          out IntPtr ppenumIDList);

        void BindToObject(IntPtr pidl, IntPtr pbc,
                          [MarshalAs(UnmanagedType.LPStruct)] Guid riid,
                          out IntPtr ppv);

        void BindToStorage(IntPtr pidl, IntPtr pbc,
                           [MarshalAs(UnmanagedType.LPStruct)] Guid riid,
                           out IntPtr ppv);

        [PreserveSig]
        int CompareIDs(int lParam, IntPtr pidl1, IntPtr pidl2);

        void CreateViewObject(IntPtr hwndOwner,
            [MarshalAs(UnmanagedType.LPStruct)] Guid riid,
            out IntPtr ppv);

        void GetAttributesOf(uint cidl,
            [MarshalAs(UnmanagedType.LPArray, SizeParamIndex = 0)]
            IntPtr[] apidl,
            ref SFGAO rgfInOut);

        void GetUIObjectOf(IntPtr hwndOwner, uint cidl,
            [MarshalAs(UnmanagedType.LPArray, SizeParamIndex = 1)]
            IntPtr[] apidl,
            [MarshalAs(UnmanagedType.LPStruct)] Guid riid,
            uint rgfReserved,
            out IntPtr ppv);

        void GetDisplayNameOf(IntPtr pidl, SHGDN uFlags,
                              out STRRET pName);

        void SetNameOf(IntPtr hwnd, IntPtr pidl, string pszName,
                       int uFlags, out IntPtr ppidlOut);
    }
}
