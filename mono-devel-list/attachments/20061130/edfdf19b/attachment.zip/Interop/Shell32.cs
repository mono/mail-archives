using System;
using System.Runtime.InteropServices;
using System.Text;

namespace Mono.WindowsShell.Interop {
    public enum SFGAO : uint {
        SFGAO_CANCOPY = 0x00000001,
        SFGAO_CANMOVE = 0x00000002,
        SFGAO_CANLINK = 0x00000004,
        SFGAO_STORAGE = 0x00000008,
        SFGAO_CANRENAME = 0x00000010,
        SFGAO_CANDELETE = 0x00000020,
        SFGAO_HASPROPSHEET = 0x00000040,
        SFGAO_DROPTARGET = 0x00000100,
        SFGAO_CAPABILITYMASK = 0x00000177,
        SFGAO_ENCRYPTED = 0x00002000,
        SFGAO_ISSLOW = 0x00004000,
        SFGAO_GHOSTED = 0x00008000,
        SFGAO_LINK = 0x00010000,
        SFGAO_SHARE = 0x00020000,
        SFGAO_READONLY = 0x00040000,
        SFGAO_HIDDEN = 0x00080000,
        SFGAO_DISPLAYATTRMASK = 0x000FC000,
        SFGAO_STREAM = 0x00400000,
        SFGAO_STORAGEANCESTOR = 0x00800000,
        SFGAO_VALIDATE = 0x01000000,
        SFGAO_REMOVABLE = 0x02000000,
        SFGAO_COMPRESSED = 0x04000000,
        SFGAO_BROWSABLE = 0x08000000,
        SFGAO_FILESYSANCESTOR = 0x10000000,
        SFGAO_FOLDER = 0x20000000,
        SFGAO_FILESYSTEM = 0x40000000,
        SFGAO_HASSUBFOLDER = 0x80000000,
        SFGAO_CONTENTSMASK = 0x80000000,
        SFGAO_STORAGECAPMASK = 0x70C50008,
    }

    public enum SHCONTF {
        SHCONTF_FOLDERS = 0x0020,
        SHCONTF_NONFOLDERS = 0x0040,
        SHCONTF_INCLUDEHIDDEN = 0x0080,
        SHCONTF_INIT_ON_FIRST_NEXT = 0x0100,
        SHCONTF_NETPRINTERSRCH = 0x0200,
        SHCONTF_SHAREABLE = 0x0400,
        SHCONTF_STORAGE = 0x0800
    }

    public struct SHFILEINFO {
        public IntPtr hIcon;
        public int iIcon;
        public uint dwAttributes;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 260)]
        public string szDisplayName;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 80)]
        public string szTypeName;
    };

    public enum SHGDN {
        SHGDN_NORMAL = 0x0000,
        SHGDN_INFOLDER = 0x0001,
        SHGDN_FOREDITING = 0x1000,
        SHGDN_FORADDRESSBAR = 0x4000,
        SHGDN_FORPARSING = 0x8000,
    }

    [Flags]
    enum SHGFI {
        SHGFI_ICON = 0x000000100,
        SHGFI_DISPLAYNAME = 0x000000200,
        SHGFI_TYPENAME = 0x000000400,
        SHGFI_ATTRIBUTES = 0x000000800,
        SHGFI_ICONLOCATION = 0x000001000,
        SHGFI_EXETYPE = 0x000002000,
        SHGFI_SYSICONINDEX = 0x000004000,
        SHGFI_LINKOVERLAY = 0x000008000,
        SHGFI_SELECTED = 0x000010000,
        SHGFI_ATTR_SPECIFIED = 0x000020000,
        SHGFI_LARGEICON = 0x000000000,
        SHGFI_SMALLICON = 0x000000001,
        SHGFI_OPENICON = 0x000000002,
        SHGFI_SHELLICONSIZE = 0x000000004,
        SHGFI_PIDL = 0x000000008,
        SHGFI_USEFILEATTRIBUTES = 0x000000010,
        SHGFI_ADDOVERLAYS = 0x000000020,
        SHGFI_OVERLAYINDEX = 0x000000040
    }

    [StructLayout(LayoutKind.Explicit)]
    public struct STRRET {
        [FieldOffset(0)]
        public UInt32 uType;
        [FieldOffset(4)]
        public IntPtr pOleStr;
        [FieldOffset(4)]
        public IntPtr pStr;
        [FieldOffset(4)]
        public UInt32 uOffset;
        [FieldOffset(4)]
        public IntPtr cStr;
    }

    class Shell32 {
        [DllImport("shell32.dll")]
        public static extern IntPtr ILClone(IntPtr pidl);

        [DllImport("shell32.dll")]
        public static extern IntPtr ILCombine(IntPtr pidl1, IntPtr pidl2);

        [DllImport("shell32.dll")]
        public static extern void ILFree(IntPtr pidl);

        [DllImport("shell32.dll")]
        public static extern bool ILIsEqual(IntPtr pidl1, IntPtr pidl2);

        [DllImport("shell32.dll")]
        public static extern bool ILIsParent(IntPtr pidl1, IntPtr pidl2,
            bool fImmediate);

        [DllImport("shell32.dll")]
        public static extern bool ILRemoveLastID(IntPtr pidl);

        [DllImport("shell32.dll")]
        public static extern Int32 SHBindToParent(IntPtr pidl,
            [MarshalAs(UnmanagedType.LPStruct)] Guid riid,
            out IntPtr ppv, out IntPtr ppidlLast);

        [DllImport("shell32.dll")]
        public static extern Int32 SHGetDesktopFolder(out IntPtr ppshf);

        [DllImport("shell32.dll")]
        public static extern int SHGetFolderLocation(IntPtr hwndOwner,
            Environment.SpecialFolder nFolder, IntPtr hToken, uint dwReserved,
            out IntPtr ppidl);

        [DllImport("shell32.dll")]
        public static extern IntPtr SHGetFileInfo(IntPtr pszPath,
            int dwFileAttributes, out SHFILEINFO psfi, int cbFileInfo,
            SHGFI uFlags);

        [DllImport("shell32.dll")]
        public static extern bool SHGetPathFromIDList(IntPtr pidl,
            StringBuilder pszPath);

        public static Guid IID_IExtractIcon {
            get { return new Guid("000214EB-0000-0000-c000-000000000046"); }
        }

        public static Guid IID_IShellFolder {
            get { return new Guid("000214E6-0000-0000-C000-000000000046"); }
        }
    }
}
