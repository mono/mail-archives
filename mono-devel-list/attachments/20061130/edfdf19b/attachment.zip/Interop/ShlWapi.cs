using System;
using System.Runtime.InteropServices;
using System.Text;

namespace Mono.WindowsShell.Interop {
    public class ShlWapi {
        [DllImport("shlwapi.dll")]
        public static extern Int32 StrRetToBuf(ref STRRET pstr, IntPtr pidl,
                                               StringBuilder pszBuf,
                                               UInt32 cchBuf);
    }
}
