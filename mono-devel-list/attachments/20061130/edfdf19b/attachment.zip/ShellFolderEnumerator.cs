using System;
using System.Collections;
using System.Runtime.InteropServices;
using Mono.WindowsShell.Interop;

namespace Mono.WindowsShell {
    class ShellFolderEnumerator : IEnumerator {
        internal ShellFolderEnumerator(ShellFolder folder, IEnumIDList enumerator) {
            this.folder = folder;
            this.enumerator = enumerator;
        }

        public object Current {
            get { return current; }
        }

        public void Dispose() {
            Marshal.ReleaseComObject(enumerator);
        }

        public bool MoveNext() {
            const int S_OK = 0;
            const int S_FALSE = 1;
            uint count;
            IntPtr pidl = IntPtr.Zero;
            int hresult = S_FALSE;

            if (enumerator != null) {
                hresult = enumerator.Next(1, out pidl, out count);
            }

            if (hresult == S_OK) {
                current = new ShellItem(folder, new RelativePidl(pidl, true));
                return true;
            } else if (hresult == S_FALSE) {
                return false;
            } else {
                Marshal.ThrowExceptionForHR(hresult);
                return false;
            }
        }

        public void Reset() {
            enumerator.Reset();
        }

        ShellFolder folder;
        IEnumIDList enumerator;
        ShellItem current;
    }
}
