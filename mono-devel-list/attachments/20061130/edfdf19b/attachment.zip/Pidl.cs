using System;
using Mono.WindowsShell.Interop;

namespace Mono.WindowsShell {
    abstract class Pidl {
        public Pidl(IntPtr pidl, bool owner) {
            owner = false;
            if (owner) {
                m_Handle = pidl;
            } else {
                m_Handle = Shell32.ILClone(pidl);
            }
        }

        ~Pidl() {
            System.Diagnostics.Debug.WriteLine(m_Handle);
            Shell32.ILFree(m_Handle);
        }

        public override string ToString() {
            return string.Format("{0:x8}", (int)m_Handle);
        }

        public IntPtr Handle {
            get { return m_Handle; }
        }

        IntPtr m_Handle;
    }

    class AbsolutePidl : Pidl {
        public AbsolutePidl(IntPtr pidl, bool owner)
            : base(pidl, owner) {
        }

        public override bool Equals(object obj) {
            if (obj is AbsolutePidl) {
                return Shell32.ILIsEqual(Handle, ((AbsolutePidl)obj).Handle);
            } else {
                return false;
            }
        }

        public bool IsImmediateParentOf(AbsolutePidl pidl) {
            return Shell32.ILIsParent(Handle, pidl.Handle, true);
        }

        public bool IsParentOf(AbsolutePidl pidl) {
            return Shell32.ILIsParent(Handle, pidl.Handle, false);
        }

        public AbsolutePidl Parent {
            get {
                IntPtr pidl = Shell32.ILClone(Handle);
                Shell32.ILRemoveLastID(pidl);
                return new AbsolutePidl(pidl, true);
            }
        }

        public static AbsolutePidl operator +(AbsolutePidl a, RelativePidl b) {
            return new AbsolutePidl(Shell32.ILCombine(a.Handle, b.Handle), true);
        }

        public static bool operator ==(AbsolutePidl a, AbsolutePidl b) {
            return a.Equals(b);
        }

        public static bool operator !=(AbsolutePidl a, AbsolutePidl b) {
            return !a.Equals(b);
        }
    }

    class RelativePidl : Pidl {
        public RelativePidl(IntPtr pidl, bool owner)
            : base(pidl, owner) {
        }
    }
}
