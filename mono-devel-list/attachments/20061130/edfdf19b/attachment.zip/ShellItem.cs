using System;
using System.Drawing;
using System.IO;
using Mono.WindowsShell.Interop;

namespace Mono.WindowsShell {
    public class ShellItem : IShellItem {
        public ShellItem(string path) {
            parent = new ShellFolder(System.IO.Path.GetDirectoryName(path));
            pidl = parent.GetChildPidl(System.IO.Path.GetFileName(path));
        }

        public ShellFolder ToShellFolder() {
            return parent.CreateChildFolder(pidl);
        }

        public string DisplayName {
            get { return parent.GetChildDisplayName(pidl); }
        }

        public bool IsFolder {
            get { return parent.GetChildAttributes(pidl, SFGAO.SFGAO_FOLDER) != 0;  }
        }

        public System.Drawing.Icon LargeIcon {
            get {
                Icon small;
                Icon large;
                parent.GetChildIcons(pidl, out small, out large);
                return large;
            }
        }

        public ShellFolder Parent {
            get { return parent; }
        }

        public string Path {
            get { return parent.GetChildPath(pidl); }
        }

        public System.Drawing.Icon SmallIcon {
            get {
                Icon small;
                Icon large;
                parent.GetChildIcons(pidl, out small, out large);
                return small;
            }
        }

        internal ShellItem(ShellFolder parent, RelativePidl pidl) {
            this.parent = parent;
            this.pidl = pidl;
        }

        ShellItem() { }

        ShellFolder parent;
        RelativePidl pidl;
    }
}
