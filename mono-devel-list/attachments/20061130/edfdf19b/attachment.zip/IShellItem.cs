using System;
using System.Drawing;
using System.Collections.Generic;
using System.Text;

namespace Mono.WindowsShell {
    public interface IShellItem {
        string DisplayName { get; }
        bool IsFolder { get; }
        Icon LargeIcon { get; }
        ShellFolder Parent { get; }
        string Path { get; }
        Icon SmallIcon { get; }
    }
}
