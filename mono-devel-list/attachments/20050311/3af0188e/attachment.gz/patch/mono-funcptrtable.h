#ifndef _MONO_FUNC_PTR_TABLE_H_
#define  _MONO_FUNC_PTR_TABLE_H_ 1

#include "glib.h"
#include "mono/io-layer/io-layer.h"

typedef struct {
	GArray		*funcptrtables_array;
	gpointer 	 lastoffset;
	gpointer	 maxoffset;
	CRITICAL_SECTION lock;
} MonoFunctionPointerTable;

MonoFunctionPointerTable * mono_funcptrtable_new (void);
void mono_funcptrtable_free (MonoFunctionPointerTable **table);

gpointer mono_funcptrtable_get_new_offset (MonoFunctionPointerTable *table, char* debug);
gpointer mono_funcptrtable_get_offset (MonoFunctionPointerTable *table, gpointer IP);

#endif  /*_MONO_FUNC_PTR_TABLE_H_*/
