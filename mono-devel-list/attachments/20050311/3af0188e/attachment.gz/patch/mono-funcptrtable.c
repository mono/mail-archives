#include "mono-funcptrtable.h"

/* based on mono-codeman.c */
#include <stdlib.h>
#include <unistd.h>

#ifdef PLATFORM_WIN32
#include <windows.h>
#include <io.h>
#else
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <fcntl.h>
#endif


#ifndef MAP_ANONYMOUS
#ifdef MAP_ANON
#define MAP_ANONYMOUS MAP_ANON
#endif
#endif


#ifdef __x86_64__
/*must be in 32 addr space, because the call displacements are 32 bits only!*/
#define ARCH_MAP_FLAGS MAP_32BIT
#else
#define ARCH_MAP_FLAGS 0
#endif


static int
query_pagesize (void)
{
#ifdef PLATFORM_WIN32
	SYSTEM_INFO info;
	GetSystemInfo (&info);
	return info.dwAllocationGranularity;
#else
	return getpagesize ();
#endif
}

static int FUNC_PTR_TABLE_SIZE;
static int FUNC_PTR_TABLE_MAXOFFSET;

static void
setup_limits (void)
{
	FUNC_PTR_TABLE_SIZE = 16 * query_pagesize();
	FUNC_PTR_TABLE_MAXOFFSET = FUNC_PTR_TABLE_SIZE;
}

static gpointer
mono_funcptrtable_alloc (void)
{
	gpointer result;
	result = mmap (0, FUNC_PTR_TABLE_SIZE, PROT_READ|PROT_WRITE, MAP_PRIVATE|MAP_ANONYMOUS|ARCH_MAP_FLAGS, -1, 0);
		if (result == (void*)-1) {
			int fd = open ("/dev/zero", O_RDONLY);
			if (fd != -1) {
				result = mmap (0, FUNC_PTR_TABLE_SIZE, PROT_READ|PROT_WRITE, MAP_PRIVATE|ARCH_MAP_FLAGS, fd, 0);
				close (fd);
			}
			g_assert (result != (void*)-1);
		}
	/*g_print ("FuncPtrTable: %p %p\n", result, result +FUNC_PTR_TABLE_SIZE);*/
	return result;
}

static void
mono_funcptrtable_entry_free (gpointer memory)
{
	munmap (memory, FUNC_PTR_TABLE_SIZE);
}


MonoFunctionPointerTable *
mono_funcptrtable_new (void)
{
	setup_limits ();
	MonoFunctionPointerTable * result;
	result = (MonoFunctionPointerTable*) g_malloc (sizeof (MonoFunctionPointerTable));
	InitializeCriticalSection (& (result->lock));
	result->funcptrtables_array = g_array_new (FALSE, TRUE, sizeof (gpointer));
	gpointer mem = mono_funcptrtable_alloc ();
	g_array_append_val (result->funcptrtables_array, mem);
	result->lastoffset = mem;
	result->maxoffset = mem + FUNC_PTR_TABLE_MAXOFFSET;
	return result;
}

#define Table_Lock(x) EnterCriticalSection (&((x)->lock));
#define Table_Unlock(x) LeaveCriticalSection (&((x)->lock));

void
mono_funcptrtable_free (MonoFunctionPointerTable **table)
{
	g_assert (*table);
	int i;
	setup_limits ();
/**/	Table_Lock ((*table));
/**/	for (i = 0; i < (*table)->funcptrtables_array->len; i++) {
/**/		mono_funcptrtable_entry_free (g_array_index ((*table)->funcptrtables_array, gpointer, i));
/**/	}
/**/	g_array_free ((*table)->funcptrtables_array, TRUE);
/**/	(*table)->funcptrtables_array = NULL;
/**/	Table_Unlock ((*table));
	DeleteCriticalSection (& ((*table)->lock));
	g_free (*table);
	*table = NULL;
}



gpointer
mono_funcptrtable_get_new_offset (MonoFunctionPointerTable *table, char* debug)
{
	gpointer result;
	setup_limits ();
/**/	Table_Lock (table);
/**/	result = table->lastoffset;
/**/	if (table->lastoffset <= (table->maxoffset - 4 * sizeof (gpointer))) {
/**/		table->lastoffset += 2 * sizeof (gpointer);
/**/	} else {
/**/		gpointer mem = mono_funcptrtable_alloc ();
/**/		g_array_append_val (table->funcptrtables_array, mem);
/**/		table->lastoffset = mem;
/**/		table->maxoffset = mem + FUNC_PTR_TABLE_MAXOFFSET;
/**/	}
/**/	Table_Unlock (table);
	/*clear data area*/
	*((gpointer*)(result + sizeof(gpointer))) = NULL;
	/*g_print ("New funcptrtable entry: %p (%s)\n", result, debug);*/
	return result;
}


gpointer
mono_funcptrtable_get_offset (MonoFunctionPointerTable *table, gpointer IP)
{
	int i;
	gpointer a;
	gpointer result = NULL;
	setup_limits ();
	for (i = 0; i < table->funcptrtables_array->len; i++){
		gpointer baseptr = g_array_index (table->funcptrtables_array, gpointer, i);
		for (a = baseptr; a < baseptr + FUNC_PTR_TABLE_MAXOFFSET; a += 2 * sizeof (gpointer)){
			if ( *((gpointer*)a) == IP ) {
				result = a;
				goto LoopExit;
			}
		}
	}
LoopExit:
	return result;
}
