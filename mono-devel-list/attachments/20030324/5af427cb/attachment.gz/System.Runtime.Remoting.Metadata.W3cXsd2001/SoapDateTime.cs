//
// System.Runtime.Remoting.Metadata.W3cXsd2001.SoapDateTime
//
// Authors:
//      Martin Willemoes Hansen (mwh@sysrq.dk)
//
// (C) 2003 Martin Willemoes Hansen
//

namespace System.Runtime.Remoting.Metadata.W3cXsd2001 
{
	public sealed class SoapDateTime
	{
		[MonoTODO]
		public SoapDateTime()
		{
		}
		
		public static string XsdType {
			[MonoTODO]
			get { throw new NotImplementedException(); }
		}

		[MonoTODO]
		public static DateTime Parse (string value)
		{
			throw new NotImplementedException();
		}

		[MonoTODO]
		public override string ToString()
		{
			throw new NotImplementedException();
		}

		[MonoTODO]
		~SoapDateTime()
		{
		}
	}
}
