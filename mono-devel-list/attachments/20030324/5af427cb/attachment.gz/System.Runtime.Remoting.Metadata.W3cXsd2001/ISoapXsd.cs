//
// System.Runtime.Remoting.Metadata.W3cXsd2001.ISoapXsd
//
// Authors:
//      Martin Willemoes Hansen (mwh@sysrq.dk)
//
// (C) 2003 Martin Willemoes Hansen
//

namespace System.Runtime.Remoting.Metadata.W3cXsd2001 
{
        public interface ISoapXsd {
		string GetXsdType();
	}
}
