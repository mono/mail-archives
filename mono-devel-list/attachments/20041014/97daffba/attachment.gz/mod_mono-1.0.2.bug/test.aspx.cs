using System;
using System.Collections;
using System.ComponentModel;
using System.Globalization;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace Test
{
	/// <summary>
	/// </summary>
	public class Test : Page
	{
		protected HtmlForm form;
	    
		private void Page_Load(object sender, System.EventArgs e) {

		    for ( int i = 0; i < 100; i++ ) {
			DropDownList d = new DropDownList();
			form.Controls.Add( d );
			
			for ( int j = 0; j < 50; j++ )
			    d.Items.Add(
				new ListItem(
				    "name", "value"
				)
			    );
			
		    }
		}

		override protected void OnInit(EventArgs e)	{
			InitializeComponent();
			base.OnInit(e);
		}
		
		private void InitializeComponent() {
			this.Load += new System.EventHandler(this.Page_Load);
		}
	}
}