using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.AppKit;
using MonoMac.ObjCRuntime;
using MonoMac.CoreGraphics;

namespace OpenGLScreenSnapshot
{
        public partial class AppDelegate : NSApplicationDelegate
        {
                MainWindowController mainWindowController;

                public AppDelegate ()
                {
                }

                public override void FinishedLaunching (NSObject notification)
                {
                        mainWindowController = new MainWindowController ();
                        mainWindowController.Window.MakeKeyAndOrderFront (this);
                        OpenGLScreenReader reader = new OpenGLScreenReader();
                        
                        reader.readFullScreenToBuffer();
                        reader.createTIFFImageFileOnDesktop();
                        
                        var screenShot = new NSImageView(mainWindowController.Window.ContentView.Bounds);
                        screenShot.ImageScaling = NSImageScale.ProportionallyUpOrDown;  //AxesIndependently;
                        screenShot.Image = new NSImage(reader.image(),mainWindowController.Window.ContentView.Bounds.Size);
                        screenShot.AutoresizingMask = mainWindowController.Window.ContentView.AutoresizingMask;
                        mainWindowController.Window.ContentView.AddSubview(screenShot);
   
                        
                        
                }
        }
}

