using System;
using System.Drawing;
using System.IO;
using MonoMac.Foundation;
using MonoMac.AppKit;
using MonoMac.CoreGraphics;
using MonoMac.ImageIO;
using MonoMac.ObjCRuntime;
using MonoMac.OpenGL;

namespace OpenGLScreenSnapshot
{
        public partial class OpenGLScreenReader : NSObject
        {
            
                NSOpenGLContext mGLContext;
                int mByteWidth, mWidth, mHeight;
                byte[] mData;

                public OpenGLScreenReader ()
                {
                        // Create a full-screen OpenGL graphics context

                        NSOpenGLPixelFormatAttribute[] attributes = new NSOpenGLPixelFormatAttribute[] {
                                NSOpenGLPixelFormatAttribute.FullScreen, 
                                NSOpenGLPixelFormatAttribute.ScreenMask, 
                                (NSOpenGLPixelFormatAttribute)GL.IDToOpenGLDisplayMask (GL.MainDisplayID ()), 
                                (NSOpenGLPixelFormatAttribute)0
                        };
                        
                        NSOpenGLPixelFormat glPixelFormat = new NSOpenGLPixelFormat (attributes);
                        
                        if (glPixelFormat == null)
                                return;
                        
                        // Create OpenGL context used to render
                        mGLContext = new NSOpenGLContext (glPixelFormat, null);
                        if (mGLContext == null)
                                return;
                        
                        // Set our context as the current OpenGL context
                        mGLContext.MakeCurrentContext ();
                        // Set full-screen mode
                        mGLContext.SetFullScreen ();
                        
                        RectangleF mainScreenRect = NSScreen.MainScreen.Frame;
                        mWidth = (int)mainScreenRect.Size.Width;
                        mHeight = (int)mainScreenRect.Size.Height;
                        
                        mByteWidth = mWidth * 4;         // Assume 4 bytes/pixel for now
                        mByteWidth = (mByteWidth + 3) & ~3;    // Align to 4 bytes
                        
                        mData = new byte[mByteWidth * mHeight];
                }

                public void readFullScreenToBuffer ()
                {
                        readPartialScreenToBuffer (mWidth, mHeight, mData);                
                }

                public void readPartialScreenToBuffer (int bufferWidth, int bufferHeight, byte[] buffer)
                {
                        // select front buffer as our source for pixel data
                        GL.ReadBuffer (GL.FRONT);
                        
                        //Read OpenGL context pixels directly.
                        
                        // For extra safety, save & restore OpenGL states that are changed
                        GL.PushClientAttrib (GL.CLIENT_PIXEL_STORE_BIT);
                        
                        GL.PixelStorei (GL.PACK_ALIGNMENT, 4); /* Force 4-byte alignment */
                        GL.PixelStorei (GL.PACK_ROW_LENGTH, 0);
                        GL.PixelStorei (GL.PACK_SKIP_ROWS, 0);
                        GL.PixelStorei (GL.PACK_SKIP_PIXELS, 0);
                        // Read a block of pixels from the frame buffer
                        GL.ReadPixels (0, 0, bufferWidth, bufferHeight, GL.BGRA, GL.UNSIGNED_INT_8_8_8_8_REV, buffer); 
                        /*
                        IMPORTANT
                        
                        For the pixel data format and type parameters you should *always* specify:
                        
                        format: GL_BGRA
                        type: GL_UNSIGNED_INT_8_8_8_8_REV
                        
                        because this is the native format of the GPU for both PPC and Intel and will 
                        give you the best performance. Any deviation from this format will not give 
                        you optimal performance!
                        
                        BACKGROUND
                        
                        When using GL_UNSIGNED_INT_8_8_8_8_REV, the OpenGL implementation 
                        expects to find data in byte order ARGB on big-endian systems, but BGRA on 
                        little-endian systems. Because there is no explicit way in OpenGL to specify 
                        a byte order of ARGB with 32-bit or 16-bit packed pixels (which are common
                        image formats on Macintosh PowerPC computers), many applications specify 
                        GL_BGRA with GL_UNSIGNED_INT_8_8_8_8_REV. This practice works on a 
                        big-endian system such as PowerPC, but the format is interpreted differently 
                        on a little-endian system, and causes images to be rendered with incorrect colors.
                        
                        To prevent images from being rendered incorrectly by this application on little 
                        endian systems, you must specify the ordering of the data (big/little endian)
                        when creating Quartz bitmap contexts using the CGBitmapContextCreate function. 
                        See the createRGBImageFromBufferData: method in the Buffer.m source file for
                        the details.
                        
                        Also, if you need to reverse endianness, consider using vImage after the read. See: 
                        
                        http://developer.apple.com/documentation/Performance/Conceptual/vImage/
                        
                        */
                        
                        GL.PopClientAttrib ();
                        //Check for OpenGL errors
                        int theError = GL.NO_ERROR;
                        theError = GL.GetError ();
                        if (theError != GL.NO_ERROR)
                                Console.WriteLine ("OpenGL error {0}", theError);

                }

                CGImage createRGBImageFromBufferData ()
                {
                
                        CGColorSpace cSpace = CGColorSpace.CreateDeviceRGB ();

                        CGImageAlphaInfo ai = (CGImageAlphaInfo)((int)CGImageAlphaInfo.NoneSkipFirst | (int)CGBitmapFlags.ByteOrder32Little) ;
                        
                        CGBitmapContext bitmap;
                        try {
                                unsafe {
                                        
                                        //fixed (byte* ptr = &pixels[ 0 ]) {
                                        fixed (byte* ptr = mData) {
                                                bitmap = new CGBitmapContext ((IntPtr)ptr,mWidth,mHeight,8,mByteWidth,cSpace, ai);
                                        }
                                }
                        } catch {
                                
                        }
                        
                        CGImage image = bitmap.ToImage ();
                       
                        return image;
                        
                        
                }

                /*
                  * perform an in-place swap from Quadrant 1 to Quadrant III format
                  * (upside-down PostScript/GL to right side up QD/CG raster format)
                  * We do this in-place, which requires more copying, but will touch
                  * only half the pages.  (Display grabs are BIG!)
                  *
                  * Pixel reformatting may optionally be done here if needed.
                  */
                private void flipImageData ()
                {
                        
                        long top, bottom;
                        byte[] buffer;
                        long topP;
                        long bottomP;
                        long rowBytes;
                        
                        top = 0;
                        bottom = mHeight - 1;
                        rowBytes = mByteWidth;
                        buffer = new byte[rowBytes];
                        
                        while (top < bottom) {
                                topP = top * rowBytes;
                                bottomP = bottom * rowBytes;
                                
                                /*
                                * Save and swap scanlines.
                                *
                                * This code does a simple in-place exchange with a temp buffer.
                                * If you need to reformat the pixels, replace the first two bcopy()
                                * calls with your own custom pixel reformatter.
                                */

                                Array.Copy (mData, topP, buffer, 0, rowBytes);
                                Array.Copy (mData, bottomP, mData, topP, rowBytes);
                                Array.Copy (buffer, 0, mData, bottomP, rowBytes);
                                
                                ++top;
                                --bottom;
                                
                        }
                }

                public void createTIFFImageFileOnDesktop ()
                {
                        // glReadPixels writes things from bottom to top, but we
                        // need a top to bottom representation, so we must flip
                        // the buffer contents.
                        flipImageData ();

                        CGImage imageRef = createRGBImageFromBufferData ();

                        var destopDirectory = Environment.GetFolderPath (Environment.SpecialFolder.DesktopDirectory);
                        var finalPath = Path.Combine (destopDirectory, "ScreenssSnapshot.tiff");
                        NSUrl url = NSUrl.FromString (finalPath);
                        
                        CGImageDestination dest = CGImageDestination.FromUrl (url, "public.tiff", 1, null);
                        dest.AddImage (imageRef, null);
                        
                        bool success = dest.Close ();
                        //                        if (success == false)
                        //                                Console.WriteLine("did not work");
                        //                        else
                        //                                Console.WriteLine("did work");
                        NSBitmapImageRep rep = new NSBitmapImageRep (imageRef);
                        NSData data = rep.RepresentationUsingTypeProperties (NSBitmapImageFileType.Tiff, new NSDictionary ());

                        FileStream outStream = new FileStream (finalPath, FileMode.Create);
                        Copy (data.AsStream (), outStream);
                        
                }

                public CGImage image ()
                {
                        return createRGBImageFromBufferData ();
                }

                public void Copy (Stream source, Stream target)
                {
                        byte[] buffer = new byte[0x10000];
                        int bytes;
                        try {
                                while ((bytes = source.Read (buffer, 0, buffer.Length)) > 0) {
                                        target.Write (buffer, 0, bytes);
                                }
                        } finally {
                                target.Close ();

                        }
                }


        }
}

