using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.AppKit;
using MonoMac.ObjCRuntime;

namespace OpenGLScreenSnapshot
{
        class MainClass
        {
                static void Main (string[] args)
                {
                        const string OpenGLLibrary = "/System/Library/Frameworks/OpenGL.framework/OpenGL";
                        IntPtr openGl = Dlfcn.dlopen(OpenGLLibrary,1);
                        if (openGl == IntPtr.Zero)
                                Console.WriteLine(Dlfcn.dlerror());
                        NSApplication.Init ();
                        NSApplication.Main (args);
                }
        }
}

