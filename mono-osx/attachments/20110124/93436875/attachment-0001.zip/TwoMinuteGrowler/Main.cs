using System;
using System.Runtime;
using System.IO;
using System.Drawing;
using System.Runtime.InteropServices;
using MonoMac.Foundation;
using MonoMac.AppKit;

namespace TwoMinuteGrowler {
	class MainClass {
		static void Main ( string[] args ) {
			
			var baseAppPath = Directory.GetParent (Directory.GetParent (System.AppDomain.CurrentDomain.BaseDirectory).ToString ());
			//var growlPath = baseAppPath + "/Frameworks/Growl-WithInstaller.framework/Growl-WithInstaller";
			var growlPath = baseAppPath + "/Frameworks/Growl.framework/Growl";
			
			IntPtr growlPtr = dlopen (growlPath, 1);
			
			if (growlPtr == IntPtr.Zero) {
				Console.WriteLine("Growl framework could not be loaded");
				Console.WriteLine("Make sure that the Growl framework is available");
				return;
			}
			
			NSApplication.Init ();
			NSApplication.Main (args);
		}
		
		[DllImport ("/usr/lib/libSystem.dylib")]
		public static extern IntPtr dlopen (string path, int mode);	
	}
}

