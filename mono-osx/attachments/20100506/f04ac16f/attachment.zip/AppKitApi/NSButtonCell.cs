using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSActionCell))]
	interface NSButtonCell {

		//- (NSString *)title;
		[Export ("title")]
		string Title { get; set; }

		//- (NSString *)alternateTitle;
		[Export ("alternateTitle")]
		string AlternateTitle { get; set; }

		//- (NSImage *)alternateImage;
		[Export ("alternateImage")]
		NSImage AlternateImage { get; set; }

		//- (NSCellImagePosition)imagePosition;
		[Export ("imagePosition")]
		NSCellImagePosition ImagePosition { get; set; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (NSImageScaling)imageScaling;
		[Export ("imageScaling")]
		NSImageScaling ImageScaling { get; set; }

//#endif
		//- (NSInteger)highlightsBy;
		[Export ("highlightsBy")]
		int HighlightsBy { get; set; }

		//- (NSInteger)showsStateBy;
		[Export ("showsStateBy")]
		int ShowsStateBy { get; set; }

		//- (void)setButtonType:(NSButtonType)aType;
		[Export ("setButtonType:")]
		void SetButtonType (NSButtonType aType);

		//- (BOOL)isOpaque;
		[Export ("isOpaque")]
		bool IsOpaque { get; }

		//- (void)setFont:(NSFont *)fontObj;
		[Export ("setFont:")]
		void SetFont (NSFont fontObj);

		//- (BOOL)isTransparent;
		[Export ("isTransparent")]
		bool IsTransparent { get; }

		//- (void)setTransparent:(BOOL)flag;
		[Export ("setTransparent:")]
		void SetTransparent (bool flag);

		//- (void)setPeriodicDelay:(float)delay interval:(float)interval;
		[Export ("setPeriodicDelay:interval:")]
		void SetPeriodicDelay (float delay, float interval);

		//- (void)getPeriodicDelay:(float *)delay interval:(float *)interval;
		[Export ("getPeriodicDelay:interval:")]
		void GetPeriodicDelay (float delay, float interval);

		//- (NSString *)keyEquivalent;
		[Export ("keyEquivalent")]
		string KeyEquivalent { get; set; }

		//- (NSUInteger)keyEquivalentModifierMask;
		[Export ("keyEquivalentModifierMask")]
		uint KeyEquivalentModifierMask { get; set; }

		//- (NSFont *)keyEquivalentFont;
		[Export ("keyEquivalentFont")]
		NSFont KeyEquivalentFont { get; set; }

		//- (void)setKeyEquivalentFont:(NSString *)fontName size:(CGFloat)fontSize;
		[Export ("setKeyEquivalentFont:size:")]
		void SetKeyEquivalentFont (string fontName, float fontSize);

		//- (void)performClick:(id)sender; 
		[Export ("performClick:")]
		void PerformClick (NSObject sender);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (void)drawImage:(NSImage*)image withFrame:(NSRect)frame inView:(NSView*)controlView;
		[Export ("drawImage:withFrame:inView:")]
		void DrawImage (NSImage image, RectangleF frame, NSView controlView);

		//- (NSRect)drawTitle:(NSAttributedString*)title withFrame:(NSRect)frame inView:(NSView*)controlView;
		[Export ("drawTitle:withFrame:inView:")]
		RectangleF DrawTitle (NSAttributedString title, RectangleF frame, NSView controlView);

		//- (void)drawBezelWithFrame:(NSRect)frame inView:(NSView*)controlView;
		[Export ("drawBezelWithFrame:inView:")]
		void DrawBezelWithFrame (RectangleF frame, NSView controlView);

//#endif
		//- (void)setAlternateTitleWithMnemonic:(NSString *)stringWithAmpersand;
		[Export ("setAlternateTitleWithMnemonic:")]
		void SetAlternateTitleWithMnemonic (string stringWithAmpersand);

		//- (NSUInteger)alternateMnemonicLocation;
		[Export ("alternateMnemonicLocation")]
		uint AlternateMnemonicLocation { get; set; }

		//- (NSString *)alternateMnemonic;
		[Export ("alternateMnemonic")]
		string AlternateMnemonic { get; }

		//- (void)setGradientType:(NSGradientType)type;
		[Export ("setGradientType:")]
		void SetGradientType (NSGradientType type);

		//- (BOOL)imageDimsWhenDisabled;
		[Export ("imageDimsWhenDisabled")]
		bool ImageDimsWhenDisabled { get; set; }

		//- (BOOL) showsBorderOnlyWhileMouseInside;
		[Export ("showsBorderOnlyWhileMouseInside")]
		bool ShowsBorderOnlyWhileMouseInside { get; set; }

		//- (void) mouseEntered:(NSEvent*)event;
		[Export ("mouseEntered:")]
		void MouseEntered (NSEvent event1);

		//- (void) mouseExited:(NSEvent*)event;
		[Export ("mouseExited:")]
		void MouseExited (NSEvent event1);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (NSColor*)backgroundColor;
		[Export ("backgroundColor")]
		NSColor BackgroundColor { get; set; }

//#endif
		//- (void)setAttributedTitle:(NSAttributedString *)obj;
		[Export ("setAttributedTitle:")]
		void SetAttributedTitle (NSAttributedString obj);

		//- (NSAttributedString *)attributedAlternateTitle;
		[Export ("attributedAlternateTitle")]
		NSAttributedString AttributedAlternateTitle { get; set; }

		//- (NSBezelStyle)bezelStyle;
		[Export ("bezelStyle")]
		NSBezelStyle BezelStyle { get; set; }

		//- (NSSound *)sound;
		[Export ("sound")]
		NSSound Sound { get; }

	}
}
