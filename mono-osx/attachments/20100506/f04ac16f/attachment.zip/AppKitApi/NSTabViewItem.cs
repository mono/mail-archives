using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSObject))]
	interface NSTabViewItem {

		//	- (id)initWithIdentifier:(id)identifier;
		[Export ("initWithIdentifier:")]
		IntPtr Constructor (NSObject identifier);

		//    	- (id)identifier;
		[Export ("identifier")]
		NSTabViewItem Identifier { get; }

		//- (id)view;
		[Export ("view")]
		NSTabViewItem View { get; }

		//- (id)initialFirstResponder;
		[Export ("initialFirstResponder")]
		IntPtr InitialFirstResponder { get; }

		//- (NSString *)label;
		[Export ("label")]
		string Label { get; set; }

		//- (NSColor *)color;
		[Export ("color")]
		NSColor Color { get; set; }

		//- (NSTabState)tabState;
		[Export ("tabState")]
		NSTabState TabState { get; }

		//- (NSTabView *)tabView;
		[Export ("tabView")]
		NSTabView TabView { get; }

		//    	- (void)setIdentifier:(id)identifier;
		[Export ("setIdentifier:")]
		void SetIdentifier (NSObject identifier);

		//- (void)setView:(NSView *)view;
		[Export ("setView:")]
		void SetView (NSView view);

		//- (void)setInitialFirstResponder:(NSView *)view;
		[Export ("setInitialFirstResponder:")]
		void SetInitialFirstResponder (NSView view);

		//	- (void)drawLabel:(BOOL)shouldTruncateLabel inRect:(NSRect)labelRect;
		[Export ("drawLabel:inRect:")]
		void DrawLabel (bool shouldTruncateLabel, RectangleF labelRect);

		//- (NSSize)sizeOfLabel:(BOOL)computeMin;
		[Export ("sizeOfLabel:")]
		NSSize SizeOfLabel (bool computeMin);

	}
}
