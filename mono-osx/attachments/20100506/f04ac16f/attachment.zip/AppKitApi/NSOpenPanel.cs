using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSSavePanel))]
	interface NSOpenPanel {

		//+ (NSOpenPanel *)openPanel;
		[Static, Export ("openPanel")]
		NSOpenPanel OpenPanel { get; }

		//- (NSArray *)URLs;
		[Export ("URLs")]
		NSArray Urls { get; }

		//- (NSArray *)filenames;
		[Export ("filenames")]
		NSArray Filenames { get; }

		//- (BOOL)resolvesAliases;
		[Export ("resolvesAliases")]
		bool ResolvesAliases { get; set; }

		//- (BOOL)canChooseDirectories;
		[Export ("canChooseDirectories")]
		bool CanChooseDirectories { get; set; }

		//- (BOOL)allowsMultipleSelection;
		[Export ("allowsMultipleSelection")]
		bool AllowsMultipleSelection { get; set; }

		//- (BOOL)canChooseFiles;
		[Export ("canChooseFiles")]
		bool CanChooseFiles { get; set; }

		//- (void)beginSheetForDirectory:(NSString *)path file:(NSString *)name types:(NSArray *)fileTypes modalForWindow:(NSWindow *)docWindow modalDelegate:(id)delegate didEndSelector:(SEL)didEndSelector contextInfo:(void *)contextInfo;
		[Export ("beginSheetForDirectory:file:types:modalForWindow:modalDelegate:didEndSelector:contextInfo:")]
		void BeginSheetForDirectoryFile (string path, string name, NSArray fileTypes, NSWindow docWindow, NSObject delegate1, Selector didEndSelector, IntPtr contextInfo);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//- (void)beginForDirectory:(NSString *)path file:(NSString *)name types:(NSArray *)fileTypes modelessDelegate:(id)delegate didEndSelector:(SEL)didEndSelector contextInfo:(void *)contextInfo;
		[Export ("beginForDirectory:file:types:modelessDelegate:didEndSelector:contextInfo:")]
		void BeginForDirectoryFile (string path, string name, NSArray fileTypes, NSObject delegate1, Selector didEndSelector, IntPtr contextInfo);

//#endif
		//- (NSInteger)runModalForDirectory:(NSString *)path file:(NSString *)name types:(NSArray *)fileTypes;
		[Export ("runModalForDirectory:file:types:")]
		int RunModalForDirectoryFile (string path, string name, NSArray fileTypes);

		//- (NSInteger)runModalForTypes:(NSArray *)fileTypes;
		[Export ("runModalForTypes:")]
		int RunModalForTypes (NSArray fileTypes);

	}
}
