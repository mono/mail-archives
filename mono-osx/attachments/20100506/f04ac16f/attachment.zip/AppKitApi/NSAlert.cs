using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSObject))]
	interface NSAlert {

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//+ (NSAlert *)alertWithError:(NSError *)error;
		[Static, Export ("alertWithError:")]
		NSAlert AlertWithError (NSError error);

//#endif
		////+ (NSAlert *)alertWithMessageText:(NSString *)message defaultButton:(NSString *)defaultButton alternateButton:(NSString *)alternateButton otherButton:(NSString *)otherButton informativeTextWithFormat:(NSString *)format, ...;
		//[Static, Export ("alertWithMessageText:defaultButton:alternateButton:otherButton:informativeTextWithFormat:")]
		//NSAlert AlertWithMessageText (string message, string defaultButton, string alternateButton, string otherButton, string format,);

		//- (NSString *)messageText;
		[Export ("messageText")]
		string MessageText { get; set; }

		//- (NSString *)informativeText;
		[Export ("informativeText")]
		string InformativeText { get; set; }

		//- (NSImage *)icon;
		[Export ("icon")]
		NSImage Icon { get; set; }

		//- (NSButton *)addButtonWithTitle:(NSString *)title;
		[Export ("addButtonWithTitle:")]
		NSButton AddButtonWithTitle (string title);

		//- (NSArray *)buttons;
		[Export ("buttons")]
		NSArray Buttons { get; }

		//- (BOOL)showsHelp;
		[Export ("showsHelp")]
		bool ShowsHelp { get; set; }

		//- (NSString *)helpAnchor;
		[Export ("helpAnchor")]
		string HelpAnchor { get; set; }

		//- (NSAlertStyle)alertStyle;
		[Export ("alertStyle")]
		NSAlertStyle AlertStyle { get; set; }

		//- (void)setDelegate:(id)delegate;
		[Export ("setDelegate:")]
		void SetDelegate (NSObject delegate1);

		//- (id)delegate;
		[Export ("delegate")]
		NSAlert Delegate { get; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (BOOL)showsSuppressionButton;
		[Export ("showsSuppressionButton")]
		bool ShowsSuppressionButton { get; set; }

		//- (NSButton *)suppressionButton;
		[Export ("suppressionButton")]
		NSButton SuppressionButton { get; }

		//- (NSView *)accessoryView;
		[Export ("accessoryView")]
		NSView AccessoryView { get; set; }

		//- (void)layout;
		[Export ("layout")]
		void Layout ();

//#endif
		//- (NSInteger)runModal;
		[Export ("runModal")]
		int RunModal { get; }

		//- (void)beginSheetModalForWindow:(NSWindow *)window modalDelegate:(id)delegate didEndSelector:(SEL)didEndSelector contextInfo:(void *)contextInfo;
		[Export ("beginSheetModalForWindow:modalDelegate:didEndSelector:contextInfo:")]
		void BeginSheetModalForWindow (NSWindow window, NSObject delegate1, Selector didEndSelector, IntPtr contextInfo);

		//- (id)window;
		[Export ("window")]
		NSAlert Window { get; }

	}
}
