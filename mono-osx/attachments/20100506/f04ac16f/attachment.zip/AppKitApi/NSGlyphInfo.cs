using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSObject))]
	interface NSGlyphInfo {

		//+ (NSGlyphInfo *)glyphInfoWithGlyphName:(NSString *)glyphName forFont:(NSFont *)font baseString:(NSString *)theString;
		[Static, Export ("glyphInfoWithGlyphName:forFont:baseString:")]
		NSGlyphInfo GlyphInfoWithGlyphName (string glyphName, NSFont font, string theString);

		//+ (NSGlyphInfo *)glyphInfoWithGlyph:(NSGlyph)glyph forFont:(NSFont *)font baseString:(NSString *)theString;
		[Static, Export ("glyphInfoWithGlyph:forFont:baseString:")]
		NSGlyphInfo GlyphInfoWithGlyph (uint glyph, NSFont font, string theString);

		//+ (NSGlyphInfo *)glyphInfoWithCharacterIdentifier:(NSUInteger)cid collection:(NSCharacterCollection)characterCollection baseString:(NSString *)theString;
		[Static, Export ("glyphInfoWithCharacterIdentifier:collection:baseString:")]
		NSGlyphInfo GlyphInfoWithCharacterIdentifier (uint cid, NSCharacterCollection characterCollection, string theString);

		//- (NSString *)glyphName;
		[Export ("glyphName")]
		string GlyphName { get; }

		//- (NSUInteger)characterIdentifier;
		[Export ("characterIdentifier")]
		uint CharacterIdentifier { get; }

		//- (NSCharacterCollection)characterCollection;
		[Export ("characterCollection")]
		NSCharacterCollection CharacterCollection { get; }

	}
}
