using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSObjectController))]
	interface NSArrayController {

		//- (void)rearrangeObjects;    
		[Export ("rearrangeObjects")]
		void RearrangeObjects ();

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (BOOL)automaticallyRearrangesObjects;
		[Export ("automaticallyRearrangesObjects")]
		bool AutomaticallyRearrangesObjects { get; set; }

		//- (NSArray *)automaticRearrangementKeyPaths;    
		[Export ("automaticRearrangementKeyPaths")]
		NSArray AutomaticRearrangementKeyPaths { get; }

		//- (void)didChangeArrangementCriteria;    
		[Export ("didChangeArrangementCriteria")]
		void DidChangeArrangementCriteria ();

//#endif
		//- (NSArray *)sortDescriptors;
		[Export ("sortDescriptors")]
		NSArray SortDescriptors { get; set; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (NSPredicate *)filterPredicate;
		[Export ("filterPredicate")]
		NSPredicate FilterPredicate { get; set; }

		//- (BOOL)clearsFilterPredicateOnInsertion;
		[Export ("clearsFilterPredicateOnInsertion")]
		bool ClearsFilterPredicateOnInsertion { get; set; }

//#endif
		//- (NSArray *)arrangeObjects:(NSArray *)objects;    
		[Export ("arrangeObjects:")]
		NSArray ArrangeObjects (NSArray objects);

		//- (id)arrangedObjects;     
		[Export ("arrangedObjects")]
		NSArrayController ArrangedObjects { get; }

		//- (BOOL)avoidsEmptySelection;
		[Export ("avoidsEmptySelection")]
		bool AvoidsEmptySelection { get; set; }

		//- (BOOL)preservesSelection;
		[Export ("preservesSelection")]
		bool PreservesSelection { get; set; }

		//- (BOOL)selectsInsertedObjects;
		[Export ("selectsInsertedObjects")]
		bool SelectsInsertedObjects { get; set; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (BOOL)alwaysUsesMultipleValuesMarker;
		[Export ("alwaysUsesMultipleValuesMarker")]
		bool AlwaysUsesMultipleValuesMarker { get; set; }

//#endif
		//- (BOOL)setSelectionIndexes:(NSIndexSet *)indexes;    
		[Export ("setSelectionIndexes:")]
		bool SetSelectionIndexes (NSIndexSet indexes);

		//- (NSIndexSet *)selectionIndexes;
		[Export ("selectionIndexes")]
		NSIndexSet SelectionIndexes { get; }

		//- (BOOL)setSelectionIndex:(NSUInteger)index;
		[Export ("setSelectionIndex:")]
		bool SetSelectionIndex (uint index);

		//- (NSUInteger)selectionIndex;
		[Export ("selectionIndex")]
		uint SelectionIndex { get; }

		//- (BOOL)addSelectionIndexes:(NSIndexSet *)indexes;
		[Export ("addSelectionIndexes:")]
		bool AddSelectionIndexes (NSIndexSet indexes);

		//- (BOOL)removeSelectionIndexes:(NSIndexSet *)indexes;
		[Export ("removeSelectionIndexes:")]
		bool RemoveSelectionIndexes (NSIndexSet indexes);

		//- (BOOL)setSelectedObjects:(NSArray *)objects;
		[Export ("setSelectedObjects:")]
		bool SetSelectedObjects (NSArray objects);

		//- (NSArray *)selectedObjects;
		[Export ("selectedObjects")]
		NSArray SelectedObjects { get; }

		//- (BOOL)addSelectedObjects:(NSArray *)objects;
		[Export ("addSelectedObjects:")]
		bool AddSelectedObjects (NSArray objects);

		//- (BOOL)removeSelectedObjects:(NSArray *)objects;
		[Export ("removeSelectedObjects:")]
		bool RemoveSelectedObjects (NSArray objects);

		//- (void)add:(id)sender;    
		[Export ("add:")]
		void Add (NSObject sender);

		//- (void)remove:(id)sender;    
		[Export ("remove:")]
		void Remove (NSObject sender);

		//- (void)insert:(id)sender;
		[Export ("insert:")]
		void Insert (NSObject sender);

		//- (BOOL)canInsert;    
		[Export ("canInsert")]
		bool CanInsert { get; }

		//- (void)selectNext:(id)sender;
		[Export ("selectNext:")]
		void SelectNext (NSObject sender);

		//- (void)selectPrevious:(id)sender;
		[Export ("selectPrevious:")]
		void SelectPrevious (NSObject sender);

		//- (BOOL)canSelectNext;
		[Export ("canSelectNext")]
		bool CanSelectNext { get; }

		//- (BOOL)canSelectPrevious;
		[Export ("canSelectPrevious")]
		bool CanSelectPrevious { get; }

		//- (void)addObject:(id)object;    
		[Export ("addObject:")]
		void AddObject (NSObject object1);

		//- (void)addObjects:(NSArray *)objects;
		[Export ("addObjects:")]
		void AddObjects (NSArray objects);

		//- (void)insertObject:(id)object atArrangedObjectIndex:(NSUInteger)index;    
		[Export ("insertObject:atArrangedObjectIndex:")]
		void InsertObject (NSObject object1, uint index);

		//- (void)insertObjects:(NSArray *)objects atArrangedObjectIndexes:(NSIndexSet *)indexes;
		[Export ("insertObjects:atArrangedObjectIndexes:")]
		void InsertObjects (NSArray objects, NSIndexSet indexes);

		//- (void)removeObjectAtArrangedObjectIndex:(NSUInteger)index;    
		[Export ("removeObjectAtArrangedObjectIndex:")]
		void RemoveObjectAtArrangedObjectIndex (uint index);

		//- (void)removeObjectsAtArrangedObjectIndexes:(NSIndexSet *)indexes;
		[Export ("removeObjectsAtArrangedObjectIndexes:")]
		void RemoveObjectsAtArrangedObjectIndexes (NSIndexSet indexes);

		//- (void)removeObject:(id)object;    
		[Export ("removeObject:")]
		void RemoveObject (NSObject object1);

		//- (void)removeObjects:(NSArray *)objects;
		[Export ("removeObjects:")]
		void RemoveObjects (NSArray objects);

	}
}
