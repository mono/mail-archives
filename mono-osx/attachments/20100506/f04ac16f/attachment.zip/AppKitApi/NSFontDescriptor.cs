using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSObject))]
	interface NSFontDescriptor {

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (NSString *)postscriptName;
		[Export ("postscriptName")]
		string PostscriptName { get; }

		//- (CGFloat)pointSize;
		[Export ("pointSize")]
		float PointSize { get; }

		//- (NSAffineTransform *)matrix;
		[Export ("matrix")]
		NSAffineTransform Matrix { get; }

		//- (NSFontSymbolicTraits)symbolicTraits;
		[Export ("symbolicTraits")]
		NSFontSymbolicTraits SymbolicTraits { get; }

		//- (id)objectForKey:(NSString *)anAttribute;
		[Export ("objectForKey:")]
		NSFontDescriptor ObjectForKey (string anAttribute);

//#endif 
		//- (NSDictionary *)fontAttributes;
		[Export ("fontAttributes")]
		NSDictionary FontAttributes { get; }

		//+ (NSFontDescriptor *)fontDescriptorWithFontAttributes:(NSDictionary *)attributes;
		[Static, Export ("fontDescriptorWithFontAttributes:")]
		NSFontDescriptor FontDescriptorWithFontAttributes (NSDictionary attributes);

		//+ (NSFontDescriptor *)fontDescriptorWithName:(NSString *)fontName size:(CGFloat)size;
		[Static, Export ("fontDescriptorWithName:size:")]
		NSFontDescriptor FontDescriptorWithName (string fontName, float size);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//+ (NSFontDescriptor *)fontDescriptorWithName:(NSString *)fontName matrix:(NSAffineTransform *)matrix;
		[Static, Export ("fontDescriptorWithName:matrix:")]
		NSFontDescriptor FontDescriptorWithName (string fontName, NSAffineTransform matrix);

//#endif 
		//- (id)initWithFontAttributes:(NSDictionary *)attributes;
		[Export ("initWithFontAttributes:")]
		IntPtr Constructor (NSDictionary attributes);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (NSArray *)matchingFontDescriptorsWithMandatoryKeys:(NSSet *)mandatoryKeys;
		[Export ("matchingFontDescriptorsWithMandatoryKeys:")]
		NSArray MatchingFontDescriptorsWithMandatoryKeys (NSSet mandatoryKeys);

		//- (NSFontDescriptor *)matchingFontDescriptorWithMandatoryKeys:(NSSet *)mandatoryKeys AVAILABLE_MAC_OS_X_VERSION_10_5_AND_LATER;
		[Export ("matchingFontDescriptorWithMandatoryKeys:")]
		NSFontDescriptor MatchingFontDescriptorWithMandatoryKeys (NSSet mandatoryKeys);

		//- (NSFontDescriptor *)fontDescriptorByAddingAttributes:(NSDictionary *)attributes; 
		[Export ("fontDescriptorByAddingAttributes:")]
		NSFontDescriptor FontDescriptorByAddingAttributes (NSDictionary attributes);

		//- (NSFontDescriptor *)fontDescriptorWithSymbolicTraits:(NSFontSymbolicTraits)symbolicTraits;
		[Export ("fontDescriptorWithSymbolicTraits:")]
		NSFontDescriptor FontDescriptorWithSymbolicTraits (NSFontSymbolicTraits symbolicTraits);

		//- (NSFontDescriptor *)fontDescriptorWithSize:(CGFloat)newPointSize;
		[Export ("fontDescriptorWithSize:")]
		NSFontDescriptor FontDescriptorWithSize (float newPointSize);

		//- (NSFontDescriptor *)fontDescriptorWithMatrix:(NSAffineTransform *)matrix;
		[Export ("fontDescriptorWithMatrix:")]
		NSFontDescriptor FontDescriptorWithMatrix (NSAffineTransform matrix);

		//- (NSFontDescriptor *)fontDescriptorWithFace:(NSString *)newFace;
		[Export ("fontDescriptorWithFace:")]
		NSFontDescriptor FontDescriptorWithFace (string newFace);

		//- (NSFontDescriptor *)fontDescriptorWithFamily:(NSString *)newFamily;
		[Export ("fontDescriptorWithFamily:")]
		NSFontDescriptor FontDescriptorWithFamily (string newFamily);

//#endif 
	}
}
