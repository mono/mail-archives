using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSControl))]
	interface NSPathControl {

		//- (NSURL *)URL;
		[Export ("URL")]
		NSUrl Url { get; set; }

		//- (SEL)doubleAction;
		[Export ("doubleAction")]
		Selector DoubleAction { get; set; }

		//- (NSPathStyle)pathStyle;
		[Export ("pathStyle")]
		NSPathStyle PathStyle { get; set; }

		//- (NSPathComponentCell *)clickedPathComponentCell;
		[Export ("clickedPathComponentCell")]
		NSPathComponentCell ClickedPathComponentCell { get; }

		//- (NSArray *)pathComponentCells;
		[Export ("pathComponentCells")]
		NSArray PathComponentCells { get; set; }

		//- (NSColor *)backgroundColor;
		[Export ("backgroundColor")]
		NSColor BackgroundColor { get; set; }

		//- (id)delegate;
		[Export ("delegate")]
		NSPathControl Delegate { get; }

		//- (void)setDelegate:(id)delegate;
		[Export ("setDelegate:")]
		void SetDelegate (NSObject delegate1);

		//- (void)setDraggingSourceOperationMask:(NSDragOperation)mask forLocal:(BOOL)isLocal;
		[Export ("setDraggingSourceOperationMask:forLocal:")]
		void SetDraggingSourceOperationMask (NSDragOperation mask, bool isLocal);

	}
}
