using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSMutableAttributedString))]
	interface NSTextStorage {

//#if __LP64__
//#endif
		//   - (void)addLayoutManager:(NSLayoutManager *)obj;     
		[Export ("addLayoutManager:")]
		void AddLayoutManager (NSLayoutManager obj);

		//- (void)removeLayoutManager:(NSLayoutManager *)obj;
		[Export ("removeLayoutManager:")]
		void RemoveLayoutManager (NSLayoutManager obj);

		//- (NSArray *)layoutManagers;
		[Export ("layoutManagers")]
		NSArray LayoutManagers { get; }

		//- (void)edited:(NSUInteger)editedMask range:(NSRange)range changeInLength:(NSInteger)delta;
		[Export ("edited:range:changeInLength:")]
		void Edited (uint editedMask, NSRange range, int delta);

		//- (void)processEditing;
		[Export ("processEditing")]
		void ProcessEditing ();

		//- (void)invalidateAttributesInRange:(NSRange)range;
		[Export ("invalidateAttributesInRange:")]
		void InvalidateAttributesInRange (NSRange range);

		//- (void)ensureAttributesAreFixedInRange:(NSRange)range;
		[Export ("ensureAttributesAreFixedInRange:")]
		void EnsureAttributesAreFixedInRange (NSRange range);

		//- (BOOL)fixesAttributesLazily;
		[Export ("fixesAttributesLazily")]
		bool FixesAttributesLazily { get; }

		//       - (NSUInteger)editedMask;
		[Export ("editedMask")]
		uint EditedMask { get; }

		//- (NSRange)editedRange;
		[Export ("editedRange")]
		NSRange EditedRange { get; }

		//- (NSInteger)changeInLength;
		[Export ("changeInLength")]
		int ChangeInLength { get; }

		//- (void)setDelegate:(id)delegate;
		[Export ("setDelegate:")]
		void SetDelegate (NSObject delegate1);

		//- (id)delegate;
		[Export ("delegate")]
		NSTextStorage Delegate { get; }

		//- (NSArray *)attributeRuns;
		[Export ("attributeRuns")]
		NSArray AttributeRuns { get; set; }

		//- (NSArray *)paragraphs;
		[Export ("paragraphs")]
		NSArray Paragraphs { get; set; }

		//- (NSArray *)words;
		[Export ("words")]
		NSArray Words { get; set; }

		//- (NSArray *)characters;
		[Export ("characters")]
		NSArray Characters { get; set; }

		//- (NSFont *)font;
		[Export ("font")]
		NSFont Font { get; set; }

		//- (NSColor *)foregroundColor;
		[Export ("foregroundColor")]
		NSColor ForegroundColor { get; set; }

	}
}
