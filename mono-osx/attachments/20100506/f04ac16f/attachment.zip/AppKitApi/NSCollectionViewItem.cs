using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSObject))]
	interface NSCollectionViewItem {

		//- (NSCollectionView *)collectionView;
		[Export ("collectionView")]
		NSCollectionView CollectionView { get; }

		//- (void)setRepresentedObject:(id)object;
		[Export ("setRepresentedObject:")]
		void SetRepresentedObject (NSObject object1);

		//- (id)representedObject;
		[Export ("representedObject")]
		NSCollectionViewItem RepresentedObject { get; }

		//- (NSView *)view;
		[Export ("view")]
		NSView View { get; set; }

		//- (void)setSelected:(BOOL)flag;
		[Export ("setSelected:")]
		void SetSelected (bool flag);

		//- (BOOL)isSelected;
		[Export ("isSelected")]
		bool IsSelected { get; }

	}
}
