using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSObject))]
	interface NSColorList {

//#if __LP64__
//#endif
		//+ (NSArray *)availableColorLists;			
		[Static, Export ("availableColorLists")]
		NSArray AvailableColorLists { get; }

		//+ (NSColorList *)colorListNamed:(NSString *)name;
		[Static, Export ("colorListNamed:")]
		NSColorList ColorListNamed (string name);

		//- (id)initWithName:(NSString *)name;			
		[Export ("initWithName:")]
		IntPtr Constructor (string name);

		//- (id)initWithName:(NSString *)name fromFile:(NSString *)path;	
		[Export ("initWithName:fromFile:")]
		IntPtr Constructor (string name, string path);

		//- (NSString *)name;
		[Export ("name")]
		string Name { get; }

		//- (void)setColor:(NSColor *)color forKey:(NSString *)key;
		[Export ("setColor:forKey:")]
		void SetColor (NSColor color, string key);

		//- (void)insertColor:(NSColor *)color key:(NSString *)key atIndex:(NSUInteger)loc;
		[Export ("insertColor:key:atIndex:")]
		void InsertColor (NSColor color, string key, uint loc);

		//- (void)removeColorWithKey:(NSString *)key;
		[Export ("removeColorWithKey:")]
		void RemoveColorWithKey (string key);

		//- (NSColor *)colorWithKey:(NSString *)key;
		[Export ("colorWithKey:")]
		NSColor ColorWithKey (string key);

		//- (NSArray *)allKeys;
		[Export ("allKeys")]
		NSArray AllKeys { get; }

		//- (BOOL)isEditable;
		[Export ("isEditable")]
		bool IsEditable { get; }

		//- (BOOL)writeToFile:(NSString *)path;	
		[Export ("writeToFile:")]
		bool WriteToFile (string path);

		//- (void)removeFile;
		[Export ("removeFile")]
		void RemoveFile ();

	}
}
