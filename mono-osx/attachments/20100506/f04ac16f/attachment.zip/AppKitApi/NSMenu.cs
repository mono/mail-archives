using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSObject))]
	interface NSMenu {

		//+ (void)setMenuZone:(NSZone *)aZone;
		[Static, Export ("setMenuZone:")]
		void SetMenuZone (NSZone aZone);

		//+ (NSZone *)menuZone;
		[Static, Export ("menuZone")]
		NSZone MenuZone { get; }

		//+ (void)popUpContextMenu:(NSMenu*)menu withEvent:(NSEvent*)event forView:(NSView*)view;
		[Static, Export ("popUpContextMenu:withEvent:forView:")]
		void PopUpContextMenu (NSMenu menu, NSEvent event1, NSView view);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//+ (void)popUpContextMenu:(NSMenu*)menu withEvent:(NSEvent*)event forView:(NSView*)view withFont:(NSFont*)font;
		[Static, Export ("popUpContextMenu:withEvent:forView:withFont:")]
		void PopUpContextMenu (NSMenu menu, NSEvent event1, NSView view, NSFont font);

//#endif
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_2
		//+ (void)setMenuBarVisible:(BOOL)visible;
		[Static, Export ("setMenuBarVisible:")]
		void SetMenuBarVisible (bool visible);

		//+ (BOOL)menuBarVisible;
		[Static, Export ("menuBarVisible")]
		bool MenuBarVisible { get; }

//#endif
		//- (id)initWithTitle:(NSString *)aTitle;
		[Export ("initWithTitle:")]
		IntPtr Constructor (string aTitle);

		//- (NSString *)title;
		[Export ("title")]
		string Title { get; set; }

		//- (NSMenu *)supermenu;
		[Export ("supermenu")]
		NSMenu Supermenu { get; set; }

		//    - (void)insertItem:(NSMenuItem *)newItem atIndex:(NSInteger)index;
		[Export ("insertItem:atIndex:")]
		void InsertItem (NSMenuItem newItem, int index);

		//- (void)addItem:(NSMenuItem *)newItem;
		[Export ("addItem:")]
		void AddItem (NSMenuItem newItem);

		//- (NSMenuItem *)insertItemWithTitle:(NSString *)aString action:(SEL)aSelector keyEquivalent:(NSString *)charCode atIndex:(NSInteger)index;
		[Export ("insertItemWithTitle:action:keyEquivalent:atIndex:")]
		NSMenuItem InsertItemWithTitle (string aString, Selector aSelector, string charCode, int index);

		//- (NSMenuItem *)addItemWithTitle:(NSString *)aString action:(SEL)aSelector keyEquivalent:(NSString *)charCode;
		[Export ("addItemWithTitle:action:keyEquivalent:")]
		NSMenuItem AddItemWithTitle (string aString, Selector aSelector, string charCode);

		//- (void)removeItemAtIndex:(NSInteger)index;
		[Export ("removeItemAtIndex:")]
		void RemoveItemAtIndex (int index);

		//- (void)removeItem:(NSMenuItem *)item;
		[Export ("removeItem:")]
		void RemoveItem (NSMenuItem item);

		//- (void)setSubmenu:(NSMenu *)aMenu forItem:(NSMenuItem *)anItem;
		[Export ("setSubmenu:forItem:")]
		void SetSubmenu (NSMenu aMenu, NSMenuItem anItem);

		//- (NSArray *)itemArray;
		[Export ("itemArray")]
		NSArray ItemArray { get; }

		//- (NSInteger)numberOfItems;
		[Export ("numberOfItems")]
		int NumberOfItems { get; }

		//- (NSInteger)indexOfItem:(NSMenuItem *)index;
		[Export ("indexOfItem:")]
		int IndexOfItem (NSMenuItem index);

		//- (NSInteger)indexOfItemWithTitle:(NSString *)aTitle;
		[Export ("indexOfItemWithTitle:")]
		int IndexOfItemWithTitle (string aTitle);

		//- (NSInteger)indexOfItemWithTag:(NSInteger)aTag;
		[Export ("indexOfItemWithTag:")]
		int IndexOfItemWithTag (int aTag);

		//- (NSInteger)indexOfItemWithRepresentedObject:(id)object;
		[Export ("indexOfItemWithRepresentedObject:")]
		int IndexOfItemWithRepresentedObject (NSObject object1);

		//- (NSInteger)indexOfItemWithSubmenu:(NSMenu *)submenu;
		[Export ("indexOfItemWithSubmenu:")]
		int IndexOfItemWithSubmenu (NSMenu submenu);

		//- (NSInteger)indexOfItemWithTarget:(id)target andAction:(SEL)actionSelector;
		[Export ("indexOfItemWithTarget:andAction:")]
		int IndexOfItemWithTarget (NSObject target, Selector actionSelector);

		//- (NSMenuItem *)itemAtIndex:(NSInteger)index;
		[Export ("itemAtIndex:")]
		NSMenuItem ItemAtIndex (int index);

		//- (NSMenuItem *)itemWithTitle:(NSString *)aTitle;
		[Export ("itemWithTitle:")]
		NSMenuItem ItemWithTitle (string aTitle);

		//- (NSMenuItem *)itemWithTag:(NSInteger)tag;
		[Export ("itemWithTag:")]
		NSMenuItem ItemWithTag (int tag);

		//- (BOOL)autoenablesItems;
		[Export ("autoenablesItems")]
		bool AutoenablesItems { get; set; }

		//- (BOOL)performKeyEquivalent:(NSEvent *)theEvent;
		[Export ("performKeyEquivalent:")]
		bool PerformKeyEquivalent (NSEvent theEvent);

		//- (void)update;
		[Export ("update")]
		void Update ();

		//- (BOOL)menuChangedMessagesEnabled;
		[Export ("menuChangedMessagesEnabled")]
		bool MenuChangedMessagesEnabled { get; set; }

		//- (void)itemChanged:(NSMenuItem *)item;
		[Export ("itemChanged:")]
		void ItemChanged (NSMenuItem item);

		//- (void)helpRequested:(NSEvent *)eventPtr;
		[Export ("helpRequested:")]
		void HelpRequested (NSEvent eventPtr);

		//- (void)setMenuRepresentation:(id)menuRep;
		[Export ("setMenuRepresentation:")]
		void SetMenuRepresentation (NSObject menuRep);

		//- (id)menuRepresentation;
		[Export ("menuRepresentation")]
		NSMenu MenuRepresentation { get; }

		//- (void)setContextMenuRepresentation:(id)menuRep;
		[Export ("setContextMenuRepresentation:")]
		void SetContextMenuRepresentation (NSObject menuRep);

		//- (id)contextMenuRepresentation;
		[Export ("contextMenuRepresentation")]
		NSMenu ContextMenuRepresentation { get; }

		//- (void)setTearOffMenuRepresentation:(id)menuRep;
		[Export ("setTearOffMenuRepresentation:")]
		void SetTearOffMenuRepresentation (NSObject menuRep);

		//- (id)tearOffMenuRepresentation;
		[Export ("tearOffMenuRepresentation")]
		NSMenu TearOffMenuRepresentation { get; }

		//- (BOOL)isTornOff;
		[Export ("isTornOff")]
		bool IsTornOff { get; }

		//    - (NSMenu *)attachedMenu;
		[Export ("attachedMenu")]
		NSMenu AttachedMenu { get; }

		//- (BOOL)isAttached;
		[Export ("isAttached")]
		bool IsAttached { get; }

		//- (void)sizeToFit;
		[Export ("sizeToFit")]
		void SizeToFit ();

		//- (NSPoint)locationForSubmenu:(NSMenu *)aSubmenu;
		[Export ("locationForSubmenu:")]
		PointF LocationForSubmenu (NSMenu aSubmenu);

		//- (void)performActionForItemAtIndex:(NSInteger)index;
		[Export ("performActionForItemAtIndex:")]
		void PerformActionForItemAtIndex (int index);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//- (void)setDelegate:(id)anObject;
		[Export ("setDelegate:")]
		void SetDelegate (NSObject anObject);

		//- (id)delegate;
		[Export ("delegate")]
		NSMenu Delegate { get; }

//#endif
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (CGFloat)menuBarHeight;
		[Export ("menuBarHeight")]
		float MenuBarHeight { get; }

//#endif
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (void)cancelTracking;
		[Export ("cancelTracking")]
		void CancelTracking ();

		//- (NSMenuItem *)highlightedItem;
		[Export ("highlightedItem")]
		NSMenuItem HighlightedItem { get; }

		//- (BOOL)showsStateColumn;
		[Export ("showsStateColumn")]
		bool ShowsStateColumn { get; set; }

//#endif
	}
}
