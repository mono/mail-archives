using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSObject))]
	interface NSMenuItem {

		//+ (void)setUsesUserKeyEquivalents:(BOOL)flag;
		[Static, Export ("setUsesUserKeyEquivalents:")]
		void SetUsesUserKeyEquivalents (bool flag);

		//+ (BOOL)usesUserKeyEquivalents;
		[Static, Export ("usesUserKeyEquivalents")]
		bool UsesUserKeyEquivalents { get; }

		//+ (NSMenuItem *)separatorItem;
		[Static, Export ("separatorItem")]
		NSMenuItem SeparatorItem { get; }

		//- (id)initWithTitle:(NSString *)aString action:(SEL)aSelector keyEquivalent:(NSString *)charCode;
		[Export ("initWithTitle:action:keyEquivalent:")]
		IntPtr Constructor (string aString, Selector aSelector, string charCode);

		//- (NSMenu *)menu;
		[Export ("menu")]
		NSMenu Menu { get; set; }

		//    - (BOOL)hasSubmenu;
		[Export ("hasSubmenu")]
		bool HasSubmenu { get; }

		//- (NSMenu *)submenu;
		[Export ("submenu")]
		NSMenu Submenu { get; set; }

		//- (NSString *)title;
		[Export ("title")]
		string Title { get; set; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//- (NSAttributedString*)attributedTitle;
		[Export ("attributedTitle")]
		NSAttributedString AttributedTitle { get; set; }

//#endif
		//- (BOOL)isSeparatorItem;
		[Export ("isSeparatorItem")]
		bool IsSeparatorItem { get; }

		//- (NSString *)keyEquivalent;
		[Export ("keyEquivalent")]
		string KeyEquivalent { get; set; }

		//- (NSUInteger)keyEquivalentModifierMask;
		[Export ("keyEquivalentModifierMask")]
		uint KeyEquivalentModifierMask { get; set; }

		//- (NSString *)userKeyEquivalent;
		[Export ("userKeyEquivalent")]
		string UserKeyEquivalent { get; }

		//- (NSUInteger)mnemonicLocation;
		[Export ("mnemonicLocation")]
		uint MnemonicLocation { get; set; }

		//- (NSString *)mnemonic;
		[Export ("mnemonic")]
		string Mnemonic { get; }

		//- (void)setTitleWithMnemonic:(NSString *)stringWithAmpersand;
		[Export ("setTitleWithMnemonic:")]
		void SetTitleWithMnemonic (string stringWithAmpersand);

		//- (NSImage *)image;
		[Export ("image")]
		NSImage Image { get; set; }

		//- (NSInteger)state;
		[Export ("state")]
		int State { get; set; }

		//- (NSImage *)onStateImage;
		[Export ("onStateImage")]
		NSImage OnStateImage { get; set; }

		//- (NSImage *)offStateImage;
		[Export ("offStateImage")]
		NSImage OffStateImage { get; set; }

		//- (NSImage *)mixedStateImage;
		[Export ("mixedStateImage")]
		NSImage MixedStateImage { get; set; }

		//- (void)setEnabled:(BOOL)flag;
		[Export ("setEnabled:")]
		void SetEnabled (bool flag);

		//- (BOOL)isEnabled;
		[Export ("isEnabled")]
		bool IsEnabled { get; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//- (void) setAlternate:(BOOL)isAlternate;
		[Export ("setAlternate:")]
		void SetAlternate (bool isAlternate);

		//- (BOOL) isAlternate;
		[Export ("isAlternate")]
		bool IsAlternate { get; }

		//- (NSInteger) indentationLevel;
		[Export ("indentationLevel")]
		int IndentationLevel { get; set; }

//#endif
		//- (void)setTarget:(id)anObject;
		[Export ("setTarget:")]
		void SetTarget (NSObject anObject);

		//- (id)target;
		[Export ("target")]
		NSMenuItem Target { get; }

		//- (SEL)action;
		[Export ("action")]
		Selector Action { get; set; }

		//- (NSInteger)tag;
		[Export ("tag")]
		int Tag { get; set; }

		//- (void)setRepresentedObject:(id)anObject;
		[Export ("setRepresentedObject:")]
		void SetRepresentedObject (NSObject anObject);

		//- (id)representedObject;
		[Export ("representedObject")]
		NSMenuItem RepresentedObject { get; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (NSView *)view;
		[Export ("view")]
		NSView View { get; set; }

		//- (BOOL)isHighlighted;
		[Export ("isHighlighted")]
		bool IsHighlighted { get; }

		//- (void)setHidden:(BOOL)hidden;
		[Export ("setHidden:")]
		void SetHidden (bool hidden);

		//- (BOOL)isHidden;
		[Export ("isHidden")]
		bool IsHidden { get; }

		//- (BOOL)isHiddenOrHasHiddenAncestor;
		[Export ("isHiddenOrHasHiddenAncestor")]
		bool IsHiddenOrHasHiddenAncestor { get; }

//#endif
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//- (NSString*)toolTip;
		[Export ("toolTip")]
		string ToolTip { get; set; }

//#endif
	}
}
