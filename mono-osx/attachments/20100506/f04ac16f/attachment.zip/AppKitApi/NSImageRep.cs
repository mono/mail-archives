using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSObject))]
	interface NSImageRep {

		//- (BOOL)draw;
		[Export ("draw")]
		bool Draw { get; }

		//- (BOOL)drawAtPoint:(NSPoint)point;
		[Export ("drawAtPoint:")]
		bool DrawAtPoint (PointF point);

		//- (BOOL)drawInRect:(NSRect)rect;
		[Export ("drawInRect:")]
		bool DrawInRect (RectangleF rect);

		//- (NSSize)size;
		[Export ("size")]
		NSSize Size { get; set; }

		//- (void)setAlpha:(BOOL)flag;
		[Export ("setAlpha:")]
		void SetAlpha (bool flag);

		//- (BOOL)hasAlpha;
		[Export ("hasAlpha")]
		bool HasAlpha { get; }

		////- (void)setOpaque:(BOOL)flag;
		//[Export ("setOpaque:")]
		//void SetOpaque (bool flag);

		//- (BOOL)isOpaque;
		[Export ("isOpaque")]
		bool IsOpaque { [Bind("isOpaque")] get; set; }

		//- (NSString *)colorSpaceName;
		[Export ("colorSpaceName")]
		string ColorSpaceName { get; set; }

		//- (NSInteger)bitsPerSample;
		[Export ("bitsPerSample")]
		int BitsPerSample { get; set; }

		//- (NSInteger)pixelsWide;
		[Export ("pixelsWide")]
		int PixelsWide { get; set; }

		//- (NSInteger)pixelsHigh;
		[Export ("pixelsHigh")]
		int PixelsHigh { get; set; }

		//+ (void)registerImageRepClass:(Class)imageRepClass;
		[Static, Export ("registerImageRepClass:")]
		void RegisterImageRepClass (Class imageRepClass);

		//+ (void)unregisterImageRepClass:(Class)imageRepClass;
		[Static, Export ("unregisterImageRepClass:")]
		void UnregisterImageRepClass (Class imageRepClass);

		//+ (NSArray *)registeredImageRepClasses;
		[Static, Export ("registeredImageRepClasses")]
		NSArray RegisteredImageRepClasses { get; }

		//+ (Class)imageRepClassForFileType:(NSString *)type;
		[Static, Export ("imageRepClassForFileType:")]
		Class ImageRepClassForFileType (string type);

		//+ (Class)imageRepClassForPasteboardType:(NSString *)type;
		[Static, Export ("imageRepClassForPasteboardType:")]
		Class ImageRepClassForPasteboardType (string type);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//+ (Class)imageRepClassForType:(NSString *)type;
		[Static, Export ("imageRepClassForType:")]
		Class ImageRepClassForType (string type);

//#endif
		//+ (Class)imageRepClassForData:(NSData *)data;
		[Static, Export ("imageRepClassForData:")]
		Class ImageRepClassForData (NSData data);

		//	+ (BOOL)canInitWithData:(NSData *)data;
		[Export ("canInitWithData:")]
		bool CanInitWithData (NSData data);

		//+ (NSArray *)imageUnfilteredFileTypes;
		[Static, Export ("imageUnfilteredFileTypes")]
		NSArray ImageUnfilteredFileTypes { get; }

		//+ (NSArray *)imageUnfilteredPasteboardTypes;
		[Static, Export ("imageUnfilteredPasteboardTypes")]
		NSArray ImageUnfilteredPasteboardTypes { get; }

		//+ (NSArray *)imageFileTypes;
		[Static, Export ("imageFileTypes")]
		NSArray ImageFileTypes { get; }

		//+ (NSArray *)imagePasteboardTypes;
		[Static, Export ("imagePasteboardTypes")]
		NSArray ImagePasteboardTypes { get; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//+ (NSArray *)imageUnfilteredTypes;
		[Static, Export ("imageUnfilteredTypes")]
		NSArray ImageUnfilteredTypes { get; }

		//+ (NSArray *)imageTypes;
		[Static, Export ("imageTypes")]
		NSArray ImageTypes { get; }

//#endif
		//+ (BOOL)canInitWithPasteboard:(NSPasteboard *)pasteboard;
		[Static, Export ("canInitWithPasteboard:")]
		bool CanInitWithPasteboard (NSPasteboard pasteboard);

		//+ (NSArray *)imageRepsWithContentsOfFile:(NSString *)filename;
		[Static, Export ("imageRepsWithContentsOfFile:")]
		NSArray ImageRepsWithContentsOfFile (string filename);

		//+ (id)imageRepWithContentsOfFile:(NSString *)filename;
		[Static, Export ("imageRepWithContentsOfFile:")]
		NSImageRep ImageRepWithContentsOfFile (string filename);

		//+ (NSArray *)imageRepsWithContentsOfURL:(NSURL *)url;
		[Static, Export ("imageRepsWithContentsOfURL:")]
		NSArray ImageRepsWithContentsOfUrl (NSUrl url);

		//+ (id)imageRepWithContentsOfURL:(NSURL *)url;
		[Static, Export ("imageRepWithContentsOfURL:")]
		NSImageRep ImageRepWithContentsOfUrl (NSUrl url);

		//+ (NSArray *)imageRepsWithPasteboard:(NSPasteboard *)pasteboard;
		[Static, Export ("imageRepsWithPasteboard:")]
		NSArray ImageRepsWithPasteboard (NSPasteboard pasteboard);

		//+ (id)imageRepWithPasteboard:(NSPasteboard *)pasteboard;
		[Static, Export ("imageRepWithPasteboard:")]
		NSImageRep ImageRepWithPasteboard (NSPasteboard pasteboard);

	}
}
