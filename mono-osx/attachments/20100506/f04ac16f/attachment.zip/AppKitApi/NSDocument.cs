using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSObject))]
	interface NSDocument {

		//#pragma mark *** Initialization ***- (id)init;
		[Export ("init")]
		IntPtr Init { get; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//#pragma mark *** Creation ***- (id)initWithType:(NSString *)typeName error:(NSError **)outError;
		[Export ("initWithType:error:")]
		IntPtr Constructor (string typeName, NSError outError);

//#endif
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//#pragma mark *** Opening ***- (id)initWithContentsOfURL:(NSURL *)absoluteURL ofType:(NSString *)typeName error:(NSError **)outError;
		[Export ("initWithContentsOfURL:ofType:error:")]
		IntPtr Constructor (NSUrl absoluteURL, string typeName, NSError outError);

//#endif
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//#pragma mark *** Reopening after Autosaving ***- (id)initForURL:(NSURL *)absoluteDocumentURL withContentsOfURL:(NSURL *)absoluteDocumentContentsURL ofType:(NSString *)typeName error:(NSError **)outError;
		[Export ("initForURL:withContentsOfURL:ofType:error:")]
		IntPtr Constructor (NSUrl absoluteDocumentURL, NSUrl absoluteDocumentContentsURL, string typeName, NSError outError);

//#endif
		//- (NSString *)fileType;
		[Export ("fileType")]
		string FileType { get; set; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (NSURL *)fileURL;
		[Export ("fileURL")]
		NSUrl FileUrl { get; set; }

		//- (NSDate *)fileModificationDate;
		[Export ("fileModificationDate")]
		NSDate FileModificationDate { get; set; }

//#endif
		//#pragma mark *** Reverting ***- (IBAction)revertDocumentToSaved:(id)sender;
		[Export ("revertDocumentToSaved:")]
		void RevertDocumentToSaved (NSObject sender);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (BOOL)revertToContentsOfURL:(NSURL *)absoluteURL ofType:(NSString *)typeName error:(NSError **)outError;
		[Export ("revertToContentsOfURL:ofType:error:")]
		bool RevertToContentsOfUrl (NSUrl absoluteURL, string typeName, NSError outError);

//#endif
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//#pragma mark *** Simple Reading and Writing ***- (BOOL)readFromURL:(NSURL *)absoluteURL ofType:(NSString *)typeName error:(NSError **)outError;
		[Export ("readFromURL:ofType:error:")]
		bool ReadFromUrl (NSUrl absoluteURL, string typeName, out NSError outError);

		//- (BOOL)readFromFileWrapper:(NSFileWrapper *)fileWrapper ofType:(NSString *)typeName error:(NSError **)outError;
		[Export ("readFromFileWrapper:ofType:error:")]
		bool ReadFromFileWrapper (NSFileWrapper fileWrapper, string typeName, NSError outError);

		//- (BOOL)readFromData:(NSData *)data ofType:(NSString *)typeName error:(NSError **)outError;
		[Export ("readFromData:ofType:error:")]
		bool ReadFromData (NSData data, string typeName, NSError outError);

		//- (BOOL)writeToURL:(NSURL *)absoluteURL ofType:(NSString *)typeName error:(NSError **)outError;
		[Export ("writeToURL:ofType:error:")]
		bool WriteToUrl (NSUrl absoluteURL, string typeName, NSError outError);

		//- (NSFileWrapper *)fileWrapperOfType:(NSString *)typeName error:(NSError **)outError;
		[Export ("fileWrapperOfType:error:")]
		NSFileWrapper FileWrapperOfType (string typeName, NSError outError);

		//- (NSData *)dataOfType:(NSString *)typeName error:(NSError **)outError;
		[Export ("dataOfType:error:")]
		NSData DataOfType (string typeName, NSError outError);

//#endif
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//#pragma mark *** Advanced Writing ***- (BOOL)writeSafelyToURL:(NSURL *)absoluteURL ofType:(NSString *)typeName forSaveOperation:(NSSaveOperationType)saveOperation error:(NSError **)outError;
		[Export ("writeSafelyToURL:ofType:forSaveOperation:error:")]
		bool WriteSafelyToUrl (NSUrl absoluteURL, string typeName, NSSaveOperationType saveOperation, NSError outError);

		//- (BOOL)writeToURL:(NSURL *)absoluteURL ofType:(NSString *)typeName forSaveOperation:(NSSaveOperationType)saveOperation originalContentsURL:(NSURL *)absoluteOriginalContentsURL error:(NSError **)outError;
		[Export ("writeToURL:ofType:forSaveOperation:originalContentsURL:error:")]
		bool WriteToUrl (NSUrl absoluteURL, string typeName, NSSaveOperationType saveOperation, NSUrl absoluteOriginalContentsURL, NSError outError);

		//- (NSDictionary *)fileAttributesToWriteToURL:(NSURL *)absoluteURL ofType:(NSString *)typeName forSaveOperation:(NSSaveOperationType)saveOperation originalContentsURL:(NSURL *)absoluteOriginalContentsURL error:(NSError **)outError;
		[Export ("fileAttributesToWriteToURL:ofType:forSaveOperation:originalContentsURL:error:")]
		NSDictionary FileAttributesToWriteToUrl (NSUrl absoluteURL, string typeName, NSSaveOperationType saveOperation, NSUrl absoluteOriginalContentsURL, NSError outError);

//#endif
		//- (BOOL)keepBackupFile;
		[Export ("keepBackupFile")]
		bool KeepBackupFile { get; }

		//#pragma mark *** Saving ***- (IBAction)saveDocument:(id)sender;
		[Export ("saveDocument:")]
		void SaveDocument (NSObject sender);

		//- (IBAction)saveDocumentAs:(id)sender;
		[Export ("saveDocumentAs:")]
		void SaveDocumentAs (NSObject sender);

		//- (IBAction)saveDocumentTo:(id)sender;
		[Export ("saveDocumentTo:")]
		void SaveDocumentTo (NSObject sender);

		//- (void)saveDocumentWithDelegate:(id)delegate didSaveSelector:(SEL)didSaveSelector contextInfo:(void *)contextInfo;
		[Export ("saveDocumentWithDelegate:didSaveSelector:contextInfo:")]
		void SaveDocumentWithDelegate (NSObject delegate1, Selector didSaveSelector, IntPtr contextInfo);

		//- (void)runModalSavePanelForSaveOperation:(NSSaveOperationType)saveOperation delegate:(id)delegate didSaveSelector:(SEL)didSaveSelector contextInfo:(void *)contextInfo;
		[Export ("runModalSavePanelForSaveOperation:delegate:didSaveSelector:contextInfo:")]
		void RunModalSavePanelForSaveOperation (NSSaveOperationType saveOperation, NSObject delegate1, Selector didSaveSelector, IntPtr contextInfo);

		//- (BOOL)shouldRunSavePanelWithAccessoryView;
		[Export ("shouldRunSavePanelWithAccessoryView")]
		bool ShouldRunSavePanelWithAccessoryView { get; }

		//- (BOOL)prepareSavePanel:(NSSavePanel *)savePanel;
		[Export ("prepareSavePanel:")]
		bool PrepareSavePanel (NSSavePanel savePanel);

		//- (BOOL)fileNameExtensionWasHiddenInLastRunSavePanel;
		[Export ("fileNameExtensionWasHiddenInLastRunSavePanel")]
		bool FileNameExtensionWasHiddenInLastRunSavePanel { get; }

		//- (NSString *)fileTypeFromLastRunSavePanel;
		[Export ("fileTypeFromLastRunSavePanel")]
		string FileTypeFromLastRunSavePanel { get; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (void)saveToURL:(NSURL *)absoluteURL ofType:(NSString *)typeName forSaveOperation:(NSSaveOperationType)saveOperation delegate:(id)delegate didSaveSelector:(SEL)didSaveSelector contextInfo:(void *)contextInfo;
		[Export ("saveToURL:ofType:forSaveOperation:delegate:didSaveSelector:contextInfo:")]
		void SaveToUrl (NSUrl absoluteURL, string typeName, NSSaveOperationType saveOperation, NSObject delegate1, Selector didSaveSelector, IntPtr contextInfo);

		//- (BOOL)saveToURL:(NSURL *)absoluteURL ofType:(NSString *)typeName forSaveOperation:(NSSaveOperationType)saveOperation error:(NSError **)outError;
		[Export ("saveToURL:ofType:forSaveOperation:error:")]
		bool SaveToUrl (NSUrl absoluteURL, string typeName, NSSaveOperationType saveOperation, NSError outError);

//#endif
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//#pragma mark *** Autosaving ***- (BOOL)hasUnautosavedChanges;
		[Export ("hasUnautosavedChanges")]
		bool HasUnautosavedChanges { get; }

		//- (void)autosaveDocumentWithDelegate:(id)delegate didAutosaveSelector:(SEL)didAutosaveSelector contextInfo:(void *)contextInfo;
		[Export ("autosaveDocumentWithDelegate:didAutosaveSelector:contextInfo:")]
		void AutosaveDocumentWithDelegate (NSObject delegate1, Selector didAutosaveSelector, IntPtr contextInfo);

		//- (NSString *)autosavingFileType;
		[Export ("autosavingFileType")]
		string AutosavingFileType { get; }

		//- (NSURL *)autosavedContentsFileURL;
		[Export ("autosavedContentsFileURL")]
		NSUrl AutosavedContentsFileUrl { get; set; }

//#endif
		//#pragma mark *** Closing ***- (void)canCloseDocumentWithDelegate:(id)delegate shouldCloseSelector:(SEL)shouldCloseSelector contextInfo:(void *)contextInfo;
		[Export ("canCloseDocumentWithDelegate:shouldCloseSelector:contextInfo:")]
		void CanCloseDocumentWithDelegate (NSObject delegate1, Selector shouldCloseSelector, IntPtr contextInfo);

		//- (void)close;
		[Export ("close")]
		void Close ();

		//#pragma mark *** Printing ***- (IBAction)runPageLayout:(id)sender;
		[Export ("runPageLayout:")]
		IBAction RunPageLayout (NSObject sender);

		//- (void)runModalPageLayoutWithPrintInfo:(NSPrintInfo *)printInfo delegate:(id)delegate didRunSelector:(SEL)didRunSelector contextInfo:(void *)contextInfo;
		[Export ("runModalPageLayoutWithPrintInfo:delegate:didRunSelector:contextInfo:")]
		void RunModalPageLayoutWithPrintInfo (NSPrintInfo printInfo, NSObject delegate1, Selector didRunSelector, IntPtr contextInfo);

		//- (BOOL)preparePageLayout:(NSPageLayout *)pageLayout;
		[Export ("preparePageLayout:")]
		bool PreparePageLayout (NSPageLayout pageLayout);

		//- (BOOL)shouldChangePrintInfo:(NSPrintInfo *)newPrintInfo;
		[Export ("shouldChangePrintInfo:")]
		bool ShouldChangePrintInfo (NSPrintInfo newPrintInfo);

		//- (NSPrintInfo *)printInfo;
		[Export ("printInfo")]
		NSPrintInfo PrintInfo { get; set; }

		//- (IBAction)printDocument:(id)sender;
		[Export ("printDocument:")]
		IBAction PrintDocument (NSObject sender);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (void)printDocumentWithSettings:(NSDictionary *)printSettings showPrintPanel:(BOOL)showPrintPanel delegate:(id)delegate didPrintSelector:(SEL)didPrintSelector contextInfo:(void *)contextInfo;
		[Export ("printDocumentWithSettings:showPrintPanel:delegate:didPrintSelector:contextInfo:")]
		void PrintDocumentWithSettings (NSDictionary printSettings, bool showPrintPanel, NSObject delegate1, Selector didPrintSelector, IntPtr contextInfo);

		//- (NSPrintOperation *)printOperationWithSettings:(NSDictionary *)printSettings error:(NSError **)outError;
		[Export ("printOperationWithSettings:error:")]
		NSPrintOperation PrintOperationWithSettings (NSDictionary printSettings, NSError outError);

//#endif
		//- (void)runModalPrintOperation:(NSPrintOperation *)printOperation delegate:(id)delegate didRunSelector:(SEL)didRunSelector contextInfo:(void *)contextInfo;
		[Export ("runModalPrintOperation:delegate:didRunSelector:contextInfo:")]
		void RunModalPrintOperation (NSPrintOperation printOperation, NSObject delegate1, Selector didRunSelector, IntPtr contextInfo);

		//#pragma mark *** Change Management ***- (BOOL)isDocumentEdited;
		[Export ("isDocumentEdited")]
		bool IsDocumentEdited { get; }

		//- (void)updateChangeCount:(NSDocumentChangeType)change;
		[Export ("updateChangeCount:")]
		void UpdateChangeCount (NSDocumentChangeType change);

		//- (NSUndoManager *)undoManager;
		[Export ("undoManager")]
		NSUndoManager UndoManager { get; set; }

		//- (BOOL)hasUndoManager;
		[Export ("hasUndoManager")]
		bool HasUndoManager { get; set; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//#pragma mark *** Error Presentation ***- (void)presentError:(NSError *)error modalForWindow:(NSWindow *)window delegate:(id)delegate didPresentSelector:(SEL)didPresentSelector contextInfo:(void *)contextInfo;
		[Export ("presentError:modalForWindow:delegate:didPresentSelector:contextInfo:")]
		void PresentError (NSError error, NSWindow window, NSObject delegate1, Selector didPresentSelector, IntPtr contextInfo);

		//- (BOOL)presentError:(NSError *)error;
		[Export ("presentError:")]
		bool PresentError (NSError error);

		//- (NSError *)willPresentError:(NSError *)error;
		[Export ("willPresentError:")]
		NSError WillPresentError (NSError error);

//#endif
		//#pragma mark *** Windows and Window Controllers ***- (void)makeWindowControllers;
		[Export ("makeWindowControllers")]
		void MakeWindowControllers ();

		//- (NSString *)windowNibName;
		[Export ("windowNibName")]
		string WindowNibName { get; }

		//- (void)windowControllerWillLoadNib:(NSWindowController *)windowController;
		[Export ("windowControllerWillLoadNib:")]
		void WindowControllerWillLoadNib (NSWindowController windowController);

		//- (void)windowControllerDidLoadNib:(NSWindowController *)windowController;
		[Export ("windowControllerDidLoadNib:")]
		void WindowControllerDidLoadNib (NSWindowController windowController);

		//- (void)setWindow:(NSWindow *)window;
		[Export ("setWindow:")]
		void SetWindow (NSWindow window);

		//- (void)addWindowController:(NSWindowController *)windowController;
		[Export ("addWindowController:")]
		void AddWindowController (NSWindowController windowController);

		//- (void)removeWindowController:(NSWindowController *)windowController;
		[Export ("removeWindowController:")]
		void RemoveWindowController (NSWindowController windowController);

		//- (void)showWindows;
		[Export ("showWindows")]
		void ShowWindows ();

		//- (NSArray *)windowControllers;
		[Export ("windowControllers")]
		NSArray WindowControllers { get; }

		//- (void)shouldCloseWindowController:(NSWindowController *)windowController delegate:(id)delegate shouldCloseSelector:(SEL)shouldCloseSelector contextInfo:(void *)contextInfo;
		[Export ("shouldCloseWindowController:delegate:shouldCloseSelector:contextInfo:")]
		void ShouldCloseWindowController (NSWindowController windowController, NSObject delegate1, Selector shouldCloseSelector, IntPtr contextInfo);

		//- (NSString *)displayName;
		[Export ("displayName")]
		string DisplayName { get; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_1
		//- (NSWindow *)windowForSheet;
		[Export ("windowForSheet")]
		NSWindow WindowForSheet { get; }

//#endif
		//#pragma mark *** Types ***+ (NSArray *)readableTypes;
		[Export ("readableTypes")]
		NSArray ReadableTypes { get; }

		//+ (NSArray *)writableTypes;
		[Static, Export ("writableTypes")]
		NSArray WritableTypes { get; }

		//+ (BOOL)isNativeType:(NSString *)type;
		[Static, Export ("isNativeType:")]
		bool IsNativeType (string type);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (NSArray *)writableTypesForSaveOperation:(NSSaveOperationType)saveOperation;
		[Export ("writableTypesForSaveOperation:")]
		NSArray WritableTypesForSaveOperation (NSSaveOperationType saveOperation);

//#endif
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (NSString *)fileNameExtensionForType:(NSString *)typeName saveOperation:(NSSaveOperationType)saveOperation;
		[Export ("fileNameExtensionForType:saveOperation:")]
		string FileNameExtensionForType (string typeName, NSSaveOperationType saveOperation);

//#endif
		//#pragma mark *** Menu Item Validation ***- (BOOL)validateUserInterfaceItem:(id <NSValidatedUserInterfaceItem>)anItem;
		[Export ("validateUserInterfaceItem:")]
		bool ValidateUserInterfaceItem (NSObject anItem);

		////#pragma mark *** Backward Compatibility ***- (NSData *)dataRepresentationOfType:(NSString *)type;
		//[Export ("dataRepresentationOfType:")]
		//NSData DataRepresentationOfType (string type);

		////- (NSDictionary *)fileAttributesToWriteToFile:(NSString *)fullDocumentPath ofType:(NSString *)documentTypeName saveOperation:(NSSaveOperationType)saveOperationType;
		//[Export ("fileAttributesToWriteToFile:ofType:saveOperation:")]
		//NSDictionary FileAttributesToWriteToFileOfType (string fullDocumentPath, string documentTypeName, NSSaveOperationType saveOperationType);

		////- (NSString *)fileName;
		//[Export ("fileName")]
		//string FileName { get; set; }

		////- (NSFileWrapper *)fileWrapperRepresentationOfType:(NSString *)type;
		//[Export ("fileWrapperRepresentationOfType:")]
		//NSFileWrapper FileWrapperRepresentationOfType (string type);

		////- (id)initWithContentsOfFile:(NSString *)absolutePath ofType:(NSString *)typeName;
		//[Export ("initWithContentsOfFile:ofType:")]
		//IntPtr Constructor (string absolutePath, string typeName);

		////- (id)initWithContentsOfURL:(NSURL *)absoluteURL ofType:(NSString *)typeName;
		//[Export ("initWithContentsOfURL:ofType:")]
		//IntPtr Constructor (NSUrl absoluteURL, string typeName);

		////- (BOOL)loadDataRepresentation:(NSData *)data ofType:(NSString *)type;
		//[Export ("loadDataRepresentation:ofType:")]
		//bool LoadDataRepresentationOfType (NSData data, string type);

		////- (BOOL)loadFileWrapperRepresentation:(NSFileWrapper *)wrapper ofType:(NSString *)type;
		//[Export ("loadFileWrapperRepresentation:ofType:")]
		//bool LoadFileWrapperRepresentationOfType (NSFileWrapper wrapper, string type);

		////- (void)printShowingPrintPanel:(BOOL)flag;
		//[Export ("printShowingPrintPanel:")]
		//void PrintShowingPrintPanel (bool flag);

		////- (BOOL)readFromFile:(NSString *)fileName ofType:(NSString *)type;
		//[Export ("readFromFile:ofType:")]
		//bool ReadFromFileOfType (string fileName, string type);

		////- (BOOL)readFromURL:(NSURL *)url ofType:(NSString *)type;
		//[Export ("readFromURL:ofType:")]
		//bool ReadFromURLOfType (NSUrl url, string type);

		////- (BOOL)revertToSavedFromFile:(NSString *)fileName ofType:(NSString *)type;
		//[Export ("revertToSavedFromFile:ofType:")]
		//bool RevertToSavedFromFileOfType (string fileName, string type);

		////- (BOOL)revertToSavedFromURL:(NSURL *)url ofType:(NSString *)type;
		//[Export ("revertToSavedFromURL:ofType:")]
		//bool RevertToSavedFromURLOfType (NSUrl url, string type);

		////- (NSInteger)runModalPageLayoutWithPrintInfo:(NSPrintInfo *)printInfo;
		//[Export ("runModalPageLayoutWithPrintInfo:")]
		//int RunModalPageLayoutWithPrintInfo (NSPrintInfo printInfo);

		////- (void)saveToFile:(NSString *)fileName saveOperation:(NSSaveOperationType)saveOperation delegate:(id)delegate didSaveSelector:(SEL)didSaveSelector contextInfo:(void *)contextInfo;
		//[Export ("saveToFile:saveOperation:delegate:didSaveSelector:contextInfo:")]
		//void SaveToFileSaveOperation (string fileName, NSSaveOperationType saveOperation, NSObject delegate1, Selector didSaveSelector, IntPtr contextInfo);

		////- (BOOL)writeToFile:(NSString *)fileName ofType:(NSString *)type;
		//[Export ("writeToFile:ofType:")]
		//bool WriteToFileOfType (string fileName, string type);

		////- (BOOL)writeToFile:(NSString *)fullDocumentPath ofType:(NSString *)documentTypeName originalFile:(NSString *)fullOriginalDocumentPath saveOperation:(NSSaveOperationType)saveOperationType;
		//[Export ("writeToFile:ofType:originalFile:saveOperation:")]
		//bool WriteToFileOfType (string fullDocumentPath, string documentTypeName, string fullOriginalDocumentPath, NSSaveOperationType saveOperationType);

		////- (BOOL)writeToURL:(NSURL *)url ofType:(NSString *)type;
		//[Export ("writeToURL:ofType:")]
		//bool WriteToURLOfType (NSUrl url, string type);

		////- (BOOL)writeWithBackupToFile:(NSString *)fullDocumentPath ofType:(NSString *)documentTypeName saveOperation:(NSSaveOperationType)saveOperationType;
		//[Export ("writeWithBackupToFile:ofType:saveOperation:")]
		//bool WriteWithBackupToFileOfType (string fullDocumentPath, string documentTypeName, NSSaveOperationType saveOperationType);

		//- (NSString *)lastComponentOfFileName;
		[Export ("lastComponentOfFileName")]
		string LastComponentOfFileName { get; set; }

		//- (id)handleSaveScriptCommand:(NSScriptCommand *)command;
		[Export ("handleSaveScriptCommand:")]
		NSDocument HandleSaveScriptCommand (NSScriptCommand command);

		//- (id)handleCloseScriptCommand:(NSCloseCommand *)command;
		[Export ("handleCloseScriptCommand:")]
		NSDocument HandleCloseScriptCommand (NSCloseCommand command);

		//- (id)handlePrintScriptCommand:(NSScriptCommand *)command;
		[Export ("handlePrintScriptCommand:")]
		NSDocument HandlePrintScriptCommand (NSScriptCommand command);

		//- (NSScriptObjectSpecifier *)objectSpecifier;
		[Export ("objectSpecifier")]
		NSScriptObjectSpecifier ObjectSpecifier { get; }

	}
}
