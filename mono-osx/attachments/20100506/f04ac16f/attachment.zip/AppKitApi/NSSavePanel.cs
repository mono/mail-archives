using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSPanel))]
	interface NSSavePanel {

		//+ (NSSavePanel *)savePanel;
		[Static, Export ("savePanel")]
		NSSavePanel SavePanel { get; }

		//- (NSURL *)URL;
		[Export ("URL")]
		NSUrl Url { get; }

		//- (NSString *)filename;
		[Export ("filename")]
		string Filename { get; }

		//- (NSString *)directory;
		[Export ("directory")]
		string Directory { get; set; }

		//- (NSString *)requiredFileType;
		[Export ("requiredFileType")]
		string RequiredFileType { get; set; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//- (NSArray *)allowedFileTypes;
		[Export ("allowedFileTypes")]
		NSArray AllowedFileTypes { get; set; }

		//- (BOOL)allowsOtherFileTypes;
		[Export ("allowsOtherFileTypes")]
		bool AllowsOtherFileTypes { get; set; }

//#endif
		//- (NSView *)accessoryView;
		[Export ("accessoryView")]
		NSView AccessoryView { get; set; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//- (id)delegate;
		[Export ("delegate")]
		NSSavePanel Delegate { get; }

//#endif
		//- (void)setDelegate:(id)delegate;
		[Export ("setDelegate:")]
		void SetDelegate (NSObject delegate1);

		//- (BOOL)isExpanded;
		[Export ("isExpanded")]
		bool IsExpanded { get; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//- (BOOL)canCreateDirectories;
		[Export ("canCreateDirectories")]
		bool CanCreateDirectories { get; set; }

//#endif
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//- (BOOL)canSelectHiddenExtension;
		[Export ("canSelectHiddenExtension")]
		bool CanSelectHiddenExtension { get; set; }

//#endif
		//- (BOOL)isExtensionHidden;
		[Export ("isExtensionHidden")]
		bool IsExtensionHidden { get; }

		//- (void)setExtensionHidden:(BOOL)flag;
		[Export ("setExtensionHidden:")]
		void SetExtensionHidden (bool flag);

		//- (BOOL)treatsFilePackagesAsDirectories;
		[Export ("treatsFilePackagesAsDirectories")]
		bool TreatsFilePackagesAsDirectories { get; set; }

		//- (NSString *)prompt;
		[Export ("prompt")]
		string Prompt { get; set; }

		//- (NSString *)title;
		[Export ("title")]
		string Title { get; set; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//- (NSString *)nameFieldLabel;
		[Export ("nameFieldLabel")]
		string NameFieldLabel { get; set; }

//#endif
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//- (NSString *)message;
		[Export ("message")]
		string Message { get; set; }

//#endif
		//- (void)validateVisibleColumns;
		[Export ("validateVisibleColumns")]
		void ValidateVisibleColumns ();

		//- (IBAction)selectText:(id)sender;
		[Export ("selectText:")]
		void SelectText (NSObject sender);

		//- (IBAction)ok:(id)sender;
		[Export ("ok:")]
		void Ok (NSObject sender);

		//- (IBAction)cancel:(id)sender;
		[Export ("cancel:")]
		void Cancel (NSObject sender);

		//- (void)beginSheetForDirectory:(NSString *)path file:(NSString *)name modalForWindow:(NSWindow *)docWindow modalDelegate:(id)delegate didEndSelector:(SEL)didEndSelector contextInfo:(void *)contextInfo;
		[Export ("beginSheetForDirectory:file:modalForWindow:modalDelegate:didEndSelector:contextInfo:")]
		void BeginSheetForDirectoryFile (string path, string name, NSWindow docWindow, NSObject delegate1, Selector didEndSelector, IntPtr contextInfo);

		//- (NSInteger)runModalForDirectory:(NSString *)path file:(NSString *)name;
		[Export ("runModalForDirectory:file:")]
		int RunModalForDirectoryFile (string path, string name);

		//- (NSInteger)runModal;
		[Export ("runModal")]
		int RunModal { get; }

	}
}
