using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{
	interface NSAttributedString {

		//- (NSDictionary *)fontAttributesInRange:(NSRange)range;
		[Export ("fontAttributesInRange:")]
		NSDictionary FontAttributesInRange (NSRange range);

		//- (NSDictionary *)rulerAttributesInRange:(NSRange)range;
		[Export ("rulerAttributesInRange:")]
		NSDictionary RulerAttributesInRange (NSRange range);

		//- (BOOL)containsAttachments;
		[Export ("containsAttachments")]
		bool ContainsAttachments { get; }

		//- (NSUInteger)lineBreakBeforeIndex:(NSUInteger)location withinRange:(NSRange)aRange;
		[Export ("lineBreakBeforeIndex:withinRange:")]
		uint LineBreakBeforeIndexWithinRange (uint location, NSRange aRange);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//- (NSUInteger)lineBreakByHyphenatingBeforeIndex:(NSUInteger)location withinRange:(NSRange)aRange;
		[Export ("lineBreakByHyphenatingBeforeIndex:withinRange:")]
		uint LineBreakByHyphenatingBeforeIndexWithinRange (uint location, NSRange aRange);

//#endif 
		//- (NSRange)doubleClickAtIndex:(NSUInteger)location;
		[Export ("doubleClickAtIndex:")]
		NSRange DoubleClickAtIndex (uint location);

		//- (NSUInteger)nextWordFromIndex:(NSUInteger)location forward:(BOOL)isForward;
		[Export ("nextWordFromIndex:forward:")]
		uint NextWordFromIndexForward (uint location, bool isForward);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (NSURL *)URLAtIndex:(NSUInteger)location effectiveRange:(NSRangePointer)effectiveRange;
		[Export ("URLAtIndex:effectiveRange:")]
		NSUrl URLAtIndexEffectiveRange (uint location, NSRangePointer effectiveRange);

//#endif 
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//+ (NSArray *)textTypes;
		[Static, Export ("textTypes")]
		NSArray TextTypes { get; }

		//+ (NSArray *)textUnfilteredTypes;
		[Static, Export ("textUnfilteredTypes")]
		NSArray TextUnfilteredTypes { get; }

//#endif 
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (NSRange)rangeOfTextBlock:(NSTextBlock *)block atIndex:(NSUInteger)location;
		[Export ("rangeOfTextBlock:atIndex:")]
		NSRange RangeOfTextBlockAtIndex (NSTextBlock block, uint location);

		//- (NSRange)rangeOfTextTable:(NSTextTable *)table atIndex:(NSUInteger)location;
		[Export ("rangeOfTextTable:atIndex:")]
		NSRange RangeOfTextTableAtIndex (NSTextTable table, uint location);

		//- (NSRange)rangeOfTextList:(NSTextList *)list atIndex:(NSUInteger)location;
		[Export ("rangeOfTextList:atIndex:")]
		NSRange RangeOfTextListAtIndex (NSTextList list, uint location);

		//- (NSInteger)itemNumberInTextList:(NSTextList *)list atIndex:(NSUInteger)location;
		[Export ("itemNumberInTextList:atIndex:")]
		int ItemNumberInTextListAtIndex (NSTextList list, uint location);

//#endif 
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (id)initWithURL:(NSURL *)url options:(NSDictionary *)options documentAttributes:(NSDictionary **)dict error:(NSError **)error;
		[Export ("initWithURL:options:documentAttributes:error:")]
		IntPtr Constructor (NSUrl url, NSDictionary options, NSDictionary dict, NSError error);

		//- (id)initWithData:(NSData *)data options:(NSDictionary *)options documentAttributes:(NSDictionary **)dict error:(NSError **)error;
		[Export ("initWithData:options:documentAttributes:error:")]
		IntPtr Constructor (NSData data, NSDictionary options, NSDictionary dict, NSError error);

//#endif 
		//- (id)initWithPath:(NSString *)path documentAttributes:(NSDictionary **)dict;
		[Export ("initWithPath:documentAttributes:")]
		IntPtr Constructor (string path, NSDictionary dict);

		//- (id)initWithURL:(NSURL *)url documentAttributes:(NSDictionary **)dict;
		[Export ("initWithURL:documentAttributes:")]
		IntPtr Constructor (NSUrl url, NSDictionary dict);

		//- (id)initWithRTF:(NSData *)data documentAttributes:(NSDictionary **)dict;
		[Export ("initWithRTF:documentAttributes:")]
		IntPtr Constructor (NSData data, NSDictionary dict);

		////- (id)initWithRTFD:(NSData *)data documentAttributes:(NSDictionary **)dict;
		//[Export ("initWithRTFD:documentAttributes:")]
		//IntPtr Constructor (NSData data, NSDictionary dict);

		////- (id)initWithHTML:(NSData *)data documentAttributes:(NSDictionary **)dict;
		//[Export ("initWithHTML:documentAttributes:")]
		//IntPtr Constructor (NSData data, NSDictionary dict);

		//- (id)initWithHTML:(NSData *)data baseURL:(NSURL *)base documentAttributes:(NSDictionary **)dict;
		[Export ("initWithHTML:baseURL:documentAttributes:")]
		IntPtr Constructor (NSData data, NSUrl base1, NSDictionary dict);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		////- (id)initWithDocFormat:(NSData *)data documentAttributes:(NSDictionary **)dict;
		//[Export ("initWithDocFormat:documentAttributes:")]
		//IntPtr Constructor (NSData data, NSDictionary dict);

		//- (id)initWithHTML:(NSData *)data options:(NSDictionary *)options documentAttributes:(NSDictionary **)dict;
		[Export ("initWithHTML:options:documentAttributes:")]
		IntPtr Constructor (NSData data, NSDictionary options, NSDictionary dict);

//#endif 
		//- (id)initWithRTFDFileWrapper:(NSFileWrapper *)wrapper documentAttributes:(NSDictionary **)dict;
		[Export ("initWithRTFDFileWrapper:documentAttributes:")]
		IntPtr Constructor (NSFileWrapper wrapper, NSDictionary dict);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (NSData *)dataFromRange:(NSRange)range documentAttributes:(NSDictionary *)dict error:(NSError **)error;
		[Export ("dataFromRange:documentAttributes:error:")]
		NSData DataFromRangeDocumentAttributes (NSRange range, NSDictionary dict, NSError error);

		//- (NSFileWrapper *)fileWrapperFromRange:(NSRange)range documentAttributes:(NSDictionary *)dict error:(NSError **)error;
		[Export ("fileWrapperFromRange:documentAttributes:error:")]
		NSFileWrapper FileWrapperFromRangeDocumentAttributes (NSRange range, NSDictionary dict, NSError error);

//#endif 
		//- (NSData *)RTFFromRange:(NSRange)range documentAttributes:(NSDictionary *)dict;
		[Export ("RTFFromRange:documentAttributes:")]
		NSData RTFFromRangeDocumentAttributes (NSRange range, NSDictionary dict);

		//- (NSData *)RTFDFromRange:(NSRange)range documentAttributes:(NSDictionary *)dict;
		[Export ("RTFDFromRange:documentAttributes:")]
		NSData RTFDFromRangeDocumentAttributes (NSRange range, NSDictionary dict);

		//- (NSFileWrapper *)RTFDFileWrapperFromRange:(NSRange)range documentAttributes:(NSDictionary *)dict;
		[Export ("RTFDFileWrapperFromRange:documentAttributes:")]
		NSFileWrapper RTFDFileWrapperFromRangeDocumentAttributes (NSRange range, NSDictionary dict);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//- (NSData *)docFormatFromRange:(NSRange)range documentAttributes:(NSDictionary *)dict;
		[Export ("docFormatFromRange:documentAttributes:")]
		NSData DocFormatFromRangeDocumentAttributes (NSRange range, NSDictionary dict);

//#endif 
		////+ (NSArray *)textFileTypes;
		//[Static, Export ("textFileTypes")]
		//NSArray TextFileTypes { get; }

		////+ (NSArray *)textPasteboardTypes;
		//[Static, Export ("textPasteboardTypes")]
		//NSArray TextPasteboardTypes { get; }

		////+ (NSArray *)textUnfilteredFileTypes;
		//[Static, Export ("textUnfilteredFileTypes")]
		//NSArray TextUnfilteredFileTypes { get; }

		////+ (NSArray *)textUnfilteredPasteboardTypes;
		//[Static, Export ("textUnfilteredPasteboardTypes")]
		//NSArray TextUnfilteredPasteboardTypes { get; }

		//- (NSSize)size;
		[Export ("size")]
		NSSize Size { get; }

		//- (void)drawAtPoint:(NSPoint)point;
		[Export ("drawAtPoint:")]
		void DrawAtPoint (PointF point);

		//- (void)drawInRect:(NSRect)rect;
		[Export ("drawInRect:")]
		void DrawInRect (RectangleF rect);

		//- (NSRect)boundingRectWithSize:(NSSize)size options:(NSStringDrawingOptions)options;
		[Export ("boundingRectWithSize:options:")]
		RectangleF BoundingRectWithSizeOptions (NSSize size, NSStringDrawingOptions options);

		//+ (NSAttributedString *)attributedStringWithAttachment:(NSTextAttachment *)attachment;
		[Static, Export ("attributedStringWithAttachment:")]
		NSAttributedString AttributedStringWithAttachment (NSTextAttachment attachment);

	}
}
