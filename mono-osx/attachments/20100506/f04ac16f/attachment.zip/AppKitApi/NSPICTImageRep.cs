using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSImageRep))]
	interface NSPICTImageRep {

//#if !__LP64__
//#endif
		//+ (id)imageRepWithData:(NSData*)pictData;
		[Static, Export ("imageRepWithData:")]
		NSPICTImageRep ImageRepWithData (NSData pictData);

		//- (id)initWithData:(NSData*)pictData;
		[Export ("initWithData:")]
		IntPtr Constructor (NSData pictData);

		//- (NSData*) PICTRepresentation;
		[Export ("PICTRepresentation")]
		NSData PICTRepresentation { get; }

		//- (NSRect)  boundingBox;
		[Export ("boundingBox")]
		RectangleF BoundingBox { get; }

	}
}
