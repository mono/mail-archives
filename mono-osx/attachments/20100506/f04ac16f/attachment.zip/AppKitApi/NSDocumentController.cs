using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSObject))]
	interface NSDocumentController {

		//#pragma mark *** The Shared Document Controller ***+ (id)sharedDocumentController;
		[Export ("sharedDocumentController")]
		NSDocumentController SharedDocumentController { get; }

		//- (id)init;
		[Export ("init")]
		IntPtr Init { get; }

		//#pragma mark *** Currently Open Documents ***- (NSArray *)documents;
		[Export ("documents")]
		NSArray Documents { get; }

		//- (id)currentDocument;
		[Export ("currentDocument")]
		NSDocumentController CurrentDocument { get; }

		//- (NSString *)currentDirectory;
		[Export ("currentDirectory")]
		string CurrentDirectory { get; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (id)documentForURL:(NSURL *)absoluteURL;
		[Export ("documentForURL:")]
		NSDocumentController DocumentForUrl (NSUrl absoluteURL);

//#endif
		//- (id)documentForWindow:(NSWindow *)window;
		[Export ("documentForWindow:")]
		NSDocumentController DocumentForWindow (NSWindow window);

		//- (void)addDocument:(NSDocument *)document;
		[Export ("addDocument:")]
		void AddDocument (NSDocument document);

		//- (void)removeDocument:(NSDocument *)document;
		[Export ("removeDocument:")]
		void RemoveDocument (NSDocument document);

		//#pragma mark *** Document Creation ***- (IBAction)newDocument:(id)sender;
		[Export ("newDocument:")]
		void NewDocument (NSObject sender);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (id)openUntitledDocumentAndDisplay:(BOOL)displayDocument error:(NSError **)outError;
		[Export ("openUntitledDocumentAndDisplay:error:")]
		NSDocumentController OpenUntitledDocumentAndDisplay (bool displayDocument, NSError outError);

		//- (id)makeUntitledDocumentOfType:(NSString *)typeName error:(NSError **)outError;
		[Export ("makeUntitledDocumentOfType:error:")]
		NSDocumentController MakeUntitledDocumentOfType (string typeName, NSError outError);

//#endif
		//#pragma mark *** Document Opening ***- (IBAction)openDocument:(id)sender;
		[Export ("openDocument:")]
		void OpenDocument (NSObject sender);

		//- (NSArray *)URLsFromRunningOpenPanel;
		[Export ("URLsFromRunningOpenPanel")]
		NSArray UrlsFromRunningOpenPanel { get; }

		//- (NSInteger)runModalOpenPanel:(NSOpenPanel *)openPanel forTypes:(NSArray *)types;
		[Export ("runModalOpenPanel:forTypes:")]
		int RunModalOpenPanel (NSOpenPanel openPanel, NSArray types);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (id)openDocumentWithContentsOfURL:(NSURL *)absoluteURL display:(BOOL)displayDocument error:(NSError **)outError;
		[Export ("openDocumentWithContentsOfURL:display:error:")]
		NSDocumentController OpenDocumentWithContentsOfUrl (NSUrl absoluteURL, bool displayDocument, NSError outError);

		//- (id)makeDocumentWithContentsOfURL:(NSURL *)absoluteURL ofType:(NSString *)typeName error:(NSError **)outError;
		[Export ("makeDocumentWithContentsOfURL:ofType:error:")]
		NSDocumentController MakeDocumentWithContentsOfUrl (NSUrl absoluteURL, string typeName, NSError outError);

//#endif
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//#pragma mark *** Document Reopening ***- (BOOL)reopenDocumentForURL:(NSURL *)absoluteDocumentURL withContentsOfURL:(NSURL *)absoluteDocumentContentsURL error:(NSError **)outError;
		[Export ("reopenDocumentForURL:withContentsOfURL:error:")]
		bool ReopenDocumentForUrl (NSUrl absoluteDocumentURL, NSUrl absoluteDocumentContentsURL, NSError outError);

		//- (id)makeDocumentForURL:(NSURL *)absoluteDocumentURL withContentsOfURL:(NSURL *)absoluteDocumentContentsURL ofType:(NSString *)typeName error:(NSError **)outError;
		[Export ("makeDocumentForURL:withContentsOfURL:ofType:error:")]
		NSDocumentController MakeDocumentForUrl (NSUrl absoluteDocumentURL, NSUrl absoluteDocumentContentsURL, string typeName, NSError outError);

//#endif
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (NSTimeInterval)autosavingDelay;
		[Export ("autosavingDelay")]
		double AutosavingDelay { get; set; }

//#endif
		//#pragma mark *** Document Saving ***- (IBAction)saveAllDocuments:(id)sender;
		[Export ("saveAllDocuments:")]
		void SaveAllDocuments (NSObject sender);

		//#pragma mark *** Document Closing ***- (BOOL)hasEditedDocuments;
		[Export ("hasEditedDocuments")]
		bool HasEditedDocuments { get; }

		//- (void)reviewUnsavedDocumentsWithAlertTitle:(NSString *)title cancellable:(BOOL)cancellable delegate:(id)delegate didReviewAllSelector:(SEL)didReviewAllSelector contextInfo:(void *)contextInfo;
		[Export ("reviewUnsavedDocumentsWithAlertTitle:cancellable:delegate:didReviewAllSelector:contextInfo:")]
		void ReviewUnsavedDocumentsWithAlertTitle (string title, bool cancellable, NSObject delegate1, Selector didReviewAllSelector, IntPtr contextInfo);

		//- (void)closeAllDocumentsWithDelegate:(id)delegate didCloseAllSelector:(SEL)didCloseAllSelector contextInfo:(void *)contextInfo;
		[Export ("closeAllDocumentsWithDelegate:didCloseAllSelector:contextInfo:")]
		void CloseAllDocumentsWithDelegate (NSObject delegate1, Selector didCloseAllSelector, IntPtr contextInfo);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//#pragma mark *** Error Presentation ***- (void)presentError:(NSError *)error modalForWindow:(NSWindow *)window delegate:(id)delegate didPresentSelector:(SEL)didPresentSelector contextInfo:(void *)contextInfo;
		[Export ("presentError:modalForWindow:delegate:didPresentSelector:contextInfo:")]
		void PresentError (NSError error, NSWindow window, NSObject delegate1, Selector didPresentSelector, IntPtr contextInfo);

		//- (BOOL)presentError:(NSError *)error;
		[Export ("presentError:")]
		bool PresentError (NSError error);

		//- (NSError *)willPresentError:(NSError *)error;
		[Export ("willPresentError:")]
		NSError WillPresentError (NSError error);

//#endif
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//#pragma mark *** The Open Recent Menu ***- (NSUInteger)maximumRecentDocumentCount;
		[Export ("maximumRecentDocumentCount")]
		uint MaximumRecentDocumentCount { get; }

//#endif
		//- (IBAction)clearRecentDocuments:(id)sender;
		[Export ("clearRecentDocuments:")]
		void ClearRecentDocuments (NSObject sender);

		//- (void)noteNewRecentDocument:(NSDocument *)document;
		[Export ("noteNewRecentDocument:")]
		void NoteNewRecentDocument (NSDocument document);

		//- (void)noteNewRecentDocumentURL:(NSURL *)absoluteURL;
		[Export ("noteNewRecentDocumentURL:")]
		void NoteNewRecentDocumentUrl (NSUrl absoluteURL);

		//- (NSArray *)recentDocumentURLs;
		[Export ("recentDocumentURLs")]
		NSArray RecentDocumentUrls { get; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//#pragma mark *** Document Types ***- (NSString *)defaultType;
		[Export ("defaultType")]
		string DefaultType { get; }

		//- (NSString *)typeForContentsOfURL:(NSURL *)inAbsoluteURL error:(NSError **)outError;
		[Export ("typeForContentsOfURL:error:")]
		string TypeForContentsOfUrl (NSUrl inAbsoluteURL, NSError outError);

		//- (NSArray *)documentClassNames;
		[Export ("documentClassNames")]
		NSArray DocumentClassNames { get; }

//#endif
		//- (Class)documentClassForType:(NSString *)typeName;
		[Export ("documentClassForType:")]
		Class DocumentClassForType (string typeName);

		//- (NSString *)displayNameForType:(NSString *)typeName;
		[Export ("displayNameForType:")]
		string DisplayNameForType (string typeName);

		//#pragma mark *** Menu Item Validation ***- (BOOL)validateUserInterfaceItem:(id <NSValidatedUserInterfaceItem>)anItem;
		[Export ("validateUserInterfaceItem:")]
		bool ValidateUserInterfaceItem (NSObject anItem);

		////#pragma mark *** Backward Compatibility- (NSArray *)fileExtensionsFromType:(NSString *)typeName;
		//[Export ("fileExtensionsFromType:")]
		//NSArray FileExtensionsFromType (string typeName);

		////- (NSString *)typeFromFileExtension:(NSString *)fileNameExtensionOrHFSFileType;
		//[Export ("typeFromFileExtension:")]
		//string TypeFromFileExtension (string fileNameExtensionOrHFSFileType);

		////- (id)documentForFileName:(NSString *)fileName;
		//[Export ("documentForFileName:")]
		//NSDocumentController DocumentForFileName (string fileName);

		////- (NSArray *)fileNamesFromRunningOpenPanel;
		//[Export ("fileNamesFromRunningOpenPanel")]
		//NSArray FileNamesFromRunningOpenPanel { get; }

		////- (id)makeDocumentWithContentsOfFile:(NSString *)fileName ofType:(NSString *)type;
		//[Export ("makeDocumentWithContentsOfFile:ofType:")]
		//NSDocumentController MakeDocumentWithContentsOfFileOfType (string fileName, string type);

		////- (id)makeDocumentWithContentsOfURL:(NSURL *)url ofType:(NSString *)type;
		//[Export ("makeDocumentWithContentsOfURL:ofType:")]
		//NSDocumentController MakeDocumentWithContentsOfURLOfType (NSUrl url, string type);

		////- (id)makeUntitledDocumentOfType:(NSString *)type;
		//[Export ("makeUntitledDocumentOfType:")]
		//NSDocumentController MakeUntitledDocumentOfType (string type);

		////- (id)openDocumentWithContentsOfFile:(NSString *)fileName display:(BOOL)display;
		//[Export ("openDocumentWithContentsOfFile:display:")]
		//NSDocumentController OpenDocumentWithContentsOfFileDisplay (string fileName, bool display);

		////- (id)openDocumentWithContentsOfURL:(NSURL *)url display:(BOOL)display;
		//[Export ("openDocumentWithContentsOfURL:display:")]
		//NSDocumentController OpenDocumentWithContentsOfURLDisplay (NSUrl url, bool display);

		////- (id)openUntitledDocumentOfType:(NSString*)type display:(BOOL)display;
		//[Export ("openUntitledDocumentOfType:display:")]
		//NSDocumentController OpenUntitledDocumentOfTypeDisplay (string type, bool display);

		////- (BOOL)shouldCreateUI;
		//[Export ("shouldCreateUI")]
		//bool ShouldCreateUI { get; set; }

	}
}
