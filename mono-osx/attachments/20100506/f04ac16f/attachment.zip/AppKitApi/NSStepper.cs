using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSControl))]
	interface NSStepper {

		//- (double)minValue;
		[Export ("minValue")]
		double MinValue { get; set; }

		//- (double)maxValue;
		[Export ("maxValue")]
		double MaxValue { get; set; }

		//- (double)increment;
		[Export ("increment")]
		double Increment { get; set; }

		//- (BOOL)valueWraps;
		[Export ("valueWraps")]
		bool ValueWraps { get; set; }

		//- (BOOL)autorepeat;
		[Export ("autorepeat")]
		bool Autorepeat { get; set; }

	}
}
