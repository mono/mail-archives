using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSResponder))]
	interface NSWindow {

		//- (NSArray *)drawers;
		[Export ("drawers")]
		NSArray Drawers { get; }

//#endif
		//+ (NSRect)frameRectForContentRect:(NSRect)cRect styleMask:(NSUInteger)aStyle;
		[Static, Export ("frameRectForContentRect:styleMask:")]
		RectangleF FrameRectForContentRect (RectangleF cRect, uint aStyle);

		//+ (NSRect)contentRectForFrameRect:(NSRect)fRect styleMask:(NSUInteger)aStyle;
		[Static, Export ("contentRectForFrameRect:styleMask:")]
		RectangleF ContentRectForFrameRect (RectangleF fRect, uint aStyle);

		//+ (CGFloat)minFrameWidthWithTitle:(NSString *)aTitle styleMask:(NSUInteger)aStyle;
		[Static, Export ("minFrameWidthWithTitle:styleMask:")]
		float MinFrameWidthWithTitle (string aTitle, uint aStyle);

		//+ (NSWindowDepth)defaultDepthLimit;
		[Static, Export ("defaultDepthLimit")]
		int DefaultDepthLimit { get; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//- (NSRect)frameRectForContentRect:(NSRect)contentRect;
		[Export ("frameRectForContentRect:")]
		RectangleF FrameRectForContentRect (RectangleF contentRect);

		//- (NSRect)contentRectForFrameRect:(NSRect)frameRect;
		[Export ("contentRectForFrameRect:")]
		RectangleF ContentRectForFrameRect (RectangleF frameRect);

//#endif
		//- (id)initWithContentRect:(NSRect)contentRect styleMask:(NSUInteger)aStyle backing:(NSBackingStoreType)bufferingType defer:(BOOL)flag;
		[Export ("initWithContentRect:styleMask:backing:defer:")]
		IntPtr Constructor (RectangleF contentRect, uint aStyle, NSBackingStoreType bufferingType, bool flag);

		//- (id)initWithContentRect:(NSRect)contentRect styleMask:(NSUInteger)aStyle backing:(NSBackingStoreType)bufferingType defer:(BOOL)flag screen:(NSScreen *)screen;
		[Export ("initWithContentRect:styleMask:backing:defer:screen:")]
		IntPtr Constructor (RectangleF contentRect, uint aStyle, NSBackingStoreType bufferingType, bool flag, NSScreen screen);

		//- (NSString *)title;
		[Export ("title")]
		string Title { get; set; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (NSURL *)representedURL;
		[Export ("representedURL")]
		NSUrl RepresentedUrl { get; set; }

//#endif
		//- (NSString *)representedFilename;
		[Export ("representedFilename")]
		string RepresentedFilename { get; set; }

		//- (void)setTitleWithRepresentedFilename:(NSString *)filename;
		[Export ("setTitleWithRepresentedFilename:")]
		void SetTitleWithRepresentedFilename (string filename);

		//- (void)setExcludedFromWindowsMenu:(BOOL)flag;
		[Export ("setExcludedFromWindowsMenu:")]
		void SetExcludedFromWindowsMenu (bool flag);

		//- (BOOL)isExcludedFromWindowsMenu;
		[Export ("isExcludedFromWindowsMenu")]
		bool IsExcludedFromWindowsMenu { get; }

		//- (void)setContentView:(NSView *)aView;
		[Export ("setContentView:")]
		void SetContentView (NSView aView);

		//- (id)contentView;
		[Export ("contentView")]
		NSWindow ContentView { get; }

		//- (void)setDelegate:(id)anObject;
		[Export ("setDelegate:")]
		void SetDelegate (NSObject anObject);

		//- (id)delegate;
		[Export ("delegate")]
		NSWindow Delegate { get; }

		//- (NSInteger)windowNumber;
		[Export ("windowNumber")]
		int WindowNumber { get; }

		//- (NSUInteger)styleMask;
		[Export ("styleMask")]
		uint StyleMask { get; }

		//- (NSText *)fieldEditor:(BOOL)createFlag forObject:(id)anObject;
		[Export ("fieldEditor:forObject:")]
		NSText FieldEditor (bool createFlag, NSObject anObject);

		//- (void)endEditingFor:(id)anObject;
		[Export ("endEditingFor:")]
		void EndEditingFor (NSObject anObject);

		//- (NSRect)constrainFrameRect:(NSRect)frameRect toScreen:(NSScreen *)screen;
		[Export ("constrainFrameRect:toScreen:")]
		RectangleF ConstrainFrameRect (RectangleF frameRect, NSScreen screen);

		//- (void)setFrame:(NSRect)frameRect display:(BOOL)flag;
		[Export ("setFrame:display:")]
		void SetFrame (RectangleF frameRect, bool flag);

		//- (void)setContentSize:(NSSize)aSize;
		[Export ("setContentSize:")]
		void SetContentSize (NSSize aSize);

		//- (void)setFrameOrigin:(NSPoint)aPoint;
		[Export ("setFrameOrigin:")]
		void SetFrameOrigin (PointF aPoint);

		//- (void)setFrameTopLeftPoint:(NSPoint)aPoint;
		[Export ("setFrameTopLeftPoint:")]
		void SetFrameTopLeftPoint (PointF aPoint);

		//- (NSPoint)cascadeTopLeftFromPoint:(NSPoint)topLeftPoint;
		[Export ("cascadeTopLeftFromPoint:")]
		PointF CascadeTopLeftFromPoint (PointF topLeftPoint);

		//- (NSRect)frame;
		[Export ("frame")]
		RectangleF Frame { get; }

		//- (NSTimeInterval)animationResizeTime:(NSRect)newFrame;
		[Export ("animationResizeTime:")]
		double AnimationResizeTime (RectangleF newFrame);

		//- (void)setFrame:(NSRect)frameRect display:(BOOL)displayFlag animate:(BOOL)animateFlag;
		[Export ("setFrame:display:animate:")]
		void SetFrame (RectangleF frameRect, bool displayFlag, bool animateFlag);

		//- (BOOL)showsResizeIndicator;
		[Export ("showsResizeIndicator")]
		bool ShowsResizeIndicator { get; set; }

		//- (NSSize)resizeIncrements;
		[Export ("resizeIncrements")]
		NSSize ResizeIncrements { get; set; }

		//- (NSSize)aspectRatio;
		[Export ("aspectRatio")]
		NSSize AspectRatio { get; set; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//- (NSSize)contentResizeIncrements;
		[Export ("contentResizeIncrements")]
		NSSize ContentResizeIncrements { get; set; }

		//- (NSSize)contentAspectRatio;
		[Export ("contentAspectRatio")]
		NSSize ContentAspectRatio { get; set; }

//#endif
		//- (void)useOptimizedDrawing:(BOOL)flag;
		[Export ("useOptimizedDrawing:")]
		void UseOptimizedDrawing (bool flag);

		//- (void)disableFlushWindow;
		[Export ("disableFlushWindow")]
		void DisableFlushWindow ();

		//- (void)enableFlushWindow;
		[Export ("enableFlushWindow")]
		void EnableFlushWindow ();

		//- (BOOL)isFlushWindowDisabled;
		[Export ("isFlushWindowDisabled")]
		bool IsFlushWindowDisabled { get; }

		//- (void)flushWindow;
		[Export ("flushWindow")]
		void FlushWindow ();

		//- (void)flushWindowIfNeeded;
		[Export ("flushWindowIfNeeded")]
		void FlushWindowIfNeeded ();

		//- (BOOL)viewsNeedDisplay;
		[Export ("viewsNeedDisplay")]
		bool ViewsNeedDisplay { get; set; }

		//- (void)displayIfNeeded;
		[Export ("displayIfNeeded")]
		void DisplayIfNeeded ();

		//- (void)display;
		[Export ("display")]
		void Display ();

		//- (void)setAutodisplay:(BOOL)flag;
		[Export ("setAutodisplay:")]
		void SetAutodisplay (bool flag);

		//- (BOOL)isAutodisplay;
		[Export ("isAutodisplay")]
		bool IsAutodisplay { get; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (BOOL)preservesContentDuringLiveResize;
		[Export ("preservesContentDuringLiveResize")]
		bool PreservesContentDuringLiveResize { get; set; }

//#endif
		//- (void)update;
		[Export ("update")]
		void Update ();

		//- (BOOL)makeFirstResponder:(NSResponder *)aResponder;
		[Export ("makeFirstResponder:")]
		bool MakeFirstResponder (NSResponder aResponder);

		//- (NSResponder *)firstResponder;
		[Export ("firstResponder")]
		NSResponder FirstResponder { get; }

		//- (NSInteger)resizeFlags;
		[Export ("resizeFlags")]
		int ResizeFlags { get; }

		//- (void)keyDown:(NSEvent *)theEvent;
		[Export ("keyDown:")]
		void KeyDown (NSEvent theEvent);

		//- (void)close;
		[Export ("close")]
		void Close ();

		//- (void)setReleasedWhenClosed:(BOOL)flag;
		[Export ("setReleasedWhenClosed:")]
		void SetReleasedWhenClosed (bool flag);

		//- (BOOL)isReleasedWhenClosed;
		[Export ("isReleasedWhenClosed")]
		bool IsReleasedWhenClosed { get; }

		//- (void)miniaturize:(id)sender;
		[Export ("miniaturize:")]
		void Miniaturize (NSObject sender);

		//- (void)deminiaturize:(id)sender;
		[Export ("deminiaturize:")]
		void Deminiaturize (NSObject sender);

		//- (BOOL)isZoomed;
		[Export ("isZoomed")]
		bool IsZoomed { get; set; }

		//- (void)zoom:(id)sender;
		[Export ("zoom:")]
		void Zoom (NSObject sender);

		//- (BOOL)isMiniaturized;
		[Export ("isMiniaturized")]
		bool IsMiniaturized { get; set; }

		//- (BOOL)tryToPerform:(SEL)anAction with:(id)anObject;
		[Export ("tryToPerform:with:")]
		bool TryToPerform (Selector anAction, NSObject anObject);

		//- (id)validRequestorForSendType:(NSString *)sendType returnType:(NSString *)returnType;
		[Export ("validRequestorForSendType:returnType:")]
		NSWindow ValidRequestorForSendType (string sendType, string returnType);

		//- (NSColor *)backgroundColor;
		[Export ("backgroundColor")]
		NSColor BackgroundColor { get; set; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (void)setContentBorderThickness:(CGFloat)thickness forEdge:(NSRectEdge)edge;
		[Export ("setContentBorderThickness:forEdge:")]
		void SetContentBorderThickness (float thickness, NSRectEdge edge);

		//- (CGFloat)contentBorderThicknessForEdge:(NSRectEdge)edge;
		[Export ("contentBorderThicknessForEdge:")]
		float ContentBorderThicknessForEdge (NSRectEdge edge);

		//- (void)setAutorecalculatesContentBorderThickness:(BOOL)flag forEdge:(NSRectEdge)edge;
		[Export ("setAutorecalculatesContentBorderThickness:forEdge:")]
		void SetAutorecalculatesContentBorderThickness (bool flag, NSRectEdge edge);

		//- (BOOL)autorecalculatesContentBorderThicknessForEdge:(NSRectEdge)edge;
		[Export ("autorecalculatesContentBorderThicknessForEdge:")]
		bool AutorecalculatesContentBorderThicknessForEdge (NSRectEdge edge);

//#endif
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_2
		//- (void)setMovableByWindowBackground:(BOOL)flag;
		[Export ("setMovableByWindowBackground:")]
		void SetMovableByWindowBackground (bool flag);

		//- (BOOL)isMovableByWindowBackground;
		[Export ("isMovableByWindowBackground")]
		bool IsMovableByWindowBackground { get; }

//#endif
		//- (BOOL)hidesOnDeactivate;
		[Export ("hidesOnDeactivate")]
		bool HidesOnDeactivate { get; set; }

		//- (BOOL)canHide;
		[Export ("canHide")]
		bool CanHide { get; set; }

		//- (void)center;
		[Export ("center")]
		void Center ();

		//- (void)makeKeyAndOrderFront:(id)sender;
		[Export ("makeKeyAndOrderFront:")]
		void MakeKeyAndOrderFront (NSObject sender);

		//- (void)orderFront:(id)sender;
		[Export ("orderFront:")]
		void OrderFront (NSObject sender);

		//- (void)orderBack:(id)sender;
		[Export ("orderBack:")]
		void OrderBack (NSObject sender);

		//- (void)orderOut:(id)sender;
		[Export ("orderOut:")]
		void OrderOut (NSObject sender);

		//- (void)orderWindow:(NSWindowOrderingMode)place relativeTo:(NSInteger)otherWin;
		[Export ("orderWindow:relativeTo:")]
		void OrderWindow (NSWindowOrderingMode place, int otherWin);

		//- (void)orderFrontRegardless;
		[Export ("orderFrontRegardless")]
		void OrderFrontRegardless ();

		//- (NSImage *)miniwindowImage;
		[Export ("miniwindowImage")]
		NSImage MiniwindowImage { get; set; }

		//- (NSString *)miniwindowTitle;
		[Export ("miniwindowTitle")]
		string MiniwindowTitle { get; set; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (NSDockTile *)dockTile;
		[Export ("dockTile")]
		NSDockTile DockTile { get; }

//#endif
		//- (void)setDocumentEdited:(BOOL)flag;
		[Export ("setDocumentEdited:")]
		void SetDocumentEdited (bool flag);

		//- (BOOL)isDocumentEdited;
		[Export ("isDocumentEdited")]
		bool IsDocumentEdited { get; }

		//- (BOOL)isVisible;
		[Export ("isVisible")]
		bool IsVisible { get; set; }

		//- (BOOL)isKeyWindow;
		[Export ("isKeyWindow")]
		bool IsKeyWindow { get; }

		//- (BOOL)isMainWindow;
		[Export ("isMainWindow")]
		bool IsMainWindow { get; }

		//- (BOOL)canBecomeKeyWindow;
		[Export ("canBecomeKeyWindow")]
		bool CanBecomeKeyWindow { get; }

		//- (BOOL)canBecomeMainWindow;
		[Export ("canBecomeMainWindow")]
		bool CanBecomeMainWindow { get; }

		//- (void)makeKeyWindow;
		[Export ("makeKeyWindow")]
		void MakeKeyWindow ();

		//- (void)makeMainWindow;
		[Export ("makeMainWindow")]
		void MakeMainWindow ();

		//- (void)becomeKeyWindow;
		[Export ("becomeKeyWindow")]
		void BecomeKeyWindow ();

		//- (void)resignKeyWindow;
		[Export ("resignKeyWindow")]
		void ResignKeyWindow ();

		//- (void)becomeMainWindow;
		[Export ("becomeMainWindow")]
		void BecomeMainWindow ();

		//- (void)resignMainWindow;
		[Export ("resignMainWindow")]
		void ResignMainWindow ();

		//- (BOOL)worksWhenModal;
		[Export ("worksWhenModal")]
		bool WorksWhenModal { get; }

		//- (NSPoint)convertBaseToScreen:(NSPoint)aPoint;
		[Export ("convertBaseToScreen:")]
		PointF ConvertBaseToScreen (PointF aPoint);

		//- (NSPoint)convertScreenToBase:(NSPoint)aPoint;
		[Export ("convertScreenToBase:")]
		PointF ConvertScreenToBase (PointF aPoint);

		//- (void)performClose:(id)sender;
		[Export ("performClose:")]
		void PerformClose (NSObject sender);

		//- (void)performMiniaturize:(id)sender;
		[Export ("performMiniaturize:")]
		void PerformMiniaturize (NSObject sender);

		//- (void)performZoom:(id)sender;
		[Export ("performZoom:")]
		void PerformZoom (NSObject sender);

		//- (NSInteger)gState;
		[Export ("gState")]
		int GState { get; }

		//- (void)setOneShot:(BOOL)flag;
		[Export ("setOneShot:")]
		void SetOneShot (bool flag);

		//- (BOOL)isOneShot;
		[Export ("isOneShot")]
		bool IsOneShot { get; }

		//- (NSData *)dataWithEPSInsideRect:(NSRect)rect;
		[Export ("dataWithEPSInsideRect:")]
		NSData DataWithEPSInsideRect (RectangleF rect);

		//- (NSData *)dataWithPDFInsideRect:(NSRect)rect;
		[Export ("dataWithPDFInsideRect:")]
		NSData DataWithPDFInsideRect (RectangleF rect);

		//- (void)print:(id)sender;
		[Export ("print:")]
		void Print (NSObject sender);

		//- (void)disableCursorRects;
		[Export ("disableCursorRects")]
		void DisableCursorRects ();

		//- (void)enableCursorRects;
		[Export ("enableCursorRects")]
		void EnableCursorRects ();

		//- (void)discardCursorRects;
		[Export ("discardCursorRects")]
		void DiscardCursorRects ();

		//- (BOOL)areCursorRectsEnabled;
		[Export ("areCursorRectsEnabled")]
		bool AreCursorRectsEnabled { get; }

		//- (void)invalidateCursorRectsForView:(NSView *)aView;
		[Export ("invalidateCursorRectsForView:")]
		void InvalidateCursorRectsForView (NSView aView);

		//- (void)resetCursorRects;
		[Export ("resetCursorRects")]
		void ResetCursorRects ();

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//	- (BOOL)allowsToolTipsWhenApplicationIsInactive;
		[Export ("allowsToolTipsWhenApplicationIsInactive")]
		bool AllowsToolTipsWhenApplicationIsInactive { get; set; }

//#endif
		//- (NSBackingStoreType)backingType;
		[Export ("backingType")]
		NSBackingStoreType BackingType { get; set; }

		//- (NSInteger)level;
		[Export ("level")]
		int Level { get; set; }

		//- (NSWindowDepth)depthLimit;
		[Export ("depthLimit")]
		int DepthLimit { get; set; }

		//- (void)setDynamicDepthLimit:(BOOL)flag;
		[Export ("setDynamicDepthLimit:")]
		void SetDynamicDepthLimit (bool flag);

		//- (BOOL)hasDynamicDepthLimit;
		[Export ("hasDynamicDepthLimit")]
		bool HasDynamicDepthLimit { get; }

		//- (NSScreen *)screen;
		[Export ("screen")]
		NSScreen Screen { get; }

		//- (NSScreen *)deepestScreen;
		[Export ("deepestScreen")]
		NSScreen DeepestScreen { get; }

		//- (BOOL)canStoreColor;
		[Export ("canStoreColor")]
		bool CanStoreColor { get; }

		//- (BOOL)hasShadow;
		[Export ("hasShadow")]
		bool HasShadow { get; set; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_2
		//- (void)invalidateShadow;
		[Export ("invalidateShadow")]
		void InvalidateShadow ();

//#endif
		//- (CGFloat)alphaValue;
		[Export ("alphaValue")]
		float AlphaValue { get; set; }

		//- (void)setOpaque:(BOOL)isOpaque;
		[Export ("setOpaque:")]
		void SetOpaque (bool isOpaque);

		//- (BOOL)isOpaque;
		[Export ("isOpaque")]
		bool IsOpaque { get; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (NSWindowSharingType)sharingType;
		[Export ("sharingType")]
		NSWindowSharingType SharingType { get; set; }

		//- (NSWindowBackingLocation)preferredBackingLocation;
		[Export ("preferredBackingLocation")]
		NSWindowBackingLocation PreferredBackingLocation { get; set; }

		//- (NSWindowBackingLocation)backingLocation;
		[Export ("backingLocation")]
		NSWindowBackingLocation BackingLocation { get; }

//#endif
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (BOOL)displaysWhenScreenProfileChanges;
		[Export ("displaysWhenScreenProfileChanges")]
		bool DisplaysWhenScreenProfileChanges { get; set; }

		//- (void)disableScreenUpdatesUntilFlush;
		[Export ("disableScreenUpdatesUntilFlush")]
		void DisableScreenUpdatesUntilFlush ();

//#endif
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (BOOL)canBecomeVisibleWithoutLogin;
		[Export ("canBecomeVisibleWithoutLogin")]
		bool CanBecomeVisibleWithoutLogin { get; set; }

		//- (NSWindowCollectionBehavior)collectionBehavior;
		[Export ("collectionBehavior")]
		NSWindowCollectionBehavior CollectionBehavior { get; set; }

//#endif
		//-(BOOL)canBeVisibleOnAllSpaces                  AVAILABLE_MAC_OS_X_VERSION_10_5_AND_LATER_BUT_DEPRECATED;
		[Export ("canBeVisibleOnAllSpaces")]
		bool CanBeVisibleOnAllSpaces { get; set; }

		//- (NSString *)stringWithSavedFrame;
		[Export ("stringWithSavedFrame")]
		string StringWithSavedFrame { get; }

		//- (void)setFrameFromString:(NSString *)string;
		[Export ("setFrameFromString:")]
		void SetFrameFromString (string string1);

		//- (void)saveFrameUsingName:(NSString *)name;
		[Export ("saveFrameUsingName:")]
		void SaveFrameUsingName (string name);

		//- (BOOL)setFrameUsingName:(NSString *)name force:(BOOL)force;
		[Export ("setFrameUsingName:force:")]
		bool SetFrameUsingName (string name, bool force);

		//- (BOOL)setFrameUsingName:(NSString *)name;
		[Export ("setFrameUsingName:")]
		bool SetFrameUsingName (string name);

		//- (BOOL)setFrameAutosaveName:(NSString *)name;
		[Export ("setFrameAutosaveName:")]
		bool SetFrameAutosaveName (string name);

		//- (NSString *)frameAutosaveName;
		[Export ("frameAutosaveName")]
		string FrameAutosaveName { get; }

		//+ (void)removeFrameUsingName:(NSString *)name;
		[Static, Export ("removeFrameUsingName:")]
		void RemoveFrameUsingName (string name);

		//- (void)cacheImageInRect:(NSRect)aRect;
		[Export ("cacheImageInRect:")]
		void CacheImageInRect (RectangleF aRect);

		//- (void)restoreCachedImage;
		[Export ("restoreCachedImage")]
		void RestoreCachedImage ();

		//- (void)discardCachedImage;
		[Export ("discardCachedImage")]
		void DiscardCachedImage ();

		//- (NSSize)minSize;
		[Export ("minSize")]
		NSSize MinSize { get; set; }

		//- (NSSize)maxSize;
		[Export ("maxSize")]
		NSSize MaxSize { get; set; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//- (NSSize)contentMinSize;
		[Export ("contentMinSize")]
		NSSize ContentMinSize { get; set; }

		//- (NSSize)contentMaxSize;
		[Export ("contentMaxSize")]
		NSSize ContentMaxSize { get; set; }

//#endif
		//- (NSEvent *)nextEventMatchingMask:(NSUInteger)mask;
		[Export ("nextEventMatchingMask:")]
		NSEvent NextEventMatchingMask (uint mask);

		//- (NSEvent *)nextEventMatchingMask:(NSUInteger)mask untilDate:(NSDate *)expiration inMode:(NSString *)mode dequeue:(BOOL)deqFlag;
		[Export ("nextEventMatchingMask:untilDate:inMode:dequeue:")]
		NSEvent NextEventMatchingMask (uint mask, NSDate expiration, string mode, bool deqFlag);

		//- (void)discardEventsMatchingMask:(NSUInteger)mask beforeEvent:(NSEvent *)lastEvent;
		[Export ("discardEventsMatchingMask:beforeEvent:")]
		void DiscardEventsMatchingMask (uint mask, NSEvent lastEvent);

		//- (void)postEvent:(NSEvent *)event atStart:(BOOL)flag;
		[Export ("postEvent:atStart:")]
		void PostEvent (NSEvent event1, bool flag);

		//- (NSEvent *)currentEvent;
		[Export ("currentEvent")]
		NSEvent CurrentEvent { get; }

		//- (BOOL)acceptsMouseMovedEvents;
		[Export ("acceptsMouseMovedEvents")]
		bool AcceptsMouseMovedEvents { get; set; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_2
		//- (BOOL)ignoresMouseEvents;
		[Export ("ignoresMouseEvents")]
		bool IgnoresMouseEvents { get; set; }

//#endif
		//- (NSDictionary *)deviceDescription;
		[Export ("deviceDescription")]
		NSDictionary DeviceDescription { get; }

		//- (void)sendEvent:(NSEvent *)theEvent;
		[Export ("sendEvent:")]
		void SendEvent (NSEvent theEvent);

		//- (NSPoint)mouseLocationOutsideOfEventStream;
		[Export ("mouseLocationOutsideOfEventStream")]
		PointF MouseLocationOutsideOfEventStream { get; }

		//+ (void)menuChanged:(NSMenu *)menu;
		[Static, Export ("menuChanged:")]
		void MenuChanged (NSMenu menu);

		//- (id)windowController;
		[Export ("windowController")]
		NSWindow WindowController { get; }

		//- (void)setWindowController:(NSWindowController *)windowController;
		[Export ("setWindowController:")]
		void SetWindowController (NSWindowController windowController);

		//- (BOOL)isSheet;
		[Export ("isSheet")]
		bool IsSheet { get; }

		//- (NSWindow *)attachedSheet;
		[Export ("attachedSheet")]
		NSWindow AttachedSheet { get; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_2
		//+ (NSButton *)standardWindowButton:(NSWindowButton)b forStyleMask:(NSUInteger)styleMask;
		[Static, Export ("standardWindowButton:forStyleMask:")]
		NSButton StandardWindowButton (NSWindowButton b, uint styleMask);

		//- (NSButton *)standardWindowButton:(NSWindowButton)b;
		[Export ("standardWindowButton:")]
		NSButton StandardWindowButton (NSWindowButton b);

//#endif
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_2
		//- (void)addChildWindow:(NSWindow *)childWin ordered:(NSWindowOrderingMode)place;
		[Export ("addChildWindow:ordered:")]
		void AddChildWindow (NSWindow childWin, NSWindowOrderingMode place);

		//- (void)removeChildWindow:(NSWindow *)childWin;
		[Export ("removeChildWindow:")]
		void RemoveChildWindow (NSWindow childWin);

		//- (NSArray *)childWindows;
		[Export ("childWindows")]
		NSArray ChildWindows { get; }

		//- (NSWindow *)parentWindow;
		[Export ("parentWindow")]
		NSWindow ParentWindow { get; set; }

//#endif
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (NSGraphicsContext *)graphicsContext;
		[Export ("graphicsContext")]
		NSGraphicsContext GraphicsContext { get; }

		//- (CGFloat)userSpaceScaleFactor;
		[Export ("userSpaceScaleFactor")]
		float UserSpaceScaleFactor { get; }

//#endif 
		//- (NSView *)initialFirstResponder;
		[Export ("initialFirstResponder")]
		NSView InitialFirstResponder { get; }

		//- (void)selectNextKeyView:(id)sender;
		[Export ("selectNextKeyView:")]
		void SelectNextKeyView (NSObject sender);

		//- (void)selectPreviousKeyView:(id)sender;
		[Export ("selectPreviousKeyView:")]
		void SelectPreviousKeyView (NSObject sender);

		//- (void)selectKeyViewFollowingView:(NSView *)aView;
		[Export ("selectKeyViewFollowingView:")]
		void SelectKeyViewFollowingView (NSView aView);

		//- (void)selectKeyViewPrecedingView:(NSView *)aView;
		[Export ("selectKeyViewPrecedingView:")]
		void SelectKeyViewPrecedingView (NSView aView);

		//- (NSSelectionDirection)keyViewSelectionDirection;
		[Export ("keyViewSelectionDirection")]
		NSSelectionDirection KeyViewSelectionDirection { get; }

		//- (NSButtonCell *)defaultButtonCell;
		[Export ("defaultButtonCell")]
		NSButtonCell DefaultButtonCell { get; set; }

		//- (void)disableKeyEquivalentForDefaultButtonCell;
		[Export ("disableKeyEquivalentForDefaultButtonCell")]
		void DisableKeyEquivalentForDefaultButtonCell ();

		//- (void)enableKeyEquivalentForDefaultButtonCell;
		[Export ("enableKeyEquivalentForDefaultButtonCell")]
		void EnableKeyEquivalentForDefaultButtonCell ();

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (BOOL)autorecalculatesKeyViewLoop;
		[Export ("autorecalculatesKeyViewLoop")]
		bool AutorecalculatesKeyViewLoop { get; set; }

		//- (void)recalculateKeyViewLoop;
		[Export ("recalculateKeyViewLoop")]
		void RecalculateKeyViewLoop ();

//#endif
		//- (NSToolbar *)toolbar;
		[Export ("toolbar")]
		NSToolbar Toolbar { get; }

		//- (void)toggleToolbarShown:(id)sender;
		[Export ("toggleToolbarShown:")]
		void ToggleToolbarShown (NSObject sender);

		//- (void)runToolbarCustomizationPalette:(id)sender;
		[Export ("runToolbarCustomizationPalette:")]
		void RunToolbarCustomizationPalette (NSObject sender);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (BOOL)showsToolbarButton;
		[Export ("showsToolbarButton")]
		bool ShowsToolbarButton { get; set; }

//#endif
		//- (void)registerForDraggedTypes:(NSArray *)newTypes;
		[Export ("registerForDraggedTypes:")]
		void RegisterForDraggedTypes (NSArray newTypes);

		//- (void)unregisterDraggedTypes;
		[Export ("unregisterDraggedTypes")]
		void UnregisterDraggedTypes ();

		//- (NSWindow *)initWithWindowRef:(void * )windowRef;
		[Export ("initWithWindowRef:")]
		IntPtr Constructor (IntPtr windowRef);

		//- (void * )windowRef;
		[Export ("windowRef")]
		void WindowRef ();

		//- (BOOL)hasCloseBox;
		[Export ("hasCloseBox")]
		bool HasCloseBox { get; }

		//- (BOOL)hasTitleBar;
		[Export ("hasTitleBar")]
		bool HasTitleBar { get; }

		//- (BOOL)isFloatingPanel;
		[Export ("isFloatingPanel")]
		bool IsFloatingPanel { get; }

		//- (BOOL)isMiniaturizable;
		[Export ("isMiniaturizable")]
		bool IsMiniaturizable { get; }

		//- (BOOL)isModalPanel;
		[Export ("isModalPanel")]
		bool IsModalPanel { get; }

		//- (BOOL)isResizable;
		[Export ("isResizable")]
		bool IsResizable { get; }

		//- (BOOL)isZoomable;
		[Export ("isZoomable")]
		bool IsZoomable { get; }

		//- (NSInteger)orderedIndex;
		[Export ("orderedIndex")]
		int OrderedIndex { get; set; }

		//- (id)handleCloseScriptCommand:(NSCloseCommand *)command;
		[Export ("handleCloseScriptCommand:")]
		NSWindow HandleCloseScriptCommand (NSCloseCommand command);

		//- (id)handlePrintScriptCommand:(NSScriptCommand *)command;
		[Export ("handlePrintScriptCommand:")]
		NSWindow HandlePrintScriptCommand (NSScriptCommand command);

		//- (id)handleSaveScriptCommand:(NSScriptCommand *)command;
		[Export ("handleSaveScriptCommand:")]
		NSWindow HandleSaveScriptCommand (NSScriptCommand command);

	}
}
