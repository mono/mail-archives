using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSPanel))]
	interface NSColorPanel {

		//+ (NSColorPanel *)sharedColorPanel;
		[Static, Export ("sharedColorPanel")]
		NSColorPanel SharedColorPanel { get; }

		//+ (BOOL)sharedColorPanelExists;
		[Static, Export ("sharedColorPanelExists")]
		bool SharedColorPanelExists { get; }

		//+ (BOOL)dragColor:(NSColor *)color withEvent:(NSEvent *)theEvent fromView:(NSView *)sourceView;
		[Static, Export ("dragColor:withEvent:fromView:")]
		bool DragColor (NSColor color, NSEvent theEvent, NSView sourceView);

		//+ (void)setPickerMask:(NSUInteger)mask;
		[Static, Export ("setPickerMask:")]
		void SetPickerMask (uint mask);

		//+ (void)setPickerMode:(NSColorPanelMode)mode;
		[Static, Export ("setPickerMode:")]
		void SetPickerMode (NSColorPanelMode mode);

		//- (NSView *)accessoryView;
		[Export ("accessoryView")]
		NSView AccessoryView { get; set; }

		//- (void)setContinuous:(BOOL)flag;
		[Export ("setContinuous:")]
		void SetContinuous (bool flag);

		//- (BOOL)isContinuous;
		[Export ("isContinuous")]
		bool IsContinuous { get; }

		//- (BOOL)showsAlpha;
		[Export ("showsAlpha")]
		bool ShowsAlpha { get; set; }

		//- (NSColorPanelMode)mode;
		[Export ("mode")]
		NSColorPanelMode Mode { get; set; }

		//- (NSColor *)color;
		[Export ("color")]
		NSColor Color { get; set; }

		//- (CGFloat)alpha;
		[Export ("alpha")]
		float Alpha { get; }

		//- (void)setAction:(SEL)aSelector;
		[Export ("setAction:")]
		void SetAction (Selector aSelector);

		//- (void)setTarget:(id)anObject;
		[Export ("setTarget:")]
		void SetTarget (NSObject anObject);

		//- (void)attachColorList:(NSColorList *)colorList;
		[Export ("attachColorList:")]
		void AttachColorList (NSColorList colorList);

		//- (void)detachColorList:(NSColorList *)colorList;
		[Export ("detachColorList:")]
		void DetachColorList (NSColorList colorList);

	}
}
