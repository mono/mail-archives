using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSObject))]
	interface NSSound {

		//+ (id)soundNamed:(NSString *)name;
		[Static, Export ("soundNamed:")]
		NSSound SoundNamed (string name);

		//- (id)initWithContentsOfURL:(NSURL *)url byReference:(BOOL)byRef;
		[Export ("initWithContentsOfURL:byReference:")]
		IntPtr Constructor (NSUrl url, bool byRef);

		//- (id)initWithContentsOfFile:(NSString *)path byReference:(BOOL)byRef;
		[Export ("initWithContentsOfFile:byReference:")]
		IntPtr Constructor (string path, bool byRef);

		//- (id)initWithData:(NSData *)data;
		[Export ("initWithData:")]
		IntPtr Constructor (NSData data);

		//- (BOOL)setName:(NSString *)string;
		[Export ("setName:")]
		bool SetName (string string1);

		//- (NSString *)name;
		[Export ("name")]
		string Name { get; }

		//+ (BOOL)canInitWithPasteboard:(NSPasteboard *)pasteboard;
		[Static, Export ("canInitWithPasteboard:")]
		bool CanInitWithPasteboard (NSPasteboard pasteboard);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//+ (NSArray*)soundUnfilteredTypes;
		[Static, Export ("soundUnfilteredTypes")]
		NSArray SoundUnfilteredTypes { get; }

//#endif
		//- (id)initWithPasteboard:(NSPasteboard *)pasteboard;
		[Export ("initWithPasteboard:")]
		IntPtr Constructor (NSPasteboard pasteboard);

		//- (void)writeToPasteboard:(NSPasteboard *)pasteboard;
		[Export ("writeToPasteboard:")]
		void WriteToPasteboard (NSPasteboard pasteboard);

		//- (BOOL)play;		
		[Export ("play")]
		bool Play { get; }

		//- (BOOL)pause;		
		[Export ("pause")]
		bool Pause { get; }

		//- (BOOL)resume;		
		[Export ("resume")]
		bool Resume { get; }

		//- (BOOL)stop;
		[Export ("stop")]
		bool Stop { get; }

		//- (BOOL)isPlaying;
		[Export ("isPlaying")]
		bool IsPlaying { get; }

		//- (id)delegate;
		[Export ("delegate")]
		NSSound Delegate { get; }

		//- (void)setDelegate:(id)aDelegate;
		[Export ("setDelegate:")]
		void SetDelegate (NSObject aDelegate);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (NSTimeInterval)duration;
		[Export ("duration")]
		double Duration { get; }

		//- (float)volume;
		[Export ("volume")]
		float Volume { get; set; }

		//- (NSTimeInterval)currentTime;
		[Export ("currentTime")]
		double CurrentTime { get; set; }

		//- (BOOL)loops;
		[Export ("loops")]
		bool Loops { get; set; }

		//- (NSString *)playbackDeviceIdentifier;
		[Export ("playbackDeviceIdentifier")]
		string PlaybackDeviceIdentifier { get; set; }

		//- (NSArray *)channelMapping;
		[Export ("channelMapping")]
		NSArray ChannelMapping { get; set; }

//#endif
		////+ (NSArray *)soundUnfilteredFileTypes;
		//[Static, Export ("soundUnfilteredFileTypes")]
		//NSArray SoundUnfilteredFileTypes { get; }

		////+ (NSArray *)soundUnfilteredPasteboardTypes;
		//[Static, Export ("soundUnfilteredPasteboardTypes")]
		//NSArray SoundUnfilteredPasteboardTypes { get; }

	}
}
