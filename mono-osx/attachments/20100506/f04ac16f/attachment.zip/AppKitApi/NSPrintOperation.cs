using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSObject))]
	interface NSPrintOperation {

		//+ (NSPrintOperation *)printOperationWithView:(NSView *)view printInfo:(NSPrintInfo *)printInfo;
		[Static, Export ("printOperationWithView:printInfo:")]
		NSPrintOperation PrintOperationWithView (NSView view, NSPrintInfo printInfo);

		//+ (NSPrintOperation *)PDFOperationWithView:(NSView *)view insideRect:(NSRect)rect toData:(NSMutableData *)data printInfo:(NSPrintInfo *)printInfo;
		[Static, Export ("PDFOperationWithView:insideRect:toData:printInfo:")]
		NSPrintOperation PDFOperationWithView (NSView view, RectangleF rect, NSMutableData data, NSPrintInfo printInfo);

		//+ (NSPrintOperation *)PDFOperationWithView:(NSView *)view insideRect:(NSRect)rect toPath:(NSString *)path printInfo:(NSPrintInfo *)printInfo;
		[Static, Export ("PDFOperationWithView:insideRect:toPath:printInfo:")]
		NSPrintOperation PDFOperationWithView (NSView view, RectangleF rect, string path, NSPrintInfo printInfo);

		//+ (NSPrintOperation *)EPSOperationWithView:(NSView *)view insideRect:(NSRect)rect toData:(NSMutableData *)data printInfo:(NSPrintInfo *)printInfo;
		[Static, Export ("EPSOperationWithView:insideRect:toData:printInfo:")]
		NSPrintOperation EPSOperationWithView (NSView view, RectangleF rect, NSMutableData data, NSPrintInfo printInfo);

		//+ (NSPrintOperation *)EPSOperationWithView:(NSView *)view insideRect:(NSRect)rect toPath:(NSString *)path printInfo:(NSPrintInfo *)printInfo;
		[Static, Export ("EPSOperationWithView:insideRect:toPath:printInfo:")]
		NSPrintOperation EPSOperationWithView (NSView view, RectangleF rect, string path, NSPrintInfo printInfo);

		//+ (NSPrintOperation *)printOperationWithView:(NSView *)view;
		[Static, Export ("printOperationWithView:")]
		NSPrintOperation PrintOperationWithView (NSView view);

		//+ (NSPrintOperation *)PDFOperationWithView:(NSView *)view insideRect:(NSRect)rect toData:(NSMutableData *)data;
		[Static, Export ("PDFOperationWithView:insideRect:toData:")]
		NSPrintOperation PDFOperationWithView (NSView view, RectangleF rect, NSMutableData data);

		//+ (NSPrintOperation *)EPSOperationWithView:(NSView *)view insideRect:(NSRect)rect toData:(NSMutableData *)data;
		[Static, Export ("EPSOperationWithView:insideRect:toData:")]
		NSPrintOperation EPSOperationWithView (NSView view, RectangleF rect, NSMutableData data);

		//+ (NSPrintOperation *)currentOperation;
		[Static, Export ("currentOperation")]
		NSPrintOperation CurrentOperation { get; }

		//+ (void)setCurrentOperation:(NSPrintOperation *)operation;
		[Static, Export ("setCurrentOperation:")]
		void SetCurrentOperation (NSPrintOperation operation);

		//- (BOOL)isCopyingOperation;
		[Export ("isCopyingOperation")]
		bool IsCopyingOperation { get; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (NSString *)jobTitle;
		[Export ("jobTitle")]
		string JobTitle { get; set; }

//#endif
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (BOOL)showsPrintPanel;
		[Export ("showsPrintPanel")]
		bool ShowsPrintPanel { get; set; }

		//- (BOOL)showsProgressPanel;
		[Export ("showsProgressPanel")]
		bool ShowsProgressPanel { get; set; }

//#endif
		//- (NSPrintPanel *)printPanel;
		[Export ("printPanel")]
		NSPrintPanel PrintPanel { get; set; }

		//- (BOOL)canSpawnSeparateThread;
		[Export ("canSpawnSeparateThread")]
		bool CanSpawnSeparateThread { get; set; }

		//- (NSPrintingPageOrder)pageOrder;
		[Export ("pageOrder")]
		NSPrintingPageOrder PageOrder { get; set; }

		//- (void)runOperationModalForWindow:(NSWindow *)docWindow delegate:(id)delegate didRunSelector:(SEL)didRunSelector contextInfo:(void *)contextInfo;
		[Export ("runOperationModalForWindow:delegate:didRunSelector:contextInfo:")]
		void RunOperationModalForWindow (NSWindow docWindow, NSObject delegate1, Selector didRunSelector, IntPtr contextInfo);

		//- (BOOL)runOperation;
		[Export ("runOperation")]
		bool RunOperation { get; }

		//- (NSView *)view;
		[Export ("view")]
		NSView View { get; }

		//- (NSPrintInfo *)printInfo;
		[Export ("printInfo")]
		NSPrintInfo PrintInfo { get; set; }

		//- (NSGraphicsContext *)context;
		[Export ("context")]
		NSGraphicsContext Context { get; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (NSRange)pageRange;
		[Export ("pageRange")]
		NSRange PageRange { get; }

//#endif
		//- (NSInteger)currentPage;
		[Export ("currentPage")]
		int CurrentPage { get; }

		//- (NSGraphicsContext *)createContext;
		[Export ("createContext")]
		NSGraphicsContext CreateContext { get; }

		//- (void)destroyContext;
		[Export ("destroyContext")]
		void DestroyContext ();

		//- (BOOL)deliverResult;
		[Export ("deliverResult")]
		bool DeliverResult { get; }

		//- (void)cleanUpOperation;
		[Export ("cleanUpOperation")]
		void CleanUpOperation ();

		////- (NSView *)accessoryView;
		//[Export ("accessoryView")]
		//NSView AccessoryView { get; set; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_2
		////- (NSString *)jobStyleHint;
		//[Export ("jobStyleHint")]
		//string JobStyleHint { get; set; }

//#endif
		////- (BOOL)showPanels;
		//[Export ("showPanels")]
		//bool ShowPanels { get; set; }

	}
}
