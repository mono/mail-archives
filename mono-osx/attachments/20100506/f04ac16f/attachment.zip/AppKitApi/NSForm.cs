using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSMatrix))]
	interface NSForm {

		//- (NSInteger)indexOfSelectedItem;
		[Export ("indexOfSelectedItem")]
		int IndexOfSelectedItem { get; }

		//- (void)setEntryWidth:(CGFloat)width;
		[Export ("setEntryWidth:")]
		void SetEntryWidth (float width);

		//- (void)setInterlineSpacing:(CGFloat)spacing;
		[Export ("setInterlineSpacing:")]
		void SetInterlineSpacing (float spacing);

		//- (void)setBordered:(BOOL)flag;
		[Export ("setBordered:")]
		void SetBordered (bool flag);

		//- (void)setBezeled:(BOOL)flag;
		[Export ("setBezeled:")]
		void SetBezeled (bool flag);

		//- (void)setTitleAlignment:(NSTextAlignment)mode;
		[Export ("setTitleAlignment:")]
		void SetTitleAlignment (NSTextAlignment mode);

		//- (void)setTextAlignment:(NSTextAlignment)mode;
		[Export ("setTextAlignment:")]
		void SetTextAlignment (NSTextAlignment mode);

		//- (void)setTitleFont:(NSFont *)fontObj;
		[Export ("setTitleFont:")]
		void SetTitleFont (NSFont fontObj);

		//- (void)setTextFont:(NSFont *)fontObj;
		[Export ("setTextFont:")]
		void SetTextFont (NSFont fontObj);

		//- (id)cellAtIndex:(NSInteger)index;
		[Export ("cellAtIndex:")]
		NSForm CellAtIndex (int index);

		//- (void)drawCellAtIndex:(NSInteger)index;
		[Export ("drawCellAtIndex:")]
		void DrawCellAtIndex (int index);

		//- (NSFormCell *)addEntry:(NSString *)title;
		[Export ("addEntry:")]
		NSFormCell AddEntry (string title);

		//- (NSFormCell *)insertEntry:(NSString *)title atIndex:(NSInteger)index;
		[Export ("insertEntry:atIndex:")]
		NSFormCell InsertEntry (string title, int index);

		//- (void)removeEntryAtIndex:(NSInteger)index;
		[Export ("removeEntryAtIndex:")]
		void RemoveEntryAtIndex (int index);

		//- (NSInteger)indexOfCellWithTag:(NSInteger)aTag;
		[Export ("indexOfCellWithTag:")]
		int IndexOfCellWithTag (int aTag);

		//- (void)selectTextAtIndex:(NSInteger)index;
		[Export ("selectTextAtIndex:")]
		void SelectTextAtIndex (int index);

		//- (void)setFrameSize:(NSSize)newSize;
		[Export ("setFrameSize:")]
		void SetFrameSize (NSSize newSize);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (void)setTitleBaseWritingDirection:(NSWritingDirection)writingDirection;
		[Export ("setTitleBaseWritingDirection:")]
		void SetTitleBaseWritingDirection (NSWritingDirection writingDirection);

		//- (void)setTextBaseWritingDirection:(NSWritingDirection)writingDirection;
		[Export ("setTextBaseWritingDirection:")]
		void SetTextBaseWritingDirection (NSWritingDirection writingDirection);

//#endif 
	}
}
