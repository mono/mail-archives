using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSObject))]
	interface NSSpeechSynthesizer {

		//- (id)initWithVoice:(NSString *)voice;
		[Export ("initWithVoice:")]
		IntPtr Constructor (string voice);

		//- (BOOL)startSpeakingString:(NSString *)string;
		[Export ("startSpeakingString:")]
		bool StartSpeakingString (string string1);

		//- (BOOL)startSpeakingString:(NSString *)string toURL:(NSURL *)url;
		[Export ("startSpeakingString:toURL:")]
		bool StartSpeakingString (string string1, NSUrl url);

		//- (BOOL)isSpeaking;
		[Export ("isSpeaking")]
		bool IsSpeaking { get; }

		//- (void)stopSpeaking;
		[Export ("stopSpeaking")]
		void StopSpeaking ();

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (void)stopSpeakingAtBoundary:(NSSpeechBoundary)boundary;
		[Export ("stopSpeakingAtBoundary:")]
		void StopSpeakingAtBoundary (NSSpeechBoundary boundary);

		//- (void)pauseSpeakingAtBoundary:(NSSpeechBoundary)boundary;
		[Export ("pauseSpeakingAtBoundary:")]
		void PauseSpeakingAtBoundary (NSSpeechBoundary boundary);

		//- (void)continueSpeaking;
		[Export ("continueSpeaking")]
		void ContinueSpeaking ();

//#endif
		//- (id)delegate;
		[Export ("delegate")]
		NSSpeechSynthesizer Delegate { get; }

		//- (void)setDelegate:(id)anObject;
		[Export ("setDelegate:")]
		void SetDelegate (NSObject anObject);

		//- (NSString *)voice;
		[Export ("voice")]
		string Voice { get; }

		//- (BOOL)setVoice:(NSString *)voice;
		[Export ("setVoice:")]
		bool SetVoice (string voice);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (float)rate;
		[Export ("rate")]
		float Rate { get; set; }

		//- (float)volume;
		[Export ("volume")]
		float Volume { get; set; }

//#endif
		//- (BOOL)usesFeedbackWindow;
		[Export ("usesFeedbackWindow")]
		bool UsesFeedbackWindow { get; set; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (void)addSpeechDictionary:(NSDictionary*)speechDictionary;
		[Export ("addSpeechDictionary:")]
		void AddSpeechDictionary (NSDictionary speechDictionary);

		//- (NSString *)phonemesFromText:(NSString *)text;
		[Export ("phonemesFromText:")]
		string PhonemesFromText (string text);

		//- (id)objectForProperty:(NSString *)property error:(NSError **)outError;
		[Export ("objectForProperty:error:")]
		NSSpeechSynthesizer ObjectForProperty (string property, NSError outError);

		//- (BOOL)setObject:(id)object forProperty:(NSString *)property error:(NSError **)outError;
		[Export ("setObject:forProperty:error:")]
		bool SetObject (NSObject object1, string property, NSError outError);

//#endif
		//+ (BOOL)isAnyApplicationSpeaking;
		[Static, Export ("isAnyApplicationSpeaking")]
		bool IsAnyApplicationSpeaking { get; }

		//+ (NSString *)defaultVoice;
		[Static, Export ("defaultVoice")]
		string DefaultVoice { get; }

		//+ (NSArray *)availableVoices;
		[Static, Export ("availableVoices")]
		NSArray AvailableVoices { get; }

		//+ (NSDictionary *)attributesForVoice:(NSString*)voice;
		[Static, Export ("attributesForVoice:")]
		NSDictionary AttributesForVoice (string voice);

	}
}
