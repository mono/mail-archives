
namespace MonoMac.Foundation
{
	public enum EnumNameNotFound0  // in AppKitErrors.h
	{
		NSTextReadInapplicableDocumentTypeError = 65806,
		NSTextWriteInapplicableDocumentTypeError = 66062,
		NSTextReadWriteErrorMinimum = 65792,
		NSTextReadWriteErrorMaximum = 66303,
		NSServiceApplicationNotFoundError = 66560,
		NSServiceApplicationLaunchFailedError = 66561,
		NSServiceRequestTimedOutError = 66562,
		NSServiceInvalidPasteboardDataError = 66563,
		NSServiceMalformedServiceDictionaryError = 66564,
		NSServiceMiscellaneousError = 66800,
		NSServiceErrorMinimum = 66560,
		NSServiceErrorMaximum = 66817,
//#endif
	}
	public enum NSAlertStyle  // in NSAlert.h
	{
		NSWarningAlertStyle = 0,
		NSInformationalAlertStyle = 1,
		NSCriticalAlertStyle = 2
	}
	public enum NSAnimationCurve  // in NSAnimation.h
	{
		NSAnimationEaseInOut,
		NSAnimationEaseIn,
		NSAnimationEaseOut,
		NSAnimationLinear
	}
	public enum NSAnimationBlockingMode  // in NSAnimation.h
	{
		NSAnimationBlocking,
		NSAnimationNonblocking,
		NSAnimationNonblockingThreaded
	}
	public enum EnumNameNotFound1  // in NSApplication.h
	{
		NSRunStoppedResponse			= (-1000),
		NSRunAbortedResponse			= (-1001),
		NSRunContinuesResponse		= (-1002)
	}
	public enum EnumNameNotFound2  // in NSApplication.h
	{
		NSUpdateWindowsRunLoopOrdering		= 500000
	}
	public enum NSApplicationTerminateReply  // in NSApplication.h
	{
		NSTerminateCancel = 0,
		NSTerminateNow = 1,
		NSTerminateLater = 2
	}
	public enum NSApplicationPrintReply  // in NSApplication.h
	{
		NSPrintingCancelled = 0,
		NSPrintingSuccess = 1,
		NSPrintingFailure = 3,
		NSPrintingReplyLater = 2
	}
	public enum EnumNameNotFound3  // in NSAttributedString.h
	{
		NSUnderlineStyleNone                = 0x00,
		NSUnderlineStyleSingle              = 0x01,
		NSUnderlineStyleThick               = 0x02,
		NSUnderlineStyleDouble              = 0x09
	}
	public enum EnumNameNotFound4  // in NSAttributedString.h
	{
		NSUnderlinePatternSolid             = 0x0000,
		NSUnderlinePatternDot               = 0x0100,
		NSUnderlinePatternDash              = 0x0200,
		NSUnderlinePatternDashDot           = 0x0300,
		NSUnderlinePatternDashDotDot        = 0x0400
	}
	public enum EnumNameNotFound5  // in NSAttributedString.h
	{
		NSSpellingStateSpellingFlag = (1 << 0),
		NSSpellingStateGrammarFlag  = (1 << 1),
//#endif
	}
	public enum EnumNameNotFound6  // in NSAttributedString.h
	{
		NSNoUnderlineStyle = 0,
		NSSingleUnderlineStyle
	}
	public enum NSLineCapStyle  // in NSBezierPath.h
	{
		NSButtLineCapStyle = 0,
		NSRoundLineCapStyle = 1,
		NSSquareLineCapStyle = 2
	}
	public enum NSLineJoinStyle  // in NSBezierPath.h
	{
		NSMiterLineJoinStyle = 0,
		NSRoundLineJoinStyle = 1,
		NSBevelLineJoinStyle = 2
	}
	public enum NSWindingRule  // in NSBezierPath.h
	{
		NSNonZeroWindingRule = 0,
		NSEvenOddWindingRule = 1
	}
	public enum NSBezierPathElement  // in NSBezierPath.h
	{
		NSMoveToBezierPathElement,
		NSLineToBezierPathElement,
		NSCurveToBezierPathElement,
		NSClosePathBezierPathElement
	}
	public enum NSTIFFCompression  // in NSBitmapImageRep.h
	{
		NSTIFFCompressionNone		= 1,
		NSTIFFCompressionCCITTFAX3		= 3,
		NSTIFFCompressionCCITTFAX4		= 4,
		NSTIFFCompressionLZW		= 5,
		NSTIFFCompressionJPEG		= 6,
		NSTIFFCompressionNEXT		= 32766,
		NSTIFFCompressionPackBits		= 32773,
		NSTIFFCompressionOldJPEG		= 32865
	}
	public enum NSBitmapImageFileType  // in NSBitmapImageRep.h
	{
		NSTIFFFileType,
		NSBMPFileType,
		NSGIFFileType,
		NSJPEGFileType,
		NSPNGFileType,
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		NSJPEG2000FileType,
//#endif
	}
	public enum NSImageRepLoadStatus  // in NSBitmapImageRep.h
	{
		NSImageRepLoadStatusUnknownType     = -1,
		NSImageRepLoadStatusReadingHeader   = -2,
		NSImageRepLoadStatusWillNeedAllData = -3,
		NSImageRepLoadStatusInvalidData     = -4,
		NSImageRepLoadStatusUnexpectedEOF   = -5,
		NSImageRepLoadStatusCompleted       = -6
	}
	public enum NSBitmapFormat  // in NSBitmapImageRep.h
	{
		NSAlphaFirstBitmapFormat            = 1 << 0,
		NSAlphaNonpremultipliedBitmapFormat = 1 << 1,
		NSFloatingPointSamplesBitmapFormat  = 1 << 2
	}
	public enum NSTitlePosition  // in NSBox.h
	{
		NSNoTitle				= 0,
		NSAboveTop				= 1,
		NSAtTop				= 2,
		NSBelowTop				= 3,
		NSAboveBottom			= 4,
		NSAtBottom				= 5,
		NSBelowBottom			= 6
	}
	public enum NSBoxType  // in NSBox.h
	{
		NSBoxPrimary	= 0,
		NSBoxSecondary	= 1,
		NSBoxSeparator	= 2,
		NSBoxOldStyle	= 3,
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		NSBoxCustom		= 4,
//#endif
	}
	public enum NSBrowserColumnResizingType  // in NSBrowser.h
	{
		NSBrowserNoColumnResizing = 0,
		NSBrowserAutoColumnResizing = 1,
		NSBrowserUserColumnResizing = 2
	}
	public enum NSBrowserDropOperation  // in NSBrowser.h
	{
		NSBrowserDropOn,
		NSBrowserDropAbove
	}
	public enum NSButtonType  // in NSButtonCell.h
	{
		NSMomentaryLightButton		= 0,
		NSPushOnPushOffButton		= 1,
		NSToggleButton			= 2,
		NSSwitchButton			= 3,
		NSRadioButton			= 4,
		NSMomentaryChangeButton		= 5,
		NSOnOffButton			= 6,
		NSMomentaryPushInButton		= 7,
		NSMomentaryPushButton		= 0,
		NSMomentaryLight			= 7
	}
	public enum NSBezelStyle  // in NSButtonCell.h
	{
		NSRoundedBezelStyle          = 1,
		NSRegularSquareBezelStyle    = 2,
		NSThickSquareBezelStyle      = 3,
		NSThickerSquareBezelStyle    = 4,
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		NSDisclosureBezelStyle       = 5,
//#endif
		NSShadowlessSquareBezelStyle = 6,
		NSCircularBezelStyle         = 7,
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		NSTexturedSquareBezelStyle   = 8,
		NSHelpButtonBezelStyle       = 9,
//#endif
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		NSSmallSquareBezelStyle       = 10,
		NSTexturedRoundedBezelStyle   = 11,
		NSRoundRectBezelStyle         = 12,
		NSRecessedBezelStyle          = 13,
		NSRoundedDisclosureBezelStyle = 14,
//#endif
		NSSmallIconButtonBezelStyle  = 2
	}
	public enum NSGradientType  // in NSButtonCell.h
	{
		NSGradientNone          = 0,
		NSGradientConcaveWeak   = 1,
		NSGradientConcaveStrong = 2,
		NSGradientConvexWeak    = 3,
		NSGradientConvexStrong  = 4
	}
	public enum EnumNameNotFound7  // in NSCell.h
	{
		NSAnyType				= 0,
		NSIntType				= 1,
		NSPositiveIntType			= 2,
		NSFloatType				= 3,
		NSPositiveFloatType			= 4,
		NSDoubleType			= 6,
		NSPositiveDoubleType		= 7
	}
	public enum NSCellType  // in NSCell.h
	{
		NSNullCellType			= 0,
		NSTextCellType			= 1,
		NSImageCellType			= 2
	}
	public enum NSCellAttribute  // in NSCell.h
	{
		NSCellDisabled			= 0,
		NSCellState				= 1,
		NSPushInCell			= 2,
		NSCellEditable			= 3,
		NSChangeGrayCell			= 4,
		NSCellHighlighted			= 5,
		NSCellLightsByContents		= 6,
		NSCellLightsByGray			= 7,
		NSChangeBackgroundCell		= 8,
		NSCellLightsByBackground		= 9,
		NSCellIsBordered			= 10,
		NSCellHasOverlappingImage		= 11,
		NSCellHasImageHorizontal		= 12,
		NSCellHasImageOnLeftOrBottom	= 13,
		NSCellChangesContents		= 14,
		NSCellIsInsetButton			= 15,
		NSCellAllowsMixedState		= 16
	}
	public enum NSCellImagePosition  // in NSCell.h
	{
		NSNoImage				= 0,
		NSImageOnly				= 1,
		NSImageLeft				= 2,
		NSImageRight			= 3,
		NSImageBelow			= 4,
		NSImageAbove			= 5,
		NSImageOverlaps			= 6
	}
	public enum EnumNameNotFound8  // in NSCell.h
	{
		NSScaleProportionally = 0,
		NSScaleToFit,
		NSScaleNone,
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
	}
	public enum NSImageScaling  // in NSCell.h
	{
		NSImageScaleProportionallyDown = 0,
		NSImageScaleAxesIndependently,
		NSImageScaleNone,
		NSImageScaleProportionallyUpOrDown,
//#endif
	}
	public enum NSCellStateValue  // in NSCell.h
	{
		NSMixedState = -1,
		NSOffState   =  0,
		NSOnState    =  1
	}
	public enum EnumNameNotFound9  // in NSCell.h
	{
		NSNoCellMask			= 0,
		NSContentsCellMask			= 1,
		NSPushInCellMask			= 2,
		NSChangeGrayCellMask		= 4,
		NSChangeBackgroundCellMask		= 8
	}
	public enum NSControlTint  // in NSCell.h
	{
		NSDefaultControlTint  = 0,
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		NSBlueControlTint     = 1,
		NSGraphiteControlTint = 6,
//#endif
		NSClearControlTint    = 7
	}
	public enum NSControlSize  // in NSCell.h
	{
		NSRegularControlSize,
		NSSmallControlSize,
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		NSMiniControlSize,
//#endif
	}
	public enum EnumNameNotFound10  // in NSCell.h
	{
		NSCellHitNone = 0,
		NSCellHitContentArea = 1 << 0,
		NSCellHitEditableTextArea = 1 << 1,
		NSCellHitTrackableArea = 1 << 2
	}
	public enum NSBackgroundStyle  // in NSCell.h
	{
		NSBackgroundStyleLight = 0,
		NSBackgroundStyleDark,
		NSBackgroundStyleRaised,
		NSBackgroundStyleLowered
	}
	public enum NSNoModeColorPanel  // in NSColorPanel.h
	{
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		NSNoModeColorPanel                  = -1,
//#endif
		NSGrayModeColorPanel		= 0,
		NSRGBModeColorPanel			= 1,
		NSCMYKModeColorPanel		= 2,
		NSHSBModeColorPanel			= 3,
		NSCustomPaletteModeColorPanel	= 4,
		NSColorListModeColorPanel		= 5,
		NSWheelModeColorPanel		= 6,
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_2
		NSCrayonModeColorPanel		= 7,
//#endif
	}
	public enum EnumNameNotFound12  // in NSColorPanel.h
	{
		NSColorPanelGrayModeMask		= 0x00000001,
		NSColorPanelRGBModeMask		= 0x00000002,
		NSColorPanelCMYKModeMask		= 0x00000004,
		NSColorPanelHSBModeMask		= 0x00000008,
		NSColorPanelCustomPaletteModeMask	= 0x00000010,
		NSColorPanelColorListModeMask	= 0x00000020,
		NSColorPanelWheelModeMask		= 0x00000040,
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_2
		NSColorPanelCrayonModeMask		= 0x00000080,
//#endif
		NSColorPanelAllModesMask		= 0x0000ffff
	}
	public enum NSColorSpaceModel  // in NSColorSpace.h
	{
		NSUnknownColorSpaceModel = -1,
		NSGrayColorSpaceModel,
		NSRGBColorSpaceModel,
		NSCMYKColorSpaceModel,
		NSLABColorSpaceModel,
		NSDeviceNColorSpaceModel,
		NSIndexedColorSpaceModel,
		NSPatternColorSpaceModel
	}
	public enum NSDatePickerStyle  // in NSDatePickerCell.h
	{
		NSTextFieldAndStepperDatePickerStyle    = 0,
		NSClockAndCalendarDatePickerStyle       = 1,
		NSTextFieldDatePickerStyle              = 2
	}
	public enum NSDatePickerMode  // in NSDatePickerCell.h
	{
		NSSingleDateMode = 0,
		NSRangeDateMode = 1
	}
	public enum EnumNameNotFound13  // in NSDatePickerCell.h
	{
		NSHourMinuteDatePickerElementFlag       = 0x000c,
		NSHourMinuteSecondDatePickerElementFlag = 0x000e,
		NSTimeZoneDatePickerElementFlag	    = 0x0010,
		NSYearMonthDatePickerElementFlag	    = 0x00c0,
		NSYearMonthDayDatePickerElementFlag	    = 0x00e0,
		NSEraDatePickerElementFlag		    = 0x0100
	}
	public enum NSDocumentChangeType  // in NSDocument.h
	{
		NSChangeDone = 0,
		NSChangeUndone = 1,
		NSChangeCleared = 2,
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		NSChangeRedone = 5,
//#endif
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		NSChangeReadOtherContents = 3,
		NSChangeAutosaved = 4,
//#endif
	}
	public enum NSSaveOperationType  // in NSDocument.h
	{
		NSSaveOperation = 0,
		NSSaveAsOperation = 1,
		NSSaveToOperation = 2,
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		NSAutosaveOperation = 3,
//#endif
	}
	public enum NSDragOperation // in NSDragging.h
	{
		NSDragOperationNone		= 0,
		NSDragOperationCopy		= 1,
		NSDragOperationLink		= 2,
		NSDragOperationGeneric	= 4,
		NSDragOperationPrivate	= 8,
		NSDragOperationAll_Obsolete	= 15,
		NSDragOperationMove		= 16,
		NSDragOperationDelete	= 32,
		NSDragOperationEvery	= NSUIntegerMax,
//#define NSDragOperationAll NSDragOperationAll_Obsolete
	}
	public enum NSDrawerState  // in NSDrawer.h
	{
		NSDrawerClosedState			= 0,
		NSDrawerOpeningState 		= 1,
		NSDrawerOpenState 			= 2,
		NSDrawerClosingState 		= 3
	}
	public enum NSEventType  // in NSEvent.h
	{
		NSLeftMouseDown             = 1,
		NSLeftMouseUp               = 2,
		NSRightMouseDown            = 3,
		NSRightMouseUp              = 4,
		NSMouseMoved                = 5,
		NSLeftMouseDragged          = 6,
		NSRightMouseDragged         = 7,
		NSMouseEntered              = 8,
		NSMouseExited               = 9,
		NSKeyDown                   = 10,
		NSKeyUp                     = 11,
		NSFlagsChanged              = 12,
		NSAppKitDefined             = 13,
		NSSystemDefined             = 14,
		NSApplicationDefined        = 15,
		NSPeriodic                  = 16,
		NSCursorUpdate              = 17,
		NSScrollWheel               = 22,
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		NSTabletPoint               = 23,
		NSTabletProximity           = 24,
//#endif
		NSOtherMouseDown            = 25,
		NSOtherMouseUp              = 26,
		NSOtherMouseDragged         = 27
	}
	public enum EnumNameNotFound15  // in NSEvent.h
	{
		NSLeftMouseDownMask         = 1 << NSLeftMouseDown,
		NSLeftMouseUpMask           = 1 << NSLeftMouseUp,
		NSRightMouseDownMask        = 1 << NSRightMouseDown,
		NSRightMouseUpMask          = 1 << NSRightMouseUp,
		NSMouseMovedMask            = 1 << NSMouseMoved,
		NSLeftMouseDraggedMask      = 1 << NSLeftMouseDragged,
		NSRightMouseDraggedMask     = 1 << NSRightMouseDragged,
		NSMouseEnteredMask          = 1 << NSMouseEntered,
		NSMouseExitedMask           = 1 << NSMouseExited,
		NSKeyDownMask               = 1 << NSKeyDown,
		NSKeyUpMask                 = 1 << NSKeyUp,
		NSFlagsChangedMask          = 1 << NSFlagsChanged,
		NSAppKitDefinedMask         = 1 << NSAppKitDefined,
		NSSystemDefinedMask         = 1 << NSSystemDefined,
		NSApplicationDefinedMask    = 1 << NSApplicationDefined,
		NSPeriodicMask              = 1 << NSPeriodic,
		NSCursorUpdateMask          = 1 << NSCursorUpdate,
		NSScrollWheelMask           = 1 << NSScrollWheel,
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		NSTabletPointMask           = 1 << NSTabletPoint,
		NSTabletProximityMask       = 1 << NSTabletProximity,
//#endif
		NSOtherMouseDownMask        = 1 << NSOtherMouseDown,
		NSOtherMouseUpMask          = 1 << NSOtherMouseUp,
		NSOtherMouseDraggedMask     = 1 << NSOtherMouseDragged,
		NSAnyEventMask              = NSUIntegerMax
	}
	public enum EnumNameNotFound16  // in NSEvent.h
	{
		NSAlphaShiftKeyMask         = 1 << 16,
		NSShiftKeyMask              = 1 << 17,
		NSControlKeyMask            = 1 << 18,
		NSAlternateKeyMask          = 1 << 19,
		NSCommandKeyMask            = 1 << 20,
		NSNumericPadKeyMask         = 1 << 21,
		NSHelpKeyMask               = 1 << 22,
		NSFunctionKeyMask           = 1 << 23,
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		NSDeviceIndependentModifierFlagsMask    = 0xffff0000UL,
//#endif
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
	}
	public enum NSPointingDeviceType  // in NSEvent.h
	{
		NSUnknownPointingDevice     = NX_TABLET_POINTER_UNKNOWN,
		NSPenPointingDevice         = NX_TABLET_POINTER_PEN,
		NSCursorPointingDevice      = NX_TABLET_POINTER_CURSOR,
		NSEraserPointingDevice      = NX_TABLET_POINTER_ERASER
	}
	public enum EnumNameNotFound17  // in NSEvent.h
	{
		NSPenTipMask                = NX_TABLET_BUTTON_PENTIPMASK,
		NSPenLowerSideMask          = NX_TABLET_BUTTON_PENLOWERSIDEMASK,
		NSPenUpperSideMask          = NX_TABLET_BUTTON_PENUPPERSIDEMASK,
//#endif
	}
	public enum EnumNameNotFound18  // in NSEvent.h
	{
		NSUpArrowFunctionKey        = 0xF700,
		NSDownArrowFunctionKey      = 0xF701,
		NSLeftArrowFunctionKey      = 0xF702,
		NSRightArrowFunctionKey     = 0xF703,
		NSF1FunctionKey             = 0xF704,
		NSF2FunctionKey             = 0xF705,
		NSF3FunctionKey             = 0xF706,
		NSF4FunctionKey             = 0xF707,
		NSF5FunctionKey             = 0xF708,
		NSF6FunctionKey             = 0xF709,
		NSF7FunctionKey             = 0xF70A,
		NSF8FunctionKey             = 0xF70B,
		NSF9FunctionKey             = 0xF70C,
		NSF10FunctionKey            = 0xF70D,
		NSF11FunctionKey            = 0xF70E,
		NSF12FunctionKey            = 0xF70F,
		NSF13FunctionKey            = 0xF710,
		NSF14FunctionKey            = 0xF711,
		NSF15FunctionKey            = 0xF712,
		NSF16FunctionKey            = 0xF713,
		NSF17FunctionKey            = 0xF714,
		NSF18FunctionKey            = 0xF715,
		NSF19FunctionKey            = 0xF716,
		NSF20FunctionKey            = 0xF717,
		NSF21FunctionKey            = 0xF718,
		NSF22FunctionKey            = 0xF719,
		NSF23FunctionKey            = 0xF71A,
		NSF24FunctionKey            = 0xF71B,
		NSF25FunctionKey            = 0xF71C,
		NSF26FunctionKey            = 0xF71D,
		NSF27FunctionKey            = 0xF71E,
		NSF28FunctionKey            = 0xF71F,
		NSF29FunctionKey            = 0xF720,
		NSF30FunctionKey            = 0xF721,
		NSF31FunctionKey            = 0xF722,
		NSF32FunctionKey            = 0xF723,
		NSF33FunctionKey            = 0xF724,
		NSF34FunctionKey            = 0xF725,
		NSF35FunctionKey            = 0xF726,
		NSInsertFunctionKey         = 0xF727,
		NSDeleteFunctionKey         = 0xF728,
		NSHomeFunctionKey           = 0xF729,
		NSBeginFunctionKey          = 0xF72A,
		NSEndFunctionKey            = 0xF72B,
		NSPageUpFunctionKey         = 0xF72C,
		NSPageDownFunctionKey       = 0xF72D,
		NSPrintScreenFunctionKey    = 0xF72E,
		NSScrollLockFunctionKey     = 0xF72F,
		NSPauseFunctionKey          = 0xF730,
		NSSysReqFunctionKey         = 0xF731,
		NSBreakFunctionKey          = 0xF732,
		NSResetFunctionKey          = 0xF733,
		NSStopFunctionKey           = 0xF734,
		NSMenuFunctionKey           = 0xF735,
		NSUserFunctionKey           = 0xF736,
		NSSystemFunctionKey         = 0xF737,
		NSPrintFunctionKey          = 0xF738,
		NSClearLineFunctionKey      = 0xF739,
		NSClearDisplayFunctionKey   = 0xF73A,
		NSInsertLineFunctionKey     = 0xF73B,
		NSDeleteLineFunctionKey     = 0xF73C,
		NSInsertCharFunctionKey     = 0xF73D,
		NSDeleteCharFunctionKey     = 0xF73E,
		NSPrevFunctionKey           = 0xF73F,
		NSNextFunctionKey           = 0xF740,
		NSSelectFunctionKey         = 0xF741,
		NSExecuteFunctionKey        = 0xF742,
		NSUndoFunctionKey           = 0xF743,
		NSRedoFunctionKey           = 0xF744,
		NSFindFunctionKey           = 0xF745,
		NSHelpFunctionKey           = 0xF746,
		NSModeSwitchFunctionKey     = 0xF747
	}
	public enum EnumNameNotFound19  // in NSEvent.h
	{
		NSWindowExposedEventType            = 0,
		NSApplicationActivatedEventType     = 1,
		NSApplicationDeactivatedEventType   = 2,
		NSWindowMovedEventType              = 4,
		NSScreenChangedEventType            = 8,
		NSAWTEventType                      = 16
	}
	public enum EnumNameNotFound20  // in NSEvent.h
	{
		NSPowerOffEventType             = 1,
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
	}
	public enum EnumNameNotFound21  // in NSEvent.h
	{
		NSMouseEventSubtype             = NX_SUBTYPE_DEFAULT,
		NSTabletPointEventSubtype       = NX_SUBTYPE_TABLET_POINT,
		NSTabletProximityEventSubtype   = NX_SUBTYPE_TABLET_PROXIMITY,
//#endif
	}
	public enum EnumNameNotFound22  // in NSFont.h
	{
		NSControlGlyph = 0x00FFFFFF,
		NSNullGlyph = 0x0
	}
	public enum NSMultibyteGlyphPacking  // in NSFont.h
	{
		NSNativeShortGlyphPacking = 5
	}
	public enum NSFontRenderingMode  // in NSFont.h
	{
		NSFontDefaultRenderingMode = 0,
		NSFontAntialiasedRenderingMode = 1,
		NSFontIntegerAdvancementsRenderingMode = 2,
		NSFontAntialiasedIntegerAdvancementsRenderingMode = 3
	}
	public enum EnumNameNotFound23  // in NSFont.h
	{
		NSOneByteGlyphPacking,
		NSJapaneseEUCGlyphPacking,
		NSAsciiWithDoubleByteEUCGlyphPacking,
		NSTwoByteGlyphPacking,
		NSFourByteGlyphPacking
	}
	public enum EnumNameNotFound24  // in NSFont.h
	{
		_NSGlyphRelation,
		NSGlyphBelow = 1,
		NSGlyphAbove = 2,
//#endif
	}
	public enum NSFontFamilyClass  // in NSFontDescriptor.h
	{
		NSFontUnknownClass = 0 << 28,
		NSFontOldStyleSerifsClass = 1 << 28,
		NSFontTransitionalSerifsClass = 2 << 28,
		NSFontModernSerifsClass = 3 << 28,
		NSFontClarendonSerifsClass = 4 << 28,
		NSFontSlabSerifsClass = 5 << 28,
		NSFontFreeformSerifsClass = 7 << 28,
		NSFontSansSerifClass = 8 << 28,
		NSFontOrnamentalsClass = 9 << 28,
		NSFontScriptsClass = 10 << 28,
		NSFontSymbolicClass = 12 << 28
	}
	public enum EnumNameNotFound25  // in NSFontDescriptor.h
	{
		NSFontFamilyClassMask = 0xF0000000
	}
	public enum EnumNameNotFound26  // in NSFontDescriptor.h
	{
		NSFontItalicTrait = (1 << 0),
		NSFontBoldTrait = (1 << 1),
		NSFontExpandedTrait = (1 << 5),
		NSFontCondensedTrait = (1 << 6),
		NSFontMonoSpaceTrait = (1 << 10),
		NSFontVerticalTrait = (1 << 11),
		NSFontUIOptimizedTrait = (1 << 12),
//#endif
	}
	public enum NSFontTraitMask // in NSFontManager.h
	{
		NSItalicFontMask			= 0x00000001,
		NSBoldFontMask			= 0x00000002,
		NSUnboldFontMask			= 0x00000004,
		NSNonStandardCharacterSetFontMask	= 0x00000008,
		NSNarrowFontMask			= 0x00000010,
		NSExpandedFontMask			= 0x00000020,
		NSCondensedFontMask			= 0x00000040,
		NSSmallCapsFontMask			= 0x00000080,
		NSPosterFontMask			= 0x00000100,
		NSCompressedFontMask		= 0x00000200,
		NSFixedPitchFontMask		= 0x00000400,
		NSUnitalicFontMask			= 0x01000000,
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
	}
	public enum EnumNameNotFound28  // in NSFontManager.h
	{
		NSFontCollectionApplicationOnlyMask = 1 << 0,
//#endif
	}
	public enum NSFontAction  // in NSFontManager.h
	{
		NSNoFontChangeAction		= 0,
		NSViaPanelFontAction		= 1,
		NSAddTraitFontAction		= 2,
		NSSizeUpFontAction			= 3,
		NSSizeDownFontAction		= 4,
		NSHeavierFontAction			= 5,
		NSLighterFontAction			= 6,
		NSRemoveTraitFontAction		= 7
	}
	public enum EnumNameNotFound29  // in NSFontPanel.h
	{
		NSFPPreviewButton			= 131,
		NSFPRevertButton			= 130,
		NSFPSetButton			= 132,
		NSFPPreviewField			= 128,
		NSFPSizeField			= 129,
		NSFPSizeTitle			= 133,
		NSFPCurrentField			= 134,
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
	}
	public enum EnumNameNotFound30  // in NSFontPanel.h
	{
		NSFontPanelFaceModeMask = 1 << 0,
		NSFontPanelSizeModeMask = 1 << 1,
		NSFontPanelCollectionModeMask = 1 << 2,
//#endif
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		NSFontPanelUnderlineEffectModeMask = 1<<8,
		NSFontPanelStrikethroughEffectModeMask = 1<<9,
		NSFontPanelTextColorEffectModeMask = 1<< 10,
		NSFontPanelDocumentColorEffectModeMask = 1<<11,
		NSFontPanelShadowEffectModeMask = 1<<12,
		NSFontPanelAllEffectsModeMask = 0XFFF00,
//#endif
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		NSFontPanelStandardModesMask = 0xFFFF,
		NSFontPanelAllModesMask = 0xFFFFFFFF,
//#endif
	}
	public enum EnumNameNotFound31  // in NSGlyphGenerator.h
	{
		NSShowControlGlyphs = (1 << 0),
		NSShowInvisibleGlyphs = (1 << 1),
		NSWantsBidiLevels = (1 << 2)
	}
	public enum NSCharacterCollection  // in NSGlyphInfo.h
	{
		NSIdentityMappingCharacterCollection = 0,
		NSAdobeCNS1CharacterCollection = 1,
		NSAdobeGB1CharacterCollection = 2,
		NSAdobeJapan1CharacterCollection = 3,
		NSAdobeJapan2CharacterCollection = 4,
		NSAdobeKorea1CharacterCollection = 5
	}
	public enum NSGradientDrawingOptions // in NSGradient.h
	{
		NSGradientDrawsBeforeStartingLocation =   (1 << 0),
		NSGradientDrawsAfterEndingLocation =    (1 << 1)
	}
	public enum NSCompositingOperation  // in NSGraphics.h
	{
		NSCompositeClear		= 0,
		NSCompositeCopy		= 1,
		NSCompositeSourceOver	= 2,
		NSCompositeSourceIn		= 3,
		NSCompositeSourceOut	= 4,
		NSCompositeSourceAtop	= 5,
		NSCompositeDestinationOver	= 6,
		NSCompositeDestinationIn	= 7,
		NSCompositeDestinationOut	= 8,
		NSCompositeDestinationAtop	= 9,
		NSCompositeXOR		= 10,
		NSCompositePlusDarker	= 11,
		NSCompositeHighlight	= 12,
		NSCompositePlusLighter	= 13
	}
	public enum NSBackingStoreType  // in NSGraphics.h
	{
		NSBackingStoreRetained	 = 0,
		NSBackingStoreNonretained	 = 1,
		NSBackingStoreBuffered	 = 2
	}
	public enum NSWindowOrderingMode  // in NSGraphics.h
	{
		NSWindowAbove		 =  1,
		NSWindowBelow		 = -1,
		NSWindowOut			 =  0
	}
	public enum NSFocusRingPlacement  // in NSGraphics.h
	{
		NSFocusRingOnly	 = 0,
		NSFocusRingBelow	 = 1,
		NSFocusRingAbove	 = 2
	}
	public enum NSFocusRingType  // in NSGraphics.h
	{
		NSFocusRingTypeDefault = 0,
		NSFocusRingTypeNone = 1,
		NSFocusRingTypeExterior = 2
	}
	public enum NSAnimationEffect  // in NSGraphics.h
	{
		NSAnimationEffectDisappearingItemDefault = 0,
		NSAnimationEffectPoof = 10
	}
	public enum NSImageInterpolation  // in NSGraphicsContext.h
	{
		NSImageInterpolationDefault,
		NSImageInterpolationNone,
		NSImageInterpolationLow,
		NSImageInterpolationHigh
	}
	public enum NSColorRenderingIntent  // in NSGraphicsContext.h
	{
		NSColorRenderingIntentDefault,
		NSColorRenderingIntentAbsoluteColorimetric,
		NSColorRenderingIntentRelativeColorimetric,
		NSColorRenderingIntentPerceptual,
		NSColorRenderingIntentSaturation
	}
	public enum NSImageLoadStatus  // in NSImage.h
	{
		NSImageLoadStatusCompleted,
		NSImageLoadStatusCancelled,
		NSImageLoadStatusInvalidData,
		NSImageLoadStatusUnexpectedEOF,
		NSImageLoadStatusReadError
	}
	public enum NSImageCacheMode  // in NSImage.h
	{
		NSImageCacheDefault,
		NSImageCacheAlways,
		NSImageCacheBySize,
		NSImageCacheNever
	}
	public enum NSImageAlignment  // in NSImageCell.h
	{
		NSImageAlignCenter = 0,
		NSImageAlignTop,
		NSImageAlignTopLeft,
		NSImageAlignTopRight,
		NSImageAlignLeft,
		NSImageAlignBottom,
		NSImageAlignBottomLeft,
		NSImageAlignBottomRight,
		NSImageAlignRight
	}
	public enum NSImageFrameStyle  // in NSImageCell.h
	{
		NSImageFrameNone = 0,
		NSImageFramePhoto,
		NSImageFrameGrayBezel,
		NSImageFrameGroove,
		NSImageFrameButton
	}
	public enum EnumNameNotFound33  // in NSImageRep.h
	{
		NSImageRepMatchesDevice = 0
	}
	public enum NSInterfaceStyle  // in NSInterfaceStyle.h
	{
		NSNoInterfaceStyle = 0,
		NSNextStepInterfaceStyle = 1,
		NSWindows95InterfaceStyle = 2,
		NSMacintoshInterfaceStyle = 3
	}
	public enum EnumNameNotFound34  // in NSLayoutManager.h
	{
		NSGlyphAttributeSoft        = 0,
		NSGlyphAttributeElastic     = 1,
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_2
		NSGlyphAttributeBidiLevel   = 2,
//#endif
		NSGlyphAttributeInscribe    = 5
	}
	public enum NSGlyphInscription  // in NSLayoutManager.h
	{
		NSGlyphInscribeBase         = 0,
		NSGlyphInscribeBelow        = 1,
		NSGlyphInscribeAbove        = 2,
		NSGlyphInscribeOverstrike   = 3,
		NSGlyphInscribeOverBelow    = 4
	}
	public enum NSTypesetterBehavior  // in NSLayoutManager.h
	{
		NSTypesetterLatestBehavior                  = -1,
		NSTypesetterOriginalBehavior                = 0,
		NSTypesetterBehavior_10_2_WithCompatibility = 1,
		NSTypesetterBehavior_10_2                   = 2,
		NSTypesetterBehavior_10_3                   = 3,
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		NSTypesetterBehavior_10_4                   = 4,
//#endif
	}
	public enum NSLevelIndicatorStyle  // in NSLevelIndicatorCell.h
	{
		NSRelevancyLevelIndicatorStyle,
		NSContinuousCapacityLevelIndicatorStyle,
		NSDiscreteCapacityLevelIndicatorStyle,
		NSRatingLevelIndicatorStyle
	}
	public enum NSMatrixMode  // in NSMatrix.h
	{
		NSRadioModeMatrix			= 0,
		NSHighlightModeMatrix		= 1,
		NSListModeMatrix			= 2,
		NSTrackModeMatrix			= 3
	}
	public enum NSQTMovieLoopMode  // in NSMovieView.h
	{
		NSQTMovieNormalPlayback,
		NSQTMovieLoopingPlayback,
		NSQTMovieLoopingBackAndForthPlayback
	}
public enum  NSOpenGLGlobalOption
{
	NSOpenGLGOFormatCacheSize  = 501,
	NSOpenGLGOClearFormatCache = 502,
	NSOpenGLGORetainRenderers  = 503,
	NSOpenGLGOResetLibrary     = 504
}
	public enum uint32_t  // in NSOpenGL.h
	{
		NSOpenGLPFAAllRenderers       =   1,
		NSOpenGLPFADoubleBuffer       =   5,
		NSOpenGLPFAStereo             =   6,
		NSOpenGLPFAAuxBuffers         =   7,
		NSOpenGLPFAColorSize          =   8,
		NSOpenGLPFAAlphaSize          =  11,
		NSOpenGLPFADepthSize          =  12,
		NSOpenGLPFAStencilSize        =  13,
		NSOpenGLPFAAccumSize          =  14,
		NSOpenGLPFAMinimumPolicy      =  51,
		NSOpenGLPFAMaximumPolicy      =  52,
		NSOpenGLPFAOffScreen          =  53,
		NSOpenGLPFAFullScreen         =  54,
		NSOpenGLPFASampleBuffers      =  55,
		NSOpenGLPFASamples            =  56,
		NSOpenGLPFAAuxDepthStencil    =  57,
		NSOpenGLPFAColorFloat         =  58,
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		NSOpenGLPFAMultisample        =  59,
		NSOpenGLPFASupersample        =  60,
		NSOpenGLPFASampleAlpha        =  61,
//#endif
		NSOpenGLPFARendererID         =  70,
		NSOpenGLPFASingleRenderer     =  71,
		NSOpenGLPFANoRecovery         =  72,
		NSOpenGLPFAAccelerated        =  73,
		NSOpenGLPFAClosestPolicy      =  74,
		NSOpenGLPFARobust             =  75,
		NSOpenGLPFABackingStore       =  76,
		NSOpenGLPFAMPSafe             =  78,
		NSOpenGLPFAWindow             =  80,
		NSOpenGLPFAMultiScreen        =  81,
		NSOpenGLPFACompliant          =  83,
		NSOpenGLPFAScreenMask         =  84,
		NSOpenGLPFAPixelBuffer        =  90,
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		NSOpenGLPFAAllowOfflineRenderers = 96,
//#endif
		NSOpenGLPFAVirtualScreenCount = 128
	}
public enum  NSOpenGLContextParameter
{
	NSOpenGLCPSwapRectangle       = 200,
	NSOpenGLCPSwapRectangleEnable = 201,
	NSOpenGLCPRasterizationEnable = 221,
	NSOpenGLCPSwapInterval        = 222,
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_2
	NSOpenGLCPSurfaceOrder        = 235,
	NSOpenGLCPSurfaceOpacity      = 236,
//#endif
	NSOpenGLCPStateValidation     = 301
}
	public enum EnumNameNotFound35  // in NSOutlineView.h
	{
		NSOutlineViewDropOnItemIndex = -1
	}
	public enum EnumNameNotFound36  // in NSPanel.h
	{
		NSAlertDefaultReturn		= 1,
		NSAlertAlternateReturn		= 0,
		NSAlertOtherReturn			= -1,
		NSAlertErrorReturn			= -2
	}
	public enum EnumNameNotFound37  // in NSPanel.h
	{
		NSOKButton				= 1,
		NSCancelButton			= 0
	}
	public enum EnumNameNotFound38  // in NSPanel.h
	{
		NSUtilityWindowMask			= 1 << 4,
		NSDocModalWindowMask 		= 1 << 6,
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_2
	}
	public enum EnumNameNotFound39  // in NSPanel.h
	{
		NSNonactivatingPanelMask		= 1 << 7,
//#endif
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
	}
	public enum EnumNameNotFound40  // in NSPanel.h
	{
		NSHUDWindowMask                 = 1 << 13,
//#endif
	}
	public enum NSTextTabType  // in NSParagraphStyle.h
	{
		NSLeftTabStopType = 0,
		NSRightTabStopType,
		NSCenterTabStopType,
		NSDecimalTabStopType
	}
	public enum NSLineBreakMode  // in NSParagraphStyle.h
	{
		NSLineBreakByWordWrapping = 0,
		NSLineBreakByCharWrapping,
		NSLineBreakByClipping,
		NSLineBreakByTruncatingHead,
		NSLineBreakByTruncatingTail,
		NSLineBreakByTruncatingMiddle
	}
	public enum NSPathStyle  // in NSPathCell.h
	{
		NSPathStyleStandard,
		NSPathStyleNavigationBar,
		NSPathStylePopUp
	}
	public enum NSPopUpArrowPosition  // in NSPopUpButtonCell.h
	{
		NSPopUpNoArrow = 0,
		NSPopUpArrowAtCenter = 1,
		NSPopUpArrowAtBottom = 2
	}
	public enum NSPrinterTableStatus  // in NSPrinter.h
	{
		NSPrinterTableOK = 0,
		NSPrinterTableNotFound = 1,
		NSPrinterTableError = 2
	}
	public enum NSPrintingOrientation  // in NSPrintInfo.h
	{
		NSPortraitOrientation = 0,
		NSLandscapeOrientation = 1
	}
	public enum NSPrintingPaginationMode  // in NSPrintInfo.h
	{
		NSAutoPagination = 0,
		NSFitPagination = 1,
		NSClipPagination = 2
	}
	public enum NSPrintingPageOrder  // in NSPrintOperation.h
	{
		NSDescendingPageOrder		= -1,
		NSSpecialPageOrder			= 0,
		NSAscendingPageOrder		= 1,
		NSUnknownPageOrder			= 2
	}
	public enum NSPrintPanelOptions  // in NSPrintPanel.h
	{
		NSPrintPanelShowsCopies = 0x01,
		NSPrintPanelShowsPageRange = 0x02,
		NSPrintPanelShowsPaperSize = 0x04,
		NSPrintPanelShowsOrientation = 0x08,
		NSPrintPanelShowsScaling = 0x10,
		NSPrintPanelShowsPageSetupAccessory = 0x100,
		NSPrintPanelShowsPreview = 0x20000
	}
	public enum NSProgressIndicatorThickness  // in NSProgressIndicator.h
	{
		NSProgressIndicatorPreferredThickness 	= 14,
		NSProgressIndicatorPreferredSmallThickness 	= 10,
		NSProgressIndicatorPreferredLargeThickness	= 18,
		NSProgressIndicatorPreferredAquaThickness	= 12
	}
	public enum NSProgressIndicatorStyle  // in NSProgressIndicator.h
	{
		NSProgressIndicatorBarStyle = 0,
		NSProgressIndicatorSpinningStyle = 1
	}
	public enum NSRuleEditorNestingMode  // in NSRuleEditor.h
	{
		NSRuleEditorNestingModeSingle,
		NSRuleEditorNestingModeList,
		NSRuleEditorNestingModeCompound,
		NSRuleEditorNestingModeSimple
	}
	public enum NSRuleEditorRowType  // in NSRuleEditor.h
	{
		NSRuleEditorRowTypeSimple,
		NSRuleEditorRowTypeCompound
	}
	public enum NSRulerOrientation  // in NSRulerView.h
	{
		NSHorizontalRuler,
		NSVerticalRuler
	}
	public enum __SPFlags  // in NSSavePanel.h
	{
		NSFileHandlingPanelCancelButton	= NSCancelButton,
		NSFileHandlingPanelOKButton		= NSOKButton
	}
	public enum NSScrollArrowPosition  // in NSScroller.h
	{
		NSScrollerArrowsMaxEnd		= 0,
		NSScrollerArrowsMinEnd		= 1,
		NSScrollerArrowsDefaultSetting	= 0,
		NSScrollerArrowsNone	       	= 2
	}
	public enum NSUsableScrollerParts  // in NSScroller.h
	{
		NSNoScrollerParts			= 0,
		NSOnlyScrollerArrows		= 1,
		NSAllScrollerParts			= 2
	}
	public enum NSScrollerPart  // in NSScroller.h
	{
		NSScrollerNoPart			= 0,
		NSScrollerDecrementPage		= 1,
		NSScrollerKnob			= 2,
		NSScrollerIncrementPage		= 3,
		NSScrollerDecrementLine    		= 4,
		NSScrollerIncrementLine	 	= 5,
		NSScrollerKnobSlot			= 6
	}
	public enum NSScrollerArrow  // in NSScroller.h
	{
		NSScrollerIncrementArrow		= 0,
		NSScrollerDecrementArrow		= 1
	}
	public enum NSSegmentSwitchTracking  // in NSSegmentedCell.h
	{
		NSSegmentSwitchTrackingSelectOne = 0,
		NSSegmentSwitchTrackingSelectAny = 1,
		NSSegmentSwitchTrackingMomentary = 2
	}
	public enum NSSegmentStyle  // in NSSegmentedControl.h
	{
		NSSegmentStyleAutomatic = 0,
		NSSegmentStyleRounded = 1,
		NSSegmentStyleTexturedRounded = 2,
		NSSegmentStyleRoundRect = 3,
		NSSegmentStyleTexturedSquare = 4,
		NSSegmentStyleCapsule = 5,
		NSSegmentStyleSmallSquare = 6
	}
public enum  NSLayoutStatus
{
	NSLayoutNotDone = 0,
	NSLayoutDone,
	NSLayoutCantFit,
	NSLayoutOutOfGlyphs
}
public enum  NSGlyphLayoutMode
{
	NSGlyphLayoutAtAPoint = 0,
	NSGlyphLayoutAgainstAPoint,
	NSGlyphLayoutWithPrevious
}
public enum  NSLayoutDirection
{
	NSLayoutLeftToRight = 0,
	NSLayoutRightToLeft
}
	public enum NSTickMarkPosition  // in NSSliderCell.h
	{
		NSTickMarkBelow = 0,
		NSTickMarkAbove = 1,
		NSTickMarkLeft  = NSTickMarkAbove,
		NSTickMarkRight = NSTickMarkBelow
	}
	public enum NSSliderType  // in NSSliderCell.h
	{
		NSLinearSlider   = 0,
		NSCircularSlider = 1
	}
	public enum NSSpeechBoundary  // in NSSpeechSynthesizer.h
	{
		NSSpeechImmediateBoundary =  0,
		NSSpeechWordBoundary,
		NSSpeechSentenceBoundary
	}
	public enum NSSplitViewDividerStyle  // in NSSplitView.h
	{
		NSSplitViewDividerStyleThick = 1,
		NSSplitViewDividerStyleThin
	}
	public enum NSStringDrawingOptions  // in NSStringDrawing.h
	{
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		NSStringDrawingTruncatesLastVisibleLine = (1 << 5),
//#endif
		NSStringDrawingUsesLineFragmentOrigin = (1 << 0),
		NSStringDrawingUsesFontLeading = (1 << 1),
		NSStringDrawingDisableScreenFontSubstitution = (1 << 2),
		NSStringDrawingUsesDeviceMetrics = (1 << 3),
		NSStringDrawingOneShot = (1 << 4)
	}
	public enum NSTableViewDropOperation  // in NSTableView.h
	{
		NSTableViewDropOn,
		NSTableViewDropAbove
	}
	public enum NSTabViewType  // in NSTabView.h
	{
		NSTopTabsBezelBorder	= 0,
		NSLeftTabsBezelBorder	= 1,
		NSBottomTabsBezelBorder	= 2,
		NSRightTabsBezelBorder	= 3,
		NSNoTabsBezelBorder		= 4,
		NSNoTabsLineBorder		= 5,
		NSNoTabsNoBorder		= 6
	}
	public enum NSTabState  // in NSTabViewItem.h
	{
		NSSelectedTab = 0,
		NSBackgroundTab = 1,
		NSPressedTab = 2
	}
	public enum EnumNameNotFound41  // in NSText.h
	{
		NSEnterCharacter                = 0x0003,
		NSBackspaceCharacter            = 0x0008,
		NSTabCharacter                  = 0x0009,
		NSNewlineCharacter              = 0x000a,
		NSFormFeedCharacter             = 0x000c,
		NSCarriageReturnCharacter       = 0x000d,
		NSBackTabCharacter              = 0x0019,
		NSDeleteCharacter               = 0x007f,
		NSLineSeparatorCharacter        = 0x2028,
		NSParagraphSeparatorCharacter   = 0x2029
	}
	public enum NSTextAlignment  // in NSText.h
	{
		NSLeftTextAlignment		= 0,
		NSRightTextAlignment	= 1,
		NSCenterTextAlignment	= 2,
		NSJustifiedTextAlignment	= 3,
		NSNaturalTextAlignment	= 4
	}
	public enum NSWritingDirection  // in NSText.h
	{
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		NSWritingDirectionNatural       = -1,
//#endif
		NSWritingDirectionLeftToRight   = 0,
		NSWritingDirectionRightToLeft   = 1
	}
	public enum EnumNameNotFound42  // in NSText.h
	{
		NSIllegalTextMovement		= 0,
		NSReturnTextMovement		= 0x10,
		NSTabTextMovement			= 0x11,
		NSBacktabTextMovement		= 0x12,
		NSLeftTextMovement			= 0x13,
		NSRightTextMovement			= 0x14,
		NSUpTextMovement			= 0x15,
		NSDownTextMovement			= 0x16,
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		NSCancelTextMovement		= 0x17,
		NSOtherTextMovement			= 0,
//#endif
	}
	public enum EnumNameNotFound43  // in NSTextAttachment.h
	{
		NSAttachmentCharacter = 0xfffc
	}
	public enum NSLineSweepDirection  // in NSTextContainer.h
	{
		NSLineSweepLeft     = 0,
		NSLineSweepRight    = 1,
		NSLineSweepDown     = 2,
		NSLineSweepUp       = 3
	}
	public enum NSLineMovementDirection  // in NSTextContainer.h
	{
		NSLineDoesntMove    = 0,
		NSLineMovesLeft     = 1,
		NSLineMovesRight    = 2,
		NSLineMovesDown     = 3,
		NSLineMovesUp       = 4
	}
	public enum NSTextFieldBezelStyle  // in NSTextFieldCell.h
	{
		NSTextFieldSquareBezel  = 0,
		NSTextFieldRoundedBezel = 1
	}
	public enum EnumNameNotFound44  // in NSTextList.h
	{
		NSTextListPrependEnclosingMarker = (1 << 0)
	}
	public enum EnumNameNotFound45  // in NSTextStorage.h
	{
		NSTextStorageEditedAttributes = 1,
		NSTextStorageEditedCharacters = 2
	}
	public enum NSTextBlockValueType  // in NSTextTable.h
	{
		NSTextBlockAbsoluteValueType    = 0,
		NSTextBlockPercentageValueType  = 1
	}
	public enum NSTextBlockDimension  // in NSTextTable.h
	{
		NSTextBlockWidth            = 0,
		NSTextBlockMinimumWidth     = 1,
		NSTextBlockMaximumWidth     = 2,
		NSTextBlockHeight           = 4,
		NSTextBlockMinimumHeight    = 5,
		NSTextBlockMaximumHeight    = 6
	}
	public enum NSTextBlockLayer  // in NSTextTable.h
	{
		NSTextBlockPadding  = -1,
		NSTextBlockBorder   =  0,
		NSTextBlockMargin   =  1
	}
	public enum NSTextBlockVerticalAlignment  // in NSTextTable.h
	{
		NSTextBlockTopAlignment         = 0,
		NSTextBlockMiddleAlignment      = 1,
		NSTextBlockBottomAlignment      = 2,
		NSTextBlockBaselineAlignment    = 3
	}
	public enum NSTextTableLayoutAlgorithm  // in NSTextTable.h
	{
		NSTextTableAutomaticLayoutAlgorithm = 0,
		NSTextTableFixedLayoutAlgorithm     = 1
	}
	public enum NSSelectionGranularity  // in NSTextView.h
	{
		NSSelectByCharacter = 0,
		NSSelectByWord = 1,
		NSSelectByParagraph = 2
	}
	public enum NSSelectionAffinity  // in NSTextView.h
	{
		NSSelectionAffinityUpstream = 0,
		NSSelectionAffinityDownstream = 1
	}
	public enum NSFindPanelAction  // in NSTextView.h
	{
		NSFindPanelActionShowFindPanel = 1,
		NSFindPanelActionNext = 2,
		NSFindPanelActionPrevious = 3,
		NSFindPanelActionReplaceAll = 4,
		NSFindPanelActionReplace = 5,
		NSFindPanelActionReplaceAndFind = 6,
		NSFindPanelActionSetFindString = 7,
		NSFindPanelActionReplaceAllInSelection = 8,
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		NSFindPanelActionSelectAll = 9,
		NSFindPanelActionSelectAllInSelection = 10,
//#endif
	}
	public enum NSFindPanelSubstringMatchType  // in NSTextView.h
	{
		NSFindPanelSubstringMatchTypeContains = 0,
		NSFindPanelSubstringMatchTypeStartsWith = 1,
		NSFindPanelSubstringMatchTypeFullWord = 2,
		NSFindPanelSubstringMatchTypeEndsWith = 3
	}
	public enum NSTokenStyle  // in NSTokenFieldCell.h
	{
		NSDefaultTokenStyle,
		NSPlainTextTokenStyle,
		NSRoundedTokenStyle
	}
	public enum NSToolbarDisplayMode  // in NSToolbar.h
	{
		NSToolbarDisplayModeDefault,
		NSToolbarDisplayModeIconAndLabel,
		NSToolbarDisplayModeIconOnly,
		NSToolbarDisplayModeLabelOnly
	}
	public enum NSToolbarSizeMode  // in NSToolbar.h
	{
		NSToolbarSizeModeDefault,
		NSToolbarSizeModeRegular,
		NSToolbarSizeModeSmall
	}
	public enum EnumNameNotFound46  // in NSTrackingArea.h
	{
		NSTrackingMouseEnteredAndExited     = 0x01,
		NSTrackingMouseMoved                = 0x02,
		NSTrackingCursorUpdate 		= 0x04
	}
	public enum EnumNameNotFound47  // in NSTrackingArea.h
	{
		NSTrackingActiveWhenFirstResponder 	= 0x10,
		NSTrackingActiveInKeyWindow         = 0x20,
		NSTrackingActiveInActiveApp 	= 0x40,
		NSTrackingActiveAlways 		= 0x80
	}
	public enum NSTrackingAreaOptions  // in NSTrackingArea.h
	{
		NSTrackingAssumeInside              = 0x100,
		NSTrackingInVisibleRect             = 0x200,
		NSTrackingEnabledDuringMouseDrag    = 0x400
	}
	public enum NSTypesetterControlCharacterAction  // in NSTypesetter.h
	{
		NSTypesetterZeroAdvancementAction = (1 << 0),
		NSTypesetterWhitespaceAction = (1 << 1),
		NSTypesetterHorizontalTabAction = (1 << 2),
		NSTypesetterLineBreakAction = (1 << 3),
		NSTypesetterParagraphBreakAction = (1 << 4),
		NSTypesetterContainerBreakAction = (1 << 5)
	}
	public enum EnumNameNotFound48  // in NSView.h
	{
		NSViewNotSizable			=  0,
		NSViewMinXMargin			=  1,
		NSViewWidthSizable			=  2,
		NSViewMaxXMargin			=  4,
		NSViewMinYMargin			=  8,
		NSViewHeightSizable			= 16,
		NSViewMaxYMargin			= 32
	}
	public enum NSBorderType  // in NSView.h
	{
		NSNoBorder				= 0,
		NSLineBorder			= 1,
		NSBezelBorder			= 2,
		NSGrooveBorder			= 3
	}
	public enum EnumNameNotFound49  // in NSWindow.h
	{
		NSBorderlessWindowMask		= 0,
		NSTitledWindowMask			= 1 << 0,
		NSClosableWindowMask		= 1 << 1,
		NSMiniaturizableWindowMask		= 1 << 2,
		NSResizableWindowMask		= 1 << 3,
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_2
	}
	public enum EnumNameNotFound50  // in NSWindow.h
	{
		NSTexturedBackgroundWindowMask	= 1 << 8,
//#endif
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
	}
	public enum EnumNameNotFound51  // in NSWindow.h
	{
		NSUnscaledWindowMask		= 1 << 11
	}
	public enum EnumNameNotFound52  // in NSWindow.h
	{
		NSUnifiedTitleAndToolbarWindowMask	= 1 << 12,
//#endif
	}
	public enum EnumNameNotFound53  // in NSWindow.h
	{
		NSDisplayWindowRunLoopOrdering	= 600000,
		NSResetCursorRectsRunLoopOrdering	= 700000,
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
	}
	public enum NSWindowSharingType  // in NSWindow.h
	{
		NSWindowSharingNone = 0,
		NSWindowSharingReadOnly = 1,
		NSWindowSharingReadWrite = 2
	}
	public enum NSWindowBackingLocation  // in NSWindow.h
	{
		NSWindowBackingLocationDefault = 0,
		NSWindowBackingLocationVideoMemory = 1,
		NSWindowBackingLocationMainMemory = 2
	}
	public enum NSWindowCollectionBehavior  // in NSWindow.h
	{
		NSWindowCollectionBehaviorDefault = 0,
		NSWindowCollectionBehaviorCanJoinAllSpaces = 1 << 0,
		NSWindowCollectionBehaviorMoveToActiveSpace = 1 << 1
	}
	public enum NSSelectionDirection  // in NSWindow.h
	{
		NSDirectSelection = 0,
		NSSelectingNext,
		NSSelectingPrevious
	}
	public enum NSWindowButton  // in NSWindow.h
	{
		NSWindowCloseButton,
		NSWindowMiniaturizeButton,
		NSWindowZoomButton,
		NSWindowToolbarButton,
		NSWindowDocumentIconButton
	}
	public enum NSWorkspaceLaunchOptions // in NSWorkspace.h
	{
		NSWorkspaceLaunchAndPrint = 0x00000002,
		NSWorkspaceLaunchInhibitingBackgroundOnly = 0x00000080,
		NSWorkspaceLaunchWithoutAddingToRecents = 0x00000100,
		NSWorkspaceLaunchWithoutActivation = 0x00000200,
		NSWorkspaceLaunchAsync = 0x00010000,
		NSWorkspaceLaunchAllowingClassicStartup = 0x00020000,
		NSWorkspaceLaunchPreferringClassic = 0x00040000,
		NSWorkspaceLaunchNewInstance = 0x00080000,
		NSWorkspaceLaunchAndHide = 0x00100000,
		NSWorkspaceLaunchAndHideOthers = 0x00200000,
		NSWorkspaceLaunchDefault = NSWorkspaceLaunchAsync |
		NSWorkspaceLaunchAllowingClassicStartup,
//#endif
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
	}
	public enum NSWorkspaceIconCreationOptions // in NSWorkspace.h
	{
		NSExcludeQuickDrawElementsIconCreationOption    = 1 << 1,
		NSExclude10_4ElementsIconCreationOption	    = 1 << 2,
//#endif
	}
}
