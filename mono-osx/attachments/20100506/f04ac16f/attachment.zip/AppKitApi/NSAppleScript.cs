using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{
	interface NSAppleScript {

		//- (NSAttributedString *)richTextSource;
		[Export ("richTextSource")]
		NSAttributedString RichTextSource { get; }

	}
}
