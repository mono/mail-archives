using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSDocument))]
	interface NSPersistentDocument {

		//- (NSManagedObjectContext *)managedObjectContext;
		[Export ("managedObjectContext")]
		NSManagedObjectContext ManagedObjectContext { get; set; }

		//- (id)managedObjectModel;    
		[Export ("managedObjectModel")]
		NSPersistentDocument ManagedObjectModel { get; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (BOOL)configurePersistentStoreCoordinatorForURL:(NSURL *)url ofType:(NSString *)fileType modelConfiguration:(NSString *)configuration storeOptions:(NSDictionary *)storeOptions error:(NSError **)error;
		[Export ("configurePersistentStoreCoordinatorForURL:ofType:modelConfiguration:storeOptions:error:")]
		bool ConfigurePersistentStoreCoordinatorForUrl (NSUrl url, string fileType, string configuration, NSDictionary storeOptions, NSError error);

//#endif
		//- (NSString *)persistentStoreTypeForFileType:(NSString *)fileType;  
		[Export ("persistentStoreTypeForFileType:")]
		string PersistentStoreTypeForFileType (string fileType);

		//- (BOOL)writeToURL:(NSURL *)absoluteURL ofType:(NSString *)typeName forSaveOperation:(NSSaveOperationType)saveOperation originalContentsURL:(NSURL *)absoluteOriginalContentsURL error:(NSError **)error; 
		[Export ("writeToURL:ofType:forSaveOperation:originalContentsURL:error:")]
		bool WriteToUrl (NSUrl absoluteURL, string typeName, NSSaveOperationType saveOperation, NSUrl absoluteOriginalContentsURL, NSError error);

		//- (BOOL)readFromURL:(NSURL *)absoluteURL ofType:(NSString *)typeName error:(NSError **)error; 
		[Export ("readFromURL:ofType:error:")]
		bool ReadFromUrl (NSUrl absoluteURL, string typeName, NSError error);

		//- (BOOL)revertToContentsOfURL:(NSURL *)inAbsoluteURL ofType:(NSString *)inTypeName error:(NSError **)outError; 
		[Export ("revertToContentsOfURL:ofType:error:")]
		bool RevertToContentsOfUrl (NSUrl inAbsoluteURL, string inTypeName, NSError outError);

		////- (BOOL)configurePersistentStoreCoordinatorForURL:(NSURL *)url ofType:(NSString *)fileType error:(NSError **)error;    
		//[Export ("configurePersistentStoreCoordinatorForURL:ofType:error:")]
		//bool ConfigurePersistentStoreCoordinatorForURLOfType (NSUrl url, string fileType, NSError error);

	}
}
