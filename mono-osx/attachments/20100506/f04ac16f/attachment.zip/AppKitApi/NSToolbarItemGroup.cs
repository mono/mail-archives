using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSToolbarItem))]
	interface NSToolbarItemGroup {

		//- (NSArray *)subitems;
		[Export ("subitems")]
		NSArray Subitems { get; set; }

	}
}
