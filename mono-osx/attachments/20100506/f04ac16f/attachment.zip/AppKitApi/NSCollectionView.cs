using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSView))]
	interface NSCollectionView {

		//- (BOOL)isFirstResponder;    
		[Export ("isFirstResponder")]
		bool IsFirstResponder { get; }

		//- (NSArray *)content;
		[Export ("content")]
		NSArray Content { get; set; }

		//- (void)setSelectable:(BOOL)flag;
		[Export ("setSelectable:")]
		void SetSelectable (bool flag);

		//- (BOOL)isSelectable;
		[Export ("isSelectable")]
		bool IsSelectable { get; }

		//- (BOOL)allowsMultipleSelection;
		[Export ("allowsMultipleSelection")]
		bool AllowsMultipleSelection { get; set; }

		//- (NSIndexSet *)selectionIndexes;
		[Export ("selectionIndexes")]
		NSIndexSet SelectionIndexes { get; set; }

		//- (NSCollectionViewItem *)newItemForRepresentedObject:(id)object;    
		[Export ("newItemForRepresentedObject:")]
		NSCollectionViewItem NewItemForRepresentedObject (NSObject object1);

		//- (NSCollectionViewItem *)itemPrototype;
		[Export ("itemPrototype")]
		NSCollectionViewItem ItemPrototype { get; set; }

		//- (NSUInteger)maxNumberOfRows;
		[Export ("maxNumberOfRows")]
		uint MaxNumberOfRows { get; set; }

		//- (NSUInteger)maxNumberOfColumns;
		[Export ("maxNumberOfColumns")]
		uint MaxNumberOfColumns { get; set; }

		//- (NSSize)minItemSize;
		[Export ("minItemSize")]
		NSSize MinItemSize { get; set; }

		//- (NSSize)maxItemSize;
		[Export ("maxItemSize")]
		NSSize MaxItemSize { get; set; }

		//- (NSArray *)backgroundColors;
		[Export ("backgroundColors")]
		NSArray BackgroundColors { get; set; }

	}
}
