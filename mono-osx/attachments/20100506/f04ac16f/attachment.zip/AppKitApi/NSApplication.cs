using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSResponder))]
	interface NSApplication {

		//+ (NSApplication *)sharedApplication;
		[Static, Export ("sharedApplication")]
		NSApplication SharedApplication { get; }

		//- (void)setDelegate:(id)anObject;
		[Export ("setDelegate:")]
		void SetDelegate (NSObject anObject);

		//- (id)delegate;
		[Export ("delegate")]
		NSApplication Delegate { get; }

		//- (NSGraphicsContext*)context;
		[Export ("context")]
		NSGraphicsContext Context { get; }

		//- (void)hide:(id)sender;
		[Export ("hide:")]
		void Hide (NSObject sender);

		//- (void)unhide:(id)sender;
		[Export ("unhide:")]
		void Unhide (NSObject sender);

		//- (void)unhideWithoutActivation;
		[Export ("unhideWithoutActivation")]
		void UnhideWithoutActivation ();

		//- (NSWindow *)windowWithWindowNumber:(NSInteger)windowNum;
		[Export ("windowWithWindowNumber:")]
		NSWindow WindowWithWindowNumber (int windowNum);

		//- (NSWindow *)mainWindow;
		[Export ("mainWindow")]
		NSWindow MainWindow { get; }

		//- (NSWindow *)keyWindow;
		[Export ("keyWindow")]
		NSWindow KeyWindow { get; }

		//- (BOOL)isActive;
		[Export ("isActive")]
		bool IsActive { get; }

		//- (BOOL)isHidden;
		[Export ("isHidden")]
		bool IsHidden { get; }

		//- (BOOL)isRunning;
		[Export ("isRunning")]
		bool IsRunning { get; }

		//- (void)deactivate;
		[Export ("deactivate")]
		void Deactivate ();

		//- (void)activateIgnoringOtherApps:(BOOL)flag;
		[Export ("activateIgnoringOtherApps:")]
		void ActivateIgnoringOtherApps (bool flag);

		//- (void)hideOtherApplications:(id)sender;
		[Export ("hideOtherApplications:")]
		void HideOtherApplications (NSObject sender);

		//- (void)unhideAllApplications:(id)sender;
		[Export ("unhideAllApplications:")]
		void UnhideAllApplications (NSObject sender);

		//- (void)finishLaunching;
		[Export ("finishLaunching")]
		void FinishLaunching ();

		//- (void)run;
		[Export ("run")]
		void Run ();

		//- (NSInteger)runModalForWindow:(NSWindow *)theWindow;
		[Export ("runModalForWindow:")]
		int RunModalForWindow (NSWindow theWindow);

		//- (void)stop:(id)sender;
		[Export ("stop:")]
		void Stop (NSObject sender);

		//- (void)stopModal;
		[Export ("stopModal")]
		void StopModal ();

		//- (void)stopModalWithCode:(NSInteger)returnCode;
		[Export ("stopModalWithCode:")]
		void StopModalWithCode (int returnCode);

		//- (void)abortModal;
		[Export ("abortModal")]
		void AbortModal ();

		//- (NSWindow *)modalWindow;
		[Export ("modalWindow")]
		NSWindow ModalWindow { get; }

		//- (NSModalSession)beginModalSessionForWindow:(NSWindow *)theWindow;
		[Export ("beginModalSessionForWindow:")]
		IntPtr BeginModalSessionForWindow (NSWindow theWindow);

		//- (NSInteger)runModalSession:(NSModalSession)session;
		[Export ("runModalSession:")]
		int RunModalSession (IntPtr session);

		//- (void)endModalSession:(NSModalSession)session;
		[Export ("endModalSession:")]
		void EndModalSession (IntPtr session);

		//- (void)terminate:(id)sender;
		[Export ("terminate:")]
		void Terminate (NSObject sender);

		//- (NSInteger)requestUserAttention:(NSRequestUserAttentionType)requestType;
		[Export ("requestUserAttention:")]
		int RequestUserAttention (NSRequestUserAttentionType requestType);

		//- (void)cancelUserAttentionRequest:(NSInteger)request;
		[Export ("cancelUserAttentionRequest:")]
		void CancelUserAttentionRequest (int request);

		//- (void)beginSheet:(NSWindow *)sheet modalForWindow:(NSWindow *)docWindow modalDelegate:(id)modalDelegate didEndSelector:(SEL)didEndSelector contextInfo:(void *)contextInfo;
		[Export ("beginSheet:modalForWindow:modalDelegate:didEndSelector:contextInfo:")]
		void BeginSheet (NSWindow sheet, NSWindow docWindow, NSObject modalDelegate, Selector didEndSelector, IntPtr contextInfo);

		//- (void)endSheet:(NSWindow *)sheet;
		[Export ("endSheet:")]
		void EndSheet (NSWindow sheet);

		//- (void)endSheet:(NSWindow *)sheet returnCode:(NSInteger)returnCode;
		[Export ("endSheet:returnCode:")]
		void EndSheet (NSWindow sheet, int returnCode);

		//- (NSInteger)runModalForWindow:(NSWindow *)theWindow relativeToWindow:(NSWindow *)docWindow;
		[Export ("runModalForWindow:relativeToWindow:")]
		int RunModalForWindow (NSWindow theWindow, NSWindow docWindow);

		//- (NSModalSession)beginModalSessionForWindow:(NSWindow *)theWindow relativeToWindow:(NSWindow *)docWindow;
		[Export ("beginModalSessionForWindow:relativeToWindow:")]
		IntPtr BeginModalSessionForWindow (NSWindow theWindow, NSWindow docWindow);

		//- (NSEvent *)nextEventMatchingMask:(NSUInteger)mask untilDate:(NSDate *)expiration inMode:(NSString *)mode dequeue:(BOOL)deqFlag;
		[Export ("nextEventMatchingMask:untilDate:inMode:dequeue:")]
		NSEvent NextEventMatchingMask (uint mask, NSDate expiration, string mode, bool deqFlag);

		//- (void)discardEventsMatchingMask:(NSUInteger)mask beforeEvent:(NSEvent *)lastEvent;
		[Export ("discardEventsMatchingMask:beforeEvent:")]
		void DiscardEventsMatchingMask (uint mask, NSEvent lastEvent);

		//- (void)postEvent:(NSEvent *)event atStart:(BOOL)flag;
		[Export ("postEvent:atStart:")]
		void PostEvent (NSEvent event1, bool flag);

		//- (NSEvent *)currentEvent;
		[Export ("currentEvent")]
		NSEvent CurrentEvent { get; }

		//- (void)sendEvent:(NSEvent *)theEvent;
		[Export ("sendEvent:")]
		void SendEvent (NSEvent theEvent);

		//- (void)preventWindowOrdering;
		[Export ("preventWindowOrdering")]
		void PreventWindowOrdering ();

		//- (NSWindow *)makeWindowsPerform:(SEL)aSelector inOrder:(BOOL)flag;
		[Export ("makeWindowsPerform:inOrder:")]
		NSWindow MakeWindowsPerform (Selector aSelector, bool flag);

		//- (NSArray *)windows;
		[Export ("windows")]
		NSArray Windows { get; }

		//- (void)setWindowsNeedUpdate:(BOOL)needUpdate;
		[Export ("setWindowsNeedUpdate:")]
		void SetWindowsNeedUpdate (bool needUpdate);

		//- (void)updateWindows;
		[Export ("updateWindows")]
		void UpdateWindows ();

		//- (NSMenu *)mainMenu;
		[Export ("mainMenu")]
		NSMenu MainMenu { get; set; }

		//- (NSImage *)applicationIconImage;
		[Export ("applicationIconImage")]
		NSImage ApplicationIconImage { get; set; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (NSDockTile *)dockTile;
		[Export ("dockTile")]
		NSDockTile DockTile { get; }

//#endif
		//- (BOOL)sendAction:(SEL)theAction to:(id)theTarget from:(id)sender;
		[Export ("sendAction:to:from:")]
		bool SendAction (Selector theAction, NSObject theTarget, NSObject sender);

		//- (id)targetForAction:(SEL)theAction;
		[Export ("targetForAction:")]
		NSApplication TargetForAction (Selector theAction);

		//- (id)targetForAction:(SEL)theAction to:(id)theTarget from:(id)sender;
		[Export ("targetForAction:to:from:")]
		NSApplication TargetForAction (Selector theAction, NSObject theTarget, NSObject sender);

		//- (BOOL)tryToPerform:(SEL)anAction with:(id)anObject;
		[Export ("tryToPerform:with:")]
		bool TryToPerform (Selector anAction, NSObject anObject);

		//- (id)validRequestorForSendType:(NSString *)sendType returnType:(NSString *)returnType;
		[Export ("validRequestorForSendType:returnType:")]
		NSApplication ValidRequestorForSendType (string sendType, string returnType);

		//- (void)reportException:(NSException *)theException;
		[Export ("reportException:")]
		void ReportException (NSException theException);

		//+ (void)detachDrawingThread:(SEL)selector toTarget:(id)target withObject:(id)argument;
		[Static, Export ("detachDrawingThread:toTarget:withObject:")]
		void DetachDrawingThread (Selector selector, NSObject target, NSObject argument);

		//- (void)replyToApplicationShouldTerminate:(BOOL)shouldTerminate;
		[Export ("replyToApplicationShouldTerminate:")]
		void ReplyToApplicationShouldTerminate (bool shouldTerminate);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//- (void)replyToOpenOrPrint:(NSApplicationDelegateReply)reply;
		[Export ("replyToOpenOrPrint:")]
		void ReplyToOpenOrPrint (NSApplicationDelegateReply reply);

		//- (void)orderFrontCharacterPalette:(id)sender;
		[Export ("orderFrontCharacterPalette:")]
		void OrderFrontCharacterPalette (NSObject sender);

//#endif
		//- (NSMenu *)windowsMenu;
		[Export ("windowsMenu")]
		NSMenu WindowsMenu { get; }

		//- (void)arrangeInFront:(id)sender;
		[Export ("arrangeInFront:")]
		void ArrangeInFront (NSObject sender);

		//- (void)removeWindowsItem:(NSWindow *)win;
		[Export ("removeWindowsItem:")]
		void RemoveWindowsItem (NSWindow win);

		//- (void)addWindowsItem:(NSWindow *)win title:(NSString *)aString filename:(BOOL)isFilename;
		[Export ("addWindowsItem:title:filename:")]
		void AddWindowsItemTitle (NSWindow win, string aString, bool isFilename);

		//- (void)changeWindowsItem:(NSWindow *)win title:(NSString *)aString filename:(BOOL)isFilename;
		[Export ("changeWindowsItem:title:filename:")]
		void ChangeWindowsItemTitle (NSWindow win, string aString, bool isFilename);

		//- (void)updateWindowsItem:(NSWindow *)win;
		[Export ("updateWindowsItem:")]
		void UpdateWindowsItem (NSWindow win);

		//- (void)miniaturizeAll:(id)sender;
		[Export ("miniaturizeAll:")]
		void MiniaturizeAll (NSObject sender);

		//- (NSMenu *)servicesMenu;
		[Export ("servicesMenu")]
		NSMenu ServicesMenu { get; }

		//- (void)registerServicesMenuSendTypes:(NSArray *)sendTypes returnTypes:(NSArray *)returnTypes;
		[Export ("registerServicesMenuSendTypes:returnTypes:")]
		void RegisterServicesMenuSendTypesReturnTypes (NSArray sendTypes, NSArray returnTypes);

		//- (id)servicesProvider;
		[Export ("servicesProvider")]
		NSApplication ServicesProvider { get; }

		//- (void)orderFrontStandardAboutPanelWithOptions:(NSDictionary *)optionsDictionary;
		[Export ("orderFrontStandardAboutPanelWithOptions:")]
		void OrderFrontStandardAboutPanelWithOptions (NSDictionary optionsDictionary);

		//- (NSArray *)orderedDocuments;
		[Export ("orderedDocuments")]
		NSArray OrderedDocuments { get; }

		//- (NSArray *)orderedWindows;
		[Export ("orderedWindows")]
		NSArray OrderedWindows { get; }

		//  - (void)showHelp:(id)sender;
		[Export ("showHelp:")]
		void ShowHelp (NSObject sender);

		//- (void)runPageLayout:(id)sender;
		[Export ("runPageLayout:")]
		void RunPageLayout (NSObject sender);

	}
}
