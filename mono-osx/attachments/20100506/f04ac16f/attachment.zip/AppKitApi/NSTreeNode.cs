using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSObject))]
	interface NSTreeNode {

		//+ (id)treeNodeWithRepresentedObject:(id)modelObject;
		[Static, Export ("treeNodeWithRepresentedObject:")]
		NSTreeNode TreeNodeWithRepresentedObject (NSObject modelObject);

		//- (id)initWithRepresentedObject:(id)modelObject;
		[Export ("initWithRepresentedObject:")]
		IntPtr Constructor (NSObject modelObject);

		//- (id)representedObject;
		[Export ("representedObject")]
		NSTreeNode RepresentedObject { get; }

		//    - (NSIndexPath *)indexPath; 
		[Export ("indexPath")]
		NSIndexPath IndexPath { get; }

		//- (BOOL)isLeaf; 
		[Export ("isLeaf")]
		bool IsLeaf { get; }

		//    - (NSArray *)childNodes;    
		[Export ("childNodes")]
		NSArray ChildNodes { get; }

		//- (NSMutableArray *)mutableChildNodes; 
		[Export ("mutableChildNodes")]
		NSMutableArray MutableChildNodes { get; }

		//- (NSTreeNode *)descendantNodeAtIndexPath:(NSIndexPath *)indexPath; 
		[Export ("descendantNodeAtIndexPath:")]
		NSTreeNode DescendantNodeAtIndexPath (NSIndexPath indexPath);

		//- (NSTreeNode *)parentNode;
		[Export ("parentNode")]
		NSTreeNode ParentNode { get; }

		//    - (void)sortWithSortDescriptors:(NSArray *)sortDescriptors recursively:(BOOL)recursively;
		[Export ("sortWithSortDescriptors:recursively:")]
		void SortWithSortDescriptors (NSArray sortDescriptors, bool recursively);

	}
}
