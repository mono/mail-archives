using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSObject))]
	interface NSWorkspace {

//#if ! __LP64__
//#endif
		//+ (NSWorkspace *)sharedWorkspace;
		[Static, Export ("sharedWorkspace")]
		NSWorkspace SharedWorkspace { get; }

		//- (NSNotificationCenter *)notificationCenter;
		[Export ("notificationCenter")]
		NSNotificationCenter NotificationCenter { get; }

		//- (BOOL)openFile:(NSString *)fullPath;
		[Export ("openFile:")]
		bool OpenFile (string fullPath);

		//- (BOOL)openFile:(NSString *)fullPath withApplication:(NSString *)appName;
		[Export ("openFile:withApplication:")]
		bool OpenFile (string fullPath, string appName);

		//- (BOOL)openFile:(NSString *)fullPath withApplication:(NSString *)appName andDeactivate:(BOOL)flag;
		[Export ("openFile:withApplication:andDeactivate:")]
		bool OpenFile (string fullPath, string appName, bool flag);

		//- (BOOL)openTempFile:(NSString *)fullPath;
		[Export ("openTempFile:")]
		bool OpenTempFile (string fullPath);

		//- (BOOL)openFile:(NSString *)fullPath fromImage:(NSImage *)anImage at:(NSPoint)point inView:(NSView *)aView;
		[Export ("openFile:fromImage:at:inView:")]
		bool OpenFile (string fullPath, NSImage anImage, PointF point, NSView aView);

		//- (BOOL)openURL:(NSURL *)url;
		[Export ("openURL:")]
		bool OpenUrl (NSUrl url);

		//- (BOOL)launchApplication:(NSString *)appName;
		[Export ("launchApplication:")]
		bool LaunchApplication (string appName);

		//- (BOOL)launchApplication:(NSString *)appName showIcon:(BOOL)showIcon autolaunch:(BOOL)autolaunch;
		[Export ("launchApplication:showIcon:autolaunch:")]
		bool LaunchApplication (string appName, bool showIcon, bool autolaunch);

		//- (NSString *)fullPathForApplication:(NSString *)appName;
		[Export ("fullPathForApplication:")]
		string FullPathForApplication (string appName);

		//- (BOOL)selectFile:(NSString *)fullPath inFileViewerRootedAtPath:(NSString *)rootFullpath;
		[Export ("selectFile:inFileViewerRootedAtPath:")]
		bool SelectFile (string fullPath, string rootFullpath);

		//- (void)findApplications;
		[Export ("findApplications")]
		void FindApplications ();

		//- (void)noteFileSystemChanged;
		[Export ("noteFileSystemChanged")]
		void NoteFileSystemChanged ();

		//- (void)noteFileSystemChanged:(NSString *)path;
		[Export ("noteFileSystemChanged:")]
		void NoteFileSystemChanged (string path);

		//- (BOOL)fileSystemChanged;
		[Export ("fileSystemChanged")]
		bool FileSystemChanged { get; }

		//- (void)noteUserDefaultsChanged;
		[Export ("noteUserDefaultsChanged")]
		void NoteUserDefaultsChanged ();

		//- (BOOL)userDefaultsChanged;
		[Export ("userDefaultsChanged")]
		bool UserDefaultsChanged { get; }

		//- (BOOL)getInfoForFile:(NSString *)fullPath application:(NSString **)appName type:(NSString **)type;
		[Export ("getInfoForFile:application:type:")]
		bool GetInfoForFile (string fullPath, string appName, string type);

		//- (BOOL)isFilePackageAtPath:(NSString *)fullPath;
		[Export ("isFilePackageAtPath:")]
		bool IsFilePackageAtPath (string fullPath);

		//- (NSImage *)iconForFile:(NSString *)fullPath;
		[Export ("iconForFile:")]
		NSImage IconForFile (string fullPath);

		//- (NSImage *)iconForFiles:(NSArray *)fullPaths;
		[Export ("iconForFiles:")]
		NSImage IconForFiles (NSArray fullPaths);

		//- (NSImage *)iconForFileType:(NSString *)fileType;
		[Export ("iconForFileType:")]
		NSImage IconForFileType (string fileType);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (BOOL)setIcon:(NSImage *)image forFile:(NSString *)fullPath options:(NSWorkspaceIconCreationOptions)options;
		[Export ("setIcon:forFile:options:")]
		bool SetIcon (NSImage image, string fullPath, NSWorkspaceIconCreationOptions options);

//#endif
		//- (BOOL)getFileSystemInfoForPath:(NSString *)fullPath isRemovable:(BOOL *)removableFlag isWritable:(BOOL *)writableFlag isUnmountable:(BOOL *)unmountableFlag description:(NSString **)description type:(NSString **)fileSystemType;
		[Export ("getFileSystemInfoForPath:isRemovable:isWritable:isUnmountable:description:type:")]
		bool GetFileSystemInfoForPath (string fullPath, bool removableFlag, bool writableFlag, bool unmountableFlag, string description, string fileSystemType);

		//- (BOOL)performFileOperation:(NSString *)operation source:(NSString *)source destination:(NSString *)destination files:(NSArray *)files tag:(NSInteger *)tag;	
		[Export ("performFileOperation:source:destination:files:tag:")]
		bool PerformFileOperation (string operation, string source, string destination, NSArray files, int tag);

		//- (BOOL)unmountAndEjectDeviceAtPath:(NSString *)path;
		[Export ("unmountAndEjectDeviceAtPath:")]
		bool UnmountAndEjectDeviceAtPath (string path);

		//- (NSInteger)extendPowerOffBy:(NSInteger)requested;
		[Export ("extendPowerOffBy:")]
		int ExtendPowerOffBy (int requested);

		//- (void)slideImage:(NSImage *)image from:(NSPoint)fromPoint to:(NSPoint)toPoint;
		[Export ("slideImage:from:to:")]
		void SlideImage (NSImage image, PointF fromPoint, PointF toPoint);

		//- (void)hideOtherApplications;
		[Export ("hideOtherApplications")]
		void HideOtherApplications ();

		//- (NSArray *)mountedLocalVolumePaths;
		[Export ("mountedLocalVolumePaths")]
		NSArray MountedLocalVolumePaths { get; }

		//- (NSArray *)mountedRemovableMedia;
		[Export ("mountedRemovableMedia")]
		NSArray MountedRemovableMedia { get; }

		//- (NSArray *)mountNewRemovableMedia;
		[Export ("mountNewRemovableMedia")]
		NSArray MountNewRemovableMedia { get; }

		//- (void)checkForRemovableMedia;
		[Export ("checkForRemovableMedia")]
		void CheckForRemovableMedia ();

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//- (NSString *)absolutePathForAppBundleWithIdentifier:(NSString *)bundleIdentifier; 
		[Export ("absolutePathForAppBundleWithIdentifier:")]
		string AbsolutePathForAppBundleWithIdentifier (string bundleIdentifier);

		//- (BOOL)launchAppWithBundleIdentifier:(NSString *)bundleIdentifier options:(NSWorkspaceLaunchOptions)options additionalEventParamDescriptor:(NSAppleEventDescriptor *)descriptor launchIdentifier:(NSNumber **)identifier;
		[Export ("launchAppWithBundleIdentifier:options:additionalEventParamDescriptor:launchIdentifier:")]
		bool LaunchAppWithBundleIdentifier (string bundleIdentifier, NSWorkspaceLaunchOptions options, NSAppleEventDescriptor descriptor, NSNumber identifier);

		//- (BOOL)openURLs:(NSArray *)urls withAppBundleIdentifier:(NSString *)bundleIdentifier options:(NSWorkspaceLaunchOptions)options additionalEventParamDescriptor:(NSAppleEventDescriptor *)descriptor launchIdentifiers:(NSArray **)identifiers;
		[Export ("openURLs:withAppBundleIdentifier:options:additionalEventParamDescriptor:launchIdentifiers:")]
		bool OpenUrls (NSArray urls, string bundleIdentifier, NSWorkspaceLaunchOptions options, NSAppleEventDescriptor descriptor, NSArray identifiers);

//#endif
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_2
		//- (NSArray *)launchedApplications;	
		[Export ("launchedApplications")]
		NSArray LaunchedApplications { get; }

		//- (NSDictionary *)activeApplication;	
		[Export ("activeApplication")]
		NSDictionary ActiveApplication { get; }

//#endif
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (NSString *)typeOfFile:(NSString *)absoluteFilePath error:(NSError **)outError;
		[Export ("typeOfFile:error:")]
		string TypeOfFile (string absoluteFilePath, NSError outError);

		//- (NSString *)localizedDescriptionForType:(NSString *)typeName;
		[Export ("localizedDescriptionForType:")]
		string LocalizedDescriptionForType (string typeName);

		//- (NSString *)preferredFilenameExtensionForType:(NSString *)typeName;
		[Export ("preferredFilenameExtensionForType:")]
		string PreferredFilenameExtensionForType (string typeName);

		//- (BOOL)filenameExtension:(NSString *)filenameExtension isValidForType:(NSString *)typeName;
		[Export ("filenameExtension:isValidForType:")]
		bool FilenameExtension (string filenameExtension, string typeName);

		//- (BOOL)type:(NSString *)firstTypeName conformsToType:(NSString *)secondTypeName;
		[Export ("type:conformsToType:")]
		bool Type (string firstTypeName, string secondTypeName);

//#endif
	}
}
