using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSTextBlock))]
	interface NSTextTableBlock {

		//- (id)initWithTable:(NSTextTable *)table startingRow:(NSInteger)row rowSpan:(NSInteger)rowSpan startingColumn:(NSInteger)col columnSpan:(NSInteger)colSpan;     
		[Export ("initWithTable:startingRow:rowSpan:startingColumn:columnSpan:")]
		IntPtr Constructor (NSTextTable table, int row, int rowSpan, int col, int colSpan);

		//- (NSTextTable *)table;
		[Export ("table")]
		NSTextTable Table { get; }

		//- (NSInteger)startingRow;
		[Export ("startingRow")]
		int StartingRow { get; }

		//- (NSInteger)rowSpan;
		[Export ("rowSpan")]
		int RowSpan { get; }

		//- (NSInteger)startingColumn;
		[Export ("startingColumn")]
		int StartingColumn { get; }

		//- (NSInteger)columnSpan;
		[Export ("columnSpan")]
		int ColumnSpan { get; }

	}
}
