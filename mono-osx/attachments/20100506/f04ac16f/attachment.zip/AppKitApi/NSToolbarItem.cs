using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSObject))]
	interface NSToolbarItem {

//#if __LP64__
//#endif
		//- (id)initWithItemIdentifier:(NSString *)itemIdentifier;
		[Export ("initWithItemIdentifier:")]
		IntPtr Constructor (string itemIdentifier);

		//    - (NSString *)itemIdentifier;
		[Export ("itemIdentifier")]
		string ItemIdentifier { get; }

		//- (NSToolbar *)toolbar;
		[Export ("toolbar")]
		NSToolbar Toolbar { get; }

		//- (NSString *)label;
		[Export ("label")]
		string Label { get; set; }

		//- (NSString *)paletteLabel;
		[Export ("paletteLabel")]
		string PaletteLabel { get; set; }

		//- (NSString *)toolTip;
		[Export ("toolTip")]
		string ToolTip { get; set; }

		//- (NSMenuItem *)menuFormRepresentation;
		[Export ("menuFormRepresentation")]
		NSMenuItem MenuFormRepresentation { get; set; }

		//- (NSInteger)tag;
		[Export ("tag")]
		int Tag { get; set; }

		//    - (void)setTarget:(id)target;
		[Export ("setTarget:")]
		void SetTarget (NSObject target);

		//- (id)target;
		[Export ("target")]
		NSToolbarItem Target { get; }

		//- (SEL)action;
		[Export ("action")]
		Selector Action { get; set; }

		//    - (void)setEnabled:(BOOL)enabled;
		[Export ("setEnabled:")]
		void SetEnabled (bool enabled);

		//- (BOOL)isEnabled;
		[Export ("isEnabled")]
		bool IsEnabled { get; }

		//- (NSImage *)image;
		[Export ("image")]
		NSImage Image { get; set; }

		//- (NSView *)view;
		[Export ("view")]
		NSView View { get; set; }

		//- (NSSize)minSize;
		[Export ("minSize")]
		NSSize MinSize { get; set; }

		//- (NSSize)maxSize;
		[Export ("maxSize")]
		NSSize MaxSize { get; set; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (NSInteger)visibilityPriority;
		[Export ("visibilityPriority")]
		int VisibilityPriority { get; set; }

//#endif
		//    - (void)validate;
		[Export ("validate")]
		void Validate ();

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (BOOL)autovalidates;
		[Export ("autovalidates")]
		bool Autovalidates { get; set; }

//#endif
		//    - (BOOL)allowsDuplicatesInToolbar;
		[Export ("allowsDuplicatesInToolbar")]
		bool AllowsDuplicatesInToolbar { get; }

	}
}
