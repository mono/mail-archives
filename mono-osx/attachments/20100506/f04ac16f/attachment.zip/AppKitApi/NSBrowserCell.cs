using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSCell))]
	interface NSBrowserCell {

		//+ (NSImage *)branchImage;
		[Static, Export ("branchImage")]
		NSImage BranchImage { get; }

		//+ (NSImage *)highlightedBranchImage;
		[Static, Export ("highlightedBranchImage")]
		NSImage HighlightedBranchImage { get; }

		//- (NSColor *)highlightColorInView:(NSView *)controlView;
		[Export ("highlightColorInView:")]
		NSColor HighlightColorInView (NSView controlView);

		//- (BOOL)isLeaf;
		[Export ("isLeaf")]
		bool IsLeaf { get; }

		//- (void)setLeaf:(BOOL)flag;
		[Export ("setLeaf:")]
		void SetLeaf (bool flag);

		//- (BOOL)isLoaded;
		[Export ("isLoaded")]
		bool IsLoaded { get; }

		//- (void)setLoaded:(BOOL)flag;
		[Export ("setLoaded:")]
		void SetLoaded (bool flag);

		//- (void)reset;
		[Export ("reset")]
		void Reset ();

		//- (void)set;
		[Export ("set")]
		void Set ();

		//- (NSImage *)image;
		[Export ("image")]
		NSImage Image { get; set; }

		//- (NSImage *)alternateImage;
		[Export ("alternateImage")]
		NSImage AlternateImage { get; set; }

	}
}
