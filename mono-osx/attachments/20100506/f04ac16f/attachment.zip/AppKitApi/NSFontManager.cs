using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSObject))]
	interface NSFontManager {

		//+ (void)setFontPanelFactory:(Class)factoryId;
		[Static, Export ("setFontPanelFactory:")]
		void SetFontPanelFactory (Class factoryId);

		//+ (void)setFontManagerFactory:(Class)factoryId;
		[Static, Export ("setFontManagerFactory:")]
		void SetFontManagerFactory (Class factoryId);

		//+ (NSFontManager *)sharedFontManager;
		[Static, Export ("sharedFontManager")]
		NSFontManager SharedFontManager { get; }

		//- (BOOL)isMultiple;
		[Export ("isMultiple")]
		bool IsMultiple { get; }

		//- (NSFont *)selectedFont;
		[Export ("selectedFont")]
		NSFont SelectedFont { get; }

		//- (void)setSelectedFont:(NSFont *)fontObj isMultiple:(BOOL)flag;
		[Export ("setSelectedFont:isMultiple:")]
		void SetSelectedFont (NSFont fontObj, bool flag);

		//- (void)setFontMenu:(NSMenu *)newMenu;
		[Export ("setFontMenu:")]
		void SetFontMenu (NSMenu newMenu);

		//- (NSMenu *)fontMenu:(BOOL)create;
		[Export ("fontMenu:")]
		NSMenu FontMenu (bool create);

		//- (NSFontPanel *)fontPanel:(BOOL)create;
		[Export ("fontPanel:")]
		NSFontPanel FontPanel (bool create);

		//- (NSFont *)fontWithFamily:(NSString *)family traits:(NSFontTraitMask)traits weight:(NSInteger)weight size:(CGFloat)size;
		[Export ("fontWithFamily:traits:weight:size:")]
		NSFont FontWithFamily (string family, NSFontTraitMask traits, int weight, float size);

		//- (NSFontTraitMask)traitsOfFont:(NSFont *)fontObj;
		[Export ("traitsOfFont:")]
		NSFontTraitMask TraitsOfFont (NSFont fontObj);

		//- (NSInteger)weightOfFont:(NSFont *)fontObj;
		[Export ("weightOfFont:")]
		int WeightOfFont (NSFont fontObj);

		//- (NSArray *)availableFonts;
		[Export ("availableFonts")]
		NSArray AvailableFonts { get; }

		//- (NSArray *)availableFontFamilies;
		[Export ("availableFontFamilies")]
		NSArray AvailableFontFamilies { get; }

		//- (NSArray *)availableMembersOfFontFamily:(NSString *)fam;
		[Export ("availableMembersOfFontFamily:")]
		NSArray AvailableMembersOfFontFamily (string fam);

		//- (NSFont *)convertFont:(NSFont *)fontObj;
		[Export ("convertFont:")]
		NSFont ConvertFont (NSFont fontObj);

		//- (NSFont *)convertFont:(NSFont *)fontObj toSize:(CGFloat)size;
		[Export ("convertFont:toSize:")]
		NSFont ConvertFont (NSFont fontObj, float size);

		//- (NSFont *)convertFont:(NSFont *)fontObj toFace:(NSString *)typeface;
		[Export ("convertFont:toFace:")]
		NSFont ConvertFont (NSFont fontObj, string typeface);

		//- (NSFont *)convertFont:(NSFont *)fontObj toFamily:(NSString *)family;
		[Export ("convertFont:toFamily:")]
		NSFont ConvertFontToFamily (NSFont fontObj, string family);

		//- (NSFont *)convertFont:(NSFont *)fontObj toHaveTrait:(NSFontTraitMask)trait;
		[Export ("convertFont:toHaveTrait:")]
		NSFont ConvertFont (NSFont fontObj, NSFontTraitMask trait);

		//- (NSFont *)convertFont:(NSFont *)fontObj toNotHaveTrait:(NSFontTraitMask)trait;
		[Export ("convertFont:toNotHaveTrait:")]
		NSFont ConvertFontToNotHaveTrait (NSFont fontObj, NSFontTraitMask trait);

		//- (NSFont *)convertWeight:(BOOL)upFlag ofFont:(NSFont *)fontObj;
		[Export ("convertWeight:ofFont:")]
		NSFont ConvertWeight (bool upFlag, NSFont fontObj);

		//- (BOOL)isEnabled;
		[Export ("isEnabled")]
		bool IsEnabled { get; }

		//- (void)setEnabled:(BOOL)flag;
		[Export ("setEnabled:")]
		void SetEnabled (bool flag);

		//- (SEL)action;
		[Export ("action")]
		Selector Action { get; set; }

		//- (BOOL)sendAction;
		[Export ("sendAction")]
		bool SendAction { get; }

		//- (void)setDelegate:(id)anObject;
		[Export ("setDelegate:")]
		void SetDelegate (NSObject anObject);

		//- (id)delegate;
		[Export ("delegate")]
		NSFontManager Delegate { get; }

		//- (NSString *) localizedNameForFamily:(NSString *)family face:(NSString *)faceKey;
		[Export ("localizedNameForFamily:face:")]
		string LocalizedNameForFamily (string family, string faceKey);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//- (void)setSelectedAttributes:(NSDictionary *)attributes isMultiple:(BOOL)flag;
		[Export ("setSelectedAttributes:isMultiple:")]
		void SetSelectedAttributes (NSDictionary attributes, bool flag);

		//- (NSDictionary *)convertAttributes:(NSDictionary *)attributes;
		[Export ("convertAttributes:")]
		NSDictionary ConvertAttributes (NSDictionary attributes);

		//- (NSArray *)availableFontNamesMatchingFontDescriptor:(NSFontDescriptor *)descriptor;
		[Export ("availableFontNamesMatchingFontDescriptor:")]
		NSArray AvailableFontNamesMatchingFontDescriptor (NSFontDescriptor descriptor);

		//- (NSArray *)collectionNames;
		[Export ("collectionNames")]
		NSArray CollectionNames { get; }

		//- (NSArray *)fontDescriptorsInCollection:(NSString *)collectionNames;
		[Export ("fontDescriptorsInCollection:")]
		NSArray FontDescriptorsInCollection (string collectionNames);

		//- (BOOL)addCollection:(NSString *)collectionName options:(NSInteger)collectionOptions;
		[Export ("addCollection:options:")]
		bool AddCollection (string collectionName, int collectionOptions);

		//- (BOOL)removeCollection:(NSString *)collectionName;
		[Export ("removeCollection:")]
		bool RemoveCollection (string collectionName);

		//- (void)addFontDescriptors:(NSArray *)descriptors  toCollection:(NSString *)collectionName;
		[Export ("addFontDescriptors:toCollection:")]
		void AddFontDescriptors (NSArray descriptors, string collectionName);

		//- (void)removeFontDescriptor:(NSFontDescriptor *)descriptor fromCollection:(NSString *)collection;
		[Export ("removeFontDescriptor:fromCollection:")]
		void RemoveFontDescriptor (NSFontDescriptor descriptor, string collection);

//#endif
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (NSFontAction)currentFontAction;
		[Export ("currentFontAction")]
		NSFontAction CurrentFontAction { get; }

		//- (NSFontTraitMask)convertFontTraits:(NSFontTraitMask)traits;
		[Export ("convertFontTraits:")]
		NSFontTraitMask ConvertFontTraits (NSFontTraitMask traits);

		//- (void)setTarget:(id)aTarget;
		[Export ("setTarget:")]
		void SetTarget (NSObject aTarget);

		//- (id)target;
		[Export ("target")]
		NSFontManager Target { get; }

//#endif 
		//- (BOOL)fontNamed:(NSString *)fName hasTraits:(NSFontTraitMask)someTraits;
		[Export ("fontNamed:hasTraits:")]
		bool FontNamedHasTraits (string fName, NSFontTraitMask someTraits);

		//- (NSArray *)availableFontNamesWithTraits:(NSFontTraitMask)someTraits;
		[Export ("availableFontNamesWithTraits:")]
		NSArray AvailableFontNamesWithTraits (NSFontTraitMask someTraits);

		//- (void)addFontTrait:(id)sender;
		[Export ("addFontTrait:")]
		void AddFontTrait (NSObject sender);

		//- (void)removeFontTrait:(id)sender;
		[Export ("removeFontTrait:")]
		void RemoveFontTrait (NSObject sender);

		//- (void)modifyFontViaPanel:(id)sender;
		[Export ("modifyFontViaPanel:")]
		void ModifyFontViaPanel (NSObject sender);

		//- (void)modifyFont:(id)sender;
		[Export ("modifyFont:")]
		void ModifyFont (NSObject sender);

		//- (void)orderFrontFontPanel:(id)sender;
		[Export ("orderFrontFontPanel:")]
		void OrderFrontFontPanel (NSObject sender);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//- (void)orderFrontStylesPanel:(id)sender;
		[Export ("orderFrontStylesPanel:")]
		void OrderFrontStylesPanel (NSObject sender);

//#endif
	}
}
