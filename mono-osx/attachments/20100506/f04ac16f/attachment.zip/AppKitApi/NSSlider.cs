using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSControl))]
	interface NSSlider {

		//- (double)minValue;
		[Export ("minValue")]
		double MinValue { get; set; }

		//- (double)maxValue;
		[Export ("maxValue")]
		double MaxValue { get; set; }

		//- (double)altIncrementValue;
		[Export ("altIncrementValue")]
		double AltIncrementValue { get; set; }

		//- (void)setTitleCell:(NSCell *)aCell;
		[Export ("setTitleCell:")]
		void SetTitleCell (NSCell aCell);

		//- (id)titleCell;
		[Export ("titleCell")]
		NSSlider TitleCell { get; }

		//- (NSColor *)titleColor;
		[Export ("titleColor")]
		NSColor TitleColor { get; set; }

		//- (NSFont *)titleFont;
		[Export ("titleFont")]
		NSFont TitleFont { get; set; }

		//- (NSString *)title;
		[Export ("title")]
		string Title { get; set; }

		//- (CGFloat)knobThickness;
		[Export ("knobThickness")]
		float KnobThickness { get; set; }

		//- (NSImage *)image;
		[Export ("image")]
		NSImage Image { get; set; }

		//- (NSInteger)isVertical;
		[Export ("isVertical")]
		int IsVertical { get; }

		//- (BOOL)acceptsFirstMouse:(NSEvent *)theEvent;
		[Export ("acceptsFirstMouse:")]
		bool AcceptsFirstMouse (NSEvent theEvent);

		//- (NSInteger)numberOfTickMarks;
		[Export ("numberOfTickMarks")]
		int NumberOfTickMarks { get; set; }

		//- (NSTickMarkPosition)tickMarkPosition;
		[Export ("tickMarkPosition")]
		NSTickMarkPosition TickMarkPosition { get; set; }

		//- (BOOL)allowsTickMarkValuesOnly;
		[Export ("allowsTickMarkValuesOnly")]
		bool AllowsTickMarkValuesOnly { get; set; }

		//- (double)tickMarkValueAtIndex:(NSInteger)index;
		[Export ("tickMarkValueAtIndex:")]
		double TickMarkValueAtIndex (int index);

		//- (NSRect)rectOfTickMarkAtIndex:(NSInteger)index;
		[Export ("rectOfTickMarkAtIndex:")]
		RectangleF RectOfTickMarkAtIndex (int index);

		//- (NSInteger)indexOfTickMarkAtPoint:(NSPoint)point;
		[Export ("indexOfTickMarkAtPoint:")]
		int IndexOfTickMarkAtPoint (PointF point);

		//- (double)closestTickMarkValueToValue:(double)value;
		[Export ("closestTickMarkValueToValue:")]
		double ClosestTickMarkValueToValue (double value);

	}
}
