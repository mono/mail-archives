using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSObject))]
	interface NSHelpManager {

		//+ (NSHelpManager *)sharedHelpManager;
		[Static, Export ("sharedHelpManager")]
		NSHelpManager SharedHelpManager { get; }

		//+ (void)setContextHelpModeActive:(BOOL)active;
		[Static, Export ("setContextHelpModeActive:")]
		void SetContextHelpModeActive (bool active);

		//+ (BOOL)isContextHelpModeActive;
		[Static, Export ("isContextHelpModeActive")]
		bool IsContextHelpModeActive { get; }

		//- (void)setContextHelp:(NSAttributedString *)attrString forObject:(id)object;
		[Export ("setContextHelp:forObject:")]
		void SetContextHelp (NSAttributedString attrString, NSObject object1);

		//- (void)removeContextHelpForObject:(id)object;
		[Export ("removeContextHelpForObject:")]
		void RemoveContextHelpForObject (NSObject object1);

		//- (NSAttributedString *)contextHelpForObject:(id)object;
		[Export ("contextHelpForObject:")]
		NSAttributedString ContextHelpForObject (NSObject object1);

		//- (BOOL)showContextHelpForObject:(id)object locationHint:(NSPoint)pt;
		[Export ("showContextHelpForObject:locationHint:")]
		bool ShowContextHelpForObject (NSObject object1, PointF pt);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//- (void)openHelpAnchor:(NSString *)anchor inBook:(NSString *)book;
		[Export ("openHelpAnchor:inBook:")]
		void OpenHelpAnchor (string anchor, string book);

		//- (void)findString:(NSString *)query inBook:(NSString *)book;
		[Export ("findString:inBook:")]
		void FindString (string query, string book);

//#endif
	}
}
