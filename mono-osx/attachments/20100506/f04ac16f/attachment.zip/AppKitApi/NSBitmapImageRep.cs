using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSImageRep))]
	interface NSBitmapImageRep {

		//- (id)initWithFocusedViewRect:(NSRect)rect;
		[Export ("initWithFocusedViewRect:")]
		IntPtr Constructor (RectangleF rect);

		//- (id)initWithBitmapDataPlanes:(unsigned char **)planes pixelsWide:(NSInteger)width pixelsHigh:(NSInteger)height bitsPerSample:(NSInteger)bps samplesPerPixel:(NSInteger)spp hasAlpha:(BOOL)alpha isPlanar:(BOOL)isPlanar colorSpaceName:(NSString *)colorSpaceName bytesPerRow:(NSInteger)rBytes bitsPerPixel:(NSInteger)pBits; 
		[Export ("initWithBitmapDataPlanes:pixelsWide:pixelsHigh:bitsPerSample:samplesPerPixel:hasAlpha:isPlanar:colorSpaceName:bytesPerRow:bitsPerPixel:")]
		IntPtr Constructor (byte planes, int width, int height, int bps, int spp, bool alpha, bool isPlanar, string colorSpaceName, int rBytes, int pBits);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (id)initWithBitmapDataPlanes:(unsigned char **)planes pixelsWide:(NSInteger)width pixelsHigh:(NSInteger)height bitsPerSample:(NSInteger)bps samplesPerPixel:(NSInteger)spp hasAlpha:(BOOL)alpha isPlanar:(BOOL)isPlanar colorSpaceName:(NSString *)colorSpaceName  bitmapFormat:(NSBitmapFormat)bitmapFormat bytesPerRow:(NSInteger)rBytes bitsPerPixel:(NSInteger)pBits; 
		[Export ("initWithBitmapDataPlanes:pixelsWide:pixelsHigh:bitsPerSample:samplesPerPixel:hasAlpha:isPlanar:colorSpaceName:bitmapFormat:bytesPerRow:bitsPerPixel:")]
		IntPtr Constructor (byte planes, int width, int height, int bps, int spp, bool alpha, bool isPlanar, string colorSpaceName, NSBitmapFormat bitmapFormat, int rBytes, int pBits);

//#endif
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (id)initWithCGImage:(CGImageRef)cgImage;
		[Export ("initWithCGImage:")]
		IntPtr Constructor (CGImageRef cgImage);

		//- (id)initWithCIImage:(CIImage *)ciImage;
		[Export ("initWithCIImage:")]
		IntPtr Constructor (CIImage ciImage);

//#endif
		//+ (NSArray *)imageRepsWithData:(NSData *)data;	
		[Static, Export ("imageRepsWithData:")]
		NSArray ImageRepsWithData (NSData data);

		//+ (id)imageRepWithData:(NSData *)data;	
		[Static, Export ("imageRepWithData:")]
		NSBitmapImageRep ImageRepWithData (NSData data);

		//- (id)initWithData:(NSData *)data;
		[Export ("initWithData:")]
		IntPtr Constructor (NSData data);

		//- (unsigned char *)bitmapData;
		[Export ("bitmapData")]
		byte BitmapData { get; }

		//- (void)getBitmapDataPlanes:(unsigned char **)data;
		[Export ("getBitmapDataPlanes:")]
		void GetBitmapDataPlanes (byte data);

		//- (BOOL)isPlanar;
		[Export ("isPlanar")]
		bool IsPlanar { get; }

		//- (NSInteger)samplesPerPixel;
		[Export ("samplesPerPixel")]
		int SamplesPerPixel { get; }

		//- (NSInteger)bitsPerPixel;
		[Export ("bitsPerPixel")]
		int BitsPerPixel { get; }

		//- (NSInteger)bytesPerRow;
		[Export ("bytesPerRow")]
		int BytesPerRow { get; }

		//- (NSInteger)bytesPerPlane;
		[Export ("bytesPerPlane")]
		int BytesPerPlane { get; }

		//- (NSInteger)numberOfPlanes;
		[Export ("numberOfPlanes")]
		int NumberOfPlanes { get; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (NSBitmapFormat)bitmapFormat;
		[Export ("bitmapFormat")]
		NSBitmapFormat BitmapFormat { get; }

//#endif
		//- (void)getCompression:(NSTIFFCompression *)compression factor:(float *)factor;
		[Export ("getCompression:factor:")]
		void GetCompression (NSTIFFCompression compression, float factor);

		//- (void)setCompression:(NSTIFFCompression)compression factor:(float)factor;
		[Export ("setCompression:factor:")]
		void SetCompression (NSTIFFCompression compression, float factor);

		//- (NSData *)TIFFRepresentation;
		[Export ("TIFFRepresentation")]
		NSData TIFFRepresentation { get; }

		//- (NSData *)TIFFRepresentationUsingCompression:(NSTIFFCompression)comp factor:(float)factor;
		[Export ("TIFFRepresentationUsingCompression:factor:")]
		NSData TIFFRepresentationUsingCompression (NSTIFFCompression comp, float factor);

		//+ (NSData *)TIFFRepresentationOfImageRepsInArray:(NSArray *)array;
		[Static, Export ("TIFFRepresentationOfImageRepsInArray:")]
		NSData TIFFRepresentationOfImageRepsInArray (NSArray array);

		//+ (NSData *)TIFFRepresentationOfImageRepsInArray:(NSArray *)array usingCompression:(NSTIFFCompression)comp factor:(float)factor;
		[Static, Export ("TIFFRepresentationOfImageRepsInArray:usingCompression:factor:")]
		NSData TIFFRepresentationOfImageRepsInArray (NSArray array, NSTIFFCompression comp, float factor);

		////+ (void)getTIFFCompressionTypes:(const NSTIFFCompression **)list count:(NSInteger *)numTypes;
		//[Static, Export ("getTIFFCompressionTypes:count:")]
		//void GetTIFFCompressionTypes (const NSTIFFCompression list, int numTypes);

		//+ (NSString *)localizedNameForTIFFCompressionType:(NSTIFFCompression)compression;
		[Static, Export ("localizedNameForTIFFCompressionType:")]
		string LocalizedNameForTIFFCompressionType (NSTIFFCompression compression);

		//- (BOOL)canBeCompressedUsing:(NSTIFFCompression)compression;
		[Export ("canBeCompressedUsing:")]
		bool CanBeCompressedUsing (NSTIFFCompression compression);

		//- (void)colorizeByMappingGray:(CGFloat)midPoint toColor:(NSColor *)midPointColor blackMapping:(NSColor *)shadowColor whiteMapping:(NSColor *)lightColor;
		[Export ("colorizeByMappingGray:toColor:blackMapping:whiteMapping:")]
		void ColorizeByMappingGray (float midPoint, NSColor midPointColor, NSColor shadowColor, NSColor lightColor);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_2
		//- (id)initForIncrementalLoad;
		[Export ("initForIncrementalLoad")]
		IntPtr InitForIncrementalLoad { get; }

		//- (NSInteger)incrementalLoadFromData:(NSData*)data complete:(BOOL)complete;
		[Export ("incrementalLoadFromData:complete:")]
		int IncrementalLoadFromData (NSData data, bool complete);

//#endif
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (void)setColor:(NSColor*)color atX:(NSInteger)x y:(NSInteger)y;
		[Export ("setColor:atX:y:")]
		void SetColor (NSColor color, int x, int y);

		//- (NSColor*)colorAtX:(NSInteger)x y:(NSInteger)y;
		[Export ("colorAtX:y:")]
		NSColor ColorAtX (int x, int y);

		////- (void)getPixel:(NSUInteger[])p atX:(NSInteger)x y:(NSInteger)y;
		//[Export ("getPixel:atX:y:")]
		//void GetPixel (NSUInteger[] p, int x, int y);

		////- (void)setPixel:(NSUInteger[])p atX:(NSInteger)x y:(NSInteger)y;
		//[Export ("setPixel:atX:y:")]
		//void SetPixel (NSUInteger[] p, int x, int y);

//#endif
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (CGImageRef)CGImage;
		[Export ("CGImage")]
		CGImageRef CGImage { get; }

//#endif
		//+ (NSData *)representationOfImageRepsInArray:(NSArray *)imageReps usingType:(NSBitmapImageFileType)storageType properties:(NSDictionary *)properties;
		[Static, Export ("representationOfImageRepsInArray:usingType:properties:")]
		NSData RepresentationOfImageRepsInArrayUsingType (NSArray imageReps, NSBitmapImageFileType storageType, NSDictionary properties);

		//- (NSData *)representationUsingType:(NSBitmapImageFileType)storageType properties:(NSDictionary *)properties;
		[Export ("representationUsingType:properties:")]
		NSData RepresentationUsingTypeProperties (NSBitmapImageFileType storageType, NSDictionary properties);

		//- (void)setProperty:(NSString *)property withValue:(id)value;
		[Export ("setProperty:withValue:")]
		void SetPropertyWithValue (string property, NSObject value);

		//- (id)valueForProperty:(NSString *)property;
		[Export ("valueForProperty:")]
		NSBitmapImageRep ValueForProperty (string property);

	}
}
