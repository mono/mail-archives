using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSObject))]
	interface NSSpellChecker {

		//+ (NSSpellChecker *)sharedSpellChecker;
		[Static, Export ("sharedSpellChecker")]
		NSSpellChecker SharedSpellChecker { get; }

		//+ (BOOL)sharedSpellCheckerExists;
		[Static, Export ("sharedSpellCheckerExists")]
		bool SharedSpellCheckerExists { get; }

		//+ (NSInteger)uniqueSpellDocumentTag;
		[Static, Export ("uniqueSpellDocumentTag")]
		int UniqueSpellDocumentTag { get; }

		//- (NSRange)checkSpellingOfString:(NSString *)stringToCheck startingAt:(NSInteger)startingOffset language:(NSString *)language wrap:(BOOL)wrapFlag inSpellDocumentWithTag:(NSInteger)tag wordCount:(NSInteger *)wordCount;
		[Export ("checkSpellingOfString:startingAt:language:wrap:inSpellDocumentWithTag:wordCount:")]
		NSRange CheckSpellingOfString (string stringToCheck, int startingOffset, string language, bool wrapFlag, int tag, int wordCount);

		//- (NSRange)checkSpellingOfString:(NSString *)stringToCheck startingAt:(NSInteger)startingOffset;
		[Export ("checkSpellingOfString:startingAt:")]
		NSRange CheckSpellingOfString (string stringToCheck, int startingOffset);

		//- (NSInteger)countWordsInString:(NSString *)stringToCount language:(NSString *)language;
		[Export ("countWordsInString:language:")]
		int CountWordsInString (string stringToCount, string language);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (NSRange)checkGrammarOfString:(NSString *)stringToCheck startingAt:(NSInteger)startingOffset language:(NSString *)language wrap:(BOOL)wrapFlag inSpellDocumentWithTag:(NSInteger)tag details:(NSArray **)details;
		[Export ("checkGrammarOfString:startingAt:language:wrap:inSpellDocumentWithTag:details:")]
		NSRange CheckGrammarOfString (string stringToCheck, int startingOffset, string language, bool wrapFlag, int tag, NSArray details);

//#endif 
		//- (void)updateSpellingPanelWithMisspelledWord:(NSString *)word;
		[Export ("updateSpellingPanelWithMisspelledWord:")]
		void UpdateSpellingPanelWithMisspelledWord (string word);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (void)updateSpellingPanelWithGrammarString:(NSString *)string detail:(NSDictionary *)detail;
		[Export ("updateSpellingPanelWithGrammarString:detail:")]
		void UpdateSpellingPanelWithGrammarString (string string1, NSDictionary detail);

//#endif 
		//- (NSPanel *)spellingPanel;
		[Export ("spellingPanel")]
		NSPanel SpellingPanel { get; }

		//- (NSView *)accessoryView;
		[Export ("accessoryView")]
		NSView AccessoryView { get; set; }

		//- (void)ignoreWord:(NSString *)wordToIgnore inSpellDocumentWithTag:(NSInteger)tag;
		[Export ("ignoreWord:inSpellDocumentWithTag:")]
		void IgnoreWord (string wordToIgnore, int tag);

		//- (NSArray *)ignoredWordsInSpellDocumentWithTag:(NSInteger)tag;
		[Export ("ignoredWordsInSpellDocumentWithTag:")]
		NSArray IgnoredWordsInSpellDocumentWithTag (int tag);

		//- (void)setIgnoredWords:(NSArray *)words inSpellDocumentWithTag:(NSInteger)tag;
		[Export ("setIgnoredWords:inSpellDocumentWithTag:")]
		void SetIgnoredWords (NSArray words, int tag);

		//- (NSArray *)guessesForWord:(NSString *)word;
		[Export ("guessesForWord:")]
		NSArray GuessesForWord (string word);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//- (NSArray *)completionsForPartialWordRange:(NSRange)range inString:(NSString *)string language:(NSString *)language inSpellDocumentWithTag:(NSInteger)tag;
		[Export ("completionsForPartialWordRange:inString:language:inSpellDocumentWithTag:")]
		NSArray CompletionsForPartialWordRange (NSRange range, string string1, string language, int tag);

//#endif
		//- (void)closeSpellDocumentWithTag:(NSInteger)tag;
		[Export ("closeSpellDocumentWithTag:")]
		void CloseSpellDocumentWithTag (int tag);

		//- (NSString *)language;
		[Export ("language")]
		string Language { get; }

		//- (BOOL)setLanguage:(NSString *)language;
		[Export ("setLanguage:")]
		bool SetLanguage (string language);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (NSArray *)availableLanguages;
		[Export ("availableLanguages")]
		NSArray AvailableLanguages { get; }

//#endif 
		//- (void)setWordFieldStringValue:(NSString *)aString;
		[Export ("setWordFieldStringValue:")]
		void SetWordFieldStringValue (string aString);

		//- (void)learnWord:(NSString *)word;
		[Export ("learnWord:")]
		void LearnWord (string word);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (BOOL)hasLearnedWord:(NSString *)word;
		[Export ("hasLearnedWord:")]
		bool HasLearnedWord (string word);

		//- (void)unlearnWord:(NSString *)word;
		[Export ("unlearnWord:")]
		void UnlearnWord (string word);

//#endif 
		////- (void)forgetWord:(NSString *)word;
		//[Export ("forgetWord:")]
		//void ForgetWord (string word);

	}
}
