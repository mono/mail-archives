using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSObject))]
	interface NSAnimationContext {

		//+ (void)beginGrouping;
		[Static, Export ("beginGrouping")]
		void BeginGrouping ();

		//+ (void)endGrouping;
		[Static, Export ("endGrouping")]
		void EndGrouping ();

		//+ (NSAnimationContext *)currentContext;
		[Static, Export ("currentContext")]
		NSAnimationContext CurrentContext { get; }

		//- (NSTimeInterval)duration;
		[Export ("duration")]
		double Duration { get; set; }

	}
}
