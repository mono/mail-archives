using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSObject))]
	interface NSPrintPanel {

//#if __LP64__
//#endif
		//+ (NSPrintPanel *)printPanel;
		[Static, Export ("printPanel")]
		NSPrintPanel PrintPanel { get; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (void)addAccessoryController:(NSViewController<NSPrintPanelAccessorizing> *)accessoryController;
		[Export ("addAccessoryController:")]
		void AddAccessoryController (NSViewController accessoryController);

		//- (void)removeAccessoryController:(NSViewController<NSPrintPanelAccessorizing> *)accessoryController;
		[Export ("removeAccessoryController:")]
		void RemoveAccessoryController (NSViewController accessoryController);

		//- (NSArray *)accessoryControllers;
		[Export ("accessoryControllers")]
		NSArray AccessoryControllers { get; }

		//- (NSPrintPanelOptions)options;
		[Export ("options")]
		NSPrintPanelOptions Options { get; set; }

		//- (NSString *)defaultButtonTitle;
		[Export ("defaultButtonTitle")]
		string DefaultButtonTitle { get; set; }

		//- (NSString *)helpAnchor;
		[Export ("helpAnchor")]
		string HelpAnchor { get; set; }

//#endif
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_2
		//- (NSString *)jobStyleHint;
		[Export ("jobStyleHint")]
		string JobStyleHint { get; set; }

//#endif
		//- (void)beginSheetWithPrintInfo:(NSPrintInfo *)printInfo modalForWindow:(NSWindow *)docWindow delegate:(id)delegate didEndSelector:(SEL)didEndSelector contextInfo:(void *)contextInfo;
		[Export ("beginSheetWithPrintInfo:modalForWindow:delegate:didEndSelector:contextInfo:")]
		void BeginSheetWithPrintInfo (NSPrintInfo printInfo, NSWindow docWindow, NSObject delegate1, Selector didEndSelector, IntPtr contextInfo);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (NSInteger)runModalWithPrintInfo:(NSPrintInfo *)printInfo;
		[Export ("runModalWithPrintInfo:")]
		int RunModalWithPrintInfo (NSPrintInfo printInfo);

//#endif
		//- (NSInteger)runModal;
		[Export ("runModal")]
		int RunModal { get; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (NSPrintInfo *)printInfo;
		[Export ("printInfo")]
		NSPrintInfo PrintInfo { get; }

//#endif
		////- (NSView *)accessoryView;
		//[Export ("accessoryView")]
		//NSView AccessoryView { get; set; }

		////- (void)updateFromPrintInfo;
		//[Export ("updateFromPrintInfo")]
		//void UpdateFromPrintInfo ();

		////- (void)finalWritePrintInfo;
		//[Export ("finalWritePrintInfo")]
		//void FinalWritePrintInfo ();

	}
}
