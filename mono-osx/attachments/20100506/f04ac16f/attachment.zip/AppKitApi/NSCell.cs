using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSObject))]
	interface NSCell {

		//+ (BOOL)prefersTrackingUntilMouseUp;
		[Static, Export ("prefersTrackingUntilMouseUp")]
		bool PrefersTrackingUntilMouseUp { get; }

		//- (id)initTextCell:(NSString *)aString;
		[Export ("initTextCell:")]
		IntPtr Constructor (string aString);

		//- (id)initImageCell:(NSImage *)image;
		[Export ("initImageCell:")]
		IntPtr Constructor (NSImage image);

		//- (NSView *)controlView;
		[Export ("controlView")]
		NSView ControlView { get; set; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
//#endif
		//- (NSCellType)type;
		[Export ("type")]
		NSCellType Type { get; set; }

		//- (NSInteger)state;
		[Export ("state")]
		int State { get; set; }

		//- (id)target;
		[Export ("target")]
		NSCell Target { get; }

		//- (void)setTarget:(id)anObject;
		[Export ("setTarget:")]
		void SetTarget (NSObject anObject);

		//- (SEL)action;
		[Export ("action")]
		Selector Action { get; set; }

		//- (NSInteger)tag;
		[Export ("tag")]
		int Tag { get; set; }

		//- (NSString*)title;
		[Export ("title")]
		string Title { get; set; }

		//- (BOOL)isOpaque;
		[Export ("isOpaque")]
		bool IsOpaque { get; }

		//- (BOOL)isEnabled;
		[Export ("isEnabled")]
		bool IsEnabled { get; }

		//- (void)setEnabled:(BOOL)flag;
		[Export ("setEnabled:")]
		void SetEnabled (bool flag);

		//- (NSInteger)sendActionOn:(NSInteger)mask;
		[Export ("sendActionOn:")]
		int SendActionOn (int mask);

		//- (BOOL)isContinuous;
		[Export ("isContinuous")]
		bool IsContinuous { get; }

		//- (void)setContinuous:(BOOL)flag;
		[Export ("setContinuous:")]
		void SetContinuous (bool flag);

		//- (BOOL)isEditable;
		[Export ("isEditable")]
		bool IsEditable { get; }

		//- (void)setEditable:(BOOL)flag;
		[Export ("setEditable:")]
		void SetEditable (bool flag);

		//- (BOOL)isSelectable;
		[Export ("isSelectable")]
		bool IsSelectable { get; }

		//- (void)setSelectable:(BOOL)flag;
		[Export ("setSelectable:")]
		void SetSelectable (bool flag);

		//- (BOOL)isBordered;
		[Export ("isBordered")]
		bool IsBordered { get; }

		//- (void)setBordered:(BOOL)flag;
		[Export ("setBordered:")]
		void SetBordered (bool flag);

		//- (BOOL)isBezeled;
		[Export ("isBezeled")]
		bool IsBezeled { get; }

		//- (void)setBezeled:(BOOL)flag;
		[Export ("setBezeled:")]
		void SetBezeled (bool flag);

		//- (BOOL)isScrollable;
		[Export ("isScrollable")]
		bool IsScrollable { get; }

		//- (void)setScrollable:(BOOL)flag;	
		[Export ("setScrollable:")]
		void SetScrollable (bool flag);

		//- (BOOL)isHighlighted;
		[Export ("isHighlighted")]
		bool IsHighlighted { get; }

		//- (void)setHighlighted:(BOOL)flag;
		[Export ("setHighlighted:")]
		void SetHighlighted (bool flag);

		//- (NSTextAlignment)alignment;
		[Export ("alignment")]
		NSTextAlignment Alignment { get; set; }

		//- (BOOL)wraps;
		[Export ("wraps")]
		bool Wraps { get; set; }

		//- (NSFont *)font;
		[Export ("font")]
		NSFont Font { get; set; }

		//- (NSInteger)entryType;
		[Export ("entryType")]
		int EntryType { get; set; }

		//- (BOOL)isEntryAcceptable:(NSString *)aString;
		[Export ("isEntryAcceptable:")]
		bool IsEntryAcceptable (string aString);

		//- (void)setFloatingPointFormat:(BOOL)autoRange left:(NSUInteger)leftDigits right:(NSUInteger)rightDigits;
		[Export ("setFloatingPointFormat:left:right:")]
		void SetFloatingPointFormat (bool autoRange, uint leftDigits, uint rightDigits);

		//- (NSString *)keyEquivalent;
		[Export ("keyEquivalent")]
		string KeyEquivalent { get; }

		//- (void)setFormatter:(NSFormatter *)newFormatter;
		[Export ("setFormatter:")]
		void SetFormatter (NSFormatter newFormatter);

		//- (id)formatter;
		[Export ("formatter")]
		NSCell Formatter { get; }

		//- (id)objectValue;
		[Export ("objectValue")]
		NSCell ObjectValue { get; }

		//- (void)setObjectValue:(id <NSCopying>)obj;
		[Export ("setObjectValue:")]
		void SetObjectValue (NSObject obj);

		//- (BOOL)hasValidObjectValue;
		[Export ("hasValidObjectValue")]
		bool HasValidObjectValue { get; }

		//- (NSString *)stringValue;
		[Export ("stringValue")]
		string StringValue { get; set; }

		//- (NSComparisonResult)compare:(id)otherCell;
		[Export ("compare:")]
		NSComparisonResult Compare (NSObject otherCell);

		//- (int)intValue;
		[Export ("intValue")]
		int IntValue { get; set; }

		//- (float)floatValue;
		[Export ("floatValue")]
		float FloatValue { get; set; }

		//- (double)doubleValue;
		[Export ("doubleValue")]
		double DoubleValue { get; set; }

		//- (void)takeIntValueFrom:(id)sender;
		[Export ("takeIntValueFrom:")]
		void TakeIntValueFrom (NSObject sender);

		//- (void)takeFloatValueFrom:(id)sender;
		[Export ("takeFloatValueFrom:")]
		void TakeFloatValueFrom (NSObject sender);

		//- (void)takeDoubleValueFrom:(id)sender;
		[Export ("takeDoubleValueFrom:")]
		void TakeDoubleValueFrom (NSObject sender);

		//- (void)takeStringValueFrom:(id)sender;
		[Export ("takeStringValueFrom:")]
		void TakeStringValueFrom (NSObject sender);

		//- (void)takeObjectValueFrom:(id)sender;
		[Export ("takeObjectValueFrom:")]
		void TakeObjectValueFrom (NSObject sender);

		//- (NSImage *)image;
		[Export ("image")]
		NSImage Image { get; set; }

		//- (NSControlTint)controlTint;
		[Export ("controlTint")]
		NSControlTint ControlTint { get; set; }

		//- (NSControlSize)controlSize;
		[Export ("controlSize")]
		NSControlSize ControlSize { get; set; }

		//- (id)representedObject;
		[Export ("representedObject")]
		NSCell RepresentedObject { get; }

		//- (void)setRepresentedObject:(id)anObject;
		[Export ("setRepresentedObject:")]
		void SetRepresentedObject (NSObject anObject);

		//- (NSInteger)cellAttribute:(NSCellAttribute)aParameter;
		[Export ("cellAttribute:")]
		int CellAttribute (NSCellAttribute aParameter);

		//- (void)setCellAttribute:(NSCellAttribute)aParameter to:(NSInteger)value;
		[Export ("setCellAttribute:to:")]
		void SetCellAttribute (NSCellAttribute aParameter, int value);

		//- (NSRect)imageRectForBounds:(NSRect)theRect;
		[Export ("imageRectForBounds:")]
		RectangleF ImageRectForBounds (RectangleF theRect);

		//- (NSRect)titleRectForBounds:(NSRect)theRect;
		[Export ("titleRectForBounds:")]
		RectangleF TitleRectForBounds (RectangleF theRect);

		//- (NSRect)drawingRectForBounds:(NSRect)theRect;
		[Export ("drawingRectForBounds:")]
		RectangleF DrawingRectForBounds (RectangleF theRect);

		//- (NSSize)cellSize;
		[Export ("cellSize")]
		NSSize CellSize { get; }

		//- (NSSize)cellSizeForBounds:(NSRect)aRect;
		[Export ("cellSizeForBounds:")]
		NSSize CellSizeForBounds (RectangleF aRect);

		//- (NSColor *)highlightColorWithFrame:(NSRect)cellFrame inView:(NSView *)controlView;
		[Export ("highlightColorWithFrame:inView:")]
		NSColor HighlightColorWithFrame (RectangleF cellFrame, NSView controlView);

		//- (void)calcDrawInfo:(NSRect)aRect;
		[Export ("calcDrawInfo:")]
		void CalcDrawInfo (RectangleF aRect);

		//- (NSText *)setUpFieldEditorAttributes:(NSText *)textObj;
		[Export ("setUpFieldEditorAttributes:")]
		NSText SetUpFieldEditorAttributes (NSText textObj);

		//- (void)drawInteriorWithFrame:(NSRect)cellFrame inView:(NSView *)controlView;
		[Export ("drawInteriorWithFrame:inView:")]
		void DrawInteriorWithFrame (RectangleF cellFrame, NSView controlView);

		//- (void)drawWithFrame:(NSRect)cellFrame inView:(NSView *)controlView;
		[Export ("drawWithFrame:inView:")]
		void DrawWithFrame (RectangleF cellFrame, NSView controlView);

		//- (void)highlight:(BOOL)flag withFrame:(NSRect)cellFrame inView:(NSView *)controlView;
		[Export ("highlight:withFrame:inView:")]
		void Highlight (bool flag, RectangleF cellFrame, NSView controlView);

		//- (NSInteger)mouseDownFlags;
		[Export ("mouseDownFlags")]
		int MouseDownFlags { get; }

		//- (void)getPeriodicDelay:(float *)delay interval:(float *)interval;
		[Export ("getPeriodicDelay:interval:")]
		void GetPeriodicDelay (float delay, float interval);

		//- (BOOL)startTrackingAt:(NSPoint)startPoint inView:(NSView *)controlView;
		[Export ("startTrackingAt:inView:")]
		bool StartTrackingAt (PointF startPoint, NSView controlView);

		//- (BOOL)continueTracking:(NSPoint)lastPoint at:(NSPoint)currentPoint inView:(NSView *)controlView;
		[Export ("continueTracking:at:inView:")]
		bool ContinueTracking (PointF lastPoint, PointF currentPoint, NSView controlView);

		//- (void)stopTracking:(NSPoint)lastPoint at:(NSPoint)stopPoint inView:(NSView *)controlView mouseIsUp:(BOOL)flag;
		[Export ("stopTracking:at:inView:mouseIsUp:")]
		void StopTracking (PointF lastPoint, PointF stopPoint, NSView controlView, bool flag);

		//- (BOOL)trackMouse:(NSEvent *)theEvent inRect:(NSRect)cellFrame ofView:(NSView *)controlView untilMouseUp:(BOOL)flag;
		[Export ("trackMouse:inRect:ofView:untilMouseUp:")]
		bool TrackMouse (NSEvent theEvent, RectangleF cellFrame, NSView controlView, bool flag);

		//- (void)editWithFrame:(NSRect)aRect inView:(NSView *)controlView editor:(NSText *)textObj delegate:(id)anObject event:(NSEvent *)theEvent;
		[Export ("editWithFrame:inView:editor:delegate:event:")]
		void EditWithFrame (RectangleF aRect, NSView controlView, NSText textObj, NSObject anObject, NSEvent theEvent);

		//- (void)selectWithFrame:(NSRect)aRect inView:(NSView *)controlView editor:(NSText *)textObj delegate:(id)anObject start:(NSInteger)selStart length:(NSInteger)selLength;
		[Export ("selectWithFrame:inView:editor:delegate:start:length:")]
		void SelectWithFrame (RectangleF aRect, NSView controlView, NSText textObj, NSObject anObject, int selStart, int selLength);

		//- (void)endEditing:(NSText *)textObj;
		[Export ("endEditing:")]
		void EndEditing (NSText textObj);

		//- (void)resetCursorRect:(NSRect)cellFrame inView:(NSView *)controlView;
		[Export ("resetCursorRect:inView:")]
		void ResetCursorRect (RectangleF cellFrame, NSView controlView);

		//- (NSMenu *)menu;
		[Export ("menu")]
		NSMenu Menu { get; set; }

		//- (NSMenu *)menuForEvent:(NSEvent *)event inRect:(NSRect)cellFrame ofView:(NSView *)view;
		[Export ("menuForEvent:inRect:ofView:")]
		NSMenu MenuForEvent (NSEvent event1, RectangleF cellFrame, NSView view);

		//+ (NSMenu *)defaultMenu;
		[Static, Export ("defaultMenu")]
		NSMenu DefaultMenu { get; }

		//- (BOOL)sendsActionOnEndEditing;
		[Export ("sendsActionOnEndEditing")]
		bool SendsActionOnEndEditing { get; set; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (NSWritingDirection)baseWritingDirection;
		[Export ("baseWritingDirection")]
		NSWritingDirection BaseWritingDirection { get; set; }

		//- (NSLineBreakMode)lineBreakMode;
		[Export ("lineBreakMode")]
		NSLineBreakMode LineBreakMode { get; set; }

		//- (BOOL)allowsUndo;
		[Export ("allowsUndo")]
		bool AllowsUndo { get; set; }

//#endif 
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (NSInteger)integerValue;
		[Export ("integerValue")]
		int IntegerValue { get; set; }

		//- (void)takeIntegerValueFrom:(id)sender;
		[Export ("takeIntegerValueFrom:")]
		void TakeIntegerValueFrom (NSObject sender);

//#endif 
		//- (BOOL)truncatesLastVisibleLine AVAILABLE_MAC_OS_X_VERSION_10_5_AND_LATER;
		[Export ("truncatesLastVisibleLine")]
		bool TruncatesLastVisibleLine { get; set; }

		//- (BOOL)refusesFirstResponder;
		[Export ("refusesFirstResponder")]
		bool RefusesFirstResponder { get; }

		//- (BOOL)acceptsFirstResponder;
		[Export ("acceptsFirstResponder")]
		bool AcceptsFirstResponder { get; }

		//- (BOOL)showsFirstResponder;
		[Export ("showsFirstResponder")]
		bool ShowsFirstResponder { get; set; }

		//- (NSUInteger)mnemonicLocation;
		[Export ("mnemonicLocation")]
		uint MnemonicLocation { get; set; }

		//- (NSString *)mnemonic;
		[Export ("mnemonic")]
		string Mnemonic { get; }

		//- (void)setTitleWithMnemonic:(NSString *)stringWithAmpersand;
		[Export ("setTitleWithMnemonic:")]
		void SetTitleWithMnemonic (string stringWithAmpersand);

		//- (void)performClick:(id)sender;
		[Export ("performClick:")]
		void PerformClick (NSObject sender);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//- (NSFocusRingType)focusRingType;
		[Export ("focusRingType")]
		NSFocusRingType FocusRingType { get; set; }

		//+ (NSFocusRingType)defaultFocusRingType;
		[Static, Export ("defaultFocusRingType")]
		NSFocusRingType DefaultFocusRingType { get; }

//#endif
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_2
		//- (BOOL)wantsNotificationForMarkedText; 
		[Export ("wantsNotificationForMarkedText")]
		bool WantsNotificationForMarkedText { get; }

//#endif 
		//- (void)setAttributedStringValue:(NSAttributedString *)obj;
		[Export ("setAttributedStringValue:")]
		void SetAttributedStringValue (NSAttributedString obj);

		//- (BOOL)allowsEditingTextAttributes;
		[Export ("allowsEditingTextAttributes")]
		bool AllowsEditingTextAttributes { get; set; }

		//- (BOOL)importsGraphics;
		[Export ("importsGraphics")]
		bool ImportsGraphics { get; set; }

		//- (BOOL)allowsMixedState;
		[Export ("allowsMixedState")]
		bool AllowsMixedState { get; }

		//- (NSInteger)nextState;			
		[Export ("nextState")]
		int NextState { get; }

		//- (void)setNextState;			
		[Export ("setNextState")]
		void SetNextState ();

		//- (NSUInteger)hitTestForEvent:(NSEvent *)event inRect:(NSRect)cellFrame ofView:(NSView *)controlView;
		[Export ("hitTestForEvent:inRect:ofView:")]
		uint HitTestForEventInRect (NSEvent event1, RectangleF cellFrame, NSView controlView);

		//- (NSRect)expansionFrameWithFrame:(NSRect)cellFrame inView:(NSView *)view;
		[Export ("expansionFrameWithFrame:inView:")]
		RectangleF ExpansionFrameWithFrameInView (RectangleF cellFrame, NSView view);

		//- (void)drawWithExpansionFrame:(NSRect)cellFrame inView:(NSView *)view;
		[Export ("drawWithExpansionFrame:inView:")]
		void DrawWithExpansionFrameInView (RectangleF cellFrame, NSView view);

		//- (NSBackgroundStyle)backgroundStyle;
		[Export ("backgroundStyle")]
		NSBackgroundStyle BackgroundStyle { get; set; }

		//- (NSBackgroundStyle)interiorBackgroundStyle;
		[Export ("interiorBackgroundStyle")]
		NSBackgroundStyle InteriorBackgroundStyle { get; }

	}
}
