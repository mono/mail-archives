using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSTextFieldCell))]
	interface NSSearchFieldCell {

		//- (NSButtonCell*) searchButtonCell;
		[Export ("searchButtonCell")]
		NSButtonCell SearchButtonCell { get; set; }

		//    - (NSButtonCell*) cancelButtonCell;
		[Export ("cancelButtonCell")]
		NSButtonCell CancelButtonCell { get; set; }

		//    - (void) resetSearchButtonCell;
		[Export ("resetSearchButtonCell")]
		void ResetSearchButtonCell ();

		//- (void) resetCancelButtonCell;
		[Export ("resetCancelButtonCell")]
		void ResetCancelButtonCell ();

		//    - (NSRect) searchTextRectForBounds:(NSRect)rect;
		[Export ("searchTextRectForBounds:")]
		RectangleF SearchTextRectForBounds (RectangleF rect);

		//- (NSRect) searchButtonRectForBounds:(NSRect)rect;
		[Export ("searchButtonRectForBounds:")]
		RectangleF SearchButtonRectForBounds (RectangleF rect);

		//- (NSRect) cancelButtonRectForBounds:(NSRect)rect;
		[Export ("cancelButtonRectForBounds:")]
		RectangleF CancelButtonRectForBounds (RectangleF rect);

		//- (NSMenu*)searchMenuTemplate;
		[Export ("searchMenuTemplate")]
		NSMenu SearchMenuTemplate { get; set; }

		//- (BOOL) sendsWholeSearchString;
		[Export ("sendsWholeSearchString")]
		bool SendsWholeSearchString { get; set; }

		//- (NSInteger) maximumRecents;
		[Export ("maximumRecents")]
		int MaximumRecents { get; set; }

		//- (NSArray*) recentSearches;
		[Export ("recentSearches")]
		NSArray RecentSearches { get; set; }

		//- (NSString*) recentsAutosaveName;
		[Export ("recentsAutosaveName")]
		string RecentsAutosaveName { get; set; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//    - (BOOL) sendsSearchStringImmediately;
		[Export ("sendsSearchStringImmediately")]
		bool SendsSearchStringImmediately { get; set; }

//#endif
	}
}
