using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSObject))]
	interface NSImage {

		//+ (id)imageNamed:(NSString *)name;	
		[Static, Export ("imageNamed:")]
		NSImage ImageNamed (string name);

		//- (id)initWithSize:(NSSize)aSize;
		[Export ("initWithSize:")]
		IntPtr Constructor (NSSize aSize);

		//- (id)initWithData:(NSData *)data;			
		[Export ("initWithData:")]
		IntPtr Constructor (NSData data);

		//- (id)initWithContentsOfFile:(NSString *)fileName;	
		[Export ("initWithContentsOfFile:")]
		IntPtr Constructor (string fileName);

		//- (id)initWithContentsOfURL:(NSURL *)url;               
		[Export ("initWithContentsOfURL:")]
		IntPtr Constructor (NSUrl url);

		////- (id)initByReferencingFile:(NSString *)fileName;	
		//[Export ("initByReferencingFile:")]
		//IntPtr Constructor (string fileName);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_2
		////- (id)initByReferencingURL:(NSURL *)url;		
		//[Export ("initByReferencingURL:")]
		//IntPtr Constructor (NSUrl url);

//#endif
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (id)initWithIconRef:(IconRef)iconRef;
		[Export ("initWithIconRef:")]
		IntPtr Constructor (IconRef iconRef);

//#endif
		//- (id)initWithPasteboard:(NSPasteboard *)pasteboard;
		[Export ("initWithPasteboard:")]
		IntPtr Constructor (NSPasteboard pasteboard);

		//- (NSSize)size;
		[Export ("size")]
		NSSize Size { get; set; }

		//- (BOOL)setName:(NSString *)string;
		[Export ("setName:")]
		bool SetName (string string1);

		//- (NSString *)name;
		[Export ("name")]
		string Name { get; }

		//- (BOOL)scalesWhenResized;
		[Export ("scalesWhenResized")]
		bool ScalesWhenResized { get; set; }

		//- (void)setDataRetained:(BOOL)flag;
		[Export ("setDataRetained:")]
		void SetDataRetained (bool flag);

		//- (BOOL)isDataRetained;
		[Export ("isDataRetained")]
		bool IsDataRetained { get; }

		//- (void)setCachedSeparately:(BOOL)flag;
		[Export ("setCachedSeparately:")]
		void SetCachedSeparately (bool flag);

		//- (BOOL)isCachedSeparately;
		[Export ("isCachedSeparately")]
		bool IsCachedSeparately { get; }

		//- (BOOL)cacheDepthMatchesImageDepth;
		[Export ("cacheDepthMatchesImageDepth")]
		bool CacheDepthMatchesImageDepth { get; set; }

		//- (NSColor *)backgroundColor;
		[Export ("backgroundColor")]
		NSColor BackgroundColor { get; set; }

		//- (BOOL)usesEPSOnResolutionMismatch;
		[Export ("usesEPSOnResolutionMismatch")]
		bool UsesEPSOnResolutionMismatch { get; set; }

		//- (BOOL)prefersColorMatch;
		[Export ("prefersColorMatch")]
		bool PrefersColorMatch { get; set; }

		//- (BOOL)matchesOnMultipleResolution;
		[Export ("matchesOnMultipleResolution")]
		bool MatchesOnMultipleResolution { get; set; }

		//- (void)dissolveToPoint:(NSPoint)point fraction:(CGFloat)aFloat;
		[Export ("dissolveToPoint:fraction:")]
		void DissolveToPoint (PointF point, float aFloat);

		//- (void)dissolveToPoint:(NSPoint)point fromRect:(NSRect)rect fraction:(CGFloat)aFloat;
		[Export ("dissolveToPoint:fromRect:fraction:")]
		void DissolveToPoint (PointF point, RectangleF rect, float aFloat);

		//- (void)compositeToPoint:(NSPoint)point operation:(NSCompositingOperation)op;
		[Export ("compositeToPoint:operation:")]
		void CompositeToPoint (PointF point, NSCompositingOperation op);

		//- (void)compositeToPoint:(NSPoint)point fromRect:(NSRect)rect operation:(NSCompositingOperation)op;
		[Export ("compositeToPoint:fromRect:operation:")]
		void CompositeToPoint (PointF point, RectangleF rect, NSCompositingOperation op);

		//- (void)compositeToPoint:(NSPoint)point operation:(NSCompositingOperation)op fraction:(CGFloat)delta;
		[Export ("compositeToPoint:operation:fraction:")]
		void CompositeToPoint (PointF point, NSCompositingOperation op, float delta);

		//- (void)compositeToPoint:(NSPoint)point fromRect:(NSRect)rect operation:(NSCompositingOperation)op fraction:(CGFloat)delta;
		[Export ("compositeToPoint:fromRect:operation:fraction:")]
		void CompositeToPoint (PointF point, RectangleF rect, NSCompositingOperation op, float delta);

		//- (void)drawAtPoint:(NSPoint)point fromRect:(NSRect)fromRect operation:(NSCompositingOperation)op fraction:(CGFloat)delta;
		[Export ("drawAtPoint:fromRect:operation:fraction:")]
		void DrawAtPoint (PointF point, RectangleF fromRect, NSCompositingOperation op, float delta);

		//- (void)drawInRect:(NSRect)rect fromRect:(NSRect)fromRect operation:(NSCompositingOperation)op fraction:(CGFloat)delta;
		[Export ("drawInRect:fromRect:operation:fraction:")]
		void DrawInRect (RectangleF rect, RectangleF fromRect, NSCompositingOperation op, float delta);

		//- (BOOL)drawRepresentation:(NSImageRep *)imageRep inRect:(NSRect)rect;
		[Export ("drawRepresentation:inRect:")]
		bool DrawRepresentation (NSImageRep imageRep, RectangleF rect);

		//- (void)recache;
		[Export ("recache")]
		void Recache ();

		//- (NSData *)TIFFRepresentation;
		[Export ("TIFFRepresentation")]
		NSData TIFFRepresentation { get; }

		//- (NSData *)TIFFRepresentationUsingCompression:(NSTIFFCompression)comp factor:(float)aFloat;
		[Export ("TIFFRepresentationUsingCompression:factor:")]
		NSData TIFFRepresentationUsingCompression (NSTIFFCompression comp, float aFloat);

		//- (NSArray *)representations;
		[Export ("representations")]
		NSArray Representations { get; }

		//- (void)addRepresentations:(NSArray *)imageReps;
		[Export ("addRepresentations:")]
		void AddRepresentations (NSArray imageReps);

		//- (void)addRepresentation:(NSImageRep *)imageRep;
		[Export ("addRepresentation:")]
		void AddRepresentation (NSImageRep imageRep);

		//- (void)removeRepresentation:(NSImageRep *)imageRep;
		[Export ("removeRepresentation:")]
		void RemoveRepresentation (NSImageRep imageRep);

		//- (BOOL)isValid;
		[Export ("isValid")]
		bool IsValid { get; }

		//- (void)lockFocus;
		[Export ("lockFocus")]
		void LockFocus ();

		//- (void)lockFocusOnRepresentation:(NSImageRep *)imageRepresentation;
		[Export ("lockFocusOnRepresentation:")]
		void LockFocusOnRepresentation (NSImageRep imageRepresentation);

		//- (void)unlockFocus;
		[Export ("unlockFocus")]
		void UnlockFocus ();

		//- (NSImageRep *)bestRepresentationForDevice:(NSDictionary *)deviceDescription;
		[Export ("bestRepresentationForDevice:")]
		NSImageRep BestRepresentationForDevice (NSDictionary deviceDescription);

		//- (void)setDelegate:(id)anObject;
		[Export ("setDelegate:")]
		void SetDelegate (NSObject anObject);

		//- (id)delegate;
		[Export ("delegate")]
		NSImage Delegate { get; }

		//+ (NSArray *)imageUnfilteredFileTypes;
		[Static, Export ("imageUnfilteredFileTypes")]
		NSArray ImageUnfilteredFileTypes { get; }

		//+ (NSArray *)imageUnfilteredPasteboardTypes;
		[Static, Export ("imageUnfilteredPasteboardTypes")]
		NSArray ImageUnfilteredPasteboardTypes { get; }

		//+ (NSArray *)imageFileTypes;
		[Static, Export ("imageFileTypes")]
		NSArray ImageFileTypes { get; }

		//+ (NSArray *)imagePasteboardTypes;
		[Static, Export ("imagePasteboardTypes")]
		NSArray ImagePasteboardTypes { get; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//+ (NSArray *)imageTypes;
		[Static, Export ("imageTypes")]
		NSArray ImageTypes { get; }

		//+ (NSArray *)imageUnfilteredTypes;
		[Static, Export ("imageUnfilteredTypes")]
		NSArray ImageUnfilteredTypes { get; }

//#endif
		//+ (BOOL)canInitWithPasteboard:(NSPasteboard *)pasteboard;
		[Static, Export ("canInitWithPasteboard:")]
		bool CanInitWithPasteboard (NSPasteboard pasteboard);

		//- (void)setFlipped:(BOOL)flag;
		[Export ("setFlipped:")]
		void SetFlipped (bool flag);

		//- (BOOL)isFlipped;
		[Export ("isFlipped")]
		bool IsFlipped { get; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_2
		//- (void)cancelIncrementalLoad;
		[Export ("cancelIncrementalLoad")]
		void CancelIncrementalLoad ();

		//-(NSImageCacheMode)cacheMode;
		[Export ("cacheMode")]
		NSImageCacheMode CacheMode { get; set; }

//#endif
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (NSRect)alignmentRect;
		[Export ("alignmentRect")]
		RectangleF AlignmentRect { get; set; }

		//- (BOOL)isTemplate;
		[Export ("isTemplate")]
		bool IsTemplate { get; }

		//- (void)setTemplate:(BOOL)isTemplate;
		[Export ("setTemplate:")]
		void SetTemplate (bool isTemplate);

//#endif
	}
}
