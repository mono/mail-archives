using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSControl))]
	interface NSMatrix {

		//- (id)initWithFrame:(NSRect)frameRect;
		[Export ("initWithFrame:")]
		IntPtr Constructor (RectangleF frameRect);

		//- (id)initWithFrame:(NSRect)frameRect mode:(NSMatrixMode)aMode prototype:(NSCell *)aCell numberOfRows:(NSInteger)rowsHigh numberOfColumns:(NSInteger)colsWide;
		[Export ("initWithFrame:mode:prototype:numberOfRows:numberOfColumns:")]
		IntPtr Constructor (RectangleF frameRect, NSMatrixMode aMode, NSCell aCell, int rowsHigh, int colsWide);

		//- (id)initWithFrame:(NSRect)frameRect mode:(NSMatrixMode)aMode cellClass:(Class)factoryId numberOfRows:(NSInteger)rowsHigh numberOfColumns:(NSInteger)colsWide;
		[Export ("initWithFrame:mode:cellClass:numberOfRows:numberOfColumns:")]
		IntPtr Constructor (RectangleF frameRect, NSMatrixMode aMode, Class factoryId, int rowsHigh, int colsWide);

		//- (Class)cellClass;
		[Export ("cellClass")]
		Class CellClass { get; set; }

		//- (id)prototype;
		[Export ("prototype")]
		NSMatrix Prototype { get; }

		//- (void)setPrototype:(NSCell *)aCell;
		[Export ("setPrototype:")]
		void SetPrototype (NSCell aCell);

		//- (NSCell *)makeCellAtRow:(NSInteger)row column:(NSInteger)col;
		[Export ("makeCellAtRow:column:")]
		NSCell MakeCellAtRow (int row, int col);

		//- (NSMatrixMode)mode;
		[Export ("mode")]
		NSMatrixMode Mode { get; set; }

		//- (BOOL)allowsEmptySelection;
		[Export ("allowsEmptySelection")]
		bool AllowsEmptySelection { get; set; }

		//- (void)sendAction:(SEL)aSelector to:(id)anObject forAllCells:(BOOL)flag;
		[Export ("sendAction:to:forAllCells:")]
		void SendActionTo (Selector aSelector, NSObject anObject, bool flag);

		//- (NSArray *)cells;
		[Export ("cells")]
		NSArray Cells { get; }

		//- (void)sortUsingSelector:(SEL)comparator;
		[Export ("sortUsingSelector:")]
		void SortUsingSelector (Selector comparator);

		////- (void)sortUsingFunction:(NSInteger (*)(id, id, void *))compare context:(void *)context;
		//[Export ("sortUsingFunction:context:")]
		//void SortUsingFunction ((NSInteger (*, IntPtr context);

		//- (id)selectedCell;
		[Export ("selectedCell")]
		NSMatrix SelectedCell { get; }

		//- (NSArray *)selectedCells;
		[Export ("selectedCells")]
		NSArray SelectedCells { get; }

		//- (NSInteger)selectedRow;
		[Export ("selectedRow")]
		int SelectedRow { get; }

		//- (NSInteger)selectedColumn;
		[Export ("selectedColumn")]
		int SelectedColumn { get; }

		//- (void)setSelectionByRect:(BOOL)flag;
		[Export ("setSelectionByRect:")]
		void SetSelectionByRect (bool flag);

		//- (BOOL)isSelectionByRect;
		[Export ("isSelectionByRect")]
		bool IsSelectionByRect { get; }

		//- (void)setSelectionFrom:(NSInteger)startPos to:(NSInteger)endPos anchor:(NSInteger)anchorPos highlight:(BOOL)lit;
		[Export ("setSelectionFrom:to:anchor:highlight:")]
		void SetSelectionFrom (int startPos, int endPos, int anchorPos, bool lit);

		//- (void)deselectSelectedCell;
		[Export ("deselectSelectedCell")]
		void DeselectSelectedCell ();

		//- (void)deselectAllCells;
		[Export ("deselectAllCells")]
		void DeselectAllCells ();

		//- (void)selectCellAtRow:(NSInteger)row column:(NSInteger)col;
		[Export ("selectCellAtRow:column:")]
		void SelectCellAtRow (int row, int col);

		//- (void)selectAll:(id)sender;
		[Export ("selectAll:")]
		void SelectAll (NSObject sender);

		//- (BOOL)selectCellWithTag:(NSInteger)anInt;
		[Export ("selectCellWithTag:")]
		bool SelectCellWithTag (int anInt);

		//- (NSSize)cellSize;
		[Export ("cellSize")]
		NSSize CellSize { get; set; }

		//- (NSSize)intercellSpacing;
		[Export ("intercellSpacing")]
		NSSize IntercellSpacing { get; set; }

		//- (void)setScrollable:(BOOL)flag;
		[Export ("setScrollable:")]
		void SetScrollable (bool flag);

		//- (NSColor *)backgroundColor;
		[Export ("backgroundColor")]
		NSColor BackgroundColor { get; set; }

		//- (NSColor *)cellBackgroundColor;
		[Export ("cellBackgroundColor")]
		NSColor CellBackgroundColor { get; set; }

		//- (BOOL)drawsCellBackground;
		[Export ("drawsCellBackground")]
		bool DrawsCellBackground { get; set; }

		//- (BOOL)drawsBackground;
		[Export ("drawsBackground")]
		bool DrawsBackground { get; set; }

		//- (void)setState:(NSInteger)value atRow:(NSInteger)row column:(NSInteger)col;
		[Export ("setState:atRow:column:")]
		void SetState (int value, int row, int col);

		//- (void)getNumberOfRows:(NSInteger *)rowCount columns:(NSInteger *)colCount;
		[Export ("getNumberOfRows:columns:")]
		void GetNumberOfRows (int rowCount, int colCount);

		//- (NSInteger)numberOfRows;
		[Export ("numberOfRows")]
		int NumberOfRows { get; }

		//- (NSInteger)numberOfColumns;
		[Export ("numberOfColumns")]
		int NumberOfColumns { get; }

		//- (id)cellAtRow:(NSInteger)row column:(NSInteger)col;
		[Export ("cellAtRow:column:")]
		NSMatrix CellAtRow (int row, int col);

		//- (NSRect)cellFrameAtRow:(NSInteger)row column:(NSInteger)col;
		[Export ("cellFrameAtRow:column:")]
		RectangleF CellFrameAtRow (int row, int col);

		//- (BOOL)getRow:(NSInteger *)row column:(NSInteger *)col ofCell:(NSCell *)aCell;
		[Export ("getRow:column:ofCell:")]
		bool GetRow (int row, int col, NSCell aCell);

		//- (BOOL)getRow:(NSInteger *)row column:(NSInteger *)col forPoint:(NSPoint)aPoint;
		[Export ("getRow:column:forPoint:")]
		bool GetRow (int row, int col, PointF aPoint);

		//- (void)renewRows:(NSInteger)newRows columns:(NSInteger)newCols;
		[Export ("renewRows:columns:")]
		void RenewRows (int newRows, int newCols);

		//- (void)putCell:(NSCell *)newCell atRow:(NSInteger)row column:(NSInteger)col;
		[Export ("putCell:atRow:column:")]
		void PutCell (NSCell newCell, int row, int col);

		//- (void)addRow;
		[Export ("addRow")]
		void AddRow ();

		//- (void)addRowWithCells:(NSArray *)newCells;
		[Export ("addRowWithCells:")]
		void AddRowWithCells (NSArray newCells);

		//- (void)insertRow:(NSInteger)row;
		[Export ("insertRow:")]
		void InsertRow (int row);

		//- (void)insertRow:(NSInteger)row withCells:(NSArray *)newCells;
		[Export ("insertRow:withCells:")]
		void InsertRow (int row, NSArray newCells);

		//- (void)removeRow:(NSInteger)row;
		[Export ("removeRow:")]
		void RemoveRow (int row);

		//- (void)addColumn;
		[Export ("addColumn")]
		void AddColumn ();

		//- (void)addColumnWithCells:(NSArray *)newCells;
		[Export ("addColumnWithCells:")]
		void AddColumnWithCells (NSArray newCells);

		//- (void)insertColumn:(NSInteger)column;
		[Export ("insertColumn:")]
		void InsertColumn (int column);

		//- (void)insertColumn:(NSInteger)column withCells:(NSArray *)newCells;
		[Export ("insertColumn:withCells:")]
		void InsertColumn (int column, NSArray newCells);

		//- (void)removeColumn:(NSInteger)col;
		[Export ("removeColumn:")]
		void RemoveColumn (int col);

		//- (id)cellWithTag:(NSInteger)anInt;
		[Export ("cellWithTag:")]
		NSMatrix CellWithTag (int anInt);

		//- (SEL)doubleAction;
		[Export ("doubleAction")]
		Selector DoubleAction { get; set; }

		//- (BOOL)autosizesCells;
		[Export ("autosizesCells")]
		bool AutosizesCells { get; set; }

		//- (void)sizeToCells;
		[Export ("sizeToCells")]
		void SizeToCells ();

		//- (void)setValidateSize:(BOOL)flag;
		[Export ("setValidateSize:")]
		void SetValidateSize (bool flag);

		//- (void)drawCellAtRow:(NSInteger)row column:(NSInteger)col;
		[Export ("drawCellAtRow:column:")]
		void DrawCellAtRow (int row, int col);

		//- (void)highlightCell:(BOOL)flag atRow:(NSInteger)row column:(NSInteger)col;
		[Export ("highlightCell:atRow:column:")]
		void HighlightCell (bool flag, int row, int col);

		//- (void)setAutoscroll:(BOOL)flag;
		[Export ("setAutoscroll:")]
		void SetAutoscroll (bool flag);

		//- (BOOL)isAutoscroll;
		[Export ("isAutoscroll")]
		bool IsAutoscroll { get; }

		//- (void)scrollCellToVisibleAtRow:(NSInteger)row column:(NSInteger)col;
		[Export ("scrollCellToVisibleAtRow:column:")]
		void ScrollCellToVisibleAtRow (int row, int col);

		//- (NSInteger)mouseDownFlags;
		[Export ("mouseDownFlags")]
		int MouseDownFlags { get; }

		//- (void)mouseDown:(NSEvent *)theEvent;
		[Export ("mouseDown:")]
		void MouseDown (NSEvent theEvent);

		//- (BOOL)performKeyEquivalent:(NSEvent *)theEvent;
		[Export ("performKeyEquivalent:")]
		bool PerformKeyEquivalent (NSEvent theEvent);

		//- (BOOL)sendAction;
		[Export ("sendAction")]
		bool SendAction { get; }

		//- (void)sendDoubleAction;
		[Export ("sendDoubleAction")]
		void SendDoubleAction ();

		//- (id)delegate;
		[Export ("delegate")]
		NSMatrix Delegate { get; }

		//- (void)setDelegate:(id)anObject;
		[Export ("setDelegate:")]
		void SetDelegate (NSObject anObject);

		//- (BOOL)textShouldBeginEditing:(NSText *)textObject;
		[Export ("textShouldBeginEditing:")]
		bool TextShouldBeginEditing (NSText textObject);

		//- (BOOL)textShouldEndEditing:(NSText *)textObject;
		[Export ("textShouldEndEditing:")]
		bool TextShouldEndEditing (NSText textObject);

		//- (void)textDidBeginEditing:(NSNotification *)notification;
		[Export ("textDidBeginEditing:")]
		void TextDidBeginEditing (NSNotification notification);

		//- (void)textDidEndEditing:(NSNotification *)notification;
		[Export ("textDidEndEditing:")]
		void TextDidEndEditing (NSNotification notification);

		//- (void)textDidChange:(NSNotification *)notification;
		[Export ("textDidChange:")]
		void TextDidChange (NSNotification notification);

		//- (void)selectText:(id)sender;
		[Export ("selectText:")]
		void SelectText (NSObject sender);

		//- (id)selectTextAtRow:(NSInteger)row column:(NSInteger)col;
		[Export ("selectTextAtRow:column:")]
		NSMatrix SelectTextAtRow (int row, int col);

		//- (BOOL)acceptsFirstMouse:(NSEvent *)theEvent;
		[Export ("acceptsFirstMouse:")]
		bool AcceptsFirstMouse (NSEvent theEvent);

		//- (void)resetCursorRects;
		[Export ("resetCursorRects")]
		void ResetCursorRects ();

		//- (void)setToolTip:(NSString *)toolTipString forCell:(NSCell *)cell;
		[Export ("setToolTip:forCell:")]
		void SetToolTip (string toolTipString, NSCell cell);

		//- (NSString *)toolTipForCell:(NSCell *)cell;
		[Export ("toolTipForCell:")]
		string ToolTipForCell (NSCell cell);

		//- (BOOL)tabKeyTraversesCells;
		[Export ("tabKeyTraversesCells")]
		bool TabKeyTraversesCells { get; }

		//- (void)setKeyCell:(NSCell *)keyCell;
		[Export ("setKeyCell:")]
		void SetKeyCell (NSCell keyCell);

		//- (id)keyCell;
		[Export ("keyCell")]
		NSMatrix KeyCell { get; }

	}
}
