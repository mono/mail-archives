using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSObject))]
	interface NSBezierPath {

		//+ (NSBezierPath *)bezierPath;
		[Static, Export ("bezierPath")]
		NSBezierPath BezierPath { get; }

		//+ (NSBezierPath *)bezierPathWithRect:(NSRect)rect;
		[Static, Export ("bezierPathWithRect:")]
		NSBezierPath BezierPathWithRect (RectangleF rect);

		//+ (NSBezierPath *)bezierPathWithOvalInRect:(NSRect)rect;
		[Static, Export ("bezierPathWithOvalInRect:")]
		NSBezierPath BezierPathWithOvalInRect (RectangleF rect);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//+ (NSBezierPath *)bezierPathWithRoundedRect:(NSRect)rect xRadius:(CGFloat)xRadius yRadius:(CGFloat)yRadius;
		[Static, Export ("bezierPathWithRoundedRect:xRadius:yRadius:")]
		NSBezierPath BezierPathWithRoundedRect (RectangleF rect, float xRadius, float yRadius);

//#endif 
		//+ (void)fillRect:(NSRect)rect;
		[Static, Export ("fillRect:")]
		void FillRect (RectangleF rect);

		//+ (void)strokeRect:(NSRect)rect;
		[Static, Export ("strokeRect:")]
		void StrokeRect (RectangleF rect);

		//+ (void)clipRect:(NSRect)rect;
		[Static, Export ("clipRect:")]
		void ClipRect (RectangleF rect);

		//+ (void)strokeLineFromPoint:(NSPoint)point1 toPoint:(NSPoint)point2;
		[Static, Export ("strokeLineFromPoint:toPoint:")]
		void StrokeLineFromPoint (PointF point1, PointF point2);

		////+ (void)drawPackedGlyphs:(const char *)packedGlyphs atPoint:(NSPoint)point;
		//[Static, Export ("drawPackedGlyphs:atPoint:")]
		//void DrawPackedGlyphs (const char packedGlyphs, PointF point);

		//+ (void)setDefaultMiterLimit:(CGFloat)limit;
		[Static, Export ("setDefaultMiterLimit:")]
		void SetDefaultMiterLimit (float limit);

		//+ (CGFloat)defaultMiterLimit;
		[Static, Export ("defaultMiterLimit")]
		float DefaultMiterLimit { get; }

		//+ (void)setDefaultFlatness:(CGFloat)flatness;
		[Static, Export ("setDefaultFlatness:")]
		void SetDefaultFlatness (float flatness);

		//+ (CGFloat)defaultFlatness;
		[Static, Export ("defaultFlatness")]
		float DefaultFlatness { get; }

		//+ (void)setDefaultWindingRule:(NSWindingRule)windingRule;
		[Static, Export ("setDefaultWindingRule:")]
		void SetDefaultWindingRule (NSWindingRule windingRule);

		//+ (NSWindingRule)defaultWindingRule;
		[Static, Export ("defaultWindingRule")]
		NSWindingRule DefaultWindingRule { get; }

		//+ (void)setDefaultLineCapStyle:(NSLineCapStyle)lineCapStyle;
		[Static, Export ("setDefaultLineCapStyle:")]
		void SetDefaultLineCapStyle (NSLineCapStyle lineCapStyle);

		//+ (NSLineCapStyle)defaultLineCapStyle;
		[Static, Export ("defaultLineCapStyle")]
		NSLineCapStyle DefaultLineCapStyle { get; }

		//+ (void)setDefaultLineJoinStyle:(NSLineJoinStyle)lineJoinStyle;
		[Static, Export ("setDefaultLineJoinStyle:")]
		void SetDefaultLineJoinStyle (NSLineJoinStyle lineJoinStyle);

		//+ (NSLineJoinStyle)defaultLineJoinStyle;
		[Static, Export ("defaultLineJoinStyle")]
		NSLineJoinStyle DefaultLineJoinStyle { get; }

		//+ (void)setDefaultLineWidth:(CGFloat)lineWidth;
		[Static, Export ("setDefaultLineWidth:")]
		void SetDefaultLineWidth (float lineWidth);

		//+ (CGFloat)defaultLineWidth;
		[Static, Export ("defaultLineWidth")]
		float DefaultLineWidth { get; }

		//- (void)moveToPoint:(NSPoint)point;
		[Export ("moveToPoint:")]
		void MoveToPoint (PointF point);

		//- (void)lineToPoint:(NSPoint)point;
		[Export ("lineToPoint:")]
		void LineToPoint (PointF point);

		//- (void)curveToPoint:(NSPoint)endPoint       controlPoint1:(NSPoint)controlPoint1       controlPoint2:(NSPoint)controlPoint2;
		[Export ("curveToPoint:controlPoint1:controlPoint2:")]
		void CurveToPoint (PointF endPoint, PointF controlPoint1, PointF controlPoint2);

		//- (void)closePath;
		[Export ("closePath")]
		void ClosePath ();

		//- (void)removeAllPoints;
		[Export ("removeAllPoints")]
		void RemoveAllPoints ();

		//- (void)relativeMoveToPoint:(NSPoint)point;
		[Export ("relativeMoveToPoint:")]
		void RelativeMoveToPoint (PointF point);

		//- (void)relativeLineToPoint:(NSPoint)point;
		[Export ("relativeLineToPoint:")]
		void RelativeLineToPoint (PointF point);

		//- (void)relativeCurveToPoint:(NSPoint)endPoint	       controlPoint1:(NSPoint)controlPoint1	       controlPoint2:(NSPoint)controlPoint2;
		[Export ("relativeCurveToPoint:")]
		void RelativeCurveToPoint (PointF endPoint, PointF controlPoint1, PointF controlPoint2);

		//- (CGFloat)lineWidth;
		[Export ("lineWidth")]
		float LineWidth { get; set; }

		//- (NSLineCapStyle)lineCapStyle;
		[Export ("lineCapStyle")]
		NSLineCapStyle LineCapStyle { get; set; }

		//- (NSLineJoinStyle)lineJoinStyle;
		[Export ("lineJoinStyle")]
		NSLineJoinStyle LineJoinStyle { get; set; }

		//- (NSWindingRule)windingRule;
		[Export ("windingRule")]
		NSWindingRule WindingRule { get; set; }

		//- (CGFloat)miterLimit;
		[Export ("miterLimit")]
		float MiterLimit { get; set; }

		//- (CGFloat)flatness;
		[Export ("flatness")]
		float Flatness { get; set; }

		//- (void)getLineDash:(CGFloat *)pattern count:(NSInteger *)count phase:(CGFloat *)phase;
		[Export ("getLineDash:count:phase:")]
		void GetLineDash (float pattern, int count, float phase);

		////- (void)setLineDash:(const CGFloat *)pattern count:(NSInteger)count phase:(CGFloat)phase;
		//[Export ("setLineDash:count:phase:")]
		//void SetLineDash (const CGFloat pattern, int count, float phase);

		//- (void)stroke;
		[Export ("stroke")]
		void Stroke ();

		//- (void)fill;
		[Export ("fill")]
		void Fill ();

		//- (void)addClip;
		[Export ("addClip")]
		void AddClip ();

		//- (void)setClip;
		[Export ("setClip")]
		void SetClip ();

		//- (NSBezierPath *)bezierPathByFlatteningPath;
		[Export ("bezierPathByFlatteningPath")]
		NSBezierPath BezierPathByFlatteningPath { get; }

		//- (NSBezierPath *)bezierPathByReversingPath;
		[Export ("bezierPathByReversingPath")]
		NSBezierPath BezierPathByReversingPath { get; }

		//- (void)transformUsingAffineTransform:(NSAffineTransform *)transform;
		[Export ("transformUsingAffineTransform:")]
		void TransformUsingAffineTransform (NSAffineTransform transform);

		//- (BOOL)isEmpty;
		[Export ("isEmpty")]
		bool IsEmpty { get; }

		//- (NSPoint)currentPoint;
		[Export ("currentPoint")]
		PointF CurrentPoint { get; }

		//- (NSRect)controlPointBounds;
		[Export ("controlPointBounds")]
		RectangleF ControlPointBounds { get; }

		//- (NSRect)bounds;
		[Export ("bounds")]
		RectangleF Bounds { get; }

		//- (NSInteger)elementCount;
		[Export ("elementCount")]
		int ElementCount { get; }

		//- (NSBezierPathElement)elementAtIndex:(NSInteger)index		     associatedPoints:(NSPointArray)points;
		[Export ("elementAtIndex:associatedPoints:")]
		NSBezierPathElement ElementAtIndex (int index, NSPointArray points);

		//- (NSBezierPathElement)elementAtIndex:(NSInteger)index;
		[Export ("elementAtIndex:")]
		NSBezierPathElement ElementAtIndex (int index);

		//- (void)setAssociatedPoints:(NSPointArray)points atIndex:(NSInteger)index;
		[Export ("setAssociatedPoints:atIndex:")]
		void SetAssociatedPoints (NSPointArray points, int index);

		//- (void)appendBezierPath:(NSBezierPath *)path;
		[Export ("appendBezierPath:")]
		void AppendBezierPath (NSBezierPath path);

		//- (void)appendBezierPathWithRect:(NSRect)rect;
		[Export ("appendBezierPathWithRect:")]
		void AppendBezierPathWithRect (RectangleF rect);

		//- (void)appendBezierPathWithPoints:(NSPointArray)points count:(NSInteger)count;
		[Export ("appendBezierPathWithPoints:count:")]
		void AppendBezierPathWithPoints (NSPointArray points, int count);

		//- (void)appendBezierPathWithOvalInRect:(NSRect)rect;
		[Export ("appendBezierPathWithOvalInRect:")]
		void AppendBezierPathWithOvalInRect (RectangleF rect);

		//- (void)appendBezierPathWithArcWithCenter:(NSPoint)center radius:(CGFloat)radius			       startAngle:(CGFloat)startAngle				 endAngle:(CGFloat)endAngle				clockwise:(BOOL)clockwise;
		[Export ("appendBezierPathWithArcWithCenter:radius:startAngleendAngle:clockwise:")]
		void AppendBezierPathWithArcWithCenter (PointF center, float radius, float startAngle, float endAngle, bool clockwise);

		//- (void)appendBezierPathWithArcWithCenter:(NSPoint)center radius:(CGFloat)radius			       startAngle:(CGFloat)startAngle				 endAngle:(CGFloat)endAngle;
		[Export ("appendBezierPathWithArcWithCenter:radius:startAngleendAngle:")]
		void AppendBezierPathWithArcWithCenter (PointF center, float radius, float startAngle, float endAngle);

		//- (void)appendBezierPathWithArcFromPoint:(NSPoint)point1				 toPoint:(NSPoint)point2				  radius:(CGFloat)radius;
		[Export ("appendBezierPathWithArcFromPoint:toPoint:radius:")]
		void AppendBezierPathWithArcFromPoint (PointF point1, PointF point2, float radius);

		//- (void)appendBezierPathWithGlyph:(NSGlyph)glyph inFont:(NSFont *)font;
		[Export ("appendBezierPathWithGlyph:inFont:")]
		void AppendBezierPathWithGlyph (uint glyph, NSFont font);

		//- (void)appendBezierPathWithGlyphs:(NSGlyph *)glyphs count:(NSInteger)count			    inFont:(NSFont *)font;
		[Export ("appendBezierPathWithGlyphs:count:")]
		void AppendBezierPathWithGlyphs (uint glyphs, int count, NSFont font);

		////- (void)appendBezierPathWithPackedGlyphs:(const char *)packedGlyphs;
		//[Export ("appendBezierPathWithPackedGlyphs:")]
		//void AppendBezierPathWithPackedGlyphs (const char packedGlyphs);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (void)appendBezierPathWithRoundedRect:(NSRect)rect xRadius:(CGFloat)xRadius yRadius:(CGFloat)yRadius;
		[Export ("appendBezierPathWithRoundedRect:xRadius:yRadius:")]
		void AppendBezierPathWithRoundedRect (RectangleF rect, float xRadius, float yRadius);

//#endif 
		//- (BOOL)containsPoint:(NSPoint)point;
		[Export ("containsPoint:")]
		bool ContainsPoint (PointF point);

		//- (BOOL)cachesBezierPath;
		[Export ("cachesBezierPath")]
		bool CachesBezierPath { get; set; }

	}
}
