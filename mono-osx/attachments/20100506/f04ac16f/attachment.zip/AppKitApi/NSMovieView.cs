using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSView))]
	interface NSMovieView {

		//- (NSMovie*) movie;
		[Export ("movie")]
		NSMovie Movie { get; set; }

		//- (void* ) movieController;
		[Export ("movieController")]
		void MovieController ();

		//- (NSRect) movieRect;
		[Export ("movieRect")]
		RectangleF MovieRect { get; }

		//    - (void)start:(id)sender;
		[Export ("start:")]
		void Start (NSObject sender);

		//- (void)stop:(id)sender;
		[Export ("stop:")]
		void Stop (NSObject sender);

		//- (BOOL)isPlaying;
		[Export ("isPlaying")]
		bool IsPlaying { get; }

		//- (void)gotoPosterFrame:(id)sender;
		[Export ("gotoPosterFrame:")]
		void GotoPosterFrame (NSObject sender);

		//- (void)gotoBeginning:(id)sender;
		[Export ("gotoBeginning:")]
		void GotoBeginning (NSObject sender);

		//- (void)gotoEnd:(id)sender;
		[Export ("gotoEnd:")]
		void GotoEnd (NSObject sender);

		//- (void)stepForward:(id)sender;
		[Export ("stepForward:")]
		void StepForward (NSObject sender);

		//- (void)stepBack:(id)sender;
		[Export ("stepBack:")]
		void StepBack (NSObject sender);

		//- (float)rate;
		[Export ("rate")]
		float Rate { get; set; }

		//- (float)volume;
		[Export ("volume")]
		float Volume { get; set; }

		//- (void)setMuted:(BOOL)mute;
		[Export ("setMuted:")]
		void SetMuted (bool mute);

		//- (BOOL)isMuted;
		[Export ("isMuted")]
		bool IsMuted { get; }

		//- (NSQTMovieLoopMode)loopMode;
		[Export ("loopMode")]
		NSQTMovieLoopMode LoopMode { get; set; }

		//- (BOOL)playsSelectionOnly;
		[Export ("playsSelectionOnly")]
		bool PlaysSelectionOnly { get; set; }

		//- (BOOL)playsEveryFrame;
		[Export ("playsEveryFrame")]
		bool PlaysEveryFrame { get; set; }

		//    - (void)showController:(BOOL)show adjustingSize:(BOOL)adjustSize;
		[Export ("showController:adjustingSize:")]
		void ShowController (bool show, bool adjustSize);

		//- (BOOL)isControllerVisible;
		[Export ("isControllerVisible")]
		bool IsControllerVisible { get; }

		//    - (void)resizeWithMagnification:(CGFloat)magnification;
		[Export ("resizeWithMagnification:")]
		void ResizeWithMagnification (float magnification);

		//- (NSSize)sizeForMagnification:(CGFloat)magnification;
		[Export ("sizeForMagnification:")]
		NSSize SizeForMagnification (float magnification);

		//    - (void)setEditable:(BOOL)editable;
		[Export ("setEditable:")]
		void SetEditable (bool editable);

		//- (BOOL)isEditable;
		[Export ("isEditable")]
		bool IsEditable { get; }

		//- (void)cut:(id)sender;
		[Export ("cut:")]
		void Cut (NSObject sender);

		//- (void)copy:(id)sender;
		[Export ("copy:")]
		void Copy (NSObject sender);

		//- (void)paste:(id)sender;
		[Export ("paste:")]
		void Paste (NSObject sender);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//- (void)delete:(id)sender;
		[Export ("delete:")]
		void Delete (NSObject sender);

//#endif
		//- (void)selectAll:(id)sender;
		[Export ("selectAll:")]
		void SelectAll (NSObject sender);

		//- (void)clear:(id)sender;	
		[Export ("clear:")]
		void Clear (NSObject sender);

	}
}
