using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSActionCell))]
	interface NSTextFieldCell {

		//- (NSColor *)backgroundColor;
		[Export ("backgroundColor")]
		NSColor BackgroundColor { get; set; }

		//- (BOOL)drawsBackground;
		[Export ("drawsBackground")]
		bool DrawsBackground { get; set; }

		//- (NSColor *)textColor;
		[Export ("textColor")]
		NSColor TextColor { get; set; }

		//- (NSText *)setUpFieldEditorAttributes:(NSText *)textObj;
		[Export ("setUpFieldEditorAttributes:")]
		NSText SetUpFieldEditorAttributes (NSText textObj);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_2
		//- (NSTextFieldBezelStyle)bezelStyle;
		[Export ("bezelStyle")]
		NSTextFieldBezelStyle BezelStyle { get; set; }

//#endif
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//- (NSString*)placeholderString;
		[Export ("placeholderString")]
		string PlaceholderString { get; set; }

		//- (NSAttributedString*)placeholderAttributedString;
		[Export ("placeholderAttributedString")]
		NSAttributedString PlaceholderAttributedString { get; set; }

//#endif
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (void)setWantsNotificationForMarkedText:(BOOL)flag;
		[Export ("setWantsNotificationForMarkedText:")]
		void SetWantsNotificationForMarkedText (bool flag);

		//- (NSArray *)allowedInputSourceLocales;
		[Export ("allowedInputSourceLocales")]
		NSArray AllowedInputSourceLocales { get; set; }

//#endif 
	}
}
