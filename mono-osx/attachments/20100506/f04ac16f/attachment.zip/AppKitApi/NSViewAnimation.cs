using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSAnimation))]
	interface NSViewAnimation {

		//- (id)initWithViewAnimations:(NSArray*)viewAnimations;
		[Export ("initWithViewAnimations:")]
		IntPtr Constructor (NSArray viewAnimations);

		//- (NSArray*)viewAnimations;
		[Export ("viewAnimations")]
		NSArray ViewAnimations { get; set; }

	}
}
