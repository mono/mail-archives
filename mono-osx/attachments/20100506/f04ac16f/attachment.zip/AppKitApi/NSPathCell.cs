using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSActionCell))]
	interface NSPathCell {

		//- (NSPathStyle)pathStyle;
		[Export ("pathStyle")]
		NSPathStyle PathStyle { get; set; }

		//- (NSURL *)URL;
		[Export ("URL")]
		NSUrl Url { get; set; }

		//- (void)setObjectValue:(id <NSCopying>)obj;
		[Export ("setObjectValue:")]
		void SetObjectValue (NSObject obj);

		//- (NSArray *)allowedTypes;
		[Export ("allowedTypes")]
		NSArray AllowedTypes { get; set; }

		//- (id)delegate;
		[Export ("delegate")]
		NSPathCell Delegate { get; }

		//- (void)setDelegate:(id)value;
		[Export ("setDelegate:")]
		void SetDelegate (NSObject value);

		//+ (Class)pathComponentCellClass;
		[Static, Export ("pathComponentCellClass")]
		Class PathComponentCellClass { get; }

		//    - (NSArray *)pathComponentCells;
		[Export ("pathComponentCells")]
		NSArray PathComponentCells { get; set; }

		//- (NSRect)rectOfPathComponentCell:(NSPathComponentCell *)cell withFrame:(NSRect)frame inView:(NSView *)view;
		[Export ("rectOfPathComponentCell:withFrame:inView:")]
		RectangleF RectOfPathComponentCell (NSPathComponentCell cell, RectangleF frame, NSView view);

		//- (NSPathComponentCell *)pathComponentCellAtPoint:(NSPoint)point withFrame:(NSRect)frame inView:(NSView *)view;
		[Export ("pathComponentCellAtPoint:withFrame:inView:")]
		NSPathComponentCell PathComponentCellAtPoint (PointF point, RectangleF frame, NSView view);

		//- (NSPathComponentCell *)clickedPathComponentCell;
		[Export ("clickedPathComponentCell")]
		NSPathComponentCell ClickedPathComponentCell { get; }

		//- (void)mouseEntered:(NSEvent *)event withFrame:(NSRect)frame inView:(NSView *)view;
		[Export ("mouseEntered:withFrame:inView:")]
		void MouseEntered (NSEvent event1, RectangleF frame, NSView view);

		//- (void)mouseExited:(NSEvent *)event withFrame:(NSRect)frame inView:(NSView *)view;
		[Export ("mouseExited:withFrame:inView:")]
		void MouseExited (NSEvent event1, RectangleF frame, NSView view);

		//- (SEL)doubleAction;
		[Export ("doubleAction")]
		Selector DoubleAction { get; set; }

		//- (NSColor *)backgroundColor;
		[Export ("backgroundColor")]
		NSColor BackgroundColor { get; set; }

		//- (NSString *)placeholderString;
		[Export ("placeholderString")]
		string PlaceholderString { get; set; }

		//- (NSAttributedString *)placeholderAttributedString;
		[Export ("placeholderAttributedString")]
		NSAttributedString PlaceholderAttributedString { get; set; }

		//- (void)setControlSize:(NSControlSize)size;
		[Export ("setControlSize:")]
		void SetControlSize (NSControlSize size);

	}
}
