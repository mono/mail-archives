using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSObject))]
	interface NSTextList {

		//- (id)initWithMarkerFormat:(NSString *)format options:(NSUInteger)mask;
		[Export ("initWithMarkerFormat:options:")]
		IntPtr Constructor (string format, uint mask);

		//- (NSString *)markerFormat;
		[Export ("markerFormat")]
		string MarkerFormat { get; }

		//- (NSUInteger)listOptions;
		[Export ("listOptions")]
		uint ListOptions { get; }

		//- (NSString *)markerForItemNumber:(NSInteger)itemNum;
		[Export ("markerForItemNumber:")]
		string MarkerForItemNumber (int itemNum);

	}
}
