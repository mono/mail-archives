using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSObject))]
	interface NSOpenGLPixelFormat {

		////- (id)initWithAttributes:(const NSOpenGLPixelFormatAttribute *)attribs;
		//[Export ("initWithAttributes:")]
		//IntPtr Constructor (const NSOpenGLPixelFormatAttribute attribs);

		//- (id)initWithData:(NSData*)attribs;
		[Export ("initWithData:")]
		IntPtr Constructor (NSData attribs);

		//- (NSData*)attributes;
		[Export ("attributes")]
		NSData Attributes { get; set; }

		//- (void)getValues:(GLint *)vals forAttribute:(NSOpenGLPixelFormatAttribute)attrib forVirtualScreen:(GLint)screen;
		[Export ("getValues:forAttribute:forVirtualScreen:")]
		void GetValues (GLint vals, NSOpenGLPixelFormatAttribute attrib, GLint screen);

		//- (GLint)numberOfVirtualScreens;
		[Export ("numberOfVirtualScreens")]
		GLint NumberOfVirtualScreens { get; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//- (void *)CGLPixelFormatObj;
		[Export ("CGLPixelFormatObj")]
		void CGLPixelFormatObj ();

//#endif
	}
}
