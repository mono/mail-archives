using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSObject))]
	interface NSAnimation {

		//- (id)initWithDuration:(NSTimeInterval)duration animationCurve:(NSAnimationCurve)animationCurve;
		[Export ("initWithDuration:animationCurve:")]
		IntPtr Constructor (double duration, NSAnimationCurve animationCurve);

		//- (void)startAnimation;
		[Export ("startAnimation")]
		void StartAnimation ();

		//- (void)stopAnimation;
		[Export ("stopAnimation")]
		void StopAnimation ();

		//- (BOOL)isAnimating;
		[Export ("isAnimating")]
		bool IsAnimating { get; }

		//- (NSAnimationProgress)currentProgress;
		[Export ("currentProgress")]
		float CurrentProgress { get; set; }

		//- (NSTimeInterval)duration;
		[Export ("duration")]
		double Duration { get; set; }

		//- (NSAnimationBlockingMode)animationBlockingMode;
		[Export ("animationBlockingMode")]
		NSAnimationBlockingMode AnimationBlockingMode { get; set; }

		//- (float)frameRate;
		[Export ("frameRate")]
		float FrameRate { get; set; }

		//- (NSAnimationCurve)animationCurve;
		[Export ("animationCurve")]
		NSAnimationCurve AnimationCurve { get; set; }

		//- (float)currentValue;
		[Export ("currentValue")]
		float CurrentValue { get; }

		//- (void)setDelegate:(id)delegate;
		[Export ("setDelegate:")]
		void SetDelegate (NSObject delegate1);

		//- (id)delegate;
		[Export ("delegate")]
		NSAnimation Delegate { get; }

		//- (NSArray*)progressMarks;
		[Export ("progressMarks")]
		NSArray ProgressMarks { get; set; }

		//- (void)addProgressMark:(NSAnimationProgress)progressMark;
		[Export ("addProgressMark:")]
		void AddProgressMark (float progressMark);

		//- (void)removeProgressMark:(NSAnimationProgress)progressMark;
		[Export ("removeProgressMark:")]
		void RemoveProgressMark (float progressMark);

		//- (void)startWhenAnimation:(NSAnimation*)animation reachesProgress:(NSAnimationProgress)startProgress;
		[Export ("startWhenAnimation:reachesProgress:")]
		void StartWhenAnimation (NSAnimation animation, float startProgress);

		//- (void)stopWhenAnimation:(NSAnimation*)animation reachesProgress:(NSAnimationProgress)stopProgress;
		[Export ("stopWhenAnimation:reachesProgress:")]
		void StopWhenAnimation (NSAnimation animation, float stopProgress);

		//- (void)clearStartAnimation;
		[Export ("clearStartAnimation")]
		void ClearStartAnimation ();

		//- (void)clearStopAnimation;
		[Export ("clearStopAnimation")]
		void ClearStopAnimation ();

		//- (NSArray*)runLoopModesForAnimating;
		[Export ("runLoopModesForAnimating")]
		NSArray RunLoopModesForAnimating { get; }

	}
}
