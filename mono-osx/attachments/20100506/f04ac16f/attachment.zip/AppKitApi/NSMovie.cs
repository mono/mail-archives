using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSObject))]
	interface NSMovie {

//#endif
//#if !__LP64__
		//- (id) initWithMovie:(void* )movie;			
		[Export ("initWithMovie:")]
		IntPtr Constructor (IntPtr movie);

		//- (id) initWithURL:(NSURL*)url byReference:(BOOL)byRef;	
		[Export ("initWithURL:byReference:")]
		IntPtr Constructor (NSUrl url, bool byRef);

		//- (id) initWithPasteboard:(NSPasteboard*)pasteboard;
		[Export ("initWithPasteboard:")]
		IntPtr Constructor (NSPasteboard pasteboard);

		////- (void*)QTMovie;
		//[Export ("QTMovie")]
		//void QTMovie ();

		//- (NSURL*)URL;
		[Export ("URL")]
		NSUrl Url { get; }

		//+ (NSArray*) movieUnfilteredFileTypes;
		[Static, Export ("movieUnfilteredFileTypes")]
		NSArray MovieUnfilteredFileTypes { get; }

		//+ (NSArray*) movieUnfilteredPasteboardTypes;
		[Static, Export ("movieUnfilteredPasteboardTypes")]
		NSArray MovieUnfilteredPasteboardTypes { get; }

		//+ (BOOL) canInitWithPasteboard:(NSPasteboard*)pasteboard;
		[Static, Export ("canInitWithPasteboard:")]
		bool CanInitWithPasteboard (NSPasteboard pasteboard);

		////#else- (id) initWithMovie:(QTMovie*)movie;
		//[Export ("initWithMovie:")]
		//IntPtr Constructor (QTMovie movie);

		////- (QTMovie *)QTMovie;
		//[Export ("QTMovie")]
		//QTMovie QTMovie { get; }

//#endif
	}
}
