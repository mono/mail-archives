using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;
using MonoMac.CoreAnimation;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSResponder))]
	interface NSView {

		//- (void)scrollClipView:(NSClipView *)aClipView toPoint:(NSPoint)aPoint;
		[Export ("scrollClipView:toPoint:")]
		void ScrollClipViewToPoint (NSClipView aClipView, PointF aPoint);

		//- (NSMenuItem *)enclosingMenuItem;
		[Export ("enclosingMenuItem")]
		NSMenuItem EnclosingMenuItem { get; }

		//- (BOOL)rulerView:(NSRulerView *)ruler shouldMoveMarker:(NSRulerMarker *)marker;
		[Export ("rulerView:shouldMoveMarker:")]
		bool RulerViewShouldMoveMarker (NSRulerView ruler, NSRulerMarker marker);

		//    - (CGFloat)rulerView:(NSRulerView *)ruler willMoveMarker:(NSRulerMarker *)marker toLocation:(CGFloat)location;
		[Export ("rulerView:willMoveMarker:toLocation:")]
		float RulerViewWillMoveMarker (NSRulerView ruler, NSRulerMarker marker, float location);

		//    - (void)rulerView:(NSRulerView *)ruler didMoveMarker:(NSRulerMarker *)marker;
		[Export ("rulerView:didMoveMarker:")]
		void RulerViewDidMoveMarker (NSRulerView ruler, NSRulerMarker marker);

		//    - (BOOL)rulerView:(NSRulerView *)ruler shouldRemoveMarker:(NSRulerMarker *)marker;
		[Export ("rulerView:shouldRemoveMarker:")]
		bool RulerViewShouldRemoveMarker (NSRulerView ruler, NSRulerMarker marker);

		//    - (void)rulerView:(NSRulerView *)ruler didRemoveMarker:(NSRulerMarker *)marker;
		[Export ("rulerView:didRemoveMarker:")]
		void RulerViewDidRemoveMarker (NSRulerView ruler, NSRulerMarker marker);

		//    - (BOOL)rulerView:(NSRulerView *)ruler shouldAddMarker:(NSRulerMarker *)marker;
		[Export ("rulerView:shouldAddMarker:")]
		bool RulerViewShouldAddMarker (NSRulerView ruler, NSRulerMarker marker);

		//    - (CGFloat)rulerView:(NSRulerView *)ruler willAddMarker:(NSRulerMarker *)marker atLocation:(CGFloat)location;
		[Export ("rulerView:willAddMarker:atLocation:")]
		float RulerViewWillAddMarker (NSRulerView ruler, NSRulerMarker marker, float location);

		//    - (void)rulerView:(NSRulerView *)ruler didAddMarker:(NSRulerMarker *)marker;
		[Export ("rulerView:didAddMarker:")]
		void RulerViewDidAddMarker (NSRulerView ruler, NSRulerMarker marker);

		//    - (void)rulerView:(NSRulerView *)ruler handleMouseDown:(NSEvent *)event;
		[Export ("rulerView:handleMouseDown:")]
		void RulerViewHandleMouseDown (NSRulerView ruler, NSEvent event1);

		//    - (void)rulerView:(NSRulerView *)ruler willSetClientView:(NSView *)newClient;
		[Export ("rulerView:willSetClientView:")]
		void RulerViewWillSetClientView (NSRulerView ruler, NSView newClient);

//#endif
		//- (id)initWithFrame:(NSRect)frameRect;
		[Export ("initWithFrame:")]
		IntPtr Constructor (RectangleF frameRect);

		//- (NSWindow *)window;
		[Export ("window")]
		NSWindow Window { get; }

		//- (NSView *)superview;
		[Export ("superview")]
		NSView Superview { get; }

		//- (NSArray *)subviews;
		[Export ("subviews")]
		NSArray Subviews { get; set; }

		//- (BOOL)isDescendantOf:(NSView *)aView;
		[Export ("isDescendantOf:")]
		bool IsDescendantOf (NSView aView);

		//- (NSView *)ancestorSharedWithView:(NSView *)aView;
		[Export ("ancestorSharedWithView:")]
		NSView AncestorSharedWithView (NSView aView);

		//- (NSView *)opaqueAncestor;
		[Export ("opaqueAncestor")]
		NSView OpaqueAncestor { get; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//- (void)setHidden:(BOOL)flag;
		[Export ("setHidden:")]
		void SetHidden (bool flag);

		//- (BOOL)isHidden;
		[Export ("isHidden")]
		bool IsHidden { get; }

		//- (BOOL)isHiddenOrHasHiddenAncestor;
		[Export ("isHiddenOrHasHiddenAncestor")]
		bool IsHiddenOrHasHiddenAncestor { get; }

		////- (void)getRectsBeingDrawn:(const NSRect **)rects count:(NSInteger *)count;
		//[Export ("getRectsBeingDrawn:count:")]
		//void GetRectsBeingDrawn (const NSRect rects, int count);

		//- (BOOL)needsToDrawRect:(NSRect)aRect;
		[Export ("needsToDrawRect:")]
		bool NeedsToDrawRect (RectangleF aRect);

		//- (BOOL)wantsDefaultClipping;
		[Export ("wantsDefaultClipping")]
		bool WantsDefaultClipping { get; }

//#endif
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (void)viewDidHide;
		[Export ("viewDidHide")]
		void ViewDidHide ();

		//- (void)viewDidUnhide;
		[Export ("viewDidUnhide")]
		void ViewDidUnhide ();

//#endif
		//- (void)addSubview:(NSView *)aView;
		[Export ("addSubview:")]
		void AddSubview (NSView aView);

		//- (void)addSubview:(NSView *)aView positioned:(NSWindowOrderingMode)place relativeTo:(NSView *)otherView;
		[Export ("addSubview:positioned:relativeTo:")]
		void AddSubview (NSView aView, NSWindowOrderingMode place, NSView otherView);

		////- (void)sortSubviewsUsingFunction:(NSComparisonResult (*)(id, id, void *))compare context:(void *)context;
		//[Export ("sortSubviewsUsingFunction:context:")]
		//void SortSubviewsUsingFunction ((NSComparisonResult (*, IntPtr context);

		//- (void)viewWillMoveToWindow:(NSWindow *)newWindow;
		[Export ("viewWillMoveToWindow:")]
		void ViewWillMoveToWindow (NSWindow newWindow);

		//- (void)viewDidMoveToWindow;
		[Export ("viewDidMoveToWindow")]
		void ViewDidMoveToWindow ();

		//- (void)viewWillMoveToSuperview:(NSView *)newSuperview;
		[Export ("viewWillMoveToSuperview:")]
		void ViewWillMoveToSuperview (NSView newSuperview);

		//- (void)viewDidMoveToSuperview;
		[Export ("viewDidMoveToSuperview")]
		void ViewDidMoveToSuperview ();

		//- (void)didAddSubview:(NSView *)subview;
		[Export ("didAddSubview:")]
		void DidAddSubview (NSView subview);

		//- (void)willRemoveSubview:(NSView *)subview;
		[Export ("willRemoveSubview:")]
		void WillRemoveSubview (NSView subview);

		//- (void)removeFromSuperview;
		[Export ("removeFromSuperview")]
		void RemoveFromSuperview ();

		//- (void)replaceSubview:(NSView *)oldView with:(NSView *)newView;
		[Export ("replaceSubview:with:")]
		void ReplaceSubview (NSView oldView, NSView newView);

		//- (void)removeFromSuperviewWithoutNeedingDisplay;
		[Export ("removeFromSuperviewWithoutNeedingDisplay")]
		void RemoveFromSuperviewWithoutNeedingDisplay ();

		//- (BOOL)postsFrameChangedNotifications;
		[Export ("postsFrameChangedNotifications")]
		bool PostsFrameChangedNotifications { get; set; }

		//- (void)resizeSubviewsWithOldSize:(NSSize)oldSize;
		[Export ("resizeSubviewsWithOldSize:")]
		void ResizeSubviewsWithOldSize (NSSize oldSize);

		//- (void)resizeWithOldSuperviewSize:(NSSize)oldSize;
		[Export ("resizeWithOldSuperviewSize:")]
		void ResizeWithOldSuperviewSize (NSSize oldSize);

		//- (BOOL)autoresizesSubviews;
		[Export ("autoresizesSubviews")]
		bool AutoresizesSubviews { get; set; }

		//- (NSUInteger)autoresizingMask;
		[Export ("autoresizingMask")]
		uint AutoresizingMask { get; set; }

		//- (void)setFrameOrigin:(NSPoint)newOrigin;
		[Export ("setFrameOrigin:")]
		void SetFrameOrigin (PointF newOrigin);

		//- (void)setFrameSize:(NSSize)newSize;
		[Export ("setFrameSize:")]
		void SetFrameSize (NSSize newSize);

		//- (NSRect)frame;
		[Export ("frame")]
		RectangleF Frame { get; set; }

		//- (CGFloat)frameRotation;
		[Export ("frameRotation")]
		float FrameRotation { get; set; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (CGFloat)frameCenterRotation;
		[Export ("frameCenterRotation")]
		float FrameCenterRotation { get; set; }

//#endif
		//- (void)setBoundsOrigin:(NSPoint)newOrigin;
		[Export ("setBoundsOrigin:")]
		void SetBoundsOrigin (PointF newOrigin);

		//- (void)setBoundsSize:(NSSize)newSize;
		[Export ("setBoundsSize:")]
		void SetBoundsSize (NSSize newSize);

		//- (CGFloat)boundsRotation;
		[Export ("boundsRotation")]
		float BoundsRotation { get; set; }

		//- (void)translateOriginToPoint:(NSPoint)translation;
		[Export ("translateOriginToPoint:")]
		void TranslateOriginToPoint (PointF translation);

		//- (void)scaleUnitSquareToSize:(NSSize)newUnitSize;
		[Export ("scaleUnitSquareToSize:")]
		void ScaleUnitSquareToSize (NSSize newUnitSize);

		//- (void)rotateByAngle:(CGFloat)angle;
		[Export ("rotateByAngle:")]
		void RotateByAngle (float angle);

		//- (NSRect)bounds;
		[Export ("bounds")]
		RectangleF Bounds { get; set; }

		//- (BOOL)isFlipped;
		[Export ("isFlipped")]
		bool IsFlipped { get; }

		//- (BOOL)isRotatedFromBase;
		[Export ("isRotatedFromBase")]
		bool IsRotatedFromBase { get; }

		//- (BOOL)isRotatedOrScaledFromBase;
		[Export ("isRotatedOrScaledFromBase")]
		bool IsRotatedOrScaledFromBase { get; }

		//- (BOOL)isOpaque;
		[Export ("isOpaque")]
		bool IsOpaque { get; }

		//- (NSPoint)convertPoint:(NSPoint)aPoint fromView:(NSView *)aView;
		[Export ("convertPoint:fromView:")]
		PointF ConvertPoint (PointF aPoint, NSView aView);

		//- (NSPoint)convertPoint:(NSPoint)aPoint toView:(NSView *)aView;
		[Export ("convertPoint:toView:")]
		PointF ConvertPointToView (PointF aPoint, NSView aView);

		//- (NSSize)convertSize:(NSSize)aSize fromView:(NSView *)aView;
		[Export ("convertSize:fromView:")]
		NSSize ConvertSize (NSSize aSize, NSView aView);

		//- (NSSize)convertSize:(NSSize)aSize toView:(NSView *)aView;
		[Export ("convertSize:toView:")]
		NSSize ConvertSizeToView (NSSize aSize, NSView aView);

		//- (NSRect)convertRect:(NSRect)aRect fromView:(NSView *)aView;
		[Export ("convertRect:fromView:")]
		RectangleF ConvertRect (RectangleF aRect, NSView aView);

		//- (NSRect)convertRect:(NSRect)aRect toView:(NSView *)aView;
		[Export ("convertRect:toView:")]
		RectangleF ConvertRectToView (RectangleF aRect, NSView aView);

		//- (NSRect)centerScanRect:(NSRect)aRect;
		[Export ("centerScanRect:")]
		RectangleF CenterScanRect (RectangleF aRect);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (NSPoint)convertPointToBase:(NSPoint)aPoint;
		[Export ("convertPointToBase:")]
		PointF ConvertPointToBase (PointF aPoint);

		//- (NSPoint)convertPointFromBase:(NSPoint)aPoint;
		[Export ("convertPointFromBase:")]
		PointF ConvertPointFromBase (PointF aPoint);

		//- (NSSize)convertSizeToBase:(NSSize)aSize;
		[Export ("convertSizeToBase:")]
		NSSize ConvertSizeToBase (NSSize aSize);

		//- (NSSize)convertSizeFromBase:(NSSize)aSize;
		[Export ("convertSizeFromBase:")]
		NSSize ConvertSizeFromBase (NSSize aSize);

		//- (NSRect)convertRectToBase:(NSRect)aRect;
		[Export ("convertRectToBase:")]
		RectangleF ConvertRectToBase (RectangleF aRect);

		//- (NSRect)convertRectFromBase:(NSRect)aRect;
		[Export ("convertRectFromBase:")]
		RectangleF ConvertRectFromBase (RectangleF aRect);

//#endif
		//- (BOOL)canDraw;
		[Export ("canDraw")]
		bool CanDraw { get; }

		//- (void)setNeedsDisplayInRect:(NSRect)invalidRect;
		[Export ("setNeedsDisplayInRect:")]
		void SetNeedsDisplayInRect (RectangleF invalidRect);

		//- (BOOL)needsDisplay;
		[Export ("needsDisplay")]
		bool NeedsDisplay { get; set; }

		//- (void)lockFocus;
		[Export ("lockFocus")]
		void LockFocus ();

		//- (void)unlockFocus;
		[Export ("unlockFocus")]
		void UnlockFocus ();

		//- (BOOL)lockFocusIfCanDraw;
		[Export ("lockFocusIfCanDraw")]
		bool LockFocusIfCanDraw { get; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (BOOL)lockFocusIfCanDrawInContext:(NSGraphicsContext *)context;
		[Export ("lockFocusIfCanDrawInContext:")]
		bool LockFocusIfCanDrawInContext (NSGraphicsContext context);

//#endif
		//+ (NSView *)focusView;
		[Static, Export ("focusView")]
		NSView FocusView { get; }

		//- (NSRect)visibleRect;
		[Export ("visibleRect")]
		RectangleF VisibleRect { get; }

		//- (void)display;
		[Export ("display")]
		void Display ();

		//- (void)displayIfNeeded;
		[Export ("displayIfNeeded")]
		void DisplayIfNeeded ();

		//- (void)displayIfNeededIgnoringOpacity;
		[Export ("displayIfNeededIgnoringOpacity")]
		void DisplayIfNeededIgnoringOpacity ();

		//- (void)displayRect:(NSRect)rect;
		[Export ("displayRect:")]
		void DisplayRect (RectangleF rect);

		//- (void)displayIfNeededInRect:(NSRect)rect;
		[Export ("displayIfNeededInRect:")]
		void DisplayIfNeededInRect (RectangleF rect);

		//- (void)displayRectIgnoringOpacity:(NSRect)rect;
		[Export ("displayRectIgnoringOpacity:")]
		void DisplayRectIgnoringOpacity (RectangleF rect);

		//- (void)displayIfNeededInRectIgnoringOpacity:(NSRect)rect;
		[Export ("displayIfNeededInRectIgnoringOpacity:")]
		void DisplayIfNeededInRectIgnoringOpacity (RectangleF rect);

		//- (void)drawRect:(NSRect)rect;
		[Export ("drawRect:")]
		void DrawRect (RectangleF rect);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (void)displayRectIgnoringOpacity:(NSRect)aRect inContext:(NSGraphicsContext *)context;
		[Export ("displayRectIgnoringOpacity:inContext:")]
		void DisplayRectIgnoringOpacity (RectangleF aRect, NSGraphicsContext context);

		//- (NSBitmapImageRep *)bitmapImageRepForCachingDisplayInRect:(NSRect)rect;
		[Export ("bitmapImageRepForCachingDisplayInRect:")]
		NSBitmapImageRep BitmapImageRepForCachingDisplayInRect (RectangleF rect);

		//- (void)cacheDisplayInRect:(NSRect)rect toBitmapImageRep:(NSBitmapImageRep *)bitmapImageRep;
		[Export ("cacheDisplayInRect:toBitmapImageRep:")]
		void CacheDisplayInRect (RectangleF rect, NSBitmapImageRep bitmapImageRep);

//#endif
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (void)viewWillDraw;
		[Export ("viewWillDraw")]
		void ViewWillDraw ();

//#endif
		//- (NSInteger)gState;
		[Export ("gState")]
		int GState { get; }

		//- (void)allocateGState;
		[Export ("allocateGState")]
		void AllocateGState ();

		//- (void)releaseGState;
		[Export ("releaseGState")]
		void ReleaseGState ();

		//- (void)setUpGState;
		[Export ("setUpGState")]
		void SetUpGState ();

		//- (void)renewGState;
		[Export ("renewGState")]
		void RenewGState ();

		//- (void)scrollPoint:(NSPoint)aPoint;
		[Export ("scrollPoint:")]
		void ScrollPoint (PointF aPoint);

		//- (BOOL)scrollRectToVisible:(NSRect)aRect;
		[Export ("scrollRectToVisible:")]
		bool ScrollRectToVisible (RectangleF aRect);

		//- (BOOL)autoscroll:(NSEvent *)theEvent;
		[Export ("autoscroll:")]
		bool Autoscroll (NSEvent theEvent);

		//- (NSRect)adjustScroll:(NSRect)newVisible;
		[Export ("adjustScroll:")]
		RectangleF AdjustScroll (RectangleF newVisible);

		//- (void)scrollRect:(NSRect)aRect by:(NSSize)delta;
		[Export ("scrollRect:by:")]
		void ScrollRect (RectangleF aRect, NSSize delta);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (void)translateRectsNeedingDisplayInRect:(NSRect)clipRect by:(NSSize)delta;
		[Export ("translateRectsNeedingDisplayInRect:by:")]
		void TranslateRectsNeedingDisplayInRect (RectangleF clipRect, NSSize delta);

//#endif
		//- (NSView *)hitTest:(NSPoint)aPoint;
		[Export ("hitTest:")]
		NSView HitTest (PointF aPoint);

		//- (BOOL)mouse:(NSPoint)aPoint inRect:(NSRect)aRect;
		[Export ("mouse:inRect:")]
		bool Mouse (PointF aPoint, RectangleF aRect);

		//- (id)viewWithTag:(NSInteger)aTag;
		[Export ("viewWithTag:")]
		NSView ViewWithTag (int aTag);

		//- (NSInteger)tag;
		[Export ("tag")]
		int Tag { get; }

		//- (BOOL)performKeyEquivalent:(NSEvent *)theEvent;
		[Export ("performKeyEquivalent:")]
		bool PerformKeyEquivalent (NSEvent theEvent);

		//- (BOOL)acceptsFirstMouse:(NSEvent *)theEvent;
		[Export ("acceptsFirstMouse:")]
		bool AcceptsFirstMouse (NSEvent theEvent);

		//- (BOOL)shouldDelayWindowOrderingForEvent:(NSEvent *)theEvent;
		[Export ("shouldDelayWindowOrderingForEvent:")]
		bool ShouldDelayWindowOrderingForEvent (NSEvent theEvent);

		//- (BOOL)needsPanelToBecomeKey;
		[Export ("needsPanelToBecomeKey")]
		bool NeedsPanelToBecomeKey { get; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_2
		//- (BOOL)mouseDownCanMoveWindow;
		[Export ("mouseDownCanMoveWindow")]
		bool MouseDownCanMoveWindow { get; }

//#endif
		//- (void)addCursorRect:(NSRect)aRect cursor:(NSCursor *)anObj;
		[Export ("addCursorRect:cursor:")]
		void AddCursorRect (RectangleF aRect, NSCursor anObj);

		//- (void)removeCursorRect:(NSRect)aRect cursor:(NSCursor *)anObj;
		[Export ("removeCursorRect:cursor:")]
		void RemoveCursorRect (RectangleF aRect, NSCursor anObj);

		//- (void)discardCursorRects;
		[Export ("discardCursorRects")]
		void DiscardCursorRects ();

		//- (void)resetCursorRects;
		[Export ("resetCursorRects")]
		void ResetCursorRects ();

		//- (NSTrackingRectTag)addTrackingRect:(NSRect)aRect owner:(id)anObject userData:(void *)data assumeInside:(BOOL)flag;
		[Export ("addTrackingRect:owner:userData:assumeInside:")]
		NSTrackingRectTag AddTrackingRect (RectangleF aRect, NSObject anObject, IntPtr data, bool flag);

		//- (void)removeTrackingRect:(NSTrackingRectTag)tag;
		[Export ("removeTrackingRect:")]
		void RemoveTrackingRect (NSTrackingRectTag tag);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (BOOL)wantsLayer;
		[Export ("wantsLayer")]
		bool WantsLayer { get; set; }

		//- (CALayer *)layer;
		[Export ("layer")]
		CALayer Layer { get; set; }

		//- (CGFloat)alphaValue;
		[Export ("alphaValue")]
		float AlphaValue { get; set; }

		//- (NSArray *)backgroundFilters;
		[Export ("backgroundFilters")]
		NSArray BackgroundFilters { get; set; }

		//- (CIFilter *)compositingFilter;
		[Export ("compositingFilter")]
		CIFilter CompositingFilter { get; set; }

		//- (NSArray *)contentFilters;
		[Export ("contentFilters")]
		NSArray ContentFilters { get; set; }

		//- (NSShadow *)shadow;
		[Export ("shadow")]
		NSShadow Shadow { get; set; }

		//- (void)addTrackingArea:(NSTrackingArea *)trackingArea;
		[Export ("addTrackingArea:")]
		void AddTrackingArea (NSTrackingArea trackingArea);

		//- (void)removeTrackingArea:(NSTrackingArea *)trackingArea;
		[Export ("removeTrackingArea:")]
		void RemoveTrackingArea (NSTrackingArea trackingArea);

		//- (NSArray *)trackingAreas;
		[Export ("trackingAreas")]
		NSArray TrackingAreas { get; }

		//- (void)updateTrackingAreas;
		[Export ("updateTrackingAreas")]
		void UpdateTrackingAreas ();

//#endif
		//- (BOOL)shouldDrawColor;
		[Export ("shouldDrawColor")]
		bool ShouldDrawColor { get; }

		//- (BOOL)postsBoundsChangedNotifications;
		[Export ("postsBoundsChangedNotifications")]
		bool PostsBoundsChangedNotifications { get; set; }

		//- (NSScrollView *)enclosingScrollView;
		[Export ("enclosingScrollView")]
		NSScrollView EnclosingScrollView { get; }

		//- (NSMenu *)menuForEvent:(NSEvent *)event;
		[Export ("menuForEvent:")]
		NSMenu MenuForEvent (NSEvent event1);

		//+ (NSMenu *)defaultMenu;
		[Static, Export ("defaultMenu")]
		NSMenu DefaultMenu { get; }

		//- (NSString *)toolTip;
		[Export ("toolTip")]
		string ToolTip { get; set; }

		//- (NSToolTipTag)addToolTipRect:(NSRect)aRect owner:(id)anObject userData:(void *)data;
		[Export ("addToolTipRect:owner:userData:")]
		NSToolTipTag AddToolTipRect (RectangleF aRect, NSObject anObject, IntPtr data);

		//- (void)removeToolTip:(NSToolTipTag)tag;
		[Export ("removeToolTip:")]
		void RemoveToolTip (NSToolTipTag tag);

		//- (void)removeAllToolTips;
		[Export ("removeAllToolTips")]
		void RemoveAllToolTips ();

		//- (void)viewWillStartLiveResize;
		[Export ("viewWillStartLiveResize")]
		void ViewWillStartLiveResize ();

		//- (void)viewDidEndLiveResize;
		[Export ("viewDidEndLiveResize")]
		void ViewDidEndLiveResize ();

		//- (BOOL)inLiveResize;
		[Export ("inLiveResize")]
		bool InLiveResize { get; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (BOOL)preservesContentDuringLiveResize;
		[Export ("preservesContentDuringLiveResize")]
		bool PreservesContentDuringLiveResize { get; }

		//- (NSRect)rectPreservedDuringLiveResize;
		[Export ("rectPreservedDuringLiveResize")]
		RectangleF RectPreservedDuringLiveResize { get; }

		////- (void)getRectsExposedDuringLiveResize:(NSRect[4])exposedRects count:(NSInteger *)count;
		//[Export ("getRectsExposedDuringLiveResize:count:")]
		//void GetRectsExposedDuringLiveResize (NSRect[4] exposedRects, int count);

//#endif
		//- (NSView *)nextKeyView;
		[Export ("nextKeyView")]
		NSView NextKeyView { get; set; }

		//- (NSView *)previousKeyView;
		[Export ("previousKeyView")]
		NSView PreviousKeyView { get; }

		//- (NSView *)nextValidKeyView;
		[Export ("nextValidKeyView")]
		NSView NextValidKeyView { get; }

		//- (NSView *)previousValidKeyView;
		[Export ("previousValidKeyView")]
		NSView PreviousValidKeyView { get; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//- (BOOL)canBecomeKeyView;
		[Export ("canBecomeKeyView")]
		bool CanBecomeKeyView { get; }

//#endif
		//- (void)setKeyboardFocusRingNeedsDisplayInRect:(NSRect)rect;
		[Export ("setKeyboardFocusRingNeedsDisplayInRect:")]
		void SetKeyboardFocusRingNeedsDisplayInRect (RectangleF rect);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//- (NSFocusRingType)focusRingType;
		[Export ("focusRingType")]
		NSFocusRingType FocusRingType { get; set; }

		//+ (NSFocusRingType)defaultFocusRingType;
		[Static, Export ("defaultFocusRingType")]
		NSFocusRingType DefaultFocusRingType { get; }

//#endif
		//- (void)writeEPSInsideRect:(NSRect)rect toPasteboard:(NSPasteboard *)pasteboard;
		[Export ("writeEPSInsideRect:toPasteboard:")]
		void WriteEPSInsideRectToPasteboard (RectangleF rect, NSPasteboard pasteboard);

		//- (NSData *)dataWithEPSInsideRect:(NSRect)rect;
		[Export ("dataWithEPSInsideRect:")]
		NSData DataWithEPSInsideRect (RectangleF rect);

		//- (void)writePDFInsideRect:(NSRect)rect toPasteboard:(NSPasteboard *)pasteboard;
		[Export ("writePDFInsideRect:toPasteboard:")]
		void WritePDFInsideRectToPasteboard (RectangleF rect, NSPasteboard pasteboard);

		//- (NSData *)dataWithPDFInsideRect:(NSRect)rect;
		[Export ("dataWithPDFInsideRect:")]
		NSData DataWithPDFInsideRect (RectangleF rect);

		//- (void)print:(id)sender;
		[Export ("print:")]
		void Print (NSObject sender);

		//- (BOOL)knowsPageRange:(NSRangePointer)range;
		[Export ("knowsPageRange:")]
		bool KnowsPageRange (NSRangePointer range);

		//- (CGFloat)heightAdjustLimit;
		[Export ("heightAdjustLimit")]
		float HeightAdjustLimit { get; }

		//- (CGFloat)widthAdjustLimit;
		[Export ("widthAdjustLimit")]
		float WidthAdjustLimit { get; }

		//- (void)adjustPageWidthNew:(CGFloat *)newRight left:(CGFloat)oldLeft right:(CGFloat)oldRight limit:(CGFloat)rightLimit;
		[Export ("adjustPageWidthNew:left:right:limit:")]
		void AdjustPageWidthNewLeft (float newRight, float oldLeft, float oldRight, float rightLimit);

		//- (void)adjustPageHeightNew:(CGFloat *)newBottom top:(CGFloat)oldTop bottom:(CGFloat)oldBottom limit:(CGFloat)bottomLimit;
		[Export ("adjustPageHeightNew:top:bottom:limit:")]
		void AdjustPageHeightNewTop (float newBottom, float oldTop, float oldBottom, float bottomLimit);

		//- (NSRect)rectForPage:(NSInteger)page;
		[Export ("rectForPage:")]
		RectangleF RectForPage (int page);

		//- (NSPoint)locationOfPrintRect:(NSRect)aRect;
		[Export ("locationOfPrintRect:")]
		PointF LocationOfPrintRect (RectangleF aRect);

		//- (void)drawPageBorderWithSize:(NSSize)borderSize;
		[Export ("drawPageBorderWithSize:")]
		void DrawPageBorderWithSize (NSSize borderSize);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (NSAttributedString *)pageHeader;
		[Export ("pageHeader")]
		NSAttributedString PageHeader { get; }

		//- (NSAttributedString *)pageFooter;
		[Export ("pageFooter")]
		NSAttributedString PageFooter { get; }

//#endif
		//- (void)drawSheetBorderWithSize:(NSSize)borderSize;
		[Export ("drawSheetBorderWithSize:")]
		void DrawSheetBorderWithSize (NSSize borderSize);

		//- (NSString *)printJobTitle;
		[Export ("printJobTitle")]
		string PrintJobTitle { get; }

		//- (void)beginDocument;
		[Export ("beginDocument")]
		void BeginDocument ();

		//- (void)endDocument;
		[Export ("endDocument")]
		void EndDocument ();

		//- (void)beginPageInRect:(NSRect)aRect atPlacement:(NSPoint)location;
		[Export ("beginPageInRect:atPlacement:")]
		void BeginPageInRectAtPlacement (RectangleF aRect, PointF location);

		//- (void)endPage;
		[Export ("endPage")]
		void EndPage ();

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (NSArray *)registeredDraggedTypes;
		[Export ("registeredDraggedTypes")]
		NSArray RegisteredDraggedTypes { get; }

//#endif
		//- (void)registerForDraggedTypes:(NSArray *)newTypes;
		[Export ("registerForDraggedTypes:")]
		void RegisterForDraggedTypes (NSArray newTypes);

		//- (void)unregisterDraggedTypes;
		[Export ("unregisterDraggedTypes")]
		void UnregisterDraggedTypes ();

		//- (BOOL)dragFile:(NSString *)filename fromRect:(NSRect)rect slideBack:(BOOL)aFlag event:(NSEvent *)event;
		[Export ("dragFile:fromRect:slideBack:event:")]
		bool DragFileFromRect (string filename, RectangleF rect, bool aFlag, NSEvent event1);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_2
		//- (BOOL)dragPromisedFilesOfTypes:(NSArray *)typeArray fromRect:(NSRect)rect source:(id)sourceObject slideBack:(BOOL)aFlag event:(NSEvent *)event;
		[Export ("dragPromisedFilesOfTypes:fromRect:source:slideBack:event:")]
		bool DragPromisedFilesOfTypesFromRect (NSArray typeArray, RectangleF rect, NSObject sourceObject, bool aFlag, NSEvent event1);

//#endif
		//- (void)exitFullScreenModeWithOptions:(NSDictionary *)options;
		[Export ("exitFullScreenModeWithOptions:")]
		void ExitFullScreenModeWithOptions (NSDictionary options);

		//- (BOOL)isInFullScreenMode; 
		[Export ("isInFullScreenMode")]
		bool IsInFullScreenMode { get; }

	}
}
