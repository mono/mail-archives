using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSTextFieldCell))]
	interface NSComboBoxCell {

		//- (BOOL)hasVerticalScroller;
		[Export ("hasVerticalScroller")]
		bool HasVerticalScroller { get; set; }

		//- (NSSize)intercellSpacing; 
		[Export ("intercellSpacing")]
		NSSize IntercellSpacing { get; set; }

		//- (CGFloat)itemHeight;
		[Export ("itemHeight")]
		float ItemHeight { get; set; }

		//- (NSInteger)numberOfVisibleItems;
		[Export ("numberOfVisibleItems")]
		int NumberOfVisibleItems { get; set; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//- (void)setButtonBordered:(BOOL)flag;
		[Export ("setButtonBordered:")]
		void SetButtonBordered (bool flag);

		//- (BOOL)isButtonBordered;
		[Export ("isButtonBordered")]
		bool IsButtonBordered { get; }

//#endif
		//- (void)reloadData;
		[Export ("reloadData")]
		void ReloadData ();

		//- (void)noteNumberOfItemsChanged;
		[Export ("noteNumberOfItemsChanged")]
		void NoteNumberOfItemsChanged ();

		//- (BOOL)usesDataSource;
		[Export ("usesDataSource")]
		bool UsesDataSource { get; set; }

		//- (void)scrollItemAtIndexToTop:(NSInteger)index;
		[Export ("scrollItemAtIndexToTop:")]
		void ScrollItemAtIndexToTop (int index);

		//- (void)scrollItemAtIndexToVisible:(NSInteger)index;
		[Export ("scrollItemAtIndexToVisible:")]
		void ScrollItemAtIndexToVisible (int index);

		//- (void)selectItemAtIndex:(NSInteger)index;
		[Export ("selectItemAtIndex:")]
		void SelectItemAtIndex (int index);

		//- (void)deselectItemAtIndex:(NSInteger)index;
		[Export ("deselectItemAtIndex:")]
		void DeselectItemAtIndex (int index);

		//- (NSInteger)indexOfSelectedItem;
		[Export ("indexOfSelectedItem")]
		int IndexOfSelectedItem { get; }

		//- (NSInteger)numberOfItems;
		[Export ("numberOfItems")]
		int NumberOfItems { get; }

		//- (BOOL)completes;
		[Export ("completes")]
		bool Completes { get; set; }

		//- (NSString *)completedString:(NSString *)string;
		[Export ("completedString:")]
		string CompletedString (string string1);

		//- (id)dataSource;
		[Export ("dataSource")]
		NSComboBoxCell DataSource { get; }

		//- (void)setDataSource:(id)aSource; 
		[Export ("setDataSource:")]
		void SetDataSource (NSObject aSource);

		//- (void)addItemWithObjectValue:(id)object;
		[Export ("addItemWithObjectValue:")]
		void AddItemWithObjectValue (NSObject object1);

		//- (void)addItemsWithObjectValues:(NSArray *)objects;
		[Export ("addItemsWithObjectValues:")]
		void AddItemsWithObjectValues (NSArray objects);

		//- (void)insertItemWithObjectValue:(id)object atIndex:(NSInteger)index;
		[Export ("insertItemWithObjectValue:atIndex:")]
		void InsertItemWithObjectValue (NSObject object1, int index);

		//- (void)removeItemWithObjectValue:(id)object;
		[Export ("removeItemWithObjectValue:")]
		void RemoveItemWithObjectValue (NSObject object1);

		//- (void)removeItemAtIndex:(NSInteger)index;
		[Export ("removeItemAtIndex:")]
		void RemoveItemAtIndex (int index);

		//- (void)removeAllItems;
		[Export ("removeAllItems")]
		void RemoveAllItems ();

		//- (void)selectItemWithObjectValue:(id)object;
		[Export ("selectItemWithObjectValue:")]
		void SelectItemWithObjectValue (NSObject object1);

		//- (id)itemObjectValueAtIndex:(NSInteger)index;
		[Export ("itemObjectValueAtIndex:")]
		NSComboBoxCell ItemObjectValueAtIndex (int index);

		//- (id)objectValueOfSelectedItem;
		[Export ("objectValueOfSelectedItem")]
		NSComboBoxCell ObjectValueOfSelectedItem { get; }

		//- (NSInteger)indexOfItemWithObjectValue:(id)object;
		[Export ("indexOfItemWithObjectValue:")]
		int IndexOfItemWithObjectValue (NSObject object1);

		//- (NSArray *)objectValues;
		[Export ("objectValues")]
		NSArray ObjectValues { get; }

	}
}
