using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{
	interface NSString {

		//- (NSSize)sizeWithAttributes:(NSDictionary *)attrs;
		[Export ("sizeWithAttributes:")]
		NSSize SizeWithAttributes (NSDictionary attrs);

		//- (void)drawAtPoint:(NSPoint)point withAttributes:(NSDictionary *)attrs;
		[Export ("drawAtPoint:withAttributes:")]
		void DrawAtPointWithAttributes (PointF point, NSDictionary attrs);

		//- (void)drawInRect:(NSRect)rect withAttributes:(NSDictionary *)attrs;
		[Export ("drawInRect:withAttributes:")]
		void DrawInRectWithAttributes (RectangleF rect, NSDictionary attrs);

		//- (void)drawWithRect:(NSRect)rect options:(NSStringDrawingOptions)options attributes:(NSDictionary *)attributes;
		[Export ("drawWithRect:options:attributes:")]
		void DrawWithRectOptions (RectangleF rect, NSStringDrawingOptions options, NSDictionary attributes);

		// - (NSRect)boundingRectWithSize:(NSSize)size options:(NSStringDrawingOptions)options attributes:(NSDictionary *)attributes;
		[Export ("boundingRectWithSize:options:attributes:")]
		RectangleF BoundingRectWithSizeOptions (NSSize size, NSStringDrawingOptions options, NSDictionary attributes);

	}
}
