using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSObject))]
	interface NSNibConnector {

		//- (id)source;
		[Export ("source")]
		NSNibConnector Source { get; }

		//- (void)setSource:(id)source;
		[Export ("setSource:")]
		void SetSource (NSObject source);

		//- (id)destination;
		[Export ("destination")]
		NSNibConnector Destination { get; }

		//- (void)setDestination:(id)destination;
		[Export ("setDestination:")]
		void SetDestination (NSObject destination);

		//- (NSString *)label;
		[Export ("label")]
		string Label { get; set; }

		//- (void)replaceObject:(id)oldObject withObject:(id)newObject;
		[Export ("replaceObject:withObject:")]
		void ReplaceObject (NSObject oldObject, NSObject newObject);

		//- (void)establishConnection;
		[Export ("establishConnection")]
		void EstablishConnection ();

	}
}
