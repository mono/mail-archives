using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSObject))]
	interface NSTextTab {

//#if __LP64__
//#endif
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//- (id)initWithTextAlignment:(NSTextAlignment)alignment location:(CGFloat)loc options:(NSDictionary *)options;
		[Export ("initWithTextAlignment:location:options:")]
		IntPtr Constructor (NSTextAlignment alignment, float loc, NSDictionary options);

		//- (NSTextAlignment)alignment;
		[Export ("alignment")]
		NSTextAlignment Alignment { get; }

		//- (NSDictionary *)options;
		[Export ("options")]
		NSDictionary Options { get; }

//#endif 
		//- (id)initWithType:(NSTextTabType)type location:(CGFloat)loc;
		[Export ("initWithType:location:")]
		IntPtr Constructor (NSTextTabType type, float loc);

		//- (CGFloat)location;
		[Export ("location")]
		float Location { get; }

		//- (NSTextTabType)tabStopType;
		[Export ("tabStopType")]
		NSTextTabType TabStopType { get; }

	}
}
