using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSObject))]
	interface NSPrintInfo {

		//+ (void)setSharedPrintInfo:(NSPrintInfo *)printInfo;
		[Static, Export ("setSharedPrintInfo:")]
		void SetSharedPrintInfo (NSPrintInfo printInfo);

		//+ (NSPrintInfo *)sharedPrintInfo;
		[Static, Export ("sharedPrintInfo")]
		NSPrintInfo SharedPrintInfo { get; }

		//- (id)initWithDictionary:(NSDictionary *)attributes;
		[Export ("initWithDictionary:")]
		IntPtr Constructor (NSDictionary attributes);

		//- (NSMutableDictionary *)dictionary;
		[Export ("dictionary")]
		NSDictionary Dictionary { get; }

		//- (NSString *)paperName;
		[Export ("paperName")]
		string PaperName { get; set; }

		//- (NSSize)paperSize;
		[Export ("paperSize")]
		NSSize PaperSize { get; set; }

		//- (NSPrintingOrientation)orientation;
		[Export ("orientation")]
		NSPrintingOrientation Orientation { get; set; }

		//- (CGFloat)leftMargin;
		[Export ("leftMargin")]
		float LeftMargin { get; set; }

		//- (CGFloat)rightMargin;
		[Export ("rightMargin")]
		float RightMargin { get; set; }

		//- (CGFloat)topMargin;
		[Export ("topMargin")]
		float TopMargin { get; set; }

		//- (CGFloat)bottomMargin;
		[Export ("bottomMargin")]
		float BottomMargin { get; set; }

		//- (void)setHorizontallyCentered:(BOOL)flag;
		[Export ("setHorizontallyCentered:")]
		void SetHorizontallyCentered (bool flag);

		//- (void)setVerticallyCentered:(BOOL)flag;
		[Export ("setVerticallyCentered:")]
		void SetVerticallyCentered (bool flag);

		//- (BOOL)isHorizontallyCentered;
		[Export ("isHorizontallyCentered")]
		bool IsHorizontallyCentered { get; }

		//- (BOOL)isVerticallyCentered;
		[Export ("isVerticallyCentered")]
		bool IsVerticallyCentered { get; }

		//- (NSPrintingPaginationMode)horizontalPagination;
		[Export ("horizontalPagination")]
		NSPrintingPaginationMode HorizontalPagination { get; set; }

		//- (NSPrintingPaginationMode)verticalPagination;
		[Export ("verticalPagination")]
		NSPrintingPaginationMode VerticalPagination { get; set; }

		//- (NSString *)jobDisposition;
		[Export ("jobDisposition")]
		string JobDisposition { get; set; }

		//- (NSPrinter *)printer;
		[Export ("printer")]
		NSPrinter Printer { get; set; }

		//- (void)setUpPrintOperationDefaultValues;
		[Export ("setUpPrintOperationDefaultValues")]
		void SetUpPrintOperationDefaultValues ();

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_2
		//- (NSRect)imageablePageBounds;
		[Export ("imageablePageBounds")]
		RectangleF ImageablePageBounds { get; }

//#endif
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//- (NSString *)localizedPaperName;
		[Export ("localizedPaperName")]
		string LocalizedPaperName { get; }

//#endif
		//+ (NSPrinter *)defaultPrinter;
		[Static, Export ("defaultPrinter")]
		NSPrinter DefaultPrinter { get; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (NSMutableDictionary *)printSettings;
		[Export ("printSettings")]
		NSDictionary PrintSettings { get; }

		//- (void *)PMPrintSession; 
		[Export ("PMPrintSession")]
		void PMPrintSession ();

		//- (void *)PMPageFormat; 
		[Export ("PMPageFormat")]
		void PMPageFormat ();

		//- (void *)PMPrintSettings; 
		[Export ("PMPrintSettings")]
		void PMPrintSettings ();

		//- (void)updateFromPMPageFormat;
		[Export ("updateFromPMPageFormat")]
		void UpdateFromPMPageFormat ();

		//- (void)updateFromPMPrintSettings;
		[Export ("updateFromPMPrintSettings")]
		void UpdateFromPMPrintSettings ();

//#endif
		////+ (void)setDefaultPrinter:(NSPrinter *)printer;
		//[Static, Export ("setDefaultPrinter:")]
		//void SetDefaultPrinter (NSPrinter printer);

		////+ (NSSize)sizeForPaperName:(NSString *)name;
		//[Static, Export ("sizeForPaperName:")]
		//NSSize SizeForPaperName (string name);

	}
}
