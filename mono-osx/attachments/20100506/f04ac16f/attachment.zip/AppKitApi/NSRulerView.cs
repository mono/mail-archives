using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSView))]
	interface NSRulerView {

		//+ (void)registerUnitWithName:(NSString *)unitName abbreviation:(NSString *)abbreviation unitToPointsConversionFactor:(CGFloat)conversionFactor stepUpCycle:(NSArray *)stepUpCycle stepDownCycle:(NSArray *)stepDownCycle;
		[Static, Export ("registerUnitWithName:abbreviation:unitToPointsConversionFactor:stepUpCycle:stepDownCycle:")]
		void RegisterUnitWithName (string unitName, string abbreviation, float conversionFactor, NSArray stepUpCycle, NSArray stepDownCycle);

		//- (id)initWithScrollView:(NSScrollView *)scrollView orientation:(NSRulerOrientation)orientation;
		[Export ("initWithScrollView:orientation:")]
		IntPtr Constructor (NSScrollView scrollView, NSRulerOrientation orientation);

		//- (NSScrollView *)scrollView;
		[Export ("scrollView")]
		NSScrollView ScrollView { get; set; }

		//- (NSRulerOrientation)orientation;
		[Export ("orientation")]
		NSRulerOrientation Orientation { get; set; }

		//    - (CGFloat)baselineLocation;
		[Export ("baselineLocation")]
		float BaselineLocation { get; }

		//    - (CGFloat)requiredThickness;
		[Export ("requiredThickness")]
		float RequiredThickness { get; }

		//- (CGFloat)ruleThickness;
		[Export ("ruleThickness")]
		float RuleThickness { get; set; }

		//- (CGFloat)reservedThicknessForMarkers;
		[Export ("reservedThicknessForMarkers")]
		float ReservedThicknessForMarkers { get; set; }

		//- (CGFloat)reservedThicknessForAccessoryView;
		[Export ("reservedThicknessForAccessoryView")]
		float ReservedThicknessForAccessoryView { get; set; }

		//- (NSString *)measurementUnits;
		[Export ("measurementUnits")]
		string MeasurementUnits { get; set; }

		//- (CGFloat)originOffset;
		[Export ("originOffset")]
		float OriginOffset { get; set; }

		//- (NSView *)clientView;
		[Export ("clientView")]
		NSView ClientView { get; set; }

		//- (void)addMarker:(NSRulerMarker *)marker;
		[Export ("addMarker:")]
		void AddMarker (NSRulerMarker marker);

		//- (void)removeMarker:(NSRulerMarker *)marker;
		[Export ("removeMarker:")]
		void RemoveMarker (NSRulerMarker marker);

		//- (NSArray *)markers;
		[Export ("markers")]
		NSArray Markers { get; set; }

		//    - (BOOL)trackMarker:(NSRulerMarker *)marker withMouseEvent:(NSEvent *)event;
		[Export ("trackMarker:withMouseEvent:")]
		bool TrackMarker (NSRulerMarker marker, NSEvent event1);

		//- (NSView *)accessoryView;
		[Export ("accessoryView")]
		NSView AccessoryView { get; set; }

		//    - (void)moveRulerlineFromLocation:(CGFloat)oldLocation toLocation:(CGFloat)newLocation;
		[Export ("moveRulerlineFromLocation:toLocation:")]
		void MoveRulerlineFromLocation (float oldLocation, float newLocation);

		//- (void)invalidateHashMarks;
		[Export ("invalidateHashMarks")]
		void InvalidateHashMarks ();

		//    - (void)drawHashMarksAndLabelsInRect:(NSRect)rect;
		[Export ("drawHashMarksAndLabelsInRect:")]
		void DrawHashMarksAndLabelsInRect (RectangleF rect);

		//    - (void)drawMarkersInRect:(NSRect)rect;
		[Export ("drawMarkersInRect:")]
		void DrawMarkersInRect (RectangleF rect);

		//    - (BOOL)isFlipped;
		[Export ("isFlipped")]
		bool IsFlipped { get; }

	}
}
