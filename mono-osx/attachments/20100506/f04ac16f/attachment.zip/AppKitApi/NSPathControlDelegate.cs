using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{
	[BaseType (typeof (NSObject))]
	[Model]
	interface NSPathControlDelegate {

		[Abstract]
		//@optional- (BOOL)pathControl:(NSPathControl *)pathControl shouldDragPathComponentCell:(NSPathComponentCell *)pathComponentCell withPasteboard:(NSPasteboard *)pasteboard;
		[Export ("pathControl:shouldDragPathComponentCell:withPasteboard:")]
		bool PathControl (NSPathControl pathControl, NSPathComponentCell pathComponentCell, NSPasteboard pasteboard);

		[Abstract]
		//- (NSDragOperation)pathControl:(NSPathControl *)pathControl validateDrop:(id <NSDraggingInfo>)info;
		[Export ("pathControl:validateDrop:")]
		NSDragOperation PathControl (NSPathControl pathControl, NSObject info);

		[Abstract]
		//- (BOOL)pathControl:(NSPathControl *)pathControl acceptDrop:(id <NSDraggingInfo>)info;
		[Export ("pathControl:acceptDrop:")]
		bool PathControlAcceptDrop (NSPathControl pathControl, NSObject info);

		[Abstract]
		//- (void)pathControl:(NSPathControl *)pathControl willDisplayOpenPanel:(NSOpenPanel *)openPanel;
		[Export ("pathControl:willDisplayOpenPanel:")]
		void PathControl (NSPathControl pathControl, NSOpenPanel openPanel);

		[Abstract]
		//- (void)pathControl:(NSPathControl *)pathControl willPopUpMenu:(NSMenu *)menu;
		[Export ("pathControl:willPopUpMenu:")]
		void PathControl (NSPathControl pathControl, NSMenu menu);

	}
}
