using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSControl))]
	interface NSBrowser {

		//+ (Class)cellClass;
		[Static, Export ("cellClass")]
		Class CellClass { get; set; }

		//- (void)loadColumnZero;
		[Export ("loadColumnZero")]
		void LoadColumnZero ();

		//- (BOOL)isLoaded;
		[Export ("isLoaded")]
		bool IsLoaded { get; }

		//- (SEL)doubleAction;
		[Export ("doubleAction")]
		Selector DoubleAction { get; set; }

		//- (Class)matrixClass;
		[Export ("matrixClass")]
		Class MatrixClass { get; set; }

		//- (void)setCellPrototype:(NSCell *)aCell;
		[Export ("setCellPrototype:")]
		void SetCellPrototype (NSCell aCell);

		//- (id)cellPrototype;
		[Export ("cellPrototype")]
		NSBrowser CellPrototype { get; }

		//- (void)setDelegate:(id)anObject;
		[Export ("setDelegate:")]
		void SetDelegate (NSObject anObject);

		//- (id)delegate;
		[Export ("delegate")]
		NSBrowser Delegate { get; }

		//- (BOOL)reusesColumns;
		[Export ("reusesColumns")]
		bool ReusesColumns { get; set; }

		//- (BOOL)hasHorizontalScroller;
		[Export ("hasHorizontalScroller")]
		bool HasHorizontalScroller { get; set; }

		//- (BOOL)separatesColumns;
		[Export ("separatesColumns")]
		bool SeparatesColumns { get; set; }

		//- (void)setTitled:(BOOL)flag;
		[Export ("setTitled:")]
		void SetTitled (bool flag);

		//- (BOOL)isTitled;
		[Export ("isTitled")]
		bool IsTitled { get; }

		//- (CGFloat)minColumnWidth;
		[Export ("minColumnWidth")]
		float MinColumnWidth { get; set; }

		//- (NSInteger)maxVisibleColumns;
		[Export ("maxVisibleColumns")]
		int MaxVisibleColumns { get; set; }

		//- (BOOL)allowsMultipleSelection;
		[Export ("allowsMultipleSelection")]
		bool AllowsMultipleSelection { get; set; }

		//- (BOOL)allowsBranchSelection;
		[Export ("allowsBranchSelection")]
		bool AllowsBranchSelection { get; set; }

		//- (BOOL)allowsEmptySelection;
		[Export ("allowsEmptySelection")]
		bool AllowsEmptySelection { get; set; }

		//- (BOOL)takesTitleFromPreviousColumn;
		[Export ("takesTitleFromPreviousColumn")]
		bool TakesTitleFromPreviousColumn { get; set; }

		//- (BOOL)acceptsArrowKeys;
		[Export ("acceptsArrowKeys")]
		bool AcceptsArrowKeys { get; set; }

		//- (BOOL)sendsActionOnArrowKeys;
		[Export ("sendsActionOnArrowKeys")]
		bool SendsActionOnArrowKeys { get; set; }

		//- (void)setTitle:(NSString *)aString ofColumn:(NSInteger)column;
		[Export ("setTitle:ofColumn:")]
		void SetTitle (string aString, int column);

		//- (NSString *)titleOfColumn:(NSInteger)column;
		[Export ("titleOfColumn:")]
		string TitleOfColumn (int column);

		//- (NSString *)pathSeparator;
		[Export ("pathSeparator")]
		string PathSeparator { get; set; }

		//- (BOOL)setPath:(NSString *)path;
		[Export ("setPath:")]
		bool SetPath (string path);

		//- (NSString *)path;
		[Export ("path")]
		string Path { get; }

		//- (NSString *)pathToColumn:(NSInteger)column;
		[Export ("pathToColumn:")]
		string PathToColumn (int column);

		//- (NSInteger)selectedColumn;
		[Export ("selectedColumn")]
		int SelectedColumn { get; }

		//- (id)selectedCell;
		[Export ("selectedCell")]
		NSBrowser SelectedCell { get; }

		//- (id)selectedCellInColumn:(NSInteger)column;
		[Export ("selectedCellInColumn:")]
		NSBrowser SelectedCellInColumn (int column);

		//- (NSArray *)selectedCells;
		[Export ("selectedCells")]
		NSArray SelectedCells { get; }

		//- (void)selectRow:(NSInteger)row inColumn:(NSInteger)column;
		[Export ("selectRow:inColumn:")]
		void SelectRow (int row, int column);

		//- (NSInteger)selectedRowInColumn:(NSInteger)column;
		[Export ("selectedRowInColumn:")]
		int SelectedRowInColumn (int column);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (void)selectRowIndexes:(NSIndexSet *)indexes inColumn:(NSInteger)column;
		[Export ("selectRowIndexes:inColumn:")]
		void SelectRowIndexes (NSIndexSet indexes, int column);

		//- (NSIndexSet *)selectedRowIndexesInColumn:(NSInteger)column;
		[Export ("selectedRowIndexesInColumn:")]
		NSIndexSet SelectedRowIndexesInColumn (int column);

//#endif
		//- (void)reloadColumn:(NSInteger)column;
		[Export ("reloadColumn:")]
		void ReloadColumn (int column);

		//- (void)validateVisibleColumns;
		[Export ("validateVisibleColumns")]
		void ValidateVisibleColumns ();

		//- (void)scrollColumnsRightBy:(NSInteger)shiftAmount;
		[Export ("scrollColumnsRightBy:")]
		void ScrollColumnsRightBy (int shiftAmount);

		//- (void)scrollColumnsLeftBy:(NSInteger)shiftAmount;
		[Export ("scrollColumnsLeftBy:")]
		void ScrollColumnsLeftBy (int shiftAmount);

		//- (void)scrollColumnToVisible:(NSInteger)column;
		[Export ("scrollColumnToVisible:")]
		void ScrollColumnToVisible (int column);

		//- (NSInteger)lastColumn;
		[Export ("lastColumn")]
		int LastColumn { get; set; }

		//- (void)addColumn;
		[Export ("addColumn")]
		void AddColumn ();

		//- (NSInteger)numberOfVisibleColumns;
		[Export ("numberOfVisibleColumns")]
		int NumberOfVisibleColumns { get; }

		//- (NSInteger)firstVisibleColumn;
		[Export ("firstVisibleColumn")]
		int FirstVisibleColumn { get; }

		//- (NSInteger)lastVisibleColumn;
		[Export ("lastVisibleColumn")]
		int LastVisibleColumn { get; }

		//- (NSInteger)columnOfMatrix:(NSMatrix *)matrix;
		[Export ("columnOfMatrix:")]
		int ColumnOfMatrix (NSMatrix matrix);

		//- (NSMatrix *)matrixInColumn:(NSInteger)column;
		[Export ("matrixInColumn:")]
		NSMatrix MatrixInColumn (int column);

		//- (id)loadedCellAtRow:(NSInteger)row column:(NSInteger)col;
		[Export ("loadedCellAtRow:column:")]
		NSBrowser LoadedCellAtRow (int row, int col);

		//- (void)selectAll:(id)sender;
		[Export ("selectAll:")]
		void SelectAll (NSObject sender);

		//- (void)tile;
		[Export ("tile")]
		void Tile ();

		//- (void)doClick:(id)sender;
		[Export ("doClick:")]
		void DoClick (NSObject sender);

		//- (void)doDoubleClick:(id)sender;
		[Export ("doDoubleClick:")]
		void DoDoubleClick (NSObject sender);

		//- (BOOL)sendAction;
		[Export ("sendAction")]
		bool SendAction { get; }

		//- (NSRect)titleFrameOfColumn:(NSInteger)column;
		[Export ("titleFrameOfColumn:")]
		RectangleF TitleFrameOfColumn (int column);

		//- (void)drawTitleOfColumn:(NSInteger)column inRect:(NSRect)aRect;
		[Export ("drawTitleOfColumn:inRect:")]
		void DrawTitleOfColumn (int column, RectangleF aRect);

		//- (CGFloat)titleHeight;
		[Export ("titleHeight")]
		float TitleHeight { get; }

		//- (NSRect)frameOfColumn:(NSInteger)column;
		[Export ("frameOfColumn:")]
		RectangleF FrameOfColumn (int column);

		//- (NSRect)frameOfInsideOfColumn:(NSInteger)column;
		[Export ("frameOfInsideOfColumn:")]
		RectangleF FrameOfInsideOfColumn (int column);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//- (CGFloat)columnWidthForColumnContentWidth:(CGFloat)columnContentWidth;
		[Export ("columnWidthForColumnContentWidth:")]
		float ColumnWidthForColumnContentWidth (float columnContentWidth);

		//- (CGFloat)columnContentWidthForColumnWidth:(CGFloat)columnWidth;
		[Export ("columnContentWidthForColumnWidth:")]
		float ColumnContentWidthForColumnWidth (float columnWidth);

//#endif
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//- (NSBrowserColumnResizingType)columnResizingType;
		[Export ("columnResizingType")]
		NSBrowserColumnResizingType ColumnResizingType { get; set; }

		//- (BOOL)prefersAllColumnUserResizing;
		[Export ("prefersAllColumnUserResizing")]
		bool PrefersAllColumnUserResizing { get; set; }

		//- (void)setWidth:(CGFloat)columnWidth ofColumn:(NSInteger)columnIndex;
		[Export ("setWidth:ofColumn:")]
		void SetWidth (float columnWidth, int columnIndex);

		//- (CGFloat)widthOfColumn:(NSInteger)column;
		[Export ("widthOfColumn:")]
		float WidthOfColumn (int column);

		//- (NSString *)columnsAutosaveName;
		[Export ("columnsAutosaveName")]
		string ColumnsAutosaveName { get; set; }

		//+ (void)removeSavedColumnsWithAutosaveName:(NSString *)name;
		[Static, Export ("removeSavedColumnsWithAutosaveName:")]
		void RemoveSavedColumnsWithAutosaveName (string name);

//#endif
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//    #pragma mark -#pragma mark **** Drag and Drop Support ****- (BOOL)canDragRowsWithIndexes:(NSIndexSet *)rowIndexes inColumn:(NSInteger)column withEvent:(NSEvent *)event;
		[Export ("canDragRowsWithIndexes:inColumn:withEvent:")]
		bool CanDragRowsWithIndexes (NSIndexSet rowIndexes, int column, NSEvent event1);

		//- (NSImage *)draggingImageForRowsWithIndexes:(NSIndexSet *)rowIndexes inColumn:(NSInteger)column withEvent:(NSEvent *)event offset:(NSPointPointer)dragImageOffset;
		[Export ("draggingImageForRowsWithIndexes:inColumn:withEvent:offset:")]
		NSImage DraggingImageForRowsWithIndexes (NSIndexSet rowIndexes, int column, NSEvent event1, NSPointPointer dragImageOffset);

		//- (void)setDraggingSourceOperationMask:(NSDragOperation)mask forLocal:(BOOL)isLocal;
		[Export ("setDraggingSourceOperationMask:forLocal:")]
		void SetDraggingSourceOperationMask (NSDragOperation mask, bool isLocal);

		//#pragma mark -- (BOOL)allowsTypeSelect;
		[Export ("allowsTypeSelect")]
		bool AllowsTypeSelect { get; set; }

		//- (NSColor *)backgroundColor;
		[Export ("backgroundColor")]
		NSColor BackgroundColor { get; set; }

//#endif  
		//#pragma mark **** Deprecated NSBrowser methods ****- (void)displayColumn:(NSInteger)column;
		[Export ("displayColumn:")]
		void DisplayColumn (int column);

		//- (void)displayAllColumns;
		[Export ("displayAllColumns")]
		void DisplayAllColumns ();

		//- (void)scrollViaScroller:(NSScroller *)sender;
		[Export ("scrollViaScroller:")]
		void ScrollViaScroller (NSScroller sender);

		//- (void)updateScroller;
		[Export ("updateScroller")]
		void UpdateScroller ();

	}
}
