using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSImageRep))]
	interface NSCustomImageRep {

		//- (id)initWithDrawSelector:(SEL)aMethod delegate:(id)anObject;
		[Export ("initWithDrawSelector:delegate:")]
		IntPtr Constructor (Selector aMethod, NSObject anObject);

		//- (SEL)drawSelector;
		[Export ("drawSelector")]
		Selector DrawSelector { get; }

		//- (id)delegate;
		[Export ("delegate")]
		NSCustomImageRep Delegate { get; }

	}
}
