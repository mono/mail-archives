using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSResponder))]
	interface NSViewController {

		//- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil;
		[Export ("initWithNibName:bundle:")]
		IntPtr Constructor (string nibNameOrNil, NSBundle nibBundleOrNil);

		//- (void)setRepresentedObject:(id)representedObject;
		[Export ("setRepresentedObject:")]
		void SetRepresentedObject (NSObject representedObject);

		//- (id)representedObject;
		[Export ("representedObject")]
		NSViewController RepresentedObject { get; }

		//- (NSString *)title;
		[Export ("title")]
		string Title { get; set; }

		//- (NSView *)view;
		[Export ("view")]
		NSView View { get; set; }

		//- (void)loadView;
		[Export ("loadView")]
		void LoadView ();

		//- (NSString *)nibName;
		[Export ("nibName")]
		string NibName { get; }

		//- (NSBundle *)nibBundle;
		[Export ("nibBundle")]
		NSBundle NibBundle { get; }

		//- (void)commitEditingWithDelegate:(id)delegate didCommitSelector:(SEL)didCommitSelector contextInfo:(void *)contextInfo;
		[Export ("commitEditingWithDelegate:didCommitSelector:contextInfo:")]
		void CommitEditingWithDelegate (NSObject delegate1, Selector didCommitSelector, IntPtr contextInfo);

		//- (BOOL)commitEditing;
		[Export ("commitEditing")]
		bool CommitEditing { get; }

		//- (void)discardEditing;
		[Export ("discardEditing")]
		void DiscardEditing ();

	}
}
