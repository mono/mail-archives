using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSView))]
	interface NSMenuView {

		//+ (CGFloat)menuBarHeight;
		[Static, Export ("menuBarHeight")]
		float MenuBarHeight { get; }

		//- (id)initWithFrame:(NSRect)frame;  
		[Export ("initWithFrame:")]
		IntPtr Constructor (RectangleF frame);

		//- (id)initAsTearOff;
		[Export ("initAsTearOff")]
		IntPtr InitAsTearOff { get; }

		//- (NSMenu *)menu;
		[Export ("menu")]
		NSMenu Menu { get; set; }

		//- (void)itemChanged:(NSNotification *)notification;
		[Export ("itemChanged:")]
		void ItemChanged (NSNotification notification);

		//- (void)itemAdded:(NSNotification *)notification;
		[Export ("itemAdded:")]
		void ItemAdded (NSNotification notification);

		//- (void)itemRemoved:(NSNotification *)notification;
		[Export ("itemRemoved:")]
		void ItemRemoved (NSNotification notification);

		//- (void)update;
		[Export ("update")]
		void Update ();

		//- (void)setHorizontal:(BOOL)flag;
		[Export ("setHorizontal:")]
		void SetHorizontal (bool flag);

		//- (BOOL)isHorizontal;
		[Export ("isHorizontal")]
		bool IsHorizontal { get; }

		//- (NSFont *)font;
		[Export ("font")]
		NSFont Font { get; set; }

		//- (NSRect)innerRect; 
		[Export ("innerRect")]
		RectangleF InnerRect { get; }

		//- (NSRect)rectOfItemAtIndex:(NSInteger)index;
		[Export ("rectOfItemAtIndex:")]
		RectangleF RectOfItemAtIndex (int index);

		//- (NSInteger)indexOfItemAtPoint:(NSPoint)point;
		[Export ("indexOfItemAtPoint:")]
		int IndexOfItemAtPoint (PointF point);

		//- (void)setNeedsDisplayForItemAtIndex:(NSInteger)index;
		[Export ("setNeedsDisplayForItemAtIndex:")]
		void SetNeedsDisplayForItemAtIndex (int index);

		//- (NSInteger)highlightedItemIndex;
		[Export ("highlightedItemIndex")]
		int HighlightedItemIndex { get; set; }

		//- (CGFloat)stateImageOffset;
		[Export ("stateImageOffset")]
		float StateImageOffset { get; }

		//- (CGFloat)stateImageWidth;
		[Export ("stateImageWidth")]
		float StateImageWidth { get; }

		//- (CGFloat)imageAndTitleOffset;
		[Export ("imageAndTitleOffset")]
		float ImageAndTitleOffset { get; }

		//- (CGFloat)imageAndTitleWidth;
		[Export ("imageAndTitleWidth")]
		float ImageAndTitleWidth { get; }

		//- (CGFloat)keyEquivalentOffset;
		[Export ("keyEquivalentOffset")]
		float KeyEquivalentOffset { get; }

		//- (CGFloat)keyEquivalentWidth;
		[Export ("keyEquivalentWidth")]
		float KeyEquivalentWidth { get; }

		//- (void)setMenuItemCell:(NSMenuItemCell *)cell forItemAtIndex:(NSInteger)index;
		[Export ("setMenuItemCell:forItemAtIndex:")]
		void SetMenuItemCell (NSMenuItemCell cell, int index);

		//- (NSMenuItemCell *)menuItemCellForItemAtIndex:(NSInteger)index;
		[Export ("menuItemCellForItemAtIndex:")]
		NSMenuItemCell MenuItemCellForItemAtIndex (int index);

		//- (NSMenuView *)attachedMenuView;
		[Export ("attachedMenuView")]
		NSMenuView AttachedMenuView { get; }

		//- (BOOL)needsSizing;
		[Export ("needsSizing")]
		bool NeedsSizing { get; set; }

		//- (void)sizeToFit;
		[Export ("sizeToFit")]
		void SizeToFit ();

		//- (NSMenu *)attachedMenu;
		[Export ("attachedMenu")]
		NSMenu AttachedMenu { get; }

		//- (BOOL)isAttached;
		[Export ("isAttached")]
		bool IsAttached { get; }

		//- (BOOL)isTornOff;
		[Export ("isTornOff")]
		bool IsTornOff { get; }

		//- (NSPoint)locationForSubmenu:(NSMenu *)aSubmenu;
		[Export ("locationForSubmenu:")]
		PointF LocationForSubmenu (NSMenu aSubmenu);

		//- (void)setWindowFrameForAttachingToRect:(NSRect)screenRect onScreen:(NSScreen *)screen preferredEdge:(NSRectEdge)edge popUpSelectedItem:(NSInteger)selectedItemIndex;
		[Export ("setWindowFrameForAttachingToRect:onScreen:preferredEdge:popUpSelectedItem:")]
		void SetWindowFrameForAttachingToRect (RectangleF screenRect, NSScreen screen, NSRectEdge edge, int selectedItemIndex);

		//- (void)detachSubmenu;
		[Export ("detachSubmenu")]
		void DetachSubmenu ();

		//- (void)attachSubmenuForItemAtIndex:(NSInteger)index;
		[Export ("attachSubmenuForItemAtIndex:")]
		void AttachSubmenuForItemAtIndex (int index);

		//- (void)performActionWithHighlightingForItemAtIndex:(NSInteger)index;
		[Export ("performActionWithHighlightingForItemAtIndex:")]
		void PerformActionWithHighlightingForItemAtIndex (int index);

		//- (BOOL)trackWithEvent:(NSEvent *)event;
		[Export ("trackWithEvent:")]
		bool TrackWithEvent (NSEvent event1);

		//- (CGFloat)horizontalEdgePadding;
		[Export ("horizontalEdgePadding")]
		float HorizontalEdgePadding { get; set; }

	}
}
