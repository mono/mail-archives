using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSObject))]
	interface NSPredicateEditorRowTemplate {

		//- (double)matchForPredicate:(NSPredicate *)predicate;
		[Export ("matchForPredicate:")]
		double MatchForPredicate (NSPredicate predicate);

		//- (NSArray *)templateViews;
		[Export ("templateViews")]
		NSArray TemplateViews { get; }

		//- (void)setPredicate:(NSPredicate *)predicate;
		[Export ("setPredicate:")]
		void SetPredicate (NSPredicate predicate);

		//- (NSPredicate *)predicateWithSubpredicates:(NSArray *)subpredicates;
		[Export ("predicateWithSubpredicates:")]
		NSPredicate PredicateWithSubpredicates (NSArray subpredicates);

		// - (NSArray *)displayableSubpredicatesOfPredicate:(NSPredicate *)predicate;
		[Export ("displayableSubpredicatesOfPredicate:")]
		NSArray DisplayableSubpredicatesOfPredicate (NSPredicate predicate);

		//- (id)initWithLeftExpressions:(NSArray *)leftExpressions rightExpressions:(NSArray *)rightExpressions modifier:(NSComparisonPredicateModifier)modifier operators:(NSArray *)operators options:(NSUInteger)options;
		[Export ("initWithLeftExpressions:rightExpressions:modifier:operators:options:")]
		IntPtr Constructor (NSArray leftExpressions, NSArray rightExpressions, NSComparisonPredicateModifier modifier, NSArray operators, uint options);

		//- (id)initWithLeftExpressions:(NSArray *)leftExpressions rightExpressionAttributeType:(NSAttributeType)attributeType modifier:(NSComparisonPredicateModifier)modifier operators:(NSArray *)operators options:(NSUInteger)options;
		[Export ("initWithLeftExpressions:rightExpressionAttributeType:modifier:operators:options:")]
		IntPtr Constructor (NSArray leftExpressions, NSAttributeType attributeType, NSComparisonPredicateModifier modifier, NSArray operators, uint options);

		//- (id)initWithCompoundTypes:(NSArray *)compoundTypes;
		[Export ("initWithCompoundTypes:")]
		IntPtr Constructor (NSArray compoundTypes);

		//- (NSArray *)leftExpressions;
		[Export ("leftExpressions")]
		NSArray LeftExpressions { get; }

		//- (NSArray *)rightExpressions;
		[Export ("rightExpressions")]
		NSArray RightExpressions { get; }

		//- (NSAttributeType)rightExpressionAttributeType;
		[Export ("rightExpressionAttributeType")]
		NSAttributeType RightExpressionAttributeType { get; }

		//- (NSComparisonPredicateModifier)modifier;
		[Export ("modifier")]
		NSComparisonPredicateModifier Modifier { get; }

		//- (NSArray *)operators;
		[Export ("operators")]
		NSArray Operators { get; }

		//- (NSUInteger)options;
		[Export ("options")]
		uint Options { get; }

		//- (NSArray *)compoundTypes;
		[Export ("compoundTypes")]
		NSArray CompoundTypes { get; }

		//+ (NSArray *)templatesWithAttributeKeyPaths:(NSArray *)keyPaths inEntityDescription:(NSEntityDescription *)entityDescription;
		[Static, Export ("templatesWithAttributeKeyPaths:inEntityDescription:")]
		NSArray TemplatesWithAttributeKeyPaths (NSArray keyPaths, NSEntityDescription entityDescription);

	}
}
