using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSObject))]
	interface NSGradient {

		//- (id)initWithStartingColor:(NSColor *)startingColor endingColor:(NSColor *)endingColor;
		[Export ("initWithStartingColor:endingColor:")]
		IntPtr Constructor (NSColor startingColor, NSColor endingColor);

		//- (id)initWithColors:(NSArray *)colorArray;
		[Export ("initWithColors:")]
		IntPtr Constructor (NSArray colorArray);

		////- (id)initWithColorsAndLocations:(NSColor *)firstColor, ...;
		//[Export ("initWithColorsAndLocations:")]
		//IntPtr Constructor (NSColor firstColor,);

		////- (id)initWithColors:(NSArray *)colorArray atLocations:(const CGFloat *)locations colorSpace:(NSColorSpace *)colorSpace;
		//[Export ("initWithColors:atLocations:colorSpace:")]
		//IntPtr Constructor (NSArray colorArray, const CGFloat locations, NSColorSpace colorSpace);

		//- (void)drawFromPoint:(NSPoint)startingPoint toPoint:(NSPoint)endingPoint options:(NSGradientDrawingOptions)options;
		[Export ("drawFromPoint:toPoint:options:")]
		void DrawFromPoint (PointF startingPoint, PointF endingPoint, NSGradientDrawingOptions options);

		//- (void)drawInRect:(NSRect)rect angle:(CGFloat)angle;
		[Export ("drawInRect:angle:")]
		void DrawInRect (RectangleF rect, float angle);

		//- (void)drawInBezierPath:(NSBezierPath *)path angle:(CGFloat)angle;
		[Export ("drawInBezierPath:angle:")]
		void DrawInBezierPath (NSBezierPath path, float angle);

		//- (void)drawFromCenter:(NSPoint)startCenter radius:(CGFloat)startRadius toCenter:(NSPoint)endCenter radius:(CGFloat)endRadius options:(NSGradientDrawingOptions)options;
		[Export ("drawFromCenter:radius:toCenter:radius:options:")]
		void DrawFromCenter (PointF startCenter, float startRadius, PointF endCenter, float endRadius, NSGradientDrawingOptions options);

		//- (void)drawInRect:(NSRect)rect relativeCenterPosition:(NSPoint)relativeCenterPosition;
		[Export ("drawInRect:relativeCenterPosition:")]
		void DrawInRect (RectangleF rect, PointF relativeCenterPosition);

		//- (void)drawInBezierPath:(NSBezierPath *)path relativeCenterPosition:(NSPoint)relativeCenterPosition;
		[Export ("drawInBezierPath:relativeCenterPosition:")]
		void DrawInBezierPath (NSBezierPath path, PointF relativeCenterPosition);

		//- (NSColorSpace *)colorSpace;
		[Export ("colorSpace")]
		NSColorSpace ColorSpace { get; }

		//- (NSInteger)numberOfColorStops;
		[Export ("numberOfColorStops")]
		int NumberOfColorStops { get; }

		//- (void)getColor:(NSColor **)color location:(CGFloat *)location atIndex:(NSInteger)index;
		[Export ("getColor:location:atIndex:")]
		void GetColor (NSColor color, float location, int index);

		//- (NSColor *)interpolatedColorAtLocation:(CGFloat)location;
		[Export ("interpolatedColorAtLocation:")]
		NSColor InterpolatedColorAtLocation (float location);

	}
}
