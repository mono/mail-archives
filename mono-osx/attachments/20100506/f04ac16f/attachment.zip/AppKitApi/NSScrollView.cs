using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSView))]
	interface NSScrollView {

		//+ (NSSize)frameSizeForContentSize:(NSSize)cSize hasHorizontalScroller:(BOOL)hFlag hasVerticalScroller:(BOOL)vFlag borderType:(NSBorderType)aType;
		[Static, Export ("frameSizeForContentSize:hasHorizontalScroller:hasVerticalScroller:borderType:")]
		NSSize FrameSizeForContentSize (NSSize cSize, bool hFlag, bool vFlag, NSBorderType aType);

		//+ (NSSize)contentSizeForFrameSize:(NSSize)fSize hasHorizontalScroller:(BOOL)hFlag hasVerticalScroller:(BOOL)vFlag borderType:(NSBorderType)aType;
		[Static, Export ("contentSizeForFrameSize:hasHorizontalScroller:hasVerticalScroller:borderType:")]
		NSSize ContentSizeForFrameSize (NSSize fSize, bool hFlag, bool vFlag, NSBorderType aType);

		//- (NSRect)documentVisibleRect;
		[Export ("documentVisibleRect")]
		RectangleF DocumentVisibleRect { get; }

		//- (NSSize)contentSize;
		[Export ("contentSize")]
		NSSize ContentSize { get; }

		//- (void)setDocumentView:(NSView *)aView;
		[Export ("setDocumentView:")]
		void SetDocumentView (NSView aView);

		//- (id)documentView;
		[Export ("documentView")]
		NSScrollView DocumentView { get; }

		//- (NSClipView *)contentView;
		[Export ("contentView")]
		NSClipView ContentView { get; set; }

		//- (NSCursor *)documentCursor;
		[Export ("documentCursor")]
		NSCursor DocumentCursor { get; set; }

		//- (NSBorderType)borderType;
		[Export ("borderType")]
		NSBorderType BorderType { get; set; }

		//- (NSColor *)backgroundColor;
		[Export ("backgroundColor")]
		NSColor BackgroundColor { get; set; }

		//- (BOOL)drawsBackground;
		[Export ("drawsBackground")]
		bool DrawsBackground { get; set; }

		//- (BOOL)hasVerticalScroller;
		[Export ("hasVerticalScroller")]
		bool HasVerticalScroller { get; set; }

		//- (BOOL)hasHorizontalScroller;
		[Export ("hasHorizontalScroller")]
		bool HasHorizontalScroller { get; set; }

		//- (NSScroller *)verticalScroller;
		[Export ("verticalScroller")]
		NSScroller VerticalScroller { get; set; }

		//- (NSScroller *)horizontalScroller;
		[Export ("horizontalScroller")]
		NSScroller HorizontalScroller { get; set; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//- (BOOL)autohidesScrollers;
		[Export ("autohidesScrollers")]
		bool AutohidesScrollers { get; set; }

//#endif
		//- (CGFloat)horizontalLineScroll;
		[Export ("horizontalLineScroll")]
		float HorizontalLineScroll { get; set; }

		//- (CGFloat)verticalLineScroll;
		[Export ("verticalLineScroll")]
		float VerticalLineScroll { get; set; }

		//- (CGFloat)lineScroll;
		[Export ("lineScroll")]
		float LineScroll { get; set; }

		//- (CGFloat)horizontalPageScroll;
		[Export ("horizontalPageScroll")]
		float HorizontalPageScroll { get; set; }

		//- (CGFloat)verticalPageScroll;
		[Export ("verticalPageScroll")]
		float VerticalPageScroll { get; set; }

		//- (CGFloat)pageScroll;
		[Export ("pageScroll")]
		float PageScroll { get; set; }

		//- (BOOL)scrollsDynamically;
		[Export ("scrollsDynamically")]
		bool ScrollsDynamically { get; set; }

		//- (void)tile;
		[Export ("tile")]
		void Tile ();

		//- (void)reflectScrolledClipView:(NSClipView *)cView;
		[Export ("reflectScrolledClipView:")]
		void ReflectScrolledClipView (NSClipView cView);

		//- (void)scrollWheel:(NSEvent *)theEvent;
		[Export ("scrollWheel:")]
		void ScrollWheel (NSEvent theEvent);

		//+ (void)setRulerViewClass:(Class)rulerViewClass;
		[Static, Export ("setRulerViewClass:")]
		void SetRulerViewClass (Class rulerViewClass);

		//+ (Class)rulerViewClass;
		[Static, Export ("rulerViewClass")]
		Class RulerViewClass { get; }

		//- (BOOL)rulersVisible;
		[Export ("rulersVisible")]
		bool RulersVisible { get; set; }

		//- (BOOL)hasHorizontalRuler;
		[Export ("hasHorizontalRuler")]
		bool HasHorizontalRuler { get; set; }

		//- (BOOL)hasVerticalRuler;
		[Export ("hasVerticalRuler")]
		bool HasVerticalRuler { get; set; }

		//- (NSRulerView *)horizontalRulerView;
		[Export ("horizontalRulerView")]
		NSRulerView HorizontalRulerView { get; set; }

		//- (NSRulerView *)verticalRulerView;
		[Export ("verticalRulerView")]
		NSRulerView VerticalRulerView { get; set; }

	}
}
