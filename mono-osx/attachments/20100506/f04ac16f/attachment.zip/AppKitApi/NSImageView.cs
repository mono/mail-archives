using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSControl))]
	interface NSImageView {

		//- (NSImage *)image;
		[Export ("image")]
		NSImage Image { get; set; }

		//- (NSImageAlignment)imageAlignment;
		[Export ("imageAlignment")]
		NSImageAlignment ImageAlignment { get; set; }

		//- (NSImageScaling)imageScaling;
		[Export ("imageScaling")]
		NSImageScaling ImageScaling { get; set; }

		//- (NSImageFrameStyle)imageFrameStyle;
		[Export ("imageFrameStyle")]
		NSImageFrameStyle ImageFrameStyle { get; set; }

		//- (void)setEditable:(BOOL)yn;
		[Export ("setEditable:")]
		void SetEditable (bool yn);

		//- (BOOL)isEditable;
		[Export ("isEditable")]
		bool IsEditable { get; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//- (BOOL)animates;
		[Export ("animates")]
		bool Animates { get; set; }

//#endif
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (BOOL)allowsCutCopyPaste;
		[Export ("allowsCutCopyPaste")]
		bool AllowsCutCopyPaste { get; set; }

//#endif
	}
}
