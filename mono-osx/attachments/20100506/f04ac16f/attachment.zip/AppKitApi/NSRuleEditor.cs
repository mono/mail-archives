using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSControl))]
	interface NSRuleEditor {

		//- (void)setDelegate:delegate;
		[Export ("setDelegate:")]
		void SetDelegate (NSObject delegate1);

		//- (id)delegate;
		[Export ("delegate")]
		NSRuleEditor Delegate { get; }

		//- (NSString *)formattingStringsFilename;
		[Export ("formattingStringsFilename")]
		string FormattingStringsFilename { get; set; }

		//- (NSDictionary *)formattingDictionary;
		[Export ("formattingDictionary")]
		NSDictionary FormattingDictionary { get; set; }

		//- (void)reloadCriteria;
		[Export ("reloadCriteria")]
		void ReloadCriteria ();

		//- (NSRuleEditorNestingMode)nestingMode;
		[Export ("nestingMode")]
		NSRuleEditorNestingMode NestingMode { get; set; }

		//- (CGFloat)rowHeight;
		[Export ("rowHeight")]
		float RowHeight { get; set; }

		//- (void)setEditable:(BOOL)editable;
		[Export ("setEditable:")]
		void SetEditable (bool editable);

		//- (BOOL)isEditable;
		[Export ("isEditable")]
		bool IsEditable { get; }

		//- (BOOL)canRemoveAllRows;
		[Export ("canRemoveAllRows")]
		bool CanRemoveAllRows { get; set; }

		//- (NSPredicate *)predicate;
		[Export ("predicate")]
		NSPredicate Predicate { get; }

		//- (void)reloadPredicate;
		[Export ("reloadPredicate")]
		void ReloadPredicate ();

		//- (NSPredicate *)predicateForRow:(NSInteger)row;
		[Export ("predicateForRow:")]
		NSPredicate PredicateForRow (int row);

		//- (NSInteger)numberOfRows;
		[Export ("numberOfRows")]
		int NumberOfRows { get; }

		//- (NSIndexSet *)subrowIndexesForRow:(NSInteger)rowIndex;
		[Export ("subrowIndexesForRow:")]
		NSIndexSet SubrowIndexesForRow (int rowIndex);

		//- (NSArray *)criteriaForRow:(NSInteger)row;
		[Export ("criteriaForRow:")]
		NSArray CriteriaForRow (int row);

		//- (NSArray *)displayValuesForRow:(NSInteger)row;
		[Export ("displayValuesForRow:")]
		NSArray DisplayValuesForRow (int row);

		//- (NSInteger)rowForDisplayValue:(id)displayValue;
		[Export ("rowForDisplayValue:")]
		int RowForDisplayValue (NSObject displayValue);

		//- (NSRuleEditorRowType)rowTypeForRow:(NSInteger)rowIndex;
		[Export ("rowTypeForRow:")]
		NSRuleEditorRowType RowTypeForRow (int rowIndex);

		//- (NSInteger)parentRowForRow:(NSInteger)rowIndex;
		[Export ("parentRowForRow:")]
		int ParentRowForRow (int rowIndex);

		//- (void)addRow:(id)sender;
		[Export ("addRow:")]
		void AddRow (NSObject sender);

		//- (void)insertRowAtIndex:(NSInteger)rowIndex withType:(NSRuleEditorRowType)rowType asSubrowOfRow:(NSInteger)parentRow animate:(BOOL)shouldAnimate;
		[Export ("insertRowAtIndex:withType:asSubrowOfRow:animate:")]
		void InsertRowAtIndex (int rowIndex, NSRuleEditorRowType rowType, int parentRow, bool shouldAnimate);

		//- (void)setCriteria:(NSArray *)criteria andDisplayValues:(NSArray *)values forRowAtIndex:(NSInteger)rowIndex;
		[Export ("setCriteria:andDisplayValues:forRowAtIndex:")]
		void SetCriteria (NSArray criteria, NSArray values, int rowIndex);

		//- (void)removeRowAtIndex:(NSInteger)rowIndex;
		[Export ("removeRowAtIndex:")]
		void RemoveRowAtIndex (int rowIndex);

		//- (void)removeRowsAtIndexes:(NSIndexSet *)rowIndexes includeSubrows:(BOOL)includeSubrows;
		[Export ("removeRowsAtIndexes:includeSubrows:")]
		void RemoveRowsAtIndexes (NSIndexSet rowIndexes, bool includeSubrows);

		//- (NSIndexSet *)selectedRowIndexes;
		[Export ("selectedRowIndexes")]
		NSIndexSet SelectedRowIndexes { get; }

		//- (void)selectRowIndexes:(NSIndexSet *)indexes byExtendingSelection:(BOOL)extend;
		[Export ("selectRowIndexes:byExtendingSelection:")]
		void SelectRowIndexes (NSIndexSet indexes, bool extend);

		//- (Class)rowClass;
		[Export ("rowClass")]
		Class RowClass { get; set; }

		//- (NSString *)rowTypeKeyPath;
		[Export ("rowTypeKeyPath")]
		string RowTypeKeyPath { get; set; }

		//- (NSString *)subrowsKeyPath;
		[Export ("subrowsKeyPath")]
		string SubrowsKeyPath { get; set; }

		//- (NSString *)criteriaKeyPath;
		[Export ("criteriaKeyPath")]
		string CriteriaKeyPath { get; set; }

		//- (NSString *)displayValuesKeyPath;
		[Export ("displayValuesKeyPath")]
		string DisplayValuesKeyPath { get; set; }

	}
}
