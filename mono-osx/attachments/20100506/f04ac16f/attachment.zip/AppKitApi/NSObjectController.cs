using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;
using MonoMac.CoreData;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSController))]
	interface NSObjectController {

		//- (id)initWithContent:(id)content;
		[Export ("initWithContent:")]
		IntPtr Constructor (NSObject content);

		//- (void)setContent:(id)content;
		[Export ("setContent:")]
		void SetContent (NSObject content);

		//- (id)content;
		[Export ("content")]
		NSObjectController Content { get; }

		//- (id)selection;    
		[Export ("selection")]
		NSObjectController Selection { get; }

		//- (NSArray *)selectedObjects;    
		[Export ("selectedObjects")]
		NSArray SelectedObjects { get; }

		//- (BOOL)automaticallyPreparesContent;
		[Export ("automaticallyPreparesContent")]
		bool AutomaticallyPreparesContent { get; set; }

		//- (void)prepareContent;    
		[Export ("prepareContent")]
		void PrepareContent ();

		//- (Class)objectClass;
		[Export ("objectClass")]
		Class ObjectClass { get; set; }

		//- (id)newObject;    
		[Export ("newObject")]
		NSObjectController NewObject { get; }

		//- (void)addObject:(id)object;    
		[Export ("addObject:")]
		void AddObject (NSObject object1);

		//- (void)removeObject:(id)object;    
		[Export ("removeObject:")]
		void RemoveObject (NSObject object1);

		//- (void)setEditable:(BOOL)flag;    
		[Export ("setEditable:")]
		void SetEditable (bool flag);

		//- (BOOL)isEditable;
		[Export ("isEditable")]
		bool IsEditable { get; }

		//- (void)add:(id)sender;    
		[Export ("add:")]
		void Add (NSObject sender);

		//- (BOOL)canAdd;    
		[Export ("canAdd")]
		bool CanAdd { get; }

		//- (void)remove:(id)sender;    
		[Export ("remove:")]
		void Remove (NSObject sender);

		//- (BOOL)canRemove;    
		[Export ("canRemove")]
		bool CanRemove { get; }

		//- (BOOL)validateUserInterfaceItem:(id <NSValidatedUserInterfaceItem>)item;    
		[Export ("validateUserInterfaceItem:")]
		bool ValidateUserInterfaceItem (NSObject item);

		//- (NSManagedObjectContext *)managedObjectContext;
		[Export ("managedObjectContext")]
		NSManagedObjectContext ManagedObjectContext { get; set; }

		//- (NSString *)entityName;
		[Export ("entityName")]
		string EntityName { get; set; }

		//- (NSPredicate *)fetchPredicate;
		[Export ("fetchPredicate")]
		NSPredicate FetchPredicate { get; set; }

		//- (BOOL)fetchWithRequest:(NSFetchRequest *)fetchRequest merge:(BOOL)merge error:(NSError **)error;    
		[Export ("fetchWithRequest:merge:error:")]
		bool FetchWithRequestMerge (NSFetchRequest fetchRequest, bool merge, NSError error);

		//- (void)fetch:(id)sender;
		[Export ("fetch:")]
		void Fetch (NSObject sender);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (BOOL)usesLazyFetching; 
		[Export ("usesLazyFetching")]
		bool UsesLazyFetching { get; set; }

		//- (NSFetchRequest *)defaultFetchRequest;
		[Export ("defaultFetchRequest")]
		NSFetchRequest DefaultFetchRequest { get; }

//#endif
	}
}
