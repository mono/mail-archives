using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSObject))]
	interface NSFont {

		//+ (NSFont *)fontWithName:(NSString *)fontName size:(CGFloat)fontSize;
		[Static, Export ("fontWithName:size:")]
		NSFont FontWithName (string fontName, float fontSize);

		////+ (NSFont *)fontWithName:(NSString *)fontName matrix:(const CGFloat *)fontMatrix;
		//[Static, Export ("fontWithName:matrix:")]
		//NSFont FontWithName (string fontName, const CGFloat fontMatrix);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//+ (NSFont *)fontWithDescriptor:(NSFontDescriptor *)fontDescriptor size:(CGFloat)fontSize;
		[Static, Export ("fontWithDescriptor:size:")]
		NSFont FontWithDescriptor (NSFontDescriptor fontDescriptor, float fontSize);

		//+ (NSFont *)fontWithDescriptor:(NSFontDescriptor *)fontDescriptor textTransform:(NSAffineTransform *)textTransform;
		[Static, Export ("fontWithDescriptor:textTransform:")]
		NSFont FontWithDescriptor (NSFontDescriptor fontDescriptor, NSAffineTransform textTransform);

//#endif 
		//+ (NSFont *)userFontOfSize:(CGFloat)fontSize;	
		[Static, Export ("userFontOfSize:")]
		NSFont UserFontOfSize (float fontSize);

		//+ (NSFont *)userFixedPitchFontOfSize:(CGFloat)fontSize; 
		[Static, Export ("userFixedPitchFontOfSize:")]
		NSFont UserFixedPitchFontOfSize (float fontSize);

		//+ (void)setUserFont:(NSFont *)aFont;	
		[Static, Export ("setUserFont:")]
		void SetUserFont (NSFont aFont);

		//+ (void)setUserFixedPitchFont:(NSFont *)aFont; 
		[Static, Export ("setUserFixedPitchFont:")]
		void SetUserFixedPitchFont (NSFont aFont);

		//+ (NSFont *)systemFontOfSize:(CGFloat)fontSize;	
		[Static, Export ("systemFontOfSize:")]
		NSFont SystemFontOfSize (float fontSize);

		//+ (NSFont *)boldSystemFontOfSize:(CGFloat)fontSize; 
		[Static, Export ("boldSystemFontOfSize:")]
		NSFont BoldSystemFontOfSize (float fontSize);

		//+ (NSFont *)labelFontOfSize:(CGFloat)fontSize; 
		[Static, Export ("labelFontOfSize:")]
		NSFont LabelFontOfSize (float fontSize);

		//+ (NSFont *)titleBarFontOfSize:(CGFloat)fontSize;
		[Static, Export ("titleBarFontOfSize:")]
		NSFont TitleBarFontOfSize (float fontSize);

		//+ (NSFont *)menuFontOfSize:(CGFloat)fontSize;
		[Static, Export ("menuFontOfSize:")]
		NSFont MenuFontOfSize (float fontSize);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//+ (NSFont *)menuBarFontOfSize:(CGFloat)fontSize;
		[Static, Export ("menuBarFontOfSize:")]
		NSFont MenuBarFontOfSize (float fontSize);

//#endif 
		//+ (NSFont *)messageFontOfSize:(CGFloat)fontSize;
		[Static, Export ("messageFontOfSize:")]
		NSFont MessageFontOfSize (float fontSize);

		//+ (NSFont *)paletteFontOfSize:(CGFloat)fontSize;
		[Static, Export ("paletteFontOfSize:")]
		NSFont PaletteFontOfSize (float fontSize);

		//+ (NSFont *)toolTipsFontOfSize:(CGFloat)fontSize;
		[Static, Export ("toolTipsFontOfSize:")]
		NSFont ToolTipsFontOfSize (float fontSize);

		//+ (NSFont *)controlContentFontOfSize:(CGFloat)fontSize;
		[Static, Export ("controlContentFontOfSize:")]
		NSFont ControlContentFontOfSize (float fontSize);

		//+ (CGFloat)systemFontSize; 
		[Static, Export ("systemFontSize")]
		float SystemFontSize { get; }

		//+ (CGFloat)smallSystemFontSize; 
		[Static, Export ("smallSystemFontSize")]
		float SmallSystemFontSize { get; }

		//+ (CGFloat)labelFontSize;	
		[Static, Export ("labelFontSize")]
		float LabelFontSize { get; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//+ (CGFloat)systemFontSizeForControlSize:(NSControlSize)controlSize;
		[Static, Export ("systemFontSizeForControlSize:")]
		float SystemFontSizeForControlSize (NSControlSize controlSize);

//#endif 
		//- (NSString *)fontName;
		[Export ("fontName")]
		string FontName { get; }

		//- (CGFloat)pointSize;
		[Export ("pointSize")]
		float PointSize { get; }

		////- (const CGFloat *)matrix;
		//[Export ("matrix")]
		//const CGFloat Matrix { get; }

		//- (NSString *)familyName;
		[Export ("familyName")]
		string FamilyName { get; }

		//- (NSString *)displayName;
		[Export ("displayName")]
		string DisplayName { get; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//- (NSFontDescriptor *)fontDescriptor;
		[Export ("fontDescriptor")]
		NSFontDescriptor FontDescriptor { get; }

//#endif 
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (NSAffineTransform *)textTransform;
		[Export ("textTransform")]
		NSAffineTransform TextTransform { get; }

//#endif 
		//- (NSUInteger)numberOfGlyphs;
		[Export ("numberOfGlyphs")]
		uint NumberOfGlyphs { get; }

		//- (NSStringEncoding)mostCompatibleStringEncoding;
		[Export ("mostCompatibleStringEncoding")]
		NSStringEncoding MostCompatibleStringEncoding { get; }

		//- (NSGlyph)glyphWithName:(NSString *)aName;
		[Export ("glyphWithName:")]
		uint GlyphWithName (string aName);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_2
		//- (NSCharacterSet *)coveredCharacterSet;
		[Export ("coveredCharacterSet")]
		NSCharacterSet CoveredCharacterSet { get; }

//#endif 
		//- (NSRect)boundingRectForFont;
		[Export ("boundingRectForFont")]
		RectangleF BoundingRectForFont { get; }

		//- (NSSize)maximumAdvancement;
		[Export ("maximumAdvancement")]
		NSSize MaximumAdvancement { get; }

		//- (CGFloat)ascender;
		[Export ("ascender")]
		float Ascender { get; }

		//- (CGFloat)descender;
		[Export ("descender")]
		float Descender { get; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (CGFloat)leading;
		[Export ("leading")]
		float Leading { get; }

//#endif 
		//- (CGFloat)underlinePosition;
		[Export ("underlinePosition")]
		float UnderlinePosition { get; }

		//- (CGFloat)underlineThickness;
		[Export ("underlineThickness")]
		float UnderlineThickness { get; }

		//- (CGFloat)italicAngle;
		[Export ("italicAngle")]
		float ItalicAngle { get; }

		//- (CGFloat)capHeight;
		[Export ("capHeight")]
		float CapHeight { get; }

		//- (CGFloat)xHeight;
		[Export ("xHeight")]
		float XHeight { get; }

		//- (BOOL)isFixedPitch;
		[Export ("isFixedPitch")]
		bool IsFixedPitch { get; }

		//- (NSRect)boundingRectForGlyph:(NSGlyph)aGlyph;
		[Export ("boundingRectForGlyph:")]
		RectangleF BoundingRectForGlyph (uint aGlyph);

		//- (NSSize)advancementForGlyph:(NSGlyph)ag;
		[Export ("advancementForGlyph:")]
		NSSize AdvancementForGlyph (uint ag);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		////- (void)getBoundingRects:(NSRectArray)bounds forGlyphs:(const NSGlyph *)glyphs count:(NSUInteger)glyphCount;
		//[Export ("getBoundingRects:forGlyphs:count:")]
		//void GetBoundingRects (NSRectArray bounds, const NSGlyph glyphs, uint glyphCount);

		////- (void)getAdvancements:(NSSizeArray)advancements forGlyphs:(const NSGlyph *)glyphs count:(NSUInteger)glyphCount;
		//[Export ("getAdvancements:forGlyphs:count:")]
		//void GetAdvancements (NSSizeArray advancements, const NSGlyph glyphs, uint glyphCount);

		////- (void)getAdvancements:(NSSizeArray)advancements forPackedGlyphs:(const void *)packedGlyphs length:(NSUInteger)length; 
		//[Export ("getAdvancements:forPackedGlyphs:length:")]
		//void GetAdvancements (NSSizeArray advancements, const void packedGlyphs, uint length);

//#endif 
		//- (void)set;
		[Export ("set")]
		void Set ();

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (void)setInContext:(NSGraphicsContext *)graphicsContext;
		[Export ("setInContext:")]
		void SetInContext (NSGraphicsContext graphicsContext);

//#endif 
		//- (NSFont *)printerFont;
		[Export ("printerFont")]
		NSFont PrinterFont { get; }

		//- (NSFont *)screenFont; 
		[Export ("screenFont")]
		NSFont ScreenFont { get; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (NSFont *)screenFontWithRenderingMode:(NSFontRenderingMode)renderingMode;
		[Export ("screenFontWithRenderingMode:")]
		NSFont ScreenFontWithRenderingMode (NSFontRenderingMode renderingMode);

		//- (NSFontRenderingMode)renderingMode;
		[Export ("renderingMode")]
		NSFontRenderingMode RenderingMode { get; }

//#endif 
		////- (CGFloat)widthOfString:(NSString *)string DEPRECATED_IN_MAC_OS_X_VERSION_10_4_AND_LATER; 
		//[Export ("widthOfString:")]
		//float WidthOfString (string string1);

		////- (BOOL)isBaseFont DEPRECATED_IN_MAC_OS_X_VERSION_10_4_AND_LATER;
		//[Export ("isBaseFont")]
		//bool IsBaseFont { get; }

		////- (NSDictionary *)afmDictionary DEPRECATED_IN_MAC_OS_X_VERSION_10_4_AND_LATER;
		//[Export ("afmDictionary")]
		//NSDictionary AfmDictionary { get; }

		////- (BOOL)glyphIsEncoded:(NSGlyph)aGlyph DEPRECATED_IN_MAC_OS_X_VERSION_10_4_AND_LATER; 
		//[Export ("glyphIsEncoded:")]
		//bool GlyphIsEncoded (uint aGlyph);

		////- (CGFloat)defaultLineHeightForFont DEPRECATED_IN_MAC_OS_X_VERSION_10_4_AND_LATER; 
		//[Export ("defaultLineHeightForFont")]
		//float DefaultLineHeightForFont { get; }

		////+ (NSArray *)preferredFontNames DEPRECATED_IN_MAC_OS_X_VERSION_10_4_AND_LATER; 
		//[Static, Export ("preferredFontNames")]
		//NSArray PreferredFontNames { get; }

		////+ (void)setPreferredFontNames:(NSArray *)fontNameArray DEPRECATED_IN_MAC_OS_X_VERSION_10_4_AND_LATER;
		//[Static, Export ("setPreferredFontNames:")]
		//void SetPreferredFontNames (NSArray fontNameArray);

		////- (NSString *)encodingScheme DEPRECATED_IN_MAC_OS_X_VERSION_10_4_AND_LATER;
		//[Export ("encodingScheme")]
		//string EncodingScheme { get; }

		////- (NSMultibyteGlyphPacking) glyphPacking DEPRECATED_IN_MAC_OS_X_VERSION_10_4_AND_LATER;
		//[Export ("glyphPacking")]
		//NSMultibyteGlyphPacking GlyphPacking { get; }

		////- (NSPoint)positionOfGlyph:(NSGlyph)curGlyph precededByGlyph:(NSGlyph)prevGlyph isNominal:(BOOL *)nominal DEPRECATED_IN_MAC_OS_X_VERSION_10_4_AND_LATER;
		//[Export ("positionOfGlyph:precededByGlyph:isNominal:")]
		//PointF PositionOfGlyphPrecededByGlyph (uint curGlyph, uint prevGlyph, bool nominal);

		////- (NSInteger)positionsForCompositeSequence:(NSGlyph *)someGlyphs numberOfGlyphs:(NSInteger)numGlyphs pointArray:(NSPointArray)points DEPRECATED_IN_MAC_OS_X_VERSION_10_4_AND_LATER;
		//[Export ("positionsForCompositeSequence:numberOfGlyphs:pointArray:")]
		//int PositionsForCompositeSequenceNumberOfGlyphs (uint someGlyphs, int numGlyphs, NSPointArray points);

		////- (NSPoint)positionOfGlyph:(NSGlyph)curGlyph struckOverGlyph:(NSGlyph)prevGlyph metricsExist:(BOOL *)exist DEPRECATED_IN_MAC_OS_X_VERSION_10_4_AND_LATER;
		//[Export ("positionOfGlyph:struckOverGlyph:metricsExist:")]
		//PointF PositionOfGlyphStruckOverGlyph (uint curGlyph, uint prevGlyph, bool exist);

		////- (NSPoint)positionOfGlyph:(NSGlyph)aGlyph struckOverRect:(NSRect)aRect metricsExist:(BOOL *)exist DEPRECATED_IN_MAC_OS_X_VERSION_10_4_AND_LATER;
		//[Export ("positionOfGlyph:struckOverRect:metricsExist:")]
		//PointF PositionOfGlyphStruckOverRect (uint aGlyph, RectangleF aRect, bool exist);

		////- (NSPoint)positionOfGlyph:(NSGlyph)aGlyph forCharacter:(unichar)aChar struckOverRect:(NSRect)aRect DEPRECATED_IN_MAC_OS_X_VERSION_10_4_AND_LATER;
		//[Export ("positionOfGlyph:forCharacter:struckOverRect:")]
		//PointF PositionOfGlyphForCharacter (uint aGlyph, unichar aChar, RectangleF aRect);

		////- (NSPoint)positionOfGlyph:(NSGlyph)thisGlyph withRelation:(NSGlyphRelation)rel toBaseGlyph:(NSGlyph)baseGlyph totalAdvancement:(NSSizePointer)adv metricsExist:(BOOL *)exist DEPRECATED_IN_MAC_OS_X_VERSION_10_4_AND_LATER;
		//[Export ("positionOfGlyph:withRelation:toBaseGlyph:totalAdvancement:metricsExist:")]
		//PointF PositionOfGlyphWithRelation (uint thisGlyph, NSGlyphRelation rel, uint baseGlyph, NSSizePointer adv, bool exist);

	}
}
