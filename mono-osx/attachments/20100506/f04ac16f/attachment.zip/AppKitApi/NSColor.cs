using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSObject))]
	interface NSColor {

		//+ (NSColor *)colorWithCalibratedWhite:(CGFloat)white alpha:(CGFloat)alpha;
		[Static, Export ("colorWithCalibratedWhite:alpha:")]
		NSColor ColorWithCalibratedWhite (float white, float alpha);

		//+ (NSColor *)colorWithCalibratedHue:(CGFloat)hue saturation:(CGFloat)saturation brightness:(CGFloat)brightness alpha:(CGFloat)alpha;
		[Static, Export ("colorWithCalibratedHue:saturation:brightness:alpha:")]
		NSColor ColorWithCalibratedHue (float hue, float saturation, float brightness, float alpha);

		//+ (NSColor *)colorWithCalibratedRed:(CGFloat)red green:(CGFloat)green blue:(CGFloat)blue alpha:(CGFloat)alpha;
		[Static, Export ("colorWithCalibratedRed:green:blue:alpha:")]
		NSColor ColorWithCalibratedRed (float red, float green, float blue, float alpha);

		//+ (NSColor *)colorWithDeviceWhite:(CGFloat)white alpha:(CGFloat)alpha;
		[Static, Export ("colorWithDeviceWhite:alpha:")]
		NSColor ColorWithDeviceWhite (float white, float alpha);

		//+ (NSColor *)colorWithDeviceHue:(CGFloat)hue saturation:(CGFloat)saturation brightness:(CGFloat)brightness alpha:(CGFloat)alpha;
		[Static, Export ("colorWithDeviceHue:saturation:brightness:alpha:")]
		NSColor ColorWithDeviceHue (float hue, float saturation, float brightness, float alpha);

		//+ (NSColor *)colorWithDeviceRed:(CGFloat)red green:(CGFloat)green blue:(CGFloat)blue alpha:(CGFloat)alpha;
		[Static, Export ("colorWithDeviceRed:green:blue:alpha:")]
		NSColor ColorWithDeviceRed (float red, float green, float blue, float alpha);

		//+ (NSColor *)colorWithDeviceCyan:(CGFloat)cyan magenta:(CGFloat)magenta yellow:(CGFloat)yellow black:(CGFloat)black alpha:(CGFloat)alpha;
		[Static, Export ("colorWithDeviceCyan:magenta:yellow:black:alpha:")]
		NSColor ColorWithDeviceCyan (float cyan, float magenta, float yellow, float black, float alpha);

		//+ (NSColor *)colorWithCatalogName:(NSString *)listName colorName:(NSString *)colorName;
		[Static, Export ("colorWithCatalogName:colorName:")]
		NSColor ColorWithCatalogName (string listName, string colorName);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		////+ (NSColor *)colorWithColorSpace:(NSColorSpace *)space components:(const CGFloat *)components count:(NSInteger)numberOfComponents;
		//[Static, Export ("colorWithColorSpace:components:count:")]
		//NSColor ColorWithColorSpace (NSColorSpace space, const CGFloat components, int numberOfComponents);

//#endif
		//+ (NSColor *)blackColor;	
		[Static, Export ("blackColor")]
		NSColor BlackColor { get; }

		//+ (NSColor *)darkGrayColor;	
		[Static, Export ("darkGrayColor")]
		NSColor DarkGrayColor { get; }

		//+ (NSColor *)lightGrayColor;	
		[Static, Export ("lightGrayColor")]
		NSColor LightGrayColor { get; }

		//+ (NSColor *)whiteColor;	
		[Static, Export ("whiteColor")]
		NSColor WhiteColor { get; }

		//+ (NSColor *)grayColor;		
		[Static, Export ("grayColor")]
		NSColor GrayColor { get; }

		//+ (NSColor *)redColor;		
		[Static, Export ("redColor")]
		NSColor RedColor { get; }

		//+ (NSColor *)greenColor;	
		[Static, Export ("greenColor")]
		NSColor GreenColor { get; }

		//+ (NSColor *)blueColor;		
		[Static, Export ("blueColor")]
		NSColor BlueColor { get; }

		//+ (NSColor *)cyanColor;		
		[Static, Export ("cyanColor")]
		NSColor CyanColor { get; }

		//+ (NSColor *)yellowColor;	
		[Static, Export ("yellowColor")]
		NSColor YellowColor { get; }

		//+ (NSColor *)magentaColor;	
		[Static, Export ("magentaColor")]
		NSColor MagentaColor { get; }

		//+ (NSColor *)orangeColor;	
		[Static, Export ("orangeColor")]
		NSColor OrangeColor { get; }

		//+ (NSColor *)purpleColor;	
		[Static, Export ("purpleColor")]
		NSColor PurpleColor { get; }

		//+ (NSColor *)brownColor;	
		[Static, Export ("brownColor")]
		NSColor BrownColor { get; }

		//+ (NSColor *)clearColor;	
		[Static, Export ("clearColor")]
		NSColor ClearColor { get; }

		//+ (NSColor *)controlShadowColor;		
		[Static, Export ("controlShadowColor")]
		NSColor ControlShadowColor { get; }

		//+ (NSColor *)controlDarkShadowColor;		
		[Static, Export ("controlDarkShadowColor")]
		NSColor ControlDarkShadowColor { get; }

		//+ (NSColor *)controlColor;			
		[Static, Export ("controlColor")]
		NSColor ControlColor { get; }

		//+ (NSColor *)controlHighlightColor;		
		[Static, Export ("controlHighlightColor")]
		NSColor ControlHighlightColor { get; }

		//+ (NSColor *)controlLightHighlightColor;	
		[Static, Export ("controlLightHighlightColor")]
		NSColor ControlLightHighlightColor { get; }

		//+ (NSColor *)controlTextColor;			
		[Static, Export ("controlTextColor")]
		NSColor ControlTextColor { get; }

		//+ (NSColor *)controlBackgroundColor;		
		[Static, Export ("controlBackgroundColor")]
		NSColor ControlBackgroundColor { get; }

		//+ (NSColor *)selectedControlColor;		
		[Static, Export ("selectedControlColor")]
		NSColor SelectedControlColor { get; }

		//+ (NSColor *)secondarySelectedControlColor;	
		[Static, Export ("secondarySelectedControlColor")]
		NSColor SecondarySelectedControlColor { get; }

		//+ (NSColor *)selectedControlTextColor;		
		[Static, Export ("selectedControlTextColor")]
		NSColor SelectedControlTextColor { get; }

		//+ (NSColor *)disabledControlTextColor;		
		[Static, Export ("disabledControlTextColor")]
		NSColor DisabledControlTextColor { get; }

		//+ (NSColor *)textColor;				
		[Static, Export ("textColor")]
		NSColor TextColor { get; }

		//+ (NSColor *)textBackgroundColor;		
		[Static, Export ("textBackgroundColor")]
		NSColor TextBackgroundColor { get; }

		//+ (NSColor *)selectedTextColor;			
		[Static, Export ("selectedTextColor")]
		NSColor SelectedTextColor { get; }

		//+ (NSColor *)selectedTextBackgroundColor;	
		[Static, Export ("selectedTextBackgroundColor")]
		NSColor SelectedTextBackgroundColor { get; }

		//+ (NSColor *)gridColor;				
		[Static, Export ("gridColor")]
		NSColor GridColor { get; }

		//+ (NSColor *)keyboardFocusIndicatorColor;	
		[Static, Export ("keyboardFocusIndicatorColor")]
		NSColor KeyboardFocusIndicatorColor { get; }

		//+ (NSColor *)windowBackgroundColor;		
		[Static, Export ("windowBackgroundColor")]
		NSColor WindowBackgroundColor { get; }

		//+ (NSColor *)scrollBarColor;			
		[Static, Export ("scrollBarColor")]
		NSColor ScrollBarColor { get; }

		//+ (NSColor *)knobColor;     			
		[Static, Export ("knobColor")]
		NSColor KnobColor { get; }

		//+ (NSColor *)selectedKnobColor;       		
		[Static, Export ("selectedKnobColor")]
		NSColor SelectedKnobColor { get; }

		//+ (NSColor *)windowFrameColor;			
		[Static, Export ("windowFrameColor")]
		NSColor WindowFrameColor { get; }

		//+ (NSColor *)windowFrameTextColor;		
		[Static, Export ("windowFrameTextColor")]
		NSColor WindowFrameTextColor { get; }

		//+ (NSColor *)selectedMenuItemColor;		
		[Static, Export ("selectedMenuItemColor")]
		NSColor SelectedMenuItemColor { get; }

		//+ (NSColor *)selectedMenuItemTextColor;		
		[Static, Export ("selectedMenuItemTextColor")]
		NSColor SelectedMenuItemTextColor { get; }

		//+ (NSColor *)highlightColor;     	     	
		[Static, Export ("highlightColor")]
		NSColor HighlightColor { get; }

		//+ (NSColor *)shadowColor;     			
		[Static, Export ("shadowColor")]
		NSColor ShadowColor { get; }

		//+ (NSColor *)headerColor;			
		[Static, Export ("headerColor")]
		NSColor HeaderColor { get; }

		//+ (NSColor *)headerTextColor;			
		[Static, Export ("headerTextColor")]
		NSColor HeaderTextColor { get; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_2
		//+ (NSColor *)alternateSelectedControlColor;	
		[Static, Export ("alternateSelectedControlColor")]
		NSColor AlternateSelectedControlColor { get; }

		//+ (NSColor *)alternateSelectedControlTextColor;		
		[Static, Export ("alternateSelectedControlTextColor")]
		NSColor AlternateSelectedControlTextColor { get; }

//#endif
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//+ (NSArray *)controlAlternatingRowBackgroundColors;	
		[Static, Export ("controlAlternatingRowBackgroundColors")]
		NSArray ControlAlternatingRowBackgroundColors { get; }

//#endif
		//- (NSColor *)highlightWithLevel:(CGFloat)val;	
		[Export ("highlightWithLevel:")]
		NSColor HighlightWithLevel (float val);

		//- (NSColor *)shadowWithLevel:(CGFloat)val;	
		[Export ("shadowWithLevel:")]
		NSColor ShadowWithLevel (float val);

		//+ (NSColor *)colorForControlTint:(NSControlTint)controlTint;	
		[Static, Export ("colorForControlTint:")]
		NSColor ColorForControlTint (NSControlTint controlTint);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//+ (NSControlTint) currentControlTint;	
		[Static, Export ("currentControlTint")]
		NSControlTint CurrentControlTint { get; }

//#endif
		//- (void)set;
		[Export ("set")]
		void Set ();

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//- (void)setFill;
		[Export ("setFill")]
		void SetFill ();

		//- (void)setStroke;
		[Export ("setStroke")]
		void SetStroke ();

//#endif
		//- (NSString *)colorSpaceName;
		[Export ("colorSpaceName")]
		string ColorSpaceName { get; }

		// - (NSColor *)colorUsingColorSpaceName:(NSString *)colorSpace;
		[Export ("colorUsingColorSpaceName:")]
		NSColor ColorUsingColorSpaceName (string colorSpace);

		//- (NSColor *)colorUsingColorSpaceName:(NSString *)colorSpace device:(NSDictionary *)deviceDescription;
		[Export ("colorUsingColorSpaceName:device:")]
		NSColor ColorUsingColorSpaceName (string colorSpace, NSDictionary deviceDescription);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (NSColor *)colorUsingColorSpace:(NSColorSpace *)space;
		[Export ("colorUsingColorSpace:")]
		NSColor ColorUsingColorSpace (NSColorSpace space);

//#endif
		//- (NSColor *)blendedColorWithFraction:(CGFloat)fraction ofColor:(NSColor *)color;
		[Export ("blendedColorWithFraction:ofColor:")]
		NSColor BlendedColorWithFraction (float fraction, NSColor color);

		//- (NSColor *)colorWithAlphaComponent:(CGFloat)alpha;
		[Export ("colorWithAlphaComponent:")]
		NSColor ColorWithAlphaComponent (float alpha);

		//- (NSString *)catalogNameComponent;
		[Export ("catalogNameComponent")]
		string CatalogNameComponent { get; }

		//- (NSString *)colorNameComponent;
		[Export ("colorNameComponent")]
		string ColorNameComponent { get; }

		//- (NSString *)localizedCatalogNameComponent;
		[Export ("localizedCatalogNameComponent")]
		string LocalizedCatalogNameComponent { get; }

		//- (NSString *)localizedColorNameComponent;
		[Export ("localizedColorNameComponent")]
		string LocalizedColorNameComponent { get; }

		//- (CGFloat)redComponent;
		[Export ("redComponent")]
		float RedComponent { get; }

		//- (CGFloat)greenComponent;
		[Export ("greenComponent")]
		float GreenComponent { get; }

		//- (CGFloat)blueComponent;
		[Export ("blueComponent")]
		float BlueComponent { get; }

		//- (void)getRed:(CGFloat *)red green:(CGFloat *)green blue:(CGFloat *)blue alpha:(CGFloat *)alpha;
		[Export ("getRed:green:blue:alpha:")]
		void GetRed (float red, float green, float blue, float alpha);

		//- (CGFloat)hueComponent;
		[Export ("hueComponent")]
		float HueComponent { get; }

		//- (CGFloat)saturationComponent;
		[Export ("saturationComponent")]
		float SaturationComponent { get; }

		//- (CGFloat)brightnessComponent;
		[Export ("brightnessComponent")]
		float BrightnessComponent { get; }

		//- (void)getHue:(CGFloat *)hue saturation:(CGFloat *)saturation brightness:(CGFloat *)brightness alpha:(CGFloat *)alpha;
		[Export ("getHue:saturation:brightness:alpha:")]
		void GetHue (float hue, float saturation, float brightness, float alpha);

		//- (CGFloat)whiteComponent;
		[Export ("whiteComponent")]
		float WhiteComponent { get; }

		//- (void)getWhite:(CGFloat *)white alpha:(CGFloat *)alpha;
		[Export ("getWhite:alpha:")]
		void GetWhite (float white, float alpha);

		//- (CGFloat)cyanComponent;
		[Export ("cyanComponent")]
		float CyanComponent { get; }

		//- (CGFloat)magentaComponent;
		[Export ("magentaComponent")]
		float MagentaComponent { get; }

		//- (CGFloat)yellowComponent;
		[Export ("yellowComponent")]
		float YellowComponent { get; }

		//- (CGFloat)blackComponent;
		[Export ("blackComponent")]
		float BlackComponent { get; }

		//- (void)getCyan:(CGFloat *)cyan magenta:(CGFloat *)magenta yellow:(CGFloat *)yellow black:(CGFloat *)black alpha:(CGFloat *)alpha;
		[Export ("getCyan:magenta:yellow:black:alpha:")]
		void GetCyan (float cyan, float magenta, float yellow, float black, float alpha);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (NSColorSpace *)colorSpace;
		[Export ("colorSpace")]
		NSColorSpace ColorSpace { get; }

		//- (NSInteger)numberOfComponents;
		[Export ("numberOfComponents")]
		int NumberOfComponents { get; }

		//- (void)getComponents:(CGFloat *)components;
		[Export ("getComponents:")]
		void GetComponents (float components);

//#endif
		//- (CGFloat)alphaComponent;
		[Export ("alphaComponent")]
		float AlphaComponent { get; }

		//+ (NSColor *)colorFromPasteboard:(NSPasteboard *)pasteBoard;
		[Static, Export ("colorFromPasteboard:")]
		NSColor ColorFromPasteboard (NSPasteboard pasteBoard);

		//- (void)writeToPasteboard:(NSPasteboard *)pasteBoard;
		[Export ("writeToPasteboard:")]
		void WriteToPasteboard (NSPasteboard pasteBoard);

		//+ (NSColor *)colorWithPatternImage:(NSImage*)image;
		[Static, Export ("colorWithPatternImage:")]
		NSColor ColorWithPatternImage (NSImage image);

		//- (NSImage *)patternImage; 
		[Export ("patternImage")]
		NSImage PatternImage { get; }

		//- (void)drawSwatchInRect:(NSRect)rect;
		[Export ("drawSwatchInRect:")]
		void DrawSwatchInRect (RectangleF rect);

		//+ (void)setIgnoresAlpha:(BOOL)flag;
		[Static, Export ("setIgnoresAlpha:")]
		void SetIgnoresAlpha (bool flag);

		//+ (BOOL)ignoresAlpha;
		[Static, Export ("ignoresAlpha")]
		bool IgnoresAlpha { get; }

	}
}
