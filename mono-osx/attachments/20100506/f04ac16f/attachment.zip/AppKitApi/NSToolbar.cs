using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSObject))]
	interface NSToolbar {

		//- (id)initWithIdentifier:(NSString *)identifier;
		[Export ("initWithIdentifier:")]
		IntPtr Constructor (string identifier);

		//    - (void)insertItemWithItemIdentifier:(NSString *)itemIdentifier atIndex:(NSInteger)index;
		[Export ("insertItemWithItemIdentifier:atIndex:")]
		void InsertItemWithItemIdentifier (string itemIdentifier, int index);

		//- (void)removeItemAtIndex:(NSInteger)index;
		[Export ("removeItemAtIndex:")]
		void RemoveItemAtIndex (int index);

		//    - (void)setDelegate:(id)delegate;
		[Export ("setDelegate:")]
		void SetDelegate (NSObject delegate1);

		//- (id)delegate;
		[Export ("delegate")]
		NSToolbar Delegate { get; }

		//    - (void)setVisible:(BOOL)shown;
		[Export ("setVisible:")]
		void SetVisible (bool shown);

		//- (BOOL)isVisible;
		[Export ("isVisible")]
		bool IsVisible { get; }

		//    - (void)runCustomizationPalette:(id)sender;
		[Export ("runCustomizationPalette:")]
		void RunCustomizationPalette (NSObject sender);

		//- (BOOL)customizationPaletteIsRunning;
		[Export ("customizationPaletteIsRunning")]
		bool CustomizationPaletteIsRunning { get; }

		//- (NSToolbarDisplayMode)displayMode;
		[Export ("displayMode")]
		NSToolbarDisplayMode DisplayMode { get; set; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//- (NSString *)selectedItemIdentifier;
		[Export ("selectedItemIdentifier")]
		string SelectedItemIdentifier { get; set; }

//#endif
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_2
		//- (NSToolbarSizeMode)sizeMode;
		[Export ("sizeMode")]
		NSToolbarSizeMode SizeMode { get; set; }

//#endif
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (BOOL)showsBaselineSeparator;
		[Export ("showsBaselineSeparator")]
		bool ShowsBaselineSeparator { get; set; }

//#endif
		//- (BOOL)allowsUserCustomization;
		[Export ("allowsUserCustomization")]
		bool AllowsUserCustomization { get; set; }

		//           - (NSString *)identifier;
		[Export ("identifier")]
		string Identifier { get; }

		//    - (NSArray *)items;
		[Export ("items")]
		NSArray Items { get; }

		//    - (NSArray *)visibleItems;
		[Export ("visibleItems")]
		NSArray VisibleItems { get; }

		//- (BOOL)autosavesConfiguration;
		[Export ("autosavesConfiguration")]
		bool AutosavesConfiguration { get; set; }

		//    - (void)setConfigurationFromDictionary:(NSDictionary *)configDict;
		[Export ("setConfigurationFromDictionary:")]
		void SetConfigurationFromDictionary (NSDictionary configDict);

		//- (NSDictionary *)configurationDictionary;
		[Export ("configurationDictionary")]
		NSDictionary ConfigurationDictionary { get; }

		//    - (void)validateVisibleItems;
		[Export ("validateVisibleItems")]
		void ValidateVisibleItems ();

	}
}
