using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSObjectController))]
	interface NSTreeController {

		//- (void)rearrangeObjects; 
		[Export ("rearrangeObjects")]
		void RearrangeObjects ();

		//- (id)arrangedObjects; 
		[Export ("arrangedObjects")]
		NSTreeController ArrangedObjects { get; }

		//- (NSString *)childrenKeyPath;
		[Export ("childrenKeyPath")]
		string ChildrenKeyPath { get; set; }

		//- (NSString *)countKeyPath;
		[Export ("countKeyPath")]
		string CountKeyPath { get; set; }

		//- (NSString *)leafKeyPath;
		[Export ("leafKeyPath")]
		string LeafKeyPath { get; set; }

		//- (NSArray *)sortDescriptors;
		[Export ("sortDescriptors")]
		NSArray SortDescriptors { get; set; }

		//- (id)content;
		[Export ("content")]
		NSTreeController Content { get; }

		//- (void)setContent:(id)content;
		[Export ("setContent:")]
		void SetContent (NSObject content);

		//- (void)add:(id)sender;    
		[Export ("add:")]
		void Add (NSObject sender);

		//- (void)remove:(id)sender; 	
		[Export ("remove:")]
		void Remove (NSObject sender);

		//- (void)addChild:(id)sender;    
		[Export ("addChild:")]
		void AddChild (NSObject sender);

		//- (void)insert:(id)sender;    
		[Export ("insert:")]
		void Insert (NSObject sender);

		//- (void)insertChild:(id)sender;    
		[Export ("insertChild:")]
		void InsertChild (NSObject sender);

		//- (BOOL)canInsert;
		[Export ("canInsert")]
		bool CanInsert { get; }

		//- (BOOL)canInsertChild;
		[Export ("canInsertChild")]
		bool CanInsertChild { get; }

		//- (BOOL)canAddChild;
		[Export ("canAddChild")]
		bool CanAddChild { get; }

		//- (void)insertObject:(id)object atArrangedObjectIndexPath:(NSIndexPath *)indexPath;
		[Export ("insertObject:atArrangedObjectIndexPath:")]
		void InsertObject (NSObject object1, NSIndexPath indexPath);

		//- (void)insertObjects:(NSArray *)objects atArrangedObjectIndexPaths:(NSArray *)indexPaths;
		[Export ("insertObjects:atArrangedObjectIndexPaths:")]
		void InsertObjects (NSArray objects, NSArray indexPaths);

		//- (void)removeObjectAtArrangedObjectIndexPath:(NSIndexPath *)indexPath;
		[Export ("removeObjectAtArrangedObjectIndexPath:")]
		void RemoveObjectAtArrangedObjectIndexPath (NSIndexPath indexPath);

		//- (void)removeObjectsAtArrangedObjectIndexPaths:(NSArray *)indexPaths;
		[Export ("removeObjectsAtArrangedObjectIndexPaths:")]
		void RemoveObjectsAtArrangedObjectIndexPaths (NSArray indexPaths);

		//- (BOOL)avoidsEmptySelection;
		[Export ("avoidsEmptySelection")]
		bool AvoidsEmptySelection { get; set; }

		//- (BOOL)preservesSelection;
		[Export ("preservesSelection")]
		bool PreservesSelection { get; set; }

		//- (BOOL)selectsInsertedObjects;
		[Export ("selectsInsertedObjects")]
		bool SelectsInsertedObjects { get; set; }

		//- (BOOL)alwaysUsesMultipleValuesMarker;
		[Export ("alwaysUsesMultipleValuesMarker")]
		bool AlwaysUsesMultipleValuesMarker { get; set; }

		//	- (NSArray *)selectedObjects;
		[Export ("selectedObjects")]
		NSArray SelectedObjects { get; }

		//- (BOOL)setSelectionIndexPaths:(NSArray *)indexPaths;
		[Export ("setSelectionIndexPaths:")]
		bool SetSelectionIndexPaths (NSArray indexPaths);

		//- (NSArray *)selectionIndexPaths;
		[Export ("selectionIndexPaths")]
		NSArray SelectionIndexPaths { get; }

		//- (BOOL)setSelectionIndexPath:(NSIndexPath *)indexPath;
		[Export ("setSelectionIndexPath:")]
		bool SetSelectionIndexPath (NSIndexPath indexPath);

		//- (NSIndexPath *)selectionIndexPath;
		[Export ("selectionIndexPath")]
		NSIndexPath SelectionIndexPath { get; }

		//- (BOOL)addSelectionIndexPaths:(NSArray *)indexPaths;
		[Export ("addSelectionIndexPaths:")]
		bool AddSelectionIndexPaths (NSArray indexPaths);

		//- (BOOL)removeSelectionIndexPaths:(NSArray *)indexPaths;
		[Export ("removeSelectionIndexPaths:")]
		bool RemoveSelectionIndexPaths (NSArray indexPaths);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (NSArray *)selectedNodes;
		[Export ("selectedNodes")]
		NSArray SelectedNodes { get; }

		//- (void)moveNode:(NSTreeNode *)node toIndexPath:(NSIndexPath *)indexPath;
		[Export ("moveNode:toIndexPath:")]
		void MoveNode (NSTreeNode node, NSIndexPath indexPath);

		//- (void)moveNodes:(NSArray *)nodes toIndexPath:(NSIndexPath *)startingIndexPath;
		[Export ("moveNodes:toIndexPath:")]
		void MoveNodes (NSArray nodes, NSIndexPath startingIndexPath);

		//- (NSString *)childrenKeyPathForNode:(NSTreeNode *)node;
		[Export ("childrenKeyPathForNode:")]
		string ChildrenKeyPathForNode (NSTreeNode node);

		//- (NSString *)countKeyPathForNode:(NSTreeNode *)node;
		[Export ("countKeyPathForNode:")]
		string CountKeyPathForNode (NSTreeNode node);

		//- (NSString *)leafKeyPathForNode:(NSTreeNode *)node;
		[Export ("leafKeyPathForNode:")]
		string LeafKeyPathForNode (NSTreeNode node);

//#endif
	}
}
