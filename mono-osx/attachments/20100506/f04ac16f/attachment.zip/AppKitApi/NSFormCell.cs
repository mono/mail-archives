using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSActionCell))]
	interface NSFormCell {

		//- (id)initTextCell:(NSString *)aString;
		[Export ("initTextCell:")]
		IntPtr Constructor (string aString);

		//- (CGFloat)titleWidth:(NSSize)aSize;
		[Export ("titleWidth:")]
		float TitleWidthWithSize (NSSize aSize);

		//- (CGFloat)titleWidth;
		[Export ("titleWidth")]
		float TitleWidth { get; set; }

		//- (NSString *)title;
		[Export ("title")]
		string Title { get; set; }

		//- (NSFont *)titleFont;
		[Export ("titleFont")]
		NSFont TitleFont { get; set; }

		//- (NSTextAlignment)titleAlignment;
		[Export ("titleAlignment")]
		NSTextAlignment TitleAlignment { get; set; }

		//- (BOOL)isOpaque;
		[Export ("isOpaque")]
		bool IsOpaque { get; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (NSString*)placeholderString;
		[Export ("placeholderString")]
		string PlaceholderString { get; set; }

		//- (NSAttributedString*)placeholderAttributedString;
		[Export ("placeholderAttributedString")]
		NSAttributedString PlaceholderAttributedString { get; set; }

//#endif
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (NSWritingDirection)titleBaseWritingDirection;
		[Export ("titleBaseWritingDirection")]
		NSWritingDirection TitleBaseWritingDirection { get; set; }

//#endif 
		//- (void)setAttributedTitle:(NSAttributedString *)obj;
		[Export ("setAttributedTitle:")]
		void SetAttributedTitle (NSAttributedString obj);

	}
}
