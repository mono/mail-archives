using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSResponder))]
	interface NSWindowController {

		//- (id)initWithWindow:(NSWindow *)window;
		[Export ("initWithWindow:")]
		IntPtr Constructor (NSWindow window);

		//    - (id)initWithWindowNibName:(NSString *)windowNibName;	
		[Export ("initWithWindowNibName:")]
		IntPtr Constructor (string windowNibName);

		//- (id)initWithWindowNibName:(NSString *)windowNibName owner:(id)owner;
		[Export ("initWithWindowNibName:owner:")]
		IntPtr Constructor (string windowNibName, NSObject owner);

		////- (id)initWithWindowNibPath:(NSString *)windowNibPath owner:(id)owner;
		//[Export ("initWithWindowNibPath:owner:")]
		//IntPtr Constructor (string windowNibPath, NSObject owner);

		//    - (NSString *)windowNibName;
		[Export ("windowNibName")]
		string WindowNibName { get; }

		//        - (NSString *)windowNibPath;  
		[Export ("windowNibPath")]
		string WindowNibPath { get; }

		//        - (id)owner;
		[Export ("owner")]
		NSWindowController Owner { get; }

		//- (NSString *)windowFrameAutosaveName;
		[Export ("windowFrameAutosaveName")]
		string WindowFrameAutosaveName { get; set; }

		//- (BOOL)shouldCascadeWindows;
		[Export ("shouldCascadeWindows")]
		bool ShouldCascadeWindows { get; set; }

		//        - (id)document;
		[Export ("document")]
		NSWindowController Document { get; }

		//        - (void)setDocument:(NSDocument *)document;
		[Export ("setDocument:")]
		void SetDocument (NSDocument document);

		//    - (void)setDocumentEdited:(BOOL)dirtyFlag;
		[Export ("setDocumentEdited:")]
		void SetDocumentEdited (bool dirtyFlag);

		//- (BOOL)shouldCloseDocument;
		[Export ("shouldCloseDocument")]
		bool ShouldCloseDocument { get; set; }

		//        - (NSWindow *)window;
		[Export ("window")]
		NSWindow Window { get; set; }

		//    - (void)synchronizeWindowTitleWithDocumentName;
		[Export ("synchronizeWindowTitleWithDocumentName")]
		void SynchronizeWindowTitleWithDocumentName ();

		//    - (NSString *)windowTitleForDocumentDisplayName:(NSString *)displayName;
		[Export ("windowTitleForDocumentDisplayName:")]
		string WindowTitleForDocumentDisplayName (string displayName);

		//    - (void)close;
		[Export ("close")]
		void Close ();

		//        - (IBAction)showWindow:(id)sender;
		[Export ("showWindow:")]
		void ShowWindow (NSObject sender);

		//    - (BOOL)isWindowLoaded;
		[Export ("isWindowLoaded")]
		bool IsWindowLoaded { get; }

		//    - (void)windowWillLoad;
		[Export ("windowWillLoad")]
		void WindowWillLoad ();

		//- (void)windowDidLoad;
		[Export ("windowDidLoad")]
		void WindowDidLoad ();

		//    - (void)loadWindow;
		[Export ("loadWindow")]
		void LoadWindow ();

	}
}
