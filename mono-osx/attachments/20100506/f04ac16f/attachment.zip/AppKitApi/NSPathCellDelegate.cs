using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{
	[BaseType (typeof (NSObject))]
	[Model]
	interface NSPathCellDelegate {

		[Abstract]
		//@optional- (void)pathCell:(NSPathCell *)pathCell willDisplayOpenPanel:(NSOpenPanel *)openPanel;
		[Export ("pathCell:willDisplayOpenPanel:")]
		void PathCell (NSPathCell pathCell, NSOpenPanel openPanel);

		[Abstract]
		//- (void)pathCell:(NSPathCell *)pathCell willPopUpMenu:(NSMenu *)menu;
		[Export ("pathCell:willPopUpMenu:")]
		void PathCell (NSPathCell pathCell, NSMenu menu);

	}
}
