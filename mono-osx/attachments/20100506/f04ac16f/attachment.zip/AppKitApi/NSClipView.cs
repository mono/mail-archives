using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSView))]
	interface NSClipView {

		//- (NSColor *)backgroundColor;
		[Export ("backgroundColor")]
		NSColor BackgroundColor { get; set; }

		//- (BOOL)drawsBackground;
		[Export ("drawsBackground")]
		bool DrawsBackground { get; set; }

		//- (void)setDocumentView:(NSView *)aView;
		[Export ("setDocumentView:")]
		void SetDocumentView (NSView aView);

		//- (id)documentView;
		[Export ("documentView")]
		NSClipView DocumentView { get; }

		//- (NSRect)documentRect;
		[Export ("documentRect")]
		RectangleF DocumentRect { get; }

		//- (NSCursor *)documentCursor;
		[Export ("documentCursor")]
		NSCursor DocumentCursor { get; set; }

		//- (NSRect)documentVisibleRect;
		[Export ("documentVisibleRect")]
		RectangleF DocumentVisibleRect { get; }

		//- (void)viewFrameChanged:(NSNotification *)notification;
		[Export ("viewFrameChanged:")]
		void ViewFrameChanged (NSNotification notification);

		//- (void)viewBoundsChanged:(NSNotification *)notification;
		[Export ("viewBoundsChanged:")]
		void ViewBoundsChanged (NSNotification notification);

		//- (BOOL)copiesOnScroll;
		[Export ("copiesOnScroll")]
		bool CopiesOnScroll { get; set; }

		//- (BOOL)autoscroll:(NSEvent *)theEvent;
		[Export ("autoscroll:")]
		bool Autoscroll (NSEvent theEvent);

		//- (NSPoint)constrainScrollPoint:(NSPoint)newOrigin;
		[Export ("constrainScrollPoint:")]
		PointF ConstrainScrollPoint (PointF newOrigin);

		//- (void)scrollToPoint:(NSPoint)newOrigin;
		[Export ("scrollToPoint:")]
		void ScrollToPoint (PointF newOrigin);

	}
}
