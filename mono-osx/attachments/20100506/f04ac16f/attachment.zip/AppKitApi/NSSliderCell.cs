using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSActionCell))]
	interface NSSliderCell {

		//+ (BOOL)prefersTrackingUntilMouseUp;
		[Static, Export ("prefersTrackingUntilMouseUp")]
		bool PrefersTrackingUntilMouseUp { get; }

		//- (double)minValue;
		[Export ("minValue")]
		double MinValue { get; set; }

		//- (double)maxValue;
		[Export ("maxValue")]
		double MaxValue { get; set; }

		//- (double)altIncrementValue;
		[Export ("altIncrementValue")]
		double AltIncrementValue { get; set; }

		//- (NSInteger)isVertical;
		[Export ("isVertical")]
		int IsVertical { get; }

		//- (NSColor *)titleColor;
		[Export ("titleColor")]
		NSColor TitleColor { get; set; }

		//- (NSFont *)titleFont;
		[Export ("titleFont")]
		NSFont TitleFont { get; set; }

		//- (NSString *)title;
		[Export ("title")]
		string Title { get; set; }

		//- (void)setTitleCell:(NSCell *)aCell;
		[Export ("setTitleCell:")]
		void SetTitleCell (NSCell aCell);

		//- (id)titleCell;
		[Export ("titleCell")]
		NSSliderCell TitleCell { get; }

		//- (CGFloat)knobThickness;
		[Export ("knobThickness")]
		float KnobThickness { get; set; }

		//- (NSRect)knobRectFlipped:(BOOL)flipped;
		[Export ("knobRectFlipped:")]
		RectangleF KnobRectFlipped (bool flipped);

		//- (void)drawKnob:(NSRect)knobRect;
		[Export ("drawKnob:")]
		void DrawKnob (RectangleF knobRect);

		//- (void)drawKnob;
		[Export ("drawKnob")]
		void DrawKnob ();

		//- (void)drawBarInside:(NSRect)aRect flipped:(BOOL)flipped;
		[Export ("drawBarInside:flipped:")]
		void DrawBarInside (RectangleF aRect, bool flipped);

		//- (NSRect)trackRect;	
		[Export ("trackRect")]
		RectangleF TrackRect { get; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//- (NSSliderType)sliderType;
		[Export ("sliderType")]
		NSSliderType SliderType { get; set; }

//#endif
		//- (NSInteger)numberOfTickMarks;
		[Export ("numberOfTickMarks")]
		int NumberOfTickMarks { get; set; }

		//- (NSTickMarkPosition)tickMarkPosition;
		[Export ("tickMarkPosition")]
		NSTickMarkPosition TickMarkPosition { get; set; }

		//- (BOOL)allowsTickMarkValuesOnly;
		[Export ("allowsTickMarkValuesOnly")]
		bool AllowsTickMarkValuesOnly { get; set; }

		//- (double)tickMarkValueAtIndex:(NSInteger)index;
		[Export ("tickMarkValueAtIndex:")]
		double TickMarkValueAtIndex (int index);

		//- (NSRect)rectOfTickMarkAtIndex:(NSInteger)index;
		[Export ("rectOfTickMarkAtIndex:")]
		RectangleF RectOfTickMarkAtIndex (int index);

		//- (NSInteger)indexOfTickMarkAtPoint:(NSPoint)point;
		[Export ("indexOfTickMarkAtPoint:")]
		int IndexOfTickMarkAtPoint (PointF point);

		//- (double)closestTickMarkValueToValue:(double)value;
		[Export ("closestTickMarkValueToValue:")]
		double ClosestTickMarkValueToValue (double value);

	}
}
