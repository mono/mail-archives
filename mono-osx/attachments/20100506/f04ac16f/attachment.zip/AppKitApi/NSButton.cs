using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSControl))]
	interface NSButton {

		//- (NSString *)title;
		[Export ("title")]
		string Title { get; set; }

		//- (NSString *)alternateTitle;
		[Export ("alternateTitle")]
		string AlternateTitle { get; set; }

		//- (NSImage *)image;
		[Export ("image")]
		NSImage Image { get; set; }

		//- (NSImage *)alternateImage;
		[Export ("alternateImage")]
		NSImage AlternateImage { get; set; }

		//- (NSCellImagePosition)imagePosition;
		[Export ("imagePosition")]
		NSCellImagePosition ImagePosition { get; set; }

		//- (void)setButtonType:(NSButtonType)aType;
		[Export ("setButtonType:")]
		void SetButtonType (NSButtonType aType);

		//- (NSInteger)state;
		[Export ("state")]
		int State { get; set; }

		//- (BOOL)isBordered;
		[Export ("isBordered")]
		bool IsBordered { get; }

		//- (void)setBordered:(BOOL)flag;
		[Export ("setBordered:")]
		void SetBordered (bool flag);

		//- (BOOL)isTransparent;
		[Export ("isTransparent")]
		bool IsTransparent { get; }

		//- (void)setTransparent:(BOOL)flag;
		[Export ("setTransparent:")]
		void SetTransparent (bool flag);

		//- (void)setPeriodicDelay:(float)delay interval:(float)interval;
		[Export ("setPeriodicDelay:interval:")]
		void SetPeriodicDelay (float delay, float interval);

		//- (void)getPeriodicDelay:(float *)delay interval:(float *)interval;
		[Export ("getPeriodicDelay:interval:")]
		void GetPeriodicDelay (float delay, float interval);

		//- (NSString *)keyEquivalent;
		[Export ("keyEquivalent")]
		string KeyEquivalent { get; set; }

		//- (NSUInteger)keyEquivalentModifierMask;
		[Export ("keyEquivalentModifierMask")]
		uint KeyEquivalentModifierMask { get; set; }

		//- (void)highlight:(BOOL)flag;
		[Export ("highlight:")]
		void Highlight (bool flag);

		//- (BOOL)performKeyEquivalent:(NSEvent *)key;
		[Export ("performKeyEquivalent:")]
		bool PerformKeyEquivalent (NSEvent key);

		//- (void)setAttributedTitle:(NSAttributedString *)aString;
		[Export ("setAttributedTitle:")]
		void SetAttributedTitle (NSAttributedString aString);

		//- (NSAttributedString *)attributedAlternateTitle;
		[Export ("attributedAlternateTitle")]
		NSAttributedString AttributedAlternateTitle { get; set; }

		//- (NSBezelStyle)bezelStyle;
		[Export ("bezelStyle")]
		NSBezelStyle BezelStyle { get; }

		//- (BOOL)allowsMixedState;
		[Export ("allowsMixedState")]
		bool AllowsMixedState { get; }

		//- (void)setNextState;
		[Export ("setNextState")]
		void SetNextState ();

		//- (BOOL) showsBorderOnlyWhileMouseInside;
		[Export ("showsBorderOnlyWhileMouseInside")]
		bool ShowsBorderOnlyWhileMouseInside { get; }

		//- (NSSound *)sound;
		[Export ("sound")]
		NSSound Sound { get; }

	}
}
