using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSCell))]
	interface NSImageCell {

		//- (NSImageAlignment)imageAlignment;
		[Export ("imageAlignment")]
		NSImageAlignment ImageAlignment { get; set; }

		//- (NSImageScaling)imageScaling;
		[Export ("imageScaling")]
		NSImageScaling ImageScaling { get; set; }

		//- (NSImageFrameStyle)imageFrameStyle;
		[Export ("imageFrameStyle")]
		NSImageFrameStyle ImageFrameStyle { get; set; }

	}
}
