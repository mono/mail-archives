using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSObject))]
	interface NSPrinter {

//#if __LP64__
//#endif
		//+ (NSArray *)printerNames;
		[Static, Export ("printerNames")]
		NSArray PrinterNames { get; }

		//+ (NSArray *)printerTypes;
		[Static, Export ("printerTypes")]
		NSArray PrinterTypes { get; }

		//+ (NSPrinter *)printerWithName:(NSString *)name;
		[Static, Export ("printerWithName:")]
		NSPrinter PrinterWithName (string name);

		//+ (NSPrinter *)printerWithType:(NSString *)type;
		[Static, Export ("printerWithType:")]
		NSPrinter PrinterWithType (string type);

		//- (NSString *)name;
		[Export ("name")]
		string Name { get; }

		//- (NSString *)type;
		[Export ("type")]
		string Type { get; }

		//- (NSInteger)languageLevel;
		[Export ("languageLevel")]
		int LanguageLevel { get; }

		//- (NSSize)pageSizeForPaper:(NSString *)paperName;
		[Export ("pageSizeForPaper:")]
		NSSize PageSizeForPaper (string paperName);

		//- (NSPrinterTableStatus)statusForTable:(NSString *)tableName;
		[Export ("statusForTable:")]
		NSPrinterTableStatus StatusForTable (string tableName);

		//- (BOOL)isKey:(NSString *)key inTable:(NSString *)table;
		[Export ("isKey:inTable:")]
		bool IsKey (string key, string table);

		//- (BOOL)booleanForKey:(NSString *)key inTable:(NSString *)table;
		[Export ("booleanForKey:inTable:")]
		bool BooleanForKey (string key, string table);

		//- (float)floatForKey:(NSString *)key inTable:(NSString *)table;
		[Export ("floatForKey:inTable:")]
		float FloatForKey (string key, string table);

		//- (int)intForKey:(NSString *)key inTable:(NSString *)table;
		[Export ("intForKey:inTable:")]
		int IntForKey (string key, string table);

		//- (NSRect)rectForKey:(NSString *)key inTable:(NSString *)table;
		[Export ("rectForKey:inTable:")]
		RectangleF RectForKey (string key, string table);

		//- (NSSize)sizeForKey:(NSString *)key inTable:(NSString *)table;
		[Export ("sizeForKey:inTable:")]
		NSSize SizeForKey (string key, string table);

		//- (NSString *)stringForKey:(NSString *)key inTable:(NSString *)table;
		[Export ("stringForKey:inTable:")]
		string StringForKey (string key, string table);

		//- (NSArray *)stringListForKey:(NSString *)key inTable:(NSString *)table;
		[Export ("stringListForKey:inTable:")]
		NSArray StringListForKey (string key, string table);

		//- (NSDictionary *)deviceDescription;
		[Export ("deviceDescription")]
		NSDictionary DeviceDescription { get; }

		////- (NSRect)imageRectForPaper:(NSString *)paperName;
		//[Export ("imageRectForPaper:")]
		//RectangleF ImageRectForPaper (string paperName);

		////- (BOOL)acceptsBinary;
		//[Export ("acceptsBinary")]
		//bool AcceptsBinary { get; }

		////- (BOOL)isColor;
		//[Export ("isColor")]
		//bool IsColor { get; }

		////- (BOOL)isFontAvailable:(NSString *)faceName;
		//[Export ("isFontAvailable:")]
		//bool IsFontAvailable (string faceName);

		////- (BOOL)isOutputStackInReverseOrder;
		//[Export ("isOutputStackInReverseOrder")]
		//bool IsOutputStackInReverseOrder { get; }

		////+ (NSPrinter *)printerWithName:(NSString *)name domain:(NSString *)domain includeUnavailable:(BOOL)flag;
		//[Static, Export ("printerWithName:domain:includeUnavailable:")]
		//NSPrinter PrinterWithNameDomain (string name, string domain, bool flag);

		////- (NSString *)domain;
		//[Export ("domain")]
		//string Domain { get; }

		////- (NSString *)host;
		//[Export ("host")]
		//string Host { get; }

		////- (NSString *)note;
		//[Export ("note")]
		//string Note { get; }

	}
}
