using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSObject))]
	interface NSInputServer {

		//- initWithDelegate:(id)aDelegate name:(NSString *)name;
		[Export ("aDelegate name:")]
		IntPtr Constructor (string name);

	}
}
