using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSView))]
	interface NSSplitView {

		//- (void)setVertical:(BOOL)flag;
		[Export ("setVertical:")]
		void SetVertical (bool flag);

		//- (BOOL)isVertical;
		[Export ("isVertical")]
		bool IsVertical { get; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (NSSplitViewDividerStyle)dividerStyle;
		[Export ("dividerStyle")]
		NSSplitViewDividerStyle DividerStyle { get; set; }

		//- (NSString *)autosaveName;
		[Export ("autosaveName")]
		string AutosaveName { get; set; }

//#endif
		//- (void)setDelegate:(id)delegate;
		[Export ("setDelegate:")]
		void SetDelegate (NSObject delegate1);

		//- (id)delegate;
		[Export ("delegate")]
		NSSplitView Delegate { get; }

		//- (void)drawDividerInRect:(NSRect)rect;
		[Export ("drawDividerInRect:")]
		void DrawDividerInRect (RectangleF rect);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (NSColor *)dividerColor;
		[Export ("dividerColor")]
		NSColor DividerColor { get; }

//#endif
		//- (CGFloat)dividerThickness;
		[Export ("dividerThickness")]
		float DividerThickness { get; }

		//- (void)adjustSubviews;
		[Export ("adjustSubviews")]
		void AdjustSubviews ();

		//- (BOOL)isSubviewCollapsed:(NSView *)subview;
		[Export ("isSubviewCollapsed:")]
		bool IsSubviewCollapsed (NSView subview);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (CGFloat)minPossiblePositionOfDividerAtIndex:(NSInteger)dividerIndex;
		[Export ("minPossiblePositionOfDividerAtIndex:")]
		float MinPossiblePositionOfDividerAtIndex (int dividerIndex);

		//- (CGFloat)maxPossiblePositionOfDividerAtIndex:(NSInteger)dividerIndex;
		[Export ("maxPossiblePositionOfDividerAtIndex:")]
		float MaxPossiblePositionOfDividerAtIndex (int dividerIndex);

		//- (void)setPosition:(CGFloat)position ofDividerAtIndex:(NSInteger)dividerIndex;
		[Export ("setPosition:ofDividerAtIndex:")]
		void SetPosition (float position, int dividerIndex);

//#endif
		//- (BOOL)isPaneSplitter;
		[Export ("isPaneSplitter")]
		bool IsPaneSplitter { get; set; }

	}
}
