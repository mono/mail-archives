using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSView))]
	interface NSControl {

		//+ (void)setCellClass:(Class)factoryId;
		[Static, Export ("setCellClass:")]
		void SetCellClass (Class factoryId);

		//+ (Class)cellClass;
		[Static, Export ("cellClass")]
		Class CellClass { get; }

		//- (id)initWithFrame:(NSRect)frameRect;
		[Export ("initWithFrame:")]
		IntPtr Constructor (RectangleF frameRect);

		//- (void)sizeToFit;
		[Export ("sizeToFit")]
		void SizeToFit ();

		//- (void)calcSize;
		[Export ("calcSize")]
		void CalcSize ();

		//- (id)cell;
		[Export ("cell")]
		NSControl Cell { get; }

		//- (void)setCell:(NSCell *)aCell;
		[Export ("setCell:")]
		void SetCell (NSCell aCell);

		//- (id)selectedCell;
		[Export ("selectedCell")]
		NSControl SelectedCell { get; }

		//- (id)target;
		[Export ("target")]
		NSControl Target { get; }

		//- (void)setTarget:(id)anObject;
		[Export ("setTarget:")]
		void SetTarget (NSObject anObject);

		//- (SEL)action;
		[Export ("action")]
		Selector Action { get; set; }

		//- (NSInteger)tag;
		[Export ("tag")]
		int Tag { get; set; }

		//- (NSInteger)selectedTag;
		[Export ("selectedTag")]
		int SelectedTag { get; }

		//- (BOOL)ignoresMultiClick;
		[Export ("ignoresMultiClick")]
		bool IgnoresMultiClick { get; set; }

		//- (NSInteger)sendActionOn:(NSInteger)mask;
		[Export ("sendActionOn:")]
		int SendActionOn (int mask);

		//- (BOOL)isContinuous;
		[Export ("isContinuous")]
		bool IsContinuous { get; }

		//- (void)setContinuous:(BOOL)flag;
		[Export ("setContinuous:")]
		void SetContinuous (bool flag);

		//- (BOOL)isEnabled;
		[Export ("isEnabled")]
		bool IsEnabled { get; }

		//- (void)setEnabled:(BOOL)flag;
		[Export ("setEnabled:")]
		void SetEnabled (bool flag);

		//- (void)setFloatingPointFormat:(BOOL)autoRange left:(NSUInteger)leftDigits right:(NSUInteger)rightDigits;
		[Export ("setFloatingPointFormat:left:right:")]
		void SetFloatingPointFormat (bool autoRange, uint leftDigits, uint rightDigits);

		//- (NSTextAlignment)alignment;
		[Export ("alignment")]
		NSTextAlignment Alignment { get; set; }

		//- (NSFont *)font;
		[Export ("font")]
		NSFont Font { get; set; }

		//- (void)setFormatter:(NSFormatter *)newFormatter;
		[Export ("setFormatter:")]
		void SetFormatter (NSFormatter newFormatter);

		//- (id)formatter;
		[Export ("formatter")]
		NSControl Formatter { get; }

		//- (void)setObjectValue:(id<NSCopying>)obj;
		[Export ("setObjectValue:")]
		void SetObjectValue (NSObject obj);

		//- (id)objectValue;
		[Export ("objectValue")]
		NSControl ObjectValue { get; }

		//- (NSString *)stringValue;
		[Export ("stringValue")]
		string StringValue { get; set; }

		//- (int)intValue;
		[Export ("intValue")]
		int IntValue { get; set; }

		//- (float)floatValue;
		[Export ("floatValue")]
		float FloatValue { get; set; }

		//- (double)doubleValue;
		[Export ("doubleValue")]
		double DoubleValue { get; set; }

		//- (void)setNeedsDisplay;
		[Export ("setNeedsDisplay")]
		void SetNeedsDisplay ();

		//- (void)updateCell:(NSCell *)aCell;
		[Export ("updateCell:")]
		void UpdateCell (NSCell aCell);

		//- (void)updateCellInside:(NSCell *)aCell;
		[Export ("updateCellInside:")]
		void UpdateCellInside (NSCell aCell);

		//- (void)drawCellInside:(NSCell *)aCell;
		[Export ("drawCellInside:")]
		void DrawCellInside (NSCell aCell);

		//- (void)drawCell:(NSCell *)aCell;
		[Export ("drawCell:")]
		void DrawCell (NSCell aCell);

		//- (void)selectCell:(NSCell *)aCell;
		[Export ("selectCell:")]
		void SelectCell (NSCell aCell);

		//- (BOOL)sendAction:(SEL)theAction to:(id)theTarget;
		[Export ("sendAction:to:")]
		bool SendAction (Selector theAction, NSObject theTarget);

		//- (void)takeIntValueFrom:(id)sender;
		[Export ("takeIntValueFrom:")]
		void TakeIntValueFrom (NSObject sender);

		//- (void)takeFloatValueFrom:(id)sender;
		[Export ("takeFloatValueFrom:")]
		void TakeFloatValueFrom (NSObject sender);

		//- (void)takeDoubleValueFrom:(id)sender;
		[Export ("takeDoubleValueFrom:")]
		void TakeDoubleValueFrom (NSObject sender);

		//- (void)takeStringValueFrom:(id)sender;
		[Export ("takeStringValueFrom:")]
		void TakeStringValueFrom (NSObject sender);

		//- (void)takeObjectValueFrom:(id)sender;
		[Export ("takeObjectValueFrom:")]
		void TakeObjectValueFrom (NSObject sender);

		//- (NSText *)currentEditor;
		[Export ("currentEditor")]
		NSText CurrentEditor { get; }

		//- (BOOL)abortEditing;
		[Export ("abortEditing")]
		bool AbortEditing { get; }

		//- (void)validateEditing;
		[Export ("validateEditing")]
		void ValidateEditing ();

		//- (void)mouseDown:(NSEvent *)theEvent;
		[Export ("mouseDown:")]
		void MouseDown (NSEvent theEvent);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (NSWritingDirection)baseWritingDirection;
		[Export ("baseWritingDirection")]
		NSWritingDirection BaseWritingDirection { get; set; }

//#endif 
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (NSInteger)integerValue;
		[Export ("integerValue")]
		int IntegerValue { get; set; }

		//- (void)takeIntegerValueFrom:(id)sender;
		[Export ("takeIntegerValueFrom:")]
		void TakeIntegerValueFrom (NSObject sender);

//#endif 
		//- (BOOL)refusesFirstResponder;
		[Export ("refusesFirstResponder")]
		bool RefusesFirstResponder { get; set; }

		//- (void)setAttributedStringValue:(NSAttributedString *)obj;
		[Export ("setAttributedStringValue:")]
		void SetAttributedStringValue (NSAttributedString obj);

	}
}
