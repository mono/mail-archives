using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSObject))]
	interface NSInputManager {

		//+ (NSInputManager *) currentInputManager;
		[Static, Export ("currentInputManager")]
		NSInputManager CurrentInputManager { get; }

		//+ (void)cycleToNextInputLanguage:(id)sender;
		[Static, Export ("cycleToNextInputLanguage:")]
		void CycleToNextInputLanguage (NSObject sender);

		//+ (void)cycleToNextInputServerInLanguage:(id)sender;
		[Static, Export ("cycleToNextInputServerInLanguage:")]
		void CycleToNextInputServerInLanguage (NSObject sender);

		//- (NSInputManager *) initWithName:(NSString *)inputServerName host:(NSString *)hostName;
		[Export ("initWithName:host:")]
		IntPtr Constructor (string inputServerName, string hostName);

		//- (NSString *) localizedInputManagerName;
		[Export ("localizedInputManagerName")]
		string LocalizedInputManagerName { get; }

		// - (void) markedTextAbandoned:(id)cli; 
		[Export ("markedTextAbandoned:")]
		void MarkedTextAbandoned (NSObject cli);

		//- (void) markedTextSelectionChanged:(NSRange)newSel client:(id)cli; 
		[Export ("markedTextSelectionChanged:client:")]
		void MarkedTextSelectionChanged (NSRange newSel, NSObject cli);

		//- (BOOL) wantsToInterpretAllKeystrokes;
		[Export ("wantsToInterpretAllKeystrokes")]
		bool WantsToInterpretAllKeystrokes { get; }

		//- (NSString*) language;
		[Export ("language")]
		string Language { get; }

		//- (NSImage *) image;
		[Export ("image")]
		NSImage Image { get; }

		//- (NSInputServer *) server;
		[Export ("server")]
		NSInputServer Server { get; }

		//- (BOOL) wantsToHandleMouseEvents;
		[Export ("wantsToHandleMouseEvents")]
		bool WantsToHandleMouseEvents { get; }

		//- (BOOL) handleMouseEvent:(NSEvent*)theMouseEvent;
		[Export ("handleMouseEvent:")]
		bool HandleMouseEvent (NSEvent theMouseEvent);

		//- (BOOL) wantsToDelayTextChangeNotifications;
		[Export ("wantsToDelayTextChangeNotifications")]
		bool WantsToDelayTextChangeNotifications { get; }

	}
}
