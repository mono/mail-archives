using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSObject))]
	interface NSGraphicsContext {

		//+ (NSGraphicsContext *)graphicsContextWithAttributes:(NSDictionary *)attributes;
		[Static, Export ("graphicsContextWithAttributes:")]
		NSGraphicsContext GraphicsContextWithAttributes (NSDictionary attributes);

		//+ (NSGraphicsContext *)graphicsContextWithWindow:(NSWindow *)window;
		[Static, Export ("graphicsContextWithWindow:")]
		NSGraphicsContext GraphicsContextWithWindow (NSWindow window);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//+ (NSGraphicsContext *)graphicsContextWithBitmapImageRep:(NSBitmapImageRep *)bitmapRep;
		[Static, Export ("graphicsContextWithBitmapImageRep:")]
		NSGraphicsContext GraphicsContextWithBitmapImageRep (NSBitmapImageRep bitmapRep);

		//+ (NSGraphicsContext *)graphicsContextWithGraphicsPort:(void *)graphicsPort flipped:(BOOL)initialFlippedState;
		[Static, Export ("graphicsContextWithGraphicsPort:flipped:")]
		IntPtr Constructor (IntPtr graphicsPort, bool initialFlippedState);

//#endif 
		//+ (NSGraphicsContext *)currentContext;
		[Static, Export ("currentContext")]
		NSGraphicsContext CurrentContext { get; }

		//+ (void)setCurrentContext:(NSGraphicsContext *)context;
		[Static, Export ("setCurrentContext:")]
		void SetCurrentContext (NSGraphicsContext context);

		//+ (BOOL)currentContextDrawingToScreen;
		[Static, Export ("currentContextDrawingToScreen")]
		bool CurrentContextDrawingToScreen { get; }

		//+ (void)saveGraphicsState;
		[Static, Export ("saveGraphicsState")]
		void SaveGraphicsStateStatic ();

		//+ (void)restoreGraphicsState;
		[Static, Export ("restoreGraphicsState")]
		void RestoreGraphicsStateStatic ();

		//+ (void)setGraphicsState:(NSInteger)gState;
		[Static, Export ("setGraphicsState:")]
		void SetGraphicsState (int gState);

		//- (NSDictionary *)attributes;
		[Export ("attributes")]
		NSDictionary Attributes { get; }

		//- (BOOL)isDrawingToScreen;
		[Export ("isDrawingToScreen")]
		bool IsDrawingToScreen { get; }

		//- (void)saveGraphicsState;
		[Export ("saveGraphicsState")]
		void SaveGraphicsState ();

		//- (void)restoreGraphicsState;
		[Export ("restoreGraphicsState")]
		void RestoreGraphicsState ();

		//- (void)flushGraphics;
		[Export ("flushGraphics")]
		void FlushGraphics ();

		//- (id)focusStack;
		[Export ("focusStack")]
		NSGraphicsContext FocusStack { get; }

		//- (void)setFocusStack:(id)stack;
		[Export ("setFocusStack:")]
		void SetFocusStack (NSObject stack);

		//- (void *)graphicsPort;
		[Export ("graphicsPort")]
		void GraphicsPort ();

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (BOOL)isFlipped;
		[Export ("isFlipped")]
		bool IsFlipped { get; }

//#endif 
		//- (BOOL)shouldAntialias;
		[Export ("shouldAntialias")]
		bool ShouldAntialias { get; set; }

		//- (NSImageInterpolation)imageInterpolation;
		[Export ("imageInterpolation")]
		NSImageInterpolation ImageInterpolation { get; set; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_2
		//- (NSPoint)patternPhase;
		[Export ("patternPhase")]
		PointF PatternPhase { get; set; }

//#endif
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (NSCompositingOperation)compositingOperation;
		[Export ("compositingOperation")]
		NSCompositingOperation CompositingOperation { get; set; }

//#endif 
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (NSColorRenderingIntent)colorRenderingIntent;
		[Export ("colorRenderingIntent")]
		NSColorRenderingIntent ColorRenderingIntent { get; set; }

//#endif 
	}
}
