using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSObject))]
	interface NSTypesetter {

//#endif 
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (BOOL)usesFontLeading;
		[Export ("usesFontLeading")]
		bool UsesFontLeading { get; set; }

		//- (NSTypesetterBehavior)typesetterBehavior;
		[Export ("typesetterBehavior")]
		NSTypesetterBehavior TypesetterBehavior { get; set; }

		//- (float)hyphenationFactor;
		[Export ("hyphenationFactor")]
		float HyphenationFactor { get; set; }

		//- (CGFloat)lineFragmentPadding;
		[Export ("lineFragmentPadding")]
		float LineFragmentPadding { get; set; }

		//- (NSFont *)substituteFontForFont:(NSFont *)originalFont;
		[Export ("substituteFontForFont:")]
		NSFont SubstituteFontForFont (NSFont originalFont);

		//- (NSTextTab *)textTabForGlyphLocation:(CGFloat)glyphLocation writingDirection:(NSWritingDirection)direction maxLocation:(CGFloat)maxLocation;
		[Export ("textTabForGlyphLocation:writingDirection:maxLocation:")]
		NSTextTab TextTabForGlyphLocation (float glyphLocation, NSWritingDirection direction, float maxLocation);

		//- (BOOL)bidiProcessingEnabled;
		[Export ("bidiProcessingEnabled")]
		bool BidiProcessingEnabled { get; set; }

		//- (NSAttributedString *)attributedString;
		[Export ("attributedString")]
		NSAttributedString AttributedString { get; set; }

		//- (void)setParagraphGlyphRange:(NSRange)paragraphRange separatorGlyphRange:(NSRange)paragraphSeparatorRange;
		[Export ("setParagraphGlyphRange:separatorGlyphRange:")]
		void SetParagraphGlyphRange (NSRange paragraphRange, NSRange paragraphSeparatorRange);

		//- (NSRange)paragraphGlyphRange; 
		[Export ("paragraphGlyphRange")]
		NSRange ParagraphGlyphRange { get; }

		//- (NSRange)paragraphSeparatorGlyphRange;
		[Export ("paragraphSeparatorGlyphRange")]
		NSRange ParagraphSeparatorGlyphRange { get; }

		//- (NSRange)paragraphCharacterRange;
		[Export ("paragraphCharacterRange")]
		NSRange ParagraphCharacterRange { get; }

		//- (NSRange)paragraphSeparatorCharacterRange;
		[Export ("paragraphSeparatorCharacterRange")]
		NSRange ParagraphSeparatorCharacterRange { get; }

		//- (NSUInteger)layoutParagraphAtPoint:(NSPointPointer)lineFragmentOrigin;
		[Export ("layoutParagraphAtPoint:")]
		uint LayoutParagraphAtPoint (NSPointPointer lineFragmentOrigin);

		//- (void)beginParagraph; 
		[Export ("beginParagraph")]
		void BeginParagraph ();

		//- (void)endParagraph; 
		[Export ("endParagraph")]
		void EndParagraph ();

		//- (void)beginLineWithGlyphAtIndex:(NSUInteger)glyphIndex; 
		[Export ("beginLineWithGlyphAtIndex:")]
		void BeginLineWithGlyphAtIndex (uint glyphIndex);

		//- (void)endLineWithGlyphRange:(NSRange)lineGlyphRange; 
		[Export ("endLineWithGlyphRange:")]
		void EndLineWithGlyphRange (NSRange lineGlyphRange);

		//- (CGFloat)lineSpacingAfterGlyphAtIndex:(NSUInteger)glyphIndex withProposedLineFragmentRect:(NSRect)rect;
		[Export ("lineSpacingAfterGlyphAtIndex:withProposedLineFragmentRect:")]
		float LineSpacingAfterGlyphAtIndex (uint glyphIndex, RectangleF rect);

		//- (CGFloat)paragraphSpacingBeforeGlyphAtIndex:(NSUInteger)glyphIndex withProposedLineFragmentRect:(NSRect)rect;
		[Export ("paragraphSpacingBeforeGlyphAtIndex:withProposedLineFragmentRect:")]
		float ParagraphSpacingBeforeGlyphAtIndex (uint glyphIndex, RectangleF rect);

		//- (CGFloat)paragraphSpacingAfterGlyphAtIndex:(NSUInteger)glyphIndex withProposedLineFragmentRect:(NSRect)rect;
		[Export ("paragraphSpacingAfterGlyphAtIndex:withProposedLineFragmentRect:")]
		float ParagraphSpacingAfterGlyphAtIndex (uint glyphIndex, RectangleF rect);

		//- (void)getLineFragmentRect:(NSRectPointer)lineFragmentRect usedRect:(NSRectPointer)lineFragmentUsedRect forParagraphSeparatorGlyphRange:(NSRange)paragraphSeparatorGlyphRange atProposedOrigin:(NSPoint)lineOrigin;
		[Export ("getLineFragmentRect:usedRect:forParagraphSeparatorGlyphRange:atProposedOrigin:")]
		void GetLineFragmentRect (NSRectPointer lineFragmentRect, NSRectPointer lineFragmentUsedRect, NSRange paragraphSeparatorGlyphRange, PointF lineOrigin);

		//- (NSDictionary *)attributesForExtraLineFragment;
		[Export ("attributesForExtraLineFragment")]
		NSDictionary AttributesForExtraLineFragment { get; }

		//- (NSTypesetterControlCharacterAction)actionForControlCharacterAtIndex:(NSUInteger)charIndex;
		[Export ("actionForControlCharacterAtIndex:")]
		NSTypesetterControlCharacterAction ActionForControlCharacterAtIndex (uint charIndex);

		//- (NSLayoutManager *)layoutManager;
		[Export ("layoutManager")]
		NSLayoutManager LayoutManager { get; }

		//- (NSArray *)textContainers;
		[Export ("textContainers")]
		NSArray TextContainers { get; }

		//- (NSTextContainer *)currentTextContainer;
		[Export ("currentTextContainer")]
		NSTextContainer CurrentTextContainer { get; }

		//- (NSParagraphStyle *)currentParagraphStyle;
		[Export ("currentParagraphStyle")]
		NSParagraphStyle CurrentParagraphStyle { get; }

		//- (void)setHardInvalidation:(BOOL)flag forGlyphRange:(NSRange)glyphRange;
		[Export ("setHardInvalidation:forGlyphRange:")]
		void SetHardInvalidation (bool flag, NSRange glyphRange);

//#endif 
		//- (void)layoutGlyphsInLayoutManager:(NSLayoutManager *)layoutManager startingAtGlyphIndex:(NSUInteger)startGlyphIndex maxNumberOfLineFragments:(NSUInteger)maxNumLines nextGlyphIndex:(NSUInteger *)nextGlyph;
		[Export ("layoutGlyphsInLayoutManager:startingAtGlyphIndex:maxNumberOfLineFragments:nextGlyphIndex:")]
		void LayoutGlyphsInLayoutManager (NSLayoutManager layoutManager, uint startGlyphIndex, uint maxNumLines, uint nextGlyph);

		//- (NSRange)layoutCharactersInRange:(NSRange)characterRange forLayoutManager:(NSLayoutManager *)layoutManager maximumNumberOfLineFragments:(NSUInteger)maxNumLines AVAILABLE_MAC_OS_X_VERSION_10_5_AND_LATER;
		[Export ("layoutCharactersInRange:forLayoutManager:maximumNumberOfLineFragments:")]
		NSRange LayoutCharactersInRange (NSRange characterRange, NSLayoutManager layoutManager, uint maxNumLines);

		////+ (NSSize)printingAdjustmentInLayoutManager:(NSLayoutManager *)layoutMgr forNominallySpacedGlyphRange:(NSRange)nominallySpacedGlyphsRange packedGlyphs:(const unsigned char *)packedGlyphs count:(NSUInteger)packedGlyphsCount;
		//[Static, Export ("printingAdjustmentInLayoutManager:forNominallySpacedGlyphRange:packedGlyphs:count:")]
		//NSSize PrintingAdjustmentInLayoutManager (NSLayoutManager layoutMgr, NSRange nominallySpacedGlyphsRange, const unsigned char packedGlyphs, uint packedGlyphsCount);

		//- (CGFloat)baselineOffsetInLayoutManager:(NSLayoutManager *)layoutMgr glyphIndex:(NSUInteger)glyphIndex;
		[Export ("baselineOffsetInLayoutManager:glyphIndex:")]
		float BaselineOffsetInLayoutManager (NSLayoutManager layoutMgr, uint glyphIndex);

		//+ (id)sharedSystemTypesetter;
		[Static, Export ("sharedSystemTypesetter")]
		NSTypesetter SharedSystemTypesetter { get; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_2
		//+ (id)sharedSystemTypesetterForBehavior:(NSTypesetterBehavior)theBehavior;
		[Static, Export ("sharedSystemTypesetterForBehavior:")]
		NSTypesetter SharedSystemTypesetterForBehavior (NSTypesetterBehavior theBehavior);

		//+ (NSTypesetterBehavior)defaultTypesetterBehavior;
		[Static, Export ("defaultTypesetterBehavior")]
		NSTypesetterBehavior DefaultTypesetterBehavior { get; }

//#endif
		//- (void)willSetLineFragmentRect:(NSRectPointer)lineRect forGlyphRange:(NSRange)glyphRange usedRect:(NSRectPointer)usedRect baselineOffset:(CGFloat *)baselineOffset;
		[Export ("willSetLineFragmentRect:forGlyphRange:usedRect:baselineOffset:")]
		void WillSetLineFragmentRectForGlyphRange (NSRectPointer lineRect, NSRange glyphRange, NSRectPointer usedRect, float baselineOffset);

		//- (BOOL)shouldBreakLineByWordBeforeCharacterAtIndex:(NSUInteger)charIndex;
		[Export ("shouldBreakLineByWordBeforeCharacterAtIndex:")]
		bool ShouldBreakLineByWordBeforeCharacterAtIndex (uint charIndex);

		//- (BOOL)shouldBreakLineByHyphenatingBeforeCharacterAtIndex:(NSUInteger)charIndex;
		[Export ("shouldBreakLineByHyphenatingBeforeCharacterAtIndex:")]
		bool ShouldBreakLineByHyphenatingBeforeCharacterAtIndex (uint charIndex);

		//- (float)hyphenationFactorForGlyphAtIndex:(NSUInteger)glyphIndex;
		[Export ("hyphenationFactorForGlyphAtIndex:")]
		float HyphenationFactorForGlyphAtIndex (uint glyphIndex);

		//- (UTF32Char)hyphenCharacterForGlyphAtIndex:(NSUInteger)glyphIndex;
		[Export ("hyphenCharacterForGlyphAtIndex:")]
		UTF32Char HyphenCharacterForGlyphAtIndex (uint glyphIndex);

		//- (NSRect)boundingBoxForControlGlyphAtIndex:(NSUInteger)glyphIndex forTextContainer:(NSTextContainer *)textContainer proposedLineFragment:(NSRect)proposedRect glyphPosition:(NSPoint)glyphPosition characterIndex:(NSUInteger)charIndex;
		[Export ("boundingBoxForControlGlyphAtIndex:forTextContainer:proposedLineFragment:glyphPosition:characterIndex:")]
		RectangleF BoundingBoxForControlGlyphAtIndexForTextContainer (uint glyphIndex, NSTextContainer textContainer, RectangleF proposedRect, PointF glyphPosition, uint charIndex);

		//- (NSRange)characterRangeForGlyphRange:(NSRange)glyphRange actualGlyphRange:(NSRangePointer)actualGlyphRange;
		[Export ("characterRangeForGlyphRange:actualGlyphRange:")]
		NSRange CharacterRangeForGlyphRangeActualGlyphRange (NSRange glyphRange, NSRangePointer actualGlyphRange);

		//- (NSRange)glyphRangeForCharacterRange:(NSRange)charRange actualCharacterRange:(NSRangePointer)actualCharRange;
		[Export ("glyphRangeForCharacterRange:actualCharacterRange:")]
		NSRange GlyphRangeForCharacterRangeActualCharacterRange (NSRange charRange, NSRangePointer actualCharRange);

		//- (NSUInteger)getGlyphsInRange:(NSRange)glyphsRange glyphs:(NSGlyph *)glyphBuffer characterIndexes:(NSUInteger *)charIndexBuffer glyphInscriptions:(NSGlyphInscription *)inscribeBuffer elasticBits:(BOOL *)elasticBuffer bidiLevels:(unsigned char *)bidiLevelBuffer;
		[Export ("getGlyphsInRange:glyphs:characterIndexes:glyphInscriptions:elasticBits:bidiLevels:")]
		uint GetGlyphsInRangeGlyphs (NSRange glyphsRange, uint glyphBuffer, uint charIndexBuffer, NSGlyphInscription inscribeBuffer, bool elasticBuffer, byte bidiLevelBuffer);

		//- (void)getLineFragmentRect:(NSRectPointer)lineFragmentRect usedRect:(NSRectPointer)lineFragmentUsedRect remainingRect:(NSRectPointer)remainingRect forStartingGlyphAtIndex:(NSUInteger)startingGlyphIndex proposedRect:(NSRect)proposedRect lineSpacing:(CGFloat)lineSpacing paragraphSpacingBefore:(CGFloat)paragraphSpacingBefore paragraphSpacingAfter:(CGFloat)paragraphSpacingAfter;
		[Export ("getLineFragmentRect:usedRect:remainingRect:forStartingGlyphAtIndex:proposedRect:lineSpacing:paragraphSpacingBefore:paragraphSpacingAfter:")]
		void GetLineFragmentRectUsedRect (NSRectPointer lineFragmentRect, NSRectPointer lineFragmentUsedRect, NSRectPointer remainingRect, uint startingGlyphIndex, RectangleF proposedRect, float lineSpacing, float paragraphSpacingBefore, float paragraphSpacingAfter);

		//- (void)setLineFragmentRect:(NSRect)fragmentRect forGlyphRange:(NSRange)glyphRange usedRect:(NSRect)usedRect baselineOffset:(CGFloat)baselineOffset;
		[Export ("setLineFragmentRect:forGlyphRange:usedRect:baselineOffset:")]
		void SetLineFragmentRectForGlyphRange (RectangleF fragmentRect, NSRange glyphRange, RectangleF usedRect, float baselineOffset);

		//- (void)substituteGlyphsInRange:(NSRange)glyphRange withGlyphs:(NSGlyph *)glyphs;
		[Export ("substituteGlyphsInRange:withGlyphs:")]
		void SubstituteGlyphsInRangeWithGlyphs (NSRange glyphRange, uint glyphs);

		//- (void)insertGlyph:(NSGlyph)glyph atGlyphIndex:(NSUInteger)glyphIndex characterIndex:(NSUInteger)characterIndex;
		[Export ("insertGlyph:atGlyphIndex:characterIndex:")]
		void InsertGlyphAtGlyphIndex (uint glyph, uint glyphIndex, uint characterIndex);

		//- (void)deleteGlyphsInRange:(NSRange)glyphRange;
		[Export ("deleteGlyphsInRange:")]
		void DeleteGlyphsInRange (NSRange glyphRange);

		//- (void)setNotShownAttribute:(BOOL)flag forGlyphRange:(NSRange)glyphRange;
		[Export ("setNotShownAttribute:forGlyphRange:")]
		void SetNotShownAttributeForGlyphRange (bool flag, NSRange glyphRange);

		//- (void)setDrawsOutsideLineFragment:(BOOL)flag forGlyphRange:(NSRange)glyphRange;
		[Export ("setDrawsOutsideLineFragment:forGlyphRange:")]
		void SetDrawsOutsideLineFragmentForGlyphRange (bool flag, NSRange glyphRange);

		////- (void)setLocation:(NSPoint)location withAdvancements:(const CGFloat *)advancements forStartOfGlyphRange:(NSRange)glyphRange;
		//[Export ("setLocation:withAdvancements:forStartOfGlyphRange:")]
		//void SetLocationWithAdvancements (PointF location, const CGFloat advancements, NSRange glyphRange);

		//- (void)setAttachmentSize:(NSSize)attachmentSize forGlyphRange:(NSRange)glyphRange;
		[Export ("setAttachmentSize:forGlyphRange:")]
		void SetAttachmentSizeForGlyphRange (NSSize attachmentSize, NSRange glyphRange);

		////- (void)setBidiLevels:(const uint8_t *)levels forGlyphRange:(NSRange)glyphRange;
		//[Export ("setBidiLevels:forGlyphRange:")]
		//void SetBidiLevelsForGlyphRange (const uint8_t levels, NSRange glyphRange);

	}
}
