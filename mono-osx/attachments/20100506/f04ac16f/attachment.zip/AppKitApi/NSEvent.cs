using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSObject))]
	interface NSEvent {

//#if __LP64__
//#endif
//#if __LP64__
//#endif
//#if __LP64__
//#endif
//#if __LP64__
//#endif
//#if __LP64__
//#endif
//#if __LP64__
//#endif
//#if __LP64__
//#endif
		//- (NSEventType)type;
		[Export ("type")]
		NSEventType Type { get; }

		//- (NSUInteger)modifierFlags;
		[Export ("modifierFlags")]
		uint ModifierFlags { get; }

		//- (NSTimeInterval)timestamp;
		[Export ("timestamp")]
		double Timestamp { get; }

		//- (NSWindow *)window;
		[Export ("window")]
		NSWindow Window { get; }

		//- (NSInteger)windowNumber;
		[Export ("windowNumber")]
		int WindowNumber { get; }

		//- (NSGraphicsContext*)context;
		[Export ("context")]
		NSGraphicsContext Context { get; }

		//- (NSInteger)clickCount;
		[Export ("clickCount")]
		int ClickCount { get; }

		//- (NSInteger)buttonNumber;    
		[Export ("buttonNumber")]
		int ButtonNumber { get; }

		//- (NSInteger)eventNumber;
		[Export ("eventNumber")]
		int EventNumber { get; }

		//- (float)pressure;
		[Export ("pressure")]
		float Pressure { get; }

		//- (NSPoint)locationInWindow;
		[Export ("locationInWindow")]
		PointF LocationInWindow { get; }

		//- (CGFloat)deltaX;    
		[Export ("deltaX")]
		float DeltaX { get; }

		//- (CGFloat)deltaY;    
		[Export ("deltaY")]
		float DeltaY { get; }

		//- (CGFloat)deltaZ;    
		[Export ("deltaZ")]
		float DeltaZ { get; }

		//- (NSString *)characters;
		[Export ("characters")]
		string Characters { get; }

		//- (NSString *)charactersIgnoringModifiers;
		[Export ("charactersIgnoringModifiers")]
		string CharactersIgnoringModifiers { get; }

		//  - (BOOL)isARepeat;
		[Export ("isARepeat")]
		bool IsARepeat { get; }

		////- (unsigned short)keyCode;        
		//[Export ("keyCode")]
		//unsigned short KeyCode { get; }

		//- (NSInteger)trackingNumber;
		[Export ("trackingNumber")]
		int TrackingNumber { get; }

		//- (void *)userData;
		[Export ("userData")]
		void UserData ();

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (NSTrackingArea *)trackingArea; 
		[Export ("trackingArea")]
		NSTrackingArea TrackingArea { get; }

//#endif
		//- (short)subtype;
		[Export ("subtype")]
		short Subtype { get; }

		//- (NSInteger)data1;
		[Export ("data1")]
		int Data1 { get; }

		//- (NSInteger)data2;
		[Export ("data2")]
		int Data2 { get; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		////- (const void * )eventRef;
		//[Export ("eventRef")]
		//const void EventRef { get; }

		////+ (NSEvent *)eventWithEventRef:(const void * )eventRef;
		//[Static, Export ("eventWithEventRef:")]
		//NSEvent EventWithEventRef (const void eventRef);

		//- (CGEventRef)CGEvent;
		[Export ("CGEvent")]
		CGEventRef CGEvent { get; }

		//+ (NSEvent *)eventWithCGEvent:(CGEventRef)cgEvent;
		[Static, Export ("eventWithCGEvent:")]
		NSEvent EventWithCGEvent (CGEventRef cgEvent);

		//+ (void)setMouseCoalescingEnabled:(BOOL)flag;
		[Static, Export ("setMouseCoalescingEnabled:")]
		void SetMouseCoalescingEnabled (bool flag);

		//+ (BOOL)isMouseCoalescingEnabled;
		[Static, Export ("isMouseCoalescingEnabled")]
		bool IsMouseCoalescingEnabled { get; }

//#endif
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (NSUInteger)deviceID;
		[Export ("deviceID")]
		uint DeviceID { get; }

		//- (NSInteger)absoluteX; 
		[Export ("absoluteX")]
		int AbsoluteX { get; }

		//- (NSInteger)absoluteY;               
		[Export ("absoluteY")]
		int AbsoluteY { get; }

		//- (NSInteger)absoluteZ;     
		[Export ("absoluteZ")]
		int AbsoluteZ { get; }

		//- (NSUInteger)buttonMask;  
		[Export ("buttonMask")]
		uint ButtonMask { get; }

		//- (NSPoint)tilt;     
		[Export ("tilt")]
		PointF Tilt { get; }

		//- (float)rotation;       
		[Export ("rotation")]
		float Rotation { get; }

		//- (float)tangentialPressure;  
		[Export ("tangentialPressure")]
		float TangentialPressure { get; }

		//- (id)vendorDefined;    
		[Export ("vendorDefined")]
		NSEvent VendorDefined { get; }

		//- (NSUInteger)vendorID;
		[Export ("vendorID")]
		uint VendorID { get; }

		//- (NSUInteger)tabletID;
		[Export ("tabletID")]
		uint TabletID { get; }

		//- (NSUInteger)pointingDeviceID;
		[Export ("pointingDeviceID")]
		uint PointingDeviceID { get; }

		//- (NSUInteger)systemTabletID;
		[Export ("systemTabletID")]
		uint SystemTabletID { get; }

		//- (NSUInteger)vendorPointingDeviceType; 
		[Export ("vendorPointingDeviceType")]
		uint VendorPointingDeviceType { get; }

		//- (NSUInteger)pointingDeviceSerialNumber; 
		[Export ("pointingDeviceSerialNumber")]
		uint PointingDeviceSerialNumber { get; }

		////- (unsigned long long)uniqueID;    
		//[Export ("uniqueID")]
		//unsigned long long UniqueID { get; }

		//- (NSUInteger)capabilityMask;    
		[Export ("capabilityMask")]
		uint CapabilityMask { get; }

		//- (NSPointingDeviceType)pointingDeviceType;
		[Export ("pointingDeviceType")]
		NSPointingDeviceType PointingDeviceType { get; }

		//- (BOOL)isEnteringProximity;    
		[Export ("isEnteringProximity")]
		bool IsEnteringProximity { get; }

//#endif
		//+ (void)startPeriodicEventsAfterDelay:(NSTimeInterval)delay withPeriod:(NSTimeInterval)period;
		[Static, Export ("startPeriodicEventsAfterDelay:withPeriod:")]
		void StartPeriodicEventsAfterDelay (double delay, double period);

		//+ (void)stopPeriodicEvents;
		[Static, Export ("stopPeriodicEvents")]
		void StopPeriodicEvents ();

		//+ (NSEvent *)mouseEventWithType:(NSEventType)type location:(NSPoint)location modifierFlags:(NSUInteger)flags timestamp:(NSTimeInterval)time windowNumber:(NSInteger)wNum context:(NSGraphicsContext*)context eventNumber:(NSInteger)eNum clickCount:(NSInteger)cNum pressure:(float)pressure;
		[Static, Export ("mouseEventWithType:location:modifierFlags:timestamp:windowNumber:context:eventNumber:clickCount:pressure:")]
		NSEvent MouseEventWithType (NSEventType type, PointF location, uint flags, double time, int wNum, NSGraphicsContext context, int eNum, int cNum, float pressure);

		////+ (NSEvent *)keyEventWithType:(NSEventType)type location:(NSPoint)location modifierFlags:(NSUInteger)flags timestamp:(NSTimeInterval)time windowNumber:(NSInteger)wNum context:(NSGraphicsContext*)context characters:(NSString *)keys charactersIgnoringModifiers:(NSString *)ukeys isARepeat:(BOOL)flag keyCode:(unsigned short)code;
		//[Static, Export ("keyEventWithType:location:modifierFlags:timestamp:windowNumber:context:characters:charactersIgnoringModifiers:isARepeat:keyCode:")]
		//NSEvent KeyEventWithType (NSEventType type, PointF location, uint flags, double time, int wNum, NSGraphicsContext context, string keys, string ukeys, bool flag, unsigned short code);

		//+ (NSEvent *)enterExitEventWithType:(NSEventType)type location:(NSPoint)location modifierFlags:(NSUInteger)flags timestamp:(NSTimeInterval)time windowNumber:(NSInteger)wNum context:(NSGraphicsContext*)context eventNumber:(NSInteger)eNum trackingNumber:(NSInteger)tNum userData:(void *)data;
		[Static, Export ("enterExitEventWithType:location:modifierFlags:timestamp:windowNumber:context:eventNumber:trackingNumber:userData:")]
		NSEvent EnterExitEventWithType (NSEventType type, PointF location, uint flags, double time, int wNum, NSGraphicsContext context, int eNum, int tNum, IntPtr data);

		//+ (NSEvent *)otherEventWithType:(NSEventType)type location:(NSPoint)location modifierFlags:(NSUInteger)flags timestamp:(NSTimeInterval)time windowNumber:(NSInteger)wNum context:(NSGraphicsContext*)context subtype:(short)subtype data1:(NSInteger)d1 data2:(NSInteger)d2;
		[Static, Export ("otherEventWithType:location:modifierFlags:timestamp:windowNumber:context:subtype:data1:data2:")]
		NSEvent OtherEventWithType (NSEventType type, PointF location, uint flags, double time, int wNum, NSGraphicsContext context, short subtype, int d1, int d2);

		//+ (NSPoint)mouseLocation;
		[Static, Export ("mouseLocation")]
		PointF MouseLocation { get; }

	}
}
