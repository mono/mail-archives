using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSImageRep))]
	interface NSPDFImageRep {

		//+ (id)imageRepWithData:(NSData*)pdfData;
		[Static, Export ("imageRepWithData:")]
		NSPDFImageRep ImageRepWithData (NSData pdfData);

		//- (id)initWithData:(NSData*)pdfData;
		[Export ("initWithData:")]
		IntPtr Constructor (NSData pdfData);

		//- (NSData*)PDFRepresentation;
		[Export ("PDFRepresentation")]
		NSData PDFRepresentation { get; }

		//- (NSRect)bounds;			
		[Export ("bounds")]
		RectangleF Bounds { get; }

		//- (NSInteger)  currentPage;
		[Export ("currentPage")]
		int CurrentPage { get; set; }

		//- (NSInteger)  pageCount;
		[Export ("pageCount")]
		int PageCount { get; }

	}
}
