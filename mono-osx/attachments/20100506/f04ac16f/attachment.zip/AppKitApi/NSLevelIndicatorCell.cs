using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSActionCell))]
	interface NSLevelIndicatorCell {

		//- (id)initWithLevelIndicatorStyle:(NSLevelIndicatorStyle)levelIndicatorStyle;
		[Export ("initWithLevelIndicatorStyle:")]
		IntPtr Constructor (NSLevelIndicatorStyle levelIndicatorStyle);

		//- (NSLevelIndicatorStyle)levelIndicatorStyle;
		[Export ("levelIndicatorStyle")]
		NSLevelIndicatorStyle LevelIndicatorStyle { get; set; }

		//- (double)minValue;
		[Export ("minValue")]
		double MinValue { get; set; }

		//- (double)maxValue;
		[Export ("maxValue")]
		double MaxValue { get; set; }

		//- (double)warningValue;
		[Export ("warningValue")]
		double WarningValue { get; set; }

		//- (double)criticalValue;
		[Export ("criticalValue")]
		double CriticalValue { get; set; }

		//- (NSTickMarkPosition)tickMarkPosition;
		[Export ("tickMarkPosition")]
		NSTickMarkPosition TickMarkPosition { get; set; }

		//- (NSInteger)numberOfTickMarks;
		[Export ("numberOfTickMarks")]
		int NumberOfTickMarks { get; set; }

		//- (NSInteger)numberOfMajorTickMarks;
		[Export ("numberOfMajorTickMarks")]
		int NumberOfMajorTickMarks { get; set; }

		//- (NSRect)rectOfTickMarkAtIndex:(NSInteger)index;
		[Export ("rectOfTickMarkAtIndex:")]
		RectangleF RectOfTickMarkAtIndex (int index);

		//- (double)tickMarkValueAtIndex:(NSInteger)index;
		[Export ("tickMarkValueAtIndex:")]
		double TickMarkValueAtIndex (int index);

		//- (void)setImage:(NSImage*)image;
		[Export ("setImage:")]
		void SetImage (NSImage image);

	}
}
