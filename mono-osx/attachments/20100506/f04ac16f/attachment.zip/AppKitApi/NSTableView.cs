using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSControl))]
	interface NSTableView {

		//- (void)setDataSource:(id)aSource;
		[Export ("setDataSource:")]
		void SetDataSource (NSObject aSource);

		//- (id)dataSource;
		[Export ("dataSource")]
		NSTableView DataSource { get; }

		//- (void)setDelegate:(id)delegate;
		[Export ("setDelegate:")]
		void SetDelegate (NSObject delegate1);

		//- (id)delegate;
		[Export ("delegate")]
		NSTableView Delegate { get; }

		//- (NSTableHeaderView *)headerView;
		[Export ("headerView")]
		NSTableHeaderView HeaderView { get; set; }

		//- (NSView *)cornerView;
		[Export ("cornerView")]
		NSView CornerView { get; set; }

		//- (BOOL)allowsColumnReordering;
		[Export ("allowsColumnReordering")]
		bool AllowsColumnReordering { get; set; }

		//- (BOOL)allowsColumnResizing;
		[Export ("allowsColumnResizing")]
		bool AllowsColumnResizing { get; set; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (NSTableViewColumnAutoresizingStyle)columnAutoresizingStyle;
		[Export ("columnAutoresizingStyle")]
		NSTableViewColumnAutoresizingStyle ColumnAutoresizingStyle { get; set; }

//#endif
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//- (NSUInteger)gridStyleMask;
		[Export ("gridStyleMask")]
		uint GridStyleMask { get; set; }

//#endif
		//- (NSSize)intercellSpacing;
		[Export ("intercellSpacing")]
		NSSize IntercellSpacing { get; set; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//- (BOOL)usesAlternatingRowBackgroundColors;
		[Export ("usesAlternatingRowBackgroundColors")]
		bool UsesAlternatingRowBackgroundColors { get; set; }

//#endif
		//- (NSColor *)backgroundColor;
		[Export ("backgroundColor")]
		NSColor BackgroundColor { get; set; }

		//- (NSColor *)gridColor;
		[Export ("gridColor")]
		NSColor GridColor { get; set; }

		//- (CGFloat)rowHeight;
		[Export ("rowHeight")]
		float RowHeight { get; set; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (void)noteHeightOfRowsWithIndexesChanged:(NSIndexSet *)indexSet;
		[Export ("noteHeightOfRowsWithIndexesChanged:")]
		void NoteHeightOfRowsWithIndexesChanged (NSIndexSet indexSet);

//#endif
		//- (NSArray *)tableColumns;
		[Export ("tableColumns")]
		NSArray TableColumns { get; }

		//- (NSInteger)numberOfColumns;
		[Export ("numberOfColumns")]
		int NumberOfColumns { get; }

		//- (NSInteger)numberOfRows;
		[Export ("numberOfRows")]
		int NumberOfRows { get; }

		//- (void)addTableColumn:(NSTableColumn *)column;
		[Export ("addTableColumn:")]
		void AddTableColumn (NSTableColumn column);

		//- (void)removeTableColumn:(NSTableColumn *)column;
		[Export ("removeTableColumn:")]
		void RemoveTableColumn (NSTableColumn column);

		//- (NSInteger)columnWithIdentifier:(id)identifier;
		[Export ("columnWithIdentifier:")]
		int ColumnWithIdentifier (NSObject identifier);

		//- (NSTableColumn *)tableColumnWithIdentifier:(id)identifier;
		[Export ("tableColumnWithIdentifier:")]
		NSTableColumn TableColumnWithIdentifier (NSObject identifier);

		//- (void)tile;
		[Export ("tile")]
		void Tile ();

		//- (void)sizeToFit;
		[Export ("sizeToFit")]
		void SizeToFit ();

		//- (void)sizeLastColumnToFit;
		[Export ("sizeLastColumnToFit")]
		void SizeLastColumnToFit ();

		//- (void)scrollRowToVisible:(NSInteger)row;
		[Export ("scrollRowToVisible:")]
		void ScrollRowToVisible (int row);

		//- (void)scrollColumnToVisible:(NSInteger)column;
		[Export ("scrollColumnToVisible:")]
		void ScrollColumnToVisible (int column);

		//- (void)moveColumn:(NSInteger)column toColumn:(NSInteger)newIndex;
		[Export ("moveColumn:toColumn:")]
		void MoveColumn (int column, int newIndex);

		//- (void)reloadData;
		[Export ("reloadData")]
		void ReloadData ();

		//- (void)noteNumberOfRowsChanged;
		[Export ("noteNumberOfRowsChanged")]
		void NoteNumberOfRowsChanged ();

		//- (NSInteger)editedColumn;
		[Export ("editedColumn")]
		int EditedColumn { get; }

		//- (NSInteger)editedRow;
		[Export ("editedRow")]
		int EditedRow { get; }

		//- (NSInteger)clickedColumn;
		[Export ("clickedColumn")]
		int ClickedColumn { get; }

		//- (NSInteger)clickedRow;
		[Export ("clickedRow")]
		int ClickedRow { get; }

		//- (SEL)doubleAction;
		[Export ("doubleAction")]
		Selector DoubleAction { get; set; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//- (NSArray *)sortDescriptors;
		[Export ("sortDescriptors")]
		NSArray SortDescriptors { get; set; }

//#endif
		//- (void)setIndicatorImage:(NSImage *)anImage inTableColumn:(NSTableColumn *)tc;
		[Export ("setIndicatorImage:inTableColumn:")]
		void SetIndicatorImage (NSImage anImage, NSTableColumn tc);

		//- (NSImage *)indicatorImageInTableColumn:(NSTableColumn *)tc;
		[Export ("indicatorImageInTableColumn:")]
		NSImage IndicatorImageInTableColumn (NSTableColumn tc);

		//- (NSTableColumn *)highlightedTableColumn;
		[Export ("highlightedTableColumn")]
		NSTableColumn HighlightedTableColumn { get; set; }

		//- (BOOL)verticalMotionCanBeginDrag;
		[Export ("verticalMotionCanBeginDrag")]
		bool VerticalMotionCanBeginDrag { get; set; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (BOOL)canDragRowsWithIndexes:(NSIndexSet *)rowIndexes atPoint:(NSPoint)mouseDownPoint;
		[Export ("canDragRowsWithIndexes:atPoint:")]
		bool CanDragRowsWithIndexes (NSIndexSet rowIndexes, PointF mouseDownPoint);

		//- (NSImage *)dragImageForRowsWithIndexes:(NSIndexSet *)dragRows tableColumns:(NSArray *)tableColumns event:(NSEvent*)dragEvent offset:(NSPointPointer)dragImageOffset;
		[Export ("dragImageForRowsWithIndexes:tableColumns:event:offset:")]
		NSImage DragImageForRowsWithIndexes (NSIndexSet dragRows, NSArray tableColumns, NSEvent dragEvent, NSPointPointer dragImageOffset);

		//- (void)setDraggingSourceOperationMask:(NSDragOperation)mask forLocal:(BOOL)isLocal;
		[Export ("setDraggingSourceOperationMask:forLocal:")]
		void SetDraggingSourceOperationMask (NSDragOperation mask, bool isLocal);

//#endif
		//- (void)setDropRow:(NSInteger)row dropOperation:(NSTableViewDropOperation)op;
		[Export ("setDropRow:dropOperation:")]
		void SetDropRow (int row, NSTableViewDropOperation op);

		//- (BOOL)allowsMultipleSelection;
		[Export ("allowsMultipleSelection")]
		bool AllowsMultipleSelection { get; set; }

		//- (BOOL)allowsEmptySelection;
		[Export ("allowsEmptySelection")]
		bool AllowsEmptySelection { get; set; }

		//- (BOOL)allowsColumnSelection;
		[Export ("allowsColumnSelection")]
		bool AllowsColumnSelection { get; set; }

		//- (void)selectAll:(id)sender;
		[Export ("selectAll:")]
		void SelectAll (NSObject sender);

		//- (void)deselectAll:(id)sender;
		[Export ("deselectAll:")]
		void DeselectAll (NSObject sender);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//- (void)selectColumnIndexes:(NSIndexSet *)indexes byExtendingSelection:(BOOL)extend;
		[Export ("selectColumnIndexes:byExtendingSelection:")]
		void SelectColumnIndexes (NSIndexSet indexes, bool extend);

		//- (void)selectRowIndexes:(NSIndexSet *)indexes byExtendingSelection:(BOOL)extend;
		[Export ("selectRowIndexes:byExtendingSelection:")]
		void SelectRowIndexes (NSIndexSet indexes, bool extend);

		//- (NSIndexSet *)selectedColumnIndexes;
		[Export ("selectedColumnIndexes")]
		NSIndexSet SelectedColumnIndexes { get; }

		//- (NSIndexSet *)selectedRowIndexes;
		[Export ("selectedRowIndexes")]
		NSIndexSet SelectedRowIndexes { get; }

//#endif
		//- (void)deselectColumn:(NSInteger)column;
		[Export ("deselectColumn:")]
		void DeselectColumn (int column);

		//- (void)deselectRow:(NSInteger)row;
		[Export ("deselectRow:")]
		void DeselectRow (int row);

		//- (NSInteger)selectedColumn;
		[Export ("selectedColumn")]
		int SelectedColumn { get; }

		//- (NSInteger)selectedRow;
		[Export ("selectedRow")]
		int SelectedRow { get; }

		//- (BOOL)isColumnSelected:(NSInteger)column;
		[Export ("isColumnSelected:")]
		bool IsColumnSelected (int column);

		//- (BOOL)isRowSelected:(NSInteger)row;
		[Export ("isRowSelected:")]
		bool IsRowSelected (int row);

		//- (NSInteger)numberOfSelectedColumns;
		[Export ("numberOfSelectedColumns")]
		int NumberOfSelectedColumns { get; }

		//- (NSInteger)numberOfSelectedRows;
		[Export ("numberOfSelectedRows")]
		int NumberOfSelectedRows { get; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (BOOL)allowsTypeSelect;
		[Export ("allowsTypeSelect")]
		bool AllowsTypeSelect { get; set; }

		//- (NSTableViewSelectionHighlightStyle)selectionHighlightStyle;
		[Export ("selectionHighlightStyle")]
		NSTableViewSelectionHighlightStyle SelectionHighlightStyle { get; set; }

//#endif
		//- (NSRect)rectOfColumn:(NSInteger)column;
		[Export ("rectOfColumn:")]
		RectangleF RectOfColumn (int column);

		//- (NSRect)rectOfRow:(NSInteger)row;
		[Export ("rectOfRow:")]
		RectangleF RectOfRow (int row);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (NSIndexSet *)columnIndexesInRect:(NSRect)rect;
		[Export ("columnIndexesInRect:")]
		NSIndexSet ColumnIndexesInRect (RectangleF rect);

//#endif
		//- (NSRange)rowsInRect:(NSRect)rect;
		[Export ("rowsInRect:")]
		NSRange RowsInRect (RectangleF rect);

		//- (NSInteger)columnAtPoint:(NSPoint)point;
		[Export ("columnAtPoint:")]
		int ColumnAtPoint (PointF point);

		//- (NSInteger)rowAtPoint:(NSPoint)point;
		[Export ("rowAtPoint:")]
		int RowAtPoint (PointF point);

		//- (NSRect)frameOfCellAtColumn:(NSInteger)column row:(NSInteger)row;
		[Export ("frameOfCellAtColumn:row:")]
		RectangleF FrameOfCellAtColumn (int column, int row);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (NSCell *)preparedCellAtColumn:(NSInteger)column row:(NSInteger)row;
		[Export ("preparedCellAtColumn:row:")]
		NSCell PreparedCellAtColumn (int column, int row);

//#endif
		//- (BOOL)textShouldBeginEditing:(NSText *)textObject;
		[Export ("textShouldBeginEditing:")]
		bool TextShouldBeginEditing (NSText textObject);

		//- (BOOL)textShouldEndEditing:(NSText *)textObject;
		[Export ("textShouldEndEditing:")]
		bool TextShouldEndEditing (NSText textObject);

		//- (void)textDidBeginEditing:(NSNotification *)notification;
		[Export ("textDidBeginEditing:")]
		void TextDidBeginEditing (NSNotification notification);

		//- (void)textDidEndEditing:(NSNotification *)notification;
		[Export ("textDidEndEditing:")]
		void TextDidEndEditing (NSNotification notification);

		//- (void)textDidChange:(NSNotification *)notification;
		[Export ("textDidChange:")]
		void TextDidChange (NSNotification notification);

		//- (NSString *)autosaveName;
		[Export ("autosaveName")]
		string AutosaveName { get; set; }

		//- (BOOL)autosaveTableColumns;
		[Export ("autosaveTableColumns")]
		bool AutosaveTableColumns { get; set; }

		//- (void)editColumn:(NSInteger)column row:(NSInteger)row withEvent:(NSEvent *)theEvent select:(BOOL)select;
		[Export ("editColumn:row:withEvent:select:")]
		void EditColumn (int column, int row, NSEvent theEvent, bool select);

		//- (void)drawRow:(NSInteger)row clipRect:(NSRect)clipRect;
		[Export ("drawRow:clipRect:")]
		void DrawRow (int row, RectangleF clipRect);

		//- (void)highlightSelectionInClipRect:(NSRect)clipRect;
		[Export ("highlightSelectionInClipRect:")]
		void HighlightSelectionInClipRect (RectangleF clipRect);

		//- (void)drawGridInClipRect:(NSRect)clipRect;
		[Export ("drawGridInClipRect:")]
		void DrawGridInClipRect (RectangleF clipRect);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//- (void)drawBackgroundInClipRect:(NSRect)clipRect;
		[Export ("drawBackgroundInClipRect:")]
		void DrawBackgroundInClipRect (RectangleF clipRect);

//#endif
		////- (BOOL)drawsGrid;
		//[Export ("drawsGrid")]
		//bool DrawsGrid { get; set; }

		////- (void)selectColumn:(NSInteger)column byExtendingSelection:(BOOL)extend;
		//[Export ("selectColumn:byExtendingSelection:")]
		//void SelectColumnByExtendingSelection (int column, bool extend);

		////- (void)selectRow:(NSInteger)row byExtendingSelection:(BOOL)extend;
		//[Export ("selectRow:byExtendingSelection:")]
		//void SelectRowByExtendingSelection (int row, bool extend);

		////- (NSEnumerator *)selectedColumnEnumerator;
		//[Export ("selectedColumnEnumerator")]
		//NSEnumerator SelectedColumnEnumerator { get; }

		////- (NSEnumerator *)selectedRowEnumerator;
		//[Export ("selectedRowEnumerator")]
		//NSEnumerator SelectedRowEnumerator { get; }

		////- (NSImage*)dragImageForRows:(NSArray*)dragRows event:(NSEvent *)dragEvent dragImageOffset:(NSPointPointer)dragImageOffset;
		//[Export ("dragImageForRows:event:dragImageOffset:")]
		//NSImage DragImageForRowsEvent (NSArray dragRows, NSEvent dragEvent, NSPointPointer dragImageOffset);

		////- (BOOL)autoresizesAllColumnsToFit;
		//[Export ("autoresizesAllColumnsToFit")]
		//bool AutoresizesAllColumnsToFit { get; set; }

		////- (NSRange)columnsInRect:(NSRect)rect;
		//[Export ("columnsInRect:")]
		//NSRange ColumnsInRect (RectangleF rect);

	}
}
