using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSTextField))]
	interface NSTokenField {

		//- (NSTokenStyle)tokenStyle;
		[Export ("tokenStyle")]
		NSTokenStyle TokenStyle { get; set; }

		//- (NSTimeInterval)completionDelay;
		[Export ("completionDelay")]
		double CompletionDelay { get; set; }

		//+ (NSTimeInterval)defaultCompletionDelay;
		[Static, Export ("defaultCompletionDelay")]
		double DefaultCompletionDelay { get; }

		//- (NSCharacterSet *)tokenizingCharacterSet;
		[Export ("tokenizingCharacterSet")]
		NSCharacterSet TokenizingCharacterSet { get; set; }

		//+ (NSCharacterSet *)defaultTokenizingCharacterSet;
		[Static, Export ("defaultTokenizingCharacterSet")]
		NSCharacterSet DefaultTokenizingCharacterSet { get; }

	}
}
