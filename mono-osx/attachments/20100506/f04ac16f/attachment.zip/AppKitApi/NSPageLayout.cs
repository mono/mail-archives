using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSObject))]
	interface NSPageLayout {

//#if __LP64__
//#endif
		//+ (NSPageLayout *)pageLayout;
		[Static, Export ("pageLayout")]
		NSPageLayout PageLayout { get; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (void)addAccessoryController:(NSViewController *)accessoryController;
		[Export ("addAccessoryController:")]
		void AddAccessoryController (NSViewController accessoryController);

		//- (void)removeAccessoryController:(NSViewController *)accessoryController;
		[Export ("removeAccessoryController:")]
		void RemoveAccessoryController (NSViewController accessoryController);

		//- (NSArray *)accessoryControllers;
		[Export ("accessoryControllers")]
		NSArray AccessoryControllers { get; }

//#endif
		//- (void)beginSheetWithPrintInfo:(NSPrintInfo *)printInfo modalForWindow:(NSWindow *)docWindow delegate:(id)delegate didEndSelector:(SEL)didEndSelector contextInfo:(void *)contextInfo;
		[Export ("beginSheetWithPrintInfo:modalForWindow:delegate:didEndSelector:contextInfo:")]
		void BeginSheetWithPrintInfo (NSPrintInfo printInfo, NSWindow docWindow, NSObject delegate1, Selector didEndSelector, IntPtr contextInfo);

		//- (NSInteger)runModalWithPrintInfo:(NSPrintInfo *)printInfo;
		[Export ("runModalWithPrintInfo:")]
		int RunModalWithPrintInfo (NSPrintInfo printInfo);

		//- (NSInteger)runModal;
		[Export ("runModal")]
		int RunModal { get; }

		//- (NSPrintInfo *)printInfo;
		[Export ("printInfo")]
		NSPrintInfo PrintInfo { get; }

		////- (NSView *)accessoryView;
		//[Export ("accessoryView")]
		//NSView AccessoryView { get; set; }

		////- (void)readPrintInfo;
		//[Export ("readPrintInfo")]
		//void ReadPrintInfo ();

		////- (void)writePrintInfo;
		//[Export ("writePrintInfo")]
		//void WritePrintInfo ();

	}
}
