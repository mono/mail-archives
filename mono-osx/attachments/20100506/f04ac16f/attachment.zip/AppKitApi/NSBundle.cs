using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{
	interface NSBundle {

		//+ (BOOL)loadNibFile:(NSString *)fileName externalNameTable:(NSDictionary *)context withZone:(NSZone *)zone;
		[Static, Export ("loadNibFile:externalNameTable:withZone:")]
		bool LoadNibFileExternalNameTable (string fileName, NSDictionary context, NSZone zone);

		//    + (BOOL)loadNibNamed:(NSString *)nibName owner:(id)owner;
		[Export ("loadNibNamed:owner:")]
		bool LoadNibNamedOwner (string nibName, NSObject owner);

		//    - (BOOL)loadNibFile:(NSString *)fileName externalNameTable:(NSDictionary *)context withZone:(NSZone *)zone;
		[Export ("loadNibFile:externalNameTable:withZone:")]
		bool LoadNibFileExternalNameTable (string fileName, NSDictionary context, NSZone zone);

		//- (NSString *)pathForSoundResource:(NSString *)name;
		[Export ("pathForSoundResource:")]
		string PathForSoundResource (string name);

	}
}
