using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{
	interface NSObject {

		//- (NSArray *)accessibilityAttributeNames;
		[Export ("accessibilityAttributeNames")]
		NSArray AccessibilityAttributeNames { get; }

		//- (id)accessibilityAttributeValue:(NSString *)attribute;
		[Export ("accessibilityAttributeValue:")]
		NSObject AccessibilityAttributeValue (string attribute);

		//- (BOOL)accessibilityIsAttributeSettable:(NSString *)attribute;
		[Export ("accessibilityIsAttributeSettable:")]
		bool AccessibilityIsAttributeSettable (string attribute);

		//- (void)accessibilitySetValue:(id)value forAttribute:(NSString *)attribute;
		[Export ("accessibilitySetValue:forAttribute:")]
		void AccessibilitySetValueForAttribute (NSObject value, string attribute);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//- (NSArray *)accessibilityParameterizedAttributeNames;
		[Export ("accessibilityParameterizedAttributeNames")]
		NSArray AccessibilityParameterizedAttributeNames { get; }

		//- (id)accessibilityAttributeValue:(NSString *)attribute forParameter:(id)parameter;
		[Export ("accessibilityAttributeValue:forParameter:")]
		NSObject AccessibilityAttributeValueForParameter (string attribute, NSObject parameter);

//#endif
		//- (NSArray *)accessibilityActionNames;
		[Export ("accessibilityActionNames")]
		NSArray AccessibilityActionNames { get; }

		//- (NSString *)accessibilityActionDescription:(NSString *)action;
		[Export ("accessibilityActionDescription:")]
		string AccessibilityActionDescription (string action);

		//- (void)accessibilityPerformAction:(NSString *)action;
		[Export ("accessibilityPerformAction:")]
		void AccessibilityPerformAction (string action);

		//- (BOOL)accessibilityIsIgnored;
		[Export ("accessibilityIsIgnored")]
		bool AccessibilityIsIgnored { get; }

		//- (id)accessibilityHitTest:(NSPoint)point;
		[Export ("accessibilityHitTest:")]
		NSObject AccessibilityHitTest (PointF point);

		//- (id)accessibilityFocusedUIElement;
		[Export ("accessibilityFocusedUIElement")]
		NSObject AccessibilityFocusedUIElement { get; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (BOOL)accessibilitySetOverrideValue:(id)value forAttribute:(NSString *)attribute;
		[Export ("accessibilitySetOverrideValue:forAttribute:")]
		bool AccessibilitySetOverrideValueForAttribute (NSObject value, string attribute);

//#endif
		//- (BOOL)alertShowHelp:(NSAlert *)alert;
		[Export ("alertShowHelp:")]
		bool AlertShowHelp (NSAlert alert);

		//- (void)animationDidStop:(NSAnimation*)animation;
		[Export ("animationDidStop:")]
		void AnimationDidStop (NSAnimation animation);

		//- (void)animationDidEnd:(NSAnimation*)animation;
		[Export ("animationDidEnd:")]
		void AnimationDidEnd (NSAnimation animation);

		//- (float)animation:(NSAnimation*)animation valueForProgress:(NSAnimationProgress)progress;
		[Export ("animation:valueForProgress:")]
		float AnimationValueForProgress (NSAnimation animation, float progress);

		//- (void)animation:(NSAnimation*)animation didReachProgressMark:(NSAnimationProgress)progress;
		[Export ("animation:didReachProgressMark:")]
		void AnimationDidReachProgressMark (NSAnimation animation, float progress);

		//- (void)applicationDidFinishLaunching:(NSNotification *)notification;
		[Export ("applicationDidFinishLaunching:")]
		void ApplicationDidFinishLaunching (NSNotification notification);

		//- (void)applicationWillHide:(NSNotification *)notification;
		[Export ("applicationWillHide:")]
		void ApplicationWillHide (NSNotification notification);

		//- (void)applicationDidHide:(NSNotification *)notification;
		[Export ("applicationDidHide:")]
		void ApplicationDidHide (NSNotification notification);

		//- (void)applicationWillUnhide:(NSNotification *)notification;
		[Export ("applicationWillUnhide:")]
		void ApplicationWillUnhide (NSNotification notification);

		//- (void)applicationDidUnhide:(NSNotification *)notification;
		[Export ("applicationDidUnhide:")]
		void ApplicationDidUnhide (NSNotification notification);

		//- (void)applicationWillBecomeActive:(NSNotification *)notification;
		[Export ("applicationWillBecomeActive:")]
		void ApplicationWillBecomeActive (NSNotification notification);

		//- (void)applicationDidBecomeActive:(NSNotification *)notification;
		[Export ("applicationDidBecomeActive:")]
		void ApplicationDidBecomeActive (NSNotification notification);

		//- (void)applicationWillResignActive:(NSNotification *)notification;
		[Export ("applicationWillResignActive:")]
		void ApplicationWillResignActive (NSNotification notification);

		//- (void)applicationDidResignActive:(NSNotification *)notification;
		[Export ("applicationDidResignActive:")]
		void ApplicationDidResignActive (NSNotification notification);

		//- (void)applicationWillUpdate:(NSNotification *)notification;
		[Export ("applicationWillUpdate:")]
		void ApplicationWillUpdate (NSNotification notification);

		//- (void)applicationDidUpdate:(NSNotification *)notification;
		[Export ("applicationDidUpdate:")]
		void ApplicationDidUpdate (NSNotification notification);

		//- (void)applicationWillTerminate:(NSNotification *)notification;
		[Export ("applicationWillTerminate:")]
		void ApplicationWillTerminate (NSNotification notification);

		//- (void)applicationDidChangeScreenParameters:(NSNotification *)notification;
		[Export ("applicationDidChangeScreenParameters:")]
		void ApplicationDidChangeScreenParameters (NSNotification notification);

		//- (NSApplicationTerminateReply)applicationShouldTerminate:(NSApplication *)sender;
		[Export ("applicationShouldTerminate:")]
		NSApplicationTerminateReply ApplicationShouldTerminate (NSApplication sender);

		//- (BOOL)application:(NSApplication *)sender openFile:(NSString *)filename;
		[Export ("application:openFile:")]
		bool ApplicationOpenFile (NSApplication sender, string filename);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//- (void)application:(NSApplication *)sender openFiles:(NSArray *)filenames;
		[Export ("application:openFiles:")]
		void ApplicationOpenFiles (NSApplication sender, NSArray filenames);

//#endif
		//- (BOOL)application:(NSApplication *)sender openTempFile:(NSString *)filename;
		[Export ("application:openTempFile:")]
		bool ApplicationOpenTempFile (NSApplication sender, string filename);

		//- (BOOL)applicationShouldOpenUntitledFile:(NSApplication *)sender;
		[Export ("applicationShouldOpenUntitledFile:")]
		bool ApplicationShouldOpenUntitledFile (NSApplication sender);

		//- (BOOL)applicationOpenUntitledFile:(NSApplication *)sender;
		[Export ("applicationOpenUntitledFile:")]
		bool ApplicationOpenUntitledFile (NSApplication sender);

		//- (BOOL)application:(id)sender openFileWithoutUI:(NSString *)filename;
		[Export ("application:openFileWithoutUI:")]
		bool ApplicationOpenFileWithoutUI (NSObject sender, string filename);

		//- (BOOL)application:(NSApplication *)sender printFile:(NSString *)filename;
		[Export ("application:printFile:")]
		bool ApplicationPrintFile (NSApplication sender, string filename);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (NSApplicationPrintReply)application:(NSApplication *)application printFiles:(NSArray *)fileNames withSettings:(NSDictionary *)printSettings showPrintPanels:(BOOL)showPrintPanels;
		[Export ("application:printFiles:withSettings:showPrintPanels:")]
		NSApplicationPrintReply ApplicationPrintFiles (NSApplication application, NSArray fileNames, NSDictionary printSettings, bool showPrintPanels);

//#endif
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//- (void)application:(NSApplication *)sender printFiles:(NSArray *)filenames;
		[Export ("application:printFiles:")]
		void ApplicationPrintFiles (NSApplication sender, NSArray filenames);

//#endif
		//- (BOOL)applicationShouldTerminateAfterLastWindowClosed:(NSApplication *)sender;
		[Export ("applicationShouldTerminateAfterLastWindowClosed:")]
		bool ApplicationShouldTerminateAfterLastWindowClosed (NSApplication sender);

		//- (BOOL)applicationShouldHandleReopen:(NSApplication *)sender hasVisibleWindows:(BOOL)flag;
		[Export ("applicationShouldHandleReopen:hasVisibleWindows:")]
		bool ApplicationShouldHandleReopenHasVisibleWindows (NSApplication sender, bool flag);

		//- (NSMenu *)applicationDockMenu:(NSApplication *)sender;
		[Export ("applicationDockMenu:")]
		NSMenu ApplicationDockMenu (NSApplication sender);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (NSError *)application:(NSApplication *)application willPresentError:(NSError *)error;
		[Export ("application:willPresentError:")]
		NSError ApplicationWillPresentError (NSApplication application, NSError error);

//#endif
		//- (BOOL)readSelectionFromPasteboard:(NSPasteboard *)pboard;
		[Export ("readSelectionFromPasteboard:")]
		bool ReadSelectionFromPasteboard (NSPasteboard pboard);

		//- (BOOL)application:(NSApplication *)sender delegateHandlesKey:(NSString *)key;
		[Export ("application:delegateHandlesKey:")]
		bool ApplicationDelegateHandlesKey (NSApplication sender, string key);

		//- (NSInteger)browser:(NSBrowser *)sender numberOfRowsInColumn:(NSInteger)column;
		[Export ("browser:numberOfRowsInColumn:")]
		int BrowserNumberOfRowsInColumn (NSBrowser sender, int column);

		//- (void)browser:(NSBrowser *)sender createRowsForColumn:(NSInteger)column inMatrix:(NSMatrix *)matrix;
		[Export ("browser:createRowsForColumn:inMatrix:")]
		void BrowserCreateRowsForColumn (NSBrowser sender, int column, NSMatrix matrix);

		//- (void)browser:(NSBrowser *)sender willDisplayCell:(id)cell atRow:(NSInteger)row column:(NSInteger)column;
		[Export ("browser:willDisplayCell:atRow:column:")]
		void BrowserWillDisplayCell (NSBrowser sender, NSObject cell, int row, int column);

		//- (NSString *)browser:(NSBrowser *)sender titleOfColumn:(NSInteger)column;
		[Export ("browser:titleOfColumn:")]
		string BrowserTitleOfColumn (NSBrowser sender, int column);

		//- (BOOL)browser:(NSBrowser *)sender selectCellWithString:(NSString *)title inColumn:(NSInteger)column;
		[Export ("browser:selectCellWithString:inColumn:")]
		bool BrowserSelectCellWithString (NSBrowser sender, string title, int column);

		//- (BOOL)browser:(NSBrowser *)sender selectRow:(NSInteger)row inColumn:(NSInteger)column;
		[Export ("browser:selectRow:inColumn:")]
		bool BrowserSelectRow (NSBrowser sender, int row, int column);

		//- (BOOL)browser:(NSBrowser *)sender isColumnValid:(NSInteger)column;
		[Export ("browser:isColumnValid:")]
		bool BrowserIsColumnValid (NSBrowser sender, int column);

		//- (void)browserWillScroll:(NSBrowser *)sender;
		[Export ("browserWillScroll:")]
		void BrowserWillScroll (NSBrowser sender);

		//- (void)browserDidScroll:(NSBrowser *)sender;
		[Export ("browserDidScroll:")]
		void BrowserDidScroll (NSBrowser sender);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//- (CGFloat)browser:(NSBrowser *)browser shouldSizeColumn:(NSInteger)columnIndex forUserResize:(BOOL)forUserResize toWidth:(CGFloat)suggestedWidth;
		[Export ("browser:shouldSizeColumn:forUserResize:toWidth:")]
		float BrowserShouldSizeColumn (NSBrowser browser, int columnIndex, bool forUserResize, float suggestedWidth);

		//- (CGFloat)browser:(NSBrowser *)browser sizeToFitWidthOfColumn:(NSInteger)columnIndex;
		[Export ("browser:sizeToFitWidthOfColumn:")]
		float BrowserSizeToFitWidthOfColumn (NSBrowser browser, int columnIndex);

		//- (void)browserColumnConfigurationDidChange:(NSNotification *)notification;
		[Export ("browserColumnConfigurationDidChange:")]
		void BrowserColumnConfigurationDidChange (NSNotification notification);

//#endif  
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (BOOL)browser:(NSBrowser *)browser shouldShowCellExpansionForRow:(NSInteger)row column:(NSInteger)column;
		[Export ("browser:shouldShowCellExpansionForRow:column:")]
		bool BrowserShouldShowCellExpansionForRow (NSBrowser browser, int row, int column);

		//#pragma mark -#pragma mark **** Optional Drag and Drop Support Methods ****#pragma mark ** Dragging Source Methods **- (BOOL)browser:(NSBrowser *)browser writeRowsWithIndexes:(NSIndexSet *)rowIndexes inColumn:(NSInteger)column toPasteboard:(NSPasteboard *)pasteboard;
		[Export ("browser:writeRowsWithIndexes:inColumn:toPasteboard:")]
		bool BrowserWriteRowsWithIndexes (NSBrowser browser, NSIndexSet rowIndexes, int column, NSPasteboard pasteboard);

		//- (NSArray *)browser:(NSBrowser *)browser namesOfPromisedFilesDroppedAtDestination:(NSURL *)dropDestination forDraggedRowsWithIndexes:(NSIndexSet *)rowIndexes inColumn:(NSInteger)column;
		[Export ("browser:namesOfPromisedFilesDroppedAtDestination:forDraggedRowsWithIndexes:inColumn:")]
		NSArray BrowserNamesOfPromisedFilesDroppedAtDestination (NSBrowser browser, NSUrl dropDestination, NSIndexSet rowIndexes, int column);

		//- (BOOL)browser:(NSBrowser *)browser canDragRowsWithIndexes:(NSIndexSet *)rowIndexes inColumn:(NSInteger)column withEvent:(NSEvent *)event;
		[Export ("browser:canDragRowsWithIndexes:inColumn:withEvent:")]
		bool BrowserCanDragRowsWithIndexes (NSBrowser browser, NSIndexSet rowIndexes, int column, NSEvent event1);

		//- (NSImage *)browser:(NSBrowser *)browser draggingImageForRowsWithIndexes:(NSIndexSet *)rowIndexes inColumn:(NSInteger)column withEvent:(NSEvent *)event offset:(NSPointPointer)dragImageOffset;
		[Export ("browser:draggingImageForRowsWithIndexes:inColumn:withEvent:offset:")]
		NSImage BrowserDraggingImageForRowsWithIndexes (NSBrowser browser, NSIndexSet rowIndexes, int column, NSEvent event1, NSPointPointer dragImageOffset);

		//#pragma mark ** Dragging Destination Methods **- (NSDragOperation)browser:(NSBrowser *)browser validateDrop:(id <NSDraggingInfo>)info proposedRow:(NSInteger *)row column:(NSInteger *)column  dropOperation:(NSBrowserDropOperation *)dropOperation;
		[Export ("browser:validateDrop:proposedRow:column:dropOperation:")]
		NSDragOperation BrowserValidateDrop (NSBrowser browser, NSObject info, int row, int column, NSBrowserDropOperation dropOperation);

		//- (BOOL)browser:(NSBrowser *)browser acceptDrop:(id <NSDraggingInfo>)info atRow:(NSInteger)row column:(NSInteger)column dropOperation:(NSBrowserDropOperation)dropOperation;
		[Export ("browser:acceptDrop:atRow:column:dropOperation:")]
		bool BrowserAcceptDrop (NSBrowser browser, NSObject info, int row, int column, NSBrowserDropOperation dropOperation);

		//#pragma mark -#pragma mark **** Type Select Support ****- (NSString *)browser:(NSBrowser *)browser typeSelectStringForRow:(NSInteger)row inColumn:(NSInteger)column;
		[Export ("browser:typeSelectStringForRow:inColumn:")]
		string BrowserTypeSelectStringForRow (NSBrowser browser, int row, int column);

		//- (BOOL)browser:(NSBrowser *)browser shouldTypeSelectForEvent:(NSEvent *)event withCurrentSearchString:(NSString *)searchString;
		[Export ("browser:shouldTypeSelectForEvent:withCurrentSearchString:")]
		bool BrowserShouldTypeSelectForEvent (NSBrowser browser, NSEvent event1, string searchString);

		//- (NSInteger)browser:(NSBrowser *)browser nextTypeSelectMatchFromRow:(NSInteger)startRow toRow:(NSInteger)endRow inColumn:(NSInteger)column forString:(NSString *)searchString;
		[Export ("browser:nextTypeSelectMatchFromRow:toRow:inColumn:forString:")]
		int BrowserNextTypeSelectMatchFromRow (NSBrowser browser, int startRow, int endRow, int column, string searchString);

//#endif 
		//- (id)comboBox:(NSComboBox *)aComboBox objectValueForItemAtIndex:(NSInteger)index;
		[Export ("comboBox:objectValueForItemAtIndex:")]
		NSObject ComboBoxObjectValueForItemAtIndex (NSComboBox aComboBox, int index);

		//- (NSUInteger)comboBox:(NSComboBox *)aComboBox indexOfItemWithStringValue:(NSString *)string;
		[Export ("comboBox:indexOfItemWithStringValue:")]
		uint ComboBoxIndexOfItemWithStringValue (NSComboBox aComboBox, string string1);

		//- (NSString *)comboBox:(NSComboBox *)aComboBox completedString:(NSString *)string;
		[Export ("comboBox:completedString:")]
		string ComboBoxCompletedString (NSComboBox aComboBox, string string1);

		//- (void)comboBoxWillDismiss:(NSNotification *)notification;
		[Export ("comboBoxWillDismiss:")]
		void ComboBoxWillDismiss (NSNotification notification);

		//- (void)comboBoxSelectionDidChange:(NSNotification *)notification;
		[Export ("comboBoxSelectionDidChange:")]
		void ComboBoxSelectionDidChange (NSNotification notification);

		//- (void)comboBoxSelectionIsChanging:(NSNotification *)notification;
		[Export ("comboBoxSelectionIsChanging:")]
		void ComboBoxSelectionIsChanging (NSNotification notification);

		//- (id)comboBoxCell:(NSComboBoxCell *)aComboBoxCell objectValueForItemAtIndex:(NSInteger)index;
		[Export ("comboBoxCell:objectValueForItemAtIndex:")]
		NSObject ComboBoxCellObjectValueForItemAtIndex (NSComboBoxCell aComboBoxCell, int index);

		//- (NSUInteger)comboBoxCell:(NSComboBoxCell *)aComboBoxCell indexOfItemWithStringValue:(NSString *)string;
		[Export ("comboBoxCell:indexOfItemWithStringValue:")]
		uint ComboBoxCellIndexOfItemWithStringValue (NSComboBoxCell aComboBoxCell, string string1);

		//- (NSString *)comboBoxCell:(NSComboBoxCell *)aComboBoxCell completedString:(NSString *)uncompletedString; 
		[Export ("comboBoxCell:completedString:")]
		string ComboBoxCellCompletedString (NSComboBoxCell aComboBoxCell, string uncompletedString);

		//- (void)controlTextDidBeginEditing:(NSNotification *)obj;
		[Export ("controlTextDidBeginEditing:")]
		void ControlTextDidBeginEditing (NSNotification obj);

		//- (void)controlTextDidEndEditing:(NSNotification *)obj;
		[Export ("controlTextDidEndEditing:")]
		void ControlTextDidEndEditing (NSNotification obj);

		//- (void)controlTextDidChange:(NSNotification *)obj;
		[Export ("controlTextDidChange:")]
		void ControlTextDidChange (NSNotification obj);

		//- (BOOL)control:(NSControl *)control textShouldBeginEditing:(NSText *)fieldEditor;
		[Export ("control:textShouldBeginEditing:")]
		bool ControlTextShouldBeginEditing (NSControl control, NSText fieldEditor);

		//- (BOOL)control:(NSControl *)control textShouldEndEditing:(NSText *)fieldEditor;
		[Export ("control:textShouldEndEditing:")]
		bool ControlTextShouldEndEditing (NSControl control, NSText fieldEditor);

		//- (BOOL)control:(NSControl *)control didFailToFormatString:(NSString *)string errorDescription:(NSString *)error;
		[Export ("control:didFailToFormatString:errorDescription:")]
		bool ControlDidFailToFormatString (NSControl control, string string1, string error);

		//- (void)control:(NSControl *)control didFailToValidatePartialString:(NSString *)string errorDescription:(NSString *)error;
		[Export ("control:didFailToValidatePartialString:errorDescription:")]
		void ControlDidFailToValidatePartialString (NSControl control, string string1, string error);

		//- (BOOL)control:(NSControl *)control isValidObject:(id)obj;
		[Export ("control:isValidObject:")]
		bool ControlIsValidObject (NSControl control, NSObject obj);

		//- (BOOL)control:(NSControl *)control textView:(NSTextView *)textView doCommandBySelector:(SEL)commandSelector;
		[Export ("control:textView:doCommandBySelector:")]
		bool ControlTextView (NSControl control, NSTextView textView, Selector commandSelector);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//- (NSArray *)control:(NSControl *)control textView:(NSTextView *)textView completions:(NSArray *)words forPartialWordRange:(NSRange)charRange indexOfSelectedItem:(NSInteger *)index;
		[Export ("control:textView:completions:forPartialWordRange:indexOfSelectedItem:")]
		NSArray ControlTextView (NSControl control, NSTextView textView, NSArray words, NSRange charRange, int index);

//#endif
		//- (NSString *)localizedKey;
		[Export ("localizedKey")]
		string LocalizedKey { get; set; }

		//- (NSString *)key;
		[Export ("key")]
		string Key { get; set; }

		//- (id)value;
		[Export ("value")]
		NSObject Value { get; set; }

		//- (BOOL)isExplicitlyIncluded;
		[Export ("isExplicitlyIncluded")]
		bool IsExplicitlyIncluded { get; }

		//- (NSDragOperation)draggingUpdated:(id <NSDraggingInfo>)sender; 
		[Export ("draggingUpdated:")]
		NSDragOperation DraggingUpdated (NSObject sender);

		//- (void)draggingExited:(id <NSDraggingInfo>)sender;
		[Export ("draggingExited:")]
		void DraggingExited (NSObject sender);

		//- (BOOL)prepareForDragOperation:(id <NSDraggingInfo>)sender;
		[Export ("prepareForDragOperation:")]
		bool PrepareForDragOperation (NSObject sender);

		//- (BOOL)performDragOperation:(id <NSDraggingInfo>)sender;
		[Export ("performDragOperation:")]
		bool PerformDragOperation (NSObject sender);

		//- (void)concludeDragOperation:(id <NSDraggingInfo>)sender;
		[Export ("concludeDragOperation:")]
		void ConcludeDragOperation (NSObject sender);

		//- (void)draggingEnded:(id <NSDraggingInfo>)sender;
		[Export ("draggingEnded:")]
		void DraggingEnded (NSObject sender);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (BOOL)wantsPeriodicDraggingUpdates;
		[Export ("wantsPeriodicDraggingUpdates")]
		bool WantsPeriodicDraggingUpdates { get; }

//#endif
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_2
		//- (NSArray *)namesOfPromisedFilesDroppedAtDestination:(NSURL *)dropDestination;
		[Export ("namesOfPromisedFilesDroppedAtDestination:")]
		NSArray NamesOfPromisedFilesDroppedAtDestination (NSUrl dropDestination);

//#endif
		//- (void)draggedImage:(NSImage *)image beganAt:(NSPoint)screenPoint;
		[Export ("draggedImage:beganAt:")]
		void DraggedImageBeganAt (NSImage image, PointF screenPoint);

		//- (void)draggedImage:(NSImage *)image endedAt:(NSPoint)screenPoint operation:(NSDragOperation)operation;
		[Export ("draggedImage:endedAt:operation:")]
		void DraggedImageEndedAt (NSImage image, PointF screenPoint, NSDragOperation operation);

		//- (void)draggedImage:(NSImage *)image movedTo:(NSPoint)screenPoint;
		[Export ("draggedImage:movedTo:")]
		void DraggedImageMovedTo (NSImage image, PointF screenPoint);

		//- (BOOL)ignoreModifierKeysWhileDragging;
		[Export ("ignoreModifierKeysWhileDragging")]
		bool IgnoreModifierKeysWhileDragging { get; }

		//- (void)draggedImage:(NSImage *)image endedAt:(NSPoint)screenPoint deposited:(BOOL)flag;
		[Export ("draggedImage:endedAt:deposited:")]
		void DraggedImageEndedAt (NSImage image, PointF screenPoint, bool flag);

		//- (void)drawerDidOpen:(NSNotification *)notification;
		[Export ("drawerDidOpen:")]
		void DrawerDidOpen (NSNotification notification);

		//- (void)drawerWillClose:(NSNotification *)notification;
		[Export ("drawerWillClose:")]
		void DrawerWillClose (NSNotification notification);

		//- (void)drawerDidClose:(NSNotification *)notification;
		[Export ("drawerDidClose:")]
		void DrawerDidClose (NSNotification notification);

		//- (BOOL)drawerShouldClose:(NSDrawer *)sender;
		[Export ("drawerShouldClose:")]
		bool DrawerShouldClose (NSDrawer sender);

		//- (NSSize)drawerWillResizeContents:(NSDrawer *)sender toSize:(NSSize)contentSize;
		[Export ("drawerWillResizeContents:toSize:")]
		NSSize DrawerWillResizeContentsToSize (NSDrawer sender, NSSize contentSize);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_2
		//- (void)image:(NSImage*)image willLoadRepresentation:(NSImageRep*)rep;
		[Export ("image:willLoadRepresentation:")]
		void ImageWillLoadRepresentation (NSImage image, NSImageRep rep);

		//- (void)image:(NSImage*)image didLoadRepresentationHeader:(NSImageRep*)rep;
		[Export ("image:didLoadRepresentationHeader:")]
		void ImageDidLoadRepresentationHeader (NSImage image, NSImageRep rep);

		//- (void)image:(NSImage*)image didLoadPartOfRepresentation:(NSImageRep*)rep withValidRows:(NSInteger)rows; 
		[Export ("image:didLoadPartOfRepresentation:withValidRows:")]
		void ImageDidLoadPartOfRepresentation (NSImage image, NSImageRep rep, int rows);

		//- (void)image:(NSImage*)image didLoadRepresentation:(NSImageRep*)rep withStatus:(NSImageLoadStatus)status;
		[Export ("image:didLoadRepresentation:withStatus:")]
		void ImageDidLoadRepresentation (NSImage image, NSImageRep rep, NSImageLoadStatus status);

//#endif
		//+ (void)exposeBinding:(NSString *)binding;    
		[Static, Export ("exposeBinding:")]
		void ExposeBinding (string binding);

		//- (NSArray *)exposedBindings;   
		[Export ("exposedBindings")]
		NSArray ExposedBindings { get; }

		//- (Class)valueClassForBinding:(NSString *)binding;    
		[Export ("valueClassForBinding:")]
		Class ValueClassForBinding (string binding);

		//- (void)bind:(NSString *)binding toObject:(id)observable withKeyPath:(NSString *)keyPath options:(NSDictionary *)options;    
		[Export ("bind:toObject:withKeyPath:options:")]
		void BindToObject (string binding, NSObject observable, string keyPath, NSDictionary options);

		//- (void)unbind:(NSString *)binding;
		[Export ("unbind:")]
		void Unbind (string binding);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (NSDictionary *)infoForBinding:(NSString *)binding;
		[Export ("infoForBinding:")]
		NSDictionary InfoForBinding (string binding);

//#endif
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (NSArray *)optionDescriptionsForBinding:(NSString *)aBinding;
		[Export ("optionDescriptionsForBinding:")]
		NSArray OptionDescriptionsForBinding (string aBinding);

//#endif
		//+ (void)setDefaultPlaceholder:(id)placeholder forMarker:(id)marker withBinding:(NSString *)binding;    
		[Static, Export ("setDefaultPlaceholder:forMarker:withBinding:")]
		void SetDefaultPlaceholderForMarker (NSObject placeholder, NSObject marker, string binding);

		//+ (id)defaultPlaceholderForMarker:(id)marker withBinding:(NSString *)binding;    
		[Static, Export ("defaultPlaceholderForMarker:withBinding:")]
		NSObject DefaultPlaceholderForMarkerWithBinding (NSObject marker, string binding);

		//- (void)objectDidBeginEditing:(id)editor;
		[Export ("objectDidBeginEditing:")]
		void ObjectDidBeginEditing (NSObject editor);

		//- (void)objectDidEndEditing:(id)editor;
		[Export ("objectDidEndEditing:")]
		void ObjectDidEndEditing (NSObject editor);

		//- (void)discardEditing;    
		[Export ("discardEditing")]
		void DiscardEditing ();

		//- (BOOL)commitEditing;    
		[Export ("commitEditing")]
		bool CommitEditing { get; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (void)commitEditingWithDelegate:(id)delegate didCommitSelector:(SEL)didCommitSelector contextInfo:(void *)contextInfo;
		[Export ("commitEditingWithDelegate:didCommitSelector:contextInfo:")]
		void CommitEditingWithDelegateDidCommitSelector (NSObject delegate1, Selector didCommitSelector, IntPtr contextInfo);

//#endif
		//- (void)layoutManagerDidInvalidateLayout:(NSLayoutManager *)sender;
		[Export ("layoutManagerDidInvalidateLayout:")]
		void LayoutManagerDidInvalidateLayout (NSLayoutManager sender);

		//    - (void)layoutManager:(NSLayoutManager *)layoutManager didCompleteLayoutForTextContainer:(NSTextContainer *)textContainer atEnd:(BOOL)layoutFinishedFlag;
		[Export ("layoutManager:didCompleteLayoutForTextContainer:atEnd:")]
		void LayoutManagerDidCompleteLayoutForTextContainer (NSLayoutManager layoutManager, NSTextContainer textContainer, bool layoutFinishedFlag);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//    - (NSDictionary *)layoutManager:(NSLayoutManager *)layoutManager shouldUseTemporaryAttributes:(NSDictionary *)attrs forDrawingToScreen:(BOOL)toScreen atCharacterIndex:(NSUInteger)charIndex effectiveRange:(NSRangePointer)effectiveCharRange;
		[Export ("layoutManager:shouldUseTemporaryAttributes:forDrawingToScreen:atCharacterIndex:effectiveRange:")]
		NSDictionary LayoutManagerShouldUseTemporaryAttributes (NSLayoutManager layoutManager, NSDictionary attrs, bool toScreen, uint charIndex, NSRangePointer effectiveCharRange);

//#endif 
		//- (NSInteger)numberOfItemsInMenu:(NSMenu*)menu;
		[Export ("numberOfItemsInMenu:")]
		int NumberOfItemsInMenu (NSMenu menu);

		//- (BOOL)menu:(NSMenu*)menu updateItem:(NSMenuItem*)item atIndex:(NSInteger)index shouldCancel:(BOOL)shouldCancel;
		[Export ("menu:updateItem:atIndex:shouldCancel:")]
		bool MenuUpdateItem (NSMenu menu, NSMenuItem item, int index, bool shouldCancel);

		//    - (BOOL)menuHasKeyEquivalent:(NSMenu*)menu forEvent:(NSEvent*)event target:(id*)target action:(SEL*)action;
		[Export ("menuHasKeyEquivalent:forEvent:target:action:")]
		bool MenuHasKeyEquivalentForEvent (NSMenu menu, NSEvent event1, NSObject target, Selector action);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//    - (void)menuWillOpen:(NSMenu *)menu;
		[Export ("menuWillOpen:")]
		void MenuWillOpen (NSMenu menu);

		//- (void)menuDidClose:(NSMenu *)menu;
		[Export ("menuDidClose:")]
		void MenuDidClose (NSMenu menu);

		//- (void)menu:(NSMenu *)menu willHighlightItem:(NSMenuItem *)item;
		[Export ("menu:willHighlightItem:")]
		void MenuWillHighlightItem (NSMenu menu, NSMenuItem item);

//#endif
		//- (id)outlineView:(NSOutlineView *)outlineView child:(NSInteger)index ofItem:(id)item;
		[Export ("outlineView:child:ofItem:")]
		NSObject OutlineViewChild (NSOutlineView outlineView, int index, NSObject item);

		//- (BOOL)outlineView:(NSOutlineView *)outlineView isItemExpandable:(id)item;
		[Export ("outlineView:isItemExpandable:")]
		bool OutlineViewIsItemExpandable (NSOutlineView outlineView, NSObject item);

		//- (NSInteger)outlineView:(NSOutlineView *)outlineView numberOfChildrenOfItem:(id)item;
		[Export ("outlineView:numberOfChildrenOfItem:")]
		int OutlineViewNumberOfChildrenOfItem (NSOutlineView outlineView, NSObject item);

		//- (id)outlineView:(NSOutlineView *)outlineView objectValueForTableColumn:(NSTableColumn *)tableColumn byItem:(id)item;
		[Export ("outlineView:objectValueForTableColumn:byItem:")]
		NSObject OutlineViewObjectValueForTableColumn (NSOutlineView outlineView, NSTableColumn tableColumn, NSObject item);

		//- (void)outlineView:(NSOutlineView *)outlineView setObjectValue:(id)object forTableColumn:(NSTableColumn *)tableColumn byItem:(id)item;
		[Export ("outlineView:setObjectValue:forTableColumn:byItem:")]
		void OutlineViewSetObjectValue (NSOutlineView outlineView, NSObject object1, NSTableColumn tableColumn, NSObject item);

		//- (id)outlineView:(NSOutlineView *)outlineView itemForPersistentObject:(id)object;
		[Export ("outlineView:itemForPersistentObject:")]
		NSObject OutlineViewItemForPersistentObject (NSOutlineView outlineView, NSObject object1);

		//- (id)outlineView:(NSOutlineView *)outlineView persistentObjectForItem:(id)item;
		[Export ("outlineView:persistentObjectForItem:")]
		NSObject OutlineViewPersistentObjectForItem (NSOutlineView outlineView, NSObject item);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//- (void)outlineView:(NSOutlineView *)outlineView sortDescriptorsDidChange:(NSArray *)oldDescriptors;
		[Export ("outlineView:sortDescriptorsDidChange:")]
		void OutlineViewSortDescriptorsDidChange (NSOutlineView outlineView, NSArray oldDescriptors);

//#endif
		//- (BOOL)outlineView:(NSOutlineView *)outlineView writeItems:(NSArray *)items toPasteboard:(NSPasteboard *)pasteboard;
		[Export ("outlineView:writeItems:toPasteboard:")]
		bool OutlineViewWriteItems (NSOutlineView outlineView, NSArray items, NSPasteboard pasteboard);

		//- (NSDragOperation)outlineView:(NSOutlineView *)outlineView validateDrop:(id <NSDraggingInfo>)info proposedItem:(id)item proposedChildIndex:(NSInteger)index;
		[Export ("outlineView:validateDrop:proposedItem:proposedChildIndex:")]
		NSDragOperation OutlineViewValidateDrop (NSOutlineView outlineView, NSObject info, NSObject item, int index);

		//- (BOOL)outlineView:(NSOutlineView *)outlineView acceptDrop:(id <NSDraggingInfo>)info item:(id)item childIndex:(NSInteger)index;
		[Export ("outlineView:acceptDrop:item:childIndex:")]
		bool OutlineViewAcceptDrop (NSOutlineView outlineView, NSObject info, NSObject item, int index);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (NSArray *)outlineView:(NSOutlineView *)outlineView namesOfPromisedFilesDroppedAtDestination:(NSURL *)dropDestination forDraggedItems:(NSArray *)items;
		[Export ("outlineView:namesOfPromisedFilesDroppedAtDestination:forDraggedItems:")]
		NSArray OutlineViewNamesOfPromisedFilesDroppedAtDestination (NSOutlineView outlineView, NSUrl dropDestination, NSArray items);

//#endif
		//- (void)outlineView:(NSOutlineView *)outlineView willDisplayCell:(id)cell forTableColumn:(NSTableColumn *)tableColumn item:(id)item;
		[Export ("outlineView:willDisplayCell:forTableColumn:item:")]
		void OutlineViewWillDisplayCell (NSOutlineView outlineView, NSObject cell, NSTableColumn tableColumn, NSObject item);

		//- (BOOL)outlineView:(NSOutlineView *)outlineView shouldEditTableColumn:(NSTableColumn *)tableColumn item:(id)item;
		[Export ("outlineView:shouldEditTableColumn:item:")]
		bool OutlineViewShouldEditTableColumn (NSOutlineView outlineView, NSTableColumn tableColumn, NSObject item);

		//- (BOOL)selectionShouldChangeInOutlineView:(NSOutlineView *)outlineView;
		[Export ("selectionShouldChangeInOutlineView:")]
		bool SelectionShouldChangeInOutlineView (NSOutlineView outlineView);

		//- (BOOL)outlineView:(NSOutlineView *)outlineView shouldSelectItem:(id)item;
		[Export ("outlineView:shouldSelectItem:")]
		bool OutlineViewShouldSelectItem (NSOutlineView outlineView, NSObject item);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (NSIndexSet *)outlineView:(NSOutlineView *)outlineView selectionIndexesForProposedSelection:(NSIndexSet *)proposedSelectionIndexes;
		[Export ("outlineView:selectionIndexesForProposedSelection:")]
		NSIndexSet OutlineViewSelectionIndexesForProposedSelection (NSOutlineView outlineView, NSIndexSet proposedSelectionIndexes);

//#endif
		//- (BOOL)outlineView:(NSOutlineView *)outlineView shouldSelectTableColumn:(NSTableColumn *)tableColumn;
		[Export ("outlineView:shouldSelectTableColumn:")]
		bool OutlineViewShouldSelectTableColumn (NSOutlineView outlineView, NSTableColumn tableColumn);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//- (void)outlineView:(NSOutlineView *)outlineView mouseDownInHeaderOfTableColumn:(NSTableColumn *)tableColumn;
		[Export ("outlineView:mouseDownInHeaderOfTableColumn:")]
		void OutlineViewMouseDownInHeaderOfTableColumn (NSOutlineView outlineView, NSTableColumn tableColumn);

		//- (void)outlineView:(NSOutlineView *)outlineView didClickTableColumn:(NSTableColumn *)tableColumn;
		[Export ("outlineView:didClickTableColumn:")]
		void OutlineViewDidClickTableColumn (NSOutlineView outlineView, NSTableColumn tableColumn);

		//- (void)outlineView:(NSOutlineView *)outlineView didDragTableColumn:(NSTableColumn *)tableColumn;
		[Export ("outlineView:didDragTableColumn:")]
		void OutlineViewDidDragTableColumn (NSOutlineView outlineView, NSTableColumn tableColumn);

//#endif
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (NSString *)outlineView:(NSOutlineView *)outlineView toolTipForCell:(NSCell *)cell rect:(NSRectPointer)rect tableColumn:(NSTableColumn *)tableColumn item:(id)item mouseLocation:(NSPoint)mouseLocation;
		[Export ("outlineView:toolTipForCell:rect:tableColumn:item:mouseLocation:")]
		string OutlineViewToolTipForCell (NSOutlineView outlineView, NSCell cell, NSRectPointer rect, NSTableColumn tableColumn, NSObject item, PointF mouseLocation);

		//- (CGFloat)outlineView:(NSOutlineView *)outlineView heightOfRowByItem:(id)item;
		[Export ("outlineView:heightOfRowByItem:")]
		float OutlineViewHeightOfRowByItem (NSOutlineView outlineView, NSObject item);

//#endif
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (NSString *)outlineView:(NSOutlineView *)outlineView typeSelectStringForTableColumn:(NSTableColumn *)tableColumn item:(id)item;
		[Export ("outlineView:typeSelectStringForTableColumn:item:")]
		string OutlineViewTypeSelectStringForTableColumn (NSOutlineView outlineView, NSTableColumn tableColumn, NSObject item);

		//- (id)outlineView:(NSOutlineView *)outlineView nextTypeSelectMatchFromItem:(id)startItem toItem:(id)endItem forString:(NSString *)searchString;
		[Export ("outlineView:nextTypeSelectMatchFromItem:toItem:forString:")]
		NSObject OutlineViewNextTypeSelectMatchFromItem (NSOutlineView outlineView, NSObject startItem, NSObject endItem, string searchString);

		//- (BOOL)outlineView:(NSOutlineView *)outlineView shouldTypeSelectForEvent:(NSEvent *)event withCurrentSearchString:(NSString *)searchString;
		[Export ("outlineView:shouldTypeSelectForEvent:withCurrentSearchString:")]
		bool OutlineViewShouldTypeSelectForEvent (NSOutlineView outlineView, NSEvent event1, string searchString);

		//- (BOOL)outlineView:(NSOutlineView *)outlineView shouldShowCellExpansionForTableColumn:(NSTableColumn *)tableColumn item:(id)item;
		[Export ("outlineView:shouldShowCellExpansionForTableColumn:item:")]
		bool OutlineViewShouldShowCellExpansionForTableColumn (NSOutlineView outlineView, NSTableColumn tableColumn, NSObject item);

		//- (BOOL)outlineView:(NSOutlineView *)outlineView shouldTrackCell:(NSCell *)cell forTableColumn:(NSTableColumn *)tableColumn item:(id)item;
		[Export ("outlineView:shouldTrackCell:forTableColumn:item:")]
		bool OutlineViewShouldTrackCell (NSOutlineView outlineView, NSCell cell, NSTableColumn tableColumn, NSObject item);

		//- (NSCell *)outlineView:(NSOutlineView *)outlineView dataCellForTableColumn:(NSTableColumn *)tableColumn item:(id)item;
		[Export ("outlineView:dataCellForTableColumn:item:")]
		NSCell OutlineViewDataCellForTableColumn (NSOutlineView outlineView, NSTableColumn tableColumn, NSObject item);

		//- (BOOL)outlineView:(NSOutlineView *)outlineView isGroupItem:(id)item;
		[Export ("outlineView:isGroupItem:")]
		bool OutlineViewIsGroupItem (NSOutlineView outlineView, NSObject item);

//#endif
		//- (BOOL)outlineView:(NSOutlineView *)outlineView shouldExpandItem:(id)item;
		[Export ("outlineView:shouldExpandItem:")]
		bool OutlineViewShouldExpandItem (NSOutlineView outlineView, NSObject item);

		//- (BOOL)outlineView:(NSOutlineView *)outlineView shouldCollapseItem:(id)item;
		[Export ("outlineView:shouldCollapseItem:")]
		bool OutlineViewShouldCollapseItem (NSOutlineView outlineView, NSObject item);

		//- (void)outlineView:(NSOutlineView *)outlineView willDisplayOutlineCell:(id)cell forTableColumn:(NSTableColumn *)tableColumn item:(id)item;
		[Export ("outlineView:willDisplayOutlineCell:forTableColumn:item:")]
		void OutlineViewWillDisplayOutlineCell (NSOutlineView outlineView, NSObject cell, NSTableColumn tableColumn, NSObject item);

		//- (void)outlineViewColumnDidMove:(NSNotification *)notification;
		[Export ("outlineViewColumnDidMove:")]
		void OutlineViewColumnDidMove (NSNotification notification);

		//- (void)outlineViewColumnDidResize:(NSNotification *)notification;
		[Export ("outlineViewColumnDidResize:")]
		void OutlineViewColumnDidResize (NSNotification notification);

		//- (void)outlineViewSelectionIsChanging:(NSNotification *)notification;
		[Export ("outlineViewSelectionIsChanging:")]
		void OutlineViewSelectionIsChanging (NSNotification notification);

		//- (void)outlineViewItemWillExpand:(NSNotification *)notification;
		[Export ("outlineViewItemWillExpand:")]
		void OutlineViewItemWillExpand (NSNotification notification);

		//- (void)outlineViewItemDidExpand:(NSNotification *)notification;
		[Export ("outlineViewItemDidExpand:")]
		void OutlineViewItemDidExpand (NSNotification notification);

		//- (void)outlineViewItemWillCollapse:(NSNotification *)notification;
		[Export ("outlineViewItemWillCollapse:")]
		void OutlineViewItemWillCollapse (NSNotification notification);

		//- (void)outlineViewItemDidCollapse:(NSNotification *)notification;
		[Export ("outlineViewItemDidCollapse:")]
		void OutlineViewItemDidCollapse (NSNotification notification);

		//- (void)pasteboardChangedOwner:(NSPasteboard *)sender;
		[Export ("pasteboardChangedOwner:")]
		void PasteboardChangedOwner (NSPasteboard sender);

		//- (NSInteger)ruleEditor:(NSRuleEditor *)editor numberOfChildrenForCriterion:(id)criterion withRowType:(NSRuleEditorRowType)rowType;
		[Export ("ruleEditor:numberOfChildrenForCriterion:withRowType:")]
		int RuleEditorNumberOfChildrenForCriterion (NSRuleEditor editor, NSObject criterion, NSRuleEditorRowType rowType);

		//- (id)ruleEditor:(NSRuleEditor *)editor child:(NSInteger)index forCriterion:(id)criterion withRowType:(NSRuleEditorRowType)rowType;
		[Export ("ruleEditor:child:forCriterion:withRowType:")]
		NSObject RuleEditorChild (NSRuleEditor editor, int index, NSObject criterion, NSRuleEditorRowType rowType);

		//- (id)ruleEditor:(NSRuleEditor *)editor displayValueForCriterion:(id)criterion inRow:(NSInteger)row;
		[Export ("ruleEditor:displayValueForCriterion:inRow:")]
		NSObject RuleEditorDisplayValueForCriterion (NSRuleEditor editor, NSObject criterion, int row);

		//- (NSDictionary *)ruleEditor:(NSRuleEditor *)editor predicatePartsForCriterion:(id)criterion withDisplayValue:(id)value inRow:(NSInteger)row;
		[Export ("ruleEditor:predicatePartsForCriterion:withDisplayValue:inRow:")]
		NSDictionary RuleEditorPredicatePartsForCriterion (NSRuleEditor editor, NSObject criterion, NSObject value, int row);

		//- (void)ruleEditorRowsDidChange:(NSNotification *)notification;
		[Export ("ruleEditorRowsDidChange:")]
		void RuleEditorRowsDidChange (NSNotification notification);

		//- (BOOL)panel:(id)sender shouldShowFilename:(NSString *)filename;
		[Export ("panel:shouldShowFilename:")]
		bool PanelShouldShowFilename (NSObject sender, string filename);

		//- (NSComparisonResult)panel:(id)sender compareFilename:(NSString *)name1 with:(NSString *)name2 caseSensitive:(BOOL)caseSensitive;
		[Export ("panel:compareFilename:with:caseSensitive:")]
		NSComparisonResult PanelCompareFilename (NSObject sender, string name1, string name2, bool caseSensitive);

		//- (BOOL)panel:(id)sender isValidFilename:(NSString *)filename;
		[Export ("panel:isValidFilename:")]
		bool PanelIsValidFilename (NSObject sender, string filename);

		//- (NSString *)panel:(id)sender userEnteredFilename:(NSString *)filename confirmed:(BOOL)okFlag;
		[Export ("panel:userEnteredFilename:confirmed:")]
		string PanelUserEnteredFilename (NSObject sender, string filename, bool okFlag);

		//- (void)panel:(id)sender willExpand:(BOOL)expanding;
		[Export ("panel:willExpand:")]
		void PanelWillExpand (NSObject sender, bool expanding);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//- (void)panel:(id)sender directoryDidChange:(NSString *)path;
		[Export ("panel:directoryDidChange:")]
		void PanelDirectoryDidChange (NSObject sender, string path);

		//- (void)panelSelectionDidChange:(id)sender;
		[Export ("panelSelectionDidChange:")]
		void PanelSelectionDidChange (NSObject sender);

//#endif
		//- (void)sound:(NSSound *)sound didFinishPlaying:(BOOL)aBool;
		[Export ("sound:didFinishPlaying:")]
		void SoundDidFinishPlaying (NSSound sound, bool aBool);

		//- (void)speechRecognizer:(NSSpeechRecognizer *)sender didRecognizeCommand:(id)command;
		[Export ("speechRecognizer:didRecognizeCommand:")]
		void SpeechRecognizerDidRecognizeCommand (NSSpeechRecognizer sender, NSObject command);

		//- (void)speechSynthesizer:(NSSpeechSynthesizer *)sender didFinishSpeaking:(BOOL)finishedSpeaking;
		[Export ("speechSynthesizer:didFinishSpeaking:")]
		void SpeechSynthesizerDidFinishSpeaking (NSSpeechSynthesizer sender, bool finishedSpeaking);

		//- (void)speechSynthesizer:(NSSpeechSynthesizer *)sender willSpeakWord:(NSRange)characterRange ofString:(NSString *)string;
		[Export ("speechSynthesizer:willSpeakWord:ofString:")]
		void SpeechSynthesizerWillSpeakWord (NSSpeechSynthesizer sender, NSRange characterRange, string string1);

		//- (void)speechSynthesizer:(NSSpeechSynthesizer *)sender willSpeakPhoneme:(short)phonemeOpcode;
		[Export ("speechSynthesizer:willSpeakPhoneme:")]
		void SpeechSynthesizerWillSpeakPhoneme (NSSpeechSynthesizer sender, short phonemeOpcode);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (void)speechSynthesizer:(NSSpeechSynthesizer *)sender didEncounterErrorAtIndex:(NSUInteger)characterIndex ofString:(NSString *)string message:(NSString *)message;
		[Export ("speechSynthesizer:didEncounterErrorAtIndex:ofString:message:")]
		void SpeechSynthesizerDidEncounterErrorAtIndex (NSSpeechSynthesizer sender, uint characterIndex, string string1, string message);

		//- (void)speechSynthesizer:(NSSpeechSynthesizer *)sender didEncounterSyncMessage:(NSString *)message;
		[Export ("speechSynthesizer:didEncounterSyncMessage:")]
		void SpeechSynthesizerDidEncounterSyncMessage (NSSpeechSynthesizer sender, string message);

//#endif
		//- (BOOL)splitView:(NSSplitView *)splitView canCollapseSubview:(NSView *)subview;
		[Export ("splitView:canCollapseSubview:")]
		bool SplitViewCanCollapseSubview (NSSplitView splitView, NSView subview);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (BOOL)splitView:(NSSplitView *)splitView shouldCollapseSubview:(NSView *)subview forDoubleClickOnDividerAtIndex:(NSInteger)dividerIndex;
		[Export ("splitView:shouldCollapseSubview:forDoubleClickOnDividerAtIndex:")]
		bool SplitViewShouldCollapseSubview (NSSplitView splitView, NSView subview, int dividerIndex);

//#endif
		//- (CGFloat)splitView:(NSSplitView *)splitView constrainMinCoordinate:(CGFloat)proposedMinimumPosition ofSubviewAt:(NSInteger)dividerIndex;
		[Export ("splitView:constrainMinCoordinate:ofSubviewAt:")]
		float SplitViewConstrainMinCoordinate (NSSplitView splitView, float proposedMinimumPosition, int dividerIndex);

		//- (CGFloat)splitView:(NSSplitView *)splitView constrainMaxCoordinate:(CGFloat)proposedMaximumPosition ofSubviewAt:(NSInteger)dividerIndex;
		[Export ("splitView:constrainMaxCoordinate:ofSubviewAt:")]
		float SplitViewConstrainMaxCoordinate (NSSplitView splitView, float proposedMaximumPosition, int dividerIndex);

		//- (CGFloat)splitView:(NSSplitView *)splitView constrainSplitPosition:(CGFloat)proposedPosition ofSubviewAt:(NSInteger)dividerIndex;
		[Export ("splitView:constrainSplitPosition:ofSubviewAt:")]
		float SplitViewConstrainSplitPosition (NSSplitView splitView, float proposedPosition, int dividerIndex);

		//- (void)splitView:(NSSplitView *)splitView resizeSubviewsWithOldSize:(NSSize)oldSize;
		[Export ("splitView:resizeSubviewsWithOldSize:")]
		void SplitViewResizeSubviewsWithOldSize (NSSplitView splitView, NSSize oldSize);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (BOOL)splitView:(NSSplitView *)splitView shouldHideDividerAtIndex:(NSInteger)dividerIndex;
		[Export ("splitView:shouldHideDividerAtIndex:")]
		bool SplitViewShouldHideDividerAtIndex (NSSplitView splitView, int dividerIndex);

		//- (NSRect)splitView:(NSSplitView *)splitView effectiveRect:(NSRect)proposedEffectiveRect forDrawnRect:(NSRect)drawnRect ofDividerAtIndex:(NSInteger)dividerIndex;
		[Export ("splitView:effectiveRect:forDrawnRect:ofDividerAtIndex:")]
		RectangleF SplitViewEffectiveRect (NSSplitView splitView, RectangleF proposedEffectiveRect, RectangleF drawnRect, int dividerIndex);

		//- (NSRect)splitView:(NSSplitView *)splitView additionalEffectiveRectOfDividerAtIndex:(NSInteger)dividerIndex;
		[Export ("splitView:additionalEffectiveRectOfDividerAtIndex:")]
		RectangleF SplitViewAdditionalEffectiveRectOfDividerAtIndex (NSSplitView splitView, int dividerIndex);

//#endif
		//- (void)splitViewWillResizeSubviews:(NSNotification *)notification;
		[Export ("splitViewWillResizeSubviews:")]
		void SplitViewWillResizeSubviews (NSNotification notification);

		//- (void)splitViewDidResizeSubviews:(NSNotification *)notification;
		[Export ("splitViewDidResizeSubviews:")]
		void SplitViewDidResizeSubviews (NSNotification notification);

		//- (void)tableView:(NSTableView *)tableView willDisplayCell:(id)cell forTableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row;
		[Export ("tableView:willDisplayCell:forTableColumn:row:")]
		void TableViewWillDisplayCell (NSTableView tableView, NSObject cell, NSTableColumn tableColumn, int row);

		//- (BOOL)tableView:(NSTableView *)tableView shouldEditTableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row;
		[Export ("tableView:shouldEditTableColumn:row:")]
		bool TableViewShouldEditTableColumn (NSTableView tableView, NSTableColumn tableColumn, int row);

		//- (BOOL)selectionShouldChangeInTableView:(NSTableView *)tableView;
		[Export ("selectionShouldChangeInTableView:")]
		bool SelectionShouldChangeInTableView (NSTableView tableView);

		//- (BOOL)tableView:(NSTableView *)tableView shouldSelectRow:(NSInteger)row;
		[Export ("tableView:shouldSelectRow:")]
		bool TableViewShouldSelectRow (NSTableView tableView, int row);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (NSIndexSet *)tableView:(NSTableView *)tableView selectionIndexesForProposedSelection:(NSIndexSet *)proposedSelectionIndexes;
		[Export ("tableView:selectionIndexesForProposedSelection:")]
		NSIndexSet TableViewSelectionIndexesForProposedSelection (NSTableView tableView, NSIndexSet proposedSelectionIndexes);

//#endif
		//- (BOOL)tableView:(NSTableView *)tableView shouldSelectTableColumn:(NSTableColumn *)tableColumn;
		[Export ("tableView:shouldSelectTableColumn:")]
		bool TableViewShouldSelectTableColumn (NSTableView tableView, NSTableColumn tableColumn);

		//- (void)tableView:(NSTableView *)tableView mouseDownInHeaderOfTableColumn:(NSTableColumn *)tableColumn;
		[Export ("tableView:mouseDownInHeaderOfTableColumn:")]
		void TableViewMouseDownInHeaderOfTableColumn (NSTableView tableView, NSTableColumn tableColumn);

		//- (void)tableView:(NSTableView *)tableView didClickTableColumn:(NSTableColumn *)tableColumn;
		[Export ("tableView:didClickTableColumn:")]
		void TableViewDidClickTableColumn (NSTableView tableView, NSTableColumn tableColumn);

		//- (void)tableView:(NSTableView *)tableView didDragTableColumn:(NSTableColumn *)tableColumn;
		[Export ("tableView:didDragTableColumn:")]
		void TableViewDidDragTableColumn (NSTableView tableView, NSTableColumn tableColumn);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (NSString *)tableView:(NSTableView *)tableView toolTipForCell:(NSCell *)cell rect:(NSRectPointer)rect tableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row mouseLocation:(NSPoint)mouseLocation;
		[Export ("tableView:toolTipForCell:rect:tableColumn:row:mouseLocation:")]
		string TableViewToolTipForCell (NSTableView tableView, NSCell cell, NSRectPointer rect, NSTableColumn tableColumn, int row, PointF mouseLocation);

		//- (CGFloat)tableView:(NSTableView *)tableView heightOfRow:(NSInteger)row;
		[Export ("tableView:heightOfRow:")]
		float TableViewHeightOfRow (NSTableView tableView, int row);

//#endif
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (NSString *)tableView:(NSTableView *)tableView typeSelectStringForTableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row;
		[Export ("tableView:typeSelectStringForTableColumn:row:")]
		string TableViewTypeSelectStringForTableColumn (NSTableView tableView, NSTableColumn tableColumn, int row);

		//- (NSInteger)tableView:(NSTableView *)tableView nextTypeSelectMatchFromRow:(NSInteger)startRow toRow:(NSInteger)endRow forString:(NSString *)searchString;
		[Export ("tableView:nextTypeSelectMatchFromRow:toRow:forString:")]
		int TableViewNextTypeSelectMatchFromRow (NSTableView tableView, int startRow, int endRow, string searchString);

		//- (BOOL)tableView:(NSTableView *)tableView shouldTypeSelectForEvent:(NSEvent *)event withCurrentSearchString:(NSString *)searchString;
		[Export ("tableView:shouldTypeSelectForEvent:withCurrentSearchString:")]
		bool TableViewShouldTypeSelectForEvent (NSTableView tableView, NSEvent event1, string searchString);

		//- (BOOL)tableView:(NSTableView *)tableView shouldShowCellExpansionForTableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row;
		[Export ("tableView:shouldShowCellExpansionForTableColumn:row:")]
		bool TableViewShouldShowCellExpansionForTableColumn (NSTableView tableView, NSTableColumn tableColumn, int row);

		//- (BOOL)tableView:(NSTableView *)tableView shouldTrackCell:(NSCell *)cell forTableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row;
		[Export ("tableView:shouldTrackCell:forTableColumn:row:")]
		bool TableViewShouldTrackCell (NSTableView tableView, NSCell cell, NSTableColumn tableColumn, int row);

		//- (NSCell *)tableView:(NSTableView *)tableView dataCellForTableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row;
		[Export ("tableView:dataCellForTableColumn:row:")]
		NSCell TableViewDataCellForTableColumn (NSTableView tableView, NSTableColumn tableColumn, int row);

		//- (BOOL)tableView:(NSTableView *)tableView isGroupRow:(NSInteger)row;
		[Export ("tableView:isGroupRow:")]
		bool TableViewIsGroupRow (NSTableView tableView, int row);

//#endif
		//- (void)tableViewColumnDidMove:(NSNotification *)notification;
		[Export ("tableViewColumnDidMove:")]
		void TableViewColumnDidMove (NSNotification notification);

		//- (void)tableViewColumnDidResize:(NSNotification *)notification;
		[Export ("tableViewColumnDidResize:")]
		void TableViewColumnDidResize (NSNotification notification);

		//- (void)tableViewSelectionIsChanging:(NSNotification *)notification;
		[Export ("tableViewSelectionIsChanging:")]
		void TableViewSelectionIsChanging (NSNotification notification);

		//- (NSInteger)numberOfRowsInTableView:(NSTableView *)tableView;
		[Export ("numberOfRowsInTableView:")]
		int NumberOfRowsInTableView (NSTableView tableView);

		//- (id)tableView:(NSTableView *)tableView objectValueForTableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row;
		[Export ("tableView:objectValueForTableColumn:row:")]
		NSObject TableViewObjectValueForTableColumn (NSTableView tableView, NSTableColumn tableColumn, int row);

		//- (void)tableView:(NSTableView *)tableView setObjectValue:(id)object forTableColumn:(NSTableColumn *)tableColumn row:(NSInteger)row;
		[Export ("tableView:setObjectValue:forTableColumn:row:")]
		void TableViewSetObjectValue (NSTableView tableView, NSObject object1, NSTableColumn tableColumn, int row);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//- (void)tableView:(NSTableView *)tableView sortDescriptorsDidChange:(NSArray *)oldDescriptors;
		[Export ("tableView:sortDescriptorsDidChange:")]
		void TableViewSortDescriptorsDidChange (NSTableView tableView, NSArray oldDescriptors);

//#endif
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (BOOL)tableView:(NSTableView *)tableView writeRowsWithIndexes:(NSIndexSet *)rowIndexes toPasteboard:(NSPasteboard*)pboard;
		[Export ("tableView:writeRowsWithIndexes:toPasteboard:")]
		bool TableViewWriteRowsWithIndexes (NSTableView tableView, NSIndexSet rowIndexes, NSPasteboard pboard);

//#endif
		//- (NSDragOperation)tableView:(NSTableView*)tableView validateDrop:(id <NSDraggingInfo>)info proposedRow:(NSInteger)row proposedDropOperation:(NSTableViewDropOperation)dropOperation;
		[Export ("tableView:validateDrop:proposedRow:proposedDropOperation:")]
		NSDragOperation TableViewValidateDrop (NSTableView tableView, NSObject info, int row, NSTableViewDropOperation dropOperation);

		//- (BOOL)tableView:(NSTableView*)tableView acceptDrop:(id <NSDraggingInfo>)info row:(NSInteger)row dropOperation:(NSTableViewDropOperation)dropOperation;
		[Export ("tableView:acceptDrop:row:dropOperation:")]
		bool TableViewAcceptDrop (NSTableView tableView, NSObject info, int row, NSTableViewDropOperation dropOperation);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (NSArray *)tableView:(NSTableView *)tableView namesOfPromisedFilesDroppedAtDestination:(NSURL *)dropDestination forDraggedRowsWithIndexes:(NSIndexSet *)indexSet;
		[Export ("tableView:namesOfPromisedFilesDroppedAtDestination:forDraggedRowsWithIndexes:")]
		NSArray TableViewNamesOfPromisedFilesDroppedAtDestination (NSTableView tableView, NSUrl dropDestination, NSIndexSet indexSet);

//#endif
		// - (BOOL)tableView:(NSTableView *)tableView writeRows:(NSArray *)rows toPasteboard:(NSPasteboard *)pboard;
		[Export ("tableView:writeRows:toPasteboard:")]
		bool TableViewWriteRows (NSTableView tableView, NSArray rows, NSPasteboard pboard);

		//- (void)tabView:(NSTabView *)tabView willSelectTabViewItem:(NSTabViewItem *)tabViewItem;
		[Export ("tabView:willSelectTabViewItem:")]
		void TabViewWillSelectTabViewItem (NSTabView tabView, NSTabViewItem tabViewItem);

		//- (void)tabView:(NSTabView *)tabView didSelectTabViewItem:(NSTabViewItem *)tabViewItem;
		[Export ("tabView:didSelectTabViewItem:")]
		void TabViewDidSelectTabViewItem (NSTabView tabView, NSTabViewItem tabViewItem);

		//- (void)tabViewDidChangeNumberOfTabViewItems:(NSTabView *)TabView;
		[Export ("tabViewDidChangeNumberOfTabViewItems:")]
		void TabViewDidChangeNumberOfTabViewItems (NSTabView TabView);

		//- (BOOL)textShouldEndEditing:(NSText *)textObject;          
		[Export ("textShouldEndEditing:")]
		bool TextShouldEndEditing (NSText textObject);

		//- (void)textDidBeginEditing:(NSNotification *)notification;
		[Export ("textDidBeginEditing:")]
		void TextDidBeginEditing (NSNotification notification);

		//- (void)textDidEndEditing:(NSNotification *)notification;
		[Export ("textDidEndEditing:")]
		void TextDidEndEditing (NSNotification notification);

		//- (void)textDidChange:(NSNotification *)notification;       
		[Export ("textDidChange:")]
		void TextDidChange (NSNotification notification);

		//- (void)textStorageWillProcessEditing:(NSNotification *)notification;	
		[Export ("textStorageWillProcessEditing:")]
		void TextStorageWillProcessEditing (NSNotification notification);

		//- (void)textStorageDidProcessEditing:(NSNotification *)notification;	
		[Export ("textStorageDidProcessEditing:")]
		void TextStorageDidProcessEditing (NSNotification notification);

		//- (BOOL)textView:(NSTextView *)textView clickedOnLink:(id)link atIndex:(NSUInteger)charIndex;
		[Export ("textView:clickedOnLink:atIndex:")]
		bool TextViewClickedOnLink (NSTextView textView, NSObject link, uint charIndex);

		//    - (void)textView:(NSTextView *)textView clickedOnCell:(id <NSTextAttachmentCell>)cell inRect:(NSRect)cellFrame atIndex:(NSUInteger)charIndex;
		[Export ("textView:clickedOnCell:inRect:atIndex:")]
		void TextViewClickedOnCell (NSTextView textView, NSObject cell, RectangleF cellFrame, uint charIndex);

		//    - (void)textView:(NSTextView *)textView doubleClickedOnCell:(id <NSTextAttachmentCell>)cell inRect:(NSRect)cellFrame atIndex:(NSUInteger)charIndex;
		[Export ("textView:doubleClickedOnCell:inRect:atIndex:")]
		void TextViewDoubleClickedOnCell (NSTextView textView, NSObject cell, RectangleF cellFrame, uint charIndex);

		//    - (void)textView:(NSTextView *)view draggedCell:(id <NSTextAttachmentCell>)cell inRect:(NSRect)rect event:(NSEvent *)event atIndex:(NSUInteger)charIndex;
		[Export ("textView:draggedCell:inRect:event:atIndex:")]
		void TextViewDraggedCell (NSTextView view, NSObject cell, RectangleF rect, NSEvent event1, uint charIndex);

		//    - (NSArray *)textView:(NSTextView *)view writablePasteboardTypesForCell:(id <NSTextAttachmentCell>)cell atIndex:(NSUInteger)charIndex;
		[Export ("textView:writablePasteboardTypesForCell:atIndex:")]
		NSArray TextViewWritablePasteboardTypesForCell (NSTextView view, NSObject cell, uint charIndex);

		//    - (BOOL)textView:(NSTextView *)view writeCell:(id <NSTextAttachmentCell>)cell atIndex:(NSUInteger)charIndex toPasteboard:(NSPasteboard *)pboard type:(NSString *)type ;
		[Export ("textView:writeCell:atIndex:toPasteboard:type:")]
		bool TextViewWriteCell (NSTextView view, NSObject cell, uint charIndex, NSPasteboard pboard, string type);

		//    - (NSRange)textView:(NSTextView *)textView willChangeSelectionFromCharacterRange:(NSRange)oldSelectedCharRange toCharacterRange:(NSRange)newSelectedCharRange;
		[Export ("textView:willChangeSelectionFromCharacterRange:toCharacterRange:")]
		NSRange TextViewWillChangeSelectionFromCharacterRange (NSTextView textView, NSRange oldSelectedCharRange, NSRange newSelectedCharRange);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//    - (NSArray *)textView:(NSTextView *)textView willChangeSelectionFromCharacterRanges:(NSArray *)oldSelectedCharRanges toCharacterRanges:(NSArray *)newSelectedCharRanges;
		[Export ("textView:willChangeSelectionFromCharacterRanges:toCharacterRanges:")]
		NSArray TextViewWillChangeSelectionFromCharacterRanges (NSTextView textView, NSArray oldSelectedCharRanges, NSArray newSelectedCharRanges);

		//    - (BOOL)textView:(NSTextView *)textView shouldChangeTextInRanges:(NSArray *)affectedRanges replacementStrings:(NSArray *)replacementStrings;
		[Export ("textView:shouldChangeTextInRanges:replacementStrings:")]
		bool TextViewShouldChangeTextInRanges (NSTextView textView, NSArray affectedRanges, NSArray replacementStrings);

		//    - (NSDictionary *)textView:(NSTextView *)textView shouldChangeTypingAttributes:(NSDictionary *)oldTypingAttributes toAttributes:(NSDictionary *)newTypingAttributes;
		[Export ("textView:shouldChangeTypingAttributes:toAttributes:")]
		NSDictionary TextViewShouldChangeTypingAttributes (NSTextView textView, NSDictionary oldTypingAttributes, NSDictionary newTypingAttributes);

//#endif 
		//    - (void)textViewDidChangeSelection:(NSNotification *)notification;
		[Export ("textViewDidChangeSelection:")]
		void TextViewDidChangeSelection (NSNotification notification);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//- (void)textViewDidChangeTypingAttributes:(NSNotification *)notification;
		[Export ("textViewDidChangeTypingAttributes:")]
		void TextViewDidChangeTypingAttributes (NSNotification notification);

		//- (NSString *)textView:(NSTextView *)textView willDisplayToolTip:(NSString *)tooltip forCharacterAtIndex:(NSUInteger)characterIndex;
		[Export ("textView:willDisplayToolTip:forCharacterAtIndex:")]
		string TextViewWillDisplayToolTip (NSTextView textView, string tooltip, uint characterIndex);

		//    - (NSArray *)textView:(NSTextView *)textView completions:(NSArray *)words forPartialWordRange:(NSRange)charRange indexOfSelectedItem:(NSInteger *)index;
		[Export ("textView:completions:forPartialWordRange:indexOfSelectedItem:")]
		NSArray TextViewCompletions (NSTextView textView, NSArray words, NSRange charRange, int index);

//#endif 
		//    - (BOOL)textView:(NSTextView *)textView shouldChangeTextInRange:(NSRange)affectedCharRange replacementString:(NSString *)replacementString;
		[Export ("textView:shouldChangeTextInRange:replacementString:")]
		bool TextViewShouldChangeTextInRange (NSTextView textView, NSRange affectedCharRange, string replacementString);

		//    - (BOOL)textView:(NSTextView *)textView doCommandBySelector:(SEL)commandSelector;
		[Export ("textView:doCommandBySelector:")]
		bool TextViewDoCommandBySelector (NSTextView textView, Selector commandSelector);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (NSInteger)textView:(NSTextView *)textView shouldSetSpellingState:(NSInteger)value range:(NSRange)affectedCharRange;
		[Export ("textView:shouldSetSpellingState:range:")]
		int TextViewShouldSetSpellingState (NSTextView textView, int value, NSRange affectedCharRange);

		//    - (NSMenu *)textView:(NSTextView *)view menu:(NSMenu *)menu forEvent:(NSEvent *)event atIndex:(NSUInteger)charIndex;
		[Export ("textView:menu:forEvent:atIndex:")]
		NSMenu TextViewMenu (NSTextView view, NSMenu menu, NSEvent event1, uint charIndex);

//#endif 
		//    - (BOOL)textView:(NSTextView *)textView clickedOnLink:(id)link;
		[Export ("textView:clickedOnLink:")]
		bool TextViewClickedOnLink (NSTextView textView, NSObject link);

		//- (void)textView:(NSTextView *)textView clickedOnCell:(id <NSTextAttachmentCell>)cell inRect:(NSRect)cellFrame;
		[Export ("textView:clickedOnCell:inRect:")]
		void TextViewClickedOnCell (NSTextView textView, NSObject cell, RectangleF cellFrame);

		//- (void)textView:(NSTextView *)textView doubleClickedOnCell:(id <NSTextAttachmentCell>)cell inRect:(NSRect)cellFrame;
		[Export ("textView:doubleClickedOnCell:inRect:")]
		void TextViewDoubleClickedOnCell (NSTextView textView, NSObject cell, RectangleF cellFrame);

		//- (void)textView:(NSTextView *)view draggedCell:(id <NSTextAttachmentCell>)cell inRect:(NSRect)rect event:(NSEvent *)event;
		[Export ("textView:draggedCell:inRect:event:")]
		void TextViewDraggedCell (NSTextView view, NSObject cell, RectangleF rect, NSEvent event1);

		//- (NSUndoManager *)undoManagerForTextView:(NSTextView *)view;
		[Export ("undoManagerForTextView:")]
		NSUndoManager UndoManagerForTextView (NSTextView view);

		//- (NSArray *)tokenField:(NSTokenField *)tokenField completionsForSubstring:(NSString *)substring indexOfToken:(NSInteger)tokenIndex indexOfSelectedItem:(NSInteger *)selectedIndex;
		[Export ("tokenField:completionsForSubstring:indexOfToken:indexOfSelectedItem:")]
		NSArray TokenFieldCompletionsForSubstring (NSTokenField tokenField, string substring, int tokenIndex, int selectedIndex);

		//- (NSArray *)tokenField:(NSTokenField *)tokenField shouldAddObjects:(NSArray *)tokens atIndex:(NSUInteger)index;
		[Export ("tokenField:shouldAddObjects:atIndex:")]
		NSArray TokenFieldShouldAddObjects (NSTokenField tokenField, NSArray tokens, uint index);

		//- (NSString *)tokenField:(NSTokenField *)tokenField displayStringForRepresentedObject:(id)representedObject;
		[Export ("tokenField:displayStringForRepresentedObject:")]
		string TokenFieldDisplayStringForRepresentedObject (NSTokenField tokenField, NSObject representedObject);

		//- (NSString *)tokenField:(NSTokenField *)tokenField editingStringForRepresentedObject:(id)representedObject;
		[Export ("tokenField:editingStringForRepresentedObject:")]
		string TokenFieldEditingStringForRepresentedObject (NSTokenField tokenField, NSObject representedObject);

		//- (id)tokenField:(NSTokenField *)tokenField representedObjectForEditingString: (NSString *)editingString;
		[Export ("tokenField:representedObjectForEditingString:")]
		NSObject TokenFieldRepresentedObjectForEditingString (NSTokenField tokenField, string editingString);

		//- (BOOL)tokenField:(NSTokenField *)tokenField writeRepresentedObjects:(NSArray *)objects toPasteboard:(NSPasteboard *)pboard;
		[Export ("tokenField:writeRepresentedObjects:toPasteboard:")]
		bool TokenFieldWriteRepresentedObjects (NSTokenField tokenField, NSArray objects, NSPasteboard pboard);

		//- (NSArray *)tokenField:(NSTokenField *)tokenField readFromPasteboard:(NSPasteboard *)pboard;
		[Export ("tokenField:readFromPasteboard:")]
		NSArray TokenFieldReadFromPasteboard (NSTokenField tokenField, NSPasteboard pboard);

		//- (NSMenu *)tokenField:(NSTokenField *)tokenField menuForRepresentedObject:(id)representedObject;
		[Export ("tokenField:menuForRepresentedObject:")]
		NSMenu TokenFieldMenuForRepresentedObject (NSTokenField tokenField, NSObject representedObject);

		//- (BOOL)tokenField:(NSTokenField *)tokenField hasMenuForRepresentedObject:(id)representedObject; 
		[Export ("tokenField:hasMenuForRepresentedObject:")]
		bool TokenFieldHasMenuForRepresentedObject (NSTokenField tokenField, NSObject representedObject);

		//- (NSTokenStyle)tokenField:(NSTokenField *)tokenField styleForRepresentedObject:(id)representedObject;
		[Export ("tokenField:styleForRepresentedObject:")]
		NSTokenStyle TokenFieldStyleForRepresentedObject (NSTokenField tokenField, NSObject representedObject);

		//- (NSArray *)tokenFieldCell:(NSTokenFieldCell *)tokenFieldCell completionsForSubstring:(NSString *)substring indexOfToken:(NSInteger)tokenIndex indexOfSelectedItem:(NSInteger *)selectedIndex;
		[Export ("tokenFieldCell:completionsForSubstring:indexOfToken:indexOfSelectedItem:")]
		NSArray TokenFieldCellCompletionsForSubstring (NSTokenFieldCell tokenFieldCell, string substring, int tokenIndex, int selectedIndex);

		//- (NSArray *)tokenFieldCell:(NSTokenFieldCell *)tokenFieldCell shouldAddObjects:(NSArray *)tokens atIndex:(NSUInteger)index;
		[Export ("tokenFieldCell:shouldAddObjects:atIndex:")]
		NSArray TokenFieldCellShouldAddObjects (NSTokenFieldCell tokenFieldCell, NSArray tokens, uint index);

		//- (NSString *)tokenFieldCell:(NSTokenFieldCell *)tokenFieldCell displayStringForRepresentedObject:(id)representedObject;
		[Export ("tokenFieldCell:displayStringForRepresentedObject:")]
		string TokenFieldCellDisplayStringForRepresentedObject (NSTokenFieldCell tokenFieldCell, NSObject representedObject);

		//- (NSString *)tokenFieldCell:(NSTokenFieldCell *)tokenFieldCell editingStringForRepresentedObject:(id)representedObject;
		[Export ("tokenFieldCell:editingStringForRepresentedObject:")]
		string TokenFieldCellEditingStringForRepresentedObject (NSTokenFieldCell tokenFieldCell, NSObject representedObject);

		//- (id)tokenFieldCell:(NSTokenFieldCell *)tokenFieldCell representedObjectForEditingString: (NSString *)editingString;
		[Export ("tokenFieldCell:representedObjectForEditingString:")]
		NSObject TokenFieldCellRepresentedObjectForEditingString (NSTokenFieldCell tokenFieldCell, string editingString);

		//- (BOOL)tokenFieldCell:(NSTokenFieldCell *)tokenFieldCell writeRepresentedObjects:(NSArray *)objects toPasteboard:(NSPasteboard *)pboard;
		[Export ("tokenFieldCell:writeRepresentedObjects:toPasteboard:")]
		bool TokenFieldCellWriteRepresentedObjects (NSTokenFieldCell tokenFieldCell, NSArray objects, NSPasteboard pboard);

		//- (NSArray *)tokenFieldCell:(NSTokenFieldCell *)tokenFieldCell readFromPasteboard:(NSPasteboard *)pboard;
		[Export ("tokenFieldCell:readFromPasteboard:")]
		NSArray TokenFieldCellReadFromPasteboard (NSTokenFieldCell tokenFieldCell, NSPasteboard pboard);

		//- (NSMenu *)tokenFieldCell:(NSTokenFieldCell *)tokenFieldCell menuForRepresentedObject:(id)representedObject;
		[Export ("tokenFieldCell:menuForRepresentedObject:")]
		NSMenu TokenFieldCellMenuForRepresentedObject (NSTokenFieldCell tokenFieldCell, NSObject representedObject);

		//- (BOOL)tokenFieldCell:(NSTokenFieldCell *)tokenFieldCell hasMenuForRepresentedObject:(id)representedObject; 
		[Export ("tokenFieldCell:hasMenuForRepresentedObject:")]
		bool TokenFieldCellHasMenuForRepresentedObject (NSTokenFieldCell tokenFieldCell, NSObject representedObject);

		//- (NSTokenStyle)tokenFieldCell:(NSTokenFieldCell *)tokenFieldCell styleForRepresentedObject:(id)representedObject;
		[Export ("tokenFieldCell:styleForRepresentedObject:")]
		NSTokenStyle TokenFieldCellStyleForRepresentedObject (NSTokenFieldCell tokenFieldCell, NSObject representedObject);

		//- (NSToolbarItem *)toolbar:(NSToolbar *)toolbar itemForItemIdentifier:(NSString *)itemIdentifier willBeInsertedIntoToolbar:(BOOL)flag;
		[Export ("toolbar:itemForItemIdentifier:willBeInsertedIntoToolbar:")]
		NSToolbarItem ToolbarItemForItemIdentifier (NSToolbar toolbar, string itemIdentifier, bool flag);

		//        - (NSArray *)toolbarDefaultItemIdentifiers:(NSToolbar*)toolbar;
		[Export ("toolbarDefaultItemIdentifiers:")]
		NSArray ToolbarDefaultItemIdentifiers (NSToolbar toolbar);

		//    - (NSArray *)toolbarAllowedItemIdentifiers:(NSToolbar*)toolbar;
		[Export ("toolbarAllowedItemIdentifiers:")]
		NSArray ToolbarAllowedItemIdentifiers (NSToolbar toolbar);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//    - (NSArray *)toolbarSelectableItemIdentifiers:(NSToolbar *)toolbar;
		[Export ("toolbarSelectableItemIdentifiers:")]
		NSArray ToolbarSelectableItemIdentifiers (NSToolbar toolbar);

//#endif
		//- (void)toolbarWillAddItem: (NSNotification *)notification;
		[Export ("toolbarWillAddItem:")]
		void ToolbarWillAddItem (NSNotification notification);

		//    - (void)toolbarDidRemoveItem: (NSNotification *)notification;
		[Export ("toolbarDidRemoveItem:")]
		void ToolbarDidRemoveItem (NSNotification notification);

		//- (void)windowDidExpose:(NSNotification *)notification;
		[Export ("windowDidExpose:")]
		void WindowDidExpose (NSNotification notification);

		//- (void)windowWillMove:(NSNotification *)notification;
		[Export ("windowWillMove:")]
		void WindowWillMove (NSNotification notification);

		//- (void)windowDidMove:(NSNotification *)notification;
		[Export ("windowDidMove:")]
		void WindowDidMove (NSNotification notification);

		//- (void)windowDidBecomeKey:(NSNotification *)notification;
		[Export ("windowDidBecomeKey:")]
		void WindowDidBecomeKey (NSNotification notification);

		//- (void)windowDidResignKey:(NSNotification *)notification;
		[Export ("windowDidResignKey:")]
		void WindowDidResignKey (NSNotification notification);

		//- (void)windowDidBecomeMain:(NSNotification *)notification;
		[Export ("windowDidBecomeMain:")]
		void WindowDidBecomeMain (NSNotification notification);

		//- (void)windowDidResignMain:(NSNotification *)notification;
		[Export ("windowDidResignMain:")]
		void WindowDidResignMain (NSNotification notification);

		//- (void)windowWillClose:(NSNotification *)notification;
		[Export ("windowWillClose:")]
		void WindowWillClose (NSNotification notification);

		//- (void)windowWillMiniaturize:(NSNotification *)notification;
		[Export ("windowWillMiniaturize:")]
		void WindowWillMiniaturize (NSNotification notification);

		//- (void)windowDidMiniaturize:(NSNotification *)notification;
		[Export ("windowDidMiniaturize:")]
		void WindowDidMiniaturize (NSNotification notification);

		//- (void)windowDidDeminiaturize:(NSNotification *)notification;
		[Export ("windowDidDeminiaturize:")]
		void WindowDidDeminiaturize (NSNotification notification);

		//- (void)windowDidUpdate:(NSNotification *)notification;
		[Export ("windowDidUpdate:")]
		void WindowDidUpdate (NSNotification notification);

		//- (void)windowDidChangeScreen:(NSNotification *)notification;
		[Export ("windowDidChangeScreen:")]
		void WindowDidChangeScreen (NSNotification notification);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (void)windowDidChangeScreenProfile:(NSNotification *)notification;
		[Export ("windowDidChangeScreenProfile:")]
		void WindowDidChangeScreenProfile (NSNotification notification);

//#endif
		//- (void)windowWillBeginSheet:(NSNotification *)notification;
		[Export ("windowWillBeginSheet:")]
		void WindowWillBeginSheet (NSNotification notification);

		//- (void)windowDidEndSheet:(NSNotification *)notification;
		[Export ("windowDidEndSheet:")]
		void WindowDidEndSheet (NSNotification notification);

		//- (id)windowWillReturnFieldEditor:(NSWindow *)sender toObject:(id)client;
		[Export ("windowWillReturnFieldEditor:toObject:")]
		NSObject WindowWillReturnFieldEditorToObject (NSWindow sender, NSObject client);

		//- (NSSize)windowWillResize:(NSWindow *)sender toSize:(NSSize)frameSize;
		[Export ("windowWillResize:toSize:")]
		NSSize WindowWillResizeToSize (NSWindow sender, NSSize frameSize);

		//- (NSRect)windowWillUseStandardFrame:(NSWindow *)window defaultFrame:(NSRect)newFrame;
		[Export ("windowWillUseStandardFrame:defaultFrame:")]
		RectangleF WindowWillUseStandardFrameDefaultFrame (NSWindow window, RectangleF newFrame);

		//- (BOOL)windowShouldZoom:(NSWindow *)window toFrame:(NSRect)newFrame;
		[Export ("windowShouldZoom:toFrame:")]
		bool WindowShouldZoomToFrame (NSWindow window, RectangleF newFrame);

		//- (NSUndoManager *)windowWillReturnUndoManager:(NSWindow *)window;
		[Export ("windowWillReturnUndoManager:")]
		NSUndoManager WindowWillReturnUndoManager (NSWindow window);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//- (NSRect)window:(NSWindow *)window willPositionSheet:(NSWindow *)sheet usingRect:(NSRect)rect;
		[Export ("window:willPositionSheet:usingRect:")]
		RectangleF WindowWillPositionSheet (NSWindow window, NSWindow sheet, RectangleF rect);

//#endif
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (BOOL)window:(NSWindow *)window shouldPopUpDocumentPathMenu:(NSMenu *)menu;
		[Export ("window:shouldPopUpDocumentPathMenu:")]
		bool WindowShouldPopUpDocumentPathMenu (NSWindow window, NSMenu menu);

		//- (BOOL)window:(NSWindow *)window shouldDragDocumentWithEvent:(NSEvent *)event from:(NSPoint)dragImageLocation withPasteboard:(NSPasteboard *)pasteboard;
		[Export ("window:shouldDragDocumentWithEvent:from:withPasteboard:")]
		bool WindowShouldDragDocumentWithEvent (NSWindow window, NSEvent event1, PointF dragImageLocation, NSPasteboard pasteboard);

//#endif
	}
}
