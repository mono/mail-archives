using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSTextFieldCell))]
	interface NSSecureTextFieldCell {

		//- (BOOL)echosBullets;
		[Export ("echosBullets")]
		bool EchosBullets { get; set; }

	}
}
