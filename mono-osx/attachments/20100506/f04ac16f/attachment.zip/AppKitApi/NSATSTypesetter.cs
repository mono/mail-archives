using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSTypesetter))]
	interface NSATSTypesetter {

		//+ (id)sharedTypesetter;
		[Static, Export ("sharedTypesetter")]
		NSATSTypesetter SharedTypesetter { get; }

		//- (NSRect)lineFragmentRectForProposedRect:(NSRect)proposedRect remainingRect:(NSRectPointer)remainingRect DEPRECATED_IN_MAC_OS_X_VERSION_10_4_AND_LATER;
		[Export ("lineFragmentRectForProposedRect:remainingRect:")]
		RectangleF LineFragmentRectForProposedRectRemainingRect (RectangleF proposedRect, NSRectPointer remainingRect);

		//- (BOOL)usesFontLeading;
		[Export ("usesFontLeading")]
		bool UsesFontLeading { get; set; }

		//- (NSTypesetterBehavior)typesetterBehavior;
		[Export ("typesetterBehavior")]
		NSTypesetterBehavior TypesetterBehavior { get; set; }

		//- (float)hyphenationFactor;
		[Export ("hyphenationFactor")]
		float HyphenationFactor { get; set; }

		//- (CGFloat)lineFragmentPadding;
		[Export ("lineFragmentPadding")]
		float LineFragmentPadding { get; set; }

		//- (NSFont *)substituteFontForFont:(NSFont *)originalFont;
		[Export ("substituteFontForFont:")]
		NSFont SubstituteFontForFont (NSFont originalFont);

		//- (NSTextTab *)textTabForGlyphLocation:(CGFloat)glyphLocation writingDirection:(NSWritingDirection)direction maxLocation:(CGFloat)maxLocation;
		[Export ("textTabForGlyphLocation:writingDirection:maxLocation:")]
		NSTextTab TextTabForGlyphLocationWritingDirection (float glyphLocation, NSWritingDirection direction, float maxLocation);

		//- (BOOL)bidiProcessingEnabled;
		[Export ("bidiProcessingEnabled")]
		bool BidiProcessingEnabled { get; set; }

		//- (NSAttributedString *)attributedString;
		[Export ("attributedString")]
		NSAttributedString AttributedString { get; set; }

		//- (void)setParagraphGlyphRange:(NSRange)paragraphRange separatorGlyphRange:(NSRange)paragraphSeparatorRange;
		[Export ("setParagraphGlyphRange:separatorGlyphRange:")]
		void SetParagraphGlyphRangeSeparatorGlyphRange (NSRange paragraphRange, NSRange paragraphSeparatorRange);

		//- (NSRange)paragraphGlyphRange;
		[Export ("paragraphGlyphRange")]
		NSRange ParagraphGlyphRange { get; }

		//- (NSRange)paragraphSeparatorGlyphRange;
		[Export ("paragraphSeparatorGlyphRange")]
		NSRange ParagraphSeparatorGlyphRange { get; }

		//- (NSUInteger)layoutParagraphAtPoint:(NSPoint *)lineFragmentOrigin; 
		[Export ("layoutParagraphAtPoint:")]
		uint LayoutParagraphAtPoint (PointF lineFragmentOrigin);

		//- (CGFloat)lineSpacingAfterGlyphAtIndex:(NSUInteger)glyphIndex withProposedLineFragmentRect:(NSRect)rect;
		[Export ("lineSpacingAfterGlyphAtIndex:withProposedLineFragmentRect:")]
		float LineSpacingAfterGlyphAtIndexWithProposedLineFragmentRect (uint glyphIndex, RectangleF rect);

		//- (CGFloat)paragraphSpacingBeforeGlyphAtIndex:(NSUInteger)glyphIndex withProposedLineFragmentRect:(NSRect)rect;
		[Export ("paragraphSpacingBeforeGlyphAtIndex:withProposedLineFragmentRect:")]
		float ParagraphSpacingBeforeGlyphAtIndexWithProposedLineFragmentRect (uint glyphIndex, RectangleF rect);

		//- (CGFloat)paragraphSpacingAfterGlyphAtIndex:(NSUInteger)glyphIndex withProposedLineFragmentRect:(NSRect)rect;
		[Export ("paragraphSpacingAfterGlyphAtIndex:withProposedLineFragmentRect:")]
		float ParagraphSpacingAfterGlyphAtIndexWithProposedLineFragmentRect (uint glyphIndex, RectangleF rect);

		//- (NSLayoutManager *)layoutManager;
		[Export ("layoutManager")]
		NSLayoutManager LayoutManager { get; }

		//- (NSTextContainer *)currentTextContainer;
		[Export ("currentTextContainer")]
		NSTextContainer CurrentTextContainer { get; }

		//- (void)setHardInvalidation:(BOOL)flag forGlyphRange:(NSRange)glyphRange;
		[Export ("setHardInvalidation:forGlyphRange:")]
		void SetHardInvalidationForGlyphRange (bool flag, NSRange glyphRange);

		//- (void)getLineFragmentRect:(NSRect *)lineFragmentRect usedRect:(NSRect *)lineFragmentUsedRect forParagraphSeparatorGlyphRange:(NSRange)paragraphSeparatorGlyphRange atProposedOrigin:(NSPoint)lineOrigin;
		[Export ("getLineFragmentRect:usedRect:forParagraphSeparatorGlyphRange:atProposedOrigin:")]
		void GetLineFragmentRectUsedRect (RectangleF lineFragmentRect, RectangleF lineFragmentUsedRect, NSRange paragraphSeparatorGlyphRange, PointF lineOrigin);

		//- (void)willSetLineFragmentRect:(NSRect *)lineRect forGlyphRange:(NSRange)glyphRange usedRect:(NSRect *)usedRect baselineOffset:(CGFloat *)baselineOffset;
		[Export ("willSetLineFragmentRect:forGlyphRange:usedRect:baselineOffset:")]
		void WillSetLineFragmentRectForGlyphRange (RectangleF lineRect, NSRange glyphRange, RectangleF usedRect, float baselineOffset);

		//- (BOOL)shouldBreakLineByWordBeforeCharacterAtIndex:(NSUInteger)charIndex;
		[Export ("shouldBreakLineByWordBeforeCharacterAtIndex:")]
		bool ShouldBreakLineByWordBeforeCharacterAtIndex (uint charIndex);

		//- (BOOL)shouldBreakLineByHyphenatingBeforeCharacterAtIndex:(NSUInteger)charIndex;
		[Export ("shouldBreakLineByHyphenatingBeforeCharacterAtIndex:")]
		bool ShouldBreakLineByHyphenatingBeforeCharacterAtIndex (uint charIndex);

		//- (float)hyphenationFactorForGlyphAtIndex:(NSUInteger)glyphIndex;
		[Export ("hyphenationFactorForGlyphAtIndex:")]
		float HyphenationFactorForGlyphAtIndex (uint glyphIndex);

		//- (UTF32Char)hyphenCharacterForGlyphAtIndex:(NSUInteger)glyphIndex;
		[Export ("hyphenCharacterForGlyphAtIndex:")]
		UTF32Char HyphenCharacterForGlyphAtIndex (uint glyphIndex);

		//- (NSRect)boundingBoxForControlGlyphAtIndex:(NSUInteger)glyphIndex forTextContainer:(NSTextContainer *)textContainer proposedLineFragment:(NSRect)proposedRect glyphPosition:(NSPoint)glyphPosition characterIndex:(NSUInteger)charIndex;
		[Export ("boundingBoxForControlGlyphAtIndex:forTextContainer:proposedLineFragment:glyphPosition:characterIndex:")]
		RectangleF BoundingBoxForControlGlyphAtIndexForTextContainer (uint glyphIndex, NSTextContainer textContainer, RectangleF proposedRect, PointF glyphPosition, uint charIndex);

		//- (NSRange)characterRangeForGlyphRange:(NSRange)glyphRange actualGlyphRange:(NSRangePointer)actualGlyphRange;
		[Export ("characterRangeForGlyphRange:actualGlyphRange:")]
		NSRange CharacterRangeForGlyphRangeActualGlyphRange (NSRange glyphRange, NSRangePointer actualGlyphRange);

		//- (NSRange)glyphRangeForCharacterRange:(NSRange)charRange actualCharacterRange:(NSRangePointer)actualCharRange;
		[Export ("glyphRangeForCharacterRange:actualCharacterRange:")]
		NSRange GlyphRangeForCharacterRangeActualCharacterRange (NSRange charRange, NSRangePointer actualCharRange);

		//- (NSUInteger)getGlyphsInRange:(NSRange)glyphsRange glyphs:(NSGlyph *)glyphBuffer characterIndexes:(NSUInteger *)charIndexBuffer glyphInscriptions:(NSGlyphInscription *)inscribeBuffer elasticBits:(BOOL *)elasticBuffer;
		[Export ("getGlyphsInRange:glyphs:characterIndexes:glyphInscriptions:elasticBits:")]
		uint GetGlyphsInRangeGlyphs (NSRange glyphsRange, uint glyphBuffer, uint charIndexBuffer, NSGlyphInscription inscribeBuffer, bool elasticBuffer);

		//- (void)setLineFragmentRect:(NSRect)fragmentRect forGlyphRange:(NSRange)glyphRange usedRect:(NSRect)usedRect baselineOffset:(CGFloat)baselineOffset;
		[Export ("setLineFragmentRect:forGlyphRange:usedRect:baselineOffset:")]
		void SetLineFragmentRectForGlyphRange (RectangleF fragmentRect, NSRange glyphRange, RectangleF usedRect, float baselineOffset);

		//- (void)substituteGlyphsInRange:(NSRange)glyphRange withGlyphs:(NSGlyph *)glyphs;
		[Export ("substituteGlyphsInRange:withGlyphs:")]
		void SubstituteGlyphsInRangeWithGlyphs (NSRange glyphRange, uint glyphs);

		//- (void)insertGlyph:(NSGlyph)glyph atGlyphIndex:(NSUInteger)glyphIndex characterIndex:(NSUInteger)characterIndex;
		[Export ("insertGlyph:atGlyphIndex:characterIndex:")]
		void InsertGlyphAtGlyphIndex (uint glyph, uint glyphIndex, uint characterIndex);

		//- (void)deleteGlyphsInRange:(NSRange)glyphRange;
		[Export ("deleteGlyphsInRange:")]
		void DeleteGlyphsInRange (NSRange glyphRange);

		//- (void)setNotShownAttribute:(BOOL)flag forGlyphRange:(NSRange)glyphRange;
		[Export ("setNotShownAttribute:forGlyphRange:")]
		void SetNotShownAttributeForGlyphRange (bool flag, NSRange glyphRange);

		//- (void)setDrawsOutsideLineFragment:(BOOL)flag forGlyphRange:(NSRange)glyphRange;
		[Export ("setDrawsOutsideLineFragment:forGlyphRange:")]
		void SetDrawsOutsideLineFragmentForGlyphRange (bool flag, NSRange glyphRange);

		////- (void)setLocation:(NSPoint)location withAdvancements:(const CGFloat *)advancements forStartOfGlyphRange:(NSRange)glyphRange;
		//[Export ("setLocation:withAdvancements:forStartOfGlyphRange:")]
		//void SetLocationWithAdvancements (PointF location, const CGFloat advancements, NSRange glyphRange);

		//- (void)setAttachmentSize:(NSSize)attachmentSize forGlyphRange:(NSRange)glyphRange;
		[Export ("setAttachmentSize:forGlyphRange:")]
		void SetAttachmentSizeForGlyphRange (NSSize attachmentSize, NSRange glyphRange);

		////- (void)setBidiLevels:(const uint8_t *)levels forGlyphRange:(NSRange)glyphRange;
		//[Export ("setBidiLevels:forGlyphRange:")]
		//void SetBidiLevelsForGlyphRange (const uint8_t levels, NSRange glyphRange);

	}
}
