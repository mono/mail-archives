using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSObject))]
	interface NSStatusBar {

		//+ (NSStatusBar*)systemStatusBar;
		[Static, Export ("systemStatusBar")]
		NSStatusBar SystemStatusBar { get; }

		//- (NSStatusItem*)statusItemWithLength:(CGFloat)length;
		[Export ("statusItemWithLength:")]
		NSStatusItem StatusItemWithLength (float length);

		//- (void)removeStatusItem:(NSStatusItem*)item;
		[Export ("removeStatusItem:")]
		void RemoveStatusItem (NSStatusItem item);

		//- (BOOL)isVertical;
		[Export ("isVertical")]
		bool IsVertical { get; }

		//- (CGFloat)thickness;
		[Export ("thickness")]
		float Thickness { get; }

	}
}
