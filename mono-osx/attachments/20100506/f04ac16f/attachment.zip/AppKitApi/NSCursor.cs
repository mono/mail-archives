using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSObject))]
	interface NSCursor {

		//+ (NSCursor *)currentCursor;
		[Static, Export ("currentCursor")]
		NSCursor CurrentCursor { get; }

		//+ (NSCursor *)arrowCursor;
		[Static, Export ("arrowCursor")]
		NSCursor ArrowCursor { get; }

		//+ (NSCursor *)IBeamCursor;
		[Static, Export ("IBeamCursor")]
		NSCursor IBeamCursor { get; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//+ (NSCursor *)pointingHandCursor;
		[Static, Export ("pointingHandCursor")]
		NSCursor PointingHandCursor { get; }

		//+ (NSCursor *)closedHandCursor;
		[Static, Export ("closedHandCursor")]
		NSCursor ClosedHandCursor { get; }

		//+ (NSCursor *)openHandCursor;
		[Static, Export ("openHandCursor")]
		NSCursor OpenHandCursor { get; }

		//+ (NSCursor *)resizeLeftCursor;
		[Static, Export ("resizeLeftCursor")]
		NSCursor ResizeLeftCursor { get; }

		//+ (NSCursor *)resizeRightCursor;
		[Static, Export ("resizeRightCursor")]
		NSCursor ResizeRightCursor { get; }

		//+ (NSCursor *)resizeLeftRightCursor;
		[Static, Export ("resizeLeftRightCursor")]
		NSCursor ResizeLeftRightCursor { get; }

		//+ (NSCursor *)resizeUpCursor;
		[Static, Export ("resizeUpCursor")]
		NSCursor ResizeUpCursor { get; }

		//+ (NSCursor *)resizeDownCursor;
		[Static, Export ("resizeDownCursor")]
		NSCursor ResizeDownCursor { get; }

		//+ (NSCursor *)resizeUpDownCursor;
		[Static, Export ("resizeUpDownCursor")]
		NSCursor ResizeUpDownCursor { get; }

		//+ (NSCursor *)crosshairCursor;
		[Static, Export ("crosshairCursor")]
		NSCursor CrosshairCursor { get; }

		//+ (NSCursor *)disappearingItemCursor;
		[Static, Export ("disappearingItemCursor")]
		NSCursor DisappearingItemCursor { get; }

//#endif
		//- (id)initWithImage:(NSImage *)newImage hotSpot:(NSPoint)aPoint;
		[Export ("initWithImage:hotSpot:")]
		IntPtr Constructor (NSImage newImage, PointF aPoint);

		//- (id)initWithImage:(NSImage *)newImage	foregroundColorHint:(NSColor *)fg backgroundColorHint:(NSColor *)bg hotSpot:(NSPoint)hotSpot;
		[Export ("initWithImage:foregroundColorHint:backgroundColorHint:hotSpot:")]
		IntPtr Constructor (NSImage newImage, NSColor fg, NSColor bg, PointF hotSpot);

		//+ (void)hide;
		[Static, Export ("hide")]
		void Hide ();

		//+ (void)unhide;
		[Static, Export ("unhide")]
		void Unhide ();

		//+ (void)setHiddenUntilMouseMoves:(BOOL)flag;
		[Static, Export ("setHiddenUntilMouseMoves:")]
		void SetHiddenUntilMouseMoves (bool flag);

		//+ (void)pop;
		[Static, Export ("pop")]
		void Pop ();

		//- (NSImage *)image;
		[Export ("image")]
		NSImage Image { get; }

		//- (NSPoint)hotSpot;
		[Export ("hotSpot")]
		PointF HotSpot { get; }

		//- (void)push;
		[Export ("push")]
		void Push ();

		//- (void)pop;
		[Export ("pop")]
		void Pop ();

		//- (void)set;
		[Export ("set")]
		void Set ();

		//- (void)setOnMouseExited:(BOOL)flag;
		[Export ("setOnMouseExited:")]
		void SetOnMouseExited (bool flag);

		//- (void)setOnMouseEntered:(BOOL)flag;
		[Export ("setOnMouseEntered:")]
		void SetOnMouseEntered (bool flag);

		//- (BOOL)isSetOnMouseExited;
		[Export ("isSetOnMouseExited")]
		bool IsSetOnMouseExited { get; }

		//- (BOOL)isSetOnMouseEntered;
		[Export ("isSetOnMouseEntered")]
		bool IsSetOnMouseEntered { get; }

		//- (void)mouseEntered:(NSEvent *)theEvent;
		[Export ("mouseEntered:")]
		void MouseEntered (NSEvent theEvent);

		//- (void)mouseExited:(NSEvent *)theEvent;
		[Export ("mouseExited:")]
		void MouseExited (NSEvent theEvent);

	}
}
