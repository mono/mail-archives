using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSController))]
	interface NSUserDefaultsController {

		//+ (id)sharedUserDefaultsController;
		[Static, Export ("sharedUserDefaultsController")]
		NSUserDefaultsController SharedUserDefaultsController { get; }

		//- (id)initWithDefaults:(NSUserDefaults *)defaults initialValues:(NSDictionary *)initialValues;    
		[Export ("initWithDefaults:initialValues:")]
		IntPtr Constructor (NSUserDefaults defaults, NSDictionary initialValues);

		//- (NSUserDefaults *)defaults;
		[Export ("defaults")]
		NSUserDefaults Defaults { get; }

		//- (NSDictionary *)initialValues;
		[Export ("initialValues")]
		NSDictionary InitialValues { get; set; }

		//- (BOOL)appliesImmediately;
		[Export ("appliesImmediately")]
		bool AppliesImmediately { get; set; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (BOOL)hasUnappliedChanges;
		[Export ("hasUnappliedChanges")]
		bool HasUnappliedChanges { get; }

//#endif
		//- (id)values;    
		[Export ("values")]
		NSUserDefaultsController Values { get; }

		//- (void)revert:(id)sender;
		[Export ("revert:")]
		void Revert (NSObject sender);

		//- (void)save:(id)sender;    
		[Export ("save:")]
		void Save (NSObject sender);

		//- (void)revertToInitialValues:(id)sender;    
		[Export ("revertToInitialValues:")]
		void RevertToInitialValues (NSObject sender);

	}
}
