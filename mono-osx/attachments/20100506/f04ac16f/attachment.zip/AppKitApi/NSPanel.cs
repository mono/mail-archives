using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSWindow))]
	interface NSPanel {

		//- (BOOL)isFloatingPanel;
		[Export ("isFloatingPanel")]
		bool IsFloatingPanel { get; }

		//- (void)setFloatingPanel:(BOOL)flag;
		[Export ("setFloatingPanel:")]
		void SetFloatingPanel (bool flag);

		//- (BOOL)becomesKeyOnlyIfNeeded;
		[Export ("becomesKeyOnlyIfNeeded")]
		bool BecomesKeyOnlyIfNeeded { get; set; }

		//- (BOOL)worksWhenModal;
		[Export ("worksWhenModal")]
		bool WorksWhenModal { get; set; }

	}
}
