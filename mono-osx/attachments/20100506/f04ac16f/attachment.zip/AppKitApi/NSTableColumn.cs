using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSObject))]
	interface NSTableColumn {

		//- (id)initWithIdentifier:(id)identifier;
		[Export ("initWithIdentifier:")]
		IntPtr Constructor (NSObject identifier);

		//- (void)setIdentifier:(id)identifier;
		[Export ("setIdentifier:")]
		void SetIdentifier (NSObject identifier);

		//- (id)identifier;
		[Export ("identifier")]
		NSTableColumn Identifier { get; }

		//- (NSTableView *)tableView;
		[Export ("tableView")]
		NSTableView TableView { get; set; }

		//- (CGFloat)width;
		[Export ("width")]
		float Width { get; set; }

		//- (CGFloat)minWidth;
		[Export ("minWidth")]
		float MinWidth { get; set; }

		//- (CGFloat)maxWidth;
		[Export ("maxWidth")]
		float MaxWidth { get; set; }

		//- (void)setHeaderCell:(NSCell *)cell; 
		[Export ("setHeaderCell:")]
		void SetHeaderCell (NSCell cell);

		//- (id)headerCell;
		[Export ("headerCell")]
		NSTableColumn HeaderCell { get; }

		//- (void)setDataCell:(NSCell *)cell;
		[Export ("setDataCell:")]
		void SetDataCell (NSCell cell);

		//- (id)dataCell;
		[Export ("dataCell")]
		NSTableColumn DataCell { get; }

		//- (id)dataCellForRow:(NSInteger)row;
		[Export ("dataCellForRow:")]
		NSTableColumn DataCellForRow (int row);

		//    - (void)setEditable:(BOOL)flag;
		[Export ("setEditable:")]
		void SetEditable (bool flag);

		//- (BOOL)isEditable;
		[Export ("isEditable")]
		bool IsEditable { get; }

		//- (void)sizeToFit;
		[Export ("sizeToFit")]
		void SizeToFit ();

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//- (NSSortDescriptor *)sortDescriptorPrototype;
		[Export ("sortDescriptorPrototype")]
		NSSortDescriptor SortDescriptorPrototype { get; set; }

//#endif
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (NSUInteger)resizingMask;
		[Export ("resizingMask")]
		uint ResizingMask { get; set; }

		////enum {    NSTableColumnNoResizing = 0,     NSTableColumnAutoresizingMask = ( 1 << 0 ),         NSTableColumnUserResizingMask = ( 1 << 1 ),     };
		//[Export (",         NSTableColumnUserResizingMask = ( 1 << 1 ),     }")]
		//1 ,         NSTableColumnUserResizingMask = ( 1 << 1 ),     } { get; }

//#endif
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (NSString *)headerToolTip;
		[Export ("headerToolTip")]
		string HeaderToolTip { get; set; }

		//- (BOOL)isHidden;
		[Export ("isHidden")]
		bool IsHidden { get; }

		//- (void)setHidden:(BOOL)hidden;
		[Export ("setHidden:")]
		void SetHidden (bool hidden);

//#endif
		//- (void)setResizable:(BOOL)flag;
		[Export ("setResizable:")]
		void SetResizable (bool flag);

		//- (BOOL)isResizable;
		[Export ("isResizable")]
		bool IsResizable { get; }

	}
}
