using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSObject))]
	interface NSShadow {

		//- (id)init;     
		[Export ("init")]
		IntPtr Init { get; }

		//- (NSSize)shadowOffset;  
		[Export ("shadowOffset")]
		NSSize ShadowOffset { get; set; }

		//- (CGFloat)shadowBlurRadius;      
		[Export ("shadowBlurRadius")]
		float ShadowBlurRadius { get; set; }

		//- (NSColor *)shadowColor;   
		[Export ("shadowColor")]
		NSColor ShadowColor { get; set; }

		//- (void)set;
		[Export ("set")]
		void Set ();

	}
}
