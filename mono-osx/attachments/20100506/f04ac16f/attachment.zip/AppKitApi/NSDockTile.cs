using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSObject))]
	interface NSDockTile {

		//- (NSSize)size;
		[Export ("size")]
		NSSize Size { get; }

		//- (NSView *)contentView;
		[Export ("contentView")]
		NSView ContentView { get; set; }

		//- (void)display;
		[Export ("display")]
		void Display ();

		//- (BOOL)showsApplicationBadge;
		[Export ("showsApplicationBadge")]
		bool ShowsApplicationBadge { get; set; }

		//- (NSString *)badgeLabel;
		[Export ("badgeLabel")]
		string BadgeLabel { get; set; }

		//- (id)owner;
		[Export ("owner")]
		NSDockTile Owner { get; }

	}
}
