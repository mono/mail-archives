using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSObject))]
	interface NSResponder {

		//- (void)setInterfaceStyle:(NSInterfaceStyle)interfaceStyle;
		[Export ("setInterfaceStyle:")]
		void SetInterfaceStyle (NSInterfaceStyle interfaceStyle);

		//- (NSResponder *)nextResponder;
		[Export ("nextResponder")]
		NSResponder NextResponder { get; set; }

		//- (BOOL)tryToPerform:(SEL)anAction with:(id)anObject;
		[Export ("tryToPerform:with:")]
		bool TryToPerform (Selector anAction, NSObject anObject);

		//- (BOOL)performKeyEquivalent:(NSEvent *)theEvent;
		[Export ("performKeyEquivalent:")]
		bool PerformKeyEquivalent (NSEvent theEvent);

		//- (id)validRequestorForSendType:(NSString *)sendType returnType:(NSString *)returnType;
		[Export ("validRequestorForSendType:returnType:")]
		NSResponder ValidRequestorForSendType (string sendType, string returnType);

		//- (void)mouseDown:(NSEvent *)theEvent;
		[Export ("mouseDown:")]
		void MouseDown (NSEvent theEvent);

		//- (void)rightMouseDown:(NSEvent *)theEvent;
		[Export ("rightMouseDown:")]
		void RightMouseDown (NSEvent theEvent);

		//- (void)otherMouseDown:(NSEvent *)theEvent;
		[Export ("otherMouseDown:")]
		void OtherMouseDown (NSEvent theEvent);

		//- (void)mouseUp:(NSEvent *)theEvent;
		[Export ("mouseUp:")]
		void MouseUp (NSEvent theEvent);

		//- (void)rightMouseUp:(NSEvent *)theEvent;
		[Export ("rightMouseUp:")]
		void RightMouseUp (NSEvent theEvent);

		//- (void)otherMouseUp:(NSEvent *)theEvent;
		[Export ("otherMouseUp:")]
		void OtherMouseUp (NSEvent theEvent);

		//- (void)mouseMoved:(NSEvent *)theEvent;
		[Export ("mouseMoved:")]
		void MouseMoved (NSEvent theEvent);

		//- (void)mouseDragged:(NSEvent *)theEvent;
		[Export ("mouseDragged:")]
		void MouseDragged (NSEvent theEvent);

		//- (void)scrollWheel:(NSEvent *)theEvent;
		[Export ("scrollWheel:")]
		void ScrollWheel (NSEvent theEvent);

		//- (void)rightMouseDragged:(NSEvent *)theEvent;
		[Export ("rightMouseDragged:")]
		void RightMouseDragged (NSEvent theEvent);

		//- (void)otherMouseDragged:(NSEvent *)theEvent;
		[Export ("otherMouseDragged:")]
		void OtherMouseDragged (NSEvent theEvent);

		//- (void)mouseEntered:(NSEvent *)theEvent;
		[Export ("mouseEntered:")]
		void MouseEntered (NSEvent theEvent);

		//- (void)mouseExited:(NSEvent *)theEvent;
		[Export ("mouseExited:")]
		void MouseExited (NSEvent theEvent);

		//- (void)keyDown:(NSEvent *)theEvent;
		[Export ("keyDown:")]
		void KeyDown (NSEvent theEvent);

		//- (void)keyUp:(NSEvent *)theEvent;
		[Export ("keyUp:")]
		void KeyUp (NSEvent theEvent);

		//- (void)flagsChanged:(NSEvent *)theEvent;
		[Export ("flagsChanged:")]
		void FlagsChanged (NSEvent theEvent);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (void)tabletPoint:(NSEvent *)theEvent;
		[Export ("tabletPoint:")]
		void TabletPoint (NSEvent theEvent);

		//- (void)tabletProximity:(NSEvent *)theEvent;
		[Export ("tabletProximity:")]
		void TabletProximity (NSEvent theEvent);

//#endif
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (void)cursorUpdate:(NSEvent *)event;
		[Export ("cursorUpdate:")]
		void CursorUpdate (NSEvent event1);

//#endif
		//- (void)noResponderFor:(SEL)eventSelector;
		[Export ("noResponderFor:")]
		void NoResponderFor (Selector eventSelector);

		//- (BOOL)acceptsFirstResponder;
		[Export ("acceptsFirstResponder")]
		bool AcceptsFirstResponder { get; }

		//- (BOOL)becomeFirstResponder;
		[Export ("becomeFirstResponder")]
		bool BecomeFirstResponder { get; }

		//- (BOOL)resignFirstResponder;
		[Export ("resignFirstResponder")]
		bool ResignFirstResponder { get; }

		//- (void)interpretKeyEvents:(NSArray *)eventArray;
		[Export ("interpretKeyEvents:")]
		void InterpretKeyEvents (NSArray eventArray);

		//- (void)flushBufferedKeyEvents;
		[Export ("flushBufferedKeyEvents")]
		void FlushBufferedKeyEvents ();

		//- (NSMenu *)menu;
		[Export ("menu")]
		NSMenu Menu { get; set; }

		//- (void)showContextHelp:(id)sender;
		[Export ("showContextHelp:")]
		void ShowContextHelp (NSObject sender);

		//- (void)helpRequested:(NSEvent *)eventPtr;
		[Export ("helpRequested:")]
		void HelpRequested (NSEvent eventPtr);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_2
		//- (BOOL)shouldBeTreatedAsInkEvent:(NSEvent *)theEvent;
		[Export ("shouldBeTreatedAsInkEvent:")]
		bool ShouldBeTreatedAsInkEvent (NSEvent theEvent);

//#endif
		//- (void)insertText:(id)insertString;
		[Export ("insertText:")]
		void InsertText (NSObject insertString);

		//    - (void)doCommandBySelector:(SEL)aSelector;
		[Export ("doCommandBySelector:")]
		void DoCommandBySelector (Selector aSelector);

		//        - (void)moveForward:(id)sender;
		[Export ("moveForward:")]
		void MoveForward (NSObject sender);

		//- (void)moveRight:(id)sender;
		[Export ("moveRight:")]
		void MoveRight (NSObject sender);

		//- (void)moveBackward:(id)sender;
		[Export ("moveBackward:")]
		void MoveBackward (NSObject sender);

		//- (void)moveLeft:(id)sender;
		[Export ("moveLeft:")]
		void MoveLeft (NSObject sender);

		//- (void)moveUp:(id)sender;
		[Export ("moveUp:")]
		void MoveUp (NSObject sender);

		//- (void)moveDown:(id)sender;
		[Export ("moveDown:")]
		void MoveDown (NSObject sender);

		//- (void)moveWordForward:(id)sender;
		[Export ("moveWordForward:")]
		void MoveWordForward (NSObject sender);

		//- (void)moveWordBackward:(id)sender;
		[Export ("moveWordBackward:")]
		void MoveWordBackward (NSObject sender);

		//- (void)moveToBeginningOfLine:(id)sender;
		[Export ("moveToBeginningOfLine:")]
		void MoveToBeginningOfLine (NSObject sender);

		//- (void)moveToEndOfLine:(id)sender;
		[Export ("moveToEndOfLine:")]
		void MoveToEndOfLine (NSObject sender);

		//- (void)moveToBeginningOfParagraph:(id)sender;
		[Export ("moveToBeginningOfParagraph:")]
		void MoveToBeginningOfParagraph (NSObject sender);

		//- (void)moveToEndOfParagraph:(id)sender;
		[Export ("moveToEndOfParagraph:")]
		void MoveToEndOfParagraph (NSObject sender);

		//- (void)moveToEndOfDocument:(id)sender;
		[Export ("moveToEndOfDocument:")]
		void MoveToEndOfDocument (NSObject sender);

		//- (void)moveToBeginningOfDocument:(id)sender;
		[Export ("moveToBeginningOfDocument:")]
		void MoveToBeginningOfDocument (NSObject sender);

		//- (void)pageDown:(id)sender;
		[Export ("pageDown:")]
		void PageDown (NSObject sender);

		//- (void)pageUp:(id)sender;
		[Export ("pageUp:")]
		void PageUp (NSObject sender);

		//- (void)centerSelectionInVisibleArea:(id)sender;
		[Export ("centerSelectionInVisibleArea:")]
		void CenterSelectionInVisibleArea (NSObject sender);

		//- (void)moveBackwardAndModifySelection:(id)sender;
		[Export ("moveBackwardAndModifySelection:")]
		void MoveBackwardAndModifySelection (NSObject sender);

		//- (void)moveForwardAndModifySelection:(id)sender;
		[Export ("moveForwardAndModifySelection:")]
		void MoveForwardAndModifySelection (NSObject sender);

		//- (void)moveWordForwardAndModifySelection:(id)sender;
		[Export ("moveWordForwardAndModifySelection:")]
		void MoveWordForwardAndModifySelection (NSObject sender);

		//- (void)moveWordBackwardAndModifySelection:(id)sender;
		[Export ("moveWordBackwardAndModifySelection:")]
		void MoveWordBackwardAndModifySelection (NSObject sender);

		//- (void)moveUpAndModifySelection:(id)sender;
		[Export ("moveUpAndModifySelection:")]
		void MoveUpAndModifySelection (NSObject sender);

		//- (void)moveDownAndModifySelection:(id)sender;
		[Export ("moveDownAndModifySelection:")]
		void MoveDownAndModifySelection (NSObject sender);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//- (void)moveWordRight:(id)sender;
		[Export ("moveWordRight:")]
		void MoveWordRight (NSObject sender);

		//- (void)moveWordLeft:(id)sender;
		[Export ("moveWordLeft:")]
		void MoveWordLeft (NSObject sender);

		//- (void)moveRightAndModifySelection:(id)sender;
		[Export ("moveRightAndModifySelection:")]
		void MoveRightAndModifySelection (NSObject sender);

		//- (void)moveLeftAndModifySelection:(id)sender;
		[Export ("moveLeftAndModifySelection:")]
		void MoveLeftAndModifySelection (NSObject sender);

		//- (void)moveWordRightAndModifySelection:(id)sender;
		[Export ("moveWordRightAndModifySelection:")]
		void MoveWordRightAndModifySelection (NSObject sender);

		//- (void)moveWordLeftAndModifySelection:(id)sender;
		[Export ("moveWordLeftAndModifySelection:")]
		void MoveWordLeftAndModifySelection (NSObject sender);

//#endif
		//- (void)scrollPageUp:(id)sender;
		[Export ("scrollPageUp:")]
		void ScrollPageUp (NSObject sender);

		//- (void)scrollPageDown:(id)sender;
		[Export ("scrollPageDown:")]
		void ScrollPageDown (NSObject sender);

		//- (void)scrollLineUp:(id)sender;
		[Export ("scrollLineUp:")]
		void ScrollLineUp (NSObject sender);

		//- (void)scrollLineDown:(id)sender;
		[Export ("scrollLineDown:")]
		void ScrollLineDown (NSObject sender);

		//    - (void)transpose:(id)sender;
		[Export ("transpose:")]
		void Transpose (NSObject sender);

		//- (void)transposeWords:(id)sender;
		[Export ("transposeWords:")]
		void TransposeWords (NSObject sender);

		//    - (void)selectAll:(id)sender;
		[Export ("selectAll:")]
		void SelectAll (NSObject sender);

		//- (void)selectParagraph:(id)sender;
		[Export ("selectParagraph:")]
		void SelectParagraph (NSObject sender);

		//- (void)selectLine:(id)sender;
		[Export ("selectLine:")]
		void SelectLine (NSObject sender);

		//- (void)selectWord:(id)sender;
		[Export ("selectWord:")]
		void SelectWord (NSObject sender);

		//    - (void)indent:(id)sender;
		[Export ("indent:")]
		void Indent (NSObject sender);

		//- (void)insertTab:(id)sender;
		[Export ("insertTab:")]
		void InsertTab (NSObject sender);

		//- (void)insertBacktab:(id)sender;
		[Export ("insertBacktab:")]
		void InsertBacktab (NSObject sender);

		//- (void)insertNewline:(id)sender;
		[Export ("insertNewline:")]
		void InsertNewline (NSObject sender);

		//- (void)insertParagraphSeparator:(id)sender;
		[Export ("insertParagraphSeparator:")]
		void InsertParagraphSeparator (NSObject sender);

		//- (void)insertNewlineIgnoringFieldEditor:(id)sender;
		[Export ("insertNewlineIgnoringFieldEditor:")]
		void InsertNewlineIgnoringFieldEditor (NSObject sender);

		//- (void)insertTabIgnoringFieldEditor:(id)sender;
		[Export ("insertTabIgnoringFieldEditor:")]
		void InsertTabIgnoringFieldEditor (NSObject sender);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (void)insertLineBreak:(id)sender;
		[Export ("insertLineBreak:")]
		void InsertLineBreak (NSObject sender);

		//- (void)insertContainerBreak:(id)sender;
		[Export ("insertContainerBreak:")]
		void InsertContainerBreak (NSObject sender);

//#endif 
		//    - (void)changeCaseOfLetter:(id)sender;
		[Export ("changeCaseOfLetter:")]
		void ChangeCaseOfLetter (NSObject sender);

		//- (void)uppercaseWord:(id)sender;
		[Export ("uppercaseWord:")]
		void UppercaseWord (NSObject sender);

		//- (void)lowercaseWord:(id)sender;
		[Export ("lowercaseWord:")]
		void LowercaseWord (NSObject sender);

		//- (void)capitalizeWord:(id)sender;
		[Export ("capitalizeWord:")]
		void CapitalizeWord (NSObject sender);

		//    - (void)deleteForward:(id)sender;
		[Export ("deleteForward:")]
		void DeleteForward (NSObject sender);

		//- (void)deleteBackward:(id)sender;
		[Export ("deleteBackward:")]
		void DeleteBackward (NSObject sender);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//- (void)deleteBackwardByDecomposingPreviousCharacter:(id)sender;
		[Export ("deleteBackwardByDecomposingPreviousCharacter:")]
		void DeleteBackwardByDecomposingPreviousCharacter (NSObject sender);

//#endif 
		//- (void)deleteWordForward:(id)sender;
		[Export ("deleteWordForward:")]
		void DeleteWordForward (NSObject sender);

		//- (void)deleteWordBackward:(id)sender;
		[Export ("deleteWordBackward:")]
		void DeleteWordBackward (NSObject sender);

		//- (void)deleteToBeginningOfLine:(id)sender;
		[Export ("deleteToBeginningOfLine:")]
		void DeleteToBeginningOfLine (NSObject sender);

		//- (void)deleteToEndOfLine:(id)sender;
		[Export ("deleteToEndOfLine:")]
		void DeleteToEndOfLine (NSObject sender);

		//- (void)deleteToBeginningOfParagraph:(id)sender;
		[Export ("deleteToBeginningOfParagraph:")]
		void DeleteToBeginningOfParagraph (NSObject sender);

		//- (void)deleteToEndOfParagraph:(id)sender;
		[Export ("deleteToEndOfParagraph:")]
		void DeleteToEndOfParagraph (NSObject sender);

		//- (void)yank:(id)sender;
		[Export ("yank:")]
		void Yank (NSObject sender);

		//    - (void)complete:(id)sender;
		[Export ("complete:")]
		void Complete (NSObject sender);

		//    - (void)setMark:(id)sender;
		[Export ("setMark:")]
		void SetMark (NSObject sender);

		//- (void)deleteToMark:(id)sender;
		[Export ("deleteToMark:")]
		void DeleteToMark (NSObject sender);

		//- (void)selectToMark:(id)sender;
		[Export ("selectToMark:")]
		void SelectToMark (NSObject sender);

		//- (void)swapWithMark:(id)sender;
		[Export ("swapWithMark:")]
		void SwapWithMark (NSObject sender);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//    - (void)cancelOperation:(id)sender;
		[Export ("cancelOperation:")]
		void CancelOperation (NSObject sender);

//#endif 
		//- (void)presentError:(NSError *)error modalForWindow:(NSWindow *)window delegate:(id)delegate didPresentSelector:(SEL)didPresentSelector contextInfo:(void *)contextInfo;
		[Export ("presentError:modalForWindow:delegate:didPresentSelector:contextInfo:")]
		void PresentErrorModalForWindow (NSError error, NSWindow window, NSObject delegate1, Selector didPresentSelector, IntPtr contextInfo);

		//- (BOOL)presentError:(NSError *)error;
		[Export ("presentError:")]
		bool PresentError (NSError error);

		//- (NSError *)willPresentError:(NSError *)error;
		[Export ("willPresentError:")]
		NSError WillPresentError (NSError error);

	}
}
