using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSObject))]
	interface NSFileWrapper {

		//- (id)initDirectoryWithFileWrappers:(NSDictionary *)docs;
		[Export ("initDirectoryWithFileWrappers:")]
		IntPtr Constructor (NSDictionary docs);

		//    - (id)initRegularFileWithContents:(NSData *)data;
		[Export ("initRegularFileWithContents:")]
		IntPtr Constructor (NSData data);

		////    - (id)initSymbolicLinkWithDestination:(NSString *)path;
		//[Export ("initSymbolicLinkWithDestination:")]
		//IntPtr Constructor (string path);

		//    - (id)initWithPath:(NSString *)path;
		[Export ("initWithPath:")]
		IntPtr Constructor (string path);

		//    - (id)initWithSerializedRepresentation:(NSData *)data;
		[Export ("initWithSerializedRepresentation:")]
		IntPtr Constructor (NSData data);

		//    - (BOOL)writeToFile:(NSString *)path atomically:(BOOL)atomicFlag updateFilenames:(BOOL)updateFilenamesFlag;
		[Export ("writeToFile:atomically:updateFilenames:")]
		bool WriteToFile (string path, bool atomicFlag, bool updateFilenamesFlag);

		//    - (NSData *)serializedRepresentation;
		[Export ("serializedRepresentation")]
		NSData SerializedRepresentation { get; }

		//- (NSString *)filename;
		[Export ("filename")]
		string Filename { get; set; }

		//- (NSString *)preferredFilename;
		[Export ("preferredFilename")]
		string PreferredFilename { get; set; }

		//- (NSDictionary *)fileAttributes;
		[Export ("fileAttributes")]
		NSDictionary FileAttributes { get; set; }

		//    - (BOOL)isRegularFile;
		[Export ("isRegularFile")]
		bool IsRegularFile { get; }

		//- (BOOL)isDirectory;
		[Export ("isDirectory")]
		bool IsDirectory { get; }

		//- (BOOL)isSymbolicLink;
		[Export ("isSymbolicLink")]
		bool IsSymbolicLink { get; }

		//- (NSImage *)icon;
		[Export ("icon")]
		NSImage Icon { get; set; }

		//    - (BOOL)needsToBeUpdatedFromPath:(NSString *)path;
		[Export ("needsToBeUpdatedFromPath:")]
		bool NeedsToBeUpdatedFromPath (string path);

		//- (BOOL)updateFromPath:(NSString *)path;
		[Export ("updateFromPath:")]
		bool UpdateFromPath (string path);

		//    - (NSString *)addFileWrapper:(NSFileWrapper *)doc;
		[Export ("addFileWrapper:")]
		string AddFileWrapper (NSFileWrapper doc);

		//    - (void)removeFileWrapper:(NSFileWrapper *)doc;
		[Export ("removeFileWrapper:")]
		void RemoveFileWrapper (NSFileWrapper doc);

		//    - (NSDictionary *)fileWrappers;
		[Export ("fileWrappers")]
		NSDictionary FileWrappers { get; }

		//    - (NSString *)keyForFileWrapper:(NSFileWrapper *)doc;
		[Export ("keyForFileWrapper:")]
		string KeyForFileWrapper (NSFileWrapper doc);

		//    - (NSString *)addFileWithPath:(NSString *)path;
		[Export ("addFileWithPath:")]
		string AddFileWithPath (string path);

		//- (NSString *)addRegularFileWithContents:(NSData *)data preferredFilename:(NSString *)filename;
		[Export ("addRegularFileWithContents:preferredFilename:")]
		string AddRegularFileWithContents (NSData data, string filename);

		//- (NSString *)addSymbolicLinkWithDestination:(NSString *)path preferredFilename:(NSString *)filename;
		[Export ("addSymbolicLinkWithDestination:preferredFilename:")]
		string AddSymbolicLinkWithDestination (string path, string filename);

		//    - (NSData *)regularFileContents;
		[Export ("regularFileContents")]
		NSData RegularFileContents { get; }

		//    - (NSString *)symbolicLinkDestination;
		[Export ("symbolicLinkDestination")]
		string SymbolicLinkDestination { get; }

	}
}
