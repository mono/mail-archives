using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSView))]
	interface NSProgressIndicator {

		//	- (BOOL)isIndeterminate;				
		[Export ("isIndeterminate")]
		bool IsIndeterminate { get; }

		//- (void)setIndeterminate:(BOOL)flag;
		[Export ("setIndeterminate:")]
		void SetIndeterminate (bool flag);

		//- (BOOL)isBezeled;
		[Export ("isBezeled")]
		bool IsBezeled { get; }

		//- (void)setBezeled:(BOOL)flag;
		[Export ("setBezeled:")]
		void SetBezeled (bool flag);

		//- (NSControlTint)controlTint;
		[Export ("controlTint")]
		NSControlTint ControlTint { get; set; }

		//- (NSControlSize)controlSize;
		[Export ("controlSize")]
		NSControlSize ControlSize { get; set; }

		//	- (double)doubleValue;
		[Export ("doubleValue")]
		double DoubleValue { get; set; }

		//- (void)incrementBy:(double)delta;			
		[Export ("incrementBy:")]
		void IncrementBy (double delta);

		//- (double)minValue;
		[Export ("minValue")]
		double MinValue { get; set; }

		//- (double)maxValue;
		[Export ("maxValue")]
		double MaxValue { get; set; }

		//	- (NSTimeInterval)animationDelay;			
		[Export ("animationDelay")]
		double AnimationDelay { get; set; }

		//- (BOOL)usesThreadedAnimation;				
		[Export ("usesThreadedAnimation")]
		bool UsesThreadedAnimation { get; set; }

		//- (void)startAnimation:(id)sender;
		[Export ("startAnimation:")]
		void StartAnimation (NSObject sender);

		//- (void)stopAnimation:(id)sender;
		[Export ("stopAnimation:")]
		void StopAnimation (NSObject sender);

		//- (void)animate:(id)sender;				
		[Export ("animate:")]
		void Animate (NSObject sender);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_2
		//- (NSProgressIndicatorStyle) style;
		[Export ("style")]
		NSProgressIndicatorStyle Style { get; set; }

		//- (void) sizeToFit;
		[Export ("sizeToFit")]
		void SizeToFit ();

		//- (BOOL) isDisplayedWhenStopped;
		[Export ("isDisplayedWhenStopped")]
		bool IsDisplayedWhenStopped { get; }

		//- (void) setDisplayedWhenStopped: (BOOL) isDisplayed;
		[Export ("setDisplayedWhenStopped:")]
		void SetDisplayedWhenStopped (bool isDisplayed);

//#endif
	}
}
