using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSControl))]
	interface NSScroller {

		//+ (CGFloat)scrollerWidth;
		[Static, Export ("scrollerWidth")]
		float ScrollerWidth { get; }

		//+ (CGFloat)scrollerWidthForControlSize:(NSControlSize)controlSize;
		[Static, Export ("scrollerWidthForControlSize:")]
		float ScrollerWidthForControlSize (NSControlSize controlSize);

		//- (void)drawParts;
		[Export ("drawParts")]
		void DrawParts ();

		//- (NSRect)rectForPart:(NSScrollerPart)partCode;
		[Export ("rectForPart:")]
		RectangleF RectForPart (NSScrollerPart partCode);

		//- (void)checkSpaceForParts;
		[Export ("checkSpaceForParts")]
		void CheckSpaceForParts ();

		//- (NSUsableScrollerParts)usableParts;
		[Export ("usableParts")]
		NSUsableScrollerParts UsableParts { get; }

		//- (NSScrollArrowPosition)arrowsPosition;
		[Export ("arrowsPosition")]
		NSScrollArrowPosition ArrowsPosition { get; set; }

		//- (NSControlTint)controlTint;
		[Export ("controlTint")]
		NSControlTint ControlTint { get; set; }

		//- (NSControlSize)controlSize;
		[Export ("controlSize")]
		NSControlSize ControlSize { get; set; }

		//- (void)drawArrow:(NSScrollerArrow)whichArrow highlight:(BOOL)flag;
		[Export ("drawArrow:highlight:")]
		void DrawArrow (NSScrollerArrow whichArrow, bool flag);

		//- (void)drawKnob;
		[Export ("drawKnob")]
		void DrawKnob ();

		//- (void)drawKnobSlotInRect:(NSRect)slotRect highlight:(BOOL)flag;
		[Export ("drawKnobSlotInRect:highlight:")]
		void DrawKnobSlotInRect (RectangleF slotRect, bool flag);

		//- (void)highlight:(BOOL)flag;
		[Export ("highlight:")]
		void Highlight (bool flag);

		//- (NSScrollerPart)testPart:(NSPoint)thePoint;
		[Export ("testPart:")]
		NSScrollerPart TestPart (PointF thePoint);

		//- (void)trackKnob:(NSEvent *)theEvent;
		[Export ("trackKnob:")]
		void TrackKnob (NSEvent theEvent);

		//- (void)trackScrollButtons:(NSEvent *)theEvent;
		[Export ("trackScrollButtons:")]
		void TrackScrollButtons (NSEvent theEvent);

		//- (NSScrollerPart)hitPart;
		[Export ("hitPart")]
		NSScrollerPart HitPart { get; }

		//- (CGFloat)knobProportion;
		[Export ("knobProportion")]
		float KnobProportion { get; set; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
//#endif
		////- (void)setFloatValue:(float)aFloat knobProportion:(CGFloat)proportion;
		//[Export ("setFloatValue:knobProportion:")]
		//void SetFloatValueKnobProportion (float aFloat, float proportion);

	}
}
