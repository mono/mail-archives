using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSImageRep))]
	interface NSCachedImageRep {

		//- (id)initWithWindow:(NSWindow *)win rect:(NSRect)rect;
		[Export ("initWithWindow:rect:")]
		IntPtr Constructor (NSWindow win, RectangleF rect);

		//- (id)initWithSize:(NSSize)size depth:(NSWindowDepth)depth separate:(BOOL)flag alpha:(BOOL)alpha;
		[Export ("initWithSize:depth:separate:alpha:")]
		IntPtr Constructor (NSSize size, int depth, bool flag, bool alpha);

		//- (NSWindow *)window;
		[Export ("window")]
		NSWindow Window { get; }

		//- (NSRect)rect;
		[Export ("rect")]
		RectangleF Rect { get; }

	}
}
