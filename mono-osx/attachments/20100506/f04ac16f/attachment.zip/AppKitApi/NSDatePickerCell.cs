using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSActionCell))]
	interface NSDatePickerCell {

		//#pragma mark *** Appearance Control ***- (NSDatePickerStyle)datePickerStyle;
		[Export ("datePickerStyle")]
		NSDatePickerStyle DatePickerStyle { get; set; }

		//- (BOOL)drawsBackground;
		[Export ("drawsBackground")]
		bool DrawsBackground { get; set; }

		//- (NSColor *)backgroundColor;
		[Export ("backgroundColor")]
		NSColor BackgroundColor { get; set; }

		//- (NSColor *)textColor;
		[Export ("textColor")]
		NSColor TextColor { get; set; }

		//#pragma mark *** Range Mode Control ***- (NSDatePickerMode)datePickerMode;
		[Export ("datePickerMode")]
		NSDatePickerMode DatePickerMode { get; set; }

		//#pragma mark *** Date Presentation Control ***- (NSDatePickerElementFlags)datePickerElements;
		[Export ("datePickerElements")]
		NSDatePickerElementFlags DatePickerElements { get; set; }

		//- (NSCalendar *)calendar;
		[Export ("calendar")]
		NSCalendar Calendar { get; set; }

		//- (NSLocale *)locale;
		[Export ("locale")]
		NSLocale Locale { get; set; }

		//- (NSTimeZone *)timeZone;
		[Export ("timeZone")]
		NSTimeZone TimeZone { get; set; }

		//#pragma mark *** Object Value Access ***- (NSDate *)dateValue;
		[Export ("dateValue")]
		NSDate DateValue { get; set; }

		//- (NSTimeInterval)timeInterval;
		[Export ("timeInterval")]
		double TimeInterval { get; set; }

		//#pragma mark *** Constraints on Displayable/Selectable Range ***- (NSDate *)minDate;
		[Export ("minDate")]
		NSDate MinDate { get; set; }

		//- (NSDate *)maxDate;
		[Export ("maxDate")]
		NSDate MaxDate { get; set; }

		//#pragma mark *** Delegate ***- (id)delegate;
		[Export ("delegate")]
		NSDatePickerCell Delegate { get; }

		//- (void)setDelegate:(id)anObject;
		[Export ("setDelegate:")]
		void SetDelegate (NSObject anObject);

	}
}
