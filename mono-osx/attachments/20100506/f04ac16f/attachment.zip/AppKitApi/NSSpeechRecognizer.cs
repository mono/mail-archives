using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSObject))]
	interface NSSpeechRecognizer {

		//- (id)init;
		[Export ("init")]
		IntPtr Init { get; }

		//- (void)startListening;
		[Export ("startListening")]
		void StartListening ();

		//- (void)stopListening;
		[Export ("stopListening")]
		void StopListening ();

		//- (id)delegate;
		[Export ("delegate")]
		NSSpeechRecognizer Delegate { get; }

		//- (void)setDelegate:(id)anObject;
		[Export ("setDelegate:")]
		void SetDelegate (NSObject anObject);

		//- (NSArray *)commands;
		[Export ("commands")]
		NSArray Commands { get; set; }

		//- (NSString *)displayedCommandsTitle;
		[Export ("displayedCommandsTitle")]
		string DisplayedCommandsTitle { get; set; }

		//- (BOOL)listensInForegroundOnly;
		[Export ("listensInForegroundOnly")]
		bool ListensInForegroundOnly { get; set; }

		//- (BOOL)blocksOtherRecognizers;
		[Export ("blocksOtherRecognizers")]
		bool BlocksOtherRecognizers { get; set; }

	}
}
