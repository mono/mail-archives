using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSControl))]
	interface NSTextField {

		//- (NSColor *)backgroundColor;
		[Export ("backgroundColor")]
		NSColor BackgroundColor { get; set; }

		//- (BOOL)drawsBackground;
		[Export ("drawsBackground")]
		bool DrawsBackground { get; set; }

		//- (NSColor *)textColor;
		[Export ("textColor")]
		NSColor TextColor { get; set; }

		//- (BOOL)isBordered;
		[Export ("isBordered")]
		bool IsBordered { get; }

		//- (void)setBordered:(BOOL)flag;
		[Export ("setBordered:")]
		void SetBordered (bool flag);

		//- (BOOL)isBezeled;
		[Export ("isBezeled")]
		bool IsBezeled { get; }

		//- (void)setBezeled:(BOOL)flag;
		[Export ("setBezeled:")]
		void SetBezeled (bool flag);

		//- (BOOL)isEditable;
		[Export ("isEditable")]
		bool IsEditable { get; }

		//- (void)setEditable:(BOOL)flag;
		[Export ("setEditable:")]
		void SetEditable (bool flag);

		//- (BOOL)isSelectable;
		[Export ("isSelectable")]
		bool IsSelectable { get; }

		//- (void)setSelectable:(BOOL)flag;
		[Export ("setSelectable:")]
		void SetSelectable (bool flag);

		//- (void)selectText:(id)sender;
		[Export ("selectText:")]
		void SelectText (NSObject sender);

		//- (id)delegate;
		[Export ("delegate")]
		NSTextField Delegate { get; }

		//- (void)setDelegate:(id)anObject;
		[Export ("setDelegate:")]
		void SetDelegate (NSObject anObject);

		//- (BOOL)textShouldBeginEditing:(NSText *)textObject;
		[Export ("textShouldBeginEditing:")]
		bool TextShouldBeginEditing (NSText textObject);

		//- (BOOL)textShouldEndEditing:(NSText *)textObject;
		[Export ("textShouldEndEditing:")]
		bool TextShouldEndEditing (NSText textObject);

		//- (void)textDidBeginEditing:(NSNotification *)notification;
		[Export ("textDidBeginEditing:")]
		void TextDidBeginEditing (NSNotification notification);

		//- (void)textDidEndEditing:(NSNotification *)notification;
		[Export ("textDidEndEditing:")]
		void TextDidEndEditing (NSNotification notification);

		//- (void)textDidChange:(NSNotification *)notification;
		[Export ("textDidChange:")]
		void TextDidChange (NSNotification notification);

		//- (BOOL)acceptsFirstResponder;
		[Export ("acceptsFirstResponder")]
		bool AcceptsFirstResponder { get; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_2
		//- (NSTextFieldBezelStyle)bezelStyle;
		[Export ("bezelStyle")]
		NSTextFieldBezelStyle BezelStyle { get; set; }

//#endif
		//- (void)setAllowsEditingTextAttributes:(BOOL)flag;
		[Export ("setAllowsEditingTextAttributes:")]
		void SetAllowsEditingTextAttributes (bool flag);

		//- (BOOL)importsGraphics;
		[Export ("importsGraphics")]
		bool ImportsGraphics { get; set; }

	}
}
