using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSActionCell))]
	interface NSSegmentedCell {

		//- (NSInteger)segmentCount;
		[Export ("segmentCount")]
		int SegmentCount { get; set; }

		//- (NSInteger)selectedSegment;
		[Export ("selectedSegment")]
		int SelectedSegment { get; set; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (BOOL)selectSegmentWithTag:(NSInteger)tag;
		[Export ("selectSegmentWithTag:")]
		bool SelectSegmentWithTag (int tag);

//#endif
		//- (void)makeNextSegmentKey;
		[Export ("makeNextSegmentKey")]
		void MakeNextSegmentKey ();

		//- (void)makePreviousSegmentKey;
		[Export ("makePreviousSegmentKey")]
		void MakePreviousSegmentKey ();

		//- (NSSegmentSwitchTracking)trackingMode;
		[Export ("trackingMode")]
		NSSegmentSwitchTracking TrackingMode { get; set; }

		//- (void)setWidth:(CGFloat)width forSegment:(NSInteger)segment;
		[Export ("setWidth:forSegment:")]
		void SetWidth (float width, int segment);

		//- (CGFloat)widthForSegment:(NSInteger)segment;
		[Export ("widthForSegment:")]
		float WidthForSegment (int segment);

		//- (void)setImage:(NSImage *)image forSegment:(NSInteger)segment;
		[Export ("setImage:forSegment:")]
		void SetImage (NSImage image, int segment);

		//- (NSImage *)imageForSegment:(NSInteger)segment;
		[Export ("imageForSegment:")]
		NSImage ImageForSegment (int segment);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (void)setImageScaling:(NSImageScaling)scaling forSegment:(NSInteger)segment;
		[Export ("setImageScaling:forSegment:")]
		void SetImageScaling (NSImageScaling scaling, int segment);

		//- (NSImageScaling)imageScalingForSegment:(NSInteger)segment;
		[Export ("imageScalingForSegment:")]
		NSImageScaling ImageScalingForSegment (int segment);

//#endif
		//- (void)setLabel:(NSString *)label forSegment:(NSInteger)segment;
		[Export ("setLabel:forSegment:")]
		void SetLabel (string label, int segment);

		//- (NSString *)labelForSegment:(NSInteger)segment;
		[Export ("labelForSegment:")]
		string LabelForSegment (int segment);

		//- (void)setSelected:(BOOL)selected forSegment:(NSInteger)segment;
		[Export ("setSelected:forSegment:")]
		void SetSelected (bool selected, int segment);

		//- (BOOL)isSelectedForSegment:(NSInteger)segment;
		[Export ("isSelectedForSegment:")]
		bool IsSelectedForSegment (int segment);

		//- (void)setEnabled:(BOOL)enabled forSegment:(NSInteger)segment;
		[Export ("setEnabled:forSegment:")]
		void SetEnabled (bool enabled, int segment);

		//- (BOOL)isEnabledForSegment:(NSInteger)segment;
		[Export ("isEnabledForSegment:")]
		bool IsEnabledForSegment (int segment);

		//- (void)setMenu:(NSMenu *)menu forSegment:(NSInteger)segment;
		[Export ("setMenu:forSegment:")]
		void SetMenu (NSMenu menu, int segment);

		//- (NSMenu *)menuForSegment:(NSInteger)segment;
		[Export ("menuForSegment:")]
		NSMenu MenuForSegment (int segment);

		//- (void)setToolTip:(NSString *)toolTip forSegment:(NSInteger)segment;
		[Export ("setToolTip:forSegment:")]
		void SetToolTip (string toolTip, int segment);

		//- (NSString *)toolTipForSegment:(NSInteger)segment;
		[Export ("toolTipForSegment:")]
		string ToolTipForSegment (int segment);

		//- (void)setTag:(NSInteger)tag forSegment:(NSInteger)segment;
		[Export ("setTag:forSegment:")]
		void SetTag (int tag, int segment);

		//- (NSInteger)tagForSegment:(NSInteger)segment;
		[Export ("tagForSegment:")]
		int TagForSegment (int segment);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (NSSegmentStyle)segmentStyle;
		[Export ("segmentStyle")]
		NSSegmentStyle SegmentStyle { get; set; }

//#endif
		//- (void)drawSegment:(NSInteger)segment inFrame:(NSRect)frame withView:(NSView *)controlView;
		[Export ("drawSegment:inFrame:withView:")]
		void DrawSegment (int segment, RectangleF frame, NSView controlView);

		//- (NSBackgroundStyle)interiorBackgroundStyleForSegment:(NSInteger)segment;
		[Export ("interiorBackgroundStyleForSegment:")]
		NSBackgroundStyle InteriorBackgroundStyleForSegment (int segment);

	}
}
