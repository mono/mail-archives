using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSTextField))]
	interface NSSearchField {

		//- (NSArray*) recentSearches;
		[Export ("recentSearches")]
		NSArray RecentSearches { get; set; }

		//- (NSString*) recentsAutosaveName;
		[Export ("recentsAutosaveName")]
		string RecentsAutosaveName { get; set; }

	}
}
