using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSResponder))]
	interface NSDrawer {

		//- (id)initWithContentSize:(NSSize)contentSize preferredEdge:(NSRectEdge)edge;
		[Export ("initWithContentSize:preferredEdge:")]
		IntPtr Constructor (NSSize contentSize, NSRectEdge edge);

		//- (NSWindow *)parentWindow;
		[Export ("parentWindow")]
		NSWindow ParentWindow { get; set; }

		//- (NSView *)contentView;
		[Export ("contentView")]
		NSView ContentView { get; set; }

		//- (NSRectEdge)preferredEdge;
		[Export ("preferredEdge")]
		NSRectEdge PreferredEdge { get; set; }

		//- (void)setDelegate:(id)anObject;
		[Export ("setDelegate:")]
		void SetDelegate (NSObject anObject);

		//- (id)delegate;
		[Export ("delegate")]
		NSDrawer Delegate { get; }

		//- (void)open;
		[Export ("open")]
		void Open ();

		//- (void)openOnEdge:(NSRectEdge)edge;
		[Export ("openOnEdge:")]
		void OpenOnEdge (NSRectEdge edge);

		//- (void)close;
		[Export ("close")]
		void Close ();

		//- (void)open:(id)sender;
		[Export ("open:")]
		void Open (NSObject sender);

		//- (void)close:(id)sender;
		[Export ("close:")]
		void Close (NSObject sender);

		//- (void)toggle:(id)sender;
		[Export ("toggle:")]
		void Toggle (NSObject sender);

		//- (NSInteger)state;
		[Export ("state")]
		int State { get; }

		//- (NSRectEdge)edge;
		[Export ("edge")]
		NSRectEdge Edge { get; }

		//- (NSSize)contentSize;
		[Export ("contentSize")]
		NSSize ContentSize { get; set; }

		//- (NSSize)minContentSize;
		[Export ("minContentSize")]
		NSSize MinContentSize { get; set; }

		//- (NSSize)maxContentSize;
		[Export ("maxContentSize")]
		NSSize MaxContentSize { get; set; }

		//- (CGFloat)leadingOffset;
		[Export ("leadingOffset")]
		float LeadingOffset { get; set; }

		//- (CGFloat)trailingOffset;
		[Export ("trailingOffset")]
		float TrailingOffset { get; set; }

	}
}
