using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{
	interface NSAffineTransform {

		//- (NSBezierPath *)transformBezierPath:(NSBezierPath *)aPath;
		[Export ("transformBezierPath:")]
		NSBezierPath TransformBezierPath (NSBezierPath aPath);

		//- (void)set;
		[Export ("set")]
		void Set ();

		//- (void)concat;
		[Export ("concat")]
		void Concat ();

	}
}
