using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSObject))]
	interface NSScreen {

		//+ (NSArray *)screens;		
		[Static, Export ("screens")]
		NSArray Screens { get; }

		//+ (NSScreen *)mainScreen;	
		[Static, Export ("mainScreen")]
		NSScreen MainScreen { get; }

		//+ (NSScreen *)deepestScreen;
		[Static, Export ("deepestScreen")]
		NSScreen DeepestScreen { get; }

		//- (NSWindowDepth)depth;
		[Export ("depth")]
		int Depth { get; }

		//- (NSRect)frame;
		[Export ("frame")]
		RectangleF Frame { get; }

		//- (NSRect)visibleFrame;
		[Export ("visibleFrame")]
		RectangleF VisibleFrame { get; }

		//- (NSDictionary *)deviceDescription;
		[Export ("deviceDescription")]
		NSDictionary DeviceDescription { get; }

		////- (const NSWindowDepth *)supportedWindowDepths; 
		//[Export ("supportedWindowDepths")]
		//const NSWindowDepth SupportedWindowDepths { get; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (CGFloat)userSpaceScaleFactor;
		[Export ("userSpaceScaleFactor")]
		float UserSpaceScaleFactor { get; }

//#endif 
	}
}
