using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{
	interface NSMutableAttributedString {

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (BOOL)readFromURL:(NSURL *)url options:(NSDictionary *)opts documentAttributes:(NSDictionary **)dict error:(NSError **)error;
		[Export ("readFromURL:options:documentAttributes:error:")]
		bool ReadFromURLOptions (NSUrl url, NSDictionary opts, NSDictionary dict, NSError error);

		//- (BOOL)readFromData:(NSData *)data options:(NSDictionary *)opts documentAttributes:(NSDictionary **)dict error:(NSError **)error;
		[Export ("readFromData:options:documentAttributes:error:")]
		bool ReadFromDataOptions (NSData data, NSDictionary opts, NSDictionary dict, NSError error);

//#endif 
		//- (BOOL)readFromURL:(NSURL *)url options:(NSDictionary *)options documentAttributes:(NSDictionary **)dict;
		[Export ("readFromURL:options:documentAttributes:")]
		bool ReadFromURLOptions (NSUrl url, NSDictionary options, NSDictionary dict);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//- (BOOL)readFromData:(NSData *)data options:(NSDictionary *)options documentAttributes:(NSDictionary **)dict;
		[Export ("readFromData:options:documentAttributes:")]
		bool ReadFromDataOptions (NSData data, NSDictionary options, NSDictionary dict);

//#endif 
		//- (void)superscriptRange:(NSRange)range;
		[Export ("superscriptRange:")]
		void SuperscriptRange (NSRange range);

		//- (void)subscriptRange:(NSRange)range;
		[Export ("subscriptRange:")]
		void SubscriptRange (NSRange range);

		//- (void)unscriptRange:(NSRange)range;
		[Export ("unscriptRange:")]
		void UnscriptRange (NSRange range);

		//- (void)applyFontTraits:(NSFontTraitMask)traitMask range:(NSRange)range;
		[Export ("applyFontTraits:range:")]
		void ApplyFontTraitsRange (NSFontTraitMask traitMask, NSRange range);

		//- (void)setAlignment:(NSTextAlignment)alignment range:(NSRange)range;
		[Export ("setAlignment:range:")]
		void SetAlignmentRange (NSTextAlignment alignment, NSRange range);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (void)setBaseWritingDirection:(NSWritingDirection)writingDirection range:(NSRange)range;
		[Export ("setBaseWritingDirection:range:")]
		void SetBaseWritingDirectionRange (NSWritingDirection writingDirection, NSRange range);

//#endif 
		//- (void)fixAttributesInRange:(NSRange)range;
		[Export ("fixAttributesInRange:")]
		void FixAttributesInRange (NSRange range);

		//- (void)fixFontAttributeInRange:(NSRange)range;
		[Export ("fixFontAttributeInRange:")]
		void FixFontAttributeInRange (NSRange range);

		//- (void)fixParagraphStyleAttributeInRange:(NSRange)range;
		[Export ("fixParagraphStyleAttributeInRange:")]
		void FixParagraphStyleAttributeInRange (NSRange range);

		//- (void)fixAttachmentAttributeInRange:(NSRange)range;
		[Export ("fixAttachmentAttributeInRange:")]
		void FixAttachmentAttributeInRange (NSRange range);

		//- (void)updateAttachmentsFromPath:(NSString *)path;
		[Export ("updateAttachmentsFromPath:")]
		void UpdateAttachmentsFromPath (string path);

	}
}
