using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSCell))]
	interface NSActionCell {

		//- (NSView *)controlView;
		[Export ("controlView")]
		NSView ControlView { get; set; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
//#endif
		//- (void)setFont:(NSFont *)fontObj;
		[Export ("setFont:")]
		void SetFont (NSFont fontObj);

		//- (void)setAlignment:(NSTextAlignment)mode;
		[Export ("setAlignment:")]
		void SetAlignment (NSTextAlignment mode);

		//- (void)setBordered:(BOOL)flag;
		[Export ("setBordered:")]
		void SetBordered (bool flag);

		//- (void)setBezeled:(BOOL)flag;
		[Export ("setBezeled:")]
		void SetBezeled (bool flag);

		//- (void)setEnabled:(BOOL)flag;
		[Export ("setEnabled:")]
		void SetEnabled (bool flag);

		//- (void)setFloatingPointFormat:(BOOL)autoRange left:(NSUInteger)leftDigits right:(NSUInteger)rightDigits;
		[Export ("setFloatingPointFormat:left:right:")]
		void SetFloatingPointFormat (bool autoRange, uint leftDigits, uint rightDigits);

		//- (void)setImage:(NSImage *)image;
		[Export ("setImage:")]
		void SetImage (NSImage image);

		//- (id)target;
		[Export ("target")]
		NSActionCell Target { get; }

		//- (void)setTarget:(id)anObject;
		[Export ("setTarget:")]
		void SetTarget (NSObject anObject);

		//- (SEL)action;
		[Export ("action")]
		Selector Action { get; set; }

		//- (NSInteger)tag;
		[Export ("tag")]
		int Tag { get; set; }

		//- (NSString *)stringValue;
		[Export ("stringValue")]
		string StringValue { get; }

		//- (int)intValue;
		[Export ("intValue")]
		int IntValue { get; }

		//- (float)floatValue;
		[Export ("floatValue")]
		float FloatValue { get; }

		//- (double)doubleValue;
		[Export ("doubleValue")]
		double DoubleValue { get; }

		//- (void)setObjectValue:(id<NSCopying>)obj;
		[Export ("setObjectValue:")]
		void SetObjectValue (NSObject obj);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (NSInteger)integerValue;
		[Export ("integerValue")]
		int IntegerValue { get; }

//#endif 
	}
}
