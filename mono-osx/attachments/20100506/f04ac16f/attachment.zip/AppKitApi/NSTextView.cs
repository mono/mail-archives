using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSText))]
	interface NSTextView {

//#endif 
		//, NSTextInputClient>- (id)initWithFrame:(NSRect)frameRect textContainer:(NSTextContainer *)container;
		[Export ("initWithFrame:textContainer:")]
		IntPtr Constructor (RectangleF frameRect, NSTextContainer container);

		//    - (id)initWithFrame:(NSRect)frameRect;
		[Export ("initWithFrame:")]
		IntPtr Constructor (RectangleF frameRect);

		//    - (NSTextContainer *)textContainer;
		[Export ("textContainer")]
		NSTextContainer TextContainer { get; set; }

		//    - (void)replaceTextContainer:(NSTextContainer *)newContainer;
		[Export ("replaceTextContainer:")]
		void ReplaceTextContainer (NSTextContainer newContainer);

		//- (NSSize)textContainerInset;
		[Export ("textContainerInset")]
		NSSize TextContainerInset { get; set; }

		//    - (NSPoint)textContainerOrigin;
		[Export ("textContainerOrigin")]
		PointF TextContainerOrigin { get; }

		//- (void)invalidateTextContainerOrigin;
		[Export ("invalidateTextContainerOrigin")]
		void InvalidateTextContainerOrigin ();

		//    - (NSLayoutManager *)layoutManager;
		[Export ("layoutManager")]
		NSLayoutManager LayoutManager { get; }

		//- (NSTextStorage *)textStorage;
		[Export ("textStorage")]
		NSTextStorage TextStorage { get; }

		//    - (void)insertText:(id)insertString;
		[Export ("insertText:")]
		void InsertText (NSObject insertString);

		//    - (void)setConstrainedFrameSize:(NSSize)desiredSize;
		[Export ("setConstrainedFrameSize:")]
		void SetConstrainedFrameSize (NSSize desiredSize);

		//    - (void)setAlignment:(NSTextAlignment)alignment range:(NSRange)range;
		[Export ("setAlignment:range:")]
		void SetAlignment (NSTextAlignment alignment, NSRange range);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (void)setBaseWritingDirection:(NSWritingDirection)writingDirection range:(NSRange)range;
		[Export ("setBaseWritingDirection:range:")]
		void SetBaseWritingDirection (NSWritingDirection writingDirection, NSRange range);

//#endif 
		//- (void)turnOffKerning:(id)sender;
		[Export ("turnOffKerning:")]
		void TurnOffKerning (NSObject sender);

		//- (void)tightenKerning:(id)sender;
		[Export ("tightenKerning:")]
		void TightenKerning (NSObject sender);

		//- (void)loosenKerning:(id)sender;
		[Export ("loosenKerning:")]
		void LoosenKerning (NSObject sender);

		//- (void)useStandardKerning:(id)sender;
		[Export ("useStandardKerning:")]
		void UseStandardKerning (NSObject sender);

		//- (void)turnOffLigatures:(id)sender;
		[Export ("turnOffLigatures:")]
		void TurnOffLigatures (NSObject sender);

		//- (void)useStandardLigatures:(id)sender;
		[Export ("useStandardLigatures:")]
		void UseStandardLigatures (NSObject sender);

		//- (void)useAllLigatures:(id)sender;
		[Export ("useAllLigatures:")]
		void UseAllLigatures (NSObject sender);

		//- (void)raiseBaseline:(id)sender;
		[Export ("raiseBaseline:")]
		void RaiseBaseline (NSObject sender);

		//- (void)lowerBaseline:(id)sender;
		[Export ("lowerBaseline:")]
		void LowerBaseline (NSObject sender);

		//- (void)toggleTraditionalCharacterShape:(id)sender;
		[Export ("toggleTraditionalCharacterShape:")]
		void ToggleTraditionalCharacterShape (NSObject sender);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//- (void)outline:(id)sender;
		[Export ("outline:")]
		void Outline (NSObject sender);

//#endif 
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//- (void)performFindPanelAction:(id)sender;
		[Export ("performFindPanelAction:")]
		void PerformFindPanelAction (NSObject sender);

//#endif 
		//    - (void)alignJustified:(id)sender;
		[Export ("alignJustified:")]
		void AlignJustified (NSObject sender);

		//- (void)changeColor:(id)sender;
		[Export ("changeColor:")]
		void ChangeColor (NSObject sender);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//- (void)changeAttributes:(id)sender;
		[Export ("changeAttributes:")]
		void ChangeAttributes (NSObject sender);

		//- (void)changeDocumentBackgroundColor:(id)sender;
		[Export ("changeDocumentBackgroundColor:")]
		void ChangeDocumentBackgroundColor (NSObject sender);

		//- (void)toggleBaseWritingDirection:(id)sender;
		[Export ("toggleBaseWritingDirection:")]
		void ToggleBaseWritingDirection (NSObject sender);

//#endif 
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (void)orderFrontSpacingPanel:(id)sender;
		[Export ("orderFrontSpacingPanel:")]
		void OrderFrontSpacingPanel (NSObject sender);

		//- (void)orderFrontLinkPanel:(id)sender;
		[Export ("orderFrontLinkPanel:")]
		void OrderFrontLinkPanel (NSObject sender);

		//- (void)orderFrontListPanel:(id)sender;
		[Export ("orderFrontListPanel:")]
		void OrderFrontListPanel (NSObject sender);

		//- (void)orderFrontTablePanel:(id)sender;
		[Export ("orderFrontTablePanel:")]
		void OrderFrontTablePanel (NSObject sender);

//#endif 
		//- (void)rulerView:(NSRulerView *)ruler didMoveMarker:(NSRulerMarker *)marker;
		[Export ("rulerView:didMoveMarker:")]
		void RulerView (NSRulerView ruler, NSRulerMarker marker);

		//- (void)rulerView:(NSRulerView *)ruler didRemoveMarker:(NSRulerMarker *)marker;
		[Export ("rulerView:didRemoveMarker:")]
		void RulerViewDidRemoveMarker (NSRulerView ruler, NSRulerMarker marker);

		//- (void)rulerView:(NSRulerView *)ruler didAddMarker:(NSRulerMarker *)marker;
		[Export ("rulerView:didAddMarker:")]
		void RulerViewDidAddMarker (NSRulerView ruler, NSRulerMarker marker);

		//- (BOOL)rulerView:(NSRulerView *)ruler shouldMoveMarker:(NSRulerMarker *)marker;
		[Export ("rulerView:shouldMoveMarker:")]
		bool RulerViewShouldMoveMarker (NSRulerView ruler, NSRulerMarker marker);

		//- (BOOL)rulerView:(NSRulerView *)ruler shouldAddMarker:(NSRulerMarker *)marker;
		[Export ("rulerView:shouldAddMarker:")]
		bool RulerViewShouldAddMarker (NSRulerView ruler, NSRulerMarker marker);

		//- (CGFloat)rulerView:(NSRulerView *)ruler willMoveMarker:(NSRulerMarker *)marker toLocation:(CGFloat)location;
		[Export ("rulerView:willMoveMarker:toLocation:")]
		float RulerView (NSRulerView ruler, NSRulerMarker marker, float location);

		//- (BOOL)rulerView:(NSRulerView *)ruler shouldRemoveMarker:(NSRulerMarker *)marker;
		[Export ("rulerView:shouldRemoveMarker:")]
		bool RulerViewShouldRemoveMarker (NSRulerView ruler, NSRulerMarker marker);

		//- (CGFloat)rulerView:(NSRulerView *)ruler willAddMarker:(NSRulerMarker *)marker atLocation:(CGFloat)location;
		[Export ("rulerView:willAddMarker:atLocation:")]
		float RulerViewWillAddMarker (NSRulerView ruler, NSRulerMarker marker, float location);

		//- (void)rulerView:(NSRulerView *)ruler handleMouseDown:(NSEvent *)event;
		[Export ("rulerView:handleMouseDown:")]
		void RulerView (NSRulerView ruler, NSEvent event1);

		//- (void)setNeedsDisplayInRect:(NSRect)rect avoidAdditionalLayout:(BOOL)flag;
		[Export ("setNeedsDisplayInRect:avoidAdditionalLayout:")]
		void SetNeedsDisplayInRect (RectangleF rect, bool flag);

		//    - (BOOL)shouldDrawInsertionPoint;
		[Export ("shouldDrawInsertionPoint")]
		bool ShouldDrawInsertionPoint { get; }

		//- (void)drawInsertionPointInRect:(NSRect)rect color:(NSColor *)color turnedOn:(BOOL)flag;
		[Export ("drawInsertionPointInRect:color:turnedOn:")]
		void DrawInsertionPointInRect (RectangleF rect, NSColor color, bool flag);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//- (void)drawViewBackgroundInRect:(NSRect)rect;
		[Export ("drawViewBackgroundInRect:")]
		void DrawViewBackgroundInRect (RectangleF rect);

//#endif 
		//    - (void)updateRuler;
		[Export ("updateRuler")]
		void UpdateRuler ();

		//- (void)updateFontPanel;
		[Export ("updateFontPanel")]
		void UpdateFontPanel ();

		//- (void)updateDragTypeRegistration;
		[Export ("updateDragTypeRegistration")]
		void UpdateDragTypeRegistration ();

		//- (NSRange)selectionRangeForProposedRange:(NSRange)proposedCharRange granularity:(NSSelectionGranularity)granularity;
		[Export ("selectionRangeForProposedRange:granularity:")]
		NSRange SelectionRangeForProposedRange (NSRange proposedCharRange, NSSelectionGranularity granularity);

		//- (void)clickedOnLink:(id)link atIndex:(NSUInteger)charIndex;
		[Export ("clickedOnLink:atIndex:")]
		void ClickedOnLink (NSObject link, uint charIndex);

		//    - (void)startSpeaking:(id)sender;
		[Export ("startSpeaking:")]
		void StartSpeaking (NSObject sender);

		//- (void)stopSpeaking:(id)sender;
		[Export ("stopSpeaking:")]
		void StopSpeaking (NSObject sender);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (NSUInteger)characterIndexForInsertionAtPoint:(NSPoint)point;
		[Export ("characterIndexForInsertionAtPoint:")]
		uint CharacterIndexForInsertionAtPoint (PointF point);

//#endif 
		//- (void)complete:(id)sender;
		[Export ("complete:")]
		void Complete (NSObject sender);

		//        - (NSRange)rangeForUserCompletion;
		[Export ("rangeForUserCompletion")]
		NSRange RangeForUserCompletion { get; }

		//        - (NSArray *)completionsForPartialWordRange:(NSRange)charRange indexOfSelectedItem:(NSInteger *)index;
		[Export ("completionsForPartialWordRange:indexOfSelectedItem:")]
		NSArray CompletionsForPartialWordRangeIndexOfSelectedItem (NSRange charRange, int index);

		//    - (void)insertCompletion:(NSString *)word forPartialWordRange:(NSRange)charRange movement:(NSInteger)movement isFinal:(BOOL)flag;
		[Export ("insertCompletion:forPartialWordRange:movement:isFinal:")]
		void InsertCompletionForPartialWordRange (string word, NSRange charRange, int movement, bool flag);

		//- (NSArray *)writablePasteboardTypes;
		[Export ("writablePasteboardTypes")]
		NSArray WritablePasteboardTypes { get; }

		//    - (BOOL)writeSelectionToPasteboard:(NSPasteboard *)pboard type:(NSString *)type;
		[Export ("writeSelectionToPasteboard:type:")]
		bool WriteSelectionToPasteboardType (NSPasteboard pboard, string type);

		//    - (BOOL)writeSelectionToPasteboard:(NSPasteboard *)pboard types:(NSArray *)types;
		[Export ("writeSelectionToPasteboard:types:")]
		bool WriteSelectionToPasteboardTypes (NSPasteboard pboard, NSArray types);

		//    - (NSArray *)readablePasteboardTypes;
		[Export ("readablePasteboardTypes")]
		NSArray ReadablePasteboardTypes { get; }

		//    - (NSString *)preferredPasteboardTypeFromArray:(NSArray *)availableTypes restrictedToTypesFromArray:(NSArray *)allowedTypes;
		[Export ("preferredPasteboardTypeFromArray:restrictedToTypesFromArray:")]
		string PreferredPasteboardTypeFromArrayRestrictedToTypesFromArray (NSArray availableTypes, NSArray allowedTypes);

		//    - (BOOL)readSelectionFromPasteboard:(NSPasteboard *)pboard type:(NSString *)type;
		[Export ("readSelectionFromPasteboard:type:")]
		bool ReadSelectionFromPasteboardType (NSPasteboard pboard, string type);

		//    - (BOOL)readSelectionFromPasteboard:(NSPasteboard *)pboard;
		[Export ("readSelectionFromPasteboard:")]
		bool ReadSelectionFromPasteboard (NSPasteboard pboard);

		//    + (void)registerForServices;
		[Export ("registerForServices")]
		void RegisterForServices ();

		//    - (id)validRequestorForSendType:(NSString *)sendType returnType:(NSString *)returnType;
		[Export ("validRequestorForSendType:returnType:")]
		NSTextView ValidRequestorForSendTypeReturnType (string sendType, string returnType);

		//    - (void)pasteAsPlainText:(id)sender;
		[Export ("pasteAsPlainText:")]
		void PasteAsPlainText (NSObject sender);

		//- (void)pasteAsRichText:(id)sender;
		[Export ("pasteAsRichText:")]
		void PasteAsRichText (NSObject sender);

		//- (BOOL)dragSelectionWithEvent:(NSEvent *)event offset:(NSSize)mouseOffset slideBack:(BOOL)slideBack;
		[Export ("dragSelectionWithEvent:offset:slideBack:")]
		bool DragSelectionWithEventOffset (NSEvent event1, NSSize mouseOffset, bool slideBack);

		//    - (NSImage *)dragImageForSelectionWithEvent:(NSEvent *)event origin:(NSPointPointer)origin;
		[Export ("dragImageForSelectionWithEvent:origin:")]
		NSImage DragImageForSelectionWithEventOrigin (NSEvent event1, NSPointPointer origin);

		//    - (NSArray *)acceptableDragTypes;
		[Export ("acceptableDragTypes")]
		NSArray AcceptableDragTypes { get; }

		//    - (NSDragOperation)dragOperationForDraggingInfo:(id <NSDraggingInfo>)dragInfo type:(NSString *)type;
		[Export ("dragOperationForDraggingInfo:type:")]
		NSDragOperation DragOperationForDraggingInfoType (NSObject dragInfo, string type);

		//        - (void)cleanUpAfterDragOperation;
		[Export ("cleanUpAfterDragOperation")]
		void CleanUpAfterDragOperation ();

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (NSArray *)selectedRanges;
		[Export ("selectedRanges")]
		NSArray SelectedRanges { get; set; }

		//- (void)setSelectedRanges:(NSArray *)ranges affinity:(NSSelectionAffinity)affinity stillSelecting:(BOOL)stillSelectingFlag;
		[Export ("setSelectedRanges:affinity:stillSelecting:")]
		void SetSelectedRangesAffinity (NSArray ranges, NSSelectionAffinity affinity, bool stillSelectingFlag);

//#endif 
		//    - (void)setSelectedRange:(NSRange)charRange affinity:(NSSelectionAffinity)affinity stillSelecting:(BOOL)stillSelectingFlag;
		[Export ("setSelectedRange:affinity:stillSelecting:")]
		void SetSelectedRangeAffinity (NSRange charRange, NSSelectionAffinity affinity, bool stillSelectingFlag);

		//- (NSSelectionAffinity)selectionAffinity;
		[Export ("selectionAffinity")]
		NSSelectionAffinity SelectionAffinity { get; }

		//- (NSSelectionGranularity)selectionGranularity;
		[Export ("selectionGranularity")]
		NSSelectionGranularity SelectionGranularity { get; set; }

		//- (NSDictionary *)selectedTextAttributes;
		[Export ("selectedTextAttributes")]
		NSDictionary SelectedTextAttributes { get; set; }

		//- (NSColor *)insertionPointColor;
		[Export ("insertionPointColor")]
		NSColor InsertionPointColor { get; set; }

		//- (void)updateInsertionPointStateAndRestartTimer:(BOOL)restartFlag;
		[Export ("updateInsertionPointStateAndRestartTimer:")]
		void UpdateInsertionPointStateAndRestartTimer (bool restartFlag);

		//- (NSDictionary *)markedTextAttributes;
		[Export ("markedTextAttributes")]
		NSDictionary MarkedTextAttributes { get; set; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//- (NSDictionary *)linkTextAttributes;
		[Export ("linkTextAttributes")]
		NSDictionary LinkTextAttributes { get; set; }

//#endif 
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//    - (BOOL)displaysLinkToolTips;
		[Export ("displaysLinkToolTips")]
		bool DisplaysLinkToolTips { get; set; }

//#endif 
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_2
		//    - (BOOL)acceptsGlyphInfo;
		[Export ("acceptsGlyphInfo")]
		bool AcceptsGlyphInfo { get; set; }

//#endif 
		//- (void)setRulerVisible:(BOOL)flag;
		[Export ("setRulerVisible:")]
		void SetRulerVisible (bool flag);

		//- (BOOL)usesRuler;
		[Export ("usesRuler")]
		bool UsesRuler { get; set; }

		//- (void)setContinuousSpellCheckingEnabled:(BOOL)flag;
		[Export ("setContinuousSpellCheckingEnabled:")]
		void SetContinuousSpellCheckingEnabled (bool flag);

		//- (BOOL)isContinuousSpellCheckingEnabled;
		[Export ("isContinuousSpellCheckingEnabled")]
		bool IsContinuousSpellCheckingEnabled { get; }

		//- (void)toggleContinuousSpellChecking:(id)sender;
		[Export ("toggleContinuousSpellChecking:")]
		void ToggleContinuousSpellChecking (NSObject sender);

		//- (NSInteger)spellCheckerDocumentTag;
		[Export ("spellCheckerDocumentTag")]
		int SpellCheckerDocumentTag { get; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (void)setGrammarCheckingEnabled:(BOOL)flag;
		[Export ("setGrammarCheckingEnabled:")]
		void SetGrammarCheckingEnabled (bool flag);

		//- (BOOL)isGrammarCheckingEnabled;
		[Export ("isGrammarCheckingEnabled")]
		bool IsGrammarCheckingEnabled { get; }

		//- (void)toggleGrammarChecking:(id)sender;
		[Export ("toggleGrammarChecking:")]
		void ToggleGrammarChecking (NSObject sender);

		//    - (void)setSpellingState:(NSInteger)value range:(NSRange)charRange;
		[Export ("setSpellingState:range:")]
		void SetSpellingStateRange (int value, NSRange charRange);

//#endif 
		//    - (NSDictionary *)typingAttributes;
		[Export ("typingAttributes")]
		NSDictionary TypingAttributes { get; set; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//    - (BOOL)shouldChangeTextInRanges:(NSArray *)affectedRanges replacementStrings:(NSArray *)replacementStrings;
		[Export ("shouldChangeTextInRanges:replacementStrings:")]
		bool ShouldChangeTextInRangesReplacementStrings (NSArray affectedRanges, NSArray replacementStrings);

		//- (NSArray *)rangesForUserTextChange;
		[Export ("rangesForUserTextChange")]
		NSArray RangesForUserTextChange { get; }

		//- (NSArray *)rangesForUserCharacterAttributeChange;
		[Export ("rangesForUserCharacterAttributeChange")]
		NSArray RangesForUserCharacterAttributeChange { get; }

		//- (NSArray *)rangesForUserParagraphAttributeChange;
		[Export ("rangesForUserParagraphAttributeChange")]
		NSArray RangesForUserParagraphAttributeChange { get; }

//#endif 
		//- (BOOL)shouldChangeTextInRange:(NSRange)affectedCharRange replacementString:(NSString *)replacementString;
		[Export ("shouldChangeTextInRange:replacementString:")]
		bool ShouldChangeTextInRangeReplacementString (NSRange affectedCharRange, string replacementString);

		//- (void)didChangeText;
		[Export ("didChangeText")]
		void DidChangeText ();

		//- (NSRange)rangeForUserTextChange;
		[Export ("rangeForUserTextChange")]
		NSRange RangeForUserTextChange { get; }

		//- (NSRange)rangeForUserCharacterAttributeChange;
		[Export ("rangeForUserCharacterAttributeChange")]
		NSRange RangeForUserCharacterAttributeChange { get; }

		//- (NSRange)rangeForUserParagraphAttributeChange;
		[Export ("rangeForUserParagraphAttributeChange")]
		NSRange RangeForUserParagraphAttributeChange { get; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//- (BOOL)usesFindPanel;
		[Export ("usesFindPanel")]
		bool UsesFindPanel { get; set; }

		//- (BOOL)allowsDocumentBackgroundColorChange;
		[Export ("allowsDocumentBackgroundColorChange")]
		bool AllowsDocumentBackgroundColorChange { get; set; }

		//- (NSParagraphStyle *)defaultParagraphStyle;
		[Export ("defaultParagraphStyle")]
		NSParagraphStyle DefaultParagraphStyle { get; set; }

//#endif 
		//- (BOOL)allowsUndo;
		[Export ("allowsUndo")]
		bool AllowsUndo { get; set; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (void)breakUndoCoalescing;
		[Export ("breakUndoCoalescing")]
		void BreakUndoCoalescing ();

//#endif 
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//    - (BOOL)allowsImageEditing;
		[Export ("allowsImageEditing")]
		bool AllowsImageEditing { get; set; }

		//        - (void)showFindIndicatorForRange:(NSRange)charRange;
		[Export ("showFindIndicatorForRange:")]
		void ShowFindIndicatorForRange (NSRange charRange);

//#endif 
		//    - (id)delegate;
		[Export ("delegate")]
		NSTextView Delegate { get; }

		//- (void)setDelegate:(id)anObject;
		[Export ("setDelegate:")]
		void SetDelegate (NSObject anObject);

		//- (BOOL)isEditable;
		[Export ("isEditable")]
		bool IsEditable { get; }

		//- (void)setEditable:(BOOL)flag;
		[Export ("setEditable:")]
		void SetEditable (bool flag);

		//- (BOOL)isSelectable;
		[Export ("isSelectable")]
		bool IsSelectable { get; }

		//- (void)setSelectable:(BOOL)flag;
		[Export ("setSelectable:")]
		void SetSelectable (bool flag);

		//- (BOOL)isRichText;
		[Export ("isRichText")]
		bool IsRichText { get; }

		//- (void)setRichText:(BOOL)flag;
		[Export ("setRichText:")]
		void SetRichText (bool flag);

		//- (BOOL)importsGraphics;
		[Export ("importsGraphics")]
		bool ImportsGraphics { get; set; }

		//- (BOOL)drawsBackground;
		[Export ("drawsBackground")]
		bool DrawsBackground { get; set; }

		//- (NSColor *)backgroundColor;
		[Export ("backgroundColor")]
		NSColor BackgroundColor { get; set; }

		//- (BOOL)isFieldEditor;
		[Export ("isFieldEditor")]
		bool IsFieldEditor { get; }

		//- (void)setFieldEditor:(BOOL)flag;
		[Export ("setFieldEditor:")]
		void SetFieldEditor (bool flag);

		//- (BOOL)usesFontPanel;
		[Export ("usesFontPanel")]
		bool UsesFontPanel { get; set; }

		//- (BOOL)isRulerVisible;
		[Export ("isRulerVisible")]
		bool IsRulerVisible { get; }

		//- (void)setSelectedRange:(NSRange)charRange;
		[Export ("setSelectedRange:")]
		void SetSelectedRange (NSRange charRange);

		//    - (BOOL)smartInsertDeleteEnabled;
		[Export ("smartInsertDeleteEnabled")]
		bool SmartInsertDeleteEnabled { get; set; }

		//- (NSRange)smartDeleteRangeForProposedRange:(NSRange)proposedCharRange;
		[Export ("smartDeleteRangeForProposedRange:")]
		NSRange SmartDeleteRangeForProposedRange (NSRange proposedCharRange);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (void)toggleSmartInsertDelete:(id)sender;
		[Export ("toggleSmartInsertDelete:")]
		void ToggleSmartInsertDelete (NSObject sender);

//#endif 
		//- (void)smartInsertForString:(NSString *)pasteString replacingRange:(NSRange)charRangeToReplace beforeString:(NSString **)beforeString afterString:(NSString **)afterString;
		[Export ("smartInsertForString:replacingRange:beforeString:afterString:")]
		void SmartInsertForStringReplacingRange (string pasteString, NSRange charRangeToReplace, string beforeString, string afterString);

		//- (NSString *)smartInsertBeforeStringForString:(NSString *)pasteString replacingRange:(NSRange)charRangeToReplace;
		[Export ("smartInsertBeforeStringForString:replacingRange:")]
		string SmartInsertBeforeStringForStringReplacingRange (string pasteString, NSRange charRangeToReplace);

		//- (NSString *)smartInsertAfterStringForString:(NSString *)pasteString replacingRange:(NSRange)charRangeToReplace;
		[Export ("smartInsertAfterStringForString:replacingRange:")]
		string SmartInsertAfterStringForStringReplacingRange (string pasteString, NSRange charRangeToReplace);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//    - (void)setAutomaticQuoteSubstitutionEnabled:(BOOL)flag;
		[Export ("setAutomaticQuoteSubstitutionEnabled:")]
		void SetAutomaticQuoteSubstitutionEnabled (bool flag);

		//- (BOOL)isAutomaticQuoteSubstitutionEnabled;
		[Export ("isAutomaticQuoteSubstitutionEnabled")]
		bool IsAutomaticQuoteSubstitutionEnabled { get; }

		//- (void)toggleAutomaticQuoteSubstitution:(id)sender;
		[Export ("toggleAutomaticQuoteSubstitution:")]
		void ToggleAutomaticQuoteSubstitution (NSObject sender);

		//- (void)setAutomaticLinkDetectionEnabled:(BOOL)flag;
		[Export ("setAutomaticLinkDetectionEnabled:")]
		void SetAutomaticLinkDetectionEnabled (bool flag);

		//- (BOOL)isAutomaticLinkDetectionEnabled;
		[Export ("isAutomaticLinkDetectionEnabled")]
		bool IsAutomaticLinkDetectionEnabled { get; }

		//- (void)toggleAutomaticLinkDetection:(id)sender;
		[Export ("toggleAutomaticLinkDetection:")]
		void ToggleAutomaticLinkDetection (NSObject sender);

//#endif 
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (NSArray *)allowedInputSourceLocales;
		[Export ("allowedInputSourceLocales")]
		NSArray AllowedInputSourceLocales { get; set; }

//#endif 
	}
}
