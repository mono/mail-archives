using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSPanel))]
	interface NSFontPanel {

//#if !__LP64__
//#endif 
		//+ (NSFontPanel *)sharedFontPanel;
		[Static, Export ("sharedFontPanel")]
		NSFontPanel SharedFontPanel { get; }

		//+ (BOOL)sharedFontPanelExists;
		[Static, Export ("sharedFontPanelExists")]
		bool SharedFontPanelExists { get; }

		//- (NSView *)accessoryView;
		[Export ("accessoryView")]
		NSView AccessoryView { get; set; }

		//- (void)setPanelFont:(NSFont *)fontObj isMultiple:(BOOL)flag;
		[Export ("setPanelFont:isMultiple:")]
		void SetPanelFont (NSFont fontObj, bool flag);

		//- (NSFont *)panelConvertFont:(NSFont *)fontObj;
		[Export ("panelConvertFont:")]
		NSFont PanelConvertFont (NSFont fontObj);

		//- (BOOL)worksWhenModal;
		[Export ("worksWhenModal")]
		bool WorksWhenModal { get; }

		//- (BOOL)isEnabled;
		[Export ("isEnabled")]
		bool IsEnabled { get; }

		//- (void)setEnabled:(BOOL)flag;
		[Export ("setEnabled:")]
		void SetEnabled (bool flag);

		//- (void) reloadDefaultFontFamilies;
		[Export ("reloadDefaultFontFamilies")]
		void ReloadDefaultFontFamilies ();

	}
}
