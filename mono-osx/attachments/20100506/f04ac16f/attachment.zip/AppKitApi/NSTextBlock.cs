using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSObject))]
	interface NSTextBlock {

		//- (id)init;     
		[Export ("init")]
		IntPtr Init { get; }

		//- (void)setValue:(CGFloat)val type:(NSTextBlockValueType)type forDimension:(NSTextBlockDimension)dimension;
		[Export ("setValue:type:forDimension:")]
		void SetValue (float val, NSTextBlockValueType type, NSTextBlockDimension dimension);

		//- (CGFloat)valueForDimension:(NSTextBlockDimension)dimension;
		[Export ("valueForDimension:")]
		float ValueForDimension (NSTextBlockDimension dimension);

		//- (NSTextBlockValueType)valueTypeForDimension:(NSTextBlockDimension)dimension;
		[Export ("valueTypeForDimension:")]
		NSTextBlockValueType ValueTypeForDimension (NSTextBlockDimension dimension);

		//- (void)setContentWidth:(CGFloat)val type:(NSTextBlockValueType)type;
		[Export ("setContentWidth:type:")]
		void SetContentWidth (float val, NSTextBlockValueType type);

		//- (CGFloat)contentWidth;
		[Export ("contentWidth")]
		float ContentWidth { get; }

		//- (NSTextBlockValueType)contentWidthValueType;
		[Export ("contentWidthValueType")]
		NSTextBlockValueType ContentWidthValueType { get; }

		//- (void)setWidth:(CGFloat)val type:(NSTextBlockValueType)type forLayer:(NSTextBlockLayer)layer edge:(NSRectEdge)edge;
		[Export ("setWidth:type:forLayer:edge:")]
		void SetWidth (float val, NSTextBlockValueType type, NSTextBlockLayer layer, NSRectEdge edge);

		//- (void)setWidth:(CGFloat)val type:(NSTextBlockValueType)type forLayer:(NSTextBlockLayer)layer;     
		[Export ("setWidth:type:forLayer:")]
		void SetWidth (float val, NSTextBlockValueType type, NSTextBlockLayer layer);

		//- (CGFloat)widthForLayer:(NSTextBlockLayer)layer edge:(NSRectEdge)edge;
		[Export ("widthForLayer:edge:")]
		float WidthForLayer (NSTextBlockLayer layer, NSRectEdge edge);

		//- (NSTextBlockValueType)widthValueTypeForLayer:(NSTextBlockLayer)layer edge:(NSRectEdge)edge;
		[Export ("widthValueTypeForLayer:edge:")]
		NSTextBlockValueType WidthValueTypeForLayer (NSTextBlockLayer layer, NSRectEdge edge);

		//- (NSTextBlockVerticalAlignment)verticalAlignment;
		[Export ("verticalAlignment")]
		NSTextBlockVerticalAlignment VerticalAlignment { get; set; }

		//- (NSColor *)backgroundColor;
		[Export ("backgroundColor")]
		NSColor BackgroundColor { get; set; }

		//- (void)setBorderColor:(NSColor *)color forEdge:(NSRectEdge)edge;
		[Export ("setBorderColor:forEdge:")]
		void SetBorderColor (NSColor color, NSRectEdge edge);

		//- (void)setBorderColor:(NSColor *)color;        
		[Export ("setBorderColor:")]
		void SetBorderColor (NSColor color);

		//- (NSColor *)borderColorForEdge:(NSRectEdge)edge;
		[Export ("borderColorForEdge:")]
		NSColor BorderColorForEdge (NSRectEdge edge);

		//- (NSRect)rectForLayoutAtPoint:(NSPoint)startingPoint inRect:(NSRect)rect textContainer:(NSTextContainer *)textContainer characterRange:(NSRange)charRange;
		[Export ("rectForLayoutAtPoint:inRect:textContainer:characterRange:")]
		RectangleF RectForLayoutAtPoint (PointF startingPoint, RectangleF rect, NSTextContainer textContainer, NSRange charRange);

		//- (NSRect)boundsRectForContentRect:(NSRect)contentRect inRect:(NSRect)rect textContainer:(NSTextContainer *)textContainer characterRange:(NSRange)charRange;
		[Export ("boundsRectForContentRect:inRect:textContainer:characterRange:")]
		RectangleF BoundsRectForContentRect (RectangleF contentRect, RectangleF rect, NSTextContainer textContainer, NSRange charRange);

		//- (void)drawBackgroundWithFrame:(NSRect)frameRect inView:(NSView *)controlView characterRange:(NSRange)charRange layoutManager:(NSLayoutManager *)layoutManager;
		[Export ("drawBackgroundWithFrame:inView:characterRange:layoutManager:")]
		void DrawBackgroundWithFrame (RectangleF frameRect, NSView controlView, NSRange charRange, NSLayoutManager layoutManager);

	}
}
