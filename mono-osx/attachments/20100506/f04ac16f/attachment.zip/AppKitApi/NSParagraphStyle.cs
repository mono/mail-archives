using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSObject))]
	interface NSParagraphStyle {

//#if __LP64__
//#endif
		//+ (NSParagraphStyle *)defaultParagraphStyle;
		[Static, Export ("defaultParagraphStyle")]
		NSParagraphStyle DefaultParagraphStyle { get; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_2
		//+ (NSWritingDirection)defaultWritingDirectionForLanguage:(NSString *)languageName;  
		[Static, Export ("defaultWritingDirectionForLanguage:")]
		NSWritingDirection DefaultWritingDirectionForLanguage (string languageName);

//#endif
		//- (CGFloat)lineSpacing;		
		[Export ("lineSpacing")]
		float LineSpacing { get; }

		//- (CGFloat)paragraphSpacing; 	
		[Export ("paragraphSpacing")]
		float ParagraphSpacing { get; }

		//- (NSTextAlignment)alignment;
		[Export ("alignment")]
		NSTextAlignment Alignment { get; }

		//   - (CGFloat)headIndent;		
		[Export ("headIndent")]
		float HeadIndent { get; }

		//- (CGFloat)tailIndent;		
		[Export ("tailIndent")]
		float TailIndent { get; }

		//- (CGFloat)firstLineHeadIndent;	
		[Export ("firstLineHeadIndent")]
		float FirstLineHeadIndent { get; }

		//- (NSArray *)tabStops;		
		[Export ("tabStops")]
		NSArray TabStops { get; }

		//- (CGFloat)minimumLineHeight;	
		[Export ("minimumLineHeight")]
		float MinimumLineHeight { get; }

		//- (CGFloat)maximumLineHeight;	 
		[Export ("maximumLineHeight")]
		float MaximumLineHeight { get; }

		//- (NSLineBreakMode)lineBreakMode;
		[Export ("lineBreakMode")]
		NSLineBreakMode LineBreakMode { get; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_2
		//- (NSWritingDirection)baseWritingDirection;
		[Export ("baseWritingDirection")]
		NSWritingDirection BaseWritingDirection { get; }

//#endif
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//- (CGFloat)lineHeightMultiple;	
		[Export ("lineHeightMultiple")]
		float LineHeightMultiple { get; }

		//- (CGFloat)paragraphSpacingBefore;
		[Export ("paragraphSpacingBefore")]
		float ParagraphSpacingBefore { get; }

		//- (CGFloat)defaultTabInterval;	 
		[Export ("defaultTabInterval")]
		float DefaultTabInterval { get; }

//#endif
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (NSArray *)textBlocks;    
		[Export ("textBlocks")]
		NSArray TextBlocks { get; }

		//- (NSArray *)textLists;     
		[Export ("textLists")]
		NSArray TextLists { get; }

		//- (float)hyphenationFactor;
		[Export ("hyphenationFactor")]
		float HyphenationFactor { get; }

		//- (float)tighteningFactorForTruncation;
		[Export ("tighteningFactorForTruncation")]
		float TighteningFactorForTruncation { get; }

		//- (NSInteger)headerLevel;
		[Export ("headerLevel")]
		int HeaderLevel { get; }

//#endif
	}
}
