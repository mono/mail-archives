using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{
	[Model]
// NSTextAttachmentCell has multiple base types defined, 'NSObject' and 'NSCell'
	[BaseType (typeof (NSObject))]
	interface NSTextAttachmentCell {

		// from NSTextDelegate- (BOOL)wantsToTrackMouse;
		[Abstract, Export ("wantsToTrackMouse")]
		bool WantsToTrackMouse { get; }

		// from NSTextDelegate- (void)highlight:(BOOL)flag withFrame:(NSRect)cellFrame inView:(NSView *)controlView;
		[Abstract, Export ("highlight:withFrame:inView:")]
		void HighlightWithFrame (bool flag, RectangleF cellFrame, NSView controlView);

		// from NSTextDelegate- (BOOL)trackMouse:(NSEvent *)theEvent inRect:(NSRect)cellFrame ofView:(NSView *)controlView untilMouseUp:(BOOL)flag;
		[Abstract, Export ("trackMouse:inRect:ofView:untilMouseUp:")]
		bool TrackMouseInRect (NSEvent theEvent, RectangleF cellFrame, NSView controlView, bool flag);

		// from NSTextDelegate- (NSSize)cellSize;
		[Abstract, Export ("cellSize")]
		SizeF CellSize { get; }

		// from NSTextDelegate- (NSPoint)cellBaselineOffset;
		[Abstract, Export ("cellBaselineOffset")]
		PointF CellBaselineOffset { get; }

		// from NSTextDelegate- (NSTextAttachment *)attachment;
		[Abstract, Export ("attachment")]
		NSTextAttachment Attachment { get; set; }

		// from NSTextDelegate- (void)drawWithFrame:(NSRect)cellFrame inView:(NSView *)controlView characterIndex:(NSUInteger)charIndex;
		[Abstract, Export ("drawWithFrame:inView:characterIndex:")]
		void DrawWithFrameInView (RectangleF cellFrame, NSView controlView, uint charIndex);

		// from NSTextDelegate- (void)drawWithFrame:(NSRect)cellFrame inView:(NSView *)controlView characterIndex:(NSUInteger)charIndex layoutManager:(NSLayoutManager *)layoutManager;
		[Abstract, Export ("drawWithFrame:inView:characterIndex:layoutManager:")]
		void DrawWithFrameInView (RectangleF cellFrame, NSView controlView, uint charIndex, NSLayoutManager layoutManager);

		// from NSTextDelegate- (BOOL)wantsToTrackMouseForEvent:(NSEvent *)theEvent inRect:(NSRect)cellFrame ofView:(NSView *)controlView atCharacterIndex:(NSUInteger)charIndex;
		[Abstract, Export ("wantsToTrackMouseForEvent:inRect:ofView:atCharacterIndex:")]
		bool WantsToTrackMouseForEventInRect (NSEvent theEvent, RectangleF cellFrame, NSView controlView, uint charIndex);

		// from NSTextDelegate- (BOOL)trackMouse:(NSEvent *)theEvent inRect:(NSRect)cellFrame ofView:(NSView *)controlView atCharacterIndex:(NSUInteger)charIndex untilMouseUp:(BOOL)flag;
		[Abstract, Export ("trackMouse:inRect:ofView:atCharacterIndex:untilMouseUp:")]
		bool TrackMouseInRect (NSEvent theEvent, RectangleF cellFrame, NSView controlView, uint charIndex, bool flag);

		// from NSTextDelegate- (NSRect)cellFrameForTextContainer:(NSTextContainer *)textContainer proposedLineFragment:(NSRect)lineFrag glyphPosition:(NSPoint)position characterIndex:(NSUInteger)charIndex;
		[Abstract, Export ("cellFrameForTextContainer:proposedLineFragment:glyphPosition:characterIndex:")]
		RectangleF CellFrameForTextContainerProposedLineFragment (NSTextContainer textContainer, RectangleF lineFrag, PointF position, uint charIndex);

	}
}
