using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSImageRep))]
	interface NSEPSImageRep {

		//+ (id)imageRepWithData:(NSData *)epsData;	
		[Static, Export ("imageRepWithData:")]
		NSEPSImageRep ImageRepWithData (NSData epsData);

		//- (id)initWithData:(NSData *)epsData;
		[Export ("initWithData:")]
		IntPtr Constructor (NSData epsData);

		//- (void)prepareGState;
		[Export ("prepareGState")]
		void PrepareGState ();

		//- (NSData *)EPSRepresentation;
		[Export ("EPSRepresentation")]
		NSData EPSRepresentation { get; }

		//- (NSRect)boundingBox;
		[Export ("boundingBox")]
		RectangleF BoundingBox { get; }

	}
}
