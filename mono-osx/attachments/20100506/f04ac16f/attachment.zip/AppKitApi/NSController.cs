using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSObject))]
	interface NSController {

		//- (void)objectDidBeginEditing:(id)editor;
		[Export ("objectDidBeginEditing:")]
		void ObjectDidBeginEditing (NSObject editor);

		//- (void)objectDidEndEditing:(id)editor;
		[Export ("objectDidEndEditing:")]
		void ObjectDidEndEditing (NSObject editor);

		//- (void)discardEditing;
		[Export ("discardEditing")]
		void DiscardEditing ();

		//- (BOOL)commitEditing;
		[Export ("commitEditing")]
		bool CommitEditing { get; }

		//- (void)commitEditingWithDelegate:(id)delegate didCommitSelector:(SEL)didCommitSelector contextInfo:(void *)contextInfo;
		[Export ("commitEditingWithDelegate:didCommitSelector:contextInfo:")]
		void CommitEditingWithDelegate (NSObject delegate1, Selector didCommitSelector, IntPtr contextInfo);

		//- (BOOL)isEditing;
		[Export ("isEditing")]
		bool IsEditing { get; }

	}
}
