using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSTextFieldCell))]
	interface NSTableHeaderCell {

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//- (void)drawSortIndicatorWithFrame:(NSRect)cellFrame inView:(NSView *)controlView ascending:(BOOL)ascending priority:(NSInteger)priority;
		[Export ("drawSortIndicatorWithFrame:inView:ascending:priority:")]
		void DrawSortIndicatorWithFrame (RectangleF cellFrame, NSView controlView, bool ascending, int priority);

		//    - (NSRect)sortIndicatorRectForBounds:(NSRect)theRect;
		[Export ("sortIndicatorRectForBounds:")]
		RectangleF SortIndicatorRectForBounds (RectangleF theRect);

//#endif
	}
}
