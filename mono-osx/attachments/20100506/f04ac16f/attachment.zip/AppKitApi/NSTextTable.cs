using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSTextBlock))]
	interface NSTextTable {

		//- (NSUInteger)numberOfColumns;
		[Export ("numberOfColumns")]
		uint NumberOfColumns { get; set; }

		//- (NSTextTableLayoutAlgorithm)layoutAlgorithm;
		[Export ("layoutAlgorithm")]
		NSTextTableLayoutAlgorithm LayoutAlgorithm { get; set; }

		//- (BOOL)collapsesBorders;
		[Export ("collapsesBorders")]
		bool CollapsesBorders { get; set; }

		//- (BOOL)hidesEmptyCells;
		[Export ("hidesEmptyCells")]
		bool HidesEmptyCells { get; set; }

		//- (NSRect)rectForBlock:(NSTextTableBlock *)block layoutAtPoint:(NSPoint)startingPoint inRect:(NSRect)rect textContainer:(NSTextContainer *)textContainer characterRange:(NSRange)charRange;
		[Export ("rectForBlock:layoutAtPoint:inRect:textContainer:characterRange:")]
		RectangleF RectForBlock (NSTextTableBlock block, PointF startingPoint, RectangleF rect, NSTextContainer textContainer, NSRange charRange);

		//- (NSRect)boundsRectForBlock:(NSTextTableBlock *)block contentRect:(NSRect)contentRect inRect:(NSRect)rect textContainer:(NSTextContainer *)textContainer characterRange:(NSRange)charRange;
		[Export ("boundsRectForBlock:contentRect:inRect:textContainer:characterRange:")]
		RectangleF BoundsRectForBlock (NSTextTableBlock block, RectangleF contentRect, RectangleF rect, NSTextContainer textContainer, NSRange charRange);

		//- (void)drawBackgroundForBlock:(NSTextTableBlock *)block withFrame:(NSRect)frameRect inView:(NSView *)controlView characterRange:(NSRange)charRange layoutManager:(NSLayoutManager *)layoutManager;
		[Export ("drawBackgroundForBlock:withFrame:inView:characterRange:layoutManager:")]
		void DrawBackgroundForBlock (NSTextTableBlock block, RectangleF frameRect, NSView controlView, NSRange charRange, NSLayoutManager layoutManager);

	}
}
