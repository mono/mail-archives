using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSTextFieldCell))]
	interface NSPathComponentCell {

		//- (NSImage *)image;
		[Export ("image")]
		NSImage Image { get; set; }

		//- (NSURL *)URL;
		[Export ("URL")]
		NSUrl Url { get; set; }

	}
}
