using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSObject))]
	interface NSOpenGLContext {

		//- (id)initWithFormat:(NSOpenGLPixelFormat *)format shareContext:(NSOpenGLContext *)share;
		[Export ("initWithFormat:shareContext:")]
		IntPtr Constructor (NSOpenGLPixelFormat format, NSOpenGLContext share);

		//- (NSView *)view;
		[Export ("view")]
		NSView View { get; set; }

		//- (void)setFullScreen;
		[Export ("setFullScreen")]
		void SetFullScreen ();

		//- (void)setOffScreen:(void *)baseaddr width:(GLsizei)width height:(GLsizei)height rowbytes:(GLint)rowbytes;
		[Export ("setOffScreen:width:height:rowbytes:")]
		void SetOffScreen (IntPtr baseaddr, GLsizei width, GLsizei height, GLint rowbytes);

		//- (void)clearDrawable;
		[Export ("clearDrawable")]
		void ClearDrawable ();

		//- (void)update;
		[Export ("update")]
		void Update ();

		//- (void)flushBuffer;
		[Export ("flushBuffer")]
		void FlushBuffer ();

		//- (void)makeCurrentContext;
		[Export ("makeCurrentContext")]
		void MakeCurrentContext ();

		//+ (void)clearCurrentContext;
		[Static, Export ("clearCurrentContext")]
		void ClearCurrentContext ();

		//+ (NSOpenGLContext *)currentContext;
		[Static, Export ("currentContext")]
		NSOpenGLContext CurrentContext { get; }

		//- (void)copyAttributesFromContext:(NSOpenGLContext *)context withMask:(GLbitfield)mask;
		[Export ("copyAttributesFromContext:withMask:")]
		void CopyAttributesFromContext (NSOpenGLContext context, GLbitfield mask);

		////- (void)setValues:(const GLint *)vals forParameter:(NSOpenGLContextParameter)param;
		//[Export ("setValues:forParameter:")]
		//void SetValues (const GLint vals, NSOpenGLContextParameter param);

		//- (void)getValues:(GLint *)vals forParameter:(NSOpenGLContextParameter)param;
		[Export ("getValues:forParameter:")]
		void GetValues (GLint vals, NSOpenGLContextParameter param);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_2
		//- (GLint)currentVirtualScreen;
		[Export ("currentVirtualScreen")]
		GLint CurrentVirtualScreen { get; set; }

		//- (void)createTexture:(GLenum)target fromView:(NSView *)view internalFormat:(GLenum)format;
		[Export ("createTexture:fromView:internalFormat:")]
		void CreateTexture (uint target, NSView view, uint format);

//#endif
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//- (void *)CGLContextObj;
		[Export ("CGLContextObj")]
		void CGLContextObj ();

		//- (void)setPixelBuffer:(NSOpenGLPixelBuffer *)pixelBuffer cubeMapFace:(GLenum)face mipMapLevel:(GLint)level currentVirtualScreen:(GLint)screen;
		[Export ("setPixelBuffer:cubeMapFace:mipMapLevel:currentVirtualScreen:")]
		void SetPixelBuffer (NSOpenGLPixelBuffer pixelBuffer, uint face, GLint level, GLint screen);

		//- (NSOpenGLPixelBuffer *)pixelBuffer;
		[Export ("pixelBuffer")]
		NSOpenGLPixelBuffer PixelBuffer { get; }

		//- (GLenum)pixelBufferCubeMapFace;
		[Export ("pixelBufferCubeMapFace")]
		uint PixelBufferCubeMapFace { get; }

		//- (GLint)pixelBufferMipMapLevel;
		[Export ("pixelBufferMipMapLevel")]
		GLint PixelBufferMipMapLevel { get; }

		//- (void)setTextureImageToPixelBuffer:(NSOpenGLPixelBuffer *)pixelBuffer colorBuffer:(GLenum)source;
		[Export ("setTextureImageToPixelBuffer:colorBuffer:")]
		void SetTextureImageToPixelBuffer (NSOpenGLPixelBuffer pixelBuffer, uint source);

//#endif
	}
}
