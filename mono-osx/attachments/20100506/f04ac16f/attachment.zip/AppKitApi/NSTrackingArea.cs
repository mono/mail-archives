using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSObject))]
	interface NSTrackingArea {

		//- (NSTrackingArea *)initWithRect:(NSRect)rect options:(NSTrackingAreaOptions)options owner:(id)owner userInfo:(NSDictionary *)userInfo;
		[Export ("initWithRect:options:owner:userInfo:")]
		IntPtr Constructor (RectangleF rect, NSTrackingAreaOptions options, NSObject owner, NSDictionary userInfo);

		//- (NSRect)rect;
		[Export ("rect")]
		RectangleF Rect { get; }

		//- (NSTrackingAreaOptions)options;
		[Export ("options")]
		NSTrackingAreaOptions Options { get; }

		//- (id)owner;
		[Export ("owner")]
		NSTrackingArea Owner { get; }

		//- (NSDictionary *)userInfo;
		[Export ("userInfo")]
		NSDictionary UserInfo { get; }

	}
}
