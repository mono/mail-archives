using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSObject))]
	interface NSColorPicker {

		//- (id)initWithPickerMask:(NSUInteger)mask colorPanel:(NSColorPanel *)owningColorPanel;
		[Export ("initWithPickerMask:colorPanel:")]
		IntPtr Constructor (uint mask, NSColorPanel owningColorPanel);

		//- (NSColorPanel *)colorPanel;
		[Export ("colorPanel")]
		NSColorPanel ColorPanel { get; }

		//- (NSImage *)provideNewButtonImage;
		[Export ("provideNewButtonImage")]
		NSImage ProvideNewButtonImage { get; }

		//- (void)insertNewButtonImage:(NSImage *)newButtonImage in:(NSButtonCell *)buttonCell;
		[Export ("insertNewButtonImage:in:")]
		void InsertNewButtonImage (NSImage newButtonImage, NSButtonCell buttonCell);

		//- (void)viewSizeChanged:(id)sender;
		[Export ("viewSizeChanged:")]
		void ViewSizeChanged (NSObject sender);

		//- (void)attachColorList:(NSColorList *)colorList;
		[Export ("attachColorList:")]
		void AttachColorList (NSColorList colorList);

		//- (void)detachColorList:(NSColorList *)colorList;
		[Export ("detachColorList:")]
		void DetachColorList (NSColorList colorList);

		//- (void)setMode:(NSColorPanelMode)mode;
		[Export ("setMode:")]
		void SetMode (NSColorPanelMode mode);

		//- (NSString *)buttonToolTip;
		[Export ("buttonToolTip")]
		string ButtonToolTip { get; }

		//- (NSSize)minContentSize;
		[Export ("minContentSize")]
		NSSize MinContentSize { get; }

	}
}
