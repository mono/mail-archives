using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{
	[BaseType (typeof (NSColorPickingDefault))]
	[Model]
	interface NSColorPickingCustom {

		[Abstract]
		//- (BOOL)supportsMode:(NSColorPanelMode)mode;   
		[Export ("supportsMode:")]
		bool SupportsMode (NSColorPanelMode mode);

		[Abstract]
		//- (NSColorPanelMode)currentMode;
		[Export ("currentMode")]
		NSColorPanelMode CurrentMode { get; }

		[Abstract]
		//- (NSView *)provideNewView:(BOOL)initialRequest;
		[Export ("provideNewView:")]
		NSView ProvideNewView (bool initialRequest);

		[Abstract]
		//- (void)setColor:(NSColor *)newColor;
		[Export ("setColor:")]
		void SetColor (NSColor newColor);

	}
}
