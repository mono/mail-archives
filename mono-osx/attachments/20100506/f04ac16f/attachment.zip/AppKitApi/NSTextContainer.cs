using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSObject))]
	interface NSTextContainer {

		//- (id)initWithContainerSize:(NSSize)size;
		[Export ("initWithContainerSize:")]
		IntPtr Constructor (NSSize size);

		//- (NSLayoutManager *)layoutManager;
		[Export ("layoutManager")]
		NSLayoutManager LayoutManager { get; set; }

		//    - (void)replaceLayoutManager:(NSLayoutManager *)newLayoutManager;
		[Export ("replaceLayoutManager:")]
		void ReplaceLayoutManager (NSLayoutManager newLayoutManager);

		//    - (NSTextView *)textView;
		[Export ("textView")]
		NSTextView TextView { get; set; }

		//- (BOOL)widthTracksTextView;
		[Export ("widthTracksTextView")]
		bool WidthTracksTextView { get; set; }

		//- (BOOL)heightTracksTextView;
		[Export ("heightTracksTextView")]
		bool HeightTracksTextView { get; set; }

		//- (NSSize)containerSize;
		[Export ("containerSize")]
		NSSize ContainerSize { get; set; }

		//- (CGFloat)lineFragmentPadding;
		[Export ("lineFragmentPadding")]
		float LineFragmentPadding { get; set; }

		//    - (NSRect)lineFragmentRectForProposedRect:(NSRect)proposedRect sweepDirection:(NSLineSweepDirection)sweepDirection movementDirection:(NSLineMovementDirection)movementDirection remainingRect:(NSRectPointer)remainingRect;
		[Export ("lineFragmentRectForProposedRect:sweepDirection:movementDirection:remainingRect:")]
		RectangleF LineFragmentRectForProposedRect (RectangleF proposedRect, NSLineSweepDirection sweepDirection, NSLineMovementDirection movementDirection, NSRectPointer remainingRect);

		//    - (BOOL)isSimpleRectangularTextContainer;
		[Export ("isSimpleRectangularTextContainer")]
		bool IsSimpleRectangularTextContainer { get; }

		//    - (BOOL)containsPoint:(NSPoint)point;
		[Export ("containsPoint:")]
		bool ContainsPoint (PointF point);

	}
}
