using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSObject))]
	interface NSStatusItem {

		//- (NSStatusBar* )statusBar;
		[Export ("statusBar")]
		NSStatusBar StatusBar { get; }

		//- (CGFloat)length;
		[Export ("length")]
		float Length { get; set; }

		//- (SEL)action;
		[Export ("action")]
		Selector Action { get; set; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (SEL)doubleAction;
		[Export ("doubleAction")]
		Selector DoubleAction { get; set; }

//#endif
		//- (id)target;
		[Export ("target")]
		NSStatusItem Target { get; }

		//- (void)setTarget:(id)target;
		[Export ("setTarget:")]
		void SetTarget (NSObject target);

		//- (NSString* )title;
		[Export ("title")]
		string Title { get; set; }

		//- (NSAttributedString* )attributedTitle;
		[Export ("attributedTitle")]
		NSAttributedString AttributedTitle { get; set; }

		//- (NSImage* )image;
		[Export ("image")]
		NSImage Image { get; set; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//- (NSImage *)alternateImage;
		[Export ("alternateImage")]
		NSImage AlternateImage { get; set; }

//#endif
		//- (NSMenu* )menu;
		[Export ("menu")]
		NSMenu Menu { get; set; }

		//- (BOOL)isEnabled;
		[Export ("isEnabled")]
		bool IsEnabled { get; }

		//- (void)setEnabled:(BOOL)enabled;
		[Export ("setEnabled:")]
		void SetEnabled (bool enabled);

		//- (NSString* )toolTip;
		[Export ("toolTip")]
		string ToolTip { get; set; }

		//- (BOOL)highlightMode;
		[Export ("highlightMode")]
		bool HighlightMode { get; set; }

		//- (NSInteger)sendActionOn:(NSInteger)mask;
		[Export ("sendActionOn:")]
		int SendActionOn (int mask);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//- (void)popUpStatusItemMenu:(NSMenu*)menu;
		[Export ("popUpStatusItemMenu:")]
		void PopUpStatusItemMenu (NSMenu menu);

		//- (void)drawStatusBarBackgroundInRect:(NSRect)rect withHighlight:(BOOL)highlight;
		[Export ("drawStatusBarBackgroundInRect:withHighlight:")]
		void DrawStatusBarBackgroundInRectWithHighlight (RectangleF rect, bool highlight);

//#endif
		//- (NSView* )view;
		[Export ("view")]
		NSView View { get; set; }

	}
}
