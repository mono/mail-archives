using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSView))]
	interface NSTabView {

		//	- (void)selectTabViewItem:(NSTabViewItem *)tabViewItem;
		[Export ("selectTabViewItem:")]
		void SelectTabViewItem (NSTabViewItem tabViewItem);

		//- (void)selectTabViewItemAtIndex:(NSInteger)index;				
		[Export ("selectTabViewItemAtIndex:")]
		void SelectTabViewItemAtIndex (int index);

		//- (void)selectTabViewItemWithIdentifier:(id)identifier;			
		[Export ("selectTabViewItemWithIdentifier:")]
		void SelectTabViewItemWithIdentifier (NSObject identifier);

		//- (void)takeSelectedTabViewItemFromSender:(id)sender;			
		[Export ("takeSelectedTabViewItemFromSender:")]
		void TakeSelectedTabViewItemFromSender (NSObject sender);

		//	- (void)selectFirstTabViewItem:(id)sender;
		[Export ("selectFirstTabViewItem:")]
		void SelectFirstTabViewItem (NSObject sender);

		//- (void)selectLastTabViewItem:(id)sender;
		[Export ("selectLastTabViewItem:")]
		void SelectLastTabViewItem (NSObject sender);

		//- (void)selectNextTabViewItem:(id)sender;
		[Export ("selectNextTabViewItem:")]
		void SelectNextTabViewItem (NSObject sender);

		//- (void)selectPreviousTabViewItem:(id)sender;
		[Export ("selectPreviousTabViewItem:")]
		void SelectPreviousTabViewItem (NSObject sender);

		//	- (NSTabViewItem *)selectedTabViewItem;					
		[Export ("selectedTabViewItem")]
		NSTabViewItem SelectedTabViewItem { get; }

		//- (NSFont *)font;							
		[Export ("font")]
		NSFont Font { get; set; }

		//- (NSTabViewType)tabViewType;
		[Export ("tabViewType")]
		NSTabViewType TabViewType { get; set; }

		//- (NSArray *)tabViewItems;
		[Export ("tabViewItems")]
		NSArray TabViewItems { get; }

		//- (BOOL)allowsTruncatedLabels;
		[Export ("allowsTruncatedLabels")]
		bool AllowsTruncatedLabels { get; set; }

		//- (NSSize)minimumSize;							
		[Export ("minimumSize")]
		NSSize MinimumSize { get; }

		//- (BOOL)drawsBackground;  						
		[Export ("drawsBackground")]
		bool DrawsBackground { get; set; }

		//- (NSControlTint)controlTint;
		[Export ("controlTint")]
		NSControlTint ControlTint { get; set; }

		//- (NSControlSize)controlSize;
		[Export ("controlSize")]
		NSControlSize ControlSize { get; set; }

		//	- (void)addTabViewItem:(NSTabViewItem *)tabViewItem;				
		[Export ("addTabViewItem:")]
		void AddTabViewItem (NSTabViewItem tabViewItem);

		//- (void)insertTabViewItem:(NSTabViewItem *)tabViewItem atIndex:(NSInteger)index;	
		[Export ("insertTabViewItem:atIndex:")]
		void InsertTabViewItem (NSTabViewItem tabViewItem, int index);

		//- (void)removeTabViewItem:(NSTabViewItem *)tabViewItem;				
		[Export ("removeTabViewItem:")]
		void RemoveTabViewItem (NSTabViewItem tabViewItem);

		//	- (void)setDelegate:(id)anObject;
		[Export ("setDelegate:")]
		void SetDelegate (NSObject anObject);

		//- (id)delegate;
		[Export ("delegate")]
		NSTabView Delegate { get; }

		//	- (NSTabViewItem *)tabViewItemAtPoint:(NSPoint)point;			
		[Export ("tabViewItemAtPoint:")]
		NSTabViewItem TabViewItemAtPoint (PointF point);

		//	- (NSRect)contentRect;							
		[Export ("contentRect")]
		RectangleF ContentRect { get; }

		//	- (NSInteger)numberOfTabViewItems;
		[Export ("numberOfTabViewItems")]
		int NumberOfTabViewItems { get; }

		//- (NSInteger)indexOfTabViewItem:(NSTabViewItem *)tabViewItem;			
		[Export ("indexOfTabViewItem:")]
		int IndexOfTabViewItem (NSTabViewItem tabViewItem);

		//- (NSTabViewItem *)tabViewItemAtIndex:(NSInteger)index;			
		[Export ("tabViewItemAtIndex:")]
		NSTabViewItem TabViewItemAtIndex (int index);

		//- (NSInteger)indexOfTabViewItemWithIdentifier:(id)identifier;			
		[Export ("indexOfTabViewItemWithIdentifier:")]
		int IndexOfTabViewItemWithIdentifier (NSObject identifier);

	}
}
