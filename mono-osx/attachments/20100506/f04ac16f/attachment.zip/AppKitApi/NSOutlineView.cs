using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSTableView))]
	interface NSOutlineView {

		//- (NSTableColumn *)outlineTableColumn;
		[Export ("outlineTableColumn")]
		NSTableColumn OutlineTableColumn { get; set; }

		//- (BOOL)isExpandable:(id)item;
		[Export ("isExpandable:")]
		bool IsExpandable (NSObject item);

		//- (void)expandItem:(id)item expandChildren:(BOOL)expandChildren;
		[Export ("expandItem:expandChildren:")]
		void ExpandItem (NSObject item, bool expandChildren);

		//- (void)expandItem:(id)item;
		[Export ("expandItem:")]
		void ExpandItem (NSObject item);

		//- (void)collapseItem:(id)item collapseChildren:(BOOL)collapseChildren;
		[Export ("collapseItem:collapseChildren:")]
		void CollapseItem (NSObject item, bool collapseChildren);

		//- (void)collapseItem:(id)item;
		[Export ("collapseItem:")]
		void CollapseItem (NSObject item);

		//- (void)reloadItem:(id)item reloadChildren:(BOOL)reloadChildren;
		[Export ("reloadItem:reloadChildren:")]
		void ReloadItem (NSObject item, bool reloadChildren);

		//- (void)reloadItem:(id)item;
		[Export ("reloadItem:")]
		void ReloadItem (NSObject item);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (id)parentForItem:(id)item; 
		[Export ("parentForItem:")]
		NSOutlineView ParentForItem (NSObject item);

//#endif
		//- (id)itemAtRow:(NSInteger)row;
		[Export ("itemAtRow:")]
		NSOutlineView ItemAtRow (int row);

		//- (NSInteger)rowForItem:(id)item;
		[Export ("rowForItem:")]
		int RowForItem (NSObject item);

		//- (NSInteger)levelForItem:(id)item;
		[Export ("levelForItem:")]
		int LevelForItem (NSObject item);

		//- (NSInteger)levelForRow:(NSInteger)row;
		[Export ("levelForRow:")]
		int LevelForRow (int row);

		//- (BOOL)isItemExpanded:(id)item;
		[Export ("isItemExpanded:")]
		bool IsItemExpanded (NSObject item);

		//- (CGFloat)indentationPerLevel;
		[Export ("indentationPerLevel")]
		float IndentationPerLevel { get; set; }

		//- (BOOL)indentationMarkerFollowsCell;
		[Export ("indentationMarkerFollowsCell")]
		bool IndentationMarkerFollowsCell { get; set; }

		//- (BOOL)autoresizesOutlineColumn;
		[Export ("autoresizesOutlineColumn")]
		bool AutoresizesOutlineColumn { get; set; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (NSRect)frameOfOutlineCellAtRow:(NSInteger)row;
		[Export ("frameOfOutlineCellAtRow:")]
		RectangleF FrameOfOutlineCellAtRow (int row);

//#endif
		//- (void)setDropItem:(id)item dropChildIndex:(NSInteger)index;
		[Export ("setDropItem:dropChildIndex:")]
		void SetDropItem (NSObject item, int index);

		//- (BOOL)shouldCollapseAutoExpandedItemsForDeposited:(BOOL)deposited;
		[Export ("shouldCollapseAutoExpandedItemsForDeposited:")]
		bool ShouldCollapseAutoExpandedItemsForDeposited (bool deposited);

		//- (BOOL)autosaveExpandedItems;
		[Export ("autosaveExpandedItems")]
		bool AutosaveExpandedItems { get; set; }

	}
}
