using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSObject))]
	interface NSLayoutManager {

//#endif 
		//- (id)init;
		[Export ("init")]
		IntPtr Init { get; }

		//    - (NSTextStorage *)textStorage;
		[Export ("textStorage")]
		NSTextStorage TextStorage { get; set; }

		//    - (NSAttributedString *)attributedString;
		[Export ("attributedString")]
		NSAttributedString AttributedString { get; }

		//    - (void)replaceTextStorage:(NSTextStorage *)newTextStorage;
		[Export ("replaceTextStorage:")]
		void ReplaceTextStorage (NSTextStorage newTextStorage);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//        - (NSGlyphGenerator *)glyphGenerator;
		[Export ("glyphGenerator")]
		NSGlyphGenerator GlyphGenerator { get; set; }

//#endif 
		//    - (NSTypesetter *)typesetter;
		[Export ("typesetter")]
		NSTypesetter Typesetter { get; set; }

		//    - (id)delegate;
		[Export ("delegate")]
		NSLayoutManager Delegate { get; }

		//- (void)setDelegate:(id)delegate;
		[Export ("setDelegate:")]
		void SetDelegate (NSObject delegate1);

		//    - (NSArray *)textContainers;
		[Export ("textContainers")]
		NSArray TextContainers { get; }

		//- (void)addTextContainer:(NSTextContainer *)container;
		[Export ("addTextContainer:")]
		void AddTextContainer (NSTextContainer container);

		//    - (void)insertTextContainer:(NSTextContainer *)container atIndex:(NSUInteger)index;
		[Export ("insertTextContainer:atIndex:")]
		void InsertTextContainer (NSTextContainer container, uint index);

		//    - (void)removeTextContainerAtIndex:(NSUInteger)index;
		[Export ("removeTextContainerAtIndex:")]
		void RemoveTextContainerAtIndex (uint index);

		//    - (void)textContainerChangedGeometry:(NSTextContainer *)container;
		[Export ("textContainerChangedGeometry:")]
		void TextContainerChangedGeometry (NSTextContainer container);

		//    - (void)textContainerChangedTextView:(NSTextContainer *)container;
		[Export ("textContainerChangedTextView:")]
		void TextContainerChangedTextView (NSTextContainer container);

		//- (BOOL)backgroundLayoutEnabled;
		[Export ("backgroundLayoutEnabled")]
		bool BackgroundLayoutEnabled { get; set; }

		//- (BOOL)usesScreenFonts;
		[Export ("usesScreenFonts")]
		bool UsesScreenFonts { get; set; }

		//- (BOOL)showsInvisibleCharacters;
		[Export ("showsInvisibleCharacters")]
		bool ShowsInvisibleCharacters { get; set; }

		//- (BOOL)showsControlCharacters;
		[Export ("showsControlCharacters")]
		bool ShowsControlCharacters { get; set; }

		//- (float)hyphenationFactor;
		[Export ("hyphenationFactor")]
		float HyphenationFactor { get; set; }

		//- (NSImageScaling)defaultAttachmentScaling;
		[Export ("defaultAttachmentScaling")]
		NSImageScaling DefaultAttachmentScaling { get; set; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_2
		//- (NSTypesetterBehavior)typesetterBehavior;
		[Export ("typesetterBehavior")]
		NSTypesetterBehavior TypesetterBehavior { get; set; }

//#endif 
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//    - (NSUInteger)layoutOptions;
		[Export ("layoutOptions")]
		uint LayoutOptions { get; }

//#endif 
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (BOOL)allowsNonContiguousLayout;
		[Export ("allowsNonContiguousLayout")]
		bool AllowsNonContiguousLayout { get; set; }

		//    - (BOOL)hasNonContiguousLayout;
		[Export ("hasNonContiguousLayout")]
		bool HasNonContiguousLayout { get; }

//#endif 
		//    - (void)invalidateGlyphsForCharacterRange:(NSRange)charRange changeInLength:(NSInteger)delta actualCharacterRange:(NSRangePointer)actualCharRange;
		[Export ("invalidateGlyphsForCharacterRange:changeInLength:actualCharacterRange:")]
		void InvalidateGlyphsForCharacterRange (NSRange charRange, int delta, NSRangePointer actualCharRange);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//    - (void)invalidateLayoutForCharacterRange:(NSRange)charRange actualCharacterRange:(NSRangePointer)actualCharRange;
		[Export ("invalidateLayoutForCharacterRange:actualCharacterRange:")]
		void InvalidateLayoutForCharacterRange (NSRange charRange, NSRangePointer actualCharRange);

//#endif 
		//- (void)invalidateLayoutForCharacterRange:(NSRange)charRange isSoft:(BOOL)flag actualCharacterRange:(NSRangePointer)actualCharRange;
		[Export ("invalidateLayoutForCharacterRange:isSoft:actualCharacterRange:")]
		void InvalidateLayoutForCharacterRange (NSRange charRange, bool flag, NSRangePointer actualCharRange);

		//    - (void)invalidateDisplayForCharacterRange:(NSRange)charRange;
		[Export ("invalidateDisplayForCharacterRange:")]
		void InvalidateDisplayForCharacterRange (NSRange charRange);

		//- (void)invalidateDisplayForGlyphRange:(NSRange)glyphRange;
		[Export ("invalidateDisplayForGlyphRange:")]
		void InvalidateDisplayForGlyphRange (NSRange glyphRange);

		//    - (void)textStorage:(NSTextStorage *)str edited:(NSUInteger)editedMask range:(NSRange)newCharRange changeInLength:(NSInteger)delta invalidatedRange:(NSRange)invalidatedCharRange;
		[Export ("textStorage:edited:range:changeInLength:invalidatedRange:")]
		void TextStorageEdited (NSTextStorage str, uint editedMask, NSRange newCharRange, int delta, NSRange invalidatedCharRange);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//    - (void)ensureGlyphsForCharacterRange:(NSRange)charRange;
		[Export ("ensureGlyphsForCharacterRange:")]
		void EnsureGlyphsForCharacterRange (NSRange charRange);

		//- (void)ensureGlyphsForGlyphRange:(NSRange)glyphRange;
		[Export ("ensureGlyphsForGlyphRange:")]
		void EnsureGlyphsForGlyphRange (NSRange glyphRange);

		//- (void)ensureLayoutForCharacterRange:(NSRange)charRange;
		[Export ("ensureLayoutForCharacterRange:")]
		void EnsureLayoutForCharacterRange (NSRange charRange);

		//- (void)ensureLayoutForGlyphRange:(NSRange)glyphRange;
		[Export ("ensureLayoutForGlyphRange:")]
		void EnsureLayoutForGlyphRange (NSRange glyphRange);

		//- (void)ensureLayoutForTextContainer:(NSTextContainer *)container;
		[Export ("ensureLayoutForTextContainer:")]
		void EnsureLayoutForTextContainer (NSTextContainer container);

		//- (void)ensureLayoutForBoundingRect:(NSRect)bounds inTextContainer:(NSTextContainer *)container;
		[Export ("ensureLayoutForBoundingRect:inTextContainer:")]
		void EnsureLayoutForBoundingRect (RectangleF bounds, NSTextContainer container);

//#endif 
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		////    - (void)insertGlyphs:(const NSGlyph *)glyphs length:(NSUInteger)length forStartingGlyphAtIndex:(NSUInteger)glyphIndex characterIndex:(NSUInteger)charIndex;
		//[Export ("insertGlyphs:length:forStartingGlyphAtIndex:characterIndex:")]
		//void InsertGlyphs (const NSGlyph glyphs, uint length, uint glyphIndex, uint charIndex);

//#endif 
		//    - (void)insertGlyph:(NSGlyph)glyph atGlyphIndex:(NSUInteger)glyphIndex characterIndex:(NSUInteger)charIndex;
		[Export ("insertGlyph:atGlyphIndex:characterIndex:")]
		void InsertGlyph (uint glyph, uint glyphIndex, uint charIndex);

		//    - (void)replaceGlyphAtIndex:(NSUInteger)glyphIndex withGlyph:(NSGlyph)newGlyph;
		[Export ("replaceGlyphAtIndex:withGlyph:")]
		void ReplaceGlyphAtIndex (uint glyphIndex, uint newGlyph);

		//    - (void)deleteGlyphsInRange:(NSRange)glyphRange;
		[Export ("deleteGlyphsInRange:")]
		void DeleteGlyphsInRange (NSRange glyphRange);

		//    - (void)setCharacterIndex:(NSUInteger)charIndex forGlyphAtIndex:(NSUInteger)glyphIndex;
		[Export ("setCharacterIndex:forGlyphAtIndex:")]
		void SetCharacterIndex (uint charIndex, uint glyphIndex);

		//    - (void)setIntAttribute:(NSInteger)attributeTag value:(NSInteger)val forGlyphAtIndex:(NSUInteger)glyphIndex;
		[Export ("setIntAttribute:value:forGlyphAtIndex:")]
		void SetIntAttribute (int attributeTag, int val, uint glyphIndex);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//    - (void)invalidateGlyphsOnLayoutInvalidationForGlyphRange:(NSRange)glyphRange;
		[Export ("invalidateGlyphsOnLayoutInvalidationForGlyphRange:")]
		void InvalidateGlyphsOnLayoutInvalidationForGlyphRange (NSRange glyphRange);

//#endif 
		//    - (NSUInteger)numberOfGlyphs;
		[Export ("numberOfGlyphs")]
		uint NumberOfGlyphs { get; }

		//    - (NSGlyph)glyphAtIndex:(NSUInteger)glyphIndex isValidIndex:(BOOL *)isValidIndex;
		[Export ("glyphAtIndex:isValidIndex:")]
		uint GlyphAtIndex (uint glyphIndex, bool isValidIndex);

		//- (NSGlyph)glyphAtIndex:(NSUInteger)glyphIndex;
		[Export ("glyphAtIndex:")]
		uint GlyphAtIndex (uint glyphIndex);

		//- (BOOL)isValidGlyphIndex:(NSUInteger)glyphIndex;
		[Export ("isValidGlyphIndex:")]
		bool IsValidGlyphIndex (uint glyphIndex);

		//        - (NSUInteger)characterIndexForGlyphAtIndex:(NSUInteger)glyphIndex;
		[Export ("characterIndexForGlyphAtIndex:")]
		uint CharacterIndexForGlyphAtIndex (uint glyphIndex);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//    - (NSUInteger)glyphIndexForCharacterAtIndex:(NSUInteger)charIndex;
		[Export ("glyphIndexForCharacterAtIndex:")]
		uint GlyphIndexForCharacterAtIndex (uint charIndex);

//#endif 
		//    - (NSInteger)intAttribute:(NSInteger)attributeTag forGlyphAtIndex:(NSUInteger)glyphIndex;
		[Export ("intAttribute:forGlyphAtIndex:")]
		int IntAttribute (int attributeTag, uint glyphIndex);

		//    - (NSUInteger)getGlyphsInRange:(NSRange)glyphRange glyphs:(NSGlyph *)glyphBuffer characterIndexes:(NSUInteger *)charIndexBuffer glyphInscriptions:(NSGlyphInscription *)inscribeBuffer elasticBits:(BOOL *)elasticBuffer;
		[Export ("getGlyphsInRange:glyphs:characterIndexes:glyphInscriptions:elasticBits:")]
		uint GetGlyphsInRange (NSRange glyphRange, uint glyphBuffer, uint charIndexBuffer, NSGlyphInscription inscribeBuffer, bool elasticBuffer);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_2
		//- (NSUInteger)getGlyphsInRange:(NSRange)glyphRange glyphs:(NSGlyph *)glyphBuffer characterIndexes:(NSUInteger *)charIndexBuffer glyphInscriptions:(NSGlyphInscription *)inscribeBuffer elasticBits:(BOOL *)elasticBuffer bidiLevels:(unsigned char *)bidiLevelBuffer;
		[Export ("getGlyphsInRange:glyphs:characterIndexes:glyphInscriptions:elasticBits:bidiLevels:")]
		uint GetGlyphsInRange (NSRange glyphRange, uint glyphBuffer, uint charIndexBuffer, NSGlyphInscription inscribeBuffer, bool elasticBuffer, byte bidiLevelBuffer);

//#endif 
		//        - (NSUInteger)getGlyphs:(NSGlyph *)glyphArray range:(NSRange)glyphRange;
		[Export ("getGlyphs:range:")]
		uint GetGlyphs (uint glyphArray, NSRange glyphRange);

		//    - (void)setTextContainer:(NSTextContainer *)container forGlyphRange:(NSRange)glyphRange;
		[Export ("setTextContainer:forGlyphRange:")]
		void SetTextContainer (NSTextContainer container, NSRange glyphRange);

		//    - (void)setLineFragmentRect:(NSRect)fragmentRect forGlyphRange:(NSRange)glyphRange usedRect:(NSRect)usedRect;
		[Export ("setLineFragmentRect:forGlyphRange:usedRect:")]
		void SetLineFragmentRect (RectangleF fragmentRect, NSRange glyphRange, RectangleF usedRect);

		//    - (void)setExtraLineFragmentRect:(NSRect)fragmentRect usedRect:(NSRect)usedRect textContainer:(NSTextContainer *)container;
		[Export ("setExtraLineFragmentRect:usedRect:textContainer:")]
		void SetExtraLineFragmentRect (RectangleF fragmentRect, RectangleF usedRect, NSTextContainer container);

		//    - (void)setLocation:(NSPoint)location forStartOfGlyphRange:(NSRange)glyphRange;
		[Export ("setLocation:forStartOfGlyphRange:")]
		void SetLocation (PointF location, NSRange glyphRange);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//    - (void)setLocations:(NSPointArray)locations startingGlyphIndexes:(NSUInteger *)glyphIndexes count:(NSUInteger)count forGlyphRange:(NSRange)glyphRange;
		[Export ("setLocations:startingGlyphIndexes:count:forGlyphRange:")]
		void SetLocations (NSPointArray locations, uint glyphIndexes, uint count, NSRange glyphRange);

//#endif 
		//    - (void)setNotShownAttribute:(BOOL)flag forGlyphAtIndex:(NSUInteger)glyphIndex;
		[Export ("setNotShownAttribute:forGlyphAtIndex:")]
		void SetNotShownAttribute (bool flag, uint glyphIndex);

		//    - (void)setDrawsOutsideLineFragment:(BOOL)flag forGlyphAtIndex:(NSUInteger)glyphIndex;
		[Export ("setDrawsOutsideLineFragment:forGlyphAtIndex:")]
		void SetDrawsOutsideLineFragment (bool flag, uint glyphIndex);

		//    - (void)setAttachmentSize:(NSSize)attachmentSize forGlyphRange:(NSRange)glyphRange;
		[Export ("setAttachmentSize:forGlyphRange:")]
		void SetAttachmentSize (NSSize attachmentSize, NSRange glyphRange);

		//   - (void)getFirstUnlaidCharacterIndex:(NSUInteger *)charIndex glyphIndex:(NSUInteger *)glyphIndex;
		[Export ("getFirstUnlaidCharacterIndex:glyphIndex:")]
		void GetFirstUnlaidCharacterIndex (uint charIndex, uint glyphIndex);

		//- (NSUInteger)firstUnlaidCharacterIndex;
		[Export ("firstUnlaidCharacterIndex")]
		uint FirstUnlaidCharacterIndex { get; }

		//- (NSUInteger)firstUnlaidGlyphIndex;
		[Export ("firstUnlaidGlyphIndex")]
		uint FirstUnlaidGlyphIndex { get; }

		//        - (NSTextContainer *)textContainerForGlyphAtIndex:(NSUInteger)glyphIndex effectiveRange:(NSRangePointer)effectiveGlyphRange;
		[Export ("textContainerForGlyphAtIndex:effectiveRange:")]
		NSTextContainer TextContainerForGlyphAtIndex (uint glyphIndex, NSRangePointer effectiveGlyphRange);

		//    - (NSRect)usedRectForTextContainer:(NSTextContainer *)container;
		[Export ("usedRectForTextContainer:")]
		RectangleF UsedRectForTextContainer (NSTextContainer container);

		//    - (NSRect)lineFragmentRectForGlyphAtIndex:(NSUInteger)glyphIndex effectiveRange:(NSRangePointer)effectiveGlyphRange;
		[Export ("lineFragmentRectForGlyphAtIndex:effectiveRange:")]
		RectangleF LineFragmentRectForGlyphAtIndex (uint glyphIndex, NSRangePointer effectiveGlyphRange);

		//    - (NSRect)lineFragmentUsedRectForGlyphAtIndex:(NSUInteger)glyphIndex effectiveRange:(NSRangePointer)effectiveGlyphRange;
		[Export ("lineFragmentUsedRectForGlyphAtIndex:effectiveRange:")]
		RectangleF LineFragmentUsedRectForGlyphAtIndex (uint glyphIndex, NSRangePointer effectiveGlyphRange);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//    - (NSRect)lineFragmentRectForGlyphAtIndex:(NSUInteger)glyphIndex effectiveRange:(NSRangePointer)effectiveGlyphRange withoutAdditionalLayout:(BOOL)flag;
		[Export ("lineFragmentRectForGlyphAtIndex:effectiveRange:withoutAdditionalLayout:")]
		RectangleF LineFragmentRectForGlyphAtIndex (uint glyphIndex, NSRangePointer effectiveGlyphRange, bool flag);

		//- (NSRect)lineFragmentUsedRectForGlyphAtIndex:(NSUInteger)glyphIndex effectiveRange:(NSRangePointer)effectiveGlyphRange withoutAdditionalLayout:(BOOL)flag;
		[Export ("lineFragmentUsedRectForGlyphAtIndex:effectiveRange:withoutAdditionalLayout:")]
		RectangleF LineFragmentUsedRectForGlyphAtIndex (uint glyphIndex, NSRangePointer effectiveGlyphRange, bool flag);

		//- (NSTextContainer *)textContainerForGlyphAtIndex:(NSUInteger)glyphIndex effectiveRange:(NSRangePointer)effectiveGlyphRange withoutAdditionalLayout:(BOOL)flag;
		[Export ("textContainerForGlyphAtIndex:effectiveRange:withoutAdditionalLayout:")]
		NSTextContainer TextContainerForGlyphAtIndex (uint glyphIndex, NSRangePointer effectiveGlyphRange, bool flag);

//#endif 
		//    - (NSRect)extraLineFragmentRect;
		[Export ("extraLineFragmentRect")]
		RectangleF ExtraLineFragmentRect { get; }

		//- (NSRect)extraLineFragmentUsedRect;
		[Export ("extraLineFragmentUsedRect")]
		RectangleF ExtraLineFragmentUsedRect { get; }

		//- (NSTextContainer *)extraLineFragmentTextContainer;
		[Export ("extraLineFragmentTextContainer")]
		NSTextContainer ExtraLineFragmentTextContainer { get; }

		//    - (NSPoint)locationForGlyphAtIndex:(NSUInteger)glyphIndex;
		[Export ("locationForGlyphAtIndex:")]
		PointF LocationForGlyphAtIndex (uint glyphIndex);

		//    - (BOOL)notShownAttributeForGlyphAtIndex:(NSUInteger)glyphIndex;
		[Export ("notShownAttributeForGlyphAtIndex:")]
		bool NotShownAttributeForGlyphAtIndex (uint glyphIndex);

		//    - (BOOL)drawsOutsideLineFragmentForGlyphAtIndex:(NSUInteger)glyphIndex;
		[Export ("drawsOutsideLineFragmentForGlyphAtIndex:")]
		bool DrawsOutsideLineFragmentForGlyphAtIndex (uint glyphIndex);

		//    - (NSSize)attachmentSizeForGlyphAtIndex:(NSUInteger)glyphIndex;
		[Export ("attachmentSizeForGlyphAtIndex:")]
		NSSize AttachmentSizeForGlyphAtIndex (uint glyphIndex);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//    - (void)setLayoutRect:(NSRect)rect forTextBlock:(NSTextBlock *)block glyphRange:(NSRange)glyphRange;
		[Export ("setLayoutRect:forTextBlock:glyphRange:")]
		void SetLayoutRect (RectangleF rect, NSTextBlock block, NSRange glyphRange);

		//- (void)setBoundsRect:(NSRect)rect forTextBlock:(NSTextBlock *)block glyphRange:(NSRange)glyphRange;
		[Export ("setBoundsRect:forTextBlock:glyphRange:")]
		void SetBoundsRect (RectangleF rect, NSTextBlock block, NSRange glyphRange);

		//- (NSRect)layoutRectForTextBlock:(NSTextBlock *)block glyphRange:(NSRange)glyphRange;
		[Export ("layoutRectForTextBlock:glyphRange:")]
		RectangleF LayoutRectForTextBlock (NSTextBlock block, NSRange glyphRange);

		//- (NSRect)boundsRectForTextBlock:(NSTextBlock *)block glyphRange:(NSRange)glyphRange;
		[Export ("boundsRectForTextBlock:glyphRange:")]
		RectangleF BoundsRectForTextBlock (NSTextBlock block, NSRange glyphRange);

		//    - (NSRect)layoutRectForTextBlock:(NSTextBlock *)block atIndex:(NSUInteger)glyphIndex effectiveRange:(NSRangePointer)effectiveGlyphRange;
		[Export ("layoutRectForTextBlock:atIndex:effectiveRange:")]
		RectangleF LayoutRectForTextBlock (NSTextBlock block, uint glyphIndex, NSRangePointer effectiveGlyphRange);

		//- (NSRect)boundsRectForTextBlock:(NSTextBlock *)block atIndex:(NSUInteger)glyphIndex effectiveRange:(NSRangePointer)effectiveGlyphRange;
		[Export ("boundsRectForTextBlock:atIndex:effectiveRange:")]
		RectangleF BoundsRectForTextBlock (NSTextBlock block, uint glyphIndex, NSRangePointer effectiveGlyphRange);

//#endif 
		//    - (NSRange)glyphRangeForCharacterRange:(NSRange)charRange actualCharacterRange:(NSRangePointer)actualCharRange;
		[Export ("glyphRangeForCharacterRange:actualCharacterRange:")]
		NSRange GlyphRangeForCharacterRange (NSRange charRange, NSRangePointer actualCharRange);

		//    - (NSRange)characterRangeForGlyphRange:(NSRange)glyphRange actualGlyphRange:(NSRangePointer)actualGlyphRange;
		[Export ("characterRangeForGlyphRange:actualGlyphRange:")]
		NSRange CharacterRangeForGlyphRange (NSRange glyphRange, NSRangePointer actualGlyphRange);

		//    - (NSRange)glyphRangeForTextContainer:(NSTextContainer *)container;
		[Export ("glyphRangeForTextContainer:")]
		NSRange GlyphRangeForTextContainer (NSTextContainer container);

		//    - (NSRange)rangeOfNominallySpacedGlyphsContainingIndex:(NSUInteger)glyphIndex;
		[Export ("rangeOfNominallySpacedGlyphsContainingIndex:")]
		NSRange RangeOfNominallySpacedGlyphsContainingIndex (uint glyphIndex);

		//        - (NSRectArray)rectArrayForCharacterRange:(NSRange)charRange withinSelectedCharacterRange:(NSRange)selCharRange inTextContainer:(NSTextContainer *)container rectCount:(NSUInteger *)rectCount;
		[Export ("rectArrayForCharacterRange:withinSelectedCharacterRange:inTextContainer:rectCount:")]
		NSRectArray RectArrayForCharacterRange (NSRange charRange, NSRange selCharRange, NSTextContainer container, uint rectCount);

		//- (NSRectArray)rectArrayForGlyphRange:(NSRange)glyphRange withinSelectedGlyphRange:(NSRange)selGlyphRange inTextContainer:(NSTextContainer *)container rectCount:(NSUInteger *)rectCount;
		[Export ("rectArrayForGlyphRange:withinSelectedGlyphRange:inTextContainer:rectCount:")]
		NSRectArray RectArrayForGlyphRange (NSRange glyphRange, NSRange selGlyphRange, NSTextContainer container, uint rectCount);

		//        - (NSRect)boundingRectForGlyphRange:(NSRange)glyphRange inTextContainer:(NSTextContainer *)container;
		[Export ("boundingRectForGlyphRange:inTextContainer:")]
		RectangleF BoundingRectForGlyphRange (NSRange glyphRange, NSTextContainer container);

		//    - (NSRange)glyphRangeForBoundingRect:(NSRect)bounds inTextContainer:(NSTextContainer *)container;
		[Export ("glyphRangeForBoundingRect:inTextContainer:")]
		NSRange GlyphRangeForBoundingRect (RectangleF bounds, NSTextContainer container);

		//- (NSRange)glyphRangeForBoundingRectWithoutAdditionalLayout:(NSRect)bounds inTextContainer:(NSTextContainer *)container;
		[Export ("glyphRangeForBoundingRectWithoutAdditionalLayout:inTextContainer:")]
		NSRange GlyphRangeForBoundingRectWithoutAdditionalLayout (RectangleF bounds, NSTextContainer container);

		//    - (NSUInteger)glyphIndexForPoint:(NSPoint)point inTextContainer:(NSTextContainer *)container fractionOfDistanceThroughGlyph:(CGFloat *)partialFraction;
		[Export ("glyphIndexForPoint:inTextContainer:fractionOfDistanceThroughGlyph:")]
		uint GlyphIndexForPoint (PointF point, NSTextContainer container, float partialFraction);

		//- (NSUInteger)glyphIndexForPoint:(NSPoint)point inTextContainer:(NSTextContainer *)container;
		[Export ("glyphIndexForPoint:inTextContainer:")]
		uint GlyphIndexForPoint (PointF point, NSTextContainer container);

		//- (CGFloat)fractionOfDistanceThroughGlyphForPoint:(NSPoint)point inTextContainer:(NSTextContainer *)container;
		[Export ("fractionOfDistanceThroughGlyphForPoint:inTextContainer:")]
		float FractionOfDistanceThroughGlyphForPoint (PointF point, NSTextContainer container);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//        - (NSUInteger)getLineFragmentInsertionPointsForCharacterAtIndex:(NSUInteger)charIndex alternatePositions:(BOOL)aFlag inDisplayOrder:(BOOL)dFlag positions:(CGFloat *)positions characterIndexes:(NSUInteger *)charIndexes;
		[Export ("getLineFragmentInsertionPointsForCharacterAtIndex:alternatePositions:inDisplayOrder:positions:characterIndexes:")]
		uint GetLineFragmentInsertionPointsForCharacterAtIndex (uint charIndex, bool aFlag, bool dFlag, float positions, uint charIndexes);

//#endif 
		//    - (NSDictionary *)temporaryAttributesAtCharacterIndex:(NSUInteger)charIndex effectiveRange:(NSRangePointer)effectiveCharRange;
		[Export ("temporaryAttributesAtCharacterIndex:effectiveRange:")]
		NSDictionary TemporaryAttributesAtCharacterIndex (uint charIndex, NSRangePointer effectiveCharRange);

		//- (void)setTemporaryAttributes:(NSDictionary *)attrs forCharacterRange:(NSRange)charRange;
		[Export ("setTemporaryAttributes:forCharacterRange:")]
		void SetTemporaryAttributes (NSDictionary attrs, NSRange charRange);

		//- (void)addTemporaryAttributes:(NSDictionary *)attrs forCharacterRange:(NSRange)charRange;
		[Export ("addTemporaryAttributes:forCharacterRange:")]
		void AddTemporaryAttributes (NSDictionary attrs, NSRange charRange);

		//- (void)removeTemporaryAttribute:(NSString *)attrName forCharacterRange:(NSRange)charRange;
		[Export ("removeTemporaryAttribute:forCharacterRange:")]
		void RemoveTemporaryAttribute (string attrName, NSRange charRange);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//    - (id)temporaryAttribute:(NSString *)attrName atCharacterIndex:(NSUInteger)location effectiveRange:(NSRangePointer)range;
		[Export ("temporaryAttribute:atCharacterIndex:effectiveRange:")]
		NSLayoutManager TemporaryAttribute (string attrName, uint location, NSRangePointer range);

		//- (id)temporaryAttribute:(NSString *)attrName atCharacterIndex:(NSUInteger)location longestEffectiveRange:(NSRangePointer)range inRange:(NSRange)rangeLimit;
		[Export ("temporaryAttribute:atCharacterIndex:longestEffectiveRange:inRange:")]
		NSLayoutManager TemporaryAttribute (string attrName, uint location, NSRangePointer range, NSRange rangeLimit);

		//- (NSDictionary *)temporaryAttributesAtCharacterIndex:(NSUInteger)location longestEffectiveRange:(NSRangePointer)range inRange:(NSRange)rangeLimit;
		[Export ("temporaryAttributesAtCharacterIndex:longestEffectiveRange:inRange:")]
		NSDictionary TemporaryAttributesAtCharacterIndex (uint location, NSRangePointer range, NSRange rangeLimit);

		//- (void)addTemporaryAttribute:(NSString *)attrName value:(id)value forCharacterRange:(NSRange)charRange;
		[Export ("addTemporaryAttribute:value:forCharacterRange:")]
		void AddTemporaryAttribute (string attrName, NSObject value, NSRange charRange);

//#endif 
		//    - (NSFont *)substituteFontForFont:(NSFont *)originalFont;
		[Export ("substituteFontForFont:")]
		NSFont SubstituteFontForFont (NSFont originalFont);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_2
		//    - (CGFloat)defaultLineHeightForFont:(NSFont *)theFont;
		[Export ("defaultLineHeightForFont:")]
		float DefaultLineHeightForFont (NSFont theFont);

		//    - (CGFloat)defaultBaselineOffsetForFont:(NSFont *)theFont;
		[Export ("defaultBaselineOffsetForFont:")]
		float DefaultBaselineOffsetForFont (NSFont theFont);

		//    - (BOOL)usesFontLeading;
		[Export ("usesFontLeading")]
		bool UsesFontLeading { get; set; }

//#endif 
		//- (NSArray *)rulerMarkersForTextView:(NSTextView *)view paragraphStyle:(NSParagraphStyle *)style ruler:(NSRulerView *)ruler;
		[Export ("rulerMarkersForTextView:paragraphStyle:ruler:")]
		NSArray RulerMarkersForTextViewParagraphStyle (NSTextView view, NSParagraphStyle style, NSRulerView ruler);

		//- (NSView *)rulerAccessoryViewForTextView:(NSTextView *)view paragraphStyle:(NSParagraphStyle *)style ruler:(NSRulerView *)ruler enabled:(BOOL)isEnabled;
		[Export ("rulerAccessoryViewForTextView:paragraphStyle:ruler:enabled:")]
		NSView RulerAccessoryViewForTextViewParagraphStyle (NSTextView view, NSParagraphStyle style, NSRulerView ruler, bool isEnabled);

		//    - (BOOL)layoutManagerOwnsFirstResponderInWindow:(NSWindow *)window;
		[Export ("layoutManagerOwnsFirstResponderInWindow:")]
		bool LayoutManagerOwnsFirstResponderInWindow (NSWindow window);

		//    - (NSTextView *)firstTextView;
		[Export ("firstTextView")]
		NSTextView FirstTextView { get; }

		//- (NSTextView *)textViewForBeginningOfSelection;
		[Export ("textViewForBeginningOfSelection")]
		NSTextView TextViewForBeginningOfSelection { get; }

		//    - (void)drawBackgroundForGlyphRange:(NSRange)glyphsToShow atPoint:(NSPoint)origin;
		[Export ("drawBackgroundForGlyphRange:atPoint:")]
		void DrawBackgroundForGlyphRangeAtPoint (NSRange glyphsToShow, PointF origin);

		//- (void)drawGlyphsForGlyphRange:(NSRange)glyphsToShow atPoint:(NSPoint)origin;
		[Export ("drawGlyphsForGlyphRange:atPoint:")]
		void DrawGlyphsForGlyphRangeAtPoint (NSRange glyphsToShow, PointF origin);

		//    - (void)showPackedGlyphs:(char *)glyphs length:(NSUInteger)glyphLen glyphRange:(NSRange)glyphRange atPoint:(NSPoint)point font:(NSFont *)font color:(NSColor *)color printingAdjustment:(NSSize)printingAdjustment;
		[Export ("showPackedGlyphs:length:glyphRange:atPoint:font:color:printingAdjustment:")]
		void ShowPackedGlyphsLength (char glyphs, uint glyphLen, NSRange glyphRange, PointF point, NSFont font, NSColor color, NSSize printingAdjustment);

		//    - (void)showAttachmentCell:(NSCell *)cell inRect:(NSRect)rect characterIndex:(NSUInteger)attachmentIndex;
		[Export ("showAttachmentCell:inRect:characterIndex:")]
		void ShowAttachmentCellInRect (NSCell cell, RectangleF rect, uint attachmentIndex);

		//   - (void)drawUnderlineForGlyphRange:(NSRange)glyphRange underlineType:(NSInteger)underlineVal baselineOffset:(CGFloat)baselineOffset lineFragmentRect:(NSRect)lineRect lineFragmentGlyphRange:(NSRange)lineGlyphRange containerOrigin:(NSPoint)containerOrigin;
		[Export ("drawUnderlineForGlyphRange:underlineType:baselineOffset:lineFragmentRect:lineFragmentGlyphRange:containerOrigin:")]
		void DrawUnderlineForGlyphRangeUnderlineType (NSRange glyphRange, int underlineVal, float baselineOffset, RectangleF lineRect, NSRange lineGlyphRange, PointF containerOrigin);

		//- (void)underlineGlyphRange:(NSRange)glyphRange underlineType:(NSInteger)underlineVal lineFragmentRect:(NSRect)lineRect lineFragmentGlyphRange:(NSRange)lineGlyphRange containerOrigin:(NSPoint)containerOrigin;
		[Export ("underlineGlyphRange:underlineType:lineFragmentRect:lineFragmentGlyphRange:containerOrigin:")]
		void UnderlineGlyphRangeUnderlineType (NSRange glyphRange, int underlineVal, RectangleF lineRect, NSRange lineGlyphRange, PointF containerOrigin);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//    - (void)drawStrikethroughForGlyphRange:(NSRange)glyphRange strikethroughType:(NSInteger)strikethroughVal baselineOffset:(CGFloat)baselineOffset lineFragmentRect:(NSRect)lineRect lineFragmentGlyphRange:(NSRange)lineGlyphRange containerOrigin:(NSPoint)containerOrigin;
		[Export ("drawStrikethroughForGlyphRange:strikethroughType:baselineOffset:lineFragmentRect:lineFragmentGlyphRange:containerOrigin:")]
		void DrawStrikethroughForGlyphRangeStrikethroughType (NSRange glyphRange, int strikethroughVal, float baselineOffset, RectangleF lineRect, NSRange lineGlyphRange, PointF containerOrigin);

		//- (void)strikethroughGlyphRange:(NSRange)glyphRange strikethroughType:(NSInteger)strikethroughVal lineFragmentRect:(NSRect)lineRect lineFragmentGlyphRange:(NSRange)lineGlyphRange containerOrigin:(NSPoint)containerOrigin;
		[Export ("strikethroughGlyphRange:strikethroughType:lineFragmentRect:lineFragmentGlyphRange:containerOrigin:")]
		void StrikethroughGlyphRangeStrikethroughType (NSRange glyphRange, int strikethroughVal, RectangleF lineRect, NSRange lineGlyphRange, PointF containerOrigin);

//#endif 
	}
}
