using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSRuleEditor))]
	interface NSPredicateEditor {

		//- (NSArray *)rowTemplates;
		[Export ("rowTemplates")]
		NSArray RowTemplates { get; set; }

	}
}
