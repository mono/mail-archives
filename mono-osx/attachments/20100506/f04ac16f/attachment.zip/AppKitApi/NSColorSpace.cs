using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSObject))]
	interface NSColorSpace {

//#if __LP64__
//#endif
		//- (id)initWithICCProfileData:(NSData *)iccData;
		[Export ("initWithICCProfileData:")]
		IntPtr Constructor (NSData iccData);

		//- (NSData *)ICCProfileData;
		[Export ("ICCProfileData")]
		NSData ICCProfileData { get; }

		//- (id)initWithColorSyncProfile:(void * )prof;
		[Export ("initWithColorSyncProfile:")]
		IntPtr Constructor (IntPtr prof);

		//- (void * )colorSyncProfile;
		[Export ("colorSyncProfile")]
		void ColorSyncProfile ();

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (id)initWithCGColorSpace:(CGColorSpaceRef)cgColorSpace;
		[Export ("initWithCGColorSpace:")]
		IntPtr Constructor (CGColorSpaceRef cgColorSpace);

		//- (CGColorSpaceRef)CGColorSpace;
		[Export ("CGColorSpace")]
		CGColorSpaceRef CGColorSpace { get; }

//#endif
		//- (NSInteger)numberOfColorComponents;		
		[Export ("numberOfColorComponents")]
		int NumberOfColorComponents { get; }

		//- (NSColorSpaceModel)colorSpaceModel;
		[Export ("colorSpaceModel")]
		NSColorSpaceModel ColorSpaceModel { get; }

		//- (NSString *)localizedName;			
		[Export ("localizedName")]
		string LocalizedName { get; }

		//+ (NSColorSpace *)genericRGBColorSpace;		
		[Static, Export ("genericRGBColorSpace")]
		NSColorSpace GenericRGBColorSpace { get; }

		//+ (NSColorSpace *)genericGrayColorSpace;	
		[Static, Export ("genericGrayColorSpace")]
		NSColorSpace GenericGrayColorSpace { get; }

		//+ (NSColorSpace *)genericCMYKColorSpace;
		[Static, Export ("genericCMYKColorSpace")]
		NSColorSpace GenericCMYKColorSpace { get; }

		//+ (NSColorSpace *)deviceRGBColorSpace;		
		[Static, Export ("deviceRGBColorSpace")]
		NSColorSpace DeviceRGBColorSpace { get; }

		//+ (NSColorSpace *)deviceGrayColorSpace;		
		[Static, Export ("deviceGrayColorSpace")]
		NSColorSpace DeviceGrayColorSpace { get; }

		//+ (NSColorSpace *)deviceCMYKColorSpace;		
		[Static, Export ("deviceCMYKColorSpace")]
		NSColorSpace DeviceCMYKColorSpace { get; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//+ (NSColorSpace *)sRGBColorSpace;
		[Static, Export ("sRGBColorSpace")]
		NSColorSpace SRGBColorSpace { get; }

		//+ (NSColorSpace *)adobeRGB1998ColorSpace;
		[Static, Export ("adobeRGB1998ColorSpace")]
		NSColorSpace AdobeRGB1998ColorSpace { get; }

//#endif
	}
}
