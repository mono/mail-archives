using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSImageRep))]
	interface NSCIImageRep {

		//+ (id)imageRepWithCIImage:(CIImage *)image;
		[Static, Export ("imageRepWithCIImage:")]
		NSCIImageRep ImageRepWithCIImage (CIImage image);

		//- (id)initWithCIImage:(CIImage *)image;
		[Export ("initWithCIImage:")]
		IntPtr Constructor (CIImage image);

		//- (CIImage *)CIImage;
		[Export ("CIImage")]
		CIImage CIImage { get; }

	}
}
