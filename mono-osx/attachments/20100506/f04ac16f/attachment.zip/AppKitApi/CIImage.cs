using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{
	interface CIImage {

		//- (void)drawInRect:(NSRect)rect fromRect:(NSRect)fromRect operation:(NSCompositingOperation)op fraction:(CGFloat)delta;
		[Export ("drawInRect:fromRect:operation:fraction:")]
		void DrawInRectFromRect (RectangleF rect, RectangleF fromRect, NSCompositingOperation op, float delta);

		//- (void)drawAtPoint:(NSPoint)point fromRect:(NSRect)fromRect operation:(NSCompositingOperation)op fraction:(CGFloat)delta;
		[Export ("drawAtPoint:fromRect:operation:fraction:")]
		void DrawAtPointFromRect (PointF point, RectangleF fromRect, NSCompositingOperation op, float delta);

	}
}
