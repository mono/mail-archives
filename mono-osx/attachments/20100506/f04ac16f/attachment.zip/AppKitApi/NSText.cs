using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSView))]
	interface NSText {

		//- (NSString *)string;
		[Export ("string")]
		string String { get; set; }

		//- (void)replaceCharactersInRange:(NSRange)range withString:(NSString *)aString;
		[Export ("replaceCharactersInRange:withString:")]
		void ReplaceCharactersInRange (NSRange range, string aString);

		//- (void)replaceCharactersInRange:(NSRange)range withRTF:(NSData *)rtfData;
		[Export ("replaceCharactersInRange:withRTF:")]
		void ReplaceCharactersInRange (NSRange range, NSData rtfData);

		//- (void)replaceCharactersInRange:(NSRange)range withRTFD:(NSData *)rtfdData;
		[Export ("replaceCharactersInRange:withRTFD:")]
		void ReplaceCharactersInRangeWithRTFD (NSRange range, NSData rtfdData);

		//- (NSData *)RTFFromRange:(NSRange)range;
		[Export ("RTFFromRange:")]
		NSData RTFFromRange (NSRange range);

		//- (NSData *)RTFDFromRange:(NSRange)range;
		[Export ("RTFDFromRange:")]
		NSData RTFDFromRange (NSRange range);

		//- (BOOL)writeRTFDToFile:(NSString *)path atomically:(BOOL)flag;
		[Export ("writeRTFDToFile:atomically:")]
		bool WriteRTFDToFile (string path, bool flag);

		//- (BOOL)readRTFDFromFile:(NSString *)path;
		[Export ("readRTFDFromFile:")]
		bool ReadRTFDFromFile (string path);

		//- (id)delegate;
		[Export ("delegate")]
		NSText Delegate { get; }

		//- (void)setDelegate:(id)anObject;
		[Export ("setDelegate:")]
		void SetDelegate (NSObject anObject);

		//- (BOOL)isEditable;
		[Export ("isEditable")]
		bool IsEditable { get; }

		//- (void)setEditable:(BOOL)flag;
		[Export ("setEditable:")]
		void SetEditable (bool flag);

		//- (BOOL)isSelectable;
		[Export ("isSelectable")]
		bool IsSelectable { get; }

		//- (void)setSelectable:(BOOL)flag;
		[Export ("setSelectable:")]
		void SetSelectable (bool flag);

		//- (BOOL)isRichText;
		[Export ("isRichText")]
		bool IsRichText { get; }

		//- (void)setRichText:(BOOL)flag;         
		[Export ("setRichText:")]
		void SetRichText (bool flag);

		//- (BOOL)importsGraphics;
		[Export ("importsGraphics")]
		bool ImportsGraphics { get; set; }

		//- (BOOL)isFieldEditor;
		[Export ("isFieldEditor")]
		bool IsFieldEditor { get; }

		//- (void)setFieldEditor:(BOOL)flag;      
		[Export ("setFieldEditor:")]
		void SetFieldEditor (bool flag);

		//- (BOOL)usesFontPanel;
		[Export ("usesFontPanel")]
		bool UsesFontPanel { get; set; }

		//- (BOOL)drawsBackground;
		[Export ("drawsBackground")]
		bool DrawsBackground { get; set; }

		//- (NSColor *)backgroundColor;
		[Export ("backgroundColor")]
		NSColor BackgroundColor { get; set; }

		//- (BOOL)isRulerVisible;
		[Export ("isRulerVisible")]
		bool IsRulerVisible { get; }

		//- (NSRange)selectedRange;
		[Export ("selectedRange")]
		NSRange SelectedRange { get; set; }

		//- (void)scrollRangeToVisible:(NSRange)range;
		[Export ("scrollRangeToVisible:")]
		void ScrollRangeToVisible (NSRange range);

		//- (NSFont *)font;
		[Export ("font")]
		NSFont Font { get; set; }

		//- (NSColor *)textColor;
		[Export ("textColor")]
		NSColor TextColor { get; set; }

		//- (NSTextAlignment)alignment;
		[Export ("alignment")]
		NSTextAlignment Alignment { get; set; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (NSWritingDirection)baseWritingDirection;
		[Export ("baseWritingDirection")]
		NSWritingDirection BaseWritingDirection { get; set; }

//#endif 
		//- (void)setTextColor:(NSColor *)color range:(NSRange)range;
		[Export ("setTextColor:range:")]
		void SetTextColor (NSColor color, NSRange range);

		//- (void)setFont:(NSFont *)font range:(NSRange)range;
		[Export ("setFont:range:")]
		void SetFont (NSFont font, NSRange range);

		//- (NSSize)maxSize;
		[Export ("maxSize")]
		NSSize MaxSize { get; set; }

		//- (NSSize)minSize;
		[Export ("minSize")]
		NSSize MinSize { get; set; }

		//- (BOOL)isHorizontallyResizable;
		[Export ("isHorizontallyResizable")]
		bool IsHorizontallyResizable { get; }

		//- (void)setHorizontallyResizable:(BOOL)flag;
		[Export ("setHorizontallyResizable:")]
		void SetHorizontallyResizable (bool flag);

		//- (BOOL)isVerticallyResizable;
		[Export ("isVerticallyResizable")]
		bool IsVerticallyResizable { get; }

		//- (void)setVerticallyResizable:(BOOL)flag;
		[Export ("setVerticallyResizable:")]
		void SetVerticallyResizable (bool flag);

		//- (void)sizeToFit;
		[Export ("sizeToFit")]
		void SizeToFit ();

		//- (void)copy:(id)sender;
		[Export ("copy:")]
		void Copy (NSObject sender);

		//- (void)copyFont:(id)sender;
		[Export ("copyFont:")]
		void CopyFont (NSObject sender);

		//- (void)copyRuler:(id)sender;
		[Export ("copyRuler:")]
		void CopyRuler (NSObject sender);

		//- (void)cut:(id)sender;
		[Export ("cut:")]
		void Cut (NSObject sender);

		//- (void)delete:(id)sender;
		[Export ("delete:")]
		void Delete (NSObject sender);

		//- (void)paste:(id)sender;
		[Export ("paste:")]
		void Paste (NSObject sender);

		//- (void)pasteFont:(id)sender;
		[Export ("pasteFont:")]
		void PasteFont (NSObject sender);

		//- (void)pasteRuler:(id)sender;
		[Export ("pasteRuler:")]
		void PasteRuler (NSObject sender);

		//- (void)selectAll:(id)sender;
		[Export ("selectAll:")]
		void SelectAll (NSObject sender);

		//- (void)changeFont:(id)sender;
		[Export ("changeFont:")]
		void ChangeFont (NSObject sender);

		//- (void)alignLeft:(id)sender;
		[Export ("alignLeft:")]
		void AlignLeft (NSObject sender);

		//- (void)alignRight:(id)sender;
		[Export ("alignRight:")]
		void AlignRight (NSObject sender);

		//- (void)alignCenter:(id)sender;
		[Export ("alignCenter:")]
		void AlignCenter (NSObject sender);

		//- (void)subscript:(id)sender;
		[Export ("subscript:")]
		void Subscript (NSObject sender);

		//- (void)superscript:(id)sender;
		[Export ("superscript:")]
		void Superscript (NSObject sender);

		//- (void)underline:(id)sender;
		[Export ("underline:")]
		void Underline (NSObject sender);

		//- (void)unscript:(id)sender;
		[Export ("unscript:")]
		void Unscript (NSObject sender);

		//- (void)showGuessPanel:(id)sender;
		[Export ("showGuessPanel:")]
		void ShowGuessPanel (NSObject sender);

		//- (void)checkSpelling:(id)sender;
		[Export ("checkSpelling:")]
		void CheckSpelling (NSObject sender);

		//- (void)toggleRuler:(id)sender;
		[Export ("toggleRuler:")]
		void ToggleRuler (NSObject sender);

	}
}
