using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSObject))]
	interface NSNib {

		//- (id)initWithContentsOfURL:(NSURL *)nibFileURL;
		[Export ("initWithContentsOfURL:")]
		IntPtr Constructor (NSUrl nibFileURL);

		//- (id)initWithNibNamed:(NSString *)nibName bundle:(NSBundle *)bundle;
		[Export ("initWithNibNamed:bundle:")]
		IntPtr Constructor (string nibName, NSBundle bundle);

		//- (BOOL)instantiateNibWithExternalNameTable:(NSDictionary *)externalNameTable;
		[Export ("instantiateNibWithExternalNameTable:")]
		bool InstantiateNibWithExternalNameTable (NSDictionary externalNameTable);

		//- (BOOL)instantiateNibWithOwner:(id)owner topLevelObjects:(NSArray **)topLevelObjects;
		[Export ("instantiateNibWithOwner:topLevelObjects:")]
		bool InstantiateNibWithOwner (NSObject owner, NSArray topLevelObjects);

	}
}
