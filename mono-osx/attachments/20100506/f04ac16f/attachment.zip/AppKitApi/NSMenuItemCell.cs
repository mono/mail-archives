using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSButtonCell))]
	interface NSMenuItemCell {

		//- (NSMenuItem *)menuItem;
		[Export ("menuItem")]
		NSMenuItem MenuItem { get; set; }

//#if ! __LP64__
		//- (NSMenuView *)menuView;
		[Export ("menuView")]
		NSMenuView MenuView { get; set; }

//#endif
		//- (BOOL)needsSizing;
		[Export ("needsSizing")]
		bool NeedsSizing { get; set; }

		//- (void)calcSize;
		[Export ("calcSize")]
		void CalcSize ();

		//- (BOOL)needsDisplay;
		[Export ("needsDisplay")]
		bool NeedsDisplay { get; set; }

		//- (CGFloat)stateImageWidth;
		[Export ("stateImageWidth")]
		float StateImageWidth { get; }

		//- (CGFloat)imageWidth;
		[Export ("imageWidth")]
		float ImageWidth { get; }

		//- (CGFloat)titleWidth;
		[Export ("titleWidth")]
		float TitleWidth { get; }

		//- (CGFloat)keyEquivalentWidth;
		[Export ("keyEquivalentWidth")]
		float KeyEquivalentWidth { get; }

		//- (NSRect)stateImageRectForBounds:(NSRect)cellFrame;
		[Export ("stateImageRectForBounds:")]
		RectangleF StateImageRectForBounds (RectangleF cellFrame);

		//- (NSRect)titleRectForBounds:(NSRect)cellFrame;
		[Export ("titleRectForBounds:")]
		RectangleF TitleRectForBounds (RectangleF cellFrame);

		//- (NSRect)keyEquivalentRectForBounds:(NSRect)cellFrame;
		[Export ("keyEquivalentRectForBounds:")]
		RectangleF KeyEquivalentRectForBounds (RectangleF cellFrame);

		//- (void)drawSeparatorItemWithFrame:(NSRect)cellFrame inView:(NSView *)controlView;
		[Export ("drawSeparatorItemWithFrame:inView:")]
		void DrawSeparatorItemWithFrame (RectangleF cellFrame, NSView controlView);

		//- (void)drawStateImageWithFrame:(NSRect)cellFrame inView:(NSView *)controlView;
		[Export ("drawStateImageWithFrame:inView:")]
		void DrawStateImageWithFrame (RectangleF cellFrame, NSView controlView);

		//- (void)drawImageWithFrame:(NSRect)cellFrame inView:(NSView *)controlView;
		[Export ("drawImageWithFrame:inView:")]
		void DrawImageWithFrame (RectangleF cellFrame, NSView controlView);

		//- (void)drawTitleWithFrame:(NSRect)cellFrame inView:(NSView *)controlView;
		[Export ("drawTitleWithFrame:inView:")]
		void DrawTitleWithFrame (RectangleF cellFrame, NSView controlView);

		//- (void)drawKeyEquivalentWithFrame:(NSRect)cellFrame inView:(NSView *)controlView;
		[Export ("drawKeyEquivalentWithFrame:inView:")]
		void DrawKeyEquivalentWithFrame (RectangleF cellFrame, NSView controlView);

		//- (void)drawBorderAndBackgroundWithFrame:(NSRect)cellFrame inView:(NSView *)controlView;
		[Export ("drawBorderAndBackgroundWithFrame:inView:")]
		void DrawBorderAndBackgroundWithFrame (RectangleF cellFrame, NSView controlView);

		//- (NSInteger)tag;
		[Export ("tag")]
		int Tag { get; }

	}
}
