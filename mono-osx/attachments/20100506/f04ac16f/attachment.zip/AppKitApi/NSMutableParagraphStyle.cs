using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSParagraphStyle))]
	interface NSMutableParagraphStyle {

		//- (void)setLineSpacing:(CGFloat)aFloat;
		[Export ("setLineSpacing:")]
		void SetLineSpacing (float aFloat);

		//- (void)setParagraphSpacing:(CGFloat)aFloat;
		[Export ("setParagraphSpacing:")]
		void SetParagraphSpacing (float aFloat);

		//- (void)setAlignment:(NSTextAlignment)alignment;
		[Export ("setAlignment:")]
		void SetAlignment (NSTextAlignment alignment);

		//- (void)setFirstLineHeadIndent:(CGFloat)aFloat;
		[Export ("setFirstLineHeadIndent:")]
		void SetFirstLineHeadIndent (float aFloat);

		//- (void)setHeadIndent:(CGFloat)aFloat;
		[Export ("setHeadIndent:")]
		void SetHeadIndent (float aFloat);

		//- (void)setTailIndent:(CGFloat)aFloat;
		[Export ("setTailIndent:")]
		void SetTailIndent (float aFloat);

		//- (void)setLineBreakMode:(NSLineBreakMode)mode;
		[Export ("setLineBreakMode:")]
		void SetLineBreakMode (NSLineBreakMode mode);

		//- (void)setMinimumLineHeight:(CGFloat)aFloat;
		[Export ("setMinimumLineHeight:")]
		void SetMinimumLineHeight (float aFloat);

		//- (void)setMaximumLineHeight:(CGFloat)aFloat;
		[Export ("setMaximumLineHeight:")]
		void SetMaximumLineHeight (float aFloat);

		//- (void)addTabStop:(NSTextTab *)anObject;
		[Export ("addTabStop:")]
		void AddTabStop (NSTextTab anObject);

		//- (void)removeTabStop:(NSTextTab *)anObject;
		[Export ("removeTabStop:")]
		void RemoveTabStop (NSTextTab anObject);

		//- (void)setTabStops:(NSArray *)array;
		[Export ("setTabStops:")]
		void SetTabStops (NSArray array);

		//- (void)setParagraphStyle:(NSParagraphStyle *)obj;
		[Export ("setParagraphStyle:")]
		void SetParagraphStyle (NSParagraphStyle obj);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_2
		//- (void)setBaseWritingDirection:(NSWritingDirection)writingDirection;
		[Export ("setBaseWritingDirection:")]
		void SetBaseWritingDirection (NSWritingDirection writingDirection);

//#endif
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//- (void)setLineHeightMultiple:(CGFloat)aFloat;
		[Export ("setLineHeightMultiple:")]
		void SetLineHeightMultiple (float aFloat);

		//- (void)setParagraphSpacingBefore:(CGFloat)aFloat;
		[Export ("setParagraphSpacingBefore:")]
		void SetParagraphSpacingBefore (float aFloat);

		//- (void)setDefaultTabInterval:(CGFloat)aFloat;
		[Export ("setDefaultTabInterval:")]
		void SetDefaultTabInterval (float aFloat);

//#endif
//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (void)setTextBlocks:(NSArray *)array;
		[Export ("setTextBlocks:")]
		void SetTextBlocks (NSArray array);

		//- (void)setTextLists:(NSArray *)array;
		[Export ("setTextLists:")]
		void SetTextLists (NSArray array);

		//- (void)setHyphenationFactor:(float)aFactor;
		[Export ("setHyphenationFactor:")]
		void SetHyphenationFactor (float aFactor);

		//- (void)setTighteningFactorForTruncation:(float)aFactor;
		[Export ("setTighteningFactorForTruncation:")]
		void SetTighteningFactorForTruncation (float aFactor);

		//- (void)setHeaderLevel:(NSInteger)level;
		[Export ("setHeaderLevel:")]
		void SetHeaderLevel (int level);

//#endif
	}
}
