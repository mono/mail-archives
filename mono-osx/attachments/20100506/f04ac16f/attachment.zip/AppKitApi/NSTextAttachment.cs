using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSObject))]
	interface NSTextAttachment {

		//- (id)initWithFileWrapper:(NSFileWrapper *)fileWrapper;
		[Export ("initWithFileWrapper:")]
		IntPtr Constructor (NSFileWrapper fileWrapper);

		//- (NSFileWrapper *)fileWrapper;
		[Export ("fileWrapper")]
		NSFileWrapper FileWrapper { get; set; }

		//- (id <NSTextAttachmentCell>)attachmentCell;
		[Export ("attachmentCell")]
		NSTextAttachment AttachmentCell { get; }

		//- (void)setAttachmentCell:(id <NSTextAttachmentCell>)cell;
		[Export ("setAttachmentCell:")]
		void SetAttachmentCell (NSObject cell);

	}
}
