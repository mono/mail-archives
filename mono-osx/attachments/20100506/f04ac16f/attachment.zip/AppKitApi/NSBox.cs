using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSView))]
	interface NSBox {

		//- (NSBorderType)borderType;
		[Export ("borderType")]
		NSBorderType BorderType { get; set; }

		//- (NSTitlePosition)titlePosition;
		[Export ("titlePosition")]
		NSTitlePosition TitlePosition { get; set; }

		//- (NSBoxType)boxType;
		[Export ("boxType")]
		NSBoxType BoxType { get; set; }

		//- (NSString *)title;
		[Export ("title")]
		string Title { get; set; }

		//- (NSFont *)titleFont;
		[Export ("titleFont")]
		NSFont TitleFont { get; set; }

		//- (NSRect)borderRect;
		[Export ("borderRect")]
		RectangleF BorderRect { get; }

		//- (NSRect)titleRect;
		[Export ("titleRect")]
		RectangleF TitleRect { get; }

		//- (id)titleCell;
		[Export ("titleCell")]
		NSBox TitleCell { get; }

		//- (void)sizeToFit;
		[Export ("sizeToFit")]
		void SizeToFit ();

		//- (NSSize)contentViewMargins;
		[Export ("contentViewMargins")]
		NSSize ContentViewMargins { get; set; }

		//- (void)setFrameFromContentFrame:(NSRect)contentFrame;
		[Export ("setFrameFromContentFrame:")]
		void SetFrameFromContentFrame (RectangleF contentFrame);

		//- (id)contentView;
		[Export ("contentView")]
		NSBox ContentView { get; }

		//- (void)setContentView:(NSView *)aView;
		[Export ("setContentView:")]
		void SetContentView (NSView aView);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (BOOL)isTransparent;
		[Export ("isTransparent")]
		bool IsTransparent { get; }

		//- (void)setTransparent:(BOOL)flag;
		[Export ("setTransparent:")]
		void SetTransparent (bool flag);

//#endif
		//- (CGFloat)borderWidth;
		[Export ("borderWidth")]
		float BorderWidth { get; set; }

		//- (CGFloat)cornerRadius;
		[Export ("cornerRadius")]
		float CornerRadius { get; set; }

		//- (NSColor *)borderColor;
		[Export ("borderColor")]
		NSColor BorderColor { get; set; }

		//- (NSColor *)fillColor;
		[Export ("fillColor")]
		NSColor FillColor { get; set; }

	}
}
