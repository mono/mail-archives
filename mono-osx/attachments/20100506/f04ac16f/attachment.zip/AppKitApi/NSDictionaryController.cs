using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSArrayController))]
	interface NSDictionaryController {

		//- (id)newObject;    
		[Export ("newObject")]
		NSDictionaryController NewObject { get; }

		//- (NSString *)initialKey;
		[Export ("initialKey")]
		string InitialKey { get; set; }

		//- (void)setInitialValue:(id)value;
		[Export ("setInitialValue:")]
		void SetInitialValue (NSObject value);

		//- (id)initialValue;
		[Export ("initialValue")]
		IntPtr InitialValue { get; }

		//- (NSArray *)includedKeys;
		[Export ("includedKeys")]
		NSArray IncludedKeys { get; set; }

		//- (NSArray *)excludedKeys;
		[Export ("excludedKeys")]
		NSArray ExcludedKeys { get; set; }

		//- (NSDictionary *)localizedKeyDictionary;
		[Export ("localizedKeyDictionary")]
		NSDictionary LocalizedKeyDictionary { get; set; }

		//- (NSString *)localizedKeyTable;
		[Export ("localizedKeyTable")]
		string LocalizedKeyTable { get; set; }

	}
}
