using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSObject))]
	interface NSRulerMarker {

		//- (id)initWithRulerView:(NSRulerView *)ruler markerLocation:(CGFloat)location image:(NSImage *)image imageOrigin:(NSPoint)imageOrigin;
		[Export ("initWithRulerView:markerLocation:image:imageOrigin:")]
		IntPtr Constructor (NSRulerView ruler, float location, NSImage image, PointF imageOrigin);

		//    - (NSRulerView *)ruler;
		[Export ("ruler")]
		NSRulerView Ruler { get; }

		//- (CGFloat)markerLocation;
		[Export ("markerLocation")]
		float MarkerLocation { get; set; }

		//- (NSImage *)image;
		[Export ("image")]
		NSImage Image { get; set; }

		//- (NSPoint)imageOrigin;
		[Export ("imageOrigin")]
		PointF ImageOrigin { get; set; }

		//    - (void)setMovable:(BOOL)flag;
		[Export ("setMovable:")]
		void SetMovable (bool flag);

		//- (void)setRemovable:(BOOL)flag;
		[Export ("setRemovable:")]
		void SetRemovable (bool flag);

		//- (BOOL)isMovable;
		[Export ("isMovable")]
		bool IsMovable { get; }

		//- (BOOL)isRemovable;
		[Export ("isRemovable")]
		bool IsRemovable { get; }

		//    - (BOOL)isDragging;
		[Export ("isDragging")]
		bool IsDragging { get; }

		//    - (void)setRepresentedObject:(id <NSCopying>)representedObject;
		[Export ("setRepresentedObject:")]
		void SetRepresentedObject (NSObject representedObject);

		//- (id <NSCopying>)representedObject;
		[Export ("representedObject")]
		NSRulerMarker RepresentedObject { get; }

		//    - (NSRect)imageRectInRuler;
		[Export ("imageRectInRuler")]
		RectangleF ImageRectInRuler { get; }

		//    - (CGFloat)thicknessRequiredInRuler;
		[Export ("thicknessRequiredInRuler")]
		float ThicknessRequiredInRuler { get; }

		//    - (void)drawRect:(NSRect)rect;
		[Export ("drawRect:")]
		void DrawRect (RectangleF rect);

		//    - (BOOL)trackMouse:(NSEvent *)mouseDownEvent adding:(BOOL)isAdding;
		[Export ("trackMouse:adding:")]
		bool TrackMouse (NSEvent mouseDownEvent, bool isAdding);

	}
}
