using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSTypesetter))]
	interface NSSimpleHorizontalTypesetter {

		//+ (id)sharedInstance; 
		[Static, Export ("sharedInstance")]
		NSSimpleHorizontalTypesetter SharedInstance { get; }

		//- (NSLayoutManager *)currentLayoutManager;
		[Export ("currentLayoutManager")]
		NSLayoutManager CurrentLayoutManager { get; }

		//- (NSTextContainer *)currentContainer;
		[Export ("currentContainer")]
		NSTextContainer CurrentContainer { get; }

		//- (NSParagraphStyle *)currentParagraphStyle;
		[Export ("currentParagraphStyle")]
		NSParagraphStyle CurrentParagraphStyle { get; }

		//- (NSTextStorage *)currentTextStorage;
		[Export ("currentTextStorage")]
		NSTextStorage CurrentTextStorage { get; }

		//- (NSTypesetterGlyphInfo *)baseOfTypesetterGlyphInfo;
		[Export ("baseOfTypesetterGlyphInfo")]
		NSTypesetterGlyphInfo BaseOfTypesetterGlyphInfo { get; }

		//- (NSUInteger)sizeOfTypesetterGlyphInfo;
		[Export ("sizeOfTypesetterGlyphInfo")]
		uint SizeOfTypesetterGlyphInfo { get; }

		//- (NSUInteger)capacityOfTypesetterGlyphInfo;
		[Export ("capacityOfTypesetterGlyphInfo")]
		uint CapacityOfTypesetterGlyphInfo { get; }

		//- (NSUInteger)firstGlyphIndexOfCurrentLineFragment;
		[Export ("firstGlyphIndexOfCurrentLineFragment")]
		uint FirstGlyphIndexOfCurrentLineFragment { get; }

		//- (void)layoutGlyphsInLayoutManager:(NSLayoutManager *)layoutManager startingAtGlyphIndex:(NSUInteger)startGlyphIndex maxNumberOfLineFragments:(NSUInteger)maxNumLines nextGlyphIndex:(NSUInteger *)nextGlyph;
		[Export ("layoutGlyphsInLayoutManager:startingAtGlyphIndex:maxNumberOfLineFragments:nextGlyphIndex:")]
		void LayoutGlyphsInLayoutManager (NSLayoutManager layoutManager, uint startGlyphIndex, uint maxNumLines, uint nextGlyph);

		//- (NSLayoutStatus)layoutGlyphsInHorizontalLineFragment:(NSRect *)lineFragmentRect baseline:(float *)baseline;
		[Export ("layoutGlyphsInHorizontalLineFragment:baseline:")]
		NSLayoutStatus LayoutGlyphsInHorizontalLineFragment (RectangleF lineFragmentRect, float baseline);

		//- (void)clearGlyphCache;
		[Export ("clearGlyphCache")]
		void ClearGlyphCache ();

		//- (void)fillAttributesCache;
		[Export ("fillAttributesCache")]
		void FillAttributesCache ();

		//- (void)clearAttributesCache;
		[Export ("clearAttributesCache")]
		void ClearAttributesCache ();

		//- (NSUInteger)growGlyphCaches:(NSUInteger)desiredCapacity fillGlyphInfo:(BOOL)fillGlyphInfo;
		[Export ("growGlyphCaches:fillGlyphInfo:")]
		uint GrowGlyphCaches (uint desiredCapacity, bool fillGlyphInfo);

		//- (void)updateCurGlyphOffset;
		[Export ("updateCurGlyphOffset")]
		void UpdateCurGlyphOffset ();

		//- (void)insertGlyph:(NSGlyph)glyph atGlyphIndex:(NSUInteger)glyphIndex characterIndex:(NSUInteger)charIndex;
		[Export ("insertGlyph:atGlyphIndex:characterIndex:")]
		void InsertGlyph (uint glyph, uint glyphIndex, uint charIndex);

		//- (NSLayoutStatus)layoutControlGlyphForLineFragment:(NSRect)lineFrag;
		[Export ("layoutControlGlyphForLineFragment:")]
		NSLayoutStatus LayoutControlGlyphForLineFragment (RectangleF lineFrag);

		//- (void)layoutTab;
		[Export ("layoutTab")]
		void LayoutTab ();

		//- (void)breakLineAtIndex:(NSUInteger)location;
		[Export ("breakLineAtIndex:")]
		void BreakLineAtIndex (uint location);

		//- (NSUInteger)glyphIndexToBreakLineByHyphenatingWordAtIndex:(NSUInteger)charIndex;
		[Export ("glyphIndexToBreakLineByHyphenatingWordAtIndex:")]
		uint GlyphIndexToBreakLineByHyphenatingWordAtIndex (uint charIndex);

		//- (NSUInteger)glyphIndexToBreakLineByWordWrappingAtIndex:(NSUInteger)charIndex;
		[Export ("glyphIndexToBreakLineByWordWrappingAtIndex:")]
		uint GlyphIndexToBreakLineByWordWrappingAtIndex (uint charIndex);

		//- (void)fullJustifyLineAtGlyphIndex:(NSUInteger)glyphIndexForLineBreak;
		[Export ("fullJustifyLineAtGlyphIndex:")]
		void FullJustifyLineAtGlyphIndex (uint glyphIndexForLineBreak);

		//- (void)typesetterLaidOneGlyph:(NSTypesetterGlyphInfo *)gl;
		[Export ("typesetterLaidOneGlyph:")]
		void TypesetterLaidOneGlyph (NSTypesetterGlyphInfo gl);

		//- (void) willSetLineFragmentRect:(NSRect *)aRect forGlyphRange:(NSRange)aRange usedRect:(NSRect *)bRect;
		[Export ("willSetLineFragmentRect:forGlyphRange:usedRect:")]
		void WillSetLineFragmentRectForGlyphRange (RectangleF aRect, NSRange aRange, RectangleF bRect);

	}
}
