using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSObject))]
	interface NSOpenGLPixelBuffer {

		//- (id)initWithTextureTarget:(GLenum)target textureInternalFormat:(GLenum)format textureMaxMipMapLevel:(GLint)maxLevel pixelsWide:(GLsizei)pixelsWide pixelsHigh:(GLsizei)pixelsHigh;
		[Export ("initWithTextureTarget:textureInternalFormat:textureMaxMipMapLevel:pixelsWide:pixelsHigh:")]
		IntPtr Constructor (uint target, uint format, GLint maxLevel, GLsizei pixelsWide, GLsizei pixelsHigh);

		//- (GLsizei)pixelsWide;
		[Export ("pixelsWide")]
		GLsizei PixelsWide { get; }

		//- (GLsizei)pixelsHigh;
		[Export ("pixelsHigh")]
		GLsizei PixelsHigh { get; }

		//- (GLenum)textureTarget;
		[Export ("textureTarget")]
		uint TextureTarget { get; }

		//- (GLenum)textureInternalFormat;
		[Export ("textureInternalFormat")]
		uint TextureInternalFormat { get; }

		//- (GLint)textureMaxMipMapLevel;
		[Export ("textureMaxMipMapLevel")]
		GLint TextureMaxMipMapLevel { get; }

	}
}
