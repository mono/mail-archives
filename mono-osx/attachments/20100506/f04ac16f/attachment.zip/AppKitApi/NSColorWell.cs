using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSControl))]
	interface NSColorWell {

		//- (void)deactivate;
		[Export ("deactivate")]
		void Deactivate ();

		//- (void)activate:(BOOL)exclusive;
		[Export ("activate:")]
		void Activate (bool exclusive);

		//- (BOOL)isActive;
		[Export ("isActive")]
		bool IsActive { get; }

		//- (void)drawWellInside:(NSRect)insideRect;
		[Export ("drawWellInside:")]
		void DrawWellInside (RectangleF insideRect);

		//- (BOOL)isBordered;
		[Export ("isBordered")]
		bool IsBordered { get; }

		//- (void)setBordered:(BOOL)flag;
		[Export ("setBordered:")]
		void SetBordered (bool flag);

		//- (void)takeColorFrom:(id)sender;
		[Export ("takeColorFrom:")]
		void TakeColorFrom (NSObject sender);

		//- (NSColor *)color;
		[Export ("color")]
		NSColor Color { get; set; }

	}
}
