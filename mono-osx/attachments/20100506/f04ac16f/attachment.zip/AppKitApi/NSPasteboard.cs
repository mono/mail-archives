using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSObject))]
	interface NSPasteboard {

		//+ (NSPasteboard *)generalPasteboard;
		[Static, Export ("generalPasteboard")]
		NSPasteboard GeneralPasteboard { get; }

		//+ (NSPasteboard *)pasteboardWithName:(NSString *)name;
		[Static, Export ("pasteboardWithName:")]
		NSPasteboard PasteboardWithName (string name);

		//+ (NSPasteboard *)pasteboardWithUniqueName;
		[Static, Export ("pasteboardWithUniqueName")]
		NSPasteboard PasteboardWithUniqueName { get; }

		//+ (NSArray *)typesFilterableTo:(NSString *)type;
		[Static, Export ("typesFilterableTo:")]
		NSArray TypesFilterableTo (string type);

		//+ (NSPasteboard *)pasteboardByFilteringFile:(NSString *)filename;
		[Static, Export ("pasteboardByFilteringFile:")]
		NSPasteboard PasteboardByFilteringFile (string filename);

		//+ (NSPasteboard *)pasteboardByFilteringData:(NSData *)data ofType:(NSString *)type;
		[Static, Export ("pasteboardByFilteringData:ofType:")]
		NSPasteboard PasteboardByFilteringData (NSData data, string type);

		//+ (NSPasteboard *)pasteboardByFilteringTypesInPasteboard:(NSPasteboard *)pboard;
		[Static, Export ("pasteboardByFilteringTypesInPasteboard:")]
		NSPasteboard PasteboardByFilteringTypesInPasteboard (NSPasteboard pboard);

		//- (NSString *)name;
		[Export ("name")]
		string Name { get; }

		//- (void)releaseGlobally;
		[Export ("releaseGlobally")]
		void ReleaseGlobally ();

		//- (NSInteger)declareTypes:(NSArray *)newTypes owner:(id)newOwner;
		[Export ("declareTypes:owner:")]
		int DeclareTypes (NSArray newTypes, NSObject newOwner);

		//- (NSInteger)addTypes:(NSArray *)newTypes owner:(id)newOwner;
		[Export ("addTypes:owner:")]
		int AddTypes (NSArray newTypes, NSObject newOwner);

		//- (NSInteger)changeCount;
		[Export ("changeCount")]
		int ChangeCount { get; }

		//- (NSArray *)types;
		[Export ("types")]
		NSArray Types { get; }

		//- (NSString *)availableTypeFromArray:(NSArray *)types;
		[Export ("availableTypeFromArray:")]
		string AvailableTypeFromArray (NSArray types);

		//- (BOOL)setData:(NSData *)data forType:(NSString *)dataType;
		[Export ("setData:forType:")]
		bool SetData (NSData data, string dataType);

		//- (NSData *)dataForType:(NSString *)dataType;
		[Export ("dataForType:")]
		NSData DataForType (string dataType);

		//- (BOOL)setPropertyList:(id)plist forType:(NSString *)dataType;
		[Export ("setPropertyList:forType:")]
		bool SetPropertyList (NSObject plist, string dataType);

		//- (id)propertyListForType:(NSString *)dataType;
		[Export ("propertyListForType:")]
		NSPasteboard PropertyListForType (string dataType);

		//- (BOOL)setString:(NSString *)string forType:(NSString *)dataType;
		[Export ("setString:forType:")]
		bool SetString (string string1, string dataType);

		//- (NSString *)stringForType:(NSString *)dataType;
		[Export ("stringForType:")]
		string StringForType (string dataType);

		//- (NSString *)readFileContentsType:(NSString *)type toFile:(NSString *)filename;
		[Export ("readFileContentsType:toFile:")]
		string ReadFileContentsTypeToFile (string type, string filename);

		//- (BOOL)writeFileWrapper:(NSFileWrapper *)wrapper;
		[Export ("writeFileWrapper:")]
		bool WriteFileWrapper (NSFileWrapper wrapper);

		//- (NSFileWrapper *)readFileWrapper;
		[Export ("readFileWrapper")]
		NSFileWrapper ReadFileWrapper { get; }

	}
}
