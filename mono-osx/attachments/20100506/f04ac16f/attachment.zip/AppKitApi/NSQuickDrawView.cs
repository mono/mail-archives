using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSView))]
	interface NSQuickDrawView {

		//- (void*) qdPort;
		[Export ("qdPort")]
		void QdPort ();

	}
}
