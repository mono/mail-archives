using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSView))]
	interface NSTableHeaderView {

		//- (NSTableView *)tableView;
		[Export ("tableView")]
		NSTableView TableView { get; set; }

		//- (NSInteger)draggedColumn;
		[Export ("draggedColumn")]
		int DraggedColumn { get; }

		//- (CGFloat)draggedDistance;
		[Export ("draggedDistance")]
		float DraggedDistance { get; }

		//- (NSInteger)resizedColumn;
		[Export ("resizedColumn")]
		int ResizedColumn { get; }

		//- (NSRect)headerRectOfColumn:(NSInteger)column;
		[Export ("headerRectOfColumn:")]
		RectangleF HeaderRectOfColumn (int column);

		//- (NSInteger)columnAtPoint:(NSPoint)point;
		[Export ("columnAtPoint:")]
		int ColumnAtPoint (PointF point);

	}
}
