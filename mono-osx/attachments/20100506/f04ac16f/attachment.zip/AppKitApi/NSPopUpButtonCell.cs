using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSMenuItemCell))]
	interface NSPopUpButtonCell {

//#if __LP64__
//#endif
		//- (id)initTextCell:(NSString *)stringValue pullsDown:(BOOL)pullDown;
		[Export ("initTextCell:pullsDown:")]
		IntPtr Constructor (string stringValue, bool pullDown);

		//- (NSMenu *)menu;
		[Export ("menu")]
		NSMenu Menu { get; set; }

		//- (BOOL)pullsDown;
		[Export ("pullsDown")]
		bool PullsDown { get; set; }

		//- (BOOL)autoenablesItems;
		[Export ("autoenablesItems")]
		bool AutoenablesItems { get; set; }

		//- (NSRectEdge)preferredEdge;
		[Export ("preferredEdge")]
		NSRectEdge PreferredEdge { get; set; }

		//- (BOOL)usesItemFromMenu;
		[Export ("usesItemFromMenu")]
		bool UsesItemFromMenu { get; set; }

		//- (BOOL)altersStateOfSelectedItem;
		[Export ("altersStateOfSelectedItem")]
		bool AltersStateOfSelectedItem { get; set; }

		//    - (void)addItemWithTitle:(NSString *)title;
		[Export ("addItemWithTitle:")]
		void AddItemWithTitle (string title);

		//- (void)addItemsWithTitles:(NSArray *)itemTitles;
		[Export ("addItemsWithTitles:")]
		void AddItemsWithTitles (NSArray itemTitles);

		//- (void)insertItemWithTitle:(NSString *)title atIndex:(NSInteger)index;
		[Export ("insertItemWithTitle:atIndex:")]
		void InsertItemWithTitle (string title, int index);

		//- (void)removeItemWithTitle:(NSString *)title;
		[Export ("removeItemWithTitle:")]
		void RemoveItemWithTitle (string title);

		//- (void)removeItemAtIndex:(NSInteger)index;
		[Export ("removeItemAtIndex:")]
		void RemoveItemAtIndex (int index);

		//- (void)removeAllItems;
		[Export ("removeAllItems")]
		void RemoveAllItems ();

		//- (NSArray *)itemArray;
		[Export ("itemArray")]
		NSArray ItemArray { get; }

		//- (NSInteger)numberOfItems;
		[Export ("numberOfItems")]
		int NumberOfItems { get; }

		//- (NSInteger)indexOfItem:(NSMenuItem *)item;
		[Export ("indexOfItem:")]
		int IndexOfItem (NSMenuItem item);

		//- (NSInteger)indexOfItemWithTitle:(NSString *)title;
		[Export ("indexOfItemWithTitle:")]
		int IndexOfItemWithTitle (string title);

		//- (NSInteger)indexOfItemWithTag:(NSInteger)tag;
		[Export ("indexOfItemWithTag:")]
		int IndexOfItemWithTag (int tag);

		//- (NSInteger)indexOfItemWithRepresentedObject:(id)obj;
		[Export ("indexOfItemWithRepresentedObject:")]
		int IndexOfItemWithRepresentedObject (NSObject obj);

		//- (NSInteger)indexOfItemWithTarget:(id)target andAction:(SEL)actionSelector;
		[Export ("indexOfItemWithTarget:andAction:")]
		int IndexOfItemWithTarget (NSObject target, Selector actionSelector);

		//- (NSMenuItem *)itemAtIndex:(NSInteger)index;
		[Export ("itemAtIndex:")]
		NSMenuItem ItemAtIndex (int index);

		//- (NSMenuItem *)itemWithTitle:(NSString *)title;
		[Export ("itemWithTitle:")]
		NSMenuItem ItemWithTitle (string title);

		//- (NSMenuItem *)lastItem;
		[Export ("lastItem")]
		NSMenuItem LastItem { get; }

		//- (void)selectItem:(NSMenuItem *)item;
		[Export ("selectItem:")]
		void SelectItem (NSMenuItem item);

		//- (void)selectItemAtIndex:(NSInteger)index;
		[Export ("selectItemAtIndex:")]
		void SelectItemAtIndex (int index);

		//- (void)selectItemWithTitle:(NSString *)title;
		[Export ("selectItemWithTitle:")]
		void SelectItemWithTitle (string title);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_4
		//- (BOOL)selectItemWithTag:(NSInteger)tag;
		[Export ("selectItemWithTag:")]
		bool SelectItemWithTag (int tag);

//#endif
		//- (void)setTitle:(NSString *)aString;
		[Export ("setTitle:")]
		void SetTitle (string aString);

		//- (NSMenuItem *)selectedItem;
		[Export ("selectedItem")]
		NSMenuItem SelectedItem { get; }

		//- (NSInteger)indexOfSelectedItem;
		[Export ("indexOfSelectedItem")]
		int IndexOfSelectedItem { get; }

		//- (void)synchronizeTitleAndSelectedItem;
		[Export ("synchronizeTitleAndSelectedItem")]
		void SynchronizeTitleAndSelectedItem ();

		//- (NSString *)itemTitleAtIndex:(NSInteger)index;
		[Export ("itemTitleAtIndex:")]
		string ItemTitleAtIndex (int index);

		//- (NSArray *)itemTitles;
		[Export ("itemTitles")]
		NSArray ItemTitles { get; }

		//- (NSString *)titleOfSelectedItem;
		[Export ("titleOfSelectedItem")]
		string TitleOfSelectedItem { get; }

		//- (void)attachPopUpWithFrame:(NSRect)cellFrame inView:(NSView *)controlView;
		[Export ("attachPopUpWithFrame:inView:")]
		void AttachPopUpWithFrame (RectangleF cellFrame, NSView controlView);

		//- (void)dismissPopUp;
		[Export ("dismissPopUp")]
		void DismissPopUp ();

		//- (void)performClickWithFrame:(NSRect)frame inView:(NSView *)controlView;
		[Export ("performClickWithFrame:inView:")]
		void PerformClickWithFrame (RectangleF frame, NSView controlView);

		//- (NSPopUpArrowPosition)arrowPosition;
		[Export ("arrowPosition")]
		NSPopUpArrowPosition ArrowPosition { get; set; }

		//- (id)objectValue;
		[Export ("objectValue")]
		NSPopUpButtonCell ObjectValue { get; }

		//- (void)setObjectValue:(id)obj;
		[Export ("setObjectValue:")]
		void SetObjectValue (NSObject obj);

	}
}
