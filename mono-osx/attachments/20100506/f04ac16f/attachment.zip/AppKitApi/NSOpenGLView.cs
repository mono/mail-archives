using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.ObjCRuntime;

namespace MonoMac.AppKit
{

	[BaseType (typeof (NSView))]
	interface NSOpenGLView {

		//+ (NSOpenGLPixelFormat*)defaultPixelFormat;
		[Static, Export ("defaultPixelFormat")]
		NSOpenGLPixelFormat DefaultPixelFormat { get; }

		//- (id)initWithFrame:(NSRect)frameRect pixelFormat:(NSOpenGLPixelFormat*)format;
		[Export ("initWithFrame:pixelFormat:")]
		IntPtr Constructor (RectangleF frameRect, NSOpenGLPixelFormat format);

		//- (NSOpenGLContext*)openGLContext;
		[Export ("openGLContext")]
		NSOpenGLContext OpenGLContext { get; set; }

		//- (void)clearGLContext;
		[Export ("clearGLContext")]
		void ClearGLContext ();

		//- (void)update;		
		[Export ("update")]
		void Update ();

		//- (void)reshape;	
		[Export ("reshape")]
		void Reshape ();

		//- (NSOpenGLPixelFormat*)pixelFormat;
		[Export ("pixelFormat")]
		NSOpenGLPixelFormat PixelFormat { get; set; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_3
		//- (void)prepareOpenGL;
		[Export ("prepareOpenGL")]
		void PrepareOpenGL ();

//#endif
	}
}
