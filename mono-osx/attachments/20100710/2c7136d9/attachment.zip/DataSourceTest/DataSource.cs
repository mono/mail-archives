using System;
using System.Collections;
using MonoMac.Foundation;
using MonoMac.AppKit;
using System.Collections.Generic;

namespace DataSourceTest
{
	//[Register("DataSource")]
	public class DataSource<T> : NSTableViewDataSource
	{
		public List<T> Items { get; set; }

		static DataSource ()
		{
		}

		[Export("numberOfRowsInTableView:")]
		public int numberOfRowsInTableView (NSTableView aTableView)
		{
			if (Items == null)
				return 0;
			return Items.Count;
		}

		[Export("tableView:objectValueForTableColumn:row:")]
		public NSObject objectValueForTableColumn (NSTableView aTableView, NSTableColumn aTableColumn, int rowIndex)
		{
			return new NSString(Items[rowIndex].ToString());
		}

		public void AddItems(List<T> items)
		{
			Items = items;
		}
	}

	public class DataSourceDelegate<T> : NSTableViewDelegate
    {
		public event EventHandler<SelectionChangedEventArgs<T>> SelectionChanged;

        public DataSourceDelegate ():base()
        {
			Console.WriteLine ("DataSourceDelegate created");
        }
		
		public override void SelectionDidChange(NSNotification notification)
		{
			Console.WriteLine ("SelectionDidChange");
			var table = notification.Object as NSTableView;
			
			if (table == null)
				return;
			
			var ds = table.DataSource as DataSource<T>;
			if (ds == null)
				return;
			
			var rowNum = table.SelectedRow;
			
			if (rowNum >= 0 && rowNum < ds.Items.Count)
				OnSelectionChanged(new SelectionChangedEventArgs<T>(ds.Items[rowNum]));
		}
		
		protected void OnSelectionChanged(SelectionChangedEventArgs<T> e)
		{
			if (SelectionChanged != null)
				SelectionChanged(this, e);
		}
    }
	
	public class SelectionChangedEventArgs<T> : EventArgs
	{
		public T Selection { get; set; }
		
		public SelectionChangedEventArgs(T selection)
		{
			Selection = selection;
		}
	}
}