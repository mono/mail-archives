using System;
using System.Runtime.InteropServices;

namespace Test {
    public class MyClass {
        public static void Main(String[] args) {
            try {
				Console.WriteLine("MyClass.Main()");
                InterOpTest();
            } catch (Exception ex) {
                Console.WriteLine(ex.ToString());
            }
        }

        [DllImport("__Internal")]
        private static extern MyStruct InterOpTest();

    }

    [StructLayout(LayoutKind.Sequential)]
    public struct MyStruct {
        //public char x;
        //public int y;
		//public float f;
		public IntPtr p;
    }
}
