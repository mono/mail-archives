#include <mono/jit/jit.h>
#include <mono/metadata/assembly.h>

struct MyStruct {
	//char x;
	//int y;
	//float f;
	void * p;
};
typedef struct MyStruct MyStruct;

MyStruct InterOpTest() {
	fprintf(stderr, "MyStruct InterOpTest()\n");
	MyStruct retVal;
	return retVal;
}

int main(int argc, char *argv[])
{
	char* file = "MyClass.exe";

	MonoAssembly* assembly;
	MonoDomain* domain;

	domain = mono_jit_init(file);
	assembly = mono_domain_assembly_open (domain, file);
	mono_jit_exec(domain, assembly, 1, argv);
	return 0;
}
