
using System;
using System.Collections.Generic;
using System.Linq;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.AppKit;

namespace FirstAnimation
{
	public partial class BaseView : MonoMac.AppKit.NSView
	{
		NSImageView mover;
		RectangleF leftFramePosition;
		RectangleF rightFramePosition;
		bool isRight = false;
		
		#region Constructors

		// Called when created from unmanaged code
		public BaseView (IntPtr handle) : base(handle)
		{
			Initialize ();
		}

		// Called when created directly from a XIB file
		[Export("initWithCoder:")]
		public BaseView (NSCoder coder) : base(coder)
		{
			Initialize ();
		}
		
		[Export("initWithFrame:")]
		public BaseView (RectangleF frame) : base (frame)
		{
			
			//Console.WriteLine("frame " + frame);
			Initialize();
			
			initializeFramePostions();
			addImageToSubview();
			AddSubview(mover);
		}
		// Shared initialization code
		void Initialize ()
		{
		}
		
		#endregion
		
		public override bool AcceptsFirstResponder ()
		{
			return true;
		}
		
		public override void KeyDown (NSEvent theEvent)
		{
			//base.KeyDown (theEvent);
			move();
		}
		
		private void initializeFramePostions()
		{
			
			float frameX = this.Frame.Width;
			float frameY = this.Frame.Height;
			
			leftFramePosition = new RectangleF(0.0f, 0.0f, frameX / 4.0f,
			                                   frameY / 4.0f);
			rightFramePosition = new RectangleF(7.0f * frameX /8.0f,
			                                    7.0f * frameY / 16.0f,
			                                    frameX / 8.0f, frameY/8.0f);
			mover =  new NSImageView(leftFramePosition);
			
			isRight = false;
		}
		
		private void addImageToSubview()
		{
			mover.ImageScaling = NSImageScale.ProportionallyUpOrDown;
			
			mover.Image = NSImage.ImageNamed("photo.jpg");
			
		}
		
		private void move()
		{
			if (isRight)
			{
				//mover.Frame = leftFramePosition;
				((NSView)mover.Animator).Frame = leftFramePosition;
			}
			else
			{
				//mover.Frame = rightFramePosition;
				((NSView)mover.Animator).Frame = rightFramePosition;
			}
			
			isRight = !isRight;
		}
	}
}

