NeHe Lesson 3
=============

Converted to Mono and C# by Kenneth J. Pouncey 2011/03/06 
from NeHe Productions: OpenGL Lessons
http://nehe.gamedev.net/data/lessons/lesson.asp?lesson=03

===========================================================================
DESCRIPTION:


Adding Color:
=============

Expanding on the second tutorial I will teach you how to create spectacular 
colors in OpenGL with very little effort. You will learn about both flat 
coloring and smooth coloring. The triangle on the left uses smooth coloring. 
The square on the right is using flat coloring. Notice how the colors on the 
triangle blend together.  

Color adds alot to an OpenGL project. By understanding both flat and smooth 
coloring, you can greatly enhance the way your OpenGL demos look. 


===========================================================================
SAMPLE REQUIREMENTS

The supplied solution requires MonoMac bindings from the Mono Project.

===========================================================================
CHANGES FROM PREVIOUS VERSIONS:

n/a
