NeHe Lesson 4
=============

Converted to Mono and C# by Kenneth J. Pouncey 2011/03/06 
from NeHe Productions: OpenGL Lessons
http://nehe.gamedev.net/data/lessons/lesson.asp?lesson=04

===========================================================================
DESCRIPTION:


Rotation:
=============

Moving right along. In this tutorial I'll teach you how to rotate both the 
triangle and the quad. The triangle will rotate on the Y axis, and the quad 
will rotate on the X axis. This tutorial will introduce 2 variables. rtri is 
used to store the angle of the triangle, and rquad will store the angle of 
the quad.  

It's easy to create a scene made up of polygons. Adding motion to those object 
makes the scene come alive. In later lessons I'll teach you how to rotate an 
object around a point on the screen causing the object to move around the 
screen rather than spin on its axis. 


===========================================================================
SAMPLE REQUIREMENTS

The supplied solution requires MonoMac bindings from the Mono Project.

===========================================================================
CHANGES FROM PREVIOUS VERSIONS:

n/a
