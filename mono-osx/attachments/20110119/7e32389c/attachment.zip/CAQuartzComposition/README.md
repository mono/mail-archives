CAQuartzComposition
===================

Shows the use of the Core Animation and Quartz Composition QCCompositionLayer.

Converted to Mono and C# by:  Kenneth J. Pouncey 2011/01/19

For a full description of the program and the original article point your browser here:
http://www.cimgf.com/2008/09/24/core-animation-tutorial-core-animation-and-quartz-composer-qccompositionlayer/#more-289
