using System;
using MonoMac.Foundation;

namespace MonoMac.CoreData
{

	[BaseType (typeof (NSExpression))]
	interface NSFetchRequestExpression {

		//+ (NSExpression*)expressionForFetch:(NSExpression*)fetch context:(NSExpression*)context countOnly:(BOOL)countFlag;
		[Static, Export ("expressionForFetch:context:countOnly:")]
		NSExpression ExpressionForFetch (NSExpression fetch, NSExpression context, bool countFlag);

		//- (NSExpression *)requestExpression;
		[Export ("requestExpression")]
		NSExpression RequestExpression { get; }

		//- (NSExpression *)contextExpression; 
		[Export ("contextExpression")]
		NSExpression ContextExpression { get; }

		//- (BOOL)isCountOnlyRequest;
		[Export ("isCountOnlyRequest")]
		bool IsCountOnlyRequest { get; }

	}
}
