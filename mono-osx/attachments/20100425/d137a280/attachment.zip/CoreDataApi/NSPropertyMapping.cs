using System;
using MonoMac.Foundation;

namespace MonoMac.CoreData
{

	[BaseType (typeof (NSObject))]
	interface NSPropertyMapping {

		//- (NSString *)name;
		[Export ("name")]
		NSString Name { get; set; }

		//- (void)setName:(NSString *)name;
		[Export ("setName:")]
		void SetName (NSString name);

		//- (NSExpression *)valueExpression;
		[Export ("valueExpression")]
		NSExpression ValueExpression { get; set; }

		//- (void)setValueExpression:(NSExpression *)expression;
		[Export ("setValueExpression:")]
		void SetValueExpression (NSExpression expression);

		//- (NSDictionary *)userInfo;
		[Export ("userInfo")]
		NSDictionary UserInfo { get; set; }

		//- (void)setUserInfo:(NSDictionary *)userInfo;
		[Export ("setUserInfo:")]
		void SetUserInfo (NSDictionary userInfo);

	}
}
