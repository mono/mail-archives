using System;
using MonoMac.Foundation;

namespace MonoMac.CoreData
{

	[BaseType (typeof (NSObject))]
	interface NSManagedObjectID {

		//- (NSEntityDescription *)entity;    
		[Export ("entity")]
		NSEntityDescription Entity { get; }

		//- (NSPersistentStore *)persistentStore;    
		[Export ("persistentStore")]
		NSPersistentStore PersistentStore { get; }

		//- (BOOL)isTemporaryID;    
		[Export ("isTemporaryID")]
		bool IsTemporaryID { get; }

		//- (NSURL *)URIRepresentation;    
		[Export ("URIRepresentation")]
		NSUrl URIRepresentation { get; }

	}
}
