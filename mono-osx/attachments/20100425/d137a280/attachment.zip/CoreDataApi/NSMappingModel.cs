using System;
using MonoMac.Foundation;

namespace MonoMac.CoreData
{

	[BaseType (typeof (NSObject))]
	interface NSMappingModel {

		//+ (NSMappingModel *)mappingModelFromBundles:(NSArray *)bundles forSourceModel:(NSManagedObjectModel *)sourceModel destinationModel:(NSManagedObjectModel *)destinationModel;
		[Static, Export ("mappingModelFromBundles:forSourceModel:destinationModel:")]
		NSMappingModel MappingModelFromBundles (NSArray bundles, NSManagedObjectModel sourceModel, NSManagedObjectModel destinationModel);

		//- (id)initWithContentsOfURL:(NSURL *)url;
		[Export ("initWithContentsOfURL:")]
		NSMappingModel InitWithContentsOfURL (NSUrl url);

		//- (NSArray *)entityMappings;
		[Export ("entityMappings")]
		NSArray EntityMappings { get; set; }

		//- (void)setEntityMappings:(NSArray *)mappings;
		[Export ("setEntityMappings:")]
		void SetEntityMappings (NSArray mappings);

		//- (NSDictionary *)entityMappingsByName;
		[Export ("entityMappingsByName")]
		NSDictionary EntityMappingsByName { get; }

	}
}
