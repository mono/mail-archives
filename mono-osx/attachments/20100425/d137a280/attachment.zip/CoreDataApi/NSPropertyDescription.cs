using System;
using MonoMac.Foundation;

namespace MonoMac.CoreData
{

	[BaseType (typeof (NSObject))]
	interface NSPropertyDescription {

		//- (NSEntityDescription *)entity;
		[Export ("entity")]
		NSEntityDescription Entity { get; }

		//- (NSString *)name;
		[Export ("name")]
		NSString Name { get; set; }

		//- (void)setName:(NSString *)name;
		[Export ("setName:")]
		void SetName (NSString name);

		//- (BOOL)isOptional;
		[Export ("isOptional")]
		bool IsOptional { get; }

		//- (void)setOptional:(BOOL)flag;
		[Export ("setOptional:")]
		void SetOptional (bool flag);

		//- (BOOL)isTransient;
		[Export ("isTransient")]
		bool IsTransient { get; }

		//- (void)setTransient:(BOOL)flag;
		[Export ("setTransient:")]
		void SetTransient (bool flag);

		//- (NSArray *)validationPredicates;
		[Export ("validationPredicates")]
		NSArray ValidationPredicates { get; }

		//- (NSArray *)validationWarnings;
		[Export ("validationWarnings")]
		NSArray ValidationWarnings { get; }

		//- (void)setValidationPredicates:(NSArray *)validationPredicates withValidationWarnings:(NSArray *)validationWarnings;
		[Export ("setValidationPredicates:withValidationWarnings:")]
		void SetValidationPredicates (NSArray validationPredicates, NSArray validationWarnings);

		//- (NSDictionary *)userInfo;
		[Export ("userInfo")]
		NSDictionary UserInfo { get; set; }

		//- (void)setUserInfo:(NSDictionary *)dictionary;
		[Export ("setUserInfo:")]
		void SetUserInfo (NSDictionary dictionary);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (BOOL)isIndexed;
		[Export ("isIndexed")]
		bool IsIndexed { get; }

		//- (void)setIndexed:(BOOL)flag;
		[Export ("setIndexed:")]
		void SetIndexed (bool flag);

		//- (NSData *)versionHash;
		[Export ("versionHash")]
		NSData VersionHash { get; }

		//- (NSString *)versionHashModifier;
		[Export ("versionHashModifier")]
		NSString VersionHashModifier { get; set; }

		//- (void)setVersionHashModifier:(NSString *)modifierString;
		[Export ("setVersionHashModifier:")]
		void SetVersionHashModifier (NSString modifierString);

//#endif 
	}
}
