using System;
using MonoMac.Foundation;

namespace MonoMac.CoreData
{

	[BaseType (typeof (NSObject))]
	interface NSManagedObjectContext {

		//- (void)setPersistentStoreCoordinator:(NSPersistentStoreCoordinator *)coordinator;
		[Export ("setPersistentStoreCoordinator:")]
		void SetPersistentStoreCoordinator (NSPersistentStoreCoordinator coordinator);

		//- (NSPersistentStoreCoordinator *)persistentStoreCoordinator;
		[Export ("persistentStoreCoordinator")]
		NSPersistentStoreCoordinator PersistentStoreCoordinator { get; set; }

		//- (void)setUndoManager:(NSUndoManager *)undoManager;
		[Export ("setUndoManager:")]
		void SetUndoManager (NSUndoManager undoManager);

		//- (NSUndoManager *)undoManager;
		[Export ("undoManager")]
		NSUndoManager UndoManager { get; set; }

		//- (BOOL)hasChanges;
		[Export ("hasChanges")]
		bool HasChanges { get; }

		//- (NSManagedObject *)objectRegisteredForID:(NSManagedObjectID *)objectID;    
		[Export ("objectRegisteredForID:")]
		NSManagedObject ObjectRegisteredForID (NSManagedObjectID objectID);

		//- (NSManagedObject *)objectWithID:(NSManagedObjectID *)objectID;    
		[Export ("objectWithID:")]
		NSManagedObject ObjectWithID (NSManagedObjectID objectID);

		//- (NSArray *)executeFetchRequest:(NSFetchRequest *)request error:(NSError **)error;    
		[Export ("executeFetchRequest:error:")]
		NSArray ExecuteFetchRequest (NSFetchRequest request, NSError error);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (NSUInteger) countForFetchRequest: (NSFetchRequest *)request error: (NSError **)error;    
		[Export ("countForFetchRequest:error:")]
		uint CountForFetchRequest (NSFetchRequest request, NSError error);

//#endif 
		//- (void)insertObject:(NSManagedObject *)object;
		[Export ("insertObject:")]
		void InsertObject (NSManagedObject object1);

		//- (void)deleteObject:(NSManagedObject *)object;
		[Export ("deleteObject:")]
		void DeleteObject (NSManagedObject object1);

		//- (void)refreshObject:(NSManagedObject *)object mergeChanges:(BOOL)flag;    
		[Export ("refreshObject:mergeChanges:")]
		void RefreshObject (NSManagedObject object1, bool flag);

		//- (void)detectConflictsForObject:(NSManagedObject *)object;    
		[Export ("detectConflictsForObject:")]
		void DetectConflictsForObject (NSManagedObject object1);

		//TODO- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context;    
		//[Export ("observeValueForKeyPath:ofObject:change:context:")]
		//void ObserveValueForKeyPath (NSString keyPath, IntPtr object1, NSDictionary change, void context);

		//- (void)processPendingChanges;    
		[Export ("processPendingChanges")]
		void ProcessPendingChanges ();

		//- (void)assignObject:(id)object toPersistentStore:(NSPersistentStore *)store;    
		[Export ("assignObject:toPersistentStore:")]
		void AssignObject (IntPtr object1, NSPersistentStore store);

		//- (NSSet *)insertedObjects;
		[Export ("insertedObjects")]
		NSSet InsertedObjects { get; }

		//- (NSSet *)updatedObjects;
		[Export ("updatedObjects")]
		NSSet UpdatedObjects { get; }

		//- (NSSet *)deletedObjects;
		[Export ("deletedObjects")]
		NSSet DeletedObjects { get; }

		//- (NSSet *)registeredObjects;
		[Export ("registeredObjects")]
		NSSet RegisteredObjects { get; }

		//- (void)undo;
		[Export ("undo")]
		void Undo ();

		//- (void)redo;
		[Export ("redo")]
		void Redo ();

		//- (void)reset;
		[Export ("reset")]
		void Reset ();

		//- (void)rollback;
		[Export ("rollback")]
		void Rollback ();

		//- (BOOL)save:(NSError **)error;
		[Export ("save:")]
		bool Save (NSError error);

		//- (void)lock;
		[Export ("lock")]
		void Lock ();

		//- (void)unlock;
		[Export ("unlock")]
		void Unlock ();

		//- (BOOL)tryLock;
		[Export ("tryLock")]
		bool TryLock { get; }

		//- (BOOL)propagatesDeletesAtEndOfEvent;  
		[Export ("propagatesDeletesAtEndOfEvent")]
		bool PropagatesDeletesAtEndOfEvent { get; set; }

		//- (void)setPropagatesDeletesAtEndOfEvent:(BOOL)flag;  
		[Export ("setPropagatesDeletesAtEndOfEvent:")]
		void SetPropagatesDeletesAtEndOfEvent (bool flag);

		//- (BOOL)retainsRegisteredObjects;  
		[Export ("retainsRegisteredObjects")]
		bool RetainsRegisteredObjects { get; set; }

		//- (void)setRetainsRegisteredObjects:(BOOL)flag;  
		[Export ("setRetainsRegisteredObjects:")]
		void SetRetainsRegisteredObjects (bool flag);

		//- (NSTimeInterval)stalenessInterval;
		[Export ("stalenessInterval")]
		double StalenessInterval { get; set; }

		//- (void)setStalenessInterval:(NSTimeInterval)expiration;  
		[Export ("setStalenessInterval:")]
		void SetStalenessInterval (double expiration);

		//- (void)setMergePolicy:(id)mergePolicy;  
		[Export ("setMergePolicy:")]
		void SetMergePolicy (IntPtr mergePolicy);

		//- (id)mergePolicy;    
		[Export ("mergePolicy")]
		NSManagedObjectContext MergePolicy { get; set; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (BOOL)obtainPermanentIDsForObjects:(NSArray *)objects error:(NSError **)error;
		[Export ("obtainPermanentIDsForObjects:error:")]
		bool ObtainPermanentIDsForObjects (NSArray objects, NSError error);

		//- (void)mergeChangesFromContextDidSaveNotification:(NSNotification *)notification;
		[Export ("mergeChangesFromContextDidSaveNotification:")]
		void MergeChangesFromContextDidSaveNotification (NSNotification notification);

//#endif 
	}
}
