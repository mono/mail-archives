using System;
using MonoMac.Foundation;

namespace MonoMac.CoreData
{

	[BaseType (typeof (NSObject))]
	interface NSManagedObject {

		//- (id)initWithEntity:(NSEntityDescription *)entity insertIntoManagedObjectContext:(NSManagedObjectContext *)context;    
		[Export ("initWithEntity:insertIntoManagedObjectContext:")]
		NSManagedObject InitWithEntity (NSEntityDescription entity, NSManagedObjectContext context);

		//- (NSManagedObjectContext *)managedObjectContext;
		[Export ("managedObjectContext")]
		NSManagedObjectContext ManagedObjectContext { get; }

		//- (NSEntityDescription *)entity;
		[Export ("entity")]
		NSEntityDescription Entity { get; }

		//- (NSManagedObjectID *)objectID;
		[Export ("objectID")]
		NSManagedObjectID ObjectID { get; }

		//- (BOOL)isInserted;
		[Export ("isInserted")]
		bool IsInserted { get; }

		//- (BOOL)isUpdated;
		[Export ("isUpdated")]
		bool IsUpdated { get; }

		//- (BOOL)isDeleted;
		[Export ("isDeleted")]
		bool IsDeleted { get; }

		//- (BOOL)isFault;    
		[Export ("isFault")]
		bool IsFault { get; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (BOOL) hasFaultForRelationshipNamed:(NSString *)key; 
		[Export ("hasFaultForRelationshipNamed:")]
		bool HasFaultForRelationshipNamed (NSString key);

//#endif 
		//- (void)willAccessValueForKey:(NSString *)key;      
		[Export ("willAccessValueForKey:")]
		void WillAccessValueForKey (NSString key);

		//- (void)didAccessValueForKey:(NSString *)key;       
		[Export ("didAccessValueForKey:")]
		void DidAccessValueForKey (NSString key);

		//- (void)willChangeValueForKey:(NSString *)key;
		[Export ("willChangeValueForKey:")]
		void WillChangeValueForKey (NSString key);

		//- (void)didChangeValueForKey:(NSString *)key;
		[Export ("didChangeValueForKey:")]
		void DidChangeValueForKey (NSString key);

		//- (void)willChangeValueForKey:(NSString *)inKey withSetMutation:(NSKeyValueSetMutationKind)inMutationKind usingObjects:(NSSet *)inObjects;
		[Export ("willChangeValueForKey:withSetMutation:usingObjects:")]
		void WillChangeValueForKey (NSString inKey, NSKeyValueSetMutationKind inMutationKind, NSSet inObjects);

		//- (void)didChangeValueForKey:(NSString *)inKey withSetMutation:(NSKeyValueSetMutationKind)inMutationKind usingObjects:(NSSet *)inObjects;
		[Export ("didChangeValueForKey:withSetMutation:usingObjects:")]
		void DidChangeValueForKey (NSString inKey, NSKeyValueSetMutationKind inMutationKind, NSSet inObjects);

		//TODO- (void)setObservationInfo:(void *)inObservationInfo; 
		//[Export ("setObservationInfo:")]
		//void SetObservationInfo (void inObservationInfo);

		//- (void *)observationInfo;    
		[Export ("observationInfo")]
		void ObservationInfo ();

		//- (void)awakeFromFetch;    
		[Export ("awakeFromFetch")]
		void AwakeFromFetch ();

		//- (void)awakeFromInsert;    
		[Export ("awakeFromInsert")]
		void AwakeFromInsert ();

		//- (void)willSave;    
		[Export ("willSave")]
		void WillSave ();

		//- (void)didSave;    
		[Export ("didSave")]
		void DidSave ();

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (void) willTurnIntoFault;
		[Export ("willTurnIntoFault")]
		void WillTurnIntoFault ();

//#endif 
		//- (void)didTurnIntoFault;    
		[Export ("didTurnIntoFault")]
		void DidTurnIntoFault ();

		//- (id)valueForKey:(NSString *)key;    
		[Export ("valueForKey:")]
		NSManagedObject ValueForKey (NSString key);

		//- (void)setValue:(id)value forKey:(NSString *)key;    
		[Export ("setValue:forKey:")]
		void SetValue (IntPtr value, NSString key);

		//- (id)primitiveValueForKey:(NSString *)key;    
		[Export ("primitiveValueForKey:")]
		NSManagedObject PrimitiveValueForKey (NSString key);

		//- (void)setPrimitiveValue:(id)value forKey:(NSString *)key;
		[Export ("setPrimitiveValue:forKey:")]
		void SetPrimitiveValue (IntPtr value, NSString key);

		//- (NSDictionary *)committedValuesForKeys:(NSArray *)keys;    
		[Export ("committedValuesForKeys:")]
		NSDictionary CommittedValuesForKeys (NSArray keys);

		//- (NSDictionary *)changedValues;    
		[Export ("changedValues")]
		NSDictionary ChangedValues { get; }

		//- (BOOL)validateValue:(id *)value forKey:(NSString *)key error:(NSError **)error;    
		[Export ("validateValue:forKey:error:")]
		bool ValidateValue (IntPtr value, NSString key, NSError error);

		//- (BOOL)validateForDelete:(NSError **)error;
		[Export ("validateForDelete:")]
		bool ValidateForDelete (NSError error);

		//- (BOOL)validateForInsert:(NSError **)error;
		[Export ("validateForInsert:")]
		bool ValidateForInsert (NSError error);

		//- (BOOL)validateForUpdate:(NSError **)error;
		[Export ("validateForUpdate:")]
		bool ValidateForUpdate (NSError error);

	}
}
