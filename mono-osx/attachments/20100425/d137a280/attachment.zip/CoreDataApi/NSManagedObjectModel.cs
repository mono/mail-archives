using System;
using MonoMac.Foundation;

namespace MonoMac.CoreData
{

	[BaseType (typeof (NSObject))]
	interface NSManagedObjectModel {

		//+ (NSManagedObjectModel *)mergedModelFromBundles:(NSArray *)bundles;    
		[Static, Export ("mergedModelFromBundles:")]
		NSManagedObjectModel MergedModelFromBundles (NSArray bundles);

		//+ (NSManagedObjectModel *)modelByMergingModels:(NSArray *)models;    
		[Static, Export ("modelByMergingModels:")]
		NSManagedObjectModel ModelByMergingModels (NSArray models);

		//- (id)init;    
		[Export ("init")]
		NSManagedObjectModel Init { get; }

		//- (id)initWithContentsOfURL:(NSURL *)url;
		[Export ("initWithContentsOfURL:")]
		NSManagedObjectModel InitWithContentsOfURL (NSUrl url);

		//- (NSDictionary *)entitiesByName;
		[Export ("entitiesByName")]
		NSDictionary EntitiesByName { get; }

		//- (NSArray *)entities;
		[Export ("entities")]
		NSArray Entities { get; set; }

		//- (void)setEntities:(NSArray *)entities;
		[Export ("setEntities:")]
		void SetEntities (NSArray entities);

		//- (NSArray *)configurations;    
		[Export ("configurations")]
		NSArray Configurations { get; }

		//- (NSArray *)entitiesForConfiguration:(NSString *)configuration;
		[Export ("entitiesForConfiguration:")]
		NSArray EntitiesForConfiguration (NSString configuration);

		//- (void)setEntities:(NSArray *)entities forConfiguration:(NSString *)configuration;
		[Export ("setEntities:forConfiguration:")]
		void SetEntities (NSArray entities, NSString configuration);

		//- (void)setFetchRequestTemplate:(NSFetchRequest *)fetchRequestTemplate forName:(NSString *)name;
		[Export ("setFetchRequestTemplate:forName:")]
		void SetFetchRequestTemplate (NSFetchRequest fetchRequestTemplate, NSString name);

		//- (NSFetchRequest *)fetchRequestTemplateForName:(NSString *)name;
		[Export ("fetchRequestTemplateForName:")]
		NSFetchRequest FetchRequestTemplateForName (NSString name);

		//- (NSFetchRequest *)fetchRequestFromTemplateWithName:(NSString *)name substitutionVariables:(NSDictionary *)variables;    
		[Export ("fetchRequestFromTemplateWithName:substitutionVariables:")]
		NSFetchRequest FetchRequestFromTemplateWithName (NSString name, NSDictionary variables);

		//- (NSDictionary *)localizationDictionary;
		[Export ("localizationDictionary")]
		NSDictionary LocalizationDictionary { get; set; }

		//- (void)setLocalizationDictionary:(NSDictionary *)localizationDictionary;
		[Export ("setLocalizationDictionary:")]
		void SetLocalizationDictionary (NSDictionary localizationDictionary);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//+ (NSManagedObjectModel *)mergedModelFromBundles:(NSArray *)bundles forStoreMetadata:(NSDictionary *)metadata;
		[Static, Export ("mergedModelFromBundles:forStoreMetadata:")]
		NSManagedObjectModel MergedModelFromBundles (NSArray bundles, NSDictionary metadata);

		//+ (NSManagedObjectModel *)modelByMergingModels:(NSArray *)models forStoreMetadata:(NSDictionary *)metadata;
		[Static, Export ("modelByMergingModels:forStoreMetadata:")]
		NSManagedObjectModel ModelByMergingModels (NSArray models, NSDictionary metadata);

		//- (NSDictionary *)fetchRequestTemplatesByName;
		[Export ("fetchRequestTemplatesByName")]
		NSDictionary FetchRequestTemplatesByName { get; }

		//- (NSSet *)versionIdentifiers;
		[Export ("versionIdentifiers")]
		NSSet VersionIdentifiers { get; set; }

		//- (void)setVersionIdentifiers:(NSSet *)identifiers;
		[Export ("setVersionIdentifiers:")]
		void SetVersionIdentifiers (NSSet identifiers);

		//- (BOOL)isConfiguration:(NSString *)configuration compatibleWithStoreMetadata:(NSDictionary *)metadata;
		[Export ("isConfiguration:compatibleWithStoreMetadata:")]
		bool IsConfiguration (NSString configuration, NSDictionary metadata);

		//- (NSDictionary *)entityVersionHashesByName;
		[Export ("entityVersionHashesByName")]
		NSDictionary EntityVersionHashesByName { get; }

//#endif 
	}
}
