using System;
using MonoMac.Foundation;

namespace MonoMac.CoreData
{

	[BaseType (typeof (NSObject))]
	interface NSAtomicStoreCacheNode {

		//- (id)initWithObjectID:(NSManagedObjectID *)moid;
		[Export ("initWithObjectID:")]
		NSAtomicStoreCacheNode InitWithObjectID (NSManagedObjectID moid);

		//- (NSManagedObjectID*)objectID;
		[Export ("objectID")]
		NSManagedObjectID ObjectID { get; }

		//- (NSMutableDictionary *)propertyCache;
		[Export ("propertyCache")]
		NSDictionary PropertyCache { get; set; }

		//- (void)setPropertyCache:(NSMutableDictionary *)propertyCache;
		[Export ("setPropertyCache:")]
		void SetPropertyCache (NSDictionary propertyCache);

		//- (id)valueForKey:(NSString*)key;
		[Export ("valueForKey:")]
		NSAtomicStoreCacheNode ValueForKey (NSString key);

		//- (void)setValue:(id)value forKey:(NSString*)key;
		[Export ("setValue:forKey:")]
		void SetValue (IntPtr value, NSString key);

	}
}
