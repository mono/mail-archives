using System;
using MonoMac.Foundation;

namespace MonoMac.CoreData
{

	[BaseType (typeof (NSObject))]
	interface NSEntityDescription {

		//+ (NSEntityDescription *)entityForName:(NSString *)entityName inManagedObjectContext:(NSManagedObjectContext *)context;
		[Static, Export ("entityForName:inManagedObjectContext:")]
		NSEntityDescription EntityForName (NSString entityName, NSManagedObjectContext context);

		//+ (id)insertNewObjectForEntityForName:(NSString *)entityName inManagedObjectContext:(NSManagedObjectContext *)context;
		[Export ("insertNewObjectForEntityForName:inManagedObjectContext:")]
		IntPtr Constructor (NSString entityName, NSManagedObjectContext context);

		//- (NSManagedObjectModel *)managedObjectModel;
		[Export ("managedObjectModel")]
		NSManagedObjectModel ManagedObjectModel { get; }

		//- (NSString *)managedObjectClassName;
		[Export ("managedObjectClassName")]
		NSString ManagedObjectClassName { get; set; }

		//- (void)setManagedObjectClassName:(NSString *)name;
		[Export ("setManagedObjectClassName:")]
		void SetManagedObjectClassName (NSString name);

		//- (NSString *)name;
		[Export ("name")]
		NSString Name { get; set; }

		//- (void)setName:(NSString *)name;
		[Export ("setName:")]
		void SetName (NSString name);

		//- (BOOL)isAbstract;
		[Export ("isAbstract")]
		bool IsAbstract { get; }

		//- (void)setAbstract:(BOOL)flag;
		[Export ("setAbstract:")]
		void SetAbstract (bool flag);

		//- (NSDictionary *)subentitiesByName;
		[Export ("subentitiesByName")]
		NSDictionary SubentitiesByName { get; }

		//- (NSArray *)subentities;
		[Export ("subentities")]
		NSArray Subentities { get; set; }

		//- (void)setSubentities:(NSArray *)array;
		[Export ("setSubentities:")]
		void SetSubentities (NSArray array);

		//- (NSEntityDescription *)superentity;
		[Export ("superentity")]
		NSEntityDescription Superentity { get; }

		//- (NSDictionary *)propertiesByName;
		[Export ("propertiesByName")]
		NSDictionary PropertiesByName { get; }

		//- (NSArray *)properties;
		[Export ("properties")]
		NSArray Properties { get; set; }

		//- (void)setProperties:(NSArray *)properties;
		[Export ("setProperties:")]
		void SetProperties (NSArray properties);

		//- (NSDictionary *)userInfo;
		[Export ("userInfo")]
		NSDictionary UserInfo { get; set; }

		//- (void)setUserInfo:(NSDictionary *)dictionary;
		[Export ("setUserInfo:")]
		void SetUserInfo (NSDictionary dictionary);

		//- (NSDictionary *)attributesByName;
		[Export ("attributesByName")]
		NSDictionary AttributesByName { get; }

		//- (NSDictionary *)relationshipsByName;
		[Export ("relationshipsByName")]
		NSDictionary RelationshipsByName { get; }

		//- (NSArray *)relationshipsWithDestinationEntity:(NSEntityDescription *)entity;
		[Export ("relationshipsWithDestinationEntity:")]
		NSArray RelationshipsWithDestinationEntity (NSEntityDescription entity);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (BOOL)isKindOfEntity:(NSEntityDescription *)entity;
		[Export ("isKindOfEntity:")]
		bool IsKindOfEntity (NSEntityDescription entity);

		//- (NSData *)versionHash;
		[Export ("versionHash")]
		NSData VersionHash { get; }

		//- (NSString *)versionHashModifier;
		[Export ("versionHashModifier")]
		NSString VersionHashModifier { get; set; }

		//- (void)setVersionHashModifier:(NSString *)modifierString;
		[Export ("setVersionHashModifier:")]
		void SetVersionHashModifier (NSString modifierString);

//#endif 
	}
}
