using System;
using MonoMac.Foundation;

namespace MonoMac.CoreData
{

	[BaseType (typeof (NSObject))]
	interface NSMigrationManager {

		//- (id)initWithSourceModel:(NSManagedObjectModel *)sourceModel destinationModel:(NSManagedObjectModel *)destinationModel;
		[Export ("initWithSourceModel:destinationModel:")]
		NSMigrationManager InitWithSourceModel (NSManagedObjectModel sourceModel, NSManagedObjectModel destinationModel);

		//- (BOOL)migrateStoreFromURL:(NSURL *)sourceURL type:(NSString *)sStoreType options:(NSDictionary *)sOptions withMappingModel:(NSMappingModel *)mappings toDestinationURL:(NSURL *)dURL destinationType:(NSString *)dStoreType destinationOptions:(NSDictionary *)dOptions error:(NSError **)error;
		[Export ("migrateStoreFromURL:type:options:withMappingModel:toDestinationURL:destinationType:destinationOptions:error:")]
		bool MigrateStoreFromURL (NSUrl sourceURL, NSString sStoreType, NSDictionary sOptions, NSMappingModel mappings, NSUrl dURL, NSString dStoreType, NSDictionary dOptions, NSError error);

		//- (void)reset;
		[Export ("reset")]
		void Reset ();

		//- (NSMappingModel *)mappingModel;
		[Export ("mappingModel")]
		NSMappingModel MappingModel { get; }

		//- (NSManagedObjectModel *)sourceModel;
		[Export ("sourceModel")]
		NSManagedObjectModel SourceModel { get; }

		//- (NSManagedObjectModel *)destinationModel;
		[Export ("destinationModel")]
		NSManagedObjectModel DestinationModel { get; }

		//- (NSManagedObjectContext *)sourceContext;
		[Export ("sourceContext")]
		NSManagedObjectContext SourceContext { get; }

		//- (NSManagedObjectContext *)destinationContext;
		[Export ("destinationContext")]
		NSManagedObjectContext DestinationContext { get; }

		//- (NSEntityDescription *)sourceEntityForEntityMapping:(NSEntityMapping *)mEntity;
		[Export ("sourceEntityForEntityMapping:")]
		NSEntityDescription SourceEntityForEntityMapping (NSEntityMapping mEntity);

		//- (NSEntityDescription *)destinationEntityForEntityMapping:(NSEntityMapping *)mEntity;
		[Export ("destinationEntityForEntityMapping:")]
		NSEntityDescription DestinationEntityForEntityMapping (NSEntityMapping mEntity);

		//- (void)associateSourceInstance:(NSManagedObject *)sourceInstance withDestinationInstance:(NSManagedObject *)destinationInstance forEntityMapping:(NSEntityMapping *)entityMapping;
		[Export ("associateSourceInstance:withDestinationInstance:forEntityMapping:")]
		void AssociateSourceInstance (NSManagedObject sourceInstance, NSManagedObject destinationInstance, NSEntityMapping entityMapping);

		// - (NSArray *)destinationInstancesForEntityMappingNamed:(NSString *)mappingName sourceInstances:(NSArray*)sourceInstances;
		[Export ("destinationInstancesForEntityMappingNamed:sourceInstances:")]
		NSArray DestinationInstancesForEntityMappingNamed (NSString mappingName, NSArray sourceInstances);

		// - (NSArray *)sourceInstancesForEntityMappingNamed:(NSString *)mappingName destinationInstances:(NSArray *)destinationInstances;
		[Export ("sourceInstancesForEntityMappingNamed:destinationInstances:")]
		NSArray SourceInstancesForEntityMappingNamed (NSString mappingName, NSArray destinationInstances);

		//- (NSEntityMapping *)currentEntityMapping;
		[Export ("currentEntityMapping")]
		NSEntityMapping CurrentEntityMapping { get; }

		//- (float)migrationProgress;
		[Export ("migrationProgress")]
		float MigrationProgress { get; }

		//- (NSDictionary *)userInfo;
		[Export ("userInfo")]
		NSDictionary UserInfo { get; set; }

		//- (void)setUserInfo:(NSDictionary *)dict;
		[Export ("setUserInfo:")]
		void SetUserInfo (NSDictionary dict);

		//- (void)cancelMigrationWithError:(NSError *)error;
		[Export ("cancelMigrationWithError:")]
		void CancelMigrationWithError (NSError error);

	}
}
