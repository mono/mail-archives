using System;
using MonoMac.Foundation;

namespace MonoMac.CoreData
{

	[BaseType (typeof (NSObject))]
	interface NSFetchRequest {

		//- (NSEntityDescription *)entity;
		[Export ("entity")]
		NSEntityDescription Entity { get; set; }

		//- (void)setEntity:(NSEntityDescription *)entity;
		[Export ("setEntity:")]
		void SetEntity (NSEntityDescription entity);

		//- (NSPredicate *)predicate;
		[Export ("predicate")]
		NSPredicate Predicate { get; set; }

		//- (void)setPredicate:(NSPredicate *)predicate;
		[Export ("setPredicate:")]
		void SetPredicate (NSPredicate predicate);

		//- (NSArray *)sortDescriptors;
		[Export ("sortDescriptors")]
		NSArray SortDescriptors { get; set; }

		//- (void)setSortDescriptors:(NSArray *)sortDescriptors;
		[Export ("setSortDescriptors:")]
		void SetSortDescriptors (NSArray sortDescriptors);

		//- (NSUInteger)fetchLimit;
		[Export ("fetchLimit")]
		uint FetchLimit { get; set; }

		//- (void)setFetchLimit:(NSUInteger)limit;
		[Export ("setFetchLimit:")]
		void SetFetchLimit (uint limit);

		//- (NSArray *)affectedStores;
		[Export ("affectedStores")]
		NSArray AffectedStores { get; set; }

		//- (void)setAffectedStores:(NSArray *)stores;
		[Export ("setAffectedStores:")]
		void SetAffectedStores (NSArray stores);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (NSFetchRequestResultType)resultType;
		[Export ("resultType")]
		NSFetchRequestResultType ResultType { get; set; }

		//- (void)setResultType:(NSFetchRequestResultType)type;
		[Export ("setResultType:")]
		void SetResultType (NSFetchRequestResultType type);

		//- (BOOL)includesSubentities;
		[Export ("includesSubentities")]
		bool IncludesSubentities { get; set; }

		//- (void)setIncludesSubentities:(BOOL)yesNo;
		[Export ("setIncludesSubentities:")]
		void SetIncludesSubentities (bool yesNo);

		//- (BOOL)includesPropertyValues;
		[Export ("includesPropertyValues")]
		bool IncludesPropertyValues { get; set; }

		//- (void)setIncludesPropertyValues:(BOOL)yesNo;
		[Export ("setIncludesPropertyValues:")]
		void SetIncludesPropertyValues (bool yesNo);

		//- (BOOL)returnsObjectsAsFaults;
		[Export ("returnsObjectsAsFaults")]
		bool ReturnsObjectsAsFaults { get; set; }

		//- (void)setReturnsObjectsAsFaults:(BOOL)yesNo;
		[Export ("setReturnsObjectsAsFaults:")]
		void SetReturnsObjectsAsFaults (bool yesNo);

		//- (NSArray *)relationshipKeyPathsForPrefetching;
		[Export ("relationshipKeyPathsForPrefetching")]
		NSArray RelationshipKeyPathsForPrefetching { get; set; }

		//- (void)setRelationshipKeyPathsForPrefetching:(NSArray *)keys;
		[Export ("setRelationshipKeyPathsForPrefetching:")]
		void SetRelationshipKeyPathsForPrefetching (NSArray keys);

//#endif 
	}
}
