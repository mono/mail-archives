
namespace MonoMac.CoreData
{
	public enum NSEntityMappingType
	{
	    NSUndefinedEntityMappingType    = 0x00,
	    NSCustomEntityMappingType       = 0x01,         /* developer handles destination instance creation */
	    NSAddEntityMappingType          = 0x02,         /* new entity in destination */
	    NSRemoveEntityMappingType	    = 0x03,         /* source instances aren't mapped to destination */
	    NSCopyEntityMappingType         = 0x04,         /* migrate instances as-is */
	    NSTransformEntityMappingType    = 0x05,         /* entity exists in source and destination and is mapped */
	}

	public enum NSDeleteRule 
	{
	   NSNoActionDeleteRule,
	   NSNullifyDeleteRule,
	   NSCascadeDeleteRule,
	   NSDenyDeleteRule
	}

    public enum NSKeyValueSetMutationKind : uint
    {
        NSKeyValueUnionSetMutation = 1,
        NSKeyValueMinusSetMutation = 2,
        NSKeyValueIntersectSetMutation = 3,
        NSKeyValueSetSetMutation = 4
    }

    public enum NSFetchRequestResultType : uint
    {
        NSManagedObjectResultType = 0,
        NSManagedObjectIDResultType = 1
    }

    public enum NSAttributeType : uint
    {
        NSUndefinedAttributeType = 0,
        NSInteger16AttributeType = 100,
        NSInteger32AttributeType = 200,
        NSInteger64AttributeType = 300,
        NSDecimalAttributeType = 400,
        NSDoubleAttributeType = 500,
        NSFloatAttributeType = 600,
        NSStringAttributeType = 700,
        NSBooleanAttributeType = 800,
        NSDateAttributeType = 900,
        NSBinaryDataAttributeType = 1000,
        NSTransformableAttributeType = 1800
    }

}
