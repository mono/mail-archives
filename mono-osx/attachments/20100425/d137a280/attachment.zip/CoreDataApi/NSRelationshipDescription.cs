using System;
using MonoMac.Foundation;

namespace MonoMac.CoreData
{

	[BaseType (typeof (NSPropertyDescription))]
	interface NSRelationshipDescription {

		//- (NSEntityDescription *)destinationEntity;
		[Export ("destinationEntity")]
		NSEntityDescription DestinationEntity { get; set; }

		//- (void)setDestinationEntity:(NSEntityDescription *)entity;
		[Export ("setDestinationEntity:")]
		void SetDestinationEntity (NSEntityDescription entity);

		//- (NSRelationshipDescription *)inverseRelationship;
		[Export ("inverseRelationship")]
		NSRelationshipDescription InverseRelationship { get; set; }

		//- (void)setInverseRelationship:(NSRelationshipDescription *)relationship;
		[Export ("setInverseRelationship:")]
		void SetInverseRelationship (NSRelationshipDescription relationship);

		//- (NSUInteger)maxCount;
		[Export ("maxCount")]
		uint MaxCount { get; set; }

		//- (void)setMaxCount:(NSUInteger)maxCount;
		[Export ("setMaxCount:")]
		void SetMaxCount (uint maxCount);

		//- (NSUInteger)minCount;
		[Export ("minCount")]
		uint MinCount { get; set; }

		//- (void)setMinCount:(NSUInteger)minCount;
		[Export ("setMinCount:")]
		void SetMinCount (uint minCount);

		//- (NSDeleteRule)deleteRule;
		[Export ("deleteRule")]
		NSDeleteRule DeleteRule { get; set; }

		//- (void)setDeleteRule:(NSDeleteRule)rule;
		[Export ("setDeleteRule:")]
		void SetDeleteRule (NSDeleteRule rule);

		//- (BOOL)isToMany;    
		[Export ("isToMany")]
		bool IsToMany { get; }

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (NSData *)versionHash;
		[Export ("versionHash")]
		NSData VersionHash { get; }

//#endif 
	}
}
