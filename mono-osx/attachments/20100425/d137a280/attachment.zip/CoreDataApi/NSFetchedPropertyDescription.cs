using System;
using MonoMac.Foundation;

namespace MonoMac.CoreData
{

	[BaseType (typeof (NSPropertyDescription))]
	interface NSFetchedPropertyDescription {

		//- (NSFetchRequest *)fetchRequest;
		[Export ("fetchRequest")]
		NSFetchRequest FetchRequest { get; set; }

		//- (void)setFetchRequest:(NSFetchRequest *)fetchRequest;
		[Export ("setFetchRequest:")]
		void SetFetchRequest (NSFetchRequest fetchRequest);

	}
}
