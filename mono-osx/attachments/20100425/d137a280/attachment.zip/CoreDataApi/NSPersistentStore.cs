using System;
using MonoMac.Foundation;

namespace MonoMac.CoreData
{

	[BaseType (typeof (NSObject))]
	interface NSPersistentStore {

		//+ (NSDictionary *)metadataForPersistentStoreWithURL:(NSURL *)url error:(NSError **)error;    
		[Static, Export ("metadataForPersistentStoreWithURL:error:")]
		NSDictionary MetadataForPersistentStoreWithURL (NSUrl url, NSError error);

		//+ (BOOL)setMetadata:(NSDictionary *)metadata forPersistentStoreWithURL:(NSURL*)url error:(NSError **)error;
		[Static, Export ("setMetadata:forPersistentStoreWithURL:error:")]
		bool SetMetadata (NSDictionary metadata, NSUrl url, NSError error);

		//- (id)initWithPersistentStoreCoordinator:(NSPersistentStoreCoordinator *)root configurationName:(NSString *)name URL:(NSURL *)url options:(NSDictionary *)options ;
		[Export ("initWithPersistentStoreCoordinator:configurationName:URL:options:")]
		NSPersistentStore InitWithPersistentStoreCoordinator (NSPersistentStoreCoordinator root, NSString name, NSUrl url, NSDictionary options);

		//- (NSPersistentStoreCoordinator*) persistentStoreCoordinator;
		[Export ("persistentStoreCoordinator")]
		NSPersistentStoreCoordinator PersistentStoreCoordinator { get; }

		//- (NSString *)configurationName; 
		[Export ("configurationName")]
		NSString ConfigurationName { get; }

		//- (NSDictionary *)options; 
		[Export ("options")]
		NSDictionary Options { get; }

		//- (NSURL *)URL;
		[Export ("URL")]
		NSUrl URL { get; set; }

		//- (void)setURL:(NSURL *)url;
		[Export ("setURL:")]
		void SetURL (NSUrl url);

		//- (NSString *)identifier;
		[Export ("identifier")]
		NSString Identifier { get; set; }

		//- (void)setIdentifier:(NSString *)identifier;
		[Export ("setIdentifier:")]
		void SetIdentifier (NSString identifier);

		//- (NSString *)type; 
		[Export ("type")]
		NSString Type { get; }

		//- (BOOL)isReadOnly;     
		[Export ("isReadOnly")]
		bool IsReadOnly { get; }

		//- (void)setReadOnly:(BOOL)flag;
		[Export ("setReadOnly:")]
		void SetReadOnly (bool flag);

		//- (NSDictionary *)metadata; 
		[Export ("metadata")]
		NSDictionary Metadata { get; set; }

		//- (void)setMetadata:(NSDictionary *)storeMetadata;
		[Export ("setMetadata:")]
		void SetMetadata (NSDictionary storeMetadata);

		//- (void)didAddToPersistentStoreCoordinator:(NSPersistentStoreCoordinator *)coordinator;
		[Export ("didAddToPersistentStoreCoordinator:")]
		void DidAddToPersistentStoreCoordinator (NSPersistentStoreCoordinator coordinator);

		//- (void)willRemoveFromPersistentStoreCoordinator:(NSPersistentStoreCoordinator *)coordinator; 
		[Export ("willRemoveFromPersistentStoreCoordinator:")]
		void WillRemoveFromPersistentStoreCoordinator (NSPersistentStoreCoordinator coordinator);

	}
}
