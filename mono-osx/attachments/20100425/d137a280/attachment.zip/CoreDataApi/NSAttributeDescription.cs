using System;
using MonoMac.Foundation;

namespace MonoMac.CoreData
{

	[BaseType (typeof (NSPropertyDescription))]
	interface NSAttributeDescription {

		//- (NSAttributeType)attributeType;
		[Export ("attributeType")]
		NSAttributeType AttributeType { get; set; }

		//- (void)setAttributeType:(NSAttributeType)type;
		[Export ("setAttributeType:")]
		void SetAttributeType (NSAttributeType type);

		//- (NSString *)attributeValueClassName;
		[Export ("attributeValueClassName")]
		NSString AttributeValueClassName { get; set; }

		//- (id)defaultValue;
		[Export ("defaultValue")]
		NSAttributeDescription DefaultValue { get; set; }

		//- (void)setDefaultValue:(id)value;    
		[Export ("setDefaultValue:")]
		void SetDefaultValue (IntPtr value);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (void)setAttributeValueClassName:(NSString *)className;
		[Export ("setAttributeValueClassName:")]
		void SetAttributeValueClassName (NSString className);

		//- (NSData *)versionHash;
		[Export ("versionHash")]
		NSData VersionHash { get; }

		//- (NSString *)valueTransformerName;
		[Export ("valueTransformerName")]
		NSString ValueTransformerName { get; set; }

		//- (void)setValueTransformerName:(NSString *)string;
		[Export ("setValueTransformerName:")]
		void SetValueTransformerName (NSString string1);

//#endif 
	}
}
