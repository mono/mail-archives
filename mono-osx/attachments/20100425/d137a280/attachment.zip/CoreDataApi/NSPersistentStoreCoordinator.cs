using System;
using MonoMac.Foundation;

namespace MonoMac.CoreData
{

	[BaseType (typeof (NSObject))]
	interface NSPersistentStoreCoordinator {

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//+ (NSDictionary *)registeredStoreTypes;
		[Static, Export ("registeredStoreTypes")]
		NSDictionary RegisteredStoreTypes { get; }

		//TODO+ (void)registerStoreClass:(Class)storeClass forStoreType:(NSString *)storeType;
		//[Static, Export ("registerStoreClass:forStoreType:")]
		//void RegisterStoreClass (Class storeClass, NSString storeType);

		//+ (NSDictionary *)metadataForPersistentStoreOfType:(NSString *)storeType URL:(NSURL *)url error:(NSError **)error; 
		[Static, Export ("metadataForPersistentStoreOfType:URL:error:")]
		NSDictionary MetadataForPersistentStoreOfType (NSString storeType, NSUrl url, NSError error);

		//+ (BOOL)setMetadata:(NSDictionary *)metadata forPersistentStoreOfType:(NSString *)storeType URL:(NSURL*)url error:(NSError **)error;
		[Static, Export ("setMetadata:forPersistentStoreOfType:URL:error:")]
		bool SetMetadata (NSDictionary metadata, NSString storeType, NSUrl url, NSError error);

//#endif 
		//- (void)setMetadata:(NSDictionary *)metadata forPersistentStore:(NSPersistentStore *)store;    
		[Export ("setMetadata:forPersistentStore:")]
		void SetMetadata (NSDictionary metadata, NSPersistentStore store);

		//- (NSDictionary *)metadataForPersistentStore:(NSPersistentStore *)store;    
		[Export ("metadataForPersistentStore:")]
		NSDictionary MetadataForPersistentStore (NSPersistentStore store);

		//- (id)initWithManagedObjectModel:(NSManagedObjectModel *)model;
		[Export ("initWithManagedObjectModel:")]
		NSPersistentStoreCoordinator InitWithManagedObjectModel (NSManagedObjectModel model);

		//- (NSManagedObjectModel *)managedObjectModel;
		[Export ("managedObjectModel")]
		NSManagedObjectModel ManagedObjectModel { get; }

		//- (NSArray *)persistentStores;
		[Export ("persistentStores")]
		NSArray PersistentStores { get; }

		//- (NSPersistentStore *)persistentStoreForURL:(NSURL *)URL;
		[Export ("persistentStoreForURL:")]
		NSPersistentStore PersistentStoreForURL (NSUrl URL);

		//- (NSURL *)URLForPersistentStore:(NSPersistentStore *)store;
		[Export ("URLForPersistentStore:")]
		NSUrl URLForPersistentStore (NSPersistentStore store);

//#if MAC_OS_X_VERSION_MAX_ALLOWED >= MAC_OS_X_VERSION_10_5
		//- (BOOL)setURL:(NSURL*)url forPersistentStore:(NSPersistentStore *)store;    
		[Export ("setURL:forPersistentStore:")]
		bool SetURL (NSUrl url, NSPersistentStore store);

//#endif 
		//- (NSPersistentStore *)addPersistentStoreWithType:(NSString *)storeType configuration:(NSString *)configuration URL:(NSURL *)storeURL options:(NSDictionary *)options error:(NSError **)error;    
		[Export ("addPersistentStoreWithType:configuration:URL:options:error:")]
		NSPersistentStore AddPersistentStoreWithType (NSString storeType, NSString configuration, NSUrl storeURL, NSDictionary options, NSError error);

		//- (BOOL)removePersistentStore:(NSPersistentStore *)store error:(NSError **)error;
		[Export ("removePersistentStore:error:")]
		bool RemovePersistentStore (NSPersistentStore store, NSError error);

		//- (NSPersistentStore *)migratePersistentStore:(NSPersistentStore *)store toURL:(NSURL *)URL options:(NSDictionary *)options withType:(NSString *)storeType error:(NSError **)error;    
		[Export ("migratePersistentStore:toURL:options:withType:error:")]
		NSPersistentStore MigratePersistentStore (NSPersistentStore store, NSUrl URL, NSDictionary options, NSString storeType, NSError error);

		//- (NSManagedObjectID *)managedObjectIDForURIRepresentation:(NSURL *)url;    
		[Export ("managedObjectIDForURIRepresentation:")]
		NSManagedObjectID ManagedObjectIDForURIRepresentation (NSUrl url);

		//- (void)lock;
		[Export ("lock")]
		void Lock ();

		//- (void)unlock;
		[Export ("unlock")]
		void Unlock ();

		//- (BOOL)tryLock;
		[Export ("tryLock")]
		bool TryLock { get; }

		//+ (NSDictionary *)metadataForPersistentStoreWithURL:(NSURL *)url error:(NSError **)error DEPRECATED_IN_MAC_OS_X_VERSION_10_5_AND_LATER;
		[Static, Export ("metadataForPersistentStoreWithURL:error:")]
		NSDictionary MetadataForPersistentStoreWithURL (NSUrl url, NSError error);

	}
}
