using System;
using MonoMac.Foundation;

namespace MonoMac.CoreData
{

	[BaseType (typeof (NSObject))]
	interface NSEntityMapping {

		//- (NSString *)name;
		[Export ("name")]
		NSString Name { get; set; }

		//- (void)setName:(NSString *)name;
		[Export ("setName:")]
		void SetName (NSString name);

		//- (NSEntityMappingType)mappingType;
		[Export ("mappingType")]
		NSEntityMappingType MappingType { get; set; }

		//- (void)setMappingType:(NSEntityMappingType)type;
		[Export ("setMappingType:")]
		void SetMappingType (NSEntityMappingType type);

		//- (NSString *)sourceEntityName;
		[Export ("sourceEntityName")]
		NSString SourceEntityName { get; set; }

		//- (void)setSourceEntityName:(NSString *)name;
		[Export ("setSourceEntityName:")]
		void SetSourceEntityName (NSString name);

		//- (NSData *)sourceEntityVersionHash;
		[Export ("sourceEntityVersionHash")]
		NSData SourceEntityVersionHash { get; set; }

		//- (void)setSourceEntityVersionHash:(NSData *)vhash;
		[Export ("setSourceEntityVersionHash:")]
		void SetSourceEntityVersionHash (NSData vhash);

		//- (NSString *)destinationEntityName;
		[Export ("destinationEntityName")]
		NSString DestinationEntityName { get; set; }

		//- (void)setDestinationEntityName:(NSString *)name;
		[Export ("setDestinationEntityName:")]
		void SetDestinationEntityName (NSString name);

		//- (NSData *)destinationEntityVersionHash;
		[Export ("destinationEntityVersionHash")]
		NSData DestinationEntityVersionHash { get; set; }

		//- (void)setDestinationEntityVersionHash:(NSData *)vhash;
		[Export ("setDestinationEntityVersionHash:")]
		void SetDestinationEntityVersionHash (NSData vhash);

		//- (NSArray *)attributeMappings;
		[Export ("attributeMappings")]
		NSArray AttributeMappings { get; set; }

		//- (void)setAttributeMappings:(NSArray *)mappings;
		[Export ("setAttributeMappings:")]
		void SetAttributeMappings (NSArray mappings);

		//- (NSArray *)relationshipMappings;
		[Export ("relationshipMappings")]
		NSArray RelationshipMappings { get; set; }

		//- (void)setRelationshipMappings:(NSArray *)mappings;
		[Export ("setRelationshipMappings:")]
		void SetRelationshipMappings (NSArray mappings);

		//- (NSExpression *)sourceExpression;
		[Export ("sourceExpression")]
		NSExpression SourceExpression { get; set; }

		//- (void)setSourceExpression:(NSExpression *)source;
		[Export ("setSourceExpression:")]
		void SetSourceExpression (NSExpression source);

		//- (NSDictionary *)userInfo;
		[Export ("userInfo")]
		NSDictionary UserInfo { get; set; }

		//- (void)setUserInfo:(NSDictionary *)dict;
		[Export ("setUserInfo:")]
		void SetUserInfo (NSDictionary dict);

		//- (NSString *)entityMigrationPolicyClassName;
		[Export ("entityMigrationPolicyClassName")]
		NSString EntityMigrationPolicyClassName { get; set; }

		//- (void)setEntityMigrationPolicyClassName:(NSString *)name;
		[Export ("setEntityMigrationPolicyClassName:")]
		void SetEntityMigrationPolicyClassName (NSString name);

	}
}
