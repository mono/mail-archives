using System;
using MonoMac.Foundation;

namespace MonoMac.CoreData
{

	[BaseType (typeof (NSPersistentStore))]
	interface NSAtomicStore {

		//- (id)initWithPersistentStoreCoordinator:(NSPersistentStoreCoordinator *)coordinator configurationName:(NSString *)configurationName URL:(NSURL *)url options:(NSDictionary *)options;
		[Export ("initWithPersistentStoreCoordinator:configurationName:URL:options:")]
		NSAtomicStore InitWithPersistentStoreCoordinator (NSPersistentStoreCoordinator coordinator, NSString configurationName, NSUrl url, NSDictionary options);

		//- (BOOL)load:(NSError **)error;
		[Export ("load:")]
		bool Load (NSError error);

		//- (BOOL)save:(NSError **)error;
		[Export ("save:")]
		bool Save (NSError error);

		//- (NSAtomicStoreCacheNode *)newCacheNodeForManagedObject:(NSManagedObject *)managedObject;
		[Export ("newCacheNodeForManagedObject:")]
		NSAtomicStoreCacheNode NewCacheNodeForManagedObject (NSManagedObject managedObject);

		//- (void)updateCacheNode:(NSAtomicStoreCacheNode *)node fromManagedObject:(NSManagedObject *)managedObject;
		[Export ("updateCacheNode:fromManagedObject:")]
		void UpdateCacheNode (NSAtomicStoreCacheNode node, NSManagedObject managedObject);

		//- (NSSet *)cacheNodes;
		[Export ("cacheNodes")]
		NSSet CacheNodes { get; }

		//- (void)addCacheNodes:(NSSet *)cacheNodes;
		[Export ("addCacheNodes:")]
		void AddCacheNodes (NSSet cacheNodes);

		//- (void)willRemoveCacheNodes:(NSSet *)cacheNodes;
		[Export ("willRemoveCacheNodes:")]
		void WillRemoveCacheNodes (NSSet cacheNodes);

		//- (NSAtomicStoreCacheNode *)cacheNodeForObjectID:(NSManagedObjectID *)objectID;
		[Export ("cacheNodeForObjectID:")]
		NSAtomicStoreCacheNode CacheNodeForObjectID (NSManagedObjectID objectID);

		//- (NSManagedObjectID *)objectIDForEntity:(NSEntityDescription *)entity referenceObject:(id)data;
		[Export ("objectIDForEntity:referenceObject:")]
		NSManagedObjectID ObjectIDForEntity (NSEntityDescription entity, IntPtr data);

		//- (id)newReferenceObjectForManagedObject:(NSManagedObject *)managedObject;
		[Export ("newReferenceObjectForManagedObject:")]
		NSAtomicStore NewReferenceObjectForManagedObject (NSManagedObject managedObject);

		//- (id)referenceObjectForObjectID:(NSManagedObjectID *)objectID;
		[Export ("referenceObjectForObjectID:")]
		NSAtomicStore ReferenceObjectForObjectID (NSManagedObjectID objectID);

	}
}
