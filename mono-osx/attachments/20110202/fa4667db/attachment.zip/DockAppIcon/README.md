DockAppIcon
============

Shows the use of the NSDockTile.

- Adding a badge to the icon in the Dock 
	Provides a setting to add a custom format
- Manipulating the Application Badge 
- Getting the users attention: Informational and Critical 
	To see the request for attention you will need to use the Request Button
	and then move away from this application by activating another application within 3 seconds.
	The requests only work if the requesting application is not the active application.

Author
======
Kenneth J. Pouncey 2011/02/01

Changes
=======
Version 1.0 - 2011/02/01