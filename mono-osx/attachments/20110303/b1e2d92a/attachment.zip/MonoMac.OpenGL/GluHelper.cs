﻿//
// The Open Toolkit Library License
//
// Copyright (c) 2006 - 2010 the Open Toolkit library.
// Contributions by Andy Gill.
// Copyright c) 2011 Kenneth Pouncey
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights to 
// use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
// the Software, and to permit persons to whom the Software is furnished to do
// so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
// OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
// NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
// HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
// WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
// FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
// OTHER DEALINGS IN THE SOFTWARE.
 
namespace MonoMac.OpenGL 
{

using System.Collections;
using System.Collections.Generic; 
using System.Text; 
using System.Reflection; 
using System.Runtime.InteropServices; 
using System.Reflection.Emit; 
	
    public static partial class Glu 
    { 
        private const string Library = "/System/Library/Frameworks/OpenGL.framework/OpenGL";
 
        static Glu() 
        { 
        } 

        #region Overloads 
 
        public static void LookAt(Vector3 eye, Vector3 center, Vector3 up) 
        { 
            GluCore.LookAt((double)eye.X, (double)eye.Y, (double)eye.Z, (double)center.X, (double)center.Y, (double)center.Z, (double)up.X, (double)up.Y, (double)up.Z); 
        } 
 
        // One token Project overload, I picked this one because it's CLS compliant, and it 
        // makes reasonably clear which args are inputs and which are outputs. 
        public static Int32 Project(Vector3 obj, double[] model, double[] proj, Int32[] view, out Vector3 win) 
        { 
            unsafe 
            { 
                double winX, winY, winZ; 
                double* winX_ptr = &winX; 
                double* winY_ptr = &winY; 
                double* winZ_ptr = &winZ; 
                fixed (double* model_ptr = model) 
                fixed (double* proj_ptr = proj) 
                fixed (Int32* view_ptr = view) 
                { 
                    Int32 retval = GluCore.Project((double)obj.X, (double)obj.Y, (double)obj.Z, (double*)model_ptr, (double*)proj_ptr, (Int32*)view_ptr, (double*)winX_ptr, (double*)winY_ptr, (double*)winZ_ptr); 
                    win = new Vector3((float)*winX_ptr, (float)*winY_ptr, (float)*winZ_ptr); 
                    return retval; 
                } 
            } 
        } 
 
        public static void TessNormal(IntPtr tess, Vector3 normal) 
        { 
            GluCore.TessNormal(tess, (double)normal.X, (double)normal.Y, (double)normal.Z); 
        } 
 
        public static Int32 UnProject(Vector3 win, double[] model, double[] proj, Int32[] view, out Vector3 obj) 
        { 
            unsafe 
            { 
                double objX, objY, objZ; 
                double* objX_ptr = &objX; 
                double* objY_ptr = &objY; 
                double* objZ_ptr = &objZ; 
                fixed (double* model_ptr = model) 
                fixed (double* proj_ptr = proj) 
                fixed (Int32* view_ptr = view) 
                { 
                    Int32 retval = GluCore.UnProject((double)win.X, (double)win.Y, (double)win.Z, (double*)model_ptr, (double*)proj_ptr, (Int32*)view_ptr, (double*)objX_ptr, (double*)objY_ptr, (double*)objZ_ptr); 
                    obj = new Vector3((float)*objX_ptr, (float)*objY_ptr, (float)*objZ_ptr); 
                    return retval; 
                } 
            } 
        } 
 
        public static Int32 UnProject4(Vector4 win, double[] model, double[] proj, Int32[] view, double near, double far, out Vector4 obj) 
        { 
            unsafe 
            { 
                double objX, objY, objZ, objW; 
                double* objX_ptr = &objX; 
                double* objY_ptr = &objY; 
                double* objZ_ptr = &objZ; 
                double* objW_ptr = &objW; 
                fixed (double* model_ptr = model) 
                fixed (double* proj_ptr = proj) 
                fixed (Int32* view_ptr = view) 
                { 
                    Int32 retval = GluCore.UnProject4((double)win.X, (double)win.Y, (double)win.Z, (double)win.W, (double*)model_ptr, (double*)proj_ptr, (Int32*)view_ptr, (double)near, (double)far, (double*)objX_ptr, (double*)objY_ptr, (double*)objZ_ptr, (double*)objW_ptr); 
                    obj = new Vector4((float)*objX_ptr, (float)*objY_ptr, (float)*objZ_ptr, (float)*objW_ptr); 
                    return retval; 
                } 
            } 
        } 
 
        public static string ErrorString(ErrorCode error) 
        { 
            return ErrorString((GluErrorCode)error); 
        } 
 
        public static void TessWindingRuleProperty(IntPtr tess, TessWinding property) 
        { 
            Glu.TessProperty(tess, TessParameter.TessWindingRule, (double)property); 
        } 
 
        #endregion 
 
    } 
 
} 

 
