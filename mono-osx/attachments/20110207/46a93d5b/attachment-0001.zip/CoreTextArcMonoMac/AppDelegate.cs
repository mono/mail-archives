using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.AppKit;

namespace CoreTextArcMonoMac
{
        public partial class AppDelegate : NSApplicationDelegate
        {
                public AppDelegate ()
                {
                }

                public override void FinishedLaunching (NSObject notification)
                {
                        // You can put any code here after your app launched.
                }
        }
}

