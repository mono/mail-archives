using System;

class App {
    static void Main() {
        int;   // errors are detected
        int x; // warning are detected
        Console.WriteLine("Hello, Xcode");
    }
}
