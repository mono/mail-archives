// 
// ExternalFrameworkNode.cs
//  
// Author:
//       dwandless <${AuthorEmail}>
// 
// Copyright (c) 2011 dwandless
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.
using System.IO;
using MonoDevelop.Projects;
using MonoDevelop.Core.Serialization;

namespace MonoDevelop.MonoMac
{
	public class ExternalFrameworkNode : ProjectItem
	{
		internal string Name;
		private string fullPath;
		[ItemProperty ("Include")]
		internal string FullPath 
		{
			get { return fullPath; }
			set
			{
				fullPath = value;
				Name = Path.GetFileName (fullPath);
			}
		}
		internal MonoMacProject Project;
		[ItemProperty ("Relative")]
		internal bool Relatve;
		
		public ExternalFrameworkNode ()
		{
		}
		
		public ExternalFrameworkNode (string path, MonoMacProject project)
		{
			FullPath = path;
			Project = project;
		}
	}
	
	public class ExternalFrameworksFolder
	{
		internal MonoMacProject project;
		
		public ExternalFrameworksFolder (MonoMacProject proj)
		{
			project = proj;
		}
	}
}

