using System;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.AppKit;
using MonoMac.ObjCRuntime;
using OpenTK;

namespace OpenGLScreenSnapshot
{
        class MainClass
        {
                static void Main (string[] args)
                {
                        const string OpenGLLibrary = "/System/Library/Frameworks/OpenGL.framework/OpenGL";
                        const string AGLLibrary = "/System/Library/Frameworks/AGL.framework/Versions/Current/AGL";
                        
                        IntPtr openGl = Dlfcn.dlopen (OpenGLLibrary, 1);
                        if (openGl == IntPtr.Zero)
                                Console.WriteLine (Dlfcn.dlerror ());
                        IntPtr appleGl = Dlfcn.dlopen (AGLLibrary, 1);
                        if (appleGl == IntPtr.Zero)
                                Console.WriteLine (Dlfcn.dlerror ());
                        OpenTK.Toolkit.Init();
                        NSApplication.Init ();
                        NSApplication.Main (args);
                }
        }
}

