//
//  
//  �PROJECTNAME�
//
//  Created by �FULLUSERNAME� on �DATE�.
//  Copyright �YEAR� �ORGANIZATIONNAME�. All rights reserved.
//
//

using System;
using System.Collections.Generic;
using System.Text;
using Cocoa;

namespace �PROJECTNAME�
{
	class �PROJECTNAME�
	{
        static void Main(string[] args) 
        {
            �PROJECTNAME� main = new �PROJECTNAME�();
            main.Run();
        }

        public void Run() 
        {
            Application.Init();
            Application.LoadNib("Main.nib");
            Application.Run();
        }
    }
}
