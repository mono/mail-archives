
using System;
using System.Collections.Generic;
using System.Linq;
using System.Drawing;
using MonoMac.Foundation;
using MonoMac.AppKit;

namespace CallSuper
{
	public partial class BaseView : MonoMac.AppKit.NSView
	{
		
		#region Constructors

		// Called when created from unmanaged code
		public BaseView (IntPtr handle) : base(handle)
		{
			Initialize ();
		}

		// Called when created directly from a XIB file
		[Export("initWithCoder:")]
		public BaseView (NSCoder coder) : base(coder)
		{
			Initialize ();
		}
		
		[Export("initWithFrame:")]
		public BaseView (RectangleF frame) : base (frame)
		{
			Console.WriteLine("initWithFrame:");	
		}
		// Shared initialization code
		void Initialize ()
		{
		}
		
		#endregion
		
		public override bool AcceptsFirstResponder ()
		{
			return true;
		}
		
	}
}

