WhereIsMyMac
============

Shows the use of the CoreLocation API.

Converted to Mono and C# by:  Kenneth J. Pouncey 2011/01/01

For a full description of the program and the original article point your browser here:
http://cocoawithlove.com/2009/09/whereismymac-snow-leopard-corelocation.html
