
using System;
using System.Collections.Generic;
using System.Linq;
using MonoMac.Foundation;
using MonoMac.AppKit;

namespace PopupBindings
{
	public partial class TestWindowController : MonoMac.AppKit.NSWindowController
	{
		
		internal const string NAME = "name";
		internal const string AGE = "age";
		internal const string ADDRESS_STREET = "addressStreet";
		internal const string ADDRESS_CITY = "addressCity";
		internal const string ADDRESS_STATE = "addressState";
		internal const string ADDRESS_ZIP = "addressZip";

		#region Constructors

		// Called when created from unmanaged code
		public TestWindowController (IntPtr handle) : base(handle)
		{
			Initialize ();
		}

		// Called when created directly from a XIB file
		[Export("initWithCoder:")]
		public TestWindowController (NSCoder coder) : base(coder)
		{
			Initialize ();
		}

		// Call to load from the XIB/NIB file
		public TestWindowController () : base("TestWindow")
		{
			Initialize ();
		}

		// Shared initialization code
		void Initialize ()
		{
		}

		#endregion

		//strongly typed window accessor
		public new TestWindow Window {
			get { return (TestWindow)base.Window; }
		}
		
		public override void AwakeFromNib ()
		{
			//base.AwakeFromNib ();
			
			var personVal = new Person("Joe Smith",21,"451 University Avenue","Palo Alto",
			                              "CA","94301");
			arrayController.AddObject(personVal);			


			personVal = new Person("John Doe", 31, "767 Fifth Ave.","New York","NY","10153");
			arrayController.AddObject(personVal);			

			personVal = new Person("Sally Sixpack",41,"679 North Michigan Ave.","Chicago","IL","60611");
			arrayController.AddObject(personVal);	

			personVal = new Person("John Q. Public",141,"5085 Westheimer Rd.","Houston","TX","77056");
			arrayController.AddObject(personVal);	

			// select the first popup menu item
			arrayController.SelectionIndex = 0;
		}

	}
}

