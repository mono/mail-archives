using System;
using System.Collections.Generic;
using System.Linq;
using MonoMac.Foundation;
using MonoMac.AppKit;

namespace PopupBindings
{
	public partial class Person : NSObject
	{

		public Person (string name, int age, string addressStreet, string addressCity, string addressState, string addressZip)
		{
			Name = name;
			Age = age;
			AddressStreet = addressStreet;
			AddressCity = addressCity;
			AddressState = addressState;
			AddressZip = addressZip;
		}
		
		[Export("name")]
		public NSString name()
		{
			return new NSString(Name);
		}
		
		public string Name { get; set; }
		
		[Export("age")]
		public NSNumber age()
		{
			return NSNumber.FromInt32(Age);
		}
		
		public int Age { get; set; }
		
		// Get a value for a key.  Not using this method but instead
		//  used the [Export("xxxxxx")] method.
		//public override NSObject ValueForKey (NSString key)
		//{
		//	return attributeValues[key];
		//}
		
		public override void SetValueForKey (NSObject value, NSString key)
		{
			
			switch (key.ToString())
			{
			case TestWindowController.NAME:
				Name = (value == null) ? string.Empty : value.ToString();
				break;
			case TestWindowController.AGE:
				Age = (value == null) ? 0 : ((NSNumber)value).Int32Value;
				break;
			case TestWindowController.ADDRESS_STREET:
				AddressStreet = (value == null) ? string.Empty : value.ToString();
				break;
			case TestWindowController.ADDRESS_CITY:
				AddressCity = (value == null) ? string.Empty : value.ToString();
				break;
			case TestWindowController.ADDRESS_STATE:
				AddressState = (value == null) ? string.Empty : value.ToString();
				break;
			case TestWindowController.ADDRESS_ZIP:
				AddressZip = (value == null) ? string.Empty : value.ToString();
				break;
			default:				
				base.SetValueForKey(value, key);
				break;
			}
			
		}
		
		[Export("addressStreet")]
		public NSString addressStreet()
		{
			return new NSString(AddressStreet);
		}
		
		public string AddressStreet { get; set; }

		
		[Export("addressCity")]
		public NSString addressCity()
		{
			return new NSString(AddressCity);
		}		
		
		public string AddressCity { get; set; }


		[Export("addressState")]
		public NSString addressState()
		{
			return new NSString(AddressState);
		}	
		
		public string AddressState { get; set; }

		[Export("addressZip")]
		public NSString addressZip()
		{
			return new NSString(AddressZip);
		}	
		
		public string AddressZip { get; set; }
		
		
	}
}

