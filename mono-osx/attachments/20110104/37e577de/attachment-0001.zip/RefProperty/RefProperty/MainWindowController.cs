
using System;
using System.Collections.Generic;
using System.Linq;
using MonoMac.Foundation;
using MonoMac.AppKit;

namespace RefProperty
{
	public partial class MainWindowController : MonoMac.AppKit.NSWindowController
	{
		#region Constructors

		// Called when created from unmanaged code
		public MainWindowController (IntPtr handle) : base(handle)
		{
			Initialize ();
		}

		// Called when created directly from a XIB file
		[Export("initWithCoder:")]
		public MainWindowController (NSCoder coder) : base(coder)
		{
			Initialize ();
		}

		// Call to load from the XIB/NIB file
		public MainWindowController () : base("MainWindow")
		{
			Initialize ();
		}

		// Shared initialization code
		void Initialize ()
		{
		}

		#endregion

		//strongly typed window accessor
		public new MainWindow Window {
			get { return (MainWindow)base.Window; }
		}
		
		public override void AwakeFromNib ()
		{
			// uncomment to test event handler and comment out the next line
			//dateField.ValidateProposedDateValue += HandleDateFieldValidateProposedDateValue;
			
			// to test event handler
			// comment out this line and uncomment the line for event handler above
			// ass well as the line [Export("datePickerCell:validateProposedDateValue:timeInterval:")]
			dateField.WeakDelegate = this;
		}

		void HandleDateFieldValidateProposedDateValue (object sender, NSDatePickerValidatorEventArgs e)
		{
			Console.WriteLine("Before Propsed Date Value " + e.ProposedDateValue + " Overriding to " + DateTime.Now);
			e.ProposedDateValue = DateTime.Now;
			Console.WriteLine("After Propsed Date Value " + e.ProposedDateValue + " Overriding to " + DateTime.Now);
			
		}
		
                [Export("datePickerCell:validateProposedDateValue:timeInterval:")]
                void ValidateProposedDateValue (NSDatePickerCell aDatePickerCell, ref NSDate proposedDateValue, double proposedTimeInterval)
                {
			Console.WriteLine("Before Propsed Date Value " + proposedDateValue + " Overriding to " + DateTime.Now);
			proposedDateValue = DateTime.Now;
			Console.WriteLine("After Propsed Date Value " + proposedDateValue + " Overriding to " + DateTime.Now);
                }
		
		partial void btnSetToday (NSObject sender)
		{
			dateField.DateValue = DateTime.Now;
		}
	}
}

