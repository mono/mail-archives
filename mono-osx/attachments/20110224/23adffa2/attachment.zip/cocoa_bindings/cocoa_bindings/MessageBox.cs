using System;
using MonoMac.Foundation;
using MonoMac.AppKit;
namespace cocoa_bindings
{
	public static class MessageBox
	{
		public static void Show(String msg)
		{
			NSAlert a = new NSAlert();
			a.MessageText = msg;
			a.RunModal();			
		}
	}
}

