using System;
using MonoMac.Foundation;
namespace cocoa_bindings
{
    public class Player : NSObject
    {
		private NSNumber _uid;
		private NSString _fname;
		private NSString _lname;
		private NSNumber _age;
		
        public Player(int uid, string fname, string lname, int age)
        {
			this._uid = NSNumber.FromInt32(uid);
			this._age = NSNumber.FromInt32(age);
			this._fname = new NSString(fname);
			this._lname = new NSString(lname);
		}
        
		[Export("UID")]
        public virtual NSNumber UID
        {
            get 
			{
				return _uid;
			}
			set
			{
				_uid = value;
				MessageBox.Show("UID 'saved'..");
			}
        }
        	
		[Export("FirstName")]
        public virtual NSString FirstName
        {
            get 
			{  
				return _fname;
			}
            set
            {
				_fname = value;
				MessageBox.Show("FirstName 'saved'..");
            }
        }

		[Export("LastName")]
        public virtual NSString LastName
        {
            get 
			{  
				return _lname;
			}
            set
            {
				_lname = value;
				MessageBox.Show("LastName 'saved'..");
            }
        }
		
		[Export("Age")]
        public virtual NSNumber Age
        {
            get 
			{
				return _age;
			}
			set
			{
				_age = value;
				MessageBox.Show("Age 'saved'..");
			}
        }		
	}
}

