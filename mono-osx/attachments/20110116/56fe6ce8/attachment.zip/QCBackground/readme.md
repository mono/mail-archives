QCBackground
============

Converted to Mono and C# by:  Kenneth J. Pouncey 2010/12/28

For a full description of the program you will have to buy the book:

Core Animation for Mac OS X and the iPhone: Creating Compelling Dynamic User Interfaces

by Bill Dudney

You can purchase your copy here:

http://www.pragprog.com/titles/bdcora/core-animation-for-mac-os-x-and-the-iphone
http://www.pragprog.com
