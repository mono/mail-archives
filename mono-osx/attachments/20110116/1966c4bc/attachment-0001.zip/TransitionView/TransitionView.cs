
using System;
using System.Collections.Generic;
using System.Linq;
using System.Drawing;

using MonoMac.Foundation;
using MonoMac.AppKit;
using MonoMac.CoreAnimation;
using MonoMac.CoreGraphics;

namespace TransitionView
{
	public partial class TransitionView : MonoMac.AppKit.NSView
	{
		NSImageView beach;
		NSImageView snow;
		static bool done = false;
		#region Constructors
		// Called when created from unmanaged code
		public TransitionView (IntPtr handle) : base(handle)
		{
			//Initialize ();
		}

		// Called when created directly from a XIB file
		[Export("initWithCoder:")]
		public TransitionView (NSCoder coder) : base(coder)
		{
			//Initialize ();
		}


		// Called when created directly from a XIB file
		[Export("initWithFrame:")]
		public TransitionView (RectangleF frame) : base(frame)
		{
			Console.WriteLine("init" + done);
			AddSubview(Beach);
		}

		// Shared initialization code
		void Initialize ()
		{
		
			
		}

		#endregion
		
//		public override void AwakeFromNib ()
//		{
//			AddSubview(Snow);
//		}
		
		public override bool AcceptsFirstResponder ()
		{
			return true;
		}
		
		public override void KeyDown (NSEvent theEvent)
		{
			if (Beach.Superview != null) 
			{
				Console.WriteLine("beach with snow");
				//this.ReplaceSubviewWith(Beach, Snow);
				((NSView)Animator).ReplaceSubviewWith(Beach,Snow);
			}
			else if (Snow.Superview != null) 
			{
				Console.WriteLine("snow with beach");
				//this.ReplaceSubviewWith(Snow,Beach);
				((NSView)Animator).ReplaceSubviewWith(Snow,Beach);
			}
		}
		
		private NSImageView Beach
		{
			get 
			{
				if (beach == null)
					beach = imageViewForImageNamed("beach.jpg");
				return beach;
			}
		}
		
		private NSImageView Snow
		{
			get
			{
				if (snow == null)
					snow = imageViewForImageNamed("snow.jpg");
				return snow;
			}
				
				
		}
		
		private NSImageView imageViewForImageNamed(string imageName)
		{
			float xInset = 0.125f * Frame.Width;
			float yInset = 0.125f * Frame.Height;
			RectangleF subFrame = Frame.Inset(xInset, yInset);
			PointF origin = subFrame.Location;
			origin.X = Bounds.GetMidX() - subFrame.Width / 2.0f;
			origin.Y = Bounds.GetMidY() - subFrame.Height / 2.0f;
			subFrame.Location = origin;
			NSImageView imageView = new NSImageView(subFrame);
			imageView.ImageScaling = NSImageScale.AxesIndependently;
			imageView.Image = NSImage.ImageNamed(imageName);
			return imageView;
		}
	}
}

