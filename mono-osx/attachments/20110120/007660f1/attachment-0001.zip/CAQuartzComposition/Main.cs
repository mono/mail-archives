using System;
using MonoMac.AppKit;

namespace CAQuartzComposition
{
	class MainClass
	{
		static void Main (string[] args)
		{
			NSApplication.Init ();
			NSApplication.Main (args);
		}
	}
}

