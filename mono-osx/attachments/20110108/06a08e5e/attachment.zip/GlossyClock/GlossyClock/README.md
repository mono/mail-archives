GlossyClock
============

Shows the use of the CoreAnimation Layers API and KVO bindings.

Converted to Mono and C# by:  Kenneth J. Pouncey 2011/01/04

For a full description of the program and the original article point your browser here:
http://simplyhacking.com/core-animation-layered-clock.html
