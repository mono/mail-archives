
using System;
using System.Collections.Generic;
using System.Linq;
using System.Drawing;
using System.Timers;

using MonoMac.Foundation;
using MonoMac.AppKit;
using MonoMac.CoreAnimation;
using MonoMac.CoreGraphics;

namespace GlossyClock
{
	public partial class ClockView : MonoMac.AppKit.NSView
	{
		
		CALayer backgroundLayer;
		CATextLayer clockFaceLayer;
		ClockTimer clockTimer;
		
		#region Constructors

		// Called when created from unmanaged code
		public ClockView (IntPtr handle) : base(handle)
		{
			Initialize ();
		}

		// Called when created directly from a XIB file
		[Export("initWithCoder:")]
		public ClockView (NSCoder coder) : base(coder)
		{
			Initialize ();
		}

		// Shared initialization code
		void Initialize ()
		{
			clockTimer = new ClockTimer();
			
			this.Layer = setupLayers();

		}
		
		#endregion
		
		public override void AwakeFromNib ()
		{
			this.WantsLayer = true;
		}
		
		private CALayer setupLayers()
		{
			backgroundLayer = setupBackgroundLayer();
			
			backgroundLayer.AddSublayer(setupClockFaceLayer());
			backgroundLayer.AddSublayer(setupBorderLayer());
			backgroundLayer.AddSublayer(setupGlossyLayer());

			return backgroundLayer;
		}
		
		private CALayer setupBackgroundLayer() 
		{
			backgroundLayer = new CAGradientLayer();
			
			CGColor gradColor1 = new CGColor(13.0f / 255.0f, 116.0f / 255.0f, 1.0f,1.0f);
			CGColor gradColor2 = new CGColor(0.0f, 53.0f / 255.0f, 126.0f / 255.0f,1.0f);
			
			((CAGradientLayer)backgroundLayer).Colors = new CGColor[2] {gradColor1,gradColor2};
			
			backgroundLayer.CornerRadius = 12.0f;
			
			CAConstraintLayoutManager layout = CAConstraintLayoutManager.LayoutManager;
			
			backgroundLayer.LayoutManager = layout;
			
			return backgroundLayer;
		}
		
		private CALayer setupBorderLayer()
		{
			CALayer borderLayer = CALayer.Create();
			
			RectangleF borderRect = Frame.Inset(8.0f, 8.0f);
			borderLayer.CornerRadius = 12.0f;
			borderLayer.BorderColor = new CGColor(1.0f,1.0f,1.0f,1.0f);
			borderLayer.BorderWidth = 2.0f;
			borderLayer.Frame = borderRect;
			
			return borderLayer;
		}

		private CALayer setupClockFaceLayer()
		{
			clockFaceLayer = new CATextLayer();
			
			clockFaceLayer.Bind("string",clockTimer,"outputString", null);
			
			clockFaceLayer.SetFont("Menlo");
			clockFaceLayer.FontSize = 60.0f;
			clockFaceLayer.ShadowOpacity = .9f;
			
			// Constrain the text layer in the middle
			CAConstraint constraint = CAConstraint.Create(CAConstraintAttribute.MidX, "superlayer", CAConstraintAttribute.MidX);
			clockFaceLayer.AddConstraint(constraint);
			
			constraint = CAConstraint.Create(CAConstraintAttribute.MidY, "superlayer", CAConstraintAttribute.MidY);
			
			clockFaceLayer.AddConstraint(constraint);
			return clockFaceLayer;
		}
		
		private CALayer setupGlossyLayer()
		{
			CALayer glossLayer = new CALayer();
			
			string filePath = NSBundle.MainBundle.PathForResource("clock-gloss","png");

			// Create the CGImage by proxying it through an NSImage
			var glossyImage = new NSImage(filePath).AsCGImage(RectangleF.Empty,null,null);
			glossLayer.Contents = glossyImage;
			
			glossLayer.Opacity = 0.8f;
			glossLayer.CornerRadius = 12.0f;
			glossLayer.MasksToBounds = true;
			glossLayer.Frame = this.Frame;
		
			return glossLayer;
		}
		
		
	}
}

