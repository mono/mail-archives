using System;
using Gtk;
namespace CairoBugDemo
{
    public partial class MainWindow : Gtk.Window
    {
        private System.Timers.Timer MyTimer { get; set;}
        public MainWindow () : base(Gtk.WindowType.Toplevel)
        {
            this.Build ();
            timecanvas.Initialize();
            MyTimer = new System.Timers.Timer(3000);
            MyTimer.Elapsed += TimerElapsedEvent;
            MyTimer.Start();
        }
        protected virtual void OnWindowDelete (object o, Gtk.DeleteEventArgs args)
        {
            MyTimer.Elapsed -= TimerElapsedEvent;
            Application.Quit();
        }
        
        private void TimerElapsedEvent(object sender, EventArgs e){
            Application.Invoke(delegate
                                   {
                                        timecanvas.HandlePropertyChange();
                                   });
        }
    }
}

