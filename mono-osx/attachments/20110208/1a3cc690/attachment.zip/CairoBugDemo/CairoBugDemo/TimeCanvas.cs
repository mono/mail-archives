#region Using Directives

using System;
using System.ComponentModel;
using Cairo;
using Gdk;
using Gtk;
using Color = Gdk.Color;
using Rectangle = Cairo.Rectangle;

#endregion

namespace CairoBugDemo
{
    [ToolboxItem(true)]
    public class TimeCanvas : DrawingArea
    {
        #region Members and Properties

        private int MyMinAmplitudeLabelValue { get; set; }
        private int MyMaxAmplitudeLabelValue { get; set; }
        private int MyMinAmplitudeValue { get; set; }
        private int MyMaxAmplitudeValue { get; set; }
        private int MyAmplitudeTotalCount { get; set; }

        private const int AxisTitleFontSize = 13;

        private const int MyAmplitudeDifference = 10;
        private const int XLabelTopMargin = 20;

        private double MyAmplitudeDifferencePoints
        {
            get { return MyActualViewRect.Height/MyAmplitudeTotalCount; }
        }

        private double MyPixelsPerSecond
        {
            get { return MyActualViewRect.Width/MyTimeSpan.TotalSeconds; }
        }

        private int MyActualViewWidth { get; set; }
        private int MyActualViewHeight { get; set; }

        private int MyGraphMargin { get; set; }

        private Rectangle MyActualViewRect { get; set; }

        private DateTime _myMaxTime;

        private DateTime MyMaxTime
        {
            get { return _myMaxTime; }
            set
            {
                _myMaxTime = value;
                MyMinTime = _myMaxTime - MyTimeSpan;
            }
        }

        private DateTime MyMinTime { get; set; }

        private static TimeSpan _myTimeSpan;

        private TimeSpan MyTimeSpan
        {
            get { return _myTimeSpan; }
            set
            {
                _myTimeSpan = value;
                MyMinTime = MyMaxTime - _myTimeSpan;
            }
        }

        private static readonly TimeSpan MySecsPerTick = TimeSpan.FromSeconds(60);

        #endregion

        #region Events and Callbacks

        protected override bool OnExposeEvent(EventExpose ev)
        {
            base.OnExposeEvent(ev);

            Context g = CairoHelper.Create(GdkWindow);
            DrawFramework(g);
            ((IDisposable) g.Target).Dispose();
            ((IDisposable) g).Dispose();
            return true;
        }

        protected override void OnSizeAllocated(Gdk.Rectangle allocation)
        {
            base.OnSizeAllocated(allocation);

            MyActualViewHeight = allocation.Height;
            MyActualViewWidth = allocation.Width;
        }

        #endregion

        #region Constructor, Initialization, and Disposal

        public TimeCanvas()
        {
            ModifyBg(StateType.Normal, new Color(0, 0, 0));
        }

        public void Initialize()
        {
            MyMinAmplitudeLabelValue = -90;
            MyMinAmplitudeValue = MyMinAmplitudeLabelValue - 10;
            MyMaxAmplitudeLabelValue = -10;
            MyMaxAmplitudeValue = MyMaxAmplitudeLabelValue + 10;
            MyAmplitudeTotalCount = MyMaxAmplitudeValue - MyMinAmplitudeValue;
            MyGraphMargin = 15;
            MyMaxTime = DateTime.Now;
            MyTimeSpan = TimeSpan.FromMinutes(10);
        }

        #endregion

        #region Methods

        public void HandlePropertyChange()
        {
            MyMaxTime = DateTime.Now;
            QueueDrawArea(0, 0, MyActualViewWidth, MyActualViewHeight);
        }

        private void DrawFramework(Context g)
        {
            MyActualViewRect = new Rectangle(5*MyGraphMargin, MyGraphMargin,
                                             MyActualViewWidth - 8*MyGraphMargin,
                                             MyActualViewHeight - (3*MyGraphMargin));
            MyMaxTime = DateTime.Now;
            DrawGrid(g);
            DrawTitles(g);
            DrawXLabels(g);
        }

        private void DrawGrid(Context g)
        {
            g.Save();
            g.LineWidth = 1.0;
            g.Rectangle(MyActualViewRect);
            g.Color = new Cairo.Color(0, 0, 0);
            g.FillPreserve();
            g.Color = new Cairo.Color(0.4, 0.4, 0.4);
            g.Antialias = Antialias.None;
            g.Stroke();
            g.StrokePreserve();
            g.SetFontSize(AxisTitleFontSize);
            g.SetDash(new[] {1.0, 1.0}, 0);

            int i = 1;
            for (int amplitude = MyMaxAmplitudeLabelValue;
                 amplitude >= MyMinAmplitudeLabelValue;
                 amplitude -= MyAmplitudeDifference)
            {
                g.Color = new Cairo.Color(0.4, 0.4, 0.4, 0.8);
                double y = MyActualViewRect.Y + i++*MyAmplitudeDifferencePoints*MyAmplitudeDifference;
                g.MoveTo(MyActualViewRect.X, y);
                g.LineTo(MyActualViewRect.Width + MyActualViewRect.X, y);

                switch (amplitude)
                {
                    case -60:
                        g.Color = new Cairo.Color(1.0, 1.0, 0);
                        break;
                    case -70:
                        g.Color = new Cairo.Color(1.0, 0.65, 0);
                        break;
                    case -80:
                        g.Color = new Cairo.Color(1.0, 0.28, 0);
                        break;
                    case -90:
                        g.Color = new Cairo.Color(1.0, 0, 0);
                        break;
                    default:
                        g.Color = new Cairo.Color(0.16, 0.8, 0.16);
                        break;
                }
                g.MoveTo(MyActualViewRect.X - 25, y + 5);
                g.ShowText(amplitude.ToString());
                g.MoveTo(MyActualViewRect.X + MyActualViewRect.Width + 2, y + 5);
                g.ShowText(amplitude.ToString());
            }
            g.Color = new Cairo.Color(0.4, 0.4, 0.4, 0.8);
            g.Stroke();
            g.StrokePreserve();
            g.Restore();
        }

        private void DrawXLabels(Context g)
        {
            g.Save();
            double bottom = MyActualViewRect.Y + MyActualViewRect.Height;
            g.Color = new Cairo.Color(0.16, 0.8, 0.16);
            g.SetFontSize(AxisTitleFontSize - 1);
            g.SelectFontFace("Arial", FontSlant.Normal, FontWeight.Normal);
            TextExtents extents;
            for (DateTime i = MyMaxTime - TimeSpan.FromTicks(MyMaxTime.Ticks%MySecsPerTick.Ticks);
                 i > MyMinTime;
                 i -= TimeSpan.FromMinutes(1))
            {
                double x = ConvertTime2X(i);
                string val = i.ToString("h:mm");
                DrawVerticalGuide(x, bottom, g);
                extents = g.TextExtents(val);
                g.MoveTo(x - extents.Width/2, bottom + XLabelTopMargin);
                g.ShowText(val);
            }
            g.Restore();
        }

        private void DrawVerticalGuide(double x, double y, Context g)
        {
            g.Save();
            g.Color = new Cairo.Color(0.4, 0.4, 0.4, 0.2);
            g.LineWidth = 1;
            g.MoveTo(x, y);
            g.LineTo(x, MyActualViewRect.Y);
            g.Antialias = Antialias.None;
            g.Stroke();
            g.StrokePreserve();
            g.Restore();
        }

        private void DrawTitles(Context g)
        {
            g.Save();
            const int x = 18;
            const int rotation = 270;
            string title = "Amplitude [dB]";
            g.SetFontSize(AxisTitleFontSize);
            g.Color = new Cairo.Color(0.16, 0.8, 0.16);
            TextExtents extents = g.TextExtents(title);
            double y = (MyActualViewRect.Y + MyActualViewRect.Height)/2 + extents.Width/2 + MyGraphMargin;
            g.MoveTo(x, y);
            Matrix matrix = new Matrix();
            matrix.Rotate(rotation*Math.PI/36);
            g.Transform(matrix);
            g.ShowText(title);
            g.Restore();
        }

        private double ConvertTime2X(DateTime time)
        {
            TimeSpan temp = time - MyMinTime;
            return ((temp.TotalSeconds*MyPixelsPerSecond) + MyActualViewRect.X);
        }

        #endregion
    }
}