using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using MonoMac.Foundation;

namespace PopupBindings
{
	public class NSObject_KVO : NSObject
	{
		
		MonoMacTypeConverter mmtc = new MonoMacTypeConverter();
		
		public override NSObject ValueForKey (NSString key)
		{
			Type sourceType = this.GetType();
			
			PropertyInfo info = sourceType.GetProperty((string)key);
			if (info != null && info.CanRead && mmtc.CanConvertFrom(info.PropertyType))
			{
				return mmtc.ConvertFrom(info.GetValue(this,null));
			}
			else
				return base.ValueForKey (key);
			
		}	
		
		public override void SetValueForKey (NSObject value, NSString key)
		{
			Type sourceType = this.GetType();
			
			PropertyInfo info = sourceType.GetProperty((string)key);
			
			if (info != null && info.CanWrite && mmtc.CanConvertTo(info.PropertyType))
			{
				
				info.SetValue(this, mmtc.ConvertTo(value, info.PropertyType), null);
			}
			else
				base.SetValueForKey(value,key);
		}
	}
}

