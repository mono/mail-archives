using System;
using System.Reflection;
using MonoMac.Foundation;

namespace PopupBindings
{
	public class MonoMacTypeConverter
	{
		public MonoMacTypeConverter ()
		{}
		
		// relationship is from Managed NSXXX to Primitive C#
		public bool CanConvertFrom(Type sourceType)
		{
			if (sourceType == typeof(string) ||
			    	sourceType == typeof(float) || 
			        sourceType == typeof(double) ||
			        sourceType == typeof(bool) ||
			        sourceType == typeof(sbyte) ||
			        sourceType == typeof(byte) ||
			        sourceType == typeof(short) ||
			        sourceType == typeof(ushort) ||
			        sourceType == typeof(int) ||
			        sourceType == typeof(uint) ||
			        sourceType == typeof(long) ||
			        sourceType == typeof(ulong)) 
			{
				return true;
			}
			
			return false;	
		}
		
		// relationship is to Managed NSXXX from Primitive C#		
		public bool CanConvertTo(Type destinationType)
		{
			if (destinationType == typeof(string) ||
			    	destinationType == typeof(float) || 
			        destinationType == typeof(double) ||
			        destinationType == typeof(bool) ||
			        destinationType == typeof(sbyte) ||
			        destinationType == typeof(byte) ||
			        destinationType == typeof(short) ||
			        destinationType == typeof(ushort) ||
			        destinationType == typeof(int) ||
			        destinationType == typeof(uint) ||
			        destinationType == typeof(long) ||
			        destinationType == typeof(ulong)) 
			{
				return true;
			}
				
				return false;
		}

		// Convert from Primitive to Managed NSXXXXXXX
		public NSObject ConvertFrom (object value)
		{
			
			if (value is string) 
				return (NSString)value.ToString();	
			else if (value is float)
				return NSNumber.FromFloat((float)value); 
			else if (value is double)
				return NSNumber.FromDouble((double)value);
			else if (value is bool)
				return NSNumber.FromBoolean((bool)value);
			else if (value is sbyte)
				return NSNumber.FromFloat((sbyte)value);
			else if (value is byte)
				return NSNumber.FromFloat((byte)value);
			else if (value is short)
				return NSNumber.FromFloat((short)value);
			else if (value is ushort)
				return NSNumber.FromFloat((ushort)value);
			else if (value is int)
				return NSNumber.FromFloat((int)value);
			else if (value is uint)
				return NSNumber.FromFloat((uint)value);
			else if (value is long)
				return NSNumber.FromFloat((long)value);
			else if (value is ulong)
				return NSNumber.FromFloat((ulong)value);
			
			return new NSObject();
		}
		
		// Convert from Managed NSXXXXX value to primitive type
		public object ConvertTo (NSObject value, Type destinationType)
		{
			if (destinationType == typeof(string))
				return (value == null) ? string.Empty : value.ToString();
			else if (destinationType == typeof(float))
				return (value == null) ? 0.0f : ((NSNumber)value).FloatValue; 
			else if (destinationType == typeof(double))
				return (value == null) ? 0.0 : ((NSNumber)value).DoubleValue;
			else if (destinationType == typeof(bool))
				return (value == null) ? false : ((NSNumber)value).BoolValue;
			else if (destinationType == typeof(sbyte))
				return (value == null) ? (sbyte) 0 : ((NSNumber)value).SByteValue;
			else if (destinationType == typeof(byte))
				return (value == null) ? (byte) 0 : ((NSNumber)value).ByteValue;
			else if (destinationType == typeof(short))
				return (value == null) ? (short) 0 : ((NSNumber)value).Int16Value;
			else if (destinationType == typeof(ushort))
				return (value == null) ? (ushort) 0 : ((NSNumber)value).UInt16Value;
			else if (destinationType == typeof(int))
				return (value == null) ? 0 : ((NSNumber)value).Int32Value;
			else if (destinationType == typeof(uint))
				return (value == null) ? 0 : ((NSNumber)value).UInt32Value;
			else if (destinationType == typeof(long))
				return (value == null) ? 0 : ((NSNumber)value).Int64Value;
			else if (destinationType == typeof(ulong))
				return (value == null) ? 0 : ((NSNumber)value).UInt64Value;			

			return new object();
		}				
		
	}
}

