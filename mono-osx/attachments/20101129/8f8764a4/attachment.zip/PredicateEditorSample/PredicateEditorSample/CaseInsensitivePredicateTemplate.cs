using System;
using System.Collections.Generic;
using System.Linq;
using MonoMac.Foundation;
using MonoMac.AppKit;

namespace PredicateEditorSample 
{
	
	// This class is not used in the sample but was for testing purposes.
	public partial class CaseInsensitivePredicateTemplate : NSPredicateEditorRowTemplate
	{
		
		public CaseInsensitivePredicateTemplate(IntPtr handle) : base(handle) {}
		
		public override NSPredicate PredicateWithSubpredicates (NSArray subpredicates)
		{
			
			var predicate = NSComparisonPredicate.FromModifierTypeAndOptions(NSExpression.FromKeyPath(""), 
			                                 NSExpression.FromKeyPath(""),
			                                 NSComparisonPredicateModifier.All,
			                                 NSPredicateOperatorType.In,
			                                 NSComparisonPredicateOptions.CaseInsensitive);
			
			return predicate;
			//return base.PredicateWithSubpredicates(subpredicates);
		}
	}
}

