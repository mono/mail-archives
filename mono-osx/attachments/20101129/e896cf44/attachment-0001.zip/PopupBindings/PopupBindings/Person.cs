using System;
using System.Collections.Generic;
using System.Linq;

namespace PopupBindings
{

	public partial class Person : NSObject_KVO
	{
		public Person () {}
		
		public Person (string name, int age, string addressStreet, string addressCity, string addressState, string addressZip)
		{
			Name = name;
			Age = age;
			AddressStreet = addressStreet;
			AddressCity = addressCity;
			AddressState = addressState;
			AddressZip = addressZip;
		}
		
		public string Name { get; set; }
		
		public int Age { get; set; }
		
		public string AddressStreet { get; set; }

		public string AddressCity { get; set; }

		public string AddressState { get; set; }

		public string AddressZip { get; set; }
		
	}
}

