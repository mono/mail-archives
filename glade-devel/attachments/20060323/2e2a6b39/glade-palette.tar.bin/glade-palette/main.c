
#include "glade-palette-table.h"
#include "glade-palette-expander.h"

#include <gtk/gtk.h>

int main(int argc, char *argv[])
{
	GtkWidget *window;
	GtkWidget *vbox;
	GtkWidget *group_box;
	GtkWidget *expander;
	GtkWidget *scrolled_window;
	GtkWidget *alignment;
	GtkTooltips *tips;

	gint i;


	gtk_init (&argc, &argv);

	window = gtk_window_new (GTK_WINDOW_TOPLEVEL);

	tips = gtk_tooltips_new ();

	vbox = gtk_vbox_new (FALSE, 0);
	gtk_container_set_border_width (GTK_CONTAINER (vbox), 1);

	expander = glade_palette_expander_new ("<b>Gtk Base</b>");
	glade_palette_expander_set_spacing (GLADE_PALETTE_EXPANDER (expander), 2);
	glade_palette_expander_set_use_markup (GLADE_PALETTE_EXPANDER (expander), TRUE);
	glade_palette_expander_set_expanded (GLADE_PALETTE_EXPANDER (expander), TRUE);
	gtk_container_set_border_width (GTK_CONTAINER (expander), 1);
	gtk_box_pack_start (GTK_BOX (vbox), expander, FALSE, FALSE, 0);


	group_box = glade_palette_table_new ();
	gtk_container_add (GTK_CONTAINER (expander), group_box);

	for (i=0 ; i < 20 ; i++)
	{
		GtkWidget *button = gtk_button_new ();

		GtkWidget *image = gtk_image_new_from_stock (GTK_STOCK_NEW, GTK_ICON_SIZE_BUTTON);
		gtk_container_add (GTK_CONTAINER (button), image);
		gtk_button_set_relief (GTK_BUTTON (button), GTK_RELIEF_NONE);

		gtk_container_add (GTK_CONTAINER (group_box), button);
	}

	expander = glade_palette_expander_new ("<b>Gtk Additional</b>");
	glade_palette_expander_set_spacing (GLADE_PALETTE_EXPANDER (expander), 2);
	glade_palette_expander_set_use_markup (GLADE_PALETTE_EXPANDER (expander), TRUE);
	gtk_container_set_border_width (GTK_CONTAINER (expander), 1);
	gtk_box_pack_start (GTK_BOX (vbox), expander, FALSE, FALSE, 0);

	group_box = glade_palette_table_new ();
	gtk_container_add (GTK_CONTAINER (expander), group_box);

	for (i=0 ; i < 12 ; i++)
	{
		GtkWidget *button = gtk_button_new ();

		GtkWidget *image = gtk_image_new_from_stock (GTK_STOCK_NEW, GTK_ICON_SIZE_BUTTON);
		gtk_container_add (GTK_CONTAINER (button), image);
		gtk_button_set_relief (GTK_BUTTON (button), GTK_RELIEF_NONE);

		gtk_container_add (GTK_CONTAINER (group_box), button);
	}

	expander = glade_palette_expander_new ("<b>Gtk Dialogs</b>");
	glade_palette_expander_set_spacing (GLADE_PALETTE_EXPANDER (expander), 2);
	glade_palette_expander_set_use_markup (GLADE_PALETTE_EXPANDER (expander), TRUE);
	glade_palette_expander_set_expanded (GLADE_PALETTE_EXPANDER (expander), TRUE);
	gtk_container_set_border_width (GTK_CONTAINER (expander), 1);
	gtk_box_pack_start (GTK_BOX (vbox), expander, FALSE, FALSE, 0);

	group_box = glade_palette_table_new ();
	gtk_container_add (GTK_CONTAINER (expander), group_box);

	for (i=0 ; i < 5 ; i++)
	{
		GtkWidget *button = gtk_button_new ();

		GtkWidget *image = gtk_image_new_from_stock (GTK_STOCK_NEW, GTK_ICON_SIZE_BUTTON);
		gtk_container_add (GTK_CONTAINER (button), image);
		gtk_button_set_relief (GTK_BUTTON (button), GTK_RELIEF_NONE);

		gtk_container_add (GTK_CONTAINER (group_box), button);
	}

	expander = glade_palette_expander_new ("<b>Gnome</b>");
	glade_palette_expander_set_spacing (GLADE_PALETTE_EXPANDER (expander), 2);
	glade_palette_expander_set_use_markup (GLADE_PALETTE_EXPANDER (expander), TRUE);
	gtk_container_set_border_width (GTK_CONTAINER (expander), 1);
	gtk_box_pack_start (GTK_BOX (vbox), expander, FALSE, FALSE, 0);

	group_box = glade_palette_table_new ();
	gtk_container_add (GTK_CONTAINER (expander), group_box);

	for (i=0 ; i < 8 ; i++)
	{
		GtkWidget *button = gtk_button_new ();

		GtkWidget *image = gtk_image_new_from_stock (GTK_STOCK_NEW, GTK_ICON_SIZE_BUTTON);
		gtk_container_add (GTK_CONTAINER (button), image);
		gtk_button_set_relief (GTK_BUTTON (button), GTK_RELIEF_NONE);

		gtk_container_add (GTK_CONTAINER (group_box), button);
	}

	expander = glade_palette_expander_new ("<b>Sexy Widgets</b>");
	glade_palette_expander_set_spacing (GLADE_PALETTE_EXPANDER (expander), 2);
	glade_palette_expander_set_use_markup (GLADE_PALETTE_EXPANDER (expander), TRUE);
	gtk_container_set_border_width (GTK_CONTAINER (expander), 1);
	gtk_box_pack_start (GTK_BOX (vbox), expander, FALSE, FALSE, 0);

	group_box = glade_palette_table_new ();
	gtk_container_add (GTK_CONTAINER (expander), group_box);

	for (i=0 ; i < 4 ; i++)
	{
		GtkWidget *button = gtk_button_new ();

		GtkWidget *image = gtk_image_new_from_stock (GTK_STOCK_NEW, GTK_ICON_SIZE_BUTTON);
		gtk_container_add (GTK_CONTAINER (button), image);
		gtk_button_set_relief (GTK_BUTTON (button), GTK_RELIEF_NONE);

		gtk_container_add (GTK_CONTAINER (group_box), button);
	}

	scrolled_window = gtk_scrolled_window_new (NULL, NULL);
	gtk_scrolled_window_set_policy (GTK_SCROLLED_WINDOW (scrolled_window),
				 	GTK_POLICY_NEVER, GTK_POLICY_AUTOMATIC);

	gtk_scrolled_window_set_shadow_type (GTK_SCROLLED_WINDOW (scrolled_window),
					     GTK_SHADOW_NONE);

	gtk_scrolled_window_add_with_viewport (GTK_SCROLLED_WINDOW (scrolled_window),
					       vbox);

	alignment = gtk_alignment_new (0.5, 0.5, 1, 1);
	gtk_alignment_set_padding (GTK_ALIGNMENT (alignment), 4, 0, 0, 0);

	gtk_container_add (GTK_CONTAINER (alignment), scrolled_window);
	gtk_container_add (GTK_CONTAINER (window), alignment);	

    	g_signal_connect (G_OBJECT (window), "delete_event",
		      		G_CALLBACK (gtk_main_quit), NULL);

	gtk_window_set_type_hint (GTK_WINDOW (window), GDK_WINDOW_TYPE_HINT_UTILITY);

	gtk_window_set_title (GTK_WINDOW (window), "Palette");

	gtk_window_set_default_size (GTK_WINDOW (window), -1, 450);

	gtk_window_set_keep_above (GTK_WINDOW (window), TRUE);

	gtk_container_set_border_width (GTK_CONTAINER (window), 0);

	gtk_widget_show_all (window);

	gtk_main();

	return 0;
}
