/* -*- Mode: C; tab-width: 8; indent-tabs-mode: t; c-basic-offset: 8 -*- */
/*
 * glade-palette-table.c - A Gtk container that lays out palette items 
 *
 * Copyright (C) 2006 The GNOME Foundation.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
 * USA.
 *
 * Author(s):
 *      Vincent Geddes <vgeddes@metroweb.co.za>
 */

#include "glade-palette-table.h"


static void glade_palette_table_class_init (GladePaletteTableClass *klass);

static void glade_palette_table_init (GladePaletteTable *table);

static void glade_palette_table_add (GtkContainer *container, GtkWidget *widget);

static void glade_palette_table_remove (GtkContainer *container, GtkWidget *widget);

static GType glade_palette_table_child_type (GtkContainer *container);

static void glade_palette_table_size_request (GtkWidget *widget, GtkRequisition *requisition);

static void glade_palette_table_size_allocate (GtkWidget *widget, GtkAllocation  *allocation);

static void glade_palette_table_forall (GtkContainer   *container,
					gboolean include_internals,
			        	GtkCallback callback,
			        	gpointer callback_data);

static void glade_palette_table_set_property (GObject *object,
		      		  guint prop_id,
		      		  const GValue *value,
		      		  GParamSpec *pspec);

static void glade_palette_table_get_property (GObject *object,
		      		  guint prop_id,
		      		  GValue *value,
		      		  GParamSpec *pspec);


static GtkContainerClass *parent_class = NULL;


enum {
  	PROP_0,
	PROP_SPACING,
};


GType
glade_palette_table_get_type (void)
{
	static GType type = 0;

	if (type == 0)
	{
		static const GTypeInfo info =
		{
			sizeof (GladePaletteTableClass),
			NULL,
			NULL,
			(GClassInitFunc) glade_palette_table_class_init,
			NULL,
			NULL,
			sizeof (GladePaletteTable),
			0,
			(GInstanceInitFunc) glade_palette_table_init,
		};

		type = g_type_register_static (GTK_TYPE_CONTAINER,
		                               "GladePaletteTable",
		                               &info, 0);
	}

	return type;
}

static void
glade_palette_table_class_init(GladePaletteTableClass *class)
{
	GObjectClass *gobject_class;
	GtkWidgetClass *widget_class;
	GtkContainerClass *container_class;

	parent_class = g_type_class_peek_parent (class);

	gobject_class = G_OBJECT_CLASS (class);
	gobject_class->set_property = glade_palette_table_set_property;
	gobject_class->get_property = glade_palette_table_get_property;

	container_class = GTK_CONTAINER_CLASS (class);
	container_class->add = glade_palette_table_add;
	container_class->remove = glade_palette_table_remove;
	container_class->forall = glade_palette_table_forall;
	container_class->child_type = glade_palette_table_child_type;

	widget_class = GTK_WIDGET_CLASS (class);
	widget_class->size_request = glade_palette_table_size_request;
	widget_class->size_allocate = glade_palette_table_size_allocate;
	/*
	g_object_class_install_property (gobject_class,
	                                 PROP_SPACING,
	                                 g_param_spec_int ("min-columns",
	                                                   "min-columns",
	                                                   "Minimum number of columns with which to layout children",
	                                                   0,
	                                                   G_MAXINT,
	                                                   0,
	                                                   G_PARAM_READABLE | G_PARAM_WRITABLE));*/

	g_object_class_install_property (gobject_class,
	                                 PROP_SPACING,
	                                 g_param_spec_int ("spacing",
	                                                   "Spacing",
	                                                   "The amount of space between children",
	                                                   0,
	                                                   G_MAXINT,
	                                                   0,
	                                                   G_PARAM_READABLE | G_PARAM_WRITABLE));



}

static void
glade_palette_table_init (GladePaletteTable *table)
{
	GTK_WIDGET_SET_FLAGS (table, GTK_NO_WINDOW);
	gtk_widget_set_redraw_on_allocate (GTK_WIDGET (table), FALSE);

	table->children = NULL;
	table->spacing = 0;
}

static void 
glade_palette_table_set_property (GObject *object,
		      		  guint prop_id,
		      		  const GValue *value,
		      		  GParamSpec *pspec)
{
  GladePaletteTable *table;

  table = GLADE_PALETTE_TABLE (object);

  switch (prop_id)
    {
    case PROP_SPACING:
      glade_palette_table_set_spacing (table, g_value_get_int (value));
      break;
    default:
      G_OBJECT_WARN_INVALID_PROPERTY_ID (object, prop_id, pspec);
      break;
    }
}

static void 
glade_palette_table_get_property (GObject *object,
		      		  guint prop_id,
		      		  GValue *value,
		      		  GParamSpec *pspec)
{
  GladePaletteTable *table;

  table = GLADE_PALETTE_TABLE (object);

  switch (prop_id)
    {
    case PROP_SPACING:
      g_value_set_int (value, table->spacing);
      break;
    default:
      G_OBJECT_WARN_INVALID_PROPERTY_ID (object, prop_id, pspec);
      break;
    }
}

GtkWidget*
glade_palette_table_new (void)
{
  GladePaletteTable *table;

  table = g_object_new (GLADE_TYPE_PALETTE_TABLE, NULL);

  return GTK_WIDGET (table);
}

static void
glade_palette_table_size_request (GtkWidget *widget, GtkRequisition *requisition)
{
	GladePaletteTable *table;
	GladePaletteTableChild *child;
	GList *children;
	GtkRequisition max_requisition;
	gint nvis_children;

	table = GLADE_PALETTE_TABLE (widget);
	requisition->width = 0;
	requisition->height = 0;

	max_requisition.width = 0;
	max_requisition.height = 0;

	nvis_children = 0;

	children = table->children;

	while (children != NULL)
	{
		child = children->data;
		children = g_list_next (children);

		if (GTK_WIDGET_VISIBLE (child->widget))
		{
			GtkRequisition child_requisition;

			gtk_widget_size_request (child->widget, &child_requisition);

			max_requisition.width = MAX ( max_requisition.width, child_requisition.width);

			nvis_children += 1;
		}
	}

	if (nvis_children > 0)
	{
		requisition->width = max_requisition.width * 4 + table->spacing * 3;
	}

	requisition->width += GTK_CONTAINER (table)->border_width * 2;

}

static void
glade_palette_table_size_allocate (GtkWidget *widget, GtkAllocation *allocation)
{
	GladePaletteTable *table;
	GladePaletteTableChild *child;
	GList *children;
	GtkRequisition child_requisition_maximum;
	GtkAllocation child_allocation;
	gint nvis_children;
	gint x;
	gint y;
	gint widget_height;
	gint rows;

	table = GLADE_PALETTE_TABLE (widget);
	widget->allocation = *allocation;

	child_requisition_maximum.width = 0;
	child_requisition_maximum.height = 0;

	nvis_children = 0;
	children = table->children;
	while (children != NULL)
	{
		child = children->data;
		children = g_list_next (children);

		if (GTK_WIDGET_VISIBLE (child->widget))
		{
			GtkRequisition child_requisition;

			gtk_widget_get_child_requisition (child->widget, &child_requisition);
	
			child_requisition_maximum.width = MAX (child_requisition_maximum.width, 
			                                       child_requisition.width);
			child_requisition_maximum.height = MAX (child_requisition_maximum.width, 
			                                        child_requisition.height);

			nvis_children += 1;
		}
	}

	if (nvis_children > 0)
	{

		rows = 1;
		x = allocation->x  + GTK_CONTAINER (table)->border_width;
		y =  allocation->y + GTK_CONTAINER (table)->border_width;

		children = table->children;
		while (children != NULL)
		{
			gint table_row_width;
			child = children->data;
			children = g_list_next (children);

			if (GTK_WIDGET_VISIBLE (child->widget))
			{
				child_allocation.x = x;
				child_allocation.y = y;
				child_allocation.width = child_requisition_maximum.width;
				child_allocation.height = child_requisition_maximum.height;

				gtk_widget_size_allocate (child->widget, &child_allocation);

				x += child_allocation.width + table->spacing;

				table_row_width = x - allocation->x + GTK_CONTAINER (table)->border_width + child_allocation.width;

				if ((table_row_width > allocation->width) && children != NULL )
				{
					rows++;
					x = allocation->x + GTK_CONTAINER (table)->border_width;
					y += child_allocation.height + table->spacing;
				}
			}
		}

		widget_height = rows * child_allocation.height + (rows - 1) * table->spacing;

		gtk_widget_set_size_request (widget, -1, widget_height);
	}

}

static void 
glade_palette_table_add (GtkContainer *container, GtkWidget *widget)
{
	GladePaletteTable *table;
	GladePaletteTableChild *child_info;

	g_return_if_fail (GLADE_IS_PALETTE_TABLE (container));
	g_return_if_fail (GTK_IS_WIDGET (widget));
	g_return_if_fail (widget->parent == NULL);

	table = GLADE_PALETTE_TABLE (container);

	child_info = g_new (GladePaletteTableChild, 1);

	child_info->widget = widget;

	table->children = g_list_append (table->children, child_info);

	gtk_widget_set_parent (widget, GTK_WIDGET (table));
}

static void
glade_palette_table_remove (GtkContainer *container, GtkWidget *widget)
{
	GladePaletteTable *table;
	GladePaletteTableChild *child;
	GList *children;

	g_return_if_fail (GLADE_IS_PALETTE_TABLE (container));
	g_return_if_fail (GTK_IS_WIDGET (widget));

	table = GLADE_PALETTE_TABLE (container);

  	children = table->children;
	while (children != NULL)
	{
		child = children->data;
		children = g_list_next (children);

		if (child->widget == widget)
		{
			gboolean was_visible;

			was_visible = GTK_WIDGET_VISIBLE (widget);

			gtk_widget_unparent (widget);

			table->children = g_list_remove (table->children, child);
			g_free (child);

			if (was_visible)
				gtk_widget_queue_resize (GTK_WIDGET (container));
			break;
		}

	}

}

static void
glade_palette_table_forall (GtkContainer *container,
			    gboolean include_internals,
			    GtkCallback callback,
			    gpointer callback_data)
{
	GladePaletteTable *table;
	GladePaletteTableChild *child;
	GList *children;

	g_return_if_fail (callback != NULL);

	table = GLADE_PALETTE_TABLE (container);

	children = table->children;
	while (children != NULL)
	{
		child = children->data;
		children = g_list_next (children);

		(* callback) (child->widget, callback_data);
	}
}

static GType
glade_palette_table_child_type (GtkContainer *container)
{
  return GTK_TYPE_WIDGET;
}

void
glade_palette_table_set_spacing (GladePaletteTable *table, gint spacing)
{
  g_return_if_fail (GLADE_IS_PALETTE_TABLE (table));

  if (spacing != table->spacing)
    {
      table->spacing = spacing;
      g_object_notify (G_OBJECT (table), "spacing");
      gtk_widget_queue_resize (GTK_WIDGET (table));
    }
}

gint
glade_palette_table_get_spacing (GladePaletteTable *table)
{
  g_return_val_if_fail (GLADE_IS_PALETTE_TABLE (table), 0);

  return table->spacing;
}
