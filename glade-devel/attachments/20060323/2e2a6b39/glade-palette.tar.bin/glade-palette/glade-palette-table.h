/* -*- Mode: C; tab-width: 8; indent-tabs-mode: t; c-basic-offset: 8 -*- */
/*
 * Copyright (C) 2006 Gnome Foundation
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 *
 * Authors:
 *   Vincent Geddes <vgeddes@metroweb.co.za>
 */

#ifndef __GLADE_PALETTE_TABLE_H__
#define __GLADE_PALETTE_TABLE_H__

#include <gdk/gdk.h>
#include <gtk/gtkcontainer.h>

G_BEGIN_DECLS

#define GLADE_TYPE_PALETTE_TABLE            (glade_palette_table_get_type ())
#define GLADE_PALETTE_TABLE(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), GLADE_TYPE_PALETTE_TABLE, GladePaletteTable))
#define GLADE_PALETTE_TABLE_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), GLADE_TYPE_PALETTE_TABLE, GladePaletteTableClass))
#define GLADE_IS_PALETTE_TABLE(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), GLADE_TYPE_PALETTE_TABLE))
#define GLADE_IS_PALETTE_TABLE_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), GLADE_TYPE_PALETTE_TABLE))
#define GLADE_PALETTE_TABLE_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), GLADE_TYPE_PALETTE_TABLE, GladePaletteTableClass))


typedef struct _GladePaletteTable	 GladePaletteTable;
typedef struct _GladePaletteTableClass   GladePaletteTableClass;
typedef struct _GladePaletteTableChild   GladePaletteTableChild;


struct _GladePaletteTable
{
	GtkContainer container;

	/* private */
	GList *children;
	gint16 spacing;
};

struct _GladePaletteTableClass
{
	GtkContainerClass parent_class;
};

struct _GladePaletteTableChild
{
	GtkWidget *widget;
};


GType glade_palette_table_get_type (void) G_GNUC_CONST;

GtkWidget* glade_palette_table_new (void);

void glade_palette_table_set_spacing (GladePaletteTable *table, gint spacing);

gint glade_palette_table_get_spacing (GladePaletteTable *table);


G_END_DECLS

#endif /* __GLADE_PALETTE_TABLE_H__ */
