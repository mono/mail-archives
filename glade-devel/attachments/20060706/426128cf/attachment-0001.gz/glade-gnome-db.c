/* -*- Mode: C; tab-width: 8; indent-tabs-mode: t; c-basic-offset: 8 -*- */
/*
 * Copyright (C) 2006 Juan Pablo Ugarte.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 *
 * Authors:
 *   Daniel Espinosa Ortiz <esodan@gmail.com>
 */

#include <gtk/gtk.h>
#include <libgnome/libgnome.h>
#include <libgnomedb/libgnomedb.h>
#include "glade.h"
#include "glade-widget.h"
#include "glade-property.h"
#include "glade-editor-property.h"

#include "glade-gtk.h"

#define GLADEGNOMEDB_API GLADEGNOMEDB_API

/* This function does absolutely nothing
 * (and is for use in overriding post_create functions).
 */
void GLADEGNOMEDB_API
empty (GObject *container, GladeCreateReason reason)
{
}

/* Catalog init function */
void GLADEGNOMEDB_API
glade_gnome_db_init (void)
{
	gchar *argv[2] = {"glade-3", NULL};
	
	gnome_db_init ("glade-3", "1.0", 1, argv);
}

/* GnomeDbEditor */
void GLADEGNOMEDB_API
glade_gnome_db_editor_set_editable (GObject *object, GValue *value)
{
	g_return_if_fail(G_IS_OBJECT(object) & G_IS_VALUE(value));

	GnomeDbEditor *editor = GNOME_DB_EDITOR(object);

	if(IS_GNOME_DB_EDITOR(editor)) {

		gnome_db_editor_set_editable (editor, g_value_get_boolean(value));
	}
}


void GLADEGNOMEDB_API
glade_gnome_db_editor_get_editable (GObject *object, GValue *value)
{
	g_return_if_fail(G_IS_OBJECT(object) & G_IS_VALUE(value));

	GnomeDbEditor *editor = GNOME_DB_EDITOR(object);

	if(IS_GNOME_DB_EDITOR(editor)) {
		
		g_value_set_boolean(value, gnome_db_editor_get_editable (editor);
	}
}

void GLADEGNOMEDB_API
glade_gnome_db_editor_set_highlight (GObject *object, GValue *value)
{
	g_return_if_fail(G_IS_OBJECT(object) & G_IS_VALUE(value));

	GnomeDbEditor *editor = GNOME_DB_EDITOR(object);

	if(IS_GNOME_DB_EDITOR(editor)) {

		gnome_db_editor_set_highlight (editor, g_value_get_boolean(value));
	}
}


void GLADEGNOMEDB_API
glade_gnome_db_editor_get_highlight (GObject *object, GValue *value)
{
	g_return_if_fail(G_IS_OBJECT(object) & G_IS_VALUE(value));

	GnomeDbEditor *editor = GNOME_DB_EDITOR(object);

	if(IS_GNOME_DB_EDITOR(editor)) {
		
		gnome_db_editor_get_highlight (editor, g_value_get_boolean(value));
	}
}

void GLADEGNOMEDB_API
glade_gnome_db_editor_set_text (GObject *object, GValue *value)
{
	g_return_if_fail(G_IS_OBJECT(object) & G_IS_VALUE(value));

	GnomeDbEditor *editor = GNOME_DB_EDITOR(object);

	if(IS_GNOME_DB_EDITOR(editor)) {

		gnome_db_editor_set_text (editor, g_value_get_string(value));
	}
}


void GLADEGNOMEDB_API
glade_gnome_db_editor_get_text (GObject *object, GValue *value)
{
	g_return_if_fail(G_IS_OBJECT(object) & G_IS_VALUE(value));

	GnomeDbEditor *editor = GNOME_DB_EDITOR(object);

	if(IS_GNOME_DB_EDITOR(editor)) {
		
		g_value_set_string(value, gnome_db_editor_get_all_text (editor);
	}
}


/* Gray Bar */
void GLADEGNOMEDB_API
glade_gnome_db_gray_bar_set_text (GObject *object, GValue *value)
{
	g_return_if_fail(G_IS_OBJECT(object) & G_IS_VALUE(value));

	GnomeDbGrayBar *bar = GNOME_DB_GRAY_BAR(object);

	if(IS_GNOME_DB_GRAY_BAR(bar)) {

		gnome_db_gray_bar_set_text (bar, g_value_get_string(value));
	}
}

void GLADEGNOMEDB_API
glade_gnome_db_gray_bar_get_show_icon (GObject *object, GValue *value)
{
	g_return_if_fail(G_IS_OBJECT(object) & G_IS_VALUE(value));

	GnomeDbGrayBar *bar = GNOME_DB_GRAY_BAR(object);

	if(IS_GNOME_DB_GRAY_BAR(bar)) {
		
		g_value_set_boolean(value, ;
	}
}

void GLADEGNOMEDB_API
glade_gnome_db_gray_bar_get_text (GObject *object, GValue *value)
{
	g_return_if_fail(G_IS_OBJECT(object) & G_IS_VALUE(value));

	GnomeDbGrayBar *bar = GNOME_DB_GRAY_BAR(object);

	if(IS_GNOME_DB_GRAY_BAR(bar)) {
		
		g_value_set_string(value, gnome_db_gray_bar_get_text (editor);
	}
}

void GLADEGNOMEDB_API
glade_gnome_db_gray_bar_set_icon_from_file (GObject *object, GValue *value)
{
	g_return_if_fail(G_IS_OBJECT(object) & G_IS_VALUE(value));

	GnomeDbGrayBar *bar = GNOME_DB_GRAY_BAR(object);

	if(IS_GNOME_DB_GRAY_BAR(bar)) {

		gnome_db_gray_bar_set_icon_from_file (bar, g_value_get_string(value));
	}
}

void GLADEGNOMEDB_API
glade_gnome_db_gray_bar_set_icon_from_stock (GObject *object, GValue *value)
{
	/* How to Set the stock using this function:
		gnome_db_gray_bar_set_icon_from_stock (GnomeDbGrayBar *bar, 
							const gchar *stock_id, 
							GtkIconSize size)
	   
	   This function internaly use the gtk_image_set_from_stock in a private property in the
           widget
	*/
}

void GLADEGNOMEDB_API
glade_gnome_db_gray_bar_get_show_icon (GObject *object, GValue *value)
{
	g_return_if_fail(G_IS_OBJECT(object) & G_IS_VALUE(value));

	GnomeDbGrayBar *bar = GNOME_DB_GRAY_BAR(object);

	if(IS_GNOME_DB_GRAY_BAR(bar)) {
		
		gnome_db_gray_bar_set_show_icon (editor, g_value_get_boolean(value));
	}
}

/* GnomeDbLogin */

void GLADEGNOMEDB_API
glade_gnome_db_login_set_create_button (GObject *object, GValue *value)
{
	g_return_if_fail(G_IS_OBJECT(object) & G_IS_VALUE(value));

	GnomeDbLogin *login = GNOME_DB_LOGIN(object);

	if(IS_GNOME_DB_LOGIN(login)) {

		gnome_db_login_set_enable_create_button (login, g_value_get_boolean(value));
	}
}

void GLADEGNOMEDB_API
glade_gnome_db_login_get_create_button (GObject *object, GValue *value)
{
	g_return_if_fail(G_IS_OBJECT(object) & G_IS_VALUE(value));

	GnomeDbLogin *login = GNOME_DB_LOGIN(object);

	if(IS_GNOME_DB_LOGIN(login)) {

		g_value_set_boolean(value, login->priv->hiding_button);
	}
}

void GLADEGNOMEDB_API
glade_gnome_db_login_set_show_dns_selector (GObject *object, GValue *value)
{
	g_return_if_fail(G_IS_OBJECT(object) & G_IS_VALUE(value));

	GnomeDbLogin *login = GNOME_DB_LOGIN(object);

	if(IS_GNOME_DB_LOGIN(login)) {

		gnome_db_login_set_show_dsn_selector (login, g_value_get_boolean(value));
	}
}

void GLADEGNOMEDB_API
glade_gnome_db_login_get_show_dns_selector (GObject *object, GValue *value)
{
	g_return_if_fail(G_IS_OBJECT(object) & G_IS_VALUE(value));

	GnomeDbLogin *login = GNOME_DB_LOGIN(object);

	if(IS_GNOME_DB_LOGIN(login)) {

		g_value_set_boolean(value, login->priv->hiding_dsn);
	}
}
