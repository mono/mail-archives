#!/usr/bin/env python
"""
this file is a part of GNUKhata.
GNUKhata is free software.  Permission is granted to copy modify and/ or re distribute the software with or without modifications under the terms of the GNU General Public License.
The terms of the license is provided in the copying file.
the list of authors is given in the authors file.

"""

import pygtk
pygtk.require('2.0')
import gtk 
import gtk.glade
import new_org
class mainmenu:
	def show_newOrganisation(self,widget):
		new_org.org()
		self.gladefile_newOrg = "new_org.glade"
		self.wTreenewOrg = gtk.glade.XML(self.gladefile_newOrg)
		self.page=self.wTreenewOrg.get_child('window_newOrg')
		self.page.reparent(self.notebook)
		self.page.set_tab_label_text(self.page,'New Organisation')
		
	def dialogQuit(self,widget):
		self.dialog_quit = self.wTree.get_widget("dialog_quit")
		self.dialog_quit.show()
		self.response = self.dialog_quit.run()
		if self.response == 1:# I assigned 1 to quit and -1 to cancel in glade
	
			gtk.main_quit()
		else:
			self.dialog_quit.destroy()
		
	
	#To quit the main window
	def on_Mainwindow_destroy(self):
		gtk.main_quit()


	def __init__(self):
		#set the glade file
		self.gladefile = "gnukhata.glade"
		self.wTree = gtk.glade.XML(self.gladefile)
		
		#get the Main Window and connect the Destroy event
		self.window = self.wTree.get_widget("MainWindow")
		self.window.show()
		self.window.connect('destroy',gtk.main_quit)
		self.notebook = self.wTree.get_widget("notebook_main") 
		self.notebook.show()		
		
		self.menuitem_quit = self.wTree.get_widget("menuitem_quit")
		self.menuitem_quit.connect('activate',self.dialogQuit)

		self.menuitem_newOrg = self.wTree.get_widget("menuitem_new_organisation")
		self.menuitem_newOrg.connect('activate',self.show_newOrganisation)

		
if __name__ == "__main__":
	mm=mainmenu()
	gtk.main()
