#!/usr/bin/env python

import pygtk
pygtk.require('2.0')
import gtk 
import gtk.glade

class org:

	def __init__(self):
		self.gladefile_newOrg = "new_org.glade"
		self.wTreenewOrg = gtk.glade.XML(self.gladefile_newOrg)
		self.frame_newOrg = self.wTreenewOrg.get_widget("frame_newOrg")	
