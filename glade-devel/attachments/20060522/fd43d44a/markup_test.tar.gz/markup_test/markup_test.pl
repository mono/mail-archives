#!/usr/bin/perl

use Gtk2 -init;
use Gtk2::GladeXML;

my $glade2_window = Gtk2::GladeXML->new( "glade-2.glade", "window1" );
my $glade3_window = Gtk2::GladeXML->new( "glade-3.glade", "window1" );

Gtk2->main;
