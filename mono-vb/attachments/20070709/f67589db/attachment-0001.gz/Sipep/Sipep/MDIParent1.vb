Imports System.Windows.Forms
Imports Npgsql
Imports NpgsqlTypes

Public Class MDIParent1
    Private Sub mnuProveedor_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuProveedor.Click
        w_mnt_Proveedores.Show(Me)
    End Sub

    Private Sub AboutToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AboutToolStripMenuItem.Click
        AboutBox1.Show(Me)
    End Sub

    Private Sub MDIParent1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub NewWindowToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NewWindowToolStripMenuItem.Click
        w_conectar.Show()
    End Sub
End Class
