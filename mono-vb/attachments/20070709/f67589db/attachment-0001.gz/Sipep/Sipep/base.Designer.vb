<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class base
  Inherits System.Windows.Forms.Form

  'Form overrides dispose to clean up the component list.
  <System.Diagnostics.DebuggerNonUserCode()> _
  Protected Overrides Sub Dispose(ByVal disposing As Boolean)
    If disposing AndAlso components IsNot Nothing Then
      components.Dispose()
    End If
    MyBase.Dispose(disposing)
  End Sub

  'Required by the Windows Form Designer
  Private components As System.ComponentModel.IContainer

  'NOTE: The following procedure is required by the Windows Form Designer
  'It can be modified using the Windows Form Designer.  
  'Do not modify it using the code editor.
  <System.Diagnostics.DebuggerStepThrough()> _
  Private Sub InitializeComponent()
    Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(base))
    Me.Toolbar = New System.Windows.Forms.ToolStrip
    Me.btn_agregar = New System.Windows.Forms.ToolStripButton
    Me.btn_eliminar = New System.Windows.Forms.ToolStripButton
    Me.btn_guardar = New System.Windows.Forms.ToolStripButton
    Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator
    Me.btn_Imprimir = New System.Windows.Forms.ToolStripButton
    Me.StatusStrip1 = New System.Windows.Forms.StatusStrip
    Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel
    Me.ToolStripStatusLabel2 = New System.Windows.Forms.ToolStripStatusLabel
    Me.btn_buscar = New System.Windows.Forms.ToolStripButton
    Me.btn_limpiar = New System.Windows.Forms.ToolStripButton
    Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator
    Me.btn_salir = New System.Windows.Forms.ToolStripButton
    Me.ToolStripButton4 = New System.Windows.Forms.ToolStripButton
    Me.Toolbar.SuspendLayout()
    Me.StatusStrip1.SuspendLayout()
    Me.SuspendLayout()
    '
    'Toolbar
    '
    Me.Toolbar.ImageScalingSize = New System.Drawing.Size(24, 24)
    Me.Toolbar.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.btn_agregar, Me.btn_eliminar, Me.btn_guardar, Me.ToolStripSeparator1, Me.btn_Imprimir, Me.btn_buscar, Me.btn_limpiar, Me.ToolStripSeparator2, Me.btn_salir, Me.ToolStripButton4})
    Me.Toolbar.Location = New System.Drawing.Point(0, 0)
    Me.Toolbar.Name = "Toolbar"
    Me.Toolbar.Size = New System.Drawing.Size(568, 31)
    Me.Toolbar.TabIndex = 0
    Me.Toolbar.Text = "ToolStrip1"
    '
    'btn_agregar
    '
    Me.btn_agregar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
    Me.btn_agregar.Image = CType(resources.GetObject("btn_agregar.Image"), System.Drawing.Image)
    Me.btn_agregar.ImageTransparentColor = System.Drawing.Color.Magenta
    Me.btn_agregar.Name = "btn_agregar"
    Me.btn_agregar.Size = New System.Drawing.Size(28, 28)
    Me.btn_agregar.ToolTipText = "Agregar"
    '
    'btn_eliminar
    '
    Me.btn_eliminar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
    Me.btn_eliminar.Image = CType(resources.GetObject("btn_eliminar.Image"), System.Drawing.Image)
    Me.btn_eliminar.ImageTransparentColor = System.Drawing.Color.Magenta
    Me.btn_eliminar.Name = "btn_eliminar"
    Me.btn_eliminar.Size = New System.Drawing.Size(28, 28)
    Me.btn_eliminar.ToolTipText = "Eliminar"
    '
    'btn_guardar
    '
    Me.btn_guardar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
    Me.btn_guardar.Image = CType(resources.GetObject("btn_guardar.Image"), System.Drawing.Image)
    Me.btn_guardar.ImageTransparentColor = System.Drawing.Color.Magenta
    Me.btn_guardar.Name = "btn_guardar"
    Me.btn_guardar.Size = New System.Drawing.Size(28, 28)
    Me.btn_guardar.ToolTipText = "Guardar"
    '
    'ToolStripSeparator1
    '
    Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
    Me.ToolStripSeparator1.Size = New System.Drawing.Size(6, 31)
    '
    'btn_Imprimir
    '
    Me.btn_Imprimir.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
    Me.btn_Imprimir.Image = CType(resources.GetObject("btn_Imprimir.Image"), System.Drawing.Image)
    Me.btn_Imprimir.ImageTransparentColor = System.Drawing.Color.Magenta
    Me.btn_Imprimir.Name = "btn_Imprimir"
    Me.btn_Imprimir.Size = New System.Drawing.Size(28, 28)
    Me.btn_Imprimir.ToolTipText = "Imprimir"
    '
    'StatusStrip1
    '
    Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel1, Me.ToolStripStatusLabel2})
    Me.StatusStrip1.Location = New System.Drawing.Point(0, 342)
    Me.StatusStrip1.Name = "StatusStrip1"
    Me.StatusStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional
    Me.StatusStrip1.Size = New System.Drawing.Size(568, 22)
    Me.StatusStrip1.SizingGrip = False
    Me.StatusStrip1.TabIndex = 1
    Me.StatusStrip1.Text = "StatusStrip1"
    '
    'ToolStripStatusLabel1
    '
    Me.ToolStripStatusLabel1.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
                Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
                Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
    Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
    Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(276, 17)
    Me.ToolStripStatusLabel1.Spring = True
    Me.ToolStripStatusLabel1.Text = "Ctrl + G - Guardar"
    '
    'ToolStripStatusLabel2
    '
    Me.ToolStripStatusLabel2.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
                Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
                Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
    Me.ToolStripStatusLabel2.Name = "ToolStripStatusLabel2"
    Me.ToolStripStatusLabel2.Size = New System.Drawing.Size(276, 17)
    Me.ToolStripStatusLabel2.Spring = True
    Me.ToolStripStatusLabel2.Text = "F8 - Limpiar"
    '
    'btn_buscar
    '
    Me.btn_buscar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
    Me.btn_buscar.Image = CType(resources.GetObject("btn_buscar.Image"), System.Drawing.Image)
    Me.btn_buscar.ImageTransparentColor = System.Drawing.Color.Magenta
    Me.btn_buscar.Name = "btn_buscar"
    Me.btn_buscar.Size = New System.Drawing.Size(28, 28)
    Me.btn_buscar.Text = "ToolStripButton1"
    '
    'btn_limpiar
    '
    Me.btn_limpiar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
    Me.btn_limpiar.Image = CType(resources.GetObject("btn_limpiar.Image"), System.Drawing.Image)
    Me.btn_limpiar.ImageTransparentColor = System.Drawing.Color.Magenta
    Me.btn_limpiar.Name = "btn_limpiar"
    Me.btn_limpiar.Size = New System.Drawing.Size(28, 28)
    Me.btn_limpiar.Text = "ToolStripButton2"
    '
    'ToolStripSeparator2
    '
    Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
    Me.ToolStripSeparator2.Size = New System.Drawing.Size(6, 31)
    '
    'btn_salir
    '
    Me.btn_salir.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
    Me.btn_salir.Image = CType(resources.GetObject("btn_salir.Image"), System.Drawing.Image)
    Me.btn_salir.ImageTransparentColor = System.Drawing.Color.Magenta
    Me.btn_salir.Name = "btn_salir"
    Me.btn_salir.Size = New System.Drawing.Size(28, 28)
    Me.btn_salir.Text = "ToolStripButton3"
    '
    'ToolStripButton4
    '
    Me.ToolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
    Me.ToolStripButton4.Image = CType(resources.GetObject("ToolStripButton4.Image"), System.Drawing.Image)
    Me.ToolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta
    Me.ToolStripButton4.Name = "ToolStripButton4"
    Me.ToolStripButton4.Size = New System.Drawing.Size(28, 28)
    Me.ToolStripButton4.Text = "ToolStripButton4"
    '
    'base
    '
    Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
    Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
    Me.ClientSize = New System.Drawing.Size(568, 364)
    Me.Controls.Add(Me.StatusStrip1)
    Me.Controls.Add(Me.Toolbar)
    Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
    Me.Name = "base"
    Me.Toolbar.ResumeLayout(False)
    Me.Toolbar.PerformLayout()
    Me.StatusStrip1.ResumeLayout(False)
    Me.StatusStrip1.PerformLayout()
    Me.ResumeLayout(False)
    Me.PerformLayout()

  End Sub
  Friend WithEvents Toolbar As System.Windows.Forms.ToolStrip
  Friend WithEvents btn_agregar As System.Windows.Forms.ToolStripButton
  Friend WithEvents btn_eliminar As System.Windows.Forms.ToolStripButton
  Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
  Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
  Friend WithEvents ToolStripStatusLabel1 As System.Windows.Forms.ToolStripStatusLabel
  Friend WithEvents ToolStripStatusLabel2 As System.Windows.Forms.ToolStripStatusLabel
  Friend WithEvents btn_guardar As System.Windows.Forms.ToolStripButton
  Friend WithEvents btn_Imprimir As System.Windows.Forms.ToolStripButton
  Friend WithEvents btn_buscar As System.Windows.Forms.ToolStripButton
  Friend WithEvents btn_limpiar As System.Windows.Forms.ToolStripButton
  Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
  Friend WithEvents btn_salir As System.Windows.Forms.ToolStripButton
  Friend WithEvents ToolStripButton4 As System.Windows.Forms.ToolStripButton

End Class
