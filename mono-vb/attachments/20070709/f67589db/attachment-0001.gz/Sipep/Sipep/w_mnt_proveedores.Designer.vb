<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class w_mnt_Proveedores
  Inherits WindowsApplication1.base

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
    Me.co_proveedor = New System.Windows.Forms.TextBox
    Me.Label1 = New System.Windows.Forms.Label
    Me.Label2 = New System.Windows.Forms.Label
    Me.de_proveedor = New System.Windows.Forms.TextBox
    Me.Label3 = New System.Windows.Forms.Label
    Me.da_representante = New System.Windows.Forms.TextBox
    Me.Label4 = New System.Windows.Forms.Label
    Me.da_direccion = New System.Windows.Forms.TextBox
    Me.Label5 = New System.Windows.Forms.Label
    Me.da_telefono = New System.Windows.Forms.TextBox
    Me.Label6 = New System.Windows.Forms.Label
    Me.da_fax = New System.Windows.Forms.TextBox
    Me.Label7 = New System.Windows.Forms.Label
    Me.da_nit = New System.Windows.Forms.TextBox
    Me.Label8 = New System.Windows.Forms.Label
    Me.da_rif = New System.Windows.Forms.TextBox
    Me.st_personalidad = New System.Windows.Forms.CheckBox
    Me.st_domiciliado = New System.Windows.Forms.CheckBox
    Me.st_rif = New System.Windows.Forms.CheckBox
    Me.st_constituido = New System.Windows.Forms.CheckBox
    Me.Validar = New System.Windows.Forms.Button
    Me.GroupBox1 = New System.Windows.Forms.GroupBox
    Me.Label14 = New System.Windows.Forms.Label
    Me.da_zona_postal = New System.Windows.Forms.TextBox
    Me.Label13 = New System.Windows.Forms.Label
    Me.da_estado = New System.Windows.Forms.TextBox
    Me.Label12 = New System.Windows.Forms.Label
    Me.da_ciudad = New System.Windows.Forms.TextBox
    Me.Label11 = New System.Windows.Forms.Label
    Me.da_distrito = New System.Windows.Forms.TextBox
    Me.Label10 = New System.Windows.Forms.Label
    Me.da_municipio = New System.Windows.Forms.TextBox
    Me.GroupBox2 = New System.Windows.Forms.GroupBox
    Me.Label17 = New System.Windows.Forms.Label
    Me.co_cuenta = New System.Windows.Forms.TextBox
    Me.Command2 = New System.Windows.Forms.Button
    Me.de_tipo = New System.Windows.Forms.TextBox
    Me.Label16 = New System.Windows.Forms.Label
    Me.co_tipo = New System.Windows.Forms.TextBox
    Me.Command1 = New System.Windows.Forms.Button
    Me.de_banco = New System.Windows.Forms.TextBox
    Me.Label15 = New System.Windows.Forms.Label
    Me.co_banco = New System.Windows.Forms.TextBox
    Me.Label9 = New System.Windows.Forms.Label
    Me.da_observaciones = New System.Windows.Forms.TextBox
    Me.GroupBox1.SuspendLayout()
    Me.GroupBox2.SuspendLayout()
    Me.SuspendLayout()
    '
    'co_proveedor
    '
    Me.co_proveedor.Location = New System.Drawing.Point(95, 43)
    Me.co_proveedor.Name = "co_proveedor"
    Me.co_proveedor.Size = New System.Drawing.Size(108, 20)
    Me.co_proveedor.TabIndex = 1
    Me.co_proveedor.Text = "co_proveedor"
    '
    'Label1
    '
    Me.Label1.AutoSize = True
    Me.Label1.Location = New System.Drawing.Point(12, 43)
    Me.Label1.Name = "Label1"
    Me.Label1.Size = New System.Drawing.Size(40, 13)
    Me.Label1.TabIndex = 2
    Me.Label1.Text = "C�digo"
    '
    'Label2
    '
    Me.Label2.AutoSize = True
    Me.Label2.Location = New System.Drawing.Point(12, 69)
    Me.Label2.Name = "Label2"
    Me.Label2.Size = New System.Drawing.Size(44, 13)
    Me.Label2.TabIndex = 4
    Me.Label2.Text = "Nombre"
    '
    'de_proveedor
    '
    Me.de_proveedor.Location = New System.Drawing.Point(95, 69)
    Me.de_proveedor.Name = "de_proveedor"
    Me.de_proveedor.Size = New System.Drawing.Size(289, 20)
    Me.de_proveedor.TabIndex = 3
    Me.de_proveedor.Text = "de_proveedor"
    '
    'Label3
    '
    Me.Label3.AutoSize = True
    Me.Label3.Location = New System.Drawing.Point(12, 95)
    Me.Label3.Name = "Label3"
    Me.Label3.Size = New System.Drawing.Size(77, 13)
    Me.Label3.TabIndex = 6
    Me.Label3.Text = "Representante"
    '
    'da_representante
    '
    Me.da_representante.Location = New System.Drawing.Point(95, 95)
    Me.da_representante.Name = "da_representante"
    Me.da_representante.Size = New System.Drawing.Size(289, 20)
    Me.da_representante.TabIndex = 5
    Me.da_representante.Text = "da_representante"
    '
    'Label4
    '
    Me.Label4.AutoSize = True
    Me.Label4.Location = New System.Drawing.Point(12, 121)
    Me.Label4.Name = "Label4"
    Me.Label4.Size = New System.Drawing.Size(52, 13)
    Me.Label4.TabIndex = 8
    Me.Label4.Text = "Direcci�n"
    '
    'da_direccion
    '
    Me.da_direccion.Location = New System.Drawing.Point(95, 118)
    Me.da_direccion.Name = "da_direccion"
    Me.da_direccion.Size = New System.Drawing.Size(289, 20)
    Me.da_direccion.TabIndex = 7
    Me.da_direccion.Text = "da_direccion"
    '
    'Label5
    '
    Me.Label5.AutoSize = True
    Me.Label5.Location = New System.Drawing.Point(12, 144)
    Me.Label5.Name = "Label5"
    Me.Label5.Size = New System.Drawing.Size(49, 13)
    Me.Label5.TabIndex = 10
    Me.Label5.Text = "Telefono"
    '
    'da_telefono
    '
    Me.da_telefono.Location = New System.Drawing.Point(95, 144)
    Me.da_telefono.Name = "da_telefono"
    Me.da_telefono.Size = New System.Drawing.Size(108, 20)
    Me.da_telefono.TabIndex = 9
    Me.da_telefono.Text = "da_telefono"
    '
    'Label6
    '
    Me.Label6.AutoSize = True
    Me.Label6.Location = New System.Drawing.Point(12, 170)
    Me.Label6.Name = "Label6"
    Me.Label6.Size = New System.Drawing.Size(24, 13)
    Me.Label6.TabIndex = 12
    Me.Label6.Text = "Fax"
    '
    'da_fax
    '
    Me.da_fax.Location = New System.Drawing.Point(95, 170)
    Me.da_fax.Name = "da_fax"
    Me.da_fax.Size = New System.Drawing.Size(108, 20)
    Me.da_fax.TabIndex = 11
    Me.da_fax.Text = "da_fax"
    '
    'Label7
    '
    Me.Label7.AutoSize = True
    Me.Label7.Location = New System.Drawing.Point(213, 170)
    Me.Label7.Name = "Label7"
    Me.Label7.Size = New System.Drawing.Size(34, 13)
    Me.Label7.TabIndex = 16
    Me.Label7.Text = "N.I.T."
    '
    'da_nit
    '
    Me.da_nit.Location = New System.Drawing.Point(276, 170)
    Me.da_nit.Name = "da_nit"
    Me.da_nit.Size = New System.Drawing.Size(108, 20)
    Me.da_nit.TabIndex = 15
    Me.da_nit.Text = "da_nit"
    '
    'Label8
    '
    Me.Label8.AutoSize = True
    Me.Label8.Location = New System.Drawing.Point(213, 144)
    Me.Label8.Name = "Label8"
    Me.Label8.Size = New System.Drawing.Size(44, 13)
    Me.Label8.TabIndex = 14
    Me.Label8.Text = "Rif./C.I."
    '
    'da_rif
    '
    Me.da_rif.Location = New System.Drawing.Point(276, 144)
    Me.da_rif.Name = "da_rif"
    Me.da_rif.Size = New System.Drawing.Size(108, 20)
    Me.da_rif.TabIndex = 13
    Me.da_rif.Text = "da_rif"
    '
    'st_personalidad
    '
    Me.st_personalidad.AutoSize = True
    Me.st_personalidad.Location = New System.Drawing.Point(403, 91)
    Me.st_personalidad.Name = "st_personalidad"
    Me.st_personalidad.Size = New System.Drawing.Size(62, 17)
    Me.st_personalidad.TabIndex = 17
    Me.st_personalidad.Text = "Juridico"
    Me.st_personalidad.UseVisualStyleBackColor = True
    '
    'st_domiciliado
    '
    Me.st_domiciliado.AutoSize = True
    Me.st_domiciliado.Location = New System.Drawing.Point(403, 111)
    Me.st_domiciliado.Name = "st_domiciliado"
    Me.st_domiciliado.Size = New System.Drawing.Size(80, 17)
    Me.st_domiciliado.TabIndex = 18
    Me.st_domiciliado.Text = "Domiciliado"
    Me.st_domiciliado.UseVisualStyleBackColor = True
    '
    'st_rif
    '
    Me.st_rif.AutoSize = True
    Me.st_rif.Location = New System.Drawing.Point(487, 110)
    Me.st_rif.Name = "st_rif"
    Me.st_rif.Size = New System.Drawing.Size(84, 17)
    Me.st_rif.TabIndex = 20
    Me.st_rif.Text = "R.I.F. V�lido"
    Me.st_rif.UseVisualStyleBackColor = True
    '
    'st_constituido
    '
    Me.st_constituido.AutoSize = True
    Me.st_constituido.Location = New System.Drawing.Point(487, 90)
    Me.st_constituido.Name = "st_constituido"
    Me.st_constituido.Size = New System.Drawing.Size(78, 17)
    Me.st_constituido.TabIndex = 19
    Me.st_constituido.Text = "Constituido"
    Me.st_constituido.UseVisualStyleBackColor = True
    '
    'Validar
    '
    Me.Validar.Location = New System.Drawing.Point(418, 153)
    Me.Validar.Name = "Validar"
    Me.Validar.Size = New System.Drawing.Size(121, 37)
    Me.Validar.TabIndex = 21
    Me.Validar.Text = "Consultar R.I.F."
    Me.Validar.UseVisualStyleBackColor = True
    '
    'GroupBox1
    '
    Me.GroupBox1.Controls.Add(Me.Label14)
    Me.GroupBox1.Controls.Add(Me.da_zona_postal)
    Me.GroupBox1.Controls.Add(Me.Label13)
    Me.GroupBox1.Controls.Add(Me.da_estado)
    Me.GroupBox1.Controls.Add(Me.Label12)
    Me.GroupBox1.Controls.Add(Me.da_ciudad)
    Me.GroupBox1.Controls.Add(Me.Label11)
    Me.GroupBox1.Controls.Add(Me.da_distrito)
    Me.GroupBox1.Controls.Add(Me.Label10)
    Me.GroupBox1.Controls.Add(Me.da_municipio)
    Me.GroupBox1.Location = New System.Drawing.Point(18, 200)
    Me.GroupBox1.Name = "GroupBox1"
    Me.GroupBox1.Size = New System.Drawing.Size(229, 152)
    Me.GroupBox1.TabIndex = 22
    Me.GroupBox1.TabStop = False
    Me.GroupBox1.Text = "Localidad"
    '
    'Label14
    '
    Me.Label14.AutoSize = True
    Me.Label14.Location = New System.Drawing.Point(8, 123)
    Me.Label14.Name = "Label14"
    Me.Label14.Size = New System.Drawing.Size(64, 13)
    Me.Label14.TabIndex = 24
    Me.Label14.Text = "Zona Postal"
    '
    'da_zona_postal
    '
    Me.da_zona_postal.Location = New System.Drawing.Point(77, 123)
    Me.da_zona_postal.Name = "da_zona_postal"
    Me.da_zona_postal.Size = New System.Drawing.Size(108, 20)
    Me.da_zona_postal.TabIndex = 23
    Me.da_zona_postal.Text = "da_zona_postal"
    '
    'Label13
    '
    Me.Label13.AutoSize = True
    Me.Label13.Location = New System.Drawing.Point(7, 97)
    Me.Label13.Name = "Label13"
    Me.Label13.Size = New System.Drawing.Size(40, 13)
    Me.Label13.TabIndex = 22
    Me.Label13.Text = "Estado"
    '
    'da_estado
    '
    Me.da_estado.Location = New System.Drawing.Point(77, 97)
    Me.da_estado.Name = "da_estado"
    Me.da_estado.Size = New System.Drawing.Size(108, 20)
    Me.da_estado.TabIndex = 21
    Me.da_estado.Text = "da_estado"
    '
    'Label12
    '
    Me.Label12.AutoSize = True
    Me.Label12.Location = New System.Drawing.Point(7, 71)
    Me.Label12.Name = "Label12"
    Me.Label12.Size = New System.Drawing.Size(40, 13)
    Me.Label12.TabIndex = 20
    Me.Label12.Text = "Ciudad"
    '
    'da_ciudad
    '
    Me.da_ciudad.Location = New System.Drawing.Point(77, 71)
    Me.da_ciudad.Name = "da_ciudad"
    Me.da_ciudad.Size = New System.Drawing.Size(108, 20)
    Me.da_ciudad.TabIndex = 19
    Me.da_ciudad.Text = "da_ciudad"
    '
    'Label11
    '
    Me.Label11.AutoSize = True
    Me.Label11.Location = New System.Drawing.Point(7, 45)
    Me.Label11.Name = "Label11"
    Me.Label11.Size = New System.Drawing.Size(39, 13)
    Me.Label11.TabIndex = 18
    Me.Label11.Text = "Distrito"
    '
    'da_distrito
    '
    Me.da_distrito.Location = New System.Drawing.Point(77, 45)
    Me.da_distrito.Name = "da_distrito"
    Me.da_distrito.Size = New System.Drawing.Size(108, 20)
    Me.da_distrito.TabIndex = 17
    Me.da_distrito.Text = "da_distrito"
    '
    'Label10
    '
    Me.Label10.AutoSize = True
    Me.Label10.Location = New System.Drawing.Point(6, 19)
    Me.Label10.Name = "Label10"
    Me.Label10.Size = New System.Drawing.Size(52, 13)
    Me.Label10.TabIndex = 16
    Me.Label10.Text = "Municipio"
    '
    'da_municipio
    '
    Me.da_municipio.Location = New System.Drawing.Point(77, 19)
    Me.da_municipio.Name = "da_municipio"
    Me.da_municipio.Size = New System.Drawing.Size(108, 20)
    Me.da_municipio.TabIndex = 15
    Me.da_municipio.Text = "da_municipio"
    '
    'GroupBox2
    '
    Me.GroupBox2.Controls.Add(Me.Label17)
    Me.GroupBox2.Controls.Add(Me.co_cuenta)
    Me.GroupBox2.Controls.Add(Me.Command2)
    Me.GroupBox2.Controls.Add(Me.de_tipo)
    Me.GroupBox2.Controls.Add(Me.Label16)
    Me.GroupBox2.Controls.Add(Me.co_tipo)
    Me.GroupBox2.Controls.Add(Me.Command1)
    Me.GroupBox2.Controls.Add(Me.de_banco)
    Me.GroupBox2.Controls.Add(Me.Label15)
    Me.GroupBox2.Controls.Add(Me.co_banco)
    Me.GroupBox2.Location = New System.Drawing.Point(253, 200)
    Me.GroupBox2.Name = "GroupBox2"
    Me.GroupBox2.Size = New System.Drawing.Size(310, 152)
    Me.GroupBox2.TabIndex = 23
    Me.GroupBox2.TabStop = False
    Me.GroupBox2.Text = "Bancos"
    '
    'Label17
    '
    Me.Label17.AutoSize = True
    Me.Label17.Location = New System.Drawing.Point(9, 106)
    Me.Label17.Name = "Label17"
    Me.Label17.Size = New System.Drawing.Size(41, 13)
    Me.Label17.TabIndex = 26
    Me.Label17.Text = "Cuenta"
    '
    'co_cuenta
    '
    Me.co_cuenta.Location = New System.Drawing.Point(67, 106)
    Me.co_cuenta.Name = "co_cuenta"
    Me.co_cuenta.Size = New System.Drawing.Size(200, 20)
    Me.co_cuenta.TabIndex = 25
    Me.co_cuenta.Text = "co_cuenta"
    '
    'Command2
    '
    Me.Command2.Location = New System.Drawing.Point(277, 73)
    Me.Command2.Margin = New System.Windows.Forms.Padding(0)
    Me.Command2.Name = "Command2"
    Me.Command2.Size = New System.Drawing.Size(23, 19)
    Me.Command2.TabIndex = 24
    Me.Command2.Text = "..."
    Me.Command2.UseVisualStyleBackColor = True
    '
    'de_tipo
    '
    Me.de_tipo.Location = New System.Drawing.Point(128, 73)
    Me.de_tipo.Name = "de_tipo"
    Me.de_tipo.Size = New System.Drawing.Size(139, 20)
    Me.de_tipo.TabIndex = 23
    Me.de_tipo.Text = "de_tipo"
    '
    'Label16
    '
    Me.Label16.AutoSize = True
    Me.Label16.Location = New System.Drawing.Point(9, 76)
    Me.Label16.Name = "Label16"
    Me.Label16.Size = New System.Drawing.Size(28, 13)
    Me.Label16.TabIndex = 22
    Me.Label16.Text = "Tipo"
    '
    'co_tipo
    '
    Me.co_tipo.Location = New System.Drawing.Point(69, 73)
    Me.co_tipo.Name = "co_tipo"
    Me.co_tipo.Size = New System.Drawing.Size(58, 20)
    Me.co_tipo.TabIndex = 21
    Me.co_tipo.Text = "co_tipo"
    '
    'Command1
    '
    Me.Command1.Location = New System.Drawing.Point(277, 34)
    Me.Command1.Margin = New System.Windows.Forms.Padding(0)
    Me.Command1.Name = "Command1"
    Me.Command1.Size = New System.Drawing.Size(23, 19)
    Me.Command1.TabIndex = 20
    Me.Command1.Text = "..."
    Me.Command1.UseVisualStyleBackColor = True
    '
    'de_banco
    '
    Me.de_banco.Location = New System.Drawing.Point(128, 34)
    Me.de_banco.Name = "de_banco"
    Me.de_banco.Size = New System.Drawing.Size(139, 20)
    Me.de_banco.TabIndex = 19
    Me.de_banco.Text = "de_banco"
    '
    'Label15
    '
    Me.Label15.AutoSize = True
    Me.Label15.Location = New System.Drawing.Point(9, 37)
    Me.Label15.Name = "Label15"
    Me.Label15.Size = New System.Drawing.Size(38, 13)
    Me.Label15.TabIndex = 18
    Me.Label15.Text = "Banco"
    '
    'co_banco
    '
    Me.co_banco.Location = New System.Drawing.Point(69, 34)
    Me.co_banco.Name = "co_banco"
    Me.co_banco.Size = New System.Drawing.Size(58, 20)
    Me.co_banco.TabIndex = 17
    Me.co_banco.Text = "co_banco"
    '
    'Label9
    '
    Me.Label9.AutoSize = True
    Me.Label9.Location = New System.Drawing.Point(12, 360)
    Me.Label9.Name = "Label9"
    Me.Label9.Size = New System.Drawing.Size(78, 13)
    Me.Label9.TabIndex = 25
    Me.Label9.Text = "Observaciones"
    '
    'da_observaciones
    '
    Me.da_observaciones.Location = New System.Drawing.Point(95, 360)
    Me.da_observaciones.Name = "da_observaciones"
    Me.da_observaciones.Size = New System.Drawing.Size(468, 20)
    Me.da_observaciones.TabIndex = 24
    Me.da_observaciones.Text = "da_observaciones"
    '
    'w_mnt_Proveedores
    '
    Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
    Me.ClientSize = New System.Drawing.Size(575, 415)
    Me.Controls.Add(Me.Label9)
    Me.Controls.Add(Me.da_observaciones)
    Me.Controls.Add(Me.GroupBox2)
    Me.Controls.Add(Me.GroupBox1)
    Me.Controls.Add(Me.Validar)
    Me.Controls.Add(Me.st_rif)
    Me.Controls.Add(Me.st_constituido)
    Me.Controls.Add(Me.st_domiciliado)
    Me.Controls.Add(Me.st_personalidad)
    Me.Controls.Add(Me.Label7)
    Me.Controls.Add(Me.da_nit)
    Me.Controls.Add(Me.Label8)
    Me.Controls.Add(Me.da_rif)
    Me.Controls.Add(Me.Label6)
    Me.Controls.Add(Me.da_fax)
    Me.Controls.Add(Me.Label5)
    Me.Controls.Add(Me.da_telefono)
    Me.Controls.Add(Me.Label4)
    Me.Controls.Add(Me.da_direccion)
    Me.Controls.Add(Me.Label3)
    Me.Controls.Add(Me.da_representante)
    Me.Controls.Add(Me.Label2)
    Me.Controls.Add(Me.de_proveedor)
    Me.Controls.Add(Me.Label1)
    Me.Controls.Add(Me.co_proveedor)
    Me.Name = "w_mnt_Proveedores"
    Me.Text = "Mantenimiento de Proveedores"
    Me.Controls.SetChildIndex(Me.co_proveedor, 0)
    Me.Controls.SetChildIndex(Me.Label1, 0)
    Me.Controls.SetChildIndex(Me.de_proveedor, 0)
    Me.Controls.SetChildIndex(Me.Label2, 0)
    Me.Controls.SetChildIndex(Me.da_representante, 0)
    Me.Controls.SetChildIndex(Me.Label3, 0)
    Me.Controls.SetChildIndex(Me.da_direccion, 0)
    Me.Controls.SetChildIndex(Me.Label4, 0)
    Me.Controls.SetChildIndex(Me.da_telefono, 0)
    Me.Controls.SetChildIndex(Me.Label5, 0)
    Me.Controls.SetChildIndex(Me.da_fax, 0)
    Me.Controls.SetChildIndex(Me.Label6, 0)
    Me.Controls.SetChildIndex(Me.da_rif, 0)
    Me.Controls.SetChildIndex(Me.Label8, 0)
    Me.Controls.SetChildIndex(Me.da_nit, 0)
    Me.Controls.SetChildIndex(Me.Label7, 0)
    Me.Controls.SetChildIndex(Me.st_personalidad, 0)
    Me.Controls.SetChildIndex(Me.st_domiciliado, 0)
    Me.Controls.SetChildIndex(Me.st_constituido, 0)
    Me.Controls.SetChildIndex(Me.st_rif, 0)
    Me.Controls.SetChildIndex(Me.Validar, 0)
    Me.Controls.SetChildIndex(Me.GroupBox1, 0)
    Me.Controls.SetChildIndex(Me.GroupBox2, 0)
    Me.Controls.SetChildIndex(Me.da_observaciones, 0)
    Me.Controls.SetChildIndex(Me.Label9, 0)
    Me.GroupBox1.ResumeLayout(False)
    Me.GroupBox1.PerformLayout()
    Me.GroupBox2.ResumeLayout(False)
    Me.GroupBox2.PerformLayout()
    Me.ResumeLayout(False)
    Me.PerformLayout()

  End Sub
    Friend WithEvents co_proveedor As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents de_proveedor As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents da_representante As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents da_direccion As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents da_telefono As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents da_fax As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents da_nit As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents da_rif As System.Windows.Forms.TextBox
    Friend WithEvents st_personalidad As System.Windows.Forms.CheckBox
    Friend WithEvents st_domiciliado As System.Windows.Forms.CheckBox
    Friend WithEvents st_rif As System.Windows.Forms.CheckBox
    Friend WithEvents st_constituido As System.Windows.Forms.CheckBox
    Friend WithEvents Validar As System.Windows.Forms.Button
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents da_observaciones As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents da_zona_postal As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents da_estado As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents da_ciudad As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents da_distrito As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents da_municipio As System.Windows.Forms.TextBox
    Friend WithEvents Command1 As System.Windows.Forms.Button
    Friend WithEvents de_banco As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents co_banco As System.Windows.Forms.TextBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents co_cuenta As System.Windows.Forms.TextBox
    Friend WithEvents Command2 As System.Windows.Forms.Button
    Friend WithEvents de_tipo As System.Windows.Forms.TextBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
  Friend WithEvents co_tipo As System.Windows.Forms.TextBox

End Class
