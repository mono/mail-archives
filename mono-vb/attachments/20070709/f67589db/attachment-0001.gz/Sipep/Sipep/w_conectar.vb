Public Class w_conectar

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        On Error GoTo menErr
        NpgConn = New Npgsql.NpgsqlConnection("Server=" & host.Text & ";User Id=" & usuario.Text & ";Password=" & Pass.Text & ";Database=" & database.Text & ";Encoding=UNICODE;")
        'NpgConn = New Npgsql.NpgsqlConnection("Server=127.0.0.1;User Id=postgres;Password=654321;Database=postgres;Encoding=UNICODE;")
        NpgConn.Open()
        MsgBox("Conectado!")
        Hide()
        Return
menErr:
        MsgBox("Error: Conexi�n con Servidor!")
    End Sub

    Private Sub w_conectar_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class