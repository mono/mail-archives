<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class w_conectar
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.frmLogin = New System.Windows.Forms.GroupBox
        Me.Tabla = New System.Windows.Forms.TextBox
        Me.Pass = New System.Windows.Forms.TextBox
        Me.usuario = New System.Windows.Forms.TextBox
        Me.database = New System.Windows.Forms.TextBox
        Me.host = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.Button1 = New System.Windows.Forms.Button
        Me.frmLogin.SuspendLayout()
        Me.SuspendLayout()
        '
        'frmLogin
        '
        Me.frmLogin.BackColor = System.Drawing.SystemColors.Control
        Me.frmLogin.Controls.Add(Me.Tabla)
        Me.frmLogin.Controls.Add(Me.Pass)
        Me.frmLogin.Controls.Add(Me.usuario)
        Me.frmLogin.Controls.Add(Me.database)
        Me.frmLogin.Controls.Add(Me.host)
        Me.frmLogin.Controls.Add(Me.Label5)
        Me.frmLogin.Controls.Add(Me.Label4)
        Me.frmLogin.Controls.Add(Me.Label3)
        Me.frmLogin.Controls.Add(Me.Label2)
        Me.frmLogin.Controls.Add(Me.Label1)
        Me.frmLogin.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.frmLogin.ForeColor = System.Drawing.SystemColors.ControlText
        Me.frmLogin.Location = New System.Drawing.Point(12, 12)
        Me.frmLogin.Name = "frmLogin"
        Me.frmLogin.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.frmLogin.Size = New System.Drawing.Size(297, 152)
        Me.frmLogin.TabIndex = 1
        Me.frmLogin.TabStop = False
        Me.frmLogin.Text = "Connect Setting"
        '
        'Tabla
        '
        Me.Tabla.AcceptsReturn = True
        Me.Tabla.BackColor = System.Drawing.SystemColors.Window
        Me.Tabla.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.Tabla.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Tabla.Location = New System.Drawing.Point(96, 117)
        Me.Tabla.MaxLength = 0
        Me.Tabla.Name = "Tabla"
        Me.Tabla.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Tabla.Size = New System.Drawing.Size(185, 21)
        Me.Tabla.TabIndex = 10
        '
        'Pass
        '
        Me.Pass.AcceptsReturn = True
        Me.Pass.BackColor = System.Drawing.SystemColors.Window
        Me.Pass.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.Pass.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Pass.Location = New System.Drawing.Point(96, 92)
        Me.Pass.MaxLength = 0
        Me.Pass.Name = "Pass"
        Me.Pass.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.Pass.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Pass.Size = New System.Drawing.Size(185, 21)
        Me.Pass.TabIndex = 9
        '
        'usuario
        '
        Me.usuario.AcceptsReturn = True
        Me.usuario.BackColor = System.Drawing.SystemColors.Window
        Me.usuario.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.usuario.ForeColor = System.Drawing.SystemColors.WindowText
        Me.usuario.Location = New System.Drawing.Point(96, 68)
        Me.usuario.MaxLength = 0
        Me.usuario.Name = "usuario"
        Me.usuario.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.usuario.Size = New System.Drawing.Size(185, 21)
        Me.usuario.TabIndex = 8
        Me.usuario.Text = "postgres"
        '
        'database
        '
        Me.database.AcceptsReturn = True
        Me.database.BackColor = System.Drawing.SystemColors.Window
        Me.database.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.database.ForeColor = System.Drawing.SystemColors.WindowText
        Me.database.Location = New System.Drawing.Point(96, 43)
        Me.database.MaxLength = 0
        Me.database.Name = "database"
        Me.database.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.database.Size = New System.Drawing.Size(185, 21)
        Me.database.TabIndex = 7
        Me.database.Text = "postgres"
        '
        'host
        '
        Me.host.AcceptsReturn = True
        Me.host.BackColor = System.Drawing.SystemColors.Window
        Me.host.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.host.ForeColor = System.Drawing.SystemColors.WindowText
        Me.host.Location = New System.Drawing.Point(96, 18)
        Me.host.MaxLength = 0
        Me.host.Name = "host"
        Me.host.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.host.Size = New System.Drawing.Size(185, 21)
        Me.host.TabIndex = 6
        Me.host.Text = "localhost"
        '
        'Label5
        '
        Me.Label5.BackColor = System.Drawing.SystemColors.Control
        Me.Label5.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label5.Location = New System.Drawing.Point(8, 120)
        Me.Label5.Name = "Label5"
        Me.Label5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label5.Size = New System.Drawing.Size(80, 16)
        Me.Label5.TabIndex = 5
        Me.Label5.Text = "Tabla:"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.SystemColors.Control
        Me.Label4.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label4.Location = New System.Drawing.Point(8, 92)
        Me.Label4.Name = "Label4"
        Me.Label4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label4.Size = New System.Drawing.Size(80, 20)
        Me.Label4.TabIndex = 4
        Me.Label4.Text = "Password:"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.SystemColors.Control
        Me.Label3.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label3.Location = New System.Drawing.Point(8, 68)
        Me.Label3.Name = "Label3"
        Me.Label3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label3.Size = New System.Drawing.Size(80, 20)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Usuario:"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.SystemColors.Control
        Me.Label2.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label2.Location = New System.Drawing.Point(8, 43)
        Me.Label2.Name = "Label2"
        Me.Label2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label2.Size = New System.Drawing.Size(80, 13)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "DataBase:"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.SystemColors.Control
        Me.Label1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label1.Location = New System.Drawing.Point(8, 18)
        Me.Label1.Name = "Label1"
        Me.Label1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label1.Size = New System.Drawing.Size(80, 14)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Host:"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(238, 177)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(71, 23)
        Me.Button1.TabIndex = 2
        Me.Button1.Text = "Conectar"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'w_conectar
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(323, 211)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.frmLogin)
        Me.Name = "w_conectar"
        Me.Text = "Conexi�n PostgreSQL"
        Me.frmLogin.ResumeLayout(False)
        Me.frmLogin.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Public WithEvents frmLogin As System.Windows.Forms.GroupBox
    Public WithEvents Tabla As System.Windows.Forms.TextBox
    Public WithEvents Pass As System.Windows.Forms.TextBox
    Public WithEvents usuario As System.Windows.Forms.TextBox
    Public WithEvents database As System.Windows.Forms.TextBox
    Public WithEvents host As System.Windows.Forms.TextBox
    Public WithEvents Label5 As System.Windows.Forms.Label
    Public WithEvents Label4 As System.Windows.Forms.Label
    Public WithEvents Label3 As System.Windows.Forms.Label
    Public WithEvents Label2 As System.Windows.Forms.Label
    Public WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
End Class
