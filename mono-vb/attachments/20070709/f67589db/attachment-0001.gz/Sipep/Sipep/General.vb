Module General
  Public NpgConn As Npgsql.NpgsqlConnection
  Public NpgCmd As Npgsql.NpgsqlCommand
  Public NpgDRead As Npgsql.NpgsqlDataReader
  Public NpgTrans As Npgsql.NpgsqlTransaction
  Public NpgDAdap As Npgsql.NpgsqlDataAdapter
  Public NpgCmdBld As Npgsql.NpgsqlCommandBuilder
  Public binding1 As BindingSource
  Public ds As DataSet
  Public cadena As String
  Public SysDset As DataSet
  Public SysDrow As DataRow

End Module
