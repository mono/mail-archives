Imports System.Net.IPAddress

Public Class w_mnt_Proveedores
  Public LV_COMANDO As Integer

  Sub DB_PROVEEDORES()
    co_proveedor.Enabled = True
    de_proveedor.Enabled = True
    da_representante.Enabled = True
    da_direccion.Enabled = True
    da_telefono.Enabled = True
    da_fax.Enabled = True
    da_rif.Enabled = True
    da_nit.Enabled = True
    st_personalidad.Enabled = True
    st_constituido.Enabled = True
    st_domiciliado.Enabled = True
    st_rif.Enabled = True
    da_municipio.Enabled = True
    da_distrito.Enabled = True
    da_ciudad.Enabled = True
    da_estado.Enabled = True
    da_zona_postal.Enabled = True
    co_banco.Enabled = True
    de_banco.Enabled = True
    Command1.Enabled = True
    co_tipo.Enabled = True
    de_tipo.Enabled = True
    Command2.Enabled = True
    co_cuenta.Enabled = True
    da_observaciones.Enabled = True
    Validar.Enabled = True
  End Sub
  Sub LP_PROVEEDORES()

    co_proveedor.Text = ""
    de_proveedor.Text = ""
    da_representante.Text = ""
    da_direccion.Text = ""
    da_telefono.Text = ""
    da_fax.Text = ""
    da_rif.Text = ""
    da_nit.Text = ""
    st_personalidad.Checked = False
    st_constituido.Checked = False
    st_domiciliado.Checked = False
    st_rif.Checked = False
    da_municipio.Text = ""
    da_distrito.Text = ""
    da_ciudad.Text = ""
    da_estado.Text = ""
    da_zona_postal.Text = ""
    co_banco.Text = ""
    de_banco.Text = ""
    co_tipo.Text = ""
    de_tipo.Text = ""
    co_cuenta.Text = ""
    da_observaciones.Text = ""
    'dc_conceptos.Text = ""

    co_proveedor.Enabled = False
    de_proveedor.Enabled = False
    da_representante.Enabled = False
    da_direccion.Enabled = False
    da_telefono.Enabled = False
    da_fax.Enabled = False
    da_rif.Enabled = False
    da_nit.Enabled = False
    st_personalidad.Enabled = False
    st_constituido.Enabled = False
    st_domiciliado.Enabled = False
    st_rif.Enabled = False
    da_municipio.Enabled = False
    da_distrito.Enabled = False
    da_ciudad.Enabled = False
    da_estado.Enabled = False
    da_zona_postal.Enabled = False
    co_banco.Enabled = False
    de_banco.Enabled = False
    Command1.Enabled = False
    co_tipo.Enabled = False
    de_tipo.Enabled = False
    Command2.Enabled = False
    co_cuenta.Enabled = False
    da_observaciones.Enabled = False
    Validar.Enabled = False
    'Frame1.Visible = False
    'f_progreso.Visible = False
    'TreeView1.Nodes.Clear()

    co_proveedor.BackColor = Color.White
    de_proveedor.BackColor = Color.White
    da_representante.BackColor = Color.White
    da_direccion.BackColor = Color.White
    da_telefono.BackColor = Color.White
    da_fax.BackColor = Color.White
    da_rif.BackColor = Color.White
    da_nit.BackColor = Color.White
    da_municipio.BackColor = Color.White
    da_distrito.BackColor = Color.White
    da_ciudad.BackColor = Color.White
    da_estado.BackColor = Color.White
    da_zona_postal.BackColor = Color.White
    co_banco.BackColor = Color.White
    de_banco.BackColor = Color.White
    co_tipo.BackColor = Color.White
    de_tipo.BackColor = Color.White
    co_cuenta.BackColor = Color.White
    da_observaciones.BackColor = Color.White
    Dim h As IPPacketInformation
    co_proveedor.Text = h.Address.ToString

    'cadena = "SELECT * FROM TAB_PERMISOS_VENTANA WHERE CO_USUARIO='" & g_conexion.co_usuario.Text & "' AND CO_VENTANA='" & NU_VENTANA & "' AND CO_ADMINISTRACION='" & g_conexion.co_administracion.Text & "'"
    'ur_1 = SQL1(cadena, Me)
    'If ur_1 > 0 Then
    '    ACTIVAR_BOTONES(SysDrow("DA_OPERACION"), 0, Me)
    'Else
    '    ACTIVAR_BOTONES("00000101", 0, Me)
    'End If

  End Sub

  Sub A_PROVEEDORES()
    If LV_COMANDO = 1 Then
      cadena = "SELECT * FROM MST_PROVEEDORES WHERE CO_PROVEEDOR= 'X' "
    Else
      If LV_COMANDO = 2 Then
        cadena = "SELECT * FROM MST_PROVEEDORES WHERE CO_PROVEEDOR='" & co_proveedor.Text & "'"
      End If
    End If
    NpgDAdap = New Npgsql.NpgsqlDataAdapter(cadena, NpgConn)
    NpgCmdBld = New Npgsql.NpgsqlCommandBuilder(NpgDAdap)

    SysDset = New DataSet
    NpgTrans = NpgConn.BeginTransaction(IsolationLevel.ReadCommitted)

    NpgDAdap.Fill(SysDset, "MST_PROVEEDORES")
    SysDrow = SysDset.Tables("MST_PROVEEDORES").NewRow()
    '
    SysDrow("CO_PROVEEDOR") = co_proveedor.Text
    SysDrow("DE_PROVEEDOR") = de_proveedor.Text
    'SysDrow("DA_REPRESENTANTE") = da_representante.Text
    SysDrow("DA_DIRECCION") = da_direccion.Text
    SysDrow("DA_TELEFONOS") = da_telefono.Text
    'SysDrow("DA_FAX") = da_fax.Text
    SysDrow("DA_RIF") = da_rif.Text
    SysDrow("DA_NIT") = da_nit.Text
    'SysDrow("DA_MUNICIPIO") = da_municipio.Text
    'SysDrow("DA_DISTRITO") = da_distrito.Text
    'SysDrow("DA_CIUDAD") = da_ciudad.Text
    'SysDrow("DA_ESTADO") = da_estado.Text
    'SysDrow("DA_ZONA_POSTAL") = da_zona_postal.Text
    'SysDrow("CO_BANCO") = co_banco.Text
    'SysDrow("CO_TIPO_CUENTA") = co_tipo.Text
    'SysDrow("CO_CUENTA") = co_cuenta.Text
    'SysDrow("DA_OBSERVACIONES") = da_observaciones.Text

    If st_personalidad.Checked Then
      SysDrow("ST_PERSONALIDAD") = "J"
    Else
      SysDrow("ST_PERSONALIDAD") = "N"
    End If

    If st_constituido.Checked Then
      SysDrow("ST_CONSTITUIDA") = "S"
    Else
      SysDrow("ST_CONSTITUIDA") = "N"
    End If

    If st_domiciliado.Checked Then
      SysDrow("ST_DOMICILIADA") = "S"
    Else
      SysDrow("ST_DOMICILIADA") = "N"
    End If

    If st_rif.Checked Then
      SysDrow("ST_RIF") = "V"
    Else
      SysDrow("ST_RIF") = "I"
    End If

    Select Case Asc(Mid(co_proveedor.Text, 1, 1))
      Case Asc("J"), Asc("j"), Asc("V"), Asc("v"), Asc("E"), Asc("e"), Asc("P"), Asc("p"), Asc("G"), Asc("g")
        SysDrow("ST_PROVEEDOR") = "A"
      Case Asc("L"), Asc("l")
        SysDrow("ST_PROVEEDOR") = "L"
    End Select

    ' update
    SysDset.Tables("MST_PROVEEDORES").Rows.Add(SysDrow)
    NpgDAdap.Update(SysDset, "MST_PROVEEDORES")

    NpgCmdBld = Nothing
    SysDset = Nothing
    NpgDAdap = Nothing

    NpgTrans.Commit()
    NpgConn.Close()

    'ADD_AUDITORIA("02", "1", "NA", "NA", "NA", "NA", 0, "NA", co_proveedor.Text, 0, Me, SialuzConn)

  End Sub

  Private Sub btn_agregar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_agregar.Click
    LP_PROVEEDORES()
    LV_COMANDO = 1
    co_proveedor.Enabled = True
    co_proveedor.Focus()
    'ACTIVAR_BOTONES("00000101", 0, Me)
    DB_PROVEEDORES()

  End Sub

  Private Sub btn_salir_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_guardar.Click
    Me.Close()
  End Sub

  Private Sub btn_guardar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_guardar.Click
    A_PROVEEDORES()
  End Sub

  Private Sub w_mnt_Proveedores_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    LP_PROVEEDORES()
  End Sub

End Class
