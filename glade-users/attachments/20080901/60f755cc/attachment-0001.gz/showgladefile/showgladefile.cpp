#include <libglademm.h>
#include <gtkmm.h>
#include <iostream>


class GladeFileViewer
{
	Glib::RefPtr<Gnome::Glade::Xml> file_;
	bool validfile_;
	std::string topwname_;
	std::string filename_;

	Gtk::Widget * w_;
	bool hastoplevelwindow_;
	
public:
	GladeFileViewer(const std::string & filename, const std::string & topwidget) 
	: topwname_(topwidget), validfile_(false), w_(0), hastoplevelwindow_(true), filename_(filename)
	{
		try
		{

			file_ = Gnome::Glade::Xml::create(filename_);
			validfile_ = true;
		}
		catch (const Glib::Error & e)
		{
			Gtk::MessageDialog("Error getting file" , "There was an error trying to get the glade file").run();
		}
	}


	Gtk::Window * getWindow() { 
		Gtk::Window * w = 0;

		try
		{
			file_->get_widget(topwname_, w_);
		}
		catch (const Glib::Error & e)
		{
			Gtk::MessageDialog("Error getting window" , "There was an error trying to get the window").run();
		}

		if (w_ != 0 && dynamic_cast<Gtk::Window *>(w_)) {
			static_cast<Gtk::Window *>(w_)->set_title("Preview");
			static_cast<Gtk::Window *>(w_)->set_default_size(640, 480);
			return static_cast<Gtk::Window *>(w_);
		}
		else if (w_ != 0) {
			//Get the top widget, which is not a Gtk::Window
			Gtk::Widget * aux = w_;
			w_ = new Gtk::Window; static_cast<Gtk::Window *>(w_)->set_title("Preview");
			static_cast<Gtk::Window *>(w_)->set_default_size(640, 480);
			static_cast<Gtk::Window*>(w_)->add(*aux);
			hastoplevelwindow_ = false;
		}
	}


	~GladeFileViewer()
	{
		if (validfile_ && !hastoplevelwindow_)
			delete w_;
	}

	
};



int main(int argc, char * argv[])
{
	if (argc < 2)
		std::cout << "Usage: show_layout filename [topwidget]" << std::endl;
	else
	{
		Gtk::Main m(argc, argv);
	
		GladeFileViewer gfv(argv[1], (argc == 2) ? "mainwindow" : argv[2]);
		Gtk::Window * w =  gfv.getWindow();

		w->show_all();
		Gtk::Main::run(*w);
	}
}
